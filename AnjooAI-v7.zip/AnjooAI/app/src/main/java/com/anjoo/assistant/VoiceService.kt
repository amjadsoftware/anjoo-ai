package com.anjoo.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Keeps Anjoo AI listening in the background. Say "Anjoo" followed by a command.
 * Call and SMS ask for a spoken "haan" first.
 */
class VoiceService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_STOP = "com.anjoo.assistant.STOP"
        const val ACTION_LISTEN = "com.anjoo.assistant.LISTEN"
        private const val CHANNEL = "anjoo_voice"
        private const val NOTIF_ID = 7

        @Volatile
        var running = false

        private val WAKE = listOf("anjoo", "anju", "anjo", "انجو", "آنجو", "انجُو")
        private val YES = setOf(
            "haan", "han", "haa", "ha", "yes", "yeah", "ji", "jee", "ok", "okay", "theek", "thik",
            "bilkul", "kardo", "karo", "ہاں", "جی", "ٹھیک", "بالکل", "کردو", "کرو"
        )
        private val NO = setOf("nahi", "nahin", "na", "no", "mat", "nope", "نہیں", "نہ", "مت", "نا")
    }

    private enum class Mode { LISTEN, CONFIRM, BUSY, SPEAKING }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var urduOk = false
    private lateinit var agent: Agent
    private lateinit var actions: Actions
    private var overlay: View? = null

    @Volatile private var mode = Mode.LISTEN
    private var awaitingCommand = false
    private var stopped = false
    private var speakSeq = 0
    private var lastStart = 0L
    private var lastDiag = 0L
    private var confirmLatch: CountDownLatch? = null
    @Volatile private var confirmAnswer = false

    // ---------- lifecycle ----------

    override fun onCreate() {
        super.onCreate()
        running = true
        createChannel()
        try {
            val n = notification("Sun raha hoon. Bolein: Anjoo, phir hukm.")
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Background mode shuru nahi ho saka (mic ya notification ki ijazat check karein).", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        addOverlay()
        actions = Actions(this) { askYesNo(it) }
        agent = Agent(this, actions)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_LISTEN -> main.post {
                awaitingCommand = true
                if (mode == Mode.LISTEN) startListening(0)
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopped = true
        running = false
        main.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
        tts?.shutdown()
        confirmLatch?.countDown()
        removeOverlay()
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        val t = tts
        if (status == TextToSpeech.SUCCESS && t != null) {
            ttsReady = true
            urduOk = t.isLanguageAvailable(Locale("ur", "PK")) >= TextToSpeech.LANG_AVAILABLE
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    main.post { onSpeakDone(utteranceId ?: "") }
                }
                override fun onError(utteranceId: String?) {
                    main.post { onSpeakDone(utteranceId ?: "") }
                }
            })
        }
        agent.urduScriptVoice = urduOk
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Is phone par awaaz pehchaan maujood nahi. Google app install karein.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        startListening(500)
        main.postDelayed(watchdog, 15000)
    }

    // ---------- keep the recogniser alive ----------

    private val watchdog = object : Runnable {
        override fun run() {
            if (stopped) return
            if (mode == Mode.LISTEN && SystemClock.elapsedRealtime() - lastStart > 40000) startListening(0)
            main.postDelayed(this, 15000)
        }
    }

    private fun startListening(delayMs: Long) {
        if (stopped) return
        main.postDelayed({ doStart() }, delayMs)
    }

    private fun doStart() {
        if (stopped || (mode != Mode.LISTEN && mode != Mode.CONFIRM)) return
        try {
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(listener)
            recognizer = r
            val lang = getSharedPreferences("anjoo", MODE_PRIVATE).getString("lang", "ur-PK") ?: "ur-PK"
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            lastStart = SystemClock.elapsedRealtime()
            r.startListening(i)
        } catch (e: Exception) {
            startListening(3000)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (stopped) return
            when (mode) {
                Mode.CONFIRM -> {
                    confirmAnswer = false
                    confirmLatch?.countDown()
                }
                Mode.LISTEN -> {
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        stopSelf()
                        return
                    }
                    if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT &&
                        SystemClock.elapsedRealtime() - lastDiag > 15000
                    ) {
                        lastDiag = SystemClock.elapsedRealtime()
                        Buddy.post(3, "[MIC] awaaz pehchaan ka masla (code $error)" +
                            if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                                error == SpeechRecognizer.ERROR_SERVER) " - internet check karein" else "")
                    }
                    val wait = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 150L
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER -> 4000L
                        else -> 1500L
                    }
                    startListening(wait)
                }
                else -> {}
            }
        }

        override fun onResults(results: Bundle?) {
            if (stopped) return
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            when (mode) {
                Mode.CONFIRM -> {
                    confirmAnswer = isYes(text)
                    confirmLatch?.countDown()
                }
                Mode.LISTEN -> handleHeard(text)
                else -> {}
            }
        }
    }

    // ---------- what was heard ----------

    private fun handleHeard(text: String) {
        val heard = text.trim()
        if (heard.isEmpty()) {
            startListening(150)
            return
        }
        val lower = heard.lowercase(Locale.ROOT)
        var found: String? = null
        for (w in WAKE) {
            val i = lower.indexOf(w)
            if (i >= 0) {
                found = heard.substring(i + w.length).trim().trimStart(',', '.', '،', ':', '-', ' ')
                break
            }
        }
        val needWake = getSharedPreferences("anjoo", MODE_PRIVATE).getBoolean("wake", false)
        val command: String = found ?: if (awaitingCommand || !needWake) heard else {
            startListening(150)
            return
        }
        if (command.isBlank()) {
            awaitingCommand = true
            mode = Mode.SPEAKING
            speak("Ji?", "ack")
            return
        }
        awaitingCommand = false
        Buddy.post(0, command)
        process(command)
    }

    private fun process(command: String) {
        mode = Mode.BUSY
        try { recognizer?.cancel() } catch (e: Exception) {}
        setStatus("Soch raha hoon...")
        Thread {
            val answer = try {
                agent.ask(command)
            } catch (e: Exception) {
                "Masla aaya. " + (e.message ?: "").take(80)
            }
            main.post { deliver(answer) }
        }.start()
    }

    private fun deliver(text: String) {
        if (stopped) return
        setStatus("Sun raha hoon. Bolein: Anjoo, phir hukm.")
        if (text.isBlank()) {
            mode = Mode.LISTEN
            startListening(300)
            return
        }
        mode = Mode.SPEAKING
        Buddy.post(1, text)
        speak(text, "reply")
    }

    // ---------- spoken yes/no for call and SMS ----------

    private fun isYes(text: String): Boolean {
        val words = text.lowercase(Locale.ROOT).split(Regex("[\\s,.!?؟،]+")).filter { it.isNotEmpty() }
        if (words.any { it in NO }) return false
        return words.any { it in YES }
    }

    /** Called from the agent thread: speaks the question, listens once, returns true only on a clear yes. */
    private fun askYesNo(message: String): Boolean {
        val latch = CountDownLatch(1)
        confirmLatch = latch
        confirmAnswer = false
        main.post {
            mode = Mode.SPEAKING
            try { recognizer?.cancel() } catch (e: Exception) {}
            speak(message.replace('\n', ' ') + ". Haan ya nahi bolein.", "confirm")
        }
        val finished = latch.await(45, TimeUnit.SECONDS)
        main.post {
            try { recognizer?.cancel() } catch (e: Exception) {}
            mode = Mode.BUSY
        }
        return finished && confirmAnswer
    }

    // ---------- speaking ----------

    private fun speak(text: String, id: String) {
        val t = tts
        if (t == null || !ttsReady) {
            main.post { onSpeakDone(id) }
            return
        }
        val urdu = text.any { it in '؀'..'ۿ' }
        t.setLanguage(if (urdu && urduOk) Locale("ur", "PK") else Locale("en", "IN"))
        val o = Style.officer(this)
        t.setPitch(o.pitch)
        t.setSpeechRate(o.rate)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        // If the speech engine never reports back, do not stay deaf forever.
        val seq = ++speakSeq
        main.postDelayed({
            if (seq == speakSeq && mode == Mode.SPEAKING) onSpeakDone(id)
        }, 8000L + text.length * 150L)
    }

    private fun onSpeakDone(id: String) {
        if (stopped) return
        speakSeq++
        when (id) {
            "confirm" -> {
                mode = Mode.CONFIRM
                startListening(150)
            }
            "ack" -> {
                mode = Mode.LISTEN
                awaitingCommand = true
                startListening(150)
            }
            else -> {
                mode = Mode.LISTEN
                startListening(400)
            }
        }
    }

    // ---------- notification and overlay ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Anjoo AI", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP), flags
        )
        val talk = PendingIntent.getService(
            this, 2, Intent(this, VoiceService::class.java).setAction(ACTION_LISTEN), flags
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Anjoo AI chal raha hai")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now), "Bolein", talk
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Band karein", stop
                ).build()
            )
            .build()
    }

    private fun setStatus(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(text))
        } catch (e: Exception) {}
    }

    /**
     * A 1-pixel invisible window. Android lets a background app open other apps
     * (needed for "WhatsApp kholo") only while it has a visible overlay window.
     */
    private fun addOverlay() {
        try {
            if (!Settings.canDrawOverlays(this)) return
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val v = View(this)
            v.setBackgroundColor(Color.argb(1, 0, 0, 0))
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            overlay = v
        } catch (e: Exception) {}
    }

    private fun removeOverlay() {
        try {
            overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        } catch (e: Exception) {}
        overlay = null
    }
}
