package com.anjoo.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.CountDownLatch

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private val SYSTEM = """
Tum "Anjoo AI" ho, Android phone ka awaazi assistant. User ke hukm tools ke zariye poore karo: app kholna, call, SMS, WhatsApp, alarm, timer, search, rasta.
Agar kaam ke liye tool maujood hai to pehle kaam karo, phir bas ek chhota jumla bolo ke kya hua.
Contact ka naam jaisa user ne bola waisa hi tool ko do. Agar kai contacts milen ya naam saaf na ho to user se ek chhota sawal poochho.
User ke likhe hue ya bole hue ki zubaan aur script mein jawab do: Urdu script ho to Urdu script mein, Roman Urdu ho to Roman Urdu mein, English ho to English mein.
Tumhara jawab awaaz mein parha jayega, isliye bohat chhota rakho: ek ya do jumle, markdown, list ya emoji ke baghair.
Doosri app ke andar kaam ke liye type_text, tap_text, press_key, read_screen aur copy_text tools hain. Pehle open_app se app kholo, phir type_text ya tap_text. Jo phir bhi na ho sake wo saaf bata do.
Jab user kahe "yaad rakho" ya koi pakki zaroori baat bataye (naam, rishte, aadatein), remember tool se save karo. Pehle se yaad rakhi baatein neeche likhi hain, unhe zaroorat par istemal karo.
Waqt ya tareekh waale kaam (alarm, calendar) ke liye neeche diye gaye abhi ke waqt se hisab lagao.
""".trim()

    private fun systemPrompt(): String {
        val now = java.text.SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(java.util.Date())
        val n = actions.notes()
        val sb = StringBuilder(SYSTEM)
        sb.append("\n").append(Style.officer(this).persona)
        sb.append("\nAbhi ka waqt: ").append(now).append(" (").append(java.util.TimeZone.getDefault().id).append(").")
        if (n.isNotEmpty()) sb.append("\nYaad rakhi baatein:\n- ").append(n.joinToString("\n- "))
        return sb.toString()
    }

    private lateinit var log: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var mic: Button
    private lateinit var langBtn: Button
    private lateinit var bgBtn: Button

    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    @Volatile private var busy = false
    private var lang = "ur-PK"

    private val DEFAULT_MODEL = "gemini-3.8-flash"

    private val history = JSONArray()
    private lateinit var actions: Actions
    private val prefs by lazy { getSharedPreferences("anjoo", MODE_PRIVATE) }

    private var themeIdx = 0
    private var officerIdx = 0
    private val th get() = Style.themes[themeIdx]
    private val off get() = Style.officers[officerIdx]
    private val BG get() = th.bg
    private val SURFACE get() = th.surface
    private val ACCENT get() = th.accent
    private val USER get() = th.user
    private val INK get() = th.ink
    private val MUTED get() = th.muted

    private class Line(val text: String, val kind: Int) // 0 user, 1 officer, 2 system
    private val lines = mutableListOf<Line>()
    private lateinit var rain: RainView
    private lateinit var buddy: MarkhorView
    private var seenStamp = 0L
    private lateinit var status: TextView
    private val ui = Handler(Looper.getMainLooper())
    private var torchOn = false
    private fun micIdle() = if (VoiceService.running) "[ LIVE: STOP ]" else "[ START LIVE ]"

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        themeIdx = prefs.getInt("theme", 0).coerceIn(0, Style.themes.size - 1)
        officerIdx = prefs.getInt("officer", 0).coerceIn(0, Style.officers.size - 1)
        buildUi()
        lang = prefs.getString("lang", "ur-PK") ?: "ur-PK"
        langBtn.text = if (lang == "ur-PK") "URDU" else "ENG"
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS
            ), 1
        )
        tts = TextToSpeech(this, this)
        actions = Actions(this) { confirmDialog(it) }
        bootSequence()
        buddy.setMood(Mood.HAPPY, 3500)
        if (apiKey().isEmpty()) showSettings()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        ttsOk = status == TextToSpeech.SUCCESS
    }

    // ---------- UI ----------

    private fun box(fill: Int, stroke: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill); cornerRadius = radius.toFloat(); setStroke(dp(1), stroke)
        }

    private fun bootSequence() {
        val boot = listOf(
            "> BOOT ANJOO-OS v4.0 ........ OK",
            "> LOADING MODULES ............ OK",
            "> ENCRYPTED LINK (GEMINI) .... " + (if (apiKey().isEmpty()) "NO KEY" else "SECURE"),
            "> OFFICER " + off.code + " ... ONLINE"
        )
        boot.forEachIndexed { i, t -> ui.postDelayed({ addLine(t, 2) }, i * 350L) }
        ui.postDelayed({ addLine(off.greet, 1) }, boot.size * 350L)
    }

    private fun buildUi() {
        val frame = FrameLayout(this).apply { setBackgroundColor(BG) }
        rain = RainView(this, ACCENT)
        frame.addView(rain, FrameLayout.LayoutParams(-1, -1))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        frame.addView(root, FrameLayout.LayoutParams(-1, -1))

        val title = TextView(this).apply {
            text = "ANJOO//AI"
            setTextColor(ACCENT)
            textSize = 22f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            letterSpacing = 0.12f
            setShadowLayer(14f, 0f, 0f, ACCENT)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(chip("MENU") { showMenu() })
        root.addView(head)
        status = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextColor(MUTED)
        }
        root.addView(status)

        langBtn = Button(this)
        bgBtn = Button(this)

        log = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "root@anjoo:~$ "
            typeface = Typeface.MONOSPACE
            setHintTextColor(MUTED)
            setTextColor(INK)
            background = box(SURFACE, ACCENT, dp(10))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            maxLines = 3
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(chip("EXEC") { sendTyped() })
        root.addView(row)

        mic = Button(this).apply {
            text = micIdle()
            textSize = 18f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(ACCENT)
            setShadowLayer(10f, 0f, 0f, ACCENT)
            background = box(Color.argb(60, Color.red(ACCENT), Color.green(ACCENT), Color.blue(ACCENT)), ACCENT, dp(14))
            setOnClickListener { toggleBackground() }
        }
        root.addView(mic, LinearLayout.LayoutParams(-1, dp(62)).apply { topMargin = dp(10) })

        buddy = MarkhorView(this, ACCENT)
        frame.addView(buddy, FrameLayout.LayoutParams(-1, -1))

        setContentView(frame)
        refreshStatus()
        bgBtn.text = if (VoiceService.running) "BG:ON" else "BG"
        mic.text = micIdle()
    }

    private fun refreshStatus() {
        status.text = "[" + th.name + "]  OFFICER " + off.code + " // " + off.role + "  //  LINK SECURE"
    }

    private fun chip(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        textSize = 12f
        setTextColor(ACCENT)
        background = box(SURFACE, ACCENT, dp(8))
        setPadding(dp(12), 0, dp(12), 0)
        minHeight = 0
        minimumHeight = dp(38)
        minWidth = 0
        minimumWidth = 0
        layoutParams = LinearLayout.LayoutParams(-2, dp(38)).apply { rightMargin = dp(6) }
        setOnClickListener { onClick() }
    }

    private fun moduleChip(label: String, onClick: () -> Unit) = Button(this).apply {
        text = "▶ $label"
        isAllCaps = false
        typeface = Typeface.MONOSPACE
        textSize = 11f
        setTextColor(INK)
        background = box(Color.TRANSPARENT, MUTED, dp(6))
        setPadding(dp(10), 0, dp(10), 0)
        minHeight = 0
        minimumHeight = dp(32)
        minWidth = 0
        minimumWidth = 0
        layoutParams = LinearLayout.LayoutParams(-2, dp(32)).apply { rightMargin = dp(6) }
        setOnClickListener { onClick() }
    }

    /** Runs a tool straight away, with no Gemini call, and prints the result in the log. */
    private fun direct(label: String, tool: String, args: JSONObject, after: () -> Unit = {}) {
        Thread {
            val r = try {
                actions.run(tool, args).also { runOnUiThread { after() } }
            } catch (e: Exception) {
                "ERR: " + (e.message ?: e.javaClass.simpleName)
            }
            addLine("[EXEC] $label -> $r", 2)
        }.start()
    }

    private fun prefill(t: String) {
        input.setText(t)
        input.setSelection(t.length)
        input.requestFocus()
    }

    private fun showMenu() {
        val items = arrayOf(
            "Gemini key / model",
            "Colour mode",
            "Cyber officer",
            "Zubaan: " + (if (lang == "ur-PK") "URDU" else "ENGLISH") + " (badlein)",
            "Accessibility on karein (likhna / tap)",
            "Wake word 'Anjoo': " + (if (prefs.getBoolean("wake", false)) "ON (pehle Anjoo bolna parega)" else "OFF (har baat hukm hai)") + " - badlein"
        )
        AlertDialog.Builder(this)
            .setTitle("MENU")
            .setItems(items) { _, i ->
                when (i) {
                    0 -> showSettings()
                    1 -> pickTheme()
                    2 -> pickOfficer()
                    3 -> toggleLang()
                    4 -> openAccess()
                    5 -> {
                        val on = !prefs.getBoolean("wake", false)
                        prefs.edit().putBoolean("wake", on).apply()
                        addLine("> WAKE WORD " + (if (on) "ON" else "OFF"), 2)
                    }
                }
            }.show()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.action == MotionEvent.ACTION_DOWN && ::buddy.isInitialized) {
            val loc = IntArray(2)
            buddy.getLocationOnScreen(loc)
            buddy.onTap(ev.rawX - loc[0], ev.rawY - loc[1])
        }
        return super.dispatchTouchEvent(ev)
    }

    private val poller = object : Runnable {
        override fun run() {
            if (Buddy.stamp != seenStamp) {
                seenStamp = Buddy.stamp
                val t = Buddy.text
                if (Buddy.kind >= 2) {
                    addLine(t, 2)
                } else if (Buddy.kind == 0) {
                    addLine(t, 0)
                    buddy.setMood(Mood.THINKING, 0)
                } else {
                    addLine(t, 1)
                    buddy.setMood(Mood.fromText(t) ?: Mood.HAPPY, 6000)
                    buddy.talk(minOf(8000L, t.length * 70L))
                }
            }
            ui.postDelayed(this, 400)
        }
    }

    override fun onPause() {
        ui.removeCallbacks(poller)
        super.onPause()
    }

    private fun pickTheme() {
        AlertDialog.Builder(this)
            .setTitle("COLOUR MODE")
            .setItems(Style.themes.map { it.name }.toTypedArray()) { _, i ->
                themeIdx = i
                prefs.edit().putInt("theme", i).apply()
                rebuild()
            }.show()
    }

    private fun pickOfficer() {
        AlertDialog.Builder(this)
            .setTitle("CYBER OFFICER")
            .setItems(Style.officers.map { it.code + " - " + it.role }.toTypedArray()) { _, i ->
                officerIdx = i
                prefs.edit().putInt("officer", i).apply()
                refreshStatus()
                addLine("> OFFICER " + off.code + " ASSIGNED", 2)
                addLine(off.greet, 1)
                speakIdle(off.greet)
            }.show()
    }

    /** Re-draws the whole screen in the new colours and replays the log. */
    private fun rebuild() {
        val typed = if (::input.isInitialized) input.text.toString() else ""
        buildUi()
        input.setText(typed)
        lines.forEach { render(it) }
    }

    private fun addLine(text: String, kind: Int) {
        runOnUiThread {
            val l = Line(text, kind)
            lines.add(l)
            if (lines.size > 200) lines.removeAt(0)
            render(l)
        }
    }

    private fun addBubble(text: String, user: Boolean) = addLine(text, if (user) 0 else 1)

    private fun render(l: Line) {
        val tv = TextView(this).apply {
            textDirection = TextView.TEXT_DIRECTION_FIRST_STRONG
            when (l.kind) {
                0 -> {
                    text = "$ " + l.text
                    textSize = 15f
                    typeface = Typeface.MONOSPACE
                    setTextColor(INK)
                    background = box(USER, ACCENT, dp(10))
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                }
                1 -> {
                    text = "[" + off.code + "] " + l.text
                    textSize = 16f
                    setTextColor(INK)
                    background = box(SURFACE, ACCENT, dp(10))
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                }
                else -> {
                    text = l.text
                    textSize = 12f
                    typeface = Typeface.MONOSPACE
                    setTextColor(ACCENT)
                    setPadding(dp(4), dp(1), dp(4), dp(1))
                }
            }
        }
        val lp = LinearLayout.LayoutParams(-2, -2)
        lp.topMargin = dp(if (l.kind == 2) 2 else 8)
        lp.gravity = if (l.kind == 0) Gravity.END else Gravity.START
        if (l.kind == 0) lp.marginStart = dp(40)
        if (l.kind == 1) lp.marginEnd = dp(40)
        log.addView(tv, lp)
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun setMic(text: String) = runOnUiThread { mic.text = if (text == "Bolein") micIdle() else text }

    // ---------- settings ----------

    private fun apiKey() = prefs.getString("key", "") ?: ""
    private fun model() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), 0)
        }
        val key = EditText(this).apply {
            hint = "Gemini API key (AIza...)"
            setText(apiKey())
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val mod = EditText(this).apply {
            hint = "Model"
            setText(model())
            inputType = InputType.TYPE_CLASS_TEXT
        }
        box.addView(key)
        box.addView(mod)
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setMessage("API key aistudio.google.com/apikey se banayein. Model ka naam wahin se dekh kar badal sakte hain (default: gemini-3.8-flash).")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit()
                    .putString("key", key.text.toString().trim())
                    .putString("model", mod.text.toString().trim().ifEmpty { DEFAULT_MODEL })
                    .apply()
            }
            .setNegativeButton("Band", null)
            .show()
    }

    override fun onResume() {
        super.onResume()
        seenStamp = Buddy.stamp
        ui.removeCallbacks(poller)
        ui.post(poller)
        bgBtn.text = if (VoiceService.running) "BG:ON" else "BG"
        mic.text = micIdle()
    }

    /** Turns the always-listening background mode on or off, asking for each permission in turn. */
    private fun toggleBackground() {
        if (VoiceService.running) {
            startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
            bgBtn.text = "BG"
            mic.text = "[ START LIVE ]"
            Toast.makeText(this, "Background mode band kar diya.", Toast.LENGTH_SHORT).show()
            return
        }
        if (apiKey().isEmpty()) { showSettings(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            Toast.makeText(this, "Mic ki ijazat dein, phir dobara Background dabayein.", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 3)
            Toast.makeText(this, "Notification ki ijazat dein, phir dobara Background dabayein.", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Anjoo AI ko 'Display over other apps' allow karein, phir wapas aa kar Background dabayein.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (!prefs.getBoolean("batteryAsked", false)) {
            prefs.edit().putBoolean("batteryAsked", true).apply()
            Toast.makeText(this, "Battery mein 'Allow' ya 'Unrestricted' karein, phir dobara Background dabayein.", Toast.LENGTH_LONG).show()
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
            return
        }
        if (AnjooAccess.inst == null && !prefs.getBoolean("accAsked", false)) {
            prefs.edit().putBoolean("accAsked", true).apply()
            Toast.makeText(this, "Doosri apps mein likhne/dabane ke liye Anjoo AI ko Accessibility mein on karein, phir wapas aa kar START LIVE dabayein.", Toast.LENGTH_LONG).show()
            openAccess()
            return
        }
        startForegroundService(Intent(this, VoiceService::class.java))
        bgBtn.text = "BG:ON"
        mic.text = "[ LIVE: STOP ]"
        buddy.setMood(Mood.LISTENING, 5000)
        Toast.makeText(this, "LIVE chalu. Ab back kar dein aur bolein: Anjoo, phir hukm.", Toast.LENGTH_LONG).show()
    }

    private fun openAccess() {
        Toast.makeText(this, "Downloaded Apps/Anjoo AI ko on karein. Agar band ho to App info > 3 dots > Allow restricted settings.", Toast.LENGTH_LONG).show()
        try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) {}
    }

    override fun onBackPressed() {
        if (VoiceService.running) moveTaskToBack(true) else super.onBackPressed()
    }

    private fun toggleLang() {
        lang = if (lang == "ur-PK") "en-US" else "ur-PK"
        prefs.edit().putString("lang", lang).apply()
        langBtn.text = if (lang == "ur-PK") "URDU" else "ENG"
    }

    private fun confirmDialog(msg: String): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        runOnUiThread {
            AlertDialog.Builder(this)
                .setMessage(msg)
                .setCancelable(false)
                .setPositiveButton("Haan") { _, _ -> ok = true; latch.countDown() }
                .setNegativeButton("Nahi") { _, _ -> latch.countDown() }
                .show()
        }
        latch.await()
        return ok
    }

    // ---------- voice in ----------

    private fun onMicClick() {
        if (VoiceService.running) {
            Toast.makeText(this, "Background mode chal raha hai. Pehle use band karein, ya bolein: Anjoo ...", Toast.LENGTH_LONG).show()
            return
        }
        tts?.stop()
        if (busy) return
        if (listening) { recognizer?.stopListening(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mic ki ijazat dein (Settings > Apps > Anjoo AI > Permissions).", Toast.LENGTH_LONG).show()
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Is phone par awaaz pehchaan maujood nahi. Google app install karein.", Toast.LENGTH_LONG).show()
            return
        }
        if (apiKey().isEmpty()) { showSettings(); return }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true; setMic("Sun raha hoon...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false; setMic("Samajh raha hoon...") }
            override fun onError(error: Int) {
                listening = false
                setMic("Bolein")
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Awaaz samajh nahi aayi, dobara bolein."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Internet check karein."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic ki ijazat nahi."
                    else -> "Awaaz ka masla aaya ($error)."
                }
                Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
            }
            override fun onResults(results: Bundle?) {
                listening = false
                setMic("Bolein")
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull()
                if (!text.isNullOrBlank()) submit(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        recognizer?.startListening(i)
    }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        submit(t)
    }

    // ---------- Claude loop ----------

    private fun submit(text: String) {
        if (busy) return
        if (apiKey().isEmpty()) { showSettings(); return }
        busy = true
        addBubble(text, true)
        setMic("Soch raha hoon...")
        buddy.setMood(Mood.THINKING, 0)
        Thread { runAgent(text) }.start()
    }

    private fun trimHistory() {
        // Keep roughly the last 30 messages, always starting at a plain user message.
        while (history.length() > 30) history.remove(0)
        while (history.length() > 0) {
            val m = history.getJSONObject(0)
            val first = m.getJSONArray("parts").optJSONObject(0)
            if (m.getString("role") == "user" && first != null && first.has("text")) break
            history.remove(0)
        }
    }

    private fun runAgent(text: String) {
        trimHistory()
        val startSize = history.length()
        history.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", text)))
        )
        var finalText = ""
        try {
            var steps = 0
            while (steps++ < 8) {
                val resp = Gemini.sendWithFallback(apiKey(), model(), systemPrompt(), history)
                val cands = resp.optJSONArray("candidates")
                if (cands == null || cands.length() == 0) {
                    val why = resp.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                    throw java.io.IOException("Jawab nahi mila. $why".trim())
                }
                val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                    ?: JSONArray()
                // Keep the model turn exactly as received (Gemini needs thought signatures echoed back).
                if (parts.length() > 0) {
                    history.put(JSONObject().put("role", "model").put("parts", parts))
                }

                val results = JSONArray()
                val said = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val fc = p.optJSONObject("functionCall")
                    if (fc != null) {
                        val name = fc.getString("name")
                        val out = try {
                            actions.run(name, fc.optJSONObject("args") ?: JSONObject())
                        } catch (e: Exception) {
                            "Kaam nahi ho saka: " + (e.message ?: e.javaClass.simpleName)
                        }
                        results.put(
                            JSONObject().put(
                                "functionResponse",
                                JSONObject().put("name", name)
                                    .put("response", JSONObject().put("result", out))
                            )
                        )
                    } else if (p.has("text") && !p.optBoolean("thought", false)) {
                        said.append(p.getString("text")).append(' ')
                    }
                }
                if (said.isNotBlank()) finalText = said.toString().trim()
                if (results.length() == 0) break
                history.put(JSONObject().put("role", "user").put("parts", results))
            }
            if (finalText.isNotEmpty()) {
                addBubble(finalText, false)
                buddy.setMood(Mood.fromText(finalText) ?: Mood.HAPPY, 6000)
                buddy.talk(minOf(8000L, finalText.length * 70L))
                speak(finalText)
            }
        } catch (e: Exception) {
            while (history.length() > startSize) history.remove(history.length() - 1)
            addBubble("Masla: " + (e.message ?: e.javaClass.simpleName), false)
            buddy.setMood(Mood.SAD, 6000)
        } finally {
            busy = false
            setMic("Bolein")
        }
    }

    // ---------- voice out ----------

    private fun speak(text: String) {
        val engine = tts ?: return
        if (!ttsOk) return
        val urduScript = text.any { it in '؀'..'ۿ' }
        val locale = if (urduScript) Locale("ur", "PK") else Locale("en", "IN")
        val r = engine.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) return
        engine.setPitch(off.pitch)
        engine.setSpeechRate(off.rate)
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "anjoo")
    }

    private fun speakIdle(text: String) { if (!VoiceService.running) speak(text) }
}
