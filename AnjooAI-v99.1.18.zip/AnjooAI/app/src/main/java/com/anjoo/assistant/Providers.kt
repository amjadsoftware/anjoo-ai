package com.anjoo.assistant

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** One AI company the app can talk to. kind: "gemini", "openai" (OpenAI-style API) or "anthropic". */
class Provider(
    val id: String,
    val label: String,
    val kind: String,
    val baseUrl: String,
    val models: List<String>,
    val keyHint: String,
    val keyUrl: String,
    /** Has a free tier (no card needed to start). */
    val free: Boolean = false,
    /** "llm" (direct company) or "gateway" (one key, many companies' models). */
    val group: String = "llm",
    /** Short extra instruction shown under the key box (e.g. key format). */
    val note: String = ""
)

/** A page that only gives a key for a helper service (search, speech, editors). Not a chat AI, so it has no models. */
class KeyLink(val label: String, val url: String, val group: String, val note: String)

/**
 * Lets the whole app keep using Gemini-shaped JSON (contents / parts / functionCall) while the
 * answer actually comes from another provider. Requests are translated on the way out and the
 * reply is translated back, so Agent, Coder, Studio and the chat screen do not need to change.
 */
object Providers {

    val ALL: List<Provider> = listOf(
        Provider(
            "gemini", "Google Gemini  (free tier, default)", "gemini",
            "https://generativelanguage.googleapis.com/v1beta",
            listOf(
                "gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-3.1-flash-lite", "gemini-3-flash-preview",
                "gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.5-flash-lite",
                "gemini-2.0-flash", "gemini-flash-latest", "gemini-flash-lite-latest", "gemini-pro-latest"
            ),
            "AIza...", "aistudio.google.com/apikey", free = true
        ),
        Provider(
            "openai", "OpenAI  (ChatGPT)", "openai", "https://api.openai.com/v1",
            listOf("gpt-5", "gpt-5-mini", "gpt-5-nano", "gpt-4.1", "gpt-4.1-mini", "gpt-4o", "gpt-4o-mini"),
            "sk-...", "platform.openai.com/api-keys"
        ),
        Provider(
            "anthropic", "Anthropic  (Claude)", "anthropic", "https://api.anthropic.com/v1",
            listOf("claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5", "claude-fable-5-1"),
            "sk-ant-...", "console.anthropic.com/settings/keys"
        ),
        Provider(
            "openrouter", "OpenRouter  (hundreds of models, some free)", "openai", "https://openrouter.ai/api/v1",
            listOf(
                "openrouter/free",
                "nvidia/nemotron-3-ultra-550b-a55b:free",
                "nvidia/nemotron-3.5-lightning:free",
                "nvidia/nemotron-3-super-120b-a12b:free",
                "nvidia/nemotron-3-nano-30b-a3b:free",
                "poolside/laguna-s-2.1:free",
                "thinkingmachines/inkling:free",
                "cohere/north-mini-code:free",
                "qwen/qwen3-coder:free",
                "qwen/qwen3-next-80b-a3b-instruct:free",
                "openai/gpt-oss-120b:free",
                "openai/gpt-oss-20b:free",
                "google/gemma-4-31b-it:free",
                "meta-llama/llama-3.3-70b-instruct:free",
                "nousresearch/hermes-3-llama-3.1-405b:free"
            ),
            "sk-or-...", "openrouter.ai/keys", free = true, group = "gateway"
        ),
        Provider(
            "groq", "Groq  (very fast, free tier)", "openai", "https://api.groq.com/openai/v1",
            listOf("openai/gpt-oss-120b", "openai/gpt-oss-20b", "qwen/qwen3.8-27b"),
            "gsk_...", "console.groq.com/keys", free = true
        ),
        Provider(
            "deepseek", "DeepSeek", "openai", "https://api.deepseek.com",
            listOf("deepseek-v4-flash", "deepseek-v4-pro", "deepseek-chat", "deepseek-reasoner"),
            "sk-...", "platform.deepseek.com/api_keys"
        ),
        Provider(
            "mistral", "Mistral", "openai", "https://api.mistral.ai/v1",
            listOf("mistral-large-latest", "mistral-medium-latest", "mistral-small-latest"),
            "", "console.mistral.ai/api-keys", free = true
        ),
        Provider(
            "xai", "xAI  (Grok)", "openai", "https://api.x.ai/v1",
            listOf("grok-4", "grok-3", "grok-3-mini"),
            "xai-...", "console.x.ai"
        ),
        Provider(
            "cloudflare", "Cloudflare Workers AI  (free daily quota)", "openai", "",
            listOf(
                "@cf/openai/gpt-oss-120b", "@cf/openai/gpt-oss-20b", "@cf/meta/llama-4-scout-17b-16e-instruct",
                "@cf/meta/llama-3.3-70b-instruct-fp8-fast", "@cf/qwen/qwen3-30b-a3b-fp8",
                "@cf/mistralai/mistral-small-3.1-24b-instruct", "@cf/meta/llama-3.1-8b-instruct"
            ),
            "ACCOUNT_ID:API_TOKEN", "dash.cloudflare.com/profile/api-tokens", free = true,
            note = "Cloudflare ko 2 cheezein chahiye: Account ID aur API Token (Workers AI permission). Dono yun likhein: ACCOUNT_ID:API_TOKEN (beech mein colon). Account ID dash.cloudflare.com ke Workers & Pages page par dayen taraf milti hai."
        ),
        Provider(
            "nvidia", "NVIDIA NIM  (free credits)", "openai", "https://integrate.api.nvidia.com/v1",
            listOf(
                "meta/llama-3.3-70b-instruct", "openai/gpt-oss-120b", "deepseek-ai/deepseek-v3.1",
                "qwen/qwen3-coder-480b-a35b-instruct", "moonshotai/kimi-k2-instruct", "nvidia/llama-3.1-nemotron-ultra-253b-v1"
            ),
            "nvapi-...", "build.nvidia.com/settings/api-keys", free = true
        ),
        Provider(
            "cohere", "Cohere  (free trial key)", "openai", "https://api.cohere.ai/compatibility/v1",
            listOf("command-a-03-2025", "command-r-plus-08-2024", "command-r-08-2024", "command-r7b-12-2024"),
            "", "dashboard.cohere.com/api-keys", free = true
        ),
        Provider(
            "huggingface", "Hugging Face  (monthly free credits)", "openai", "https://router.huggingface.co/v1",
            listOf(
                "openai/gpt-oss-120b", "Qwen/Qwen3-235B-A22B-Instruct-2507", "meta-llama/Llama-3.3-70B-Instruct",
                "deepseek-ai/DeepSeek-V3.2", "moonshotai/Kimi-K2-Instruct"
            ),
            "hf_...", "huggingface.co/settings/tokens", free = true,
            note = "Token banate waqt \"Make calls to Inference Providers\" ki permission on karein."
        ),
        Provider(
            "github", "GitHub Models  (free with GitHub account)", "openai", "https://models.github.ai/inference",
            listOf("openai/gpt-4.1", "openai/gpt-4.1-mini", "openai/gpt-4o", "meta/Llama-3.3-70B-Instruct", "deepseek/DeepSeek-V3-0324", "microsoft/Phi-4"),
            "github_pat_...", "github.com/settings/personal-access-tokens/new", free = true,
            note = "GitHub token banate waqt Permissions mein \"Models\" ko Read-only karein. Models ki list github.com/marketplace/models par hai."
        ),
        Provider(
            "alibaba", "Alibaba Qwen  (Model Studio / DashScope)", "openai", "https://dashscope-intl.aliyuncs.com/compatible-mode/v1",
            listOf("qwen3.7-max", "qwen3.7-plus", "qwen3.6-plus", "qwen3-coder-plus", "qwen-plus", "qwen-flash", "qwen-max", "qwen-turbo"),
            "sk-...", "modelstudio.console.alibabacloud.com/?tab=dashboard#/api-key", free = true,
            note = "Ye key international (Singapore) region ki hai. China wali key is address par nahi chalti."
        ),
        Provider(
            "zai", "Z.ai  (Zhipu GLM)", "openai", "https://open.bigmodel.cn/api/paas/v4",
            listOf("glm-4.5-flash", "glm-4.7-flash", "glm-5.2", "glm-5.1", "glm-4.5-air", "glm-4.6", "glm-4.7", "glm-4-plus"),
            "", "open.bigmodel.cn/usercenter/proj-mgmt/apikeys", free = true,
            note = "glm-4.5-flash free hai (retire hone ka elaan ho chuka hai); agar na chale to glm-4.7-flash chunein."
        ),
        Provider(
            "kilo", "Kilo AI  (gateway, many models)", "openai", "https://api.kilo.ai/api/gateway",
            listOf("kilo/auto", "anthropic/claude-sonnet-4.5", "openai/gpt-5.5", "google/gemini-3-pro-preview"),
            "", "app.kilo.ai", group = "gateway",
            note = "app.kilo.ai par login karke API Keys mein key banayen. Kuch models free hain, baqi credits se chalte hain."
        ),
        Provider(
            "chutes", "Chutes  (gateway, open-source models)", "openai", "https://llm.chutes.ai/v1",
            listOf("deepseek-ai/DeepSeek-V3.2-TEE", "zai-org/GLM-4.7-TEE", "moonshotai/Kimi-K2.5-TEE", "Qwen/Qwen3-Coder-Next-TEE", "openai/gpt-oss-120b-TEE"),
            "cpk_...", "chutes.ai/app/api", group = "gateway",
            note = "Chutes ab zyada tar paid hai: pehle account mein thora balance daalna parta hai."
        ),
        Provider(
            "pollinations", "Pollinations  (free, text + pictures)", "openai", "https://gen.pollinations.ai/v1",
            listOf("openai", "openai-fast", "mistral"),
            "", "enter.pollinations.ai", free = true,
            note = "Free key enter.pollinations.ai par banti hai (card nahi chahiye). Isi key se Pollinations ki pictures bhi behtar chalti hain. Models ki list 'Load all models' se aa jati hai."
        ),
        Provider(
            "together", "Together AI  (free trial credits)", "openai", "https://api.together.xyz/v1",
            listOf("meta-llama/Llama-3.3-70B-Instruct-Turbo", "deepseek-ai/DeepSeek-V3", "Qwen/Qwen2.5-72B-Instruct-Turbo", "moonshotai/Kimi-K2-Instruct"),
            "", "api.together.xyz/settings/api-keys", free = true,
            note = "Naye account par free trial credits milte hain. Models ke naam badalte rehte hain: 'Load all models' dabayen."
        ),
        Provider(
            "fireworks", "Fireworks AI  (free tier)", "openai", "https://api.fireworks.ai/inference/v1",
            listOf("accounts/fireworks/models/llama-v3p3-70b-instruct", "accounts/fireworks/models/deepseek-v3", "accounts/fireworks/models/qwen3-235b-a22b"),
            "fw_...", "fireworks.ai/account/api-keys", free = true,
            note = "Models ke naam badalte rehte hain: 'Load all models' dabayen."
        ),
        Provider(
            "nous", "Nous Portal  (Hermes, free tier)", "openai", "https://inference-api.nousresearch.com/v1",
            listOf("Hermes-4-405B", "Hermes-4-70B"),
            "", "portal.nousresearch.com", free = true
        ),
        Provider(
            "moonshot", "Moonshot  (Kimi, open model)", "openai", "https://api.moonshot.ai/v1",
            listOf("kimi-k2.6", "kimi-k2.7-code", "kimi-k3", "kimi-k2-0905-preview"),
            "sk-...", "platform.moonshot.ai/console/api-keys",
            note = "Kimi ke open models. Key banane par shayad pehle thora balance daalna pare."
        ),
        Provider(
            "ollama", "Ollama  (on your phone/PC, free, unlimited)", "openai", "http://127.0.0.1:11434/v1",
            listOf("llama3.3", "qwen3", "deepseek-r1", "mistral", "gemma3"),
            "ollama", "ollama.com/download", free = true,
            note = "Ollama aap ke apne device par chalta hai (jaise Termux mein). Key ki jagah koi bhi lafz likhein, jaise ollama. Ye address sirf isi phone ka hai; PC wale Ollama ke liye 'Custom' chunein aur http://PC-IP:11434/v1 likhein. Models: pehle 'ollama pull llama3.3' chalayen."
        ),
        Provider(
            "fal", "Fal.ai  (pictures only)", "openai", "",
            listOf("fal-ai/flux/schnell", "fal-ai/flux/dev"),
            "", "fal.ai/dashboard/keys", free = true, group = "image",
            note = "Ye sirf pictures banata hai, chat nahi. Key save karne se baqi chat AI nahi badlega. Free starter credits milte hain."
        ),
        Provider(
            "custom", "Custom  (any OpenAI-compatible URL)", "openai", "",
            emptyList(), "", ""
        )
    )

    /** Key pages for helper services that are not chat AIs. Shown in the "all key links" list only. */
    val EXTRA_LINKS: List<KeyLink> = listOf(
        KeyLink("Tavily  (web search)", "app.tavily.com/home", "tool", "Free key shuru mein; search ke liye."),
        KeyLink("Jina AI  (read pages, search)", "jina.ai/?sui=apikey", "tool", "Free key mil jati hai."),
        KeyLink("AssemblyAI  (speech to text)", "assemblyai.com/dashboard/api-keys", "tool", "Free credits milte hain."),
        KeyLink("Codeium", "codeium.com", "coding", "Sirf editor/extension ke andar chalta hai, isse chat key nahi banti."),
        KeyLink("Windsurf Editor", "windsurf.com", "coding", "Sirf Windsurf editor ke andar chalta hai, isse chat key nahi banti."),
        KeyLink("Replit", "replit.com", "coding", "Replit ka koi public chat API key nahi hai."),
        KeyLink("Ampere", "ampere.sh", "gateway", "Ye OpenClaw agent hosting hai, chat API nahi; isliye models ke sath nahi joda.")
    )

    /** Providers that cannot list their models (or list them without a key), so a key is checked with a tiny chat request. */
    private val NO_MODEL_LIST = setOf("cloudflare", "cohere", "zai", "github", "nvidia", "huggingface", "together", "fireworks", "nous", "moonshot")

    @Volatile var active: Provider = ALL[0]
    @Volatile var customBase: String = ""

    /** Which company a pasted key belongs to, when its start makes that clear. Null when unsure. */
    fun guessProvider(key: String): String? = when {
        key.startsWith("gsk_") -> "groq"
        key.startsWith("AIza") -> "gemini"
        key.startsWith("sk-or-") -> "openrouter"
        key.startsWith("sk-ant-") -> "anthropic"
        key.startsWith("xai-") -> "xai"
        key.startsWith("nvapi-") -> "nvidia"
        key.startsWith("hf_") -> "huggingface"
        key.startsWith("cpk_") -> "chutes"
        key.startsWith("github_pat_") || key.startsWith("ghp_") -> "github"
        Regex("[0-9a-f]{32}:.{20,}").matches(key) -> "cloudflare"
        Regex("[0-9a-f]{32}\\.[A-Za-z0-9]{8,24}").matches(key) -> "zai"
        else -> null
    }

    fun byId(id: String?): Provider = ALL.firstOrNull { it.id == id } ?: ALL[0]

    /** Reads which provider is chosen. Call before using Gemini.send* from any screen or service. */
    @Volatile internal var prefsRef: SharedPreferences? = null

    /** Free-friendly providers tried (in this order) when the chosen one is out of quota or down. */
    private val AUTO_ORDER = listOf("groq", "gemini", "openrouter", "nvidia", "cloudflare", "mistral", "github", "cohere", "huggingface", "zai", "alibaba", "together", "fireworks", "nous", "pollinations")

    /** Auto mode is ON unless the user turned it off (pref "autoFree"). */
    fun autoOn(): Boolean = prefsRef?.getBoolean("autoFree", true) ?: false

    /** Errors worth trying another provider for: quota, bad key, missing model, server trouble, no network. */
    fun shouldFailOver(e: Exception): Boolean {
        if (e is CancelledException) return false
        if (e is ApiException) return e.code != 400 && e.code != 422
        return e is IOException
    }

    /** Other providers that have a saved key, as (provider, key, model). OpenRouter is pinned to a :free model. */
    fun alternatives(exclude: Provider): List<Triple<Provider, String, String>> {
        val p = prefsRef ?: return emptyList()
        val out = ArrayList<Triple<Provider, String, String>>()
        for (id in AUTO_ORDER) {
            if (id == exclude.id) continue
            val k = savedKey(p, id)
            if (k.isBlank()) continue
            var m = savedModel(p, id)
            if (id == "openrouter" && !m.endsWith(":free") && m != "openrouter/free") m = "openrouter/free"
            out.add(Triple(byId(id), k, m))
        }
        return out
    }

    fun load(p: SharedPreferences) {
        prefsRef = p
        loadTpm(p)
        Router.load(p)
        active = byId(p.getString("provider", "gemini"))
        customBase = p.getString("base_custom", "") ?: ""
    }

    private fun baseOf(pv: Provider, override: String? = null): String =
        if (pv.id == "custom") (override ?: customBase).trim().trimEnd('/') else pv.baseUrl

    /** Address and bearer token to use. Cloudflare keeps both its account number and token in one key: "ACCOUNT_ID:TOKEN". */
    internal fun endpointFor(pv: Provider, key: String, baseOverride: String? = null): Pair<String, String> {
        if (pv.id != "cloudflare") return Pair(baseOf(pv, baseOverride), key)
        val i = key.indexOf(':').let { if (it > 0) it else key.indexOf('|') }
        if (i <= 0 || i >= key.length - 1) throw IOException("Cloudflare ki key aise honi chahiye: ACCOUNT_ID:API_TOKEN")
        val acct = key.substring(0, i).trim()
        return Pair("https://api.cloudflare.com/client/v4/accounts/$acct/ai/v1", key.substring(i + 1).trim())
    }

    /** The Gemini key, for features that only Gemini can do (voice typing, Gemini voice, pictures). */
    fun geminiKey(p: SharedPreferences): String {
        val pid = p.getString("provider", "gemini") ?: "gemini"
        return if (pid == "gemini") (p.getString("key", "") ?: "") else (p.getString("key_gemini", "") ?: "")
    }

    /** The key saved for one provider (older installs only have "key", which was always Gemini's). */
    fun savedKey(p: SharedPreferences, id: String): String {
        val own = p.getString("key_$id", null)
        if (own != null && own.isNotBlank()) return own
        val cur = p.getString("provider", "gemini") ?: "gemini"
        return if (cur == id) (p.getString("key", "") ?: "") else ""
    }

    /** Every key saved for one company: the main one first, then the extra ones (one per line in "keys_<id>"). */
    fun allKeys(p: SharedPreferences, id: String): List<String> {
        val out = LinkedHashSet<String>()
        savedKey(p, id).trim().takeIf { it.isNotEmpty() }?.let { out.add(it) }
        (p.getString("keys_$id", "") ?: "").split('\n').map { it.trim() }.filter { it.isNotEmpty() }.forEach { out.add(it) }
        return out.toList()
    }

    /**
     * Saves a key for a company. The first key of a company becomes its main key; later ones are kept as extras and used
     * when the first one runs out. Returns false when this exact key was already saved. If the app has no working AI yet,
     * this company becomes the chosen one so the app is usable straight away.
     */
    fun addKey(p: SharedPreferences, id: String, key: String): Boolean {
        val k = key.trim()
        if (k.isEmpty()) return false
        if (allKeys(p, id).contains(k)) return false
        val ed = p.edit()
        if (savedKey(p, id).isBlank()) ed.putString("key_$id", k)
        else ed.putString("keys_$id", ((p.getString("keys_$id", "") ?: "").trim() + "\n" + k).trim())
        if ((p.getString("key", "") ?: "").isBlank()) {
            ed.putString("provider", id).putString("key", k).putString("model", byId(id).models.firstOrNull() ?: "")
            if (p.getString("model_$id", "").isNullOrBlank()) ed.putString("model_$id", byId(id).models.firstOrNull() ?: "")
        }
        ed.apply()
        return true
    }

    /**
     * Asks the company whether this key is accepted. 1 = works, 0 = refused (wrong or closed key), -1 = could not tell (no internet).
     * OpenRouter lists its models without a key, so it is checked on an address that needs one.
     */
    fun verifyKey(id: String, key: String): Int = try {
        val pv = byId(id)
        if (id == "openrouter") get(pv.baseUrl + "/auth/key", mapOf("Authorization" to "Bearer $key"))
        else if (id in NO_MODEL_LIST) pingChat(pv, key)
        else listModels(pv, key)
        1
    } catch (e: Exception) {
        if (Regex("HTTP (400|401|402|403|404)").containsMatchIn(e.message ?: "")) 0 else -1
    }

    /** One-word chat request, only to see whether the company accepts this key. */
    private fun pingChat(pv: Provider, key: String) {
        val (base, token) = endpointFor(pv, key)
        val body = JSONObject().put("model", pv.models.firstOrNull() ?: "").put("max_tokens", 1)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", "hi")))
        val conn = URL("$base/chat/completions").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"; conn.connectTimeout = 15000; conn.readTimeout = 30000; conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("Authorization", "Bearer $token")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        // 401/403 = key refused. Anything else (even 400/404/429 for the test model) means the key itself was recognised.
        if (code == 401 || code == 403) throw IOException("HTTP $code")
    }

    /** Companies a key could belong to, most likely first (by how the key starts and how long it is). */
    fun candidatesFor(key: String): List<String> {
        guessProvider(key)?.let { return listOf(it) }
        return when {
            key.startsWith("sk-proj-") || key.startsWith("sk-svcacct-") -> listOf("openai")
            key.startsWith("sk-") -> listOf("openai", "deepseek", "alibaba", "mistral", "xai")
            key.matches(Regex("[A-Za-z0-9]{32}")) -> listOf("mistral", "deepseek", "groq", "openrouter")
            key.matches(Regex("[A-Za-z0-9]{40}")) -> listOf("cohere")
            key.startsWith("eyJ") -> listOf("kilo")
            else -> listOf("gemini", "groq", "openrouter", "openai", "deepseek", "mistral", "xai", "anthropic", "kilo", "zai", "cohere")
        }
    }

    fun savedModel(p: SharedPreferences, id: String): String {
        val own = p.getString("model_$id", null)
        if (own != null && own.isNotBlank()) return own
        val cur = p.getString("provider", "gemini") ?: "gemini"
        if (cur == id) {
            val m = p.getString("model", null)
            if (m != null && m.isNotBlank()) return m
        }
        return byId(id).models.firstOrNull() ?: ""
    }

    // ---------------------------------------------------------------- model lists

    /** Asks the provider which models this key can use. Throws when the key or address is wrong. */
    fun listModels(pv: Provider, key: String, baseOverride: String? = null): List<String> {
        val (base, token) = endpointFor(pv, key, baseOverride)
        if (base.isEmpty()) throw IOException("Enter the base URL first.")
        if (pv.id in NO_MODEL_LIST) return pv.models
        val out = ArrayList<String>()
        when (pv.kind) {
            "gemini" -> {
                val j = get("$base/models?pageSize=1000", mapOf("x-goog-api-key" to key))
                val arr = j.optJSONArray("models") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                    var ok = false
                    for (k in 0 until methods.length()) if (methods.getString(k) == "generateContent") ok = true
                    val name = s(m, "name").removePrefix("models/")
                    val bad = listOf("-tts", "image", "embedding", "aqa", "live", "audio", "robotics")
                    if (ok && name.isNotEmpty() && bad.none { name.contains(it) }) out.add(name)
                }
            }
            "anthropic" -> {
                val j = get("$base/models?limit=1000", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"))
                val arr = j.optJSONArray("data") ?: JSONArray()
                for (i in 0 until arr.length()) out.add(s(arr.getJSONObject(i), "id"))
            }
            else -> {
                val j = get("$base/models", mapOf("Authorization" to "Bearer $token"))
                val arr = j.optJSONArray("data") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val id = s(arr.getJSONObject(i), "id")
                    if (id.isEmpty()) continue
                    if (pv.id == "openai") {
                        val chat = id.startsWith("gpt-") || id.startsWith("chatgpt-") || Regex("^o\\d").containsMatchIn(id)
                        val bad = listOf("audio", "realtime", "transcribe", "tts", "image", "search", "instruct", "embedding")
                        if (!chat || bad.any { id.contains(it) }) continue
                    }
                    out.add(id)
                }
            }
        }
        val clean = out.filter { it.isNotBlank() }.distinct()
        return if (pv.id == "openrouter") clean.sortedBy { if (it.endsWith(":free") || it == "openrouter/free") 0 else 1 } else clean
    }

    private fun get(url: String, headers: Map<String, String>): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        val code = conn.responseCode
        if (code !in 200..299) {
            val err = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val detail = try {
                val e = JSONObject(err).opt("error")
                if (e is JSONObject) s(e, "message") else ""
            } catch (ex: Exception) { "" }
            throw IOException("HTTP $code" + if (detail.isNotBlank()) " - " + detail.take(120) else "")
        }
        val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        return JSONObject(text)
    }

    // ---------------------------------------------------------------- chat

    private val decl: JSONArray by lazy { JSONArray(Gemini.DECLARATIONS) }


    // ---------------------------------------------------------------- small per-minute limits (Groq free: 8000 tokens)

    /** Learned "tokens per minute" cap per "company|model" (and a company-wide default as "company|*"). Saved on the phone. */
    private val tpmLimits = HashMap<String, Int>()
    private var tpmLoaded = false

    @Synchronized private fun loadTpm(p: SharedPreferences) {
        if (tpmLoaded) return
        tpmLoaded = true
        try {
            val o = JSONObject(p.getString("tpmLimits", "{}") ?: "{}")
            val it = o.keys()
            while (it.hasNext()) { val k = it.next(); tpmLimits[k] = o.optInt(k) }
        } catch (e: Exception) { }
    }

    @Synchronized private fun learnTpm(pid: String, model: String, lim: Int) {
        tpmLimits["$pid|$model"] = lim
        val d = tpmLimits["$pid|*"]
        tpmLimits["$pid|*"] = if (d == null) lim else minOf(d, lim)
        try {
            val o = JSONObject()
            for ((k, v) in tpmLimits) o.put(k, v)
            prefsRef?.edit()?.putString("tpmLimits", o.toString())?.apply()
        } catch (e: Exception) { }
    }

    @Synchronized private fun tpmFor(pid: String, model: String): Int = tpmLimits["$pid|$model"] ?: tpmLimits["$pid|*"] ?: 0

    private class Fit(val system: String, val contents: JSONArray, val tools: JSONArray?, val maxTokens: Int)

    /** Tools that are always offered even in the small version. */
    private val CORE_TOOLS = listOf("open_app", "find_contact", "call", "set_alarm", "set_reminder", "remember", "read_screen", "tap_text", "type_text", "list_tools")

    private fun lastUserText(contents: JSONArray): String {
        for (i in contents.length() - 1 downTo 0) {
            val c = contents.optJSONObject(i) ?: continue
            if (c.optString("role", "user") != "user") continue
            val ps = c.optJSONArray("parts") ?: continue
            val sb = StringBuilder()
            for (j in 0 until ps.length()) ps.optJSONObject(j)?.optString("text", "")?.let { if (it.isNotEmpty()) sb.append(it).append(' ') }
            if (sb.isNotBlank()) return sb.toString()
        }
        return ""
    }

    /** The few tools that match the user's words (plus the basic ones), in OpenAI shape, with short descriptions. */
    private fun pickTools(userText: String, max: Int): JSONArray {
        val words = Regex("[\\p{L}\\p{N}_]{3,}").findAll(userText.lowercase()).map { it.value }.toSet()
        val scored = ArrayList<Pair<Int, JSONObject>>()
        for (i in 0 until decl.length()) {
            val d = decl.getJSONObject(i)
            val name = d.getString("name")
            val hay = (name.replace('_', ' ') + " " + d.optString("description")).lowercase()
            var sc = words.count { hay.contains(it) }
            if (name in CORE_TOOLS) sc += 100
            scored.add(sc to d)
        }
        val out = JSONArray()
        for ((_, d) in scored.sortedByDescending { it.first }.take(max)) {
            val fn = JSONObject().put("name", d.getString("name")).put("description", d.optString("description").take(110))
            fn.put("parameters", d.optJSONObject("parameters") ?: JSONObject().put("type", "object").put("properties", JSONObject()))
            out.put(JSONObject().put("type", "function").put("function", fn))
        }
        return out
    }

    /** Keeps the start (who Anjoo is, the rules) and the end (time, notes, custom instructions) of a long prompt. */
    private fun compactSystem(system: String, cap: Int): String {
        if (system.length <= cap) return system
        val head = (cap * 0.7).toInt()
        return system.take(head) + "\n...\n" + system.takeLast(cap - head)
    }

    /** Drops the oldest turns until the chat fits [room] characters. The current turn is always kept whole. */
    private fun trimContents(contents: JSONArray, room: Int): JSONArray {
        var total = 0
        var from = contents.length()
        for (i in contents.length() - 1 downTo 0) {
            val len = contents.getJSONObject(i).toString().length
            if (from < contents.length() && total + len > room) break
            total += len
            from = i
        }
        // start at a user message with plain text, so no tool result is left without its call
        while (from < contents.length() - 1) {
            val c = contents.getJSONObject(from)
            val ps = c.optJSONArray("parts")
            var plain = c.optString("role", "user") == "user"
            if (plain && ps != null) for (j in 0 until ps.length()) if (ps.optJSONObject(j)?.has("functionResponse") == true) plain = false
            if (plain) break
            from++
        }
        if (from == 0) return contents
        val out = JSONArray()
        for (i in from until contents.length()) out.put(contents.get(i))
        return out
    }

    /** Makes one request fit a small per-minute cap: shorter output, a shorter prompt, only the useful tools, less old chat. */
    private fun fit(limit: Int, system: String, contents: JSONArray, wantTools: Boolean, maxTokens: Int, tight: Int): Fit {
        if (limit <= 0 || limit >= 40000) return Fit(system, contents, null, maxTokens)
        val outTok = minOf(maxTokens, maxOf(512, (limit * (if (tight == 0) 0.25 else 0.15)).toInt()))
        val inChars = ((limit - outTok - 400) * 3.0 * (if (tight == 0) 1.0 else 0.75)).toInt().coerceAtLeast(2500)
        val sys = compactSystem(system, (inChars * 0.40).toInt().coerceAtLeast(1500))
        var tools: JSONArray? = null
        var used = sys.length
        if (wantTools) {
            tools = pickTools(lastUserText(contents), if (tight == 0) 14 else 9)
            used += tools.toString().length
        }
        val hist = trimContents(contents, maxOf(1500, inChars - used))
        return Fit(sys, hist, tools, outTok)
    }

    private const val NO_WEB = "\n\n(Live Google search is not available with this AI. For fresh facts use the news tool, " +
        "or say honestly that you cannot browse.)"

    /**
     * Sends the Gemini-format conversation to another provider and returns a Gemini-format reply
     * (candidates[0].content.parts with text and functionCall parts).
     */
    fun send(
        pv: Provider, key: String, model: String, system: String, contents: JSONArray,
        withTools: Boolean, maxTokens: Int, temperature: Double?, webWanted: Boolean,
        onText: ((String) -> Unit)?
    ): JSONObject {
        val sys = if (webWanted) system + NO_WEB else system
        var useTools = withTools
        var last: Exception? = null
        var attempt = 0
        var fitTries = 0
        prefsRef?.let { loadTpm(it) }
        while (attempt < 3) {
            try {
                Cancel.check()
                val r = if (pv.kind == "anthropic")
                    callAnthropic(pv, key, model, sys, contents, useTools, maxTokens, temperature)
                else {
                    // A small per-minute cap (learned from a "413 request too large" answer) gets a slimmer request.
                    val f = fit(tpmFor(pv.id, model), sys, contents, useTools, maxTokens, fitTries)
                    callOpenAi(pv, key, model, f.system, f.contents, useTools, f.maxTokens, temperature, f.tools)
                }
                if (onText != null) {
                    val t = textOf(r)
                    if (t.isNotEmpty()) onText(t)
                }
                return r
            } catch (e: ApiException) {
                Cancel.check()
                last = e
                if (e.code == 413 && pv.kind != "anthropic" && fitTries < 2) {
                    val lim = Regex("Limit (\\d+)").find(e.message ?: "")?.groupValues?.get(1)?.toIntOrNull()
                    if (lim != null && lim in 1000..39999) { learnTpm(pv.id, model, lim); fitTries++; continue }
                }
                val toolsIssue = useTools && (e.code == 400 || e.code == 422) &&
                    Regex("tool|function", RegexOption.IGNORE_CASE).containsMatchIn(e.message ?: "")
                if (toolsIssue) { useTools = false; continue }
                val busy = e.code == 500 || e.code == 502 || e.code == 503 || e.code == 504 || e.code == 529
                if (busy && attempt < 2) { Thread.sleep(1500); attempt++; continue }
                if (e.code == 429 && attempt < 1 && e.retryMs in 1..20000L) { Thread.sleep(e.retryMs + 300); attempt++; continue }
                throw e
            } catch (e: java.net.SocketTimeoutException) {
                Cancel.check()
                throw e
            } catch (e: IOException) {
                Cancel.check()
                last = e
                if (attempt < 1) { Thread.sleep(1000); attempt++; continue }
                throw e
            }
        }
        throw last ?: IOException("No answer came back.")
    }

    private fun textOf(r: JSONObject): String {
        val ps = r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            if (p.has("text") && !p.optBoolean("thought", false)) sb.append(p.getString("text"))
        }
        return sb.toString().trim()
    }

    /** org.json turns a JSON null into the text "null"; this gives "" instead. */
    private fun s(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")

    private fun wrapReply(parts: JSONArray, finish: String): JSONObject {
        val cand = JSONObject()
            .put("content", JSONObject().put("role", "model").put("parts", parts))
            .put("finishReason", finish)
        return JSONObject().put("candidates", JSONArray().put(cand))
    }

    private fun post(
        url: String, headers: Map<String, String>, body: JSONObject,
        maxTokens: Int, label: String, model: String
    ): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        Cancel.track(conn)
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = if (maxTokens > 2000) 170000 else 60000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val raw = try {
                val e = JSONObject(text).opt("error")
                if (e is JSONObject) s(e, "message") else ""
            } catch (ex: Exception) { "" }
            val detail = raw.ifBlank { text.take(200) }
            val hint = when (code) {
                401 -> "$label ki API key galat hai. Settings mein dobara dalein."
                402 -> "$label mein credits/balance khatam hai. Detail: $detail"
                403 -> detail
                404 -> "Model '$model' nahi mila. Settings mein model ka naam check karein."
                429 -> "$label ki limit poori ho gayi. Thori der ruk kar try karein ya Settings mein doosra model chunein."
                else -> detail
            }
            val retryMs = (conn.getHeaderField("retry-after")?.toDoubleOrNull()?.times(1000))?.toLong() ?: 0L
            throw ApiException(code, "($code) $hint", retryMs)
        }
        return try { JSONObject(text) } catch (e: Exception) { throw IOException("$label ka jawab samajh nahi aaya.") }
    }

    // ---------------------------------------------------------------- OpenAI-style

    private fun openAiTools(): JSONArray {
        val out = JSONArray()
        for (i in 0 until decl.length()) {
            val d = decl.getJSONObject(i)
            val fn = JSONObject().put("name", d.getString("name")).put("description", d.optString("description"))
            fn.put("parameters", d.optJSONObject("parameters") ?: JSONObject().put("type", "object").put("properties", JSONObject()))
            out.put(JSONObject().put("type", "function").put("function", fn))
        }
        return out
    }

    private fun callOpenAi(
        pv: Provider, key: String, model: String, system: String, contents: JSONArray,
        useTools: Boolean, maxTokens: Int, temperature: Double?, toolsOverride: JSONArray? = null
    ): JSONObject {
        val (base, token) = endpointFor(pv, key)
        if (base.isEmpty()) throw IOException("Settings mein Base URL dalein.")
        val msgs = JSONArray()
        if (system.isNotBlank()) msgs.put(JSONObject().put("role", "system").put("content", system))
        toOpenAiMessages(contents, msgs, pv.id == "openai")
        val body = JSONObject().put("model", model).put("messages", msgs)
        val isOpenAi = pv.id == "openai"
        val reasoning = isOpenAi && (model.startsWith("gpt-5") || Regex("^o\\d").containsMatchIn(model))
        if (isOpenAi) {
            // reasoning models count their hidden thinking inside this limit, so give them room
            body.put("max_completion_tokens", if (reasoning) minOf(32000, maxTokens * 4) else maxTokens)
        } else {
            body.put("max_tokens", if (pv.id == "deepseek") minOf(8192, maxTokens) else maxTokens)
        }
        if (temperature != null && !reasoning) body.put("temperature", temperature)
        if (useTools) body.put("tools", toolsOverride ?: openAiTools())

        val headers = HashMap<String, String>()
        if (token.isNotBlank()) headers["Authorization"] = "Bearer $token"
        if (pv.id == "openrouter") headers["X-Title"] = "Anjoo AI"
        val j = post("$base/chat/completions", headers, body, maxTokens, pv.label, model)

        val ch = j.optJSONArray("choices")?.optJSONObject(0) ?: throw IOException("No answer came back.")
        val msg = ch.optJSONObject("message") ?: JSONObject()
        val parts = JSONArray()
        val reason = s(msg, "reasoning_content")
        if (reason.isNotBlank()) parts.put(JSONObject().put("text", reason).put("thought", true))
        var text = ""
        val c = msg.opt("content")
        if (c is String) text = c
        else if (c is JSONArray) {
            val sb = StringBuilder()
            for (i in 0 until c.length()) {
                val b = c.optJSONObject(i) ?: continue
                sb.append(s(b, "text"))
            }
            text = sb.toString()
        }
        if (text.isNotBlank()) parts.put(JSONObject().put("text", text))
        val calls = msg.optJSONArray("tool_calls")
        if (calls != null) {
            for (i in 0 until calls.length()) {
                val fn = calls.getJSONObject(i).optJSONObject("function") ?: continue
                val args = try { JSONObject(s(fn, "arguments").ifBlank { "{}" }) } catch (e: Exception) { JSONObject() }
                parts.put(JSONObject().put("functionCall", JSONObject().put("name", s(fn, "name")).put("args", args)))
            }
        }
        val fr = when (s(ch, "finish_reason")) {
            "length" -> "MAX_TOKENS"
            "content_filter" -> "SAFETY"
            else -> "STOP"
        }
        return wrapReply(parts, fr)
    }

    private fun dataUrl(p: JSONObject): Pair<String, String>? {
        val d = p.optJSONObject("inlineData") ?: return null
        return Pair(s(d, "mimeType"), s(d, "data"))
    }

    private fun toOpenAiMessages(contents: JSONArray, out: JSONArray, allowPdf: Boolean) {
        val pending = ArrayList<Pair<String, String>>() // function name, call id
        var n = 0
        for (i in 0 until contents.length()) {
            val c = contents.getJSONObject(i)
            val ps = c.optJSONArray("parts") ?: continue
            if (c.optString("role", "user") == "model") {
                val text = StringBuilder()
                val calls = JSONArray()
                for (j in 0 until ps.length()) {
                    val p = ps.getJSONObject(j)
                    if (p.optBoolean("thought", false)) continue
                    if (p.has("text")) text.append(p.getString("text"))
                    val fc = p.optJSONObject("functionCall")
                    if (fc != null) {
                        val id = "call_" + (++n)
                        val name = fc.getString("name")
                        pending.add(Pair(name, id))
                        calls.put(
                            JSONObject().put("id", id).put("type", "function").put(
                                "function", JSONObject().put("name", name)
                                    .put("arguments", (fc.optJSONObject("args") ?: JSONObject()).toString())
                            )
                        )
                    }
                }
                if (text.isEmpty() && calls.length() == 0) continue
                val m = JSONObject().put("role", "assistant")
                m.put("content", if (text.isEmpty()) JSONObject.NULL else text.toString())
                if (calls.length() > 0) m.put("tool_calls", calls)
                out.put(m)
            } else {
                val content = JSONArray()
                var onlyText = true
                val textAll = StringBuilder()
                for (j in 0 until ps.length()) {
                    val p = ps.getJSONObject(j)
                    val fr = p.optJSONObject("functionResponse")
                    if (fr != null) {
                        val name = fr.optString("name")
                        var idx = pending.indexOfFirst { it.first == name }
                        if (idx < 0 && pending.isNotEmpty()) idx = 0
                        val result = (fr.optJSONObject("response") ?: JSONObject()).let {
                            if (it.length() == 1 && it.has("result")) s(it, "result") else it.toString()
                        }
                        if (idx >= 0) {
                            val id = pending.removeAt(idx).second
                            out.put(JSONObject().put("role", "tool").put("tool_call_id", id).put("content", result.ifBlank { "done" }))
                        } else {
                            content.put(JSONObject().put("type", "text").put("text", "[tool result] $result"))
                            textAll.append("[tool result] ").append(result).append('\n')
                        }
                        continue
                    }
                    if (p.has("text")) {
                        content.put(JSONObject().put("type", "text").put("text", p.getString("text")))
                        textAll.append(p.getString("text")).append('\n')
                        continue
                    }
                    val d = dataUrl(p) ?: continue
                    val mime = d.first
                    if (mime.startsWith("image/")) {
                        onlyText = false
                        content.put(
                            JSONObject().put("type", "image_url")
                                .put("image_url", JSONObject().put("url", "data:$mime;base64," + d.second))
                        )
                    } else if (mime == "application/pdf" && allowPdf) {
                        onlyText = false
                        content.put(
                            JSONObject().put("type", "file").put(
                                "file", JSONObject().put("filename", "file.pdf")
                                    .put("file_data", "data:application/pdf;base64," + d.second)
                            )
                        )
                    } else {
                        content.put(JSONObject().put("type", "text").put("text", "[An attachment of type $mime was shared, but this AI cannot read it.]"))
                        textAll.append("[An attachment of type $mime was shared, but this AI cannot read it.]\n")
                    }
                }
                if (content.length() == 0) continue
                val m = JSONObject().put("role", "user")
                if (onlyText) m.put("content", textAll.toString().trim()) else m.put("content", content)
                out.put(m)
            }
        }
    }

    // ---------------------------------------------------------------- Claude

    private fun callAnthropic(
        pv: Provider, key: String, model: String, system: String, contents: JSONArray,
        useTools: Boolean, maxTokens: Int, temperature: Double?
    ): JSONObject {
        val body = JSONObject().put("model", model).put("max_tokens", minOf(16000, maxTokens))
            .put("messages", toAnthropicMessages(contents))
        if (system.isNotBlank()) body.put("system", system)
        if (temperature != null) body.put("temperature", temperature)
        if (useTools) {
            val tools = JSONArray()
            for (i in 0 until decl.length()) {
                val d = decl.getJSONObject(i)
                tools.put(
                    JSONObject().put("name", d.getString("name")).put("description", d.optString("description"))
                        .put("input_schema", d.optJSONObject("parameters") ?: JSONObject().put("type", "object").put("properties", JSONObject()))
                )
            }
            body.put("tools", tools)
        }
        val j = post(
            baseOf(pv) + "/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
            body, maxTokens, pv.label, model
        )
        val parts = JSONArray()
        val blocks = j.optJSONArray("content") ?: JSONArray()
        for (i in 0 until blocks.length()) {
            val b = blocks.getJSONObject(i)
            when (s(b, "type")) {
                "text" -> if (s(b, "text").isNotBlank()) parts.put(JSONObject().put("text", s(b, "text")))
                "thinking" -> if (s(b, "thinking").isNotBlank()) parts.put(JSONObject().put("text", s(b, "thinking")).put("thought", true))
                "tool_use" -> parts.put(
                    JSONObject().put(
                        "functionCall",
                        JSONObject().put("name", s(b, "name")).put("args", b.optJSONObject("input") ?: JSONObject())
                    )
                )
            }
        }
        val fr = when (s(j, "stop_reason")) {
            "max_tokens" -> "MAX_TOKENS"
            "refusal" -> "SAFETY"
            else -> "STOP"
        }
        return wrapReply(parts, fr)
    }

    private fun toAnthropicMessages(contents: JSONArray): JSONArray {
        val out = JSONArray()
        val pending = ArrayList<Pair<String, String>>()
        var n = 0
        fun add(role: String, blocks: List<JSONObject>) {
            if (blocks.isEmpty()) return
            val last = if (out.length() > 0) out.getJSONObject(out.length() - 1) else null
            if (last != null && last.getString("role") == role) {
                val arr = last.getJSONArray("content")
                for (b in blocks) arr.put(b)
            } else {
                val arr = JSONArray()
                for (b in blocks) arr.put(b)
                out.put(JSONObject().put("role", role).put("content", arr))
            }
        }
        for (i in 0 until contents.length()) {
            val c = contents.getJSONObject(i)
            val ps = c.optJSONArray("parts") ?: continue
            if (c.optString("role", "user") == "model") {
                val blocks = ArrayList<JSONObject>()
                for (j in 0 until ps.length()) {
                    val p = ps.getJSONObject(j)
                    if (p.optBoolean("thought", false)) continue
                    if (p.has("text") && p.getString("text").isNotBlank()) {
                        blocks.add(JSONObject().put("type", "text").put("text", p.getString("text")))
                    }
                    val fc = p.optJSONObject("functionCall")
                    if (fc != null) {
                        val id = "toolu_" + (++n)
                        val name = fc.getString("name")
                        pending.add(Pair(name, id))
                        blocks.add(
                            JSONObject().put("type", "tool_use").put("id", id).put("name", name)
                                .put("input", fc.optJSONObject("args") ?: JSONObject())
                        )
                    }
                }
                add("assistant", blocks)
            } else {
                val results = ArrayList<JSONObject>()
                val others = ArrayList<JSONObject>()
                for (j in 0 until ps.length()) {
                    val p = ps.getJSONObject(j)
                    val fr = p.optJSONObject("functionResponse")
                    if (fr != null) {
                        val name = fr.optString("name")
                        var idx = pending.indexOfFirst { it.first == name }
                        if (idx < 0 && pending.isNotEmpty()) idx = 0
                        val result = (fr.optJSONObject("response") ?: JSONObject()).let {
                            if (it.length() == 1 && it.has("result")) s(it, "result") else it.toString()
                        }
                        if (idx >= 0) {
                            val id = pending.removeAt(idx).second
                            results.add(
                                JSONObject().put("type", "tool_result").put("tool_use_id", id)
                                    .put("content", result.ifBlank { "done" })
                            )
                        } else {
                            others.add(JSONObject().put("type", "text").put("text", "[tool result] $result"))
                        }
                        continue
                    }
                    if (p.has("text")) {
                        if (p.getString("text").isNotBlank()) others.add(JSONObject().put("type", "text").put("text", p.getString("text")))
                        continue
                    }
                    val d = dataUrl(p) ?: continue
                    val mime = d.first
                    if (mime == "image/jpeg" || mime == "image/png" || mime == "image/gif" || mime == "image/webp") {
                        others.add(
                            JSONObject().put("type", "image").put(
                                "source", JSONObject().put("type", "base64").put("media_type", mime).put("data", d.second)
                            )
                        )
                    } else if (mime == "application/pdf") {
                        others.add(
                            JSONObject().put("type", "document").put(
                                "source", JSONObject().put("type", "base64").put("media_type", mime).put("data", d.second)
                            )
                        )
                    } else {
                        others.add(JSONObject().put("type", "text").put("text", "[An attachment of type $mime was shared, but this AI cannot read it.]"))
                    }
                }
                // tool results must come first inside the user turn
                add("user", results + others)
            }
        }
        return out
    }
}
