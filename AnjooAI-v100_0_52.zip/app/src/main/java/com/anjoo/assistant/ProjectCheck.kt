package com.anjoo.assistant

import java.io.File

/**
 * Fast, local check of a project before it is sent to the cloud APK builder, so obvious problems
 * (missing manifest, source-only website, missing files) are found in seconds instead of after a long cloud build.
 * Pure Kotlin (java.io only) so it can be unit tested.
 */
object ProjectCheck {
    enum class Level { ERROR, WARN }
    data class Finding(val level: Level, val text: String)
    data class Report(val kind: String, val findings: List<Finding>) {
        val errors: List<Finding> get() = findings.filter { it.level == Level.ERROR }
        val warnings: List<Finding> get() = findings.filter { it.level == Level.WARN }
        fun text(): String {
            val head = when (kind) {
                "native" -> "Detected: native Android Gradle project"
                "web" -> "Detected: website (packaged as a WebView APK)"
                else -> "Detected: nothing that can be built"
            }
            val sb = StringBuilder(head)
            for (f in findings) sb.append("\n\n").append(if (f.level == Level.ERROR) "✕ " else "⚠ ").append(f.text)
            return sb.toString().take(2500)
        }
    }

    private val skipDirs = setOf(".git", ".gradle", "node_modules", "build", "target", ".idea", ".kotlin")
    private const val MAX_FILES = 30000
    private const val MAX_READ = 400_000L
    private val sourceExts = setOf("jsx", "tsx", "ts", "vue", "svelte")

    private fun collect(root: File): List<File> =
        root.walkTopDown()
            .onEnter { it == root || it.name !in skipDirs }
            .filter { it.isFile && !it.name.startsWith(".anjoo") }
            .take(MAX_FILES)
            .toList()

    private fun read(f: File?): String = try {
        if (f == null || !f.isFile || f.length() > MAX_READ) "" else f.readText()
    } catch (_: Exception) { "" }

    fun check(root: File, target: String = "auto"): Report {
        val files = collect(root)
        fun rel(f: File) = f.relativeTo(root).path.replace('\\', '/')

        val settings = files.filter { it.name == "settings.gradle.kts" || it.name == "settings.gradle" }.sortedBy { rel(it) }
        val nativeRoot = settings.map { it.parentFile }.firstOrNull { d ->
            File(d, "app/build.gradle.kts").isFile || File(d, "app/build.gradle").isFile
        }
        val webIndex = files.filter { it.name.equals("index.html", true) }
            .minWithOrNull(compareBy<File>({ rel(it).count { c -> c == '/' } }, { rel(it) }))

        val findings = ArrayList<Finding>()
        val kind = when {
            nativeRoot != null && target != "web" -> "native"
            webIndex != null && target != "native" -> "web"
            else -> "none"
        }
        if (kind == "none") {
            val msg = when {
                target == "native" -> "Native Android was selected, but no complete Gradle project was found. It needs settings.gradle(.kts) and app/build.gradle(.kts) in the same folder."
                target == "web" -> "WebView APK was selected, but the project has no index.html."
                else -> "No Android Gradle project and no index.html were found, so there is nothing to build into an APK."
            }
            findings.add(Finding(Level.ERROR, msg))
        } else if (kind == "native" && nativeRoot != null) {
            checkNative(root, nativeRoot, files, findings)
        } else if (webIndex != null) {
            checkWeb(webIndex, findings)
        }
        return Report(kind, findings)
    }

    private fun checkNative(root: File, n: File, files: List<File>, out: MutableList<Finding>) {
        fun err(t: String) { out.add(Finding(Level.ERROR, t)) }
        fun warn(t: String) { out.add(Finding(Level.WARN, t)) }
        val prefix = n.relativeTo(root).path.replace('\\', '/').let { if (it.isEmpty()) "" else "$it/" }
        fun rel(f: File) = f.relativeTo(root).path.replace('\\', '/')

        val settingsText = read(listOf("settings.gradle.kts", "settings.gradle").map { File(n, it) }.firstOrNull { it.isFile })
        val appGradle = read(listOf("app/build.gradle.kts", "app/build.gradle").map { File(n, it) }.firstOrNull { it.isFile })
        val rootGradle = read(listOf("build.gradle.kts", "build.gradle").map { File(n, it) }.firstOrNull { it.isFile })
        val allGradle = appGradle + "\n" + rootGradle + "\n" + settingsText

        if (!Regex("""include\s*\(?[^\n]*:app\b""").containsMatchIn(settingsText)) {
            err("settings.gradle does not include the app module. Add include(\":app\").")
        }

        val manifestFile = File(n, "app/src/main/AndroidManifest.xml")
        val manifest = read(manifestFile)
        if (!manifestFile.isFile) err("app/src/main/AndroidManifest.xml is missing.")

        val srcFiles = files.filter { rel(it).startsWith(prefix + "app/src/") && (it.extension == "kt" || it.extension == "java") }
        if (srcFiles.isEmpty()) err("No Kotlin or Java source files were found under app/src.")

        val hasNamespace = Regex("""\bnamespace\s*[=(]?\s*[\x22\x27]""").containsMatchIn(appGradle) ||
            Regex("""\bpackage\s*=\s*\x22""").containsMatchIn(manifest)
        if (!hasNamespace) err("The app has no namespace. Add namespace = \"com.example.app\" in app/build.gradle(.kts).")
        if (!Regex("""\bapplicationId\b""").containsMatchIn(appGradle)) warn("app/build.gradle(.kts) has no applicationId; the namespace will be used as the app id.")

        if (srcFiles.any { it.extension == "kt" } && !Regex("kotlin", RegexOption.IGNORE_CASE).containsMatchIn(allGradle)) {
            err("Kotlin files were found, but no Kotlin plugin is applied in the Gradle files.")
        }

        val props = read(File(n, "gradle.properties"))
        if (Regex("""androidx\.|com\.google\.android\.material""").containsMatchIn(appGradle) &&
            !Regex("""android\.useAndroidX\s*=\s*true""").containsMatchIn(props)) {
            err("The app uses AndroidX libraries, but gradle.properties does not contain android.useAndroidX=true, so the build will fail.")
        }

        if (manifestFile.isFile) {
            if (!manifest.contains("android.intent.category.LAUNCHER")) {
                warn("The manifest has no launcher activity: the app would install but have no icon to open it.")
            }
            val resFiles = files.filter { rel(it).startsWith(prefix + "app/src/main/res/") }
            val iconRefs = Regex("""android:(?:icon|roundIcon)\s*=\s*\x22@(mipmap|drawable)/([A-Za-z0-9_]+)\x22""")
                .findAll(manifest).map { it.groupValues[1] to it.groupValues[2] }.distinct().toList()
            for ((type, name) in iconRefs) {
                val found = resFiles.any { it.parentFile != null && it.parentFile.name.startsWith(type) && it.name.substringBefore('.') == name }
                if (!found) err("The manifest uses @$type/$name, but no such file exists in app/src/main/res (the build will fail).")
            }
            val definedStrings = resFiles.filter { it.extension == "xml" && it.parentFile?.name?.startsWith("values") == true }
                .flatMap { Regex("""<string\s[^>]*name\s*=\s*\x22([^\x22]+)\x22""").findAll(read(it)).map { m -> m.groupValues[1] }.toList() }.toSet()
            val stringRefs = Regex("""@string/([A-Za-z0-9_]+)""").findAll(manifest).map { it.groupValues[1] }.distinct().toList()
            for (s in stringRefs) {
                if (s !in definedStrings) err("The manifest uses @string/$s, but it is not defined in res/values/strings.xml.")
            }
            val classNames = srcFiles.map { it.nameWithoutExtension }.toSet()
            val activities = Regex("""<activity[^>]*android:name\s*=\s*\x22([^\x22]+)\x22""").findAll(manifest).map { it.groupValues[1] }.distinct().toList()
            for (a in activities) {
                if (a.startsWith(".") && a.substringAfterLast('.') !in classNames) {
                    err("The manifest declares activity $a, but no ${a.substringAfterLast('.')}.kt or .java file was found.")
                }
            }
        }

        val keystores = Regex("""storeFile\s*[=(]?\s*(?:file\s*\()?\s*[\x22\x27]([^\x22\x27]+)[\x22\x27]""").findAll(appGradle)
            .map { it.groupValues[1] }.filter { it.endsWith(".keystore") || it.endsWith(".jks") || it.endsWith(".p12") }.distinct().toList()
        if (keystores.isNotEmpty()) {
            warn("app/build.gradle(.kts) refers to the key file ${keystores.first()}. For safety the builder never uploads key files, so if the debug build needs it, the build fails (validateSigningDebug).")
        }
    }

    private fun checkWeb(index: File, out: MutableList<Finding>) {
        val text = read(index)
        if (index.length() == 0L || text.isBlank()) {
            out.add(Finding(Level.ERROR, "index.html is empty."))
            return
        }
        if (text.length < 120) out.add(Finding(Level.WARN, "index.html is almost empty, so the app may show a blank page."))
        val dir = index.parentFile
        val missing = ArrayList<String>()
        val absolute = ArrayList<String>()
        val sourceRefs = ArrayList<String>()
        val refs = Regex("""(?:src|href)\s*=\s*[\x22\x27]([^\x22\x27]+)[\x22\x27]""", RegexOption.IGNORE_CASE)
            .findAll(text).map { it.groupValues[1].trim() }.distinct().toList()
        for (r in refs) {
            val low = r.lowercase()
            if (low.startsWith("#") || low.startsWith("data:") || low.startsWith("mailto:") || low.startsWith("tel:") ||
                low.startsWith("javascript:") || low.startsWith("blob:") || low.startsWith("http://") ||
                low.startsWith("https://") || low.startsWith("//")) continue
            val path = r.substringBefore('#').substringBefore('?')
            if (path.isBlank()) continue
            if (path.substringAfterLast('.', "").lowercase() in sourceExts) { sourceRefs.add(path); continue }
            if (path.startsWith("/")) { absolute.add(path); continue }
            if (!File(dir, path).exists()) missing.add(path)
        }
        if (sourceRefs.isNotEmpty()) {
            out.add(Finding(Level.ERROR, "index.html loads source files (${sourceRefs.take(3).joinToString(", ")}). A browser or WebView cannot run these without a build step, so the app would show a blank page. Build the project first (for example npm run build) and use the generated folder."))
        }
        if (missing.isNotEmpty()) {
            out.add(Finding(Level.WARN, "index.html refers to files that are not in the project: ${missing.take(4).joinToString(", ")}."))
        }
        if (absolute.isNotEmpty()) {
            out.add(Finding(Level.WARN, "index.html uses paths that start with / (${absolute.take(3).joinToString(", ")}). Inside the APK these do not find the files; use relative paths such as ./app.js."))
        }
        val hosts = Regex("""<(?:script|link)\b[^>]*\b(?:src|href)\s*=\s*[\x22\x27](?:https?:)?//([^\x22\x27/]+)""", RegexOption.IGNORE_CASE)
            .findAll(text).map { it.groupValues[1] }.distinct().toList()
        if (hosts.isNotEmpty()) {
            out.add(Finding(Level.WARN, "The page loads scripts or styles from the internet (${hosts.take(3).joinToString(", ")}). Without internet the app may not work; put those files inside the project to make it work offline."))
        }
    }
}
