# Pollinations setup in Anjoo AI

Open **Menu → Models aur keys → Pollinations: key, models & balance report**. Use the dashboard link in that panel to create a key, paste it into the password-masked field, then choose **Save & report**. The key is encrypted in app-private storage with Anjoo's Android Keystore-backed AES-GCM helper. The app loads the Pollinations image-model catalog, shows recent health metadata where supplied, and can save a chosen image model for future image generation. If no key is set, the existing no-key image fallback remains available.

The Pollinations balance endpoint may return a remaining pollen balance and, with the needed `account:usage` permission, account-level tier and paid balances. A remaining balance alone is not a percentage: the provider must also report a matching maximum/starting budget before a valid percentage can be calculated. A missing usage permission is shown as unavailable rather than guessed. Model health is a catalog signal, not a paid test generation or guarantee that every request will succeed.

The app's general Models report shows app-observed success, failure, and cooldown status plus task suitability. Those are not provider-wide live quotas. Other companies expose different usage APIs and permissions, so the app must label unsupported remaining limits as unavailable.

**Security note:** Pollinations documents `sk_` keys as server-side secrets and advises against embedding them in mobile apps. Anjoo encrypts the stored key on-device, but this does not make a client-side secret equivalent to a server-side secret. Use a scoped/consented app-key flow where available, and never paste a key into chat or share it publicly.
