package com.anjoo.assistant

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Pollinations catalog and account-status access. Never logs or returns the API key. */
object PollinationsApi {
    data class Model(val id: String, val description: String, val status: String, val successRate: Double?)
    data class Account(val balance: Double?, val total: Double?, val tier: Double?, val paid: Double?, val usageNote: String)

    private fun keyFile(ctx: Context) = File(ctx.filesDir, "pollinations_api_key.enc")
    fun readKey(ctx: Context): String {
        val f = keyFile(ctx)
        val saved = if (f.exists()) Crypt.readText(ctx, f).orEmpty() else ""
        if (saved.isNotBlank()) return saved
        // Migrate builds made during development without ever keeping the new copy in preferences.
        val legacy = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getString("pollinationsKey", "").orEmpty()
        if (legacy.isBlank()) return ""
        if (!saveKey(ctx, legacy)) return ""
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit().remove("pollinationsKey").apply()
        return legacy
    }
    fun saveKey(ctx: Context, key: String): Boolean {
        if (key.isBlank()) { keyFile(ctx).delete(); return true }
        return Crypt.writeText(ctx, keyFile(ctx), key)
    }

    private fun get(path: String, key: String = ""): String {
        val c = URL("https://gen.pollinations.ai$path").openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.connectTimeout = 12000
        c.readTimeout = 20000
        if (key.isNotBlank()) c.setRequestProperty("Authorization", "Bearer $key")
        val code = c.responseCode
        val body = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw IOException("HTTP $code" + if (code == 403) " (key mein account:usage permission shayad nahi)" else "")
        return body
    }

    fun imageModels(key: String): List<Model> {
        val raw = get("/image/models", key)
        val parsed = org.json.JSONTokener(raw).nextValue()
        val arr = when (parsed) {
            is org.json.JSONArray -> parsed
            is JSONObject -> parsed.optJSONArray("data") ?: parsed.optJSONArray("models")
                ?: if (parsed.has("id")) org.json.JSONArray().put(parsed) else org.json.JSONArray()
            else -> org.json.JSONArray()
        }
        val out = ArrayList<Model>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id", o.optString("name")).trim()
            if (id.isEmpty()) continue
            val modalities = o.optJSONArray("output_modalities")
            if (modalities != null && (0 until modalities.length()).none { modalities.optString(it).equals("image", true) }) continue
            val health = o.optJSONObject("health")
            val status = health?.optString("status", "unknown") ?: "status info nahi"
            val rate = if (health != null && !health.isNull("success_rate")) health.optDouble("success_rate") else Double.NaN
            out.add(Model(id, o.optString("description", o.optString("name", "Image model")), status, if (rate.isNaN()) null else rate))
        }
        return out.distinctBy { it.id }.sortedWith(compareBy<Model> { it.status != "healthy" && it.status != "operational" }.thenBy { it.id })
    }

    fun account(key: String): Account {
        val root = JSONObject(get("/account/balance", key))
        val b = root.optDouble("balance", Double.NaN).takeUnless { it.isNaN() }
        val ab = root.optJSONObject("accountBalance")
        val total = ab?.optDouble("total", Double.NaN)?.takeUnless { it.isNaN() }
        val tier = ab?.optDouble("tier", Double.NaN)?.takeUnless { it.isNaN() }
        val paid = ab?.optDouble("paid", Double.NaN)?.takeUnless { it.isNaN() }
        val note = if (ab == null) "Full account breakdown ke liye key par account:usage scope chahiye." else "Balance provider se mila; maximum/top-up baseline nahi mila, is liye percent calculate nahi ho sakta."
        return Account(b, total, tier, paid, note)
    }

    fun usageSummary(key: String): String = try {
        val root = JSONObject(get("/account/usage?days=30&limit=1", key))
        val rows = root.optJSONArray("data") ?: root.optJSONArray("items")
        if (rows != null) "Pichhle 30 din: usage history available (${rows.length()} recent record)." else "Usage endpoint response mil gaya; full history parse nahi hui."
    } catch (e: Exception) {
        "Usage history: provider ne access nahi diya ya account:usage scope nahi hai."
    }
}
