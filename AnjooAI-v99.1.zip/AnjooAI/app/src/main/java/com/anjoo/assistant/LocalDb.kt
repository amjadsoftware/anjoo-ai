package com.anjoo.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

/**
 * Offline storage on the phone. This is the Android counterpart of the browser's localStorage + IndexedDB:
 *  - small settings, tasks, reminders and chats live in SharedPreferences / app files (localStorage-like, already offline);
 *  - notes and the "send when back online" queue live in this SQLite database (IndexedDB-like: real rows, search, indexes).
 * Nothing here needs the internet.
 */
class LocalDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "anjoo_local.db", null, 2) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE notes (id TEXT PRIMARY KEY, title TEXT NOT NULL DEFAULT '', body TEXT NOT NULL DEFAULT '', " +
                "pinned INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL, updated INTEGER NOT NULL, deleted INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX notes_updated ON notes(deleted, pinned, updated)")
        db.execSQL("CREATE TABLE outbox (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, created INTEGER NOT NULL, att TEXT NOT NULL DEFAULT '')")
    }

    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {
        if (o < 2) db.execSQL("ALTER TABLE outbox ADD COLUMN att TEXT NOT NULL DEFAULT ''")
    }

    companion object {
        @Volatile private var inst: LocalDb? = null
        fun get(ctx: Context): LocalDb = inst ?: synchronized(this) { inst ?: LocalDb(ctx).also { inst = it } }
    }
}

class Note(val id: String, val title: String, val body: String, val pinned: Boolean, val created: Long, val updated: Long)

/** The user's notes. Work with no internet. Deleting keeps a hidden "tombstone" so a merge from another phone does not bring a note back. */
object Notes {

    private fun db(ctx: Context) = LocalDb.get(ctx).writableDatabase

    private fun row(c: android.database.Cursor) = Note(
        c.getString(0), c.getString(1), c.getString(2), c.getInt(3) == 1, c.getLong(4), c.getLong(5)
    )

    private const val COLS = "id, title, body, pinned, created, updated"

    @Synchronized
    fun add(ctx: Context, title: String, body: String): Note {
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        val t = title.trim().take(120).ifEmpty { body.trim().lines().firstOrNull().orEmpty().take(60) }
        val cv = ContentValues().apply {
            put("id", id); put("title", t); put("body", body.trim().take(20000))
            put("pinned", 0); put("created", now); put("updated", now); put("deleted", 0)
        }
        db(ctx).insertOrThrow("notes", null, cv)
        return Note(id, t, body.trim(), false, now, now)
    }

    @Synchronized
    fun update(ctx: Context, id: String, title: String, body: String): Boolean {
        val cv = ContentValues().apply {
            put("title", title.trim().take(120)); put("body", body.trim().take(20000)); put("updated", System.currentTimeMillis())
        }
        return db(ctx).update("notes", cv, "id=? AND deleted=0", arrayOf(id)) > 0
    }

    @Synchronized
    fun setPinned(ctx: Context, id: String, pinned: Boolean) {
        val cv = ContentValues().apply { put("pinned", if (pinned) 1 else 0); put("updated", System.currentTimeMillis()) }
        db(ctx).update("notes", cv, "id=?", arrayOf(id))
    }

    @Synchronized
    fun delete(ctx: Context, id: String) {
        val cv = ContentValues().apply { put("deleted", 1); put("body", ""); put("title", ""); put("updated", System.currentTimeMillis()) }
        db(ctx).update("notes", cv, "id=?", arrayOf(id))
    }

    @Synchronized
    fun all(ctx: Context, query: String = ""): List<Note> {
        val q = query.trim()
        val out = ArrayList<Note>()
        val sel = if (q.isEmpty()) "deleted=0" else "deleted=0 AND (title LIKE ? ESCAPE '\\' OR body LIKE ? ESCAPE '\\')"
        val like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        val args = if (q.isEmpty()) null else arrayOf(like, like)
        db(ctx).query("notes", arrayOf("id", "title", "body", "pinned", "created", "updated"), sel, args, null, null, "pinned DESC, updated DESC")
            .use { c -> while (c.moveToNext()) out.add(row(c)) }
        return out
    }

    fun count(ctx: Context): Int = all(ctx).size

    /** The Nth note (1 = first) of the list as shown by [summary]. */
    fun byNumber(ctx: Context, n: Int): Note? = all(ctx).getOrNull(n - 1)

    fun summary(ctx: Context, query: String = "", max: Int = 12): String {
        val l = all(ctx, query)
        if (l.isEmpty()) return if (query.isBlank()) "Abhi koi note nahi hai." else "Is lafz ka koi note nahi mila."
        val sb = StringBuilder()
        for ((i, n) in l.take(max).withIndex()) {
            sb.append(i + 1).append(". ").append(if (n.pinned) "📌 " else "").append(n.title.ifEmpty { "(no title)" })
            val prev = n.body.replace('\n', ' ').take(70)
            if (prev.isNotEmpty() && prev != n.title) sb.append(" — ").append(prev)
            sb.append("\n")
        }
        if (l.size > max) sb.append("... aur ").append(l.size - max).append(" notes.")
        return sb.toString().trim()
    }

    // ---- sync file (move notes between phones with no server) ----

    @Synchronized
    fun exportArray(ctx: Context): JSONArray {
        val a = JSONArray()
        db(ctx).query("notes", arrayOf("id", "title", "body", "pinned", "created", "updated", "deleted"), null, null, null, null, "updated DESC").use { c ->
            while (c.moveToNext()) {
                a.put(JSONObject().put("id", c.getString(0)).put("title", c.getString(1)).put("body", c.getString(2))
                    .put("pinned", c.getInt(3) == 1).put("created", c.getLong(4)).put("updated", c.getLong(5)).put("deleted", c.getInt(6) == 1))
            }
        }
        return a
    }

    /** Merges notes from another phone or a backup. The newer edit of each note wins. Returns how many notes changed here. */
    @Synchronized
    fun merge(ctx: Context, incoming: JSONArray): Int {
        val d = db(ctx)
        var changed = 0
        d.beginTransaction()
        try {
            for (i in 0 until incoming.length()) {
                val o = incoming.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (id.isEmpty()) continue
                val upd = o.optLong("updated", 0L)
                var have = -1L
                d.rawQuery("SELECT updated FROM notes WHERE id=?", arrayOf(id)).use { c -> if (c.moveToFirst()) have = c.getLong(0) }
                if (have >= upd && have != -1L) continue
                val cv = ContentValues().apply {
                    put("id", id); put("title", o.optString("title").take(120)); put("body", o.optString("body").take(20000))
                    put("pinned", if (o.optBoolean("pinned")) 1 else 0)
                    put("created", o.optLong("created", upd)); put("updated", upd); put("deleted", if (o.optBoolean("deleted")) 1 else 0)
                }
                d.insertWithOnConflict("notes", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                changed++
            }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        return changed
    }
}

/** Messages typed while there was no internet and AI was needed. They wait here and are only sent after you say yes. */
object Outbox {
    class Item(val id: Long, val text: String, val at: Long, val attId: String = "")

    private fun db(ctx: Context) = LocalDb.get(ctx).writableDatabase

    @Synchronized
    fun add(ctx: Context, text: String, attId: String = "") {
        val t = text.trim().take(4000)
        if (t.isEmpty()) return
        val cv = ContentValues().apply { put("text", t); put("created", System.currentTimeMillis()); if (attId.isNotBlank()) put("att", attId) }
        db(ctx).insert("outbox", null, cv)
    }

    @Synchronized
    fun all(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        db(ctx).query("outbox", arrayOf("id", "text", "created", "att"), null, null, null, null, "id ASC").use { c ->
            while (c.moveToNext()) out.add(Item(c.getLong(0), c.getString(1), c.getLong(2), c.getString(3) ?: ""))
        }
        return out
    }

    fun count(ctx: Context) = all(ctx).size

    @Synchronized
    fun remove(ctx: Context, id: Long) { db(ctx).delete("outbox", "id=?", arrayOf(id.toString())) }

    @Synchronized
    fun clear(ctx: Context) { db(ctx).delete("outbox", null, null) }
}

/** Notes + tasks in one small file, so two phones can be brought together without any server. */
object SyncFile {
    fun export(ctx: Context): String =
        JSONObject().put("app", "AnjooAI-sync").put("version", 1).put("at", System.currentTimeMillis())
            .put("notes", Notes.exportArray(ctx)).put("tasks", Tasks.all(ctx)).toString()

    /** Returns a short human message. Safe to call with any text: a wrong file is refused. */
    fun merge(ctx: Context, text: String): String {
        val root = try { JSONObject(text) } catch (e: Exception) { return "Ye Anjoo ki sync file nahi lagti." }
        if (root.optString("app") != "AnjooAI-sync") return "Ye Anjoo ki sync file nahi lagti."
        val n = Notes.merge(ctx, root.optJSONArray("notes") ?: JSONArray())
        var t = 0
        val tasks = root.optJSONArray("tasks") ?: JSONArray()
        for (i in 0 until tasks.length()) if (Tasks.importOne(ctx, tasks.getJSONObject(i))) t++
        return String.format(Locale.ENGLISH, "Merge ho gaya: %d notes aur %d naye tasks.", n, t)
    }
}
