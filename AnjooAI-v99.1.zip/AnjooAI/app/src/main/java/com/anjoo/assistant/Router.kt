package com.anjoo.assistant

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** One AI model Anjoo can talk to: which company, which key (the first one; more keys are tried by [Router.keysFor]), which model. */
class Cand(val pv: Provider, val key: String, val model: String) {
    val id: String get() = pv.id + "|" + model
    val label: String get() = pv.id + " / " + model
}

/** What a request is mostly about. Every model is scored for each of these, and the best one answers. */
enum class Task(val label: String, val hint: String) {
    CHAT("seedhi baat", "tez aur halka model"),
    PHONE("phone ke kaam", "tools sahi chalane wala tez model"),
    CODE("coding", "code ka mahir model"),
    THINK("gehri sochna / hisaab", "bara reasoning model"),
    WRITE("likhna / tarjuma", "acha likhne wala model"),
    VISION("photo / PDF", "tasveer aur PDF samajhne wala model"),
    WEB("web / taaza khabar", "Gemini (search ke saath)")
}

/**
 * Picks which model answers, and learns which ones work.
 *
 * - Every message is sorted into a [Task] (coding, photo, phone command, ...) from its words, attachments and modes.
 * - Every model with a saved key is scored for that task (size, class, speed, special skills such as vision),
 *   and the best one answers. All of them stay ready; only ONE does the work.
 * - A company can have several keys. When one key runs out of limit, the next key of the same company is used at once.
 * - If a model still fails the next best one is tried. Models that worked and answered fast rank higher, failed ones rest.
 * - What it learns is saved on the phone (and in backups / the keys file).
 * - The chosen AI in Settings gets a small bonus, so it wins when two models are equally good.
 */
object Router {

    private class Stat {
        var ok = 0
        var fail = 0
        var consecFail = 0
        var avgMs = 0L
        var coolUntil = 0L
    }

    /** Local rolling diary: model use, task category, outcome and elapsed time per calendar day. */
    private class DayModel {
        var ok = 0
        var fail = 0
        var totalMs = 0L
        val tasks = HashMap<String, Int>()
        val taskOk = HashMap<String, Int>()
        val taskFail = HashMap<String, Int>()
    }

    /** One key of one company: how often used (to spread the load) and when it last hit a limit. */
    private class KeyStat {
        var use = 0
        var consec = 0
        var coolUntil = 0L
        var code = 0   // last error code that put the key to rest (429 = limit, 401/402/403 = refused)
    }

    private val stats = HashMap<String, Stat>()
    private val daily = java.util.TreeMap<String, HashMap<String, DayModel>>()
    private val keyStats = HashMap<String, KeyStat>()
    private const val MAX_TRIES = 6

    @Volatile private var stickyId: String? = null
    @Volatile private var stickyUntil = 0L

    /** Text for the screen, e.g. "groq / openai/gpt-oss-120b". Empty until the first answer. */
    @Volatile var lastUsed: String = ""

    // ------------------------------------------------------------ what happened in this run (per thread)

    /** One model that did part of the work in the current run. */
    class Used(val company: String, val model: String, val task: Task, val ms: Long)

    private val runLog = ThreadLocal<ArrayList<Used>>()

    /** Forces the task for the current thread (for example Code Studio is always "coding"). */
    val taskOverride = ThreadLocal<Task?>()

    /** Called with a short live line ("who is working now") while a request runs on this thread. */
    val live = ThreadLocal<((String) -> Unit)?>()

    fun beginRun() { runLog.set(ArrayList()) }

    private fun note(text: String) { try { live.get()?.invoke(text) } catch (e: Exception) {} }

    /** A tool that is not a chat model (picture maker, voice) can record itself, so the footer shows it too. */
    @Synchronized fun noteUsed(company: String, model: String, task: Task) {
        val l = runLog.get() ?: return
        if (l.none { it.company == company && it.model == model }) l.add(Used(company, model, task, 0))
        recordDailyId(company.lowercase(java.util.Locale.ROOT).replace(' ', '-') + "|" + model, task, true, 0)
        save()
    }

    private fun company(pv: Provider) = pv.label.substringBefore("  ").trim()

    private fun dayKey(at: Long = System.currentTimeMillis()) = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date(at))
    private fun recordDaily(c: Cand, task: Task, ok: Boolean, ms: Long) {
        recordDailyId(c.id, task, ok, ms)
    }
    private fun recordDailyId(id: String, task: Task, ok: Boolean, ms: Long) {
        val d = daily.getOrPut(dayKey()) { HashMap() }
        val m = d.getOrPut(id) { DayModel() }
        if (ok) { m.ok++; m.totalMs += ms } else m.fail++
        m.tasks[task.name] = (m.tasks[task.name] ?: 0) + 1
        val resultCounts = if (ok) m.taskOk else m.taskFail
        resultCounts[task.name] = (resultCounts[task.name] ?: 0) + 1
        while (daily.size > 45) daily.remove(daily.firstKey())
    }

    /**
     * The line shown under an answer: who made it, for which kind of work, and how many other models are ready.
     * Empty when nothing was recorded (for example a reply that did not use any AI).
     */
    fun footer(): String {
        val l = runLog.get() ?: return ""
        runLog.remove()
        if (l.isEmpty()) return ""
        val p = Providers.prefsRef
        val names = l.map { it.company + " · " + it.model.substringAfterLast('/') }.distinct()
        val shown = if (names.size <= 2) names.joinToString(" + ") else names.take(2).joinToString(" + ") + " +" + (names.size - 2)
        val task = l.first().task
        val total = if (p != null) universe(p).size else 0
        val others = maxOf(0, total - names.size)
        return "🤖 Banaya: " + shown + "  ·  " + task.label + (if (others > 0) "  ·  " + others + " aur models tayyar" else "")
    }

    // ------------------------------------------------------------ memory (kept on the phone)

    @Volatile private var loaded = false

    /** Reads the saved notes once per app start. Called from Providers.load. */
    @Synchronized fun load(p: SharedPreferences) {
        if (loaded) return
        loaded = true
        importJson(p.getString("routerStats", "") ?: "")
    }

    @Synchronized private fun save() {
        val p = Providers.prefsRef ?: return
        try { p.edit().putString("routerStats", exportJson()).apply() } catch (e: Exception) {}
    }

    @Synchronized fun exportJson(): String {
        val st = JSONObject()
        for ((id, s) in stats) {
            if (s.ok + s.fail == 0) continue
            st.put(id, JSONObject().put("ok", s.ok).put("fail", s.fail).put("cf", s.consecFail).put("ms", s.avgMs).put("cool", s.coolUntil))
        }
        val diary = JSONObject()
        for ((date, models) in daily) {
            val day = JSONObject()
            for ((id, m) in models) {
                val tasks = JSONObject()
                for ((task, n) in m.tasks) tasks.put(task, n)
                val taskOk = JSONObject(); for ((task, n) in m.taskOk) taskOk.put(task, n)
                val taskFail = JSONObject(); for ((task, n) in m.taskFail) taskFail.put(task, n)
                day.put(id, JSONObject().put("ok", m.ok).put("fail", m.fail).put("ms", m.totalMs).put("tasks", tasks).put("taskOk", taskOk).put("taskFail", taskFail))
            }
            diary.put(date, day)
        }
        return JSONObject().put("stats", st).put("daily", diary).put("sticky", stickyId ?: "").put("until", stickyUntil).put("last", lastUsed).toString()
    }

    @Synchronized fun importJson(text: String) {
        if (text.isBlank()) return
        try {
            val root = JSONObject(text)
            root.optJSONObject("stats")?.let { st ->
                val it = st.keys()
                while (it.hasNext()) {
                    val id = it.next()
                    val o = st.getJSONObject(id)
                    val s = stat(id)
                    s.ok = o.optInt("ok"); s.fail = o.optInt("fail"); s.consecFail = o.optInt("cf")
                    s.avgMs = o.optLong("ms"); s.coolUntil = o.optLong("cool")
                }
            }
            root.optJSONObject("daily")?.let { diary ->
                val dates = diary.keys()
                while (dates.hasNext()) {
                    val date = dates.next()
                    val dayObj = diary.optJSONObject(date) ?: continue
                    val models = HashMap<String, DayModel>()
                    val modelIds = dayObj.keys()
                    while (modelIds.hasNext()) {
                        val id = modelIds.next()
                        val o = dayObj.optJSONObject(id) ?: continue
                        val m = DayModel()
                        m.ok = o.optInt("ok"); m.fail = o.optInt("fail"); m.totalMs = o.optLong("ms")
                        o.optJSONObject("tasks")?.let { ts ->
                            val ti = ts.keys()
                            while (ti.hasNext()) { val task = ti.next(); m.tasks[task] = ts.optInt(task) }
                        }
                        o.optJSONObject("taskOk")?.let { ts -> val ti = ts.keys(); while (ti.hasNext()) { val task = ti.next(); m.taskOk[task] = ts.optInt(task) } }
                        o.optJSONObject("taskFail")?.let { ts -> val ti = ts.keys(); while (ti.hasNext()) { val task = ti.next(); m.taskFail[task] = ts.optInt(task) } }
                        models[id] = m
                    }
                    daily[date] = models
                }
                while (daily.size > 45) daily.remove(daily.firstKey())
            }
            lastUsed = root.optString("last", "")
        } catch (e: Exception) { /* bad notes are ignored; they build up again */ }
    }

    // ------------------------------------------------------------ what is this request about?

    private val CODE_RX = Regex("(\\bcode\\b|coding|\\bbug\\b|traceback|exception|compile|\\bdebug|function|script|python|kotlin|java\\b|javascript|typescript|\\bhtml\\b|\\bcss\\b|\\bsql\\b|regex|\\bapi\\b|algorithm|program|github|gradle|android studio|website bana|app bana|project bana|apk|\\bjson\\b|\\bnode\\b|\\breact\\b|flutter)")
    private val THINK_RX = Regex("(hisaab|hisab|calculat|solve|\\bmath|equation|proof|logic|reason|step by step|analy[sz]|compare|tafseel|gehri|gehra|\\bwhy\\b|kyun|strategy|\\bplan\\b|decide|pros and cons|derive|puzzle|probability|statistics)")
    private val WRITE_RX = Regex("(likho|likh do|likh kar|essay|article|story|kahani|letter|\\bemail\\b|\\bmail\\b|caption|poem|shayari|speech|\\bblog|report|summar|translate|tarjuma|tarjama|rewrite|proofread|paragraph|cv\\b|resume)")
    private val PHONE_RX = Regex("(\\bcall\\b|\\bsms\\b|message bhej|whatsapp|alarm|timer|reminder|yaad dila|kholo|\\bopen\\b|volume|torch|flashlight|wifi|wi-fi|bluetooth|brightness|screenshot|\\btap\\b|swipe|contact|battery|music|chalao|band karo|laga do|lagao|\\bset\\b|notification|screen)")

    private fun realUserTurn(contents: JSONArray): JSONObject? {
        for (i in contents.length() - 1 downTo 0) {
            val c = contents.optJSONObject(i) ?: continue
            if (c.optString("role", "user") != "user") continue
            val ps = c.optJSONArray("parts") ?: continue
            for (j in 0 until ps.length()) { val t = ps.optJSONObject(j)?.optString("text", "") ?: ""; if (t.isNotBlank()) return c }
        }
        return null
    }

    /** Sorts a request into a [Task]. Second value: true when it carries a PDF (fewer models can read those). */
    fun taskFor(contents: JSONArray, thinking: Boolean, grounded: Boolean, withTools: Boolean, maxTokens: Int): Pair<Task, Boolean> {
        taskOverride.get()?.let { return Pair(it, false) }
        val turn = realUserTurn(contents)
        val ps = turn?.optJSONArray("parts")
        val sb = StringBuilder()
        var media = false
        var pdf = false
        if (ps != null) for (j in 0 until ps.length()) {
            val o = ps.optJSONObject(j) ?: continue
            if (o.has("text")) sb.append(o.optString("text")).append(' ')
            val d = o.optJSONObject("inlineData")
            if (d != null) { media = true; if (d.optString("mimeType") == "application/pdf") pdf = true }
        }
        val t = sb.toString().lowercase().take(3000)
        val task = when {
            media -> Task.VISION
            grounded -> Task.WEB
            t.contains("```") || CODE_RX.containsMatchIn(t) || maxTokens >= 16000 -> Task.CODE
            thinking -> Task.THINK
            withTools && PHONE_RX.containsMatchIn(t) -> Task.PHONE
            THINK_RX.containsMatchIn(t) -> Task.THINK
            WRITE_RX.containsMatchIn(t) -> Task.WRITE
            else -> Task.CHAT
        }
        return Pair(task, pdf)
    }

    // ------------------------------------------------------------ how good is each model at each task?

    class Prof(val vision: Boolean, val pdf: Boolean, val tools: Boolean, val score: Map<Task, Int>) {
        fun best(): Int = score.values.maxOrNull() ?: 0
    }

    private val profCache = HashMap<String, Prof>()

    private val SMALL_RX = Regex("(lite|nano|mini|small|(^|[^0-9])(1|3|4|7|8)b\\b|instant|haiku|e2b|e4b|flash-8b)")
    private val BIG_RX = Regex("(\\bpro\\b|-pro|opus|sonnet|fable|mythos|gpt-5|gpt-4\\.1|gpt-4o|120b|405b|70b|235b|480b|550b|671b|ultra|large|grok-4|grok-3\\b|reasoner|\\bo3\\b|\\bo1\\b|\\bo4\\b|3\\.8-flash|3\\.6-flash|2\\.5-flash\\b)")
    private val CODER_RX = Regex("(coder|codestral|devstral|-code\\b|code-)")
    private val REASON_RX = Regex("(reasoner|\\br1\\b|thinking|\\bo[134]\\b|-pro|\\bpro\\b|opus|gpt-5|ultra|120b|nemotron|gpt-oss|qwen3|grok-4|fable)")
    private val NO_TOOLS_RX = Regex("(reasoner|\\br1\\b|gemma|\\bo1-|prompt-guard|distill)")

    fun profile(pv: Provider, model: String): Prof = synchronized(profCache) {
        profCache.getOrPut(pv.id + "|" + model) { buildProfile(pv, model) }
    }

    private fun buildProfile(pv: Provider, model: String): Prof {
        val m = model.lowercase()
        val small = SMALL_RX.containsMatchIn(m)
        val big = !small && BIG_RX.containsMatchIn(m)
        val coder = CODER_RX.containsMatchIn(m)
        val reasoner = !small && REASON_RX.containsMatchIn(m)
        val sc = HashMap<Task, Int>()
        for (t in Task.values()) sc[t] = when (t) { Task.CHAT, Task.PHONE -> 6; Task.WEB -> 4; else -> 5 }
        fun add(t: Task, v: Int) { sc[t] = (sc[t] ?: 5) + v }
        if (big) { add(Task.CODE, 2); add(Task.THINK, 3); add(Task.WRITE, 2); add(Task.PHONE, 1); add(Task.VISION, 1) }
        if (small) { add(Task.CHAT, 2); add(Task.PHONE, 1); add(Task.CODE, -1); add(Task.THINK, -2); add(Task.WRITE, -1) }
        if (coder) add(Task.CODE, 3)
        if (reasoner) add(Task.THINK, 2)
        when (pv.id) {
            "groq" -> { add(Task.CHAT, 2); add(Task.PHONE, 2) }                          // very fast
            "gemini" -> { add(Task.WRITE, 1); add(Task.VISION, 2); add(Task.WEB, 5); add(Task.PHONE, 1) }
            "anthropic" -> { add(Task.CODE, 1); add(Task.WRITE, 2); add(Task.PHONE, 1); add(Task.VISION, 1) }
            "openai" -> { add(Task.CODE, 1); add(Task.PHONE, 1) }
            "deepseek" -> { add(Task.CODE, 1); add(Task.THINK, 1) }
            "mistral" -> add(Task.WRITE, 1)
            "xai" -> add(Task.THINK, 1)
        }
        val vision = when (pv.id) {
            "gemini", "anthropic" -> !m.contains("gemma-3n") && !m.contains("embedding")
            "openai" -> m.startsWith("gpt-4") || m.startsWith("gpt-5") || m.startsWith("o3") || m.startsWith("o4")
            "xai" -> m.contains("grok-4") || m.contains("vision")
            "mistral" -> m.contains("pixtral") || m.contains("medium") || m.contains("large")
            "github" -> m.contains("gpt-4") || m.contains("gpt-5") || m.contains("llama-4") || m.contains("multimodal")
            "nvidia", "huggingface", "kilo", "chutes", "alibaba", "zai", "cloudflare" ->
                m.contains("vision") || m.contains("-vl") || m.contains("llama-4") || m.contains("4.5v") || m.contains("qwen-vl") || m.contains("gemini") || m.contains("claude") || m.contains("gpt-5")
            "groq", "openrouter" -> m.contains("vision") || m.contains("-vl") || m.contains("llama-4") || m.contains("gemma-4") || m.contains("gemini") || m.contains("gpt-4o") || m.contains("claude")
            else -> false
        }
        val pdf = pv.id == "gemini" || pv.id == "anthropic" || (pv.id == "openai" && vision)
        val tools = !NO_TOOLS_RX.containsMatchIn(m)
        for (k in sc.keys.toList()) sc[k] = (sc[k] ?: 5).coerceIn(0, 10)
        if (!vision) sc[Task.VISION] = 0
        return Prof(vision, pdf, tools, sc)
    }

    private fun isFree(c: Cand): Boolean = when (c.pv.id) {
        "gemini", "groq" -> true
        "openrouter" -> c.model.endsWith(":free") || c.model == "openrouter/free"
        "zai" -> c.model.contains("flash")
        "kilo" -> c.model.contains("free")
        else -> c.pv.free
    }

    // ------------------------------------------------------------ which models exist (from the saved keys)

    private val NOT_CHAT = Regex("(embed|whisper|tts|speech|guard|moderat|safeguard|image|imagen|veo|audio|orpheus|playai|transcri|rerank|aqa|robotics|\\blive|dall|sora|davinci|babbage|computer-use|search-preview|realtime|-vision-only)")
    private const val PER_COMPANY = 14

    private fun catalog(p: SharedPreferences, id: String): List<String> =
        (p.getString("catalog_$id", "") ?: "").split('\n').map { it.trim() }.filter { it.isNotEmpty() }

    /** Every model that can be used right now: for each company with a key, its saved, default and listed models. */
    fun universe(p: SharedPreferences): List<Cand> {
        val out = ArrayList<Cand>()
        for (pv in Providers.ALL) {
            val keys = Providers.allKeys(p, pv.id)
            if (keys.isEmpty()) continue
            if (pv.id == "custom" && (p.getString("base_custom", "") ?: "").isBlank()) continue
            val cat = catalog(p, pv.id).filter { !NOT_CHAT.containsMatchIn(it.lowercase()) }
            val ms = LinkedHashSet<String>()
            val saved = Providers.savedModel(p, pv.id)
            if (saved.isNotBlank()) ms.add(saved)
            if (cat.isNotEmpty()) {
                pv.models.filter { it in cat }.forEach { ms.add(it) }
                var extra = cat.filter { it !in ms }
                if (pv.id == "openrouter") extra = extra.filter { it.endsWith(":free") || it == "openrouter/free" }
                extra.sortedByDescending { profile(pv, it).best() }.forEach { ms.add(it) }
            } else {
                ms.addAll(pv.models)
            }
            for (m in ms.take(PER_COMPANY)) out.add(Cand(pv, keys[0], m))
        }
        return out
    }

    /** Asks every company that has a key which models its key can use, and keeps the answer on the phone. Blocking: call from a thread. */
    fun refreshCatalog(p: SharedPreferences): Int {
        var n = 0
        for (pv in Providers.ALL) {
            if (pv.id == "custom") continue
            val keys = Providers.allKeys(p, pv.id)
            for (k in keys) {
                try {
                    val list = Providers.listModels(pv, k)
                    if (list.isNotEmpty()) {
                        p.edit().putString("catalog_" + pv.id, list.take(400).joinToString("\n")).putLong("catalogAt", System.currentTimeMillis()).apply()
                        n++
                        break
                    }
                } catch (e: Exception) { /* try the next key of this company */ }
            }
        }
        return n
    }

    // ------------------------------------------------------------ choosing

    @Synchronized private fun stat(id: String) = stats.getOrPut(id) { Stat() }
    @Synchronized private fun kstat(pv: Provider, key: String) = keyStats.getOrPut(pv.id + "#" + key.takeLast(8)) { KeyStat() }

    /** All keys of one company, the ones not resting and least used first, so the load is shared. */
    @Synchronized fun keysFor(pv: Provider): List<String> {
        val p = Providers.prefsRef ?: return emptyList()
        val now = System.currentTimeMillis()
        return Providers.allKeys(p, pv.id).sortedWith(compareBy({ kstat(pv, it).coolUntil > now }, { kstat(pv, it).use }))
    }

    private fun companyResting(pv: Provider, now: Long): Boolean {
        val p = Providers.prefsRef ?: return false
        val ks = Providers.allKeys(p, pv.id)
        return ks.isNotEmpty() && ks.all { kstat(pv, it).coolUntil > now }
    }

    private fun rate(c: Cand, task: Task, primary: Cand): Double {
        val prof = profile(c.pv, c.model)
        var v = (prof.score[task] ?: 5).toDouble()
        if (c.pv.id == primary.pv.id) v += if (c.model == primary.model) 1.5 else 0.5
        val s = stat(c.id)
        val total = s.ok + s.fail
        if (total > 0) v -= 6.0 * s.fail / total
        if (s.ok >= 2) v -= minOf(4.0, s.avgMs / (if (task == Task.CHAT || task == Task.PHONE) 1500.0 else 5000.0))
        if (s.ok >= 3 && s.consecFail == 0) v += 0.5
        if (!isFree(c)) v -= if (task == Task.THINK || task == Task.CODE || task == Task.VISION) 0.3 else 0.8
        return v
    }

    /** The models to try, best first, for this kind of work. */
    @Synchronized fun plan(primary: Cand, task: Task, needTools: Boolean, needPdf: Boolean): List<Cand> {
        val p = Providers.prefsRef ?: return listOf(primary)
        val now = System.currentTimeMillis()
        var pool = universe(p).toMutableList()
        if (primary.key.isNotBlank() && pool.none { it.pv.id == primary.pv.id && it.model == primary.model }) pool.add(primary)
        var ok = pool.filter { c ->
            val f = profile(c.pv, c.model)
            (!needTools || f.tools) && (task != Task.VISION || (f.vision && (!needPdf || f.pdf)))
        }
        if (ok.isEmpty()) ok = pool
        val healthy = ok.filter { !cooling(it, now) && !companyResting(it.pv, now) }.map { it to rate(it, task, primary) }.sortedByDescending { it.second }
        val resting = ok.filter { cooling(it, now) || companyResting(it.pv, now) }.map { it to rate(it, task, primary) }.sortedByDescending { it.second }
        // Mix companies: a second model of a company that was just picked is a little less attractive (same limits, same outage).
        val picked = ArrayList<Cand>()
        val left = healthy.toMutableList()
        while (left.isNotEmpty() && picked.size < MAX_TRIES) {
            val best = left.maxByOrNull { (c, r) -> r - 1.0 * picked.count { it.pv.id == c.pv.id } }!!
            picked.add(best.first); left.remove(best)
        }
        for ((c, _) in resting) if (picked.size < MAX_TRIES) picked.add(c)
        return picked
    }

    private fun cooling(c: Cand, now: Long) = stat(c.id).coolUntil > now

    @Synchronized fun success(c: Cand, key: String, task: Task, ms: Long) {
        val s = stat(c.id)
        s.ok++; s.consecFail = 0; s.coolUntil = 0L
        s.avgMs = if (s.avgMs == 0L) ms else (s.avgMs * 7 + ms * 3) / 10
        recordDaily(c, task, true, ms)
        val ks = kstat(c.pv, key); ks.use++; ks.consec = 0; ks.code = 0
        lastUsed = c.label
        val l = runLog.get()
        if (l != null && l.none { it.company == company(c.pv) && it.model == c.model }) l.add(Used(company(c.pv), c.model, task, ms))
        save()
    }

    /** A key hit its own limit or was refused (not the model's fault): rest that key, the next key of the company is used. */
    @Synchronized fun keyFailure(pv: Provider, key: String, e: Exception) {
        val ks = kstat(pv, key)
        ks.consec++
        val code = (e as? ApiException)?.code ?: 0
        ks.code = code
        val base = if (code == 429) 60_000L * (1L shl minOf(ks.consec - 1, 4)) else 30L * 60_000
        ks.coolUntil = System.currentTimeMillis() + minOf(base, 30L * 60_000)
    }

    @Synchronized fun failure(c: Cand, e: Exception, task: Task? = null) {
        val s = stat(c.id)
        s.fail++; s.consecFail++
        recordDaily(c, task ?: Task.CHAT, false, 0)
        val code = (e as? ApiException)?.code ?: 0
        val base = when (code) {
            401, 403, 404 -> 30L * 60_000          // wrong key / model gone: rest a long time
            400, 422 -> 5L * 60_000                // this model could not handle the request
            429 -> 60_000L                         // limit reached: rest, longer each time in a row
            else -> 45_000L                        // server down or no network
        }
        val mult = if (code == 429 || code == 0 || code >= 500) 1L shl minOf(s.consecFail - 1, 5) else 1L
        s.coolUntil = System.currentTimeMillis() + minOf(base * mult, 30L * 60_000)
        save()
    }

    /** Selected/manual provider calls bypass failover; keep their measured outcome too. */
    @Synchronized fun manualResult(pv: Provider, model: String, task: Task, ms: Long, ok: Boolean) {
        val c = Cand(pv, "", model)
        val s = stat(c.id)
        if (ok) {
            s.ok++; s.consecFail = 0; s.coolUntil = 0L
            s.avgMs = if (s.avgMs == 0L) ms else (s.avgMs * 7 + ms * 3) / 10
            lastUsed = c.label
            val l = runLog.get()
            if (l != null && l.none { it.company == company(pv) && it.model == model }) l.add(Used(company(pv), model, task, ms))
        } else s.fail++
        recordDaily(c, task, ok, ms)
        save()
    }

    /** Seven-day activity plus up to 45 days of evidence-based per-task ranking. */
    @Synchronized fun usageReport(days: Int = 7): String {
        class Total {
            var ok = 0; var fail = 0; var ms = 0L
            val tasks = HashMap<String, Int>(); val taskOk = HashMap<String, Int>(); val taskFail = HashMap<String, Int>()
        }
        val today = dayKey()
        val cal = java.util.Calendar.getInstance().apply { add(java.util.Calendar.DAY_OF_YEAR, -(days.coerceIn(1, 30) - 1)) }
        val start = dayKey(cal.timeInMillis)
        val modelTotals = HashMap<String, Total>()
        val dayTotals = daily.filterKeys { it >= start && it <= today }.toSortedMap()
        for ((_, models) in daily) for ((id, m) in models) {
            val a = modelTotals.getOrPut(id) { Total() }
            a.ok += m.ok; a.fail += m.fail; a.ms += m.totalMs
            for ((task, n) in m.tasks) a.tasks[task] = (a.tasks[task] ?: 0) + n
            for ((task, n) in m.taskOk) a.taskOk[task] = (a.taskOk[task] ?: 0) + n
            for ((task, n) in m.taskFail) a.taskFail[task] = (a.taskFail[task] ?: 0) + n
        }
        val todayModels = daily[today].orEmpty()
        val todayReq = todayModels.values.sumOf { it.ok + it.fail }
        val todayOk = todayModels.values.sumOf { it.ok }
        val todayFail = todayModels.values.sumOf { it.fail }
        val sb = StringBuilder("📊 Daily model usage · last ").append(days.coerceIn(1, 30)).append(" days\n")
        sb.append("Today: ").append(todayReq).append(" attempts · ").append(todayOk).append(" answered · ").append(todayFail).append(" failed\n")
        if (todayModels.isEmpty()) sb.append("Aaj abhi AI model use record nahi hua.\n")
        else {
            sb.append("\nTODAY · model / work / speed\n")
            for ((id, m) in todayModels.toList().sortedByDescending { it.second.ok + it.second.fail }) {
                val total = m.ok + m.fail
                val avg = if (m.ok > 0) String.format(java.util.Locale.US, "%.1fs", m.totalMs.toDouble() / m.ok / 1000.0) else "—"
                sb.append(if (m.fail == 0) "🟩 " else "🟨 ").append(displayModel(id)).append(" · ").append(m.ok).append(" ok / ").append(m.fail).append(" fail · ").append(avg)
                if (m.tasks.isNotEmpty()) sb.append("\n   ").append(m.tasks.entries.sortedByDescending { it.value }.joinToString(" · ") { (t, n) -> (Task.values().firstOrNull { it.name == t }?.label ?: t) + " " + n })
                sb.append('\n')
            }
        }
        sb.append("\nDAILY VOLUME · saved locally\n")
        val maxReq = maxOf(1, dayTotals.values.sumOf { models -> models.values.sumOf { it.ok + it.fail } })
        for ((date, models) in dayTotals) {
            val n = models.values.sumOf { it.ok + it.fail }
            val squares = if (n == 0) "▫️" else "🟩".repeat((n * 8 / maxReq).coerceIn(1, 8))
            sb.append(date).append("  ").append(squares).append("  ").append(n).append(" request")
            if (n != 1) sb.append('s')
            sb.append("\n")
            for ((id, m) in models.toList().sortedByDescending { it.second.ok + it.second.fail }) {
                val tasks = m.tasks.entries.joinToString(", ") { (t, c) -> (Task.values().firstOrNull { it.name == t }?.label ?: t) + " " + c }
                sb.append("   ").append(displayModel(id)).append(": ").append(m.ok).append(" ok, ").append(m.fail).append(" fail")
                if (tasks.isNotBlank()) sb.append(" · ").append(tasks)
                sb.append('\n')
            }
        }
        sb.append("\nBEST OBSERVED BY WORK · rolling 45-day memory\n")
        var anyBest = false
        for (task in Task.values()) {
            val ranked = modelTotals.entries.mapNotNull { (id, a) ->
                val uses = a.tasks[task.name] ?: 0
                if (uses == 0 || (a.taskOk[task.name] ?: 0) + (a.taskFail[task.name] ?: 0) == 0) null else Triple(id, a, uses)
            }.sortedWith(compareByDescending<Triple<String, Total, Int>> { (it.second.taskOk[task.name] ?: 0).toDouble() / maxOf(1, it.second.tasks[task.name] ?: 0) }.thenBy { it.second.ms / maxOf(1, it.second.ok) })
            val best = ranked.firstOrNull() ?: continue
            anyBest = true
            val taskOk = best.second.taskOk[task.name] ?: 0
            val acc = 100 * taskOk / maxOf(1, best.third)
            sb.append("• ").append(task.label).append(" → ").append(displayModel(best.first)).append(" · ").append(acc).append("% app success").append(" · ").append(best.third).append(" uses")
            if (best.second.ok > 0) sb.append(" · avg ").append(String.format(java.util.Locale.US, "%.1fs", best.second.ms.toDouble() / best.second.ok / 1000.0))
            val split = best.first.split('|', limit = 2)
            if (split.size == 2 && Providers.ALL.any { it.id == split[0] }) {
                val what = goodAt(profile(Providers.byId(split[0]), split[1]))
                if (what.isNotBlank()) sb.append("\n   Suited for: ").append(what)
            }
            sb.append('\n')
        }
        if (!anyBest) sb.append("Abhi per-work winner select karne ke liye kaafi observed usage nahi.\n")
        sb.append("\nYe counts Anjoo ke app mein dekhe gaye model calls hain, provider ke token/billing totals nahi. Data phone par save hota hai; best ranking sirf recorded results par based hai.")
        return sb.toString().trim()
    }

    private fun displayModel(id: String): String {
        val p = id.split('|', limit = 2)
        if (p.size < 2) return id
        val pv = Providers.ALL.firstOrNull { it.id == p[0] }
        return (if (pv != null) company(pv) else p[0].replace('-', ' ')) + " · " + p[1].substringAfterLast('/')
    }

    /** True when the error is about the KEY (limit, refused), so another key of the same company may work. */
    fun isKeyError(e: Exception): Boolean = e is ApiException && (e.code == 401 || e.code == 402 || e.code == 403 || e.code == 429)

    /** True when another model is worth trying after this error. [badRequests] counts earlier 400/422 in this request. */
    fun worthRetrying(e: Exception, badRequests: Int): Boolean {
        if (e is CancelledException) return false
        if (e is ApiException) return if (e.code == 400 || e.code == 422) badRequests < 2 else true
        return e is java.io.IOException || e is JSONException
    }

    /** Called by the sender before each try: shows who is working now. */
    fun announce(c: Cand, task: Task, attempt: Int) {
        note((if (attempt > 0) "⏭ agla: " else "") + company(c.pv) + " · " + c.model.substringAfterLast('/') + "  (" + task.label + ")")
    }

    fun announceFail(c: Cand, e: Exception) {
        val why = (e as? ApiException)?.code?.let { "error $it" } ?: "jawab nahi aaya"
        note(company(c.pv) + " · " + c.model.substringAfterLast('/') + " ne " + why + " diya, doosra try ho raha hai")
    }

    // ------------------------------------------------------------ map ("kaun kis kaam ka hai?")

    private fun tier(f: Prof): String {
        val strong = maxOf(f.score[Task.THINK] ?: 0, f.score[Task.CODE] ?: 0)
        return when { strong >= 9 -> "bohat taqatwar"; strong >= 8 -> "taqatwar"; strong >= 6 -> "darmiyana"; else -> "halka, tez" }
    }

    private fun goodAt(f: Prof): String {
        val top = f.score.entries.filter { it.key != Task.WEB && it.value >= 7 && (it.key != Task.VISION || f.vision) }
            .sortedByDescending { it.value }.take(3).map { it.key.label }
        val extra = ArrayList<String>()
        if (f.vision) extra.add("photo")
        if (f.pdf) extra.add("PDF")
        return (top + extra).distinct().joinToString(", ")
    }

    class KeyRow(val tail: String, val state: Int, val secs: Long, val code: Int, val uses: Int) // state: 0 ready, 1 resting (limit), 2 refused/error
    class CompanyRow(val name: String, val keys: List<KeyRow>)

    /** Limit meter: every company, every saved key, and whether it is ready, at its limit (429), or refused. */
    @Synchronized fun limitRows(): List<CompanyRow> {
        val p = Providers.prefsRef ?: return emptyList()
        val now = System.currentTimeMillis()
        val out = ArrayList<CompanyRow>()
        for (pv in universe(p).map { it.pv }.distinct()) {
            val rows = Providers.allKeys(p, pv.id).map { k ->
                val ks = kstat(pv, k)
                val left = (ks.coolUntil - now) / 1000
                val st = if (left <= 0) 0 else if (ks.code == 429) 1 else 2
                KeyRow(k.takeLast(4), st, maxOf(left, 0), ks.code, ks.use)
            }
            if (rows.isNotEmpty()) out.add(CompanyRow(company(pv), rows))
        }
        return out
    }

    /** Lets every resting key try again right now (use after a limit reset). */
    @Synchronized fun clearRests() {
        keyStats.values.forEach { it.coolUntil = 0L; it.consec = 0; it.code = 0 }
        stats.values.forEach { it.coolUntil = 0L; it.consecFail = 0 }
        save()
    }

    /** Plain-text map for the chat or a dialog: companies, keys, models, what each is good for, and who answers which kind of work. */
    @Synchronized fun report(): String {
        val p = Providers.prefsRef ?: return "Abhi models ki maloomat nahi hai. Pehle Settings me key daalo."
        val now = System.currentTimeMillis()
        val uni = universe(p)
        if (uni.isEmpty()) return "Koi key saved nahi hai. Menu → 🔑 Keys add karo me apni keys paste karo (Gemini, Groq, OpenRouter, OpenAI, Claude ... jo bhi ho)."
        val companies = uni.map { it.pv }.distinct()
        val totalKeys = companies.sumOf { Providers.allKeys(p, it.id).size }
        val sb = StringBuilder("🧭 Models ka naqsha\n")
        sb.append(companies.size).append(" company, ").append(totalKeys).append(" key, ").append(uni.size).append(" model tayyar.\n")
        if (lastUsed.isNotBlank()) sb.append("Aakhri jawab: ").append(lastUsed).append('\n')
        for (pv in companies) {
            val ks = Providers.allKeys(p, pv.id)
            val rest = ks.count { kstat(pv, it).coolUntil > now }
            sb.append("\n▸ ").append(company(pv)).append(" — ").append(ks.size).append(if (ks.size == 1) " key" else " keys")
            if (rest > 0) sb.append(" (").append(rest).append(" aaram par)")
            if (isFree(Cand(pv, "", pv.models.firstOrNull() ?: ""))) sb.append("  🆓")
            sb.append('\n')
            val ms = uni.filter { it.pv.id == pv.id }
            for (c in ms.take(6)) {
                val f = profile(c.pv, c.model)
                val s = stat(c.id)
                val st = if (s.coolUntil > now) "⏸️" else if (s.ok + s.fail == 0) "⚪" else if (s.consecFail > 0) "⚠️" else "✅"
                sb.append("  ").append(st).append(' ').append(c.model).append(" — ").append(tier(f))
                val g = goodAt(f)
                if (g.isNotEmpty()) sb.append(" | ").append(g)
                if (s.ok > 0) sb.append(" | ").append("%.1f".format(s.avgMs / 1000.0)).append("s")
                sb.append('\n')
            }
            if (ms.size > 6) sb.append("  … aur ").append(ms.size - 6).append(" model\n")
        }
        sb.append("\n🎯 Kaam → kaun karega (abhi)\n")
        val prim = Cand(Providers.active, Providers.savedKey(p, Providers.active.id), Providers.savedModel(p, Providers.active.id))
        for (t in Task.values()) {
            val first = plan(prim, t, true, false).firstOrNull() ?: continue
            sb.append("• ").append(t.label).append(": ").append(company(first.pv)).append(" · ").append(first.model.substringAfterLast('/')).append('\n')
        }
        sb.append("\nSab tayyar rehte hain, har kaam par sirf sab se munasib model jawab deta hai. Ek key ki limit khatam ho to usi company ki doosri key lag jati hai.")
        sb.append("\n✅ chal raha  ⚠️ haal hi me fail  ⏸️ aaram par  ⚪ abhi test nahi hua")
        sb.append("\n\nLimit note: yeh rang app ke recent requests ka status hain, provider ka live quota nahi. Har company ka usage endpoint alag hota hai; jahan provider authorized balance/limit nahi deta wahan remaining percentage dikhana mumkin nahi. Pollinations ka balance alag live report se dekhein.")
        sb.append("\n\n").append(usageReport(1))
        return sb.toString().trim()
    }

    private val ASK_ABOUT = Regex("(model|models|connection|connections|provider|groq|gemini|openrouter|\\bkeys?\\b|\\bapi\\b|company|companies|usage|daily|rozana|roz|aaj|memory|performance)")
    private val ASK_STATUS = Regex("(kon|kaun|konsa|kaunsa|kon sa|kaun sa|which|best|behtar|behtreen|status|strong|taqat|tagat|chal raha|chal rahi|chal rahe|working|haal|report|performance|kitna|kitne|kitni|naqsha|map|available|kis kaam|use|istemaal|istamal|chala|chalaya|work|day|rozana|roz|aaj|memory|seekha|sikha|save|report|batao|dikhao|show|usage)")
    private val ASK_NOT = Regex("(code|coding|project|website|python|kotlin|likh|bana|script|app |function)")

    /** True when the message is asking how the models/connections are doing (not asking for help using one). */
    fun asksStatus(text: String): Boolean {
        val t = text.lowercase().trim()
        if (t.length > 110 || t.contains("```")) return false
        if (t == "model status" || t == "models status" || t == "connection status") return true
        return ASK_ABOUT.containsMatchIn(t) && ASK_STATUS.containsMatchIn(t) && !ASK_NOT.containsMatchIn(t)
    }
}
