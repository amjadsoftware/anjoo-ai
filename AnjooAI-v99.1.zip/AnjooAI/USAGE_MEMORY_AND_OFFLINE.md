# Daily model-use memory and offline recovery

Anjoo keeps a rolling local diary for up to 45 calendar days. It records the model, work category, success/failure, and elapsed response time. The diary is saved in the app's `routerStats` preference and restored on app start. It does not collect provider billing/token data unless a provider API separately exposes it.

Ask in chat for a model usage or daily report, for example: **"aaj models ka use report dikhao"**, **"rozana kis model ne kitna kaam kiya?"**, or **"kis kaam ke liye konsa model best raha?"**. The report shows today's counts and response times, day-by-day call volume, and the best-observed model per task from recent usage. The ranking is based on Anjoo's observed outcomes; it is not a universal benchmark. Early reports may say there is not enough usage yet.

Text requests and attached photos/files sent while offline are saved in the local Outbox. Requests interrupted by a network error are also queued for a later retry. When connectivity returns, Anjoo shows the queued messages while the app is in the foreground and asks before sending. Saved files are referenced locally so they can be replayed with the request.

This uses the current Android process and network callback. It is not a guarantee that generation will keep executing after Android kills Anjoo's process or forcibly stops the app. In that case, queued requests remain saved once they have reached the Outbox and are offered when the app is opened and connectivity is available. Long-running guaranteed execution across process death would require a dedicated persistent-work implementation and platform scheduling.
