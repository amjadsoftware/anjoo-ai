# Anjoo AI v99.2.13
- Invoices/pages/dashboards render live inside the chat message (MainActivity.inlineArtifactCard), no extra tap.
- Markdown sent for a page/invoice is converted to a styled page; invoice design spec (Artifacts.INVOICE_RULES).
- New tools: paste_text, send_in_app (asks before pressing Send). type_text falls back to clipboard paste.
- When Accessibility is off, the app opens Accessibility settings and explains "Allow restricted settings".
- GF mode rewritten: real-girlfriend tone (loving, lazy-sweet, flirty, playful fights), addresses the owner (Amjad) by name, chat-only, always a woman's voice (GeminiVoice.voiceFor, Speaker). Non-explicit.
