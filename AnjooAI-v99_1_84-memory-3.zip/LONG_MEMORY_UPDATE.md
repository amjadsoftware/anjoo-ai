# Long-term memory - v99.1.84 (draft)

- NEW LongMemory.kt: Anjoo's memory is no longer 50 plain notes. Items have a kind: pref (pasand/aadat), task (chal raha kaam), person (log/rishte), fact. Up to 600 items, saved in long_memory.json.
- Old notes move over automatically once.
- Duplicates are merged (updated, not repeated).
- Each prompt gets only the memories that fit the current message (all preferences, open tasks, best-matching people/facts), within ~2200 characters.
- Related old chats are added to the prompt when they share words with the current message.
- Auto Memory (Settings, default on, needs Save Memory on): clear statements ("mujhe ... pasand hai", "meri behan ...", "main ... bana raha hoon") are saved without saying "yaad rakho". Questions and commands are ignored. Saying a task is done ("ho gaya") closes it.
- Never stored: password, PIN, OTP, card number, API key.
- New tools: memory_done, list_memory. remember now takes kind and pin.
- Backup/restore include the memory (merged, newest edit wins).
- Tests: LongMemoryTest.kt (not run yet - no Kotlin compiler where this was written).

# GF mode
- Say "GF" (or "gf mode on", "gf ban jao") and Anjoo talks warmly like a girlfriend. Say "normal" or "gf off" to go back. Off by default; the setting is remembered.
- A sentence about someone's gf ("meri gf ko message bhejo") does not switch it on.
- Stays affectionate but clean; no jealousy or guilt-tripping; tools, confirmations and safety rules are unchanged.

# Maker credit
- Asked who made Anjoo: answers "Amjad ne banaya hai". For new features or changes: contact Amjad on WhatsApp +92 300 1122810. Works in GF mode too. If asked which AI model runs inside, it answers honestly. (Credit.kt)

# Claude-style Summary timeline
- "Summary" pill (was "Thinking" + "Results" tabs). Tapping it opens a vertical timeline sheet.
- Timeline shows: thinking phase with sub-lines, then every tool/command step in order.
- Each entry: left timeline line + rounded icon badge (tool calls) or grey dot (thoughts), bold text for done steps, grey for in-progress, orange pulsing dot for the currently running step.
- Header: × on left, "Summary" centred. Single scrollable list — no tabs.

# Live process always visible
- Previously: for simple questions (no tools/thinking), the workstation card disappeared the moment text started streaming.
- Now: card stays on screen for every query. Streaming answer appears inside the card ("Jawab likh raha hoon..." label + text grows below the steps). For tool-heavy queries, text area is cleared when a step card appears.
- No more blank gap between "send" and seeing text appear.

# HsApkBuilderActivity — improvements
- **App metadata inputs**: Package name (com.yourname.app) and version name — folded "App info" section. Defaults auto-derive from project name. Passed as workflow_dispatch inputs to GitHub Actions.
- **Build history**: Last 15 builds stored locally. Each entry: project name, filename, build time, pass/fail, log URL. Shown below the project list with colour-coded dots. Log link opens GitHub Actions run.
- **Cancellable build**: Progress dialog now has a "Cancel build" button. Tapping it sets a flag; the polling loop sends a cancel request to the GitHub Actions run and throws with "Build cancel kar di gayi".
- **Live elapsed timer**: Progress dialog shows "Elapsed: Xm Ys · Avg build ~4–8 min" updated every second.
- **Adaptive polling**: First 6 polls every 6s, then every 12s (less likely to hit rate limit on long builds).
- **Build completion notification**: When the build finishes (success or failure) while the app is open, a system notification is sent so the user can leave the screen and come back later.
- **Better success dialog**: Shows filename, build info, "Install karein" + "Build log ↗" buttons. Title clearly says "✓ APK tayyar hai".
- **Better error dialog**: Always shows a "Build logs ↗" button linking to the exact failed run.
