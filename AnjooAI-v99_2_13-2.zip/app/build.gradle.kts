plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.anjoo.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.anjoo.assistant"
        minSdk = 26
        targetSdk = 34
        // GitHub Actions sets BUILD_NUMBER (unix seconds) so every upload gets a higher versionCode than the one
        // installed, which is what lets Android install it over the old app. Local builds keep the fixed number.
        val buildNumber = System.getenv("BUILD_NUMBER")?.toIntOrNull()
        versionCode = buildNumber ?: 99231
        versionName = "99.2.13" + (System.getenv("BUILD_LABEL")?.let { " ($it)" } ?: "")
        // The GitHub repo this app updates itself from (set automatically by GitHub Actions).
        buildConfigField("String", "UPDATE_REPO", "\"" + (System.getenv("GITHUB_REPOSITORY") ?: "") + "\"")
        val hsSupabaseAnonKey = System.getenv("HS_SUPABASE_ANON_KEY") ?: "sb_publishable__HUv75xSBdu0NPQf4ijgPQ_o1VK_rRL"
        buildConfigField("String", "HS_SUPABASE_ANON_KEY", "\"" + hsSupabaseAnonKey.replace("\\", "\\\\").replace("\"", "\\\"") + "\"")
    }

    // One fixed signing key for every build. Without it each GitHub build gets a new random debug key,
    // and Android refuses to install a new version over the old one (you had to uninstall first).
    signingConfigs {
        create("anjoo") {
            storeFile = file("anjoo.keystore")
            storePassword = "anjoo123"
            keyAlias = "anjoo"
            keyPassword = "anjoo123"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("anjoo")
        }
        release {
            signingConfig = signingConfigs.getByName("anjoo")
            // R8 shrinks and obfuscates the release APK. Rules live in proguard-rules.pro.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures {
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        // Reports are produced on every CI run; they do not block a build.
        abortOnError = false
        checkReleaseBuilds = false
        htmlReport = true
        xmlReport = true
    }

    testOptions {
        unitTests {
            // Android stubs return defaults instead of throwing, so pure-Kotlin logic can be tested on the JVM.
            isReturnDefaultValues = true
        }
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    testImplementation("junit:junit:4.13.2")
    // The Android SDK's org.json is only a stub on the JVM, so tests use the real library.
    testImplementation("org.json:json:20240303")
}
