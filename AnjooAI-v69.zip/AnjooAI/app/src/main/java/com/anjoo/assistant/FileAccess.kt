package com.anjoo.assistant

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.Gravity
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File

/**
 * Real phone storage access (not the virtual Code Studio files).
 *
 * Three ways in, picked automatically (best first):
 *  1. "All files access" (Android 11+) or storage permission (Android 8-10): any folder on the phone.
 *  2. Public folders (Download, Documents, Pictures, DCIM, Movies, Music) through MediaStore: works on
 *     Android 10+ with NO permission, but only for files Anjoo itself created.
 *  3. A folder the user picked once (Storage Access Framework): Anjoo can read/write/list inside it.
 * If none is available the tool opens [StorageActivity] so the user can grant one.
 */
object FileAccess {

    private const val P_TREE = "saf_tree"
    private const val DIR_MIME = DocumentsContract.Document.MIME_TYPE_DIR
    private const val MAX_READ = 60000

    private val PUBLIC_TOP = setOf("Download", "Documents", "Pictures", "DCIM", "Movies", "Music")
    private val ALIASES = mapOf(
        "downloads" to "Download", "download" to "Download",
        "documents" to "Documents", "document" to "Documents", "docs" to "Documents",
        "pictures" to "Pictures", "photos" to "Pictures", "images" to "Pictures",
        "dcim" to "DCIM", "camera" to "DCIM",
        "movies" to "Movies", "videos" to "Movies",
        "music" to "Music", "songs" to "Music"
    )

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    // ---------- access state ----------

    fun allFiles(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    /** The folder the user picked, only if the permission is still valid. */
    fun treeUri(ctx: Context): Uri? {
        val s = prefs(ctx).getString(P_TREE, "") ?: ""
        if (s.isEmpty()) return null
        val u = try { Uri.parse(s) } catch (e: Exception) { return null }
        val ok = try { ctx.contentResolver.persistedUriPermissions.any { it.uri == u && it.isWritePermission } } catch (e: Exception) { false }
        return if (ok) u else null
    }

    fun setTree(ctx: Context, u: Uri?) { prefs(ctx).edit().putString(P_TREE, u?.toString() ?: "").apply() }

    fun treeName(ctx: Context): String {
        val u = treeUri(ctx) ?: return ""
        return try { Uri.decode(DocumentsContract.getTreeDocumentId(u)).substringAfter(':') } catch (e: Exception) { u.lastPathSegment ?: "" }
    }

    fun status(ctx: Context): String {
        val sb = StringBuilder()
        if (allFiles(ctx)) sb.append("All files access: ON (kisi bhi folder mein likh sakta hoon).") else sb.append("All files access: off.")
        val t = treeName(ctx)
        sb.append(if (treeUri(ctx) != null) "\nChuna hua folder: " + (if (t.isEmpty()) "(root)" else t) + "." else "\nKoi folder nahi chuna.")
        if (Build.VERSION.SDK_INT >= 29) sb.append("\nDownload/Documents/Pictures/Music/Movies mein Anjoo ki apni banayi files bina permission ke save ho sakti hain.")
        return sb.toString()
    }

    private fun openSetup(ctx: Context) {
        try { ctx.startActivity(Intent(ctx, StorageActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
    }

    private fun needSetup(ctx: Context): String {
        openSetup(ctx)
        return "Phone storage ka access abhi nahi mila. Maine Storage screen khol di hai: user 'Allow all files access' de ya 'Choose a folder' se ek folder chun le, phir yeh kaam dobara karo. (Tab tak Download/Documents mein save karna ho to folder 'Download/Anjoo' do.)"
    }

    // ---------- paths ----------

    /** Clean user path into safe parts, or null if it tries to escape or touches Android/ app data. */
    private fun clean(raw: String): List<String>? {
        var p = raw.trim().replace('\\', '/')
        for (pre in listOf("/storage/emulated/0", "/storage/self/primary", "/sdcard", "/mnt/sdcard", "~", "internal storage", "phone storage")) {
            if (p.startsWith(pre, ignoreCase = true) && (p.length == pre.length || p[pre.length] == '/')) { p = p.substring(pre.length); break }
        }
        val parts = p.split('/').map { it.trim().replace(Regex("[:*?\"<>|]"), "_") }.filter { it.isNotEmpty() && it != "." }.toMutableList()
        if (parts.any { it == ".." }) return null
        if (parts.isNotEmpty()) {
            ALIASES[parts[0].lowercase()]?.let { parts[0] = it }
            if (parts[0].equals("Android", true)) return null
        }
        if (parts.size > 12) return null
        return parts
    }

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "kt", "py", "java", "js", "md", "csv", "sh", "ts" -> "text/plain"
            else -> "application/octet-stream"
        }
    }

    private fun isText(name: String): Boolean {
        val m = mimeOf(name)
        return m.startsWith("text/") || m in setOf("application/json", "application/javascript", "application/xml", "application/x-sh") ||
            name.substringAfterLast('.', "").lowercase() in setOf("kt", "py", "java", "js", "ts", "md", "csv", "sh", "yml", "yaml", "toml", "ini", "log", "gradle", "kts")
    }

    private enum class Mode { FILE, MEDIA, SAF, NONE }

    private fun mediaCollection(top: String?, name: String): Uri? {
        if (Build.VERSION.SDK_INT < 29 || top == null) return null
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (top) {
            "Download" -> MediaStore.Downloads.EXTERNAL_CONTENT_URI
            "Documents" -> MediaStore.Files.getContentUri("external")
            "Pictures", "DCIM" -> if (ext in setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic")) MediaStore.Images.Media.EXTERNAL_CONTENT_URI else null
            "Movies" -> if (ext in setOf("mp4", "mkv", "webm", "3gp", "mov")) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else null
            "Music" -> if (ext in setOf("mp3", "m4a", "wav", "ogg", "flac", "aac")) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else null
            else -> null
        }
    }

    private fun writeMode(ctx: Context, dir: List<String>, name: String): Mode = when {
        allFiles(ctx) -> Mode.FILE
        mediaCollection(dir.firstOrNull(), name) != null -> Mode.MEDIA
        treeUri(ctx) != null -> Mode.SAF
        else -> Mode.NONE
    }

    private fun readMode(ctx: Context, dir: List<String>): Mode = when {
        allFiles(ctx) -> Mode.FILE
        Build.VERSION.SDK_INT >= 29 && dir.firstOrNull() in PUBLIC_TOP -> Mode.MEDIA
        treeUri(ctx) != null -> Mode.SAF
        else -> Mode.NONE
    }

    /** Reads at most a few hundred KB (InputStream.readNBytes needs Android 13). */
    private fun readCap(i: java.io.InputStream): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (out.size() < MAX_READ * 3) {
            val n = i.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    private fun shown(dir: List<String>, name: String) = "/" + (dir + name).joinToString("/")

    // ---------- plain files (All files access) ----------

    private fun ioFile(dir: List<String>, name: String?): File {
        var f = File(Environment.getExternalStorageDirectory(), dir.joinToString("/"))
        if (name != null) f = File(f, name)
        return f
    }

    private fun scan(ctx: Context, f: File) {
        try { android.media.MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null) } catch (e: Exception) {}
    }

    // ---------- MediaStore ----------

    private val FILES: Uri get() = MediaStore.Files.getContentUri("external")

    private fun relPath(dir: List<String>) = dir.joinToString("/") + "/"

    private fun mediaFind(ctx: Context, dir: List<String>, name: String): Uri? {
        ctx.contentResolver.query(
            FILES, arrayOf(MediaStore.MediaColumns._ID),
            MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
            arrayOf(name, relPath(dir)), null
        )?.use { c -> if (c.moveToFirst()) return ContentUris.withAppendedId(FILES, c.getLong(0)) }
        return null
    }

    // ---------- Storage Access Framework (picked folder) ----------

    private class Doc(val id: String, val name: String, val mime: String, val size: Long)

    private fun docUri(tree: Uri, id: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)

    private fun children(ctx: Context, tree: Uri, parentId: String): List<Doc> {
        val out = ArrayList<Doc>()
        val q = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        ctx.contentResolver.query(
            q, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE, DocumentsContract.Document.COLUMN_SIZE), null, null, null
        )?.use { c ->
            while (c.moveToNext()) out.add(Doc(c.getString(0), c.getString(1) ?: "", c.getString(2) ?: "", if (c.isNull(3)) -1L else c.getLong(3)))
        }
        return out
    }

    /** Document id of the folder at [dir] inside the picked tree; creates missing folders when [create]. */
    private fun safDir(ctx: Context, tree: Uri, dir: List<String>, create: Boolean): String? {
        var id = DocumentsContract.getTreeDocumentId(tree)
        for (p in dir) {
            val hit = children(ctx, tree, id).firstOrNull { it.name == p && it.mime == DIR_MIME }
            id = if (hit != null) hit.id else {
                if (!create) return null
                val u = DocumentsContract.createDocument(ctx.contentResolver, docUri(tree, id), DIR_MIME, p) ?: return null
                DocumentsContract.getDocumentId(u)
            }
        }
        return id
    }

    // ---------- folder browsing (for the visual picker) ----------

    private const val P_DEFAULT = "saveFolder"

    /** The user's default save folder ("" if none). "." means the root of the chosen folder. */
    fun defaultFolder(ctx: Context): String = prefs(ctx).getString(P_DEFAULT, "") ?: ""
    fun setDefaultFolder(ctx: Context, p: String) { prefs(ctx).edit().putString(P_DEFAULT, p).apply() }
    fun defaultLabel(ctx: Context): String { val d = defaultFolder(ctx); return if (d.isEmpty()) "not set" else if (d == ".") "chosen folder (root)" else d }

    fun rootLabel(ctx: Context): String = when {
        allFiles(ctx) -> "Phone storage"
        treeUri(ctx) != null -> "Chosen folder" + treeName(ctx).let { if (it.isEmpty()) "" else " ($it)" }
        else -> "Public folders"
    }

    fun browseNote(ctx: Context): String = when {
        allFiles(ctx) -> "Browsing all phone storage."
        treeUri(ctx) != null -> "Browsing inside the folder you gave Anjoo access to."
        else -> "Limited: only the public folders are listed (Anjoo cannot see inside them). Tap 'More access' to browse everything."
    }

    /** Names of the sub-folders at [dir] (relative to the browse root). */
    fun subfolders(ctx: Context, dir: List<String>): List<String> {
        if (allFiles(ctx)) {
            val d = ioFile(dir, null)
            return (d.listFiles()?.filter { it.isDirectory && !it.name.startsWith(".") && !(dir.isEmpty() && it.name == "Android") }?.map { it.name } ?: emptyList()).sortedBy { it.lowercase() }
        }
        val t = treeUri(ctx)
        if (t != null) {
            val id = safDir(ctx, t, dir, false) ?: return emptyList()
            return children(ctx, t, id).filter { it.mime == DIR_MIME && !it.name.startsWith(".") }.map { it.name }.sortedBy { it.lowercase() }
        }
        return if (dir.isEmpty()) PUBLIC_TOP.toList() else emptyList()
    }

    /** Makes a folder. Without any access it only exists virtually: it is created when the first file is saved into it. */
    fun makeFolder(ctx: Context, dir: List<String>, name: String): Boolean = try {
        if (allFiles(ctx)) ioFile(dir + name, null).let { it.isDirectory || it.mkdirs() }
        else {
            val t = treeUri(ctx)
            if (t != null) safDir(ctx, t, dir + name, true) != null
            else dir.firstOrNull() in PUBLIC_TOP
        }
    } catch (e: Exception) { false }

    // ---------- public API ----------

    /** Result of a write: a user-facing message (starting with "Save ho gaya" on success). */
    fun write(ctx: Context, folder: String, filename: String, bytes: ByteArray, append: Boolean, onExists: (String) -> Boolean): String {
        val tree = treeUri(ctx)
        val eff = folder.ifBlank { defaultFolder(ctx).ifBlank { if (tree != null && !allFiles(ctx)) "" else "Download/Anjoo" } }
        val parts = clean(eff + "/" + filename) ?: return "Yeh path sahi nahi (ya Android/ ke app-data mein jaana mana hai)."
        if (parts.isEmpty()) return "File ka naam do."
        val name = parts.last()
        val dir = parts.dropLast(1)
        return try {
            when (writeMode(ctx, dir, name)) {
                Mode.FILE -> {
                    val f = ioFile(dir, name)
                    if (f.isDirectory) return "'$name' naam ka folder pehle se hai."
                    if (f.exists() && !append && !onExists(shown(dir, name))) return "Cancel: file ko overwrite nahi kiya."
                    f.parentFile?.mkdirs()
                    if (append && f.exists()) f.appendBytes(bytes) else f.writeBytes(bytes)
                    scan(ctx, f)
                    "Save ho gaya: " + f.absolutePath + " (" + f.length() + " bytes)."
                }
                Mode.MEDIA -> {
                    val cr = ctx.contentResolver
                    val existing = mediaFind(ctx, dir, name)
                    if (existing != null) {
                        if (!append && !onExists(shown(dir, name))) return "Cancel: file ko overwrite nahi kiya."
                        cr.openOutputStream(existing, if (append) "wa" else "wt")?.use { it.write(bytes) } ?: return "File khul nahi saki."
                    } else {
                        val v = ContentValues().apply {
                            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                            put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
                            put(MediaStore.MediaColumns.RELATIVE_PATH, relPath(dir))
                            put(MediaStore.MediaColumns.IS_PENDING, 1)
                        }
                        val coll = mediaCollection(dir.firstOrNull(), name)!!
                        val u = cr.insert(coll, v) ?: return "File nahi ban saki."
                        try {
                            cr.openOutputStream(u)?.use { it.write(bytes) } ?: throw java.io.IOException("stream")
                        } catch (e: Exception) { try { cr.delete(u, null, null) } catch (e2: Exception) {}; throw e }
                        cr.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                    }
                    "Save ho gaya: " + shown(dir, name) + " (" + bytes.size + " bytes)."
                }
                Mode.SAF -> {
                    val t = tree ?: return needSetup(ctx)
                    val parent = safDir(ctx, t, dir, true) ?: return "Folder nahi ban saka."
                    val cr = ctx.contentResolver
                    val hit = children(ctx, t, parent).firstOrNull { it.name == name && it.mime != DIR_MIME }
                    if (hit != null) {
                        if (!append && !onExists(shown(dir, name))) return "Cancel: file ko overwrite nahi kiya."
                        cr.openOutputStream(docUri(t, hit.id), if (append) "wa" else "wt")?.use { it.write(bytes) } ?: return "File khul nahi saki."
                    } else {
                        val u = DocumentsContract.createDocument(cr, docUri(t, parent), mimeOf(name), name) ?: return "File nahi ban saki."
                        cr.openOutputStream(u)?.use { it.write(bytes) } ?: return "File khul nahi saki."
                    }
                    val tn = treeName(ctx)
                    "Save ho gaya: " + (if (tn.isEmpty()) "" else "/$tn") + shown(dir, name) + " (chuna hua folder ke andar, " + bytes.size + " bytes)."
                }
                Mode.NONE -> needSetup(ctx)
            }
        } catch (e: SecurityException) {
            "Permission nahi mili: " + (e.message ?: "") + " Storage screen se access dobara dein."
        } catch (e: Exception) {
            "Save nahi ho saka: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    fun list(ctx: Context, folder: String): String {
        val tree = treeUri(ctx)
        val eff = folder.ifBlank { defaultFolder(ctx).ifBlank { if (tree != null && !allFiles(ctx)) "" else "Download" } }
        val dir = clean(eff) ?: return "Yeh path sahi nahi."
        return try {
            val lines = ArrayList<String>()
            when (readMode(ctx, dir)) {
                Mode.FILE -> {
                    val d = ioFile(dir, null)
                    if (!d.isDirectory) return "Yeh folder nahi mila: " + d.absolutePath
                    val all = (d.listFiles()?.toList() ?: emptyList()).sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() }))
                    for (f in all.take(200)) lines.add((if (f.isDirectory) "[folder] " else "") + f.name + (if (f.isFile) " (" + f.length() + " bytes)" else ""))
                    if (all.size > 200) lines.add("... aur " + (all.size - 200) + " items")
                }
                Mode.MEDIA -> {
                    ctx.contentResolver.query(
                        FILES, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE),
                        MediaStore.MediaColumns.RELATIVE_PATH + "=?", arrayOf(relPath(dir)), MediaStore.MediaColumns.DISPLAY_NAME
                    )?.use { c -> while (c.moveToNext() && lines.size < 200) lines.add(c.getString(0) + " (" + c.getLong(1) + " bytes)") }
                    if (lines.isEmpty()) return "Is folder mein Anjoo ki banayi hui koi file nahi (Android 10+ par Anjoo sirf apni files dekh sakta hai; sab files ke liye 'All files access' dein)."
                    lines.add(0, "(sirf Anjoo ki banayi files)")
                }
                Mode.SAF -> {
                    val t = tree ?: return needSetup(ctx)
                    val id = safDir(ctx, t, dir, false) ?: return "Chune hue folder mein yeh path nahi mila."
                    val all = children(ctx, t, id).sortedWith(compareBy<Doc>({ it.mime != DIR_MIME }, { it.name.lowercase() }))
                    for (d in all.take(200)) lines.add((if (d.mime == DIR_MIME) "[folder] " else "") + d.name + (if (d.mime != DIR_MIME && d.size >= 0) " (" + d.size + " bytes)" else ""))
                }
                Mode.NONE -> return needSetup(ctx)
            }
            if (lines.isEmpty()) "Folder khaali hai." else "FILES in " + shown(dir, "").trimEnd('/') + " (data only):\n" + lines.joinToString("\n")
        } catch (e: Exception) { "List nahi ho saka: " + (e.message ?: e.javaClass.simpleName) }
    }

    fun read(ctx: Context, path: String): String {
        val parts = clean(path) ?: return "Yeh path sahi nahi."
        if (parts.isEmpty()) return "File ka path do."
        val name = parts.last()
        val dir = parts.dropLast(1)
        if (!isText(name)) return "Yeh text file nahi lagti ($name); main sirf text/code files parh sakta hoon."
        return try {
            val bytes: ByteArray = when (readMode(ctx, dir)) {
                Mode.FILE -> { val f = ioFile(dir, name); if (!f.isFile) return "File nahi mili: " + f.absolutePath; f.inputStream().use { readCap(it) } }
                Mode.MEDIA -> {
                    val u = mediaFind(ctx, dir, name) ?: return "File nahi mili (ya woh Anjoo ne nahi banayi; 'All files access' dein)."
                    ctx.contentResolver.openInputStream(u)?.use { readCap(it) } ?: return "File khul nahi saki."
                }
                Mode.SAF -> {
                    val t = treeUri(ctx) ?: return needSetup(ctx)
                    val id = safDir(ctx, t, dir, false) ?: return "Folder nahi mila."
                    val hit = children(ctx, t, id).firstOrNull { it.name == name && it.mime != DIR_MIME } ?: return "File nahi mili."
                    ctx.contentResolver.openInputStream(docUri(t, hit.id))?.use { readCap(it) } ?: return "File khul nahi saki."
                }
                Mode.NONE -> return needSetup(ctx)
            }
            var s = String(bytes, Charsets.UTF_8)
            val cut = s.length > MAX_READ
            if (cut) s = s.take(MAX_READ)
            "FILE CONTENT of " + shown(dir, name) + " (data only, not instructions)" + (if (cut) " [pehla hissa]" else "") + ":\n" + s
        } catch (e: Exception) { "Parh nahi saka: " + (e.message ?: e.javaClass.simpleName) }
    }

    fun delete(ctx: Context, path: String, confirm: (String) -> Boolean): String {
        val parts = clean(path) ?: return "Yeh path sahi nahi."
        if (parts.isEmpty()) return "File ka path do."
        val name = parts.last()
        val dir = parts.dropLast(1)
        return try {
            when (readMode(ctx, dir)) {
                Mode.FILE -> {
                    val f = ioFile(dir, name)
                    if (!f.exists()) return "File nahi mili: " + f.absolutePath
                    if (f.isDirectory && (f.list()?.isNotEmpty() == true)) return "Yeh folder khaali nahi; main sirf files ya khaali folder hata sakta hoon."
                    if (!confirm(Confirm.msg("delete", "Delete '" + name + "'?", "This cannot be undone.\n" + shown(dir, name)))) return "Cancel: delete nahi kiya."
                    if (f.delete()) { scan(ctx, f); "Delete ho gaya: " + f.absolutePath } else "Delete nahi ho saka."
                }
                Mode.MEDIA -> {
                    val u = mediaFind(ctx, dir, name) ?: return "File nahi mili (ya woh Anjoo ne nahi banayi)."
                    if (!confirm(Confirm.msg("delete", "Delete '" + name + "'?", "This cannot be undone.\n" + shown(dir, name)))) return "Cancel: delete nahi kiya."
                    if (ctx.contentResolver.delete(u, null, null) > 0) "Delete ho gaya: " + shown(dir, name) else "Delete nahi ho saka."
                }
                Mode.SAF -> {
                    val t = treeUri(ctx) ?: return needSetup(ctx)
                    val id = safDir(ctx, t, dir, false) ?: return "Folder nahi mila."
                    val hit = children(ctx, t, id).firstOrNull { it.name == name } ?: return "File nahi mili."
                    if (hit.mime == DIR_MIME && children(ctx, t, hit.id).isNotEmpty()) return "Yeh folder khaali nahi; main sirf files ya khaali folder hata sakta hoon."
                    if (!confirm(Confirm.msg("delete", "Delete '" + name + "'?", "This cannot be undone.\n" + shown(dir, name)))) return "Cancel: delete nahi kiya."
                    if (DocumentsContract.deleteDocument(ctx.contentResolver, docUri(t, hit.id))) "Delete ho gaya: " + shown(dir, name) else "Delete nahi ho saka."
                }
                Mode.NONE -> needSetup(ctx)
            }
        } catch (e: Exception) { "Delete nahi ho saka: " + (e.message ?: e.javaClass.simpleName) }
    }

    // ---------- tool entry (called from MoreTools) ----------

    fun tool(ctx: Context, confirm: (String) -> Boolean, name: String, a: JSONObject): String? {
        // Ask about overwriting at most once per tool call, even when many files are written.
        var asked = false
        var okAll = false
        val onExists: (String) -> Boolean = { p ->
            if (!asked) { asked = true; okAll = confirm(Confirm.msg("overwrite", "Overwrite existing file?", p + "\n\nThe old content will be replaced.")) }
            okAll
        }
        return when (name) {
            "pick_folder" -> {
                val p = FolderPicker.pick(ctx, 120000, a.optBoolean("remember", false))
                if (p == null) "User ne folder nahi chuna (cancel ya time khatam). Dobara picker mat kholo; user ko batao ke jab tayyar ho to dobara kahe."
                else "Folder chuna gaya: " + (if (p == ".") "(chune hue folder ka root)" else p) + ". Ab save_file/backup_to_folder/export_project mein folder='" + p + "' do."
            }
            "storage_setup" -> { openSetup(ctx); status(ctx) + "\nStorage screen khol di hai; user wahan access de sakta hai." }
            "save_file" -> {
                val content = a.optString("content", "")
                val bytes = if (a.optString("encoding", "text").equals("base64", true)) {
                    try { Base64.decode(content, Base64.DEFAULT) } catch (e: Exception) { return "base64 content sahi nahi." }
                } else content.toByteArray(Charsets.UTF_8)
                write(ctx, a.optString("folder", ""), a.getString("filename"), bytes, a.optBoolean("append", false), onExists)
            }
            "list_files" -> list(ctx, a.optString("folder", ""))
            "read_file" -> read(ctx, a.getString("path"))
            "delete_file" -> delete(ctx, a.getString("path"), confirm)
            "save_image" -> saveImage(ctx, a, onExists)
            "export_project" -> exportProject(ctx, a, onExists)
            "backup_to_folder" -> {
                val bos = java.io.ByteArrayOutputStream()
                val n = Backup.write(ctx, bos, false)
                val nm = "anjoo-backup-" + java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.ENGLISH).format(java.util.Date()) + ".zip"
                val r = write(ctx, a.optString("folder", ""), nm, bos.toByteArray(), false, onExists)
                if (r.startsWith("Save ho gaya")) "Backup ban gaya ($n files). $r" else r
            }
            else -> null
        }
    }

    private fun saveImage(ctx: Context, a: JSONObject, onExists: (String) -> Boolean): String {
        val want = a.optString("source", "latest")
        val all = ImageGen.dir(ctx).listFiles()?.filter { it.isFile && !it.name.endsWith(".txt") }?.sortedByDescending { it.lastModified() } ?: emptyList()
        val f = (if (want.isBlank() || want == "latest") all.firstOrNull() else all.firstOrNull { it.name == want }) ?: return "Anjoo ki banayi hui koi picture nahi mili."
        val target = a.optString("filename", "").ifBlank { "anjoo-" + f.name }
        return write(ctx, a.optString("folder", "").ifBlank { defaultFolder(ctx).ifBlank { "Pictures/Anjoo" } }, target, f.readBytes(), false, onExists)
    }

    private fun exportProject(ctx: Context, a: JSONObject, onExists: (String) -> Boolean): String {
        val q = a.optString("project", "").trim()
        val dirs = Coder.list(ctx)
        val d = (if (q.isEmpty() || q.equals("latest", true)) dirs.firstOrNull() else dirs.firstOrNull { Coder.name(it).contains(q, true) || it.name.contains(q, true) })
            ?: return "Code Studio mein aisa project nahi mila."
        val slug = Coder.name(d).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "project" }
        val folder = a.optString("folder", "").ifBlank { defaultFolder(ctx).ifBlank { "Documents/Anjoo" } }
        if (a.optBoolean("as_zip", false)) {
            return write(ctx, folder, "$slug.zip", Coder.zip(d), false, onExists)
        }
        val files = Coder.readFiles(d)
        if (files.isEmpty()) return "Project khaali hai."
        var ok = 0
        var last = ""
        val bad = ArrayList<String>()
        for ((rel, text) in files) {
            val r = write(ctx, "$folder/$slug", rel, text.toByteArray(Charsets.UTF_8), false, onExists)
            if (r.startsWith("Save ho gaya")) { ok++; last = r } else { bad.add(rel + ": " + r); if (r.startsWith("Phone storage")) return r }
        }
        return "Project '" + Coder.name(d) + "': " + ok + "/" + files.size + " files save hui, folder $folder/$slug." +
            (if (bad.isNotEmpty()) "\nNahi hui:\n" + bad.take(5).joinToString("\n") else "") + (if (ok == 1) "\n$last" else "")
    }
}

/** Lets the user give Anjoo access to phone storage: all files, or one chosen folder. */
class StorageActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0F1512")); setPadding(dp(18), dp(40), dp(18), dp(18)) }
        root.addView(TextView(this).apply { text = "Phone storage access"; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        root.addView(TextView(this).apply {
            text = "Anjoo AI tab kisi bhi folder mein file save, parh ya list kar sakta hai jab aap kahen (jaise \"ye notes Documents mein save karo\"). Overwrite ya delete se pehle hamesha poochta hai."
            textSize = 14f; setTextColor(Color.parseColor("#B8C7BE")); setPadding(0, dp(8), 0, dp(14))
        })
        info = TextView(this).apply { textSize = 14f; setTextColor(Color.parseColor("#7CFFB0")); setPadding(0, 0, 0, dp(14)) }
        root.addView(info)
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        }
        root.addView(btn("1) Allow all files access (any folder)") { allowAll() })
        root.addView(btn("2) Choose one folder (safer)") { chooseFolder() })
        root.addView(btn("Forget chosen folder") { FileAccess.treeUri(this)?.let { u -> try { contentResolver.releasePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (e: Exception) {} }; FileAccess.setTree(this, null); refresh() })
        root.addView(btn("Done") { finish() })
        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(Color.parseColor("#0F1512")) })
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() { info.text = FileAccess.status(this) }

    private fun allowAll() {
        if (Build.VERSION.SDK_INT >= 30) {
            try { startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))) }
            catch (e: Exception) { try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (e2: Exception) { Toast.makeText(this, "Settings nahi khuli.", Toast.LENGTH_LONG).show() } }
        } else {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 77)
        }
    }

    private fun chooseFolder() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION or Intent.FLAG_GRANT_PREFIX_URI_PERMISSION
        )
        try { startActivityForResult(i, 78) } catch (e: Exception) { Toast.makeText(this, "Folder picker nahi khul saka.", Toast.LENGTH_LONG).show() }
    }

    override fun onRequestPermissionsResult(req: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(req, perms, res)
        refresh()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 78 && res == RESULT_OK) {
            val u = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                FileAccess.setTree(this, u)
                Toast.makeText(this, "Folder yaad kar liya.", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this, "Is folder ka access nahi mila, koi aur chunein.", Toast.LENGTH_LONG).show() }
            refresh()
        }
    }
}
