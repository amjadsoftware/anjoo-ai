# Anjoo AI: Android awaazi assistant

Mic dabayein aur bolein. Gemini hukm samajhta hai aur phone par kaam karta hai.

## Kya kar sakta hai
- Koi bhi installed app kholna ("WhatsApp kholo", "YouTube kholo")
- Contacts se naam dhoond kar call karna (call se pehle "Haan/Nahi" poochta hai)
- SMS bhejna (bhejne se pehle poochta hai)
- WhatsApp chat kholna aur paigham likh dena (send ka button aap dabate hain)
- Alarm aur timer lagana
- Web search, website kholna, Maps mein rasta
- Jawab awaaz mein bhi sunata hai (agar phone mein Urdu/English voice maujood ho)

## Jo nahi kar sakta
- Doosri apps ke andar khud tap karna (jaise bank app mein paise bhejna). Yeh jaan boojh kar nahi rakha.
- WhatsApp ka paigham khud send karna. Android is ki ijazat nahi deta, aap ko ek tap karna hota hai.

## Banane ke qadam (pehli baar)
1. Computer par Android Studio install karein (developer.android.com/studio).
2. Android Studio mein File > Open, aur is `AnjooAI` folder ko kholein. Gradle sync poora hone dein (internet chahiye, pehli baar kuch minute lagte hain).
3. Phone mein Settings > About phone > Build number par 7 baar tap karein, phir Developer options mein USB debugging on karein.
4. Phone ko USB se jorain, Android Studio mein upar ka hara Run button dabayein. App phone par install ho jayegi.
   (Ya Build > Build APK(s) se APK bana kar phone mein copy karke install karein.)

## Pehli dafa istemal
1. App kholte hi Settings aayegi. Apni Gemini API key dalein: aistudio.google.com/apikey par apne Google account se "Create API key" dabayein. Model "gemini-3.8-flash" rakhein (ya wahan ki list se jo naam dikhe).
2. Mic, contacts, call aur SMS ki ijazat "Allow" karein.
3. Mic dabayein aur bolein: "Ahmed ko call karo", "Subah 6 baje ka alarm lagao", "WhatsApp kholo".
   Zubaan ka button "اردو / English" bolne ki zubaan badalta hai.

## Zaroori baatein
- Gemini Pro subscription aur API key do alag cheezein hain. Key AI Studio se banti hai, us par free limit hoti hai aur us se zyada istemal par kharcha ho sakta hai. Key kisi ko na dein; yeh sirf aap ke phone mein rehti hai.
- WhatsApp ke liye "0300..." wale number Pakistan ke code (92) mein badal diye jate hain.
- Awaaz pehchaan Google ki service use karti hai, is liye internet aur Google app chahiye.
- Pehle kuch din call/SMS ki tasdeeq wali screen par nazar rakhein ke naam aur number sahi hain.

## v12 naye kaam
- Naya Anjoo AI app icon (robot + neon circuit).
- Markhor hata diya: ab ek cute robot (Buddy) screen par ghoomta hai, aapki baat par chehre ke expressions badalta hai (khush, pyar, udaas, hairan, soch, sunna, neend).
- Mouse jaisa arrow (cursor): jab Anjoo koi kaam kare (tap, likhna, back/home, scroll, app kholna) to arrow dusri apps ke upar bhi dikhta hai ke kahan ja raha hai. Iske liye Accessibility on honi chahiye.
- Awaaz pehchan behtar aur tez: jumla 0.7 sec khamoshi par poora, jawab ki awaz pehle jumle se shuru, Anjoo soch raha ho tab bhi aapki nayi baat sunta hai, aur samajhne par chhoti beep aati hai.

## v14 Code Studio (Claude jaisi coding)
- Menu > "Code Studio": likhein ya bolein kya banana hai. Pehle architecture plan, phir poora multi-file project (README aur dependency file samet), phir bug review.
- Project ke har file ka tab: dekhein, Copy, Share, haath se Edit/Save.
- Badlav: "dark mode lagao", "login add karo" likhein, sirf zaroori files badalti hain. Ask: koi bhi code ya bug ka sawal, project dekh kar jawab.
- Web projects ke liye Run (live preview), Zip se poora project save.
- Awaaz se: "Anjoo, ek calculator app banao" (write_code) ya "isme history add karo" (edit_code).

## v15 Professional chat app
- Boot lines ("loading...") aur screen par ghoomta robot hata diya. Ab saaf chat screen hai; robot sirf chhote avatar ki tarah header mein (expressions ke saath) aur khali screen par.
- Header: history, avatar, naam + model, naya chat, menu. Khali chat par suggestions (Claude/ChatGPT/Gemini jaisa).
- Jawab Markdown mein: headings, lists, bold, code blocks (Copy ke saath), links. Har jawab ke neeche Copy, Listen, Share, Retry.
- Think (DeepSeek jaisa gehri soch, "Thought process" dikhta hai) aur Web (Google Search se taaza maloomat + sources) chips.
- "+" se Photo, Camera, PDF/text/code file attach (Kimi jaisa lambi file parhna).
- Custom instructions (ChatGPT jaisa), Code Studio, Live voice (mic button), phone control sab isi app mein.
- Settings grouped: Voice and language, Phone control, Appearance, Backup, API key.

## v16 Coding aur Thinking advanced
- Chat mein code likhwayein to jawab ke code block par Code | Preview tabs aate hain (HTML/SVG ka live preview usi chat mein), saath Full screen, Studio, Copy.
- Code Studio ki chat mein har project ka card: files, code viewer, live Preview aur Edit, sab usi chat ke andar.
- Deep think (Code Studio mein ON/OFF): pehle gehra analysis (requirements, edge cases, test scenarios), phir code, phir 2 round review/test. "Thought process" dekh sakte hain.
- Main chat ka Think chip ab advanced level (high thinking) par chalta hai.

## v31 naya icon, opening scene, image generation, behtar coding
- Naya icon: koi harf nahi, ek roshan "spark" aur ghoomta hua orbit ring (gradient background). Android 13+ par themed icon bhi.
- App khulte hi chhoti film jaisi scene: raat ka aasman, taare, aurora, ubharta hua orb, shooting star, jugnu, aur beech mein Anjoo spark. Tap karein to foran skip.
- Chat mein image banana: "Image" chip dabayein ya seedha likhein/bolein "ek sheer ki tasveer banao". Picture chat mein aati hai; tap par full screen, Save (Pictures/AnjooAI), Share, Edit (photo bhej kar "isko cartoon bana do" bhi chalta hai). Model: gemini-2.5-flash-image (agar aapke account par na ho to khud doosre model par chala jata hai).
- Coding: ab har web project banne ke baad chhupe hue browser mein khud chalta hai; JavaScript errors, missing files ya khali page mile to Anjoo khud theek karta hai (2 round). Naye rules: behtar UI design, games, tests, scripts, backend.

## Naye AI providers (v34)
Settings mein ab teen cheezein chunni hoti hain: **AI** (Google Gemini free by default, OpenAI, Claude, OpenRouter, Groq, DeepSeek, Mistral, xAI, ya Custom URL), phir **Model** (list se tap karke, ya "Load all models" se poori list), phir us ki **API key**. Har provider ki key alag save hoti hai.
Voice typing, Gemini voice aur picture banana hamesha Google Gemini key se chalte hain, chahe chat kisi aur AI se ho.

## v38 Claude jaisa interface, Thinking aur Commands summary
- **Look:** naye themes "Claude Light" (garam cream + terracotta) aur "Claude Dark". Pehli dafa phone ke dark/light mode ke mutabiq khud lag jate hain; Menu > Appearance se badal sakte hain (purane themes bhi maujood hain). Jawab serif font mein, bubble ke baghair, har jawab ke neeche ✦ ke saath Copy/Listen/Share/Retry. Composer gol card jaisa, khali screen par waqt ke mutabiq salam.
- **Thinking:** jawab se pehle live card: "✦ Thinking… 4s" aur model ki soch ka khulasa. Jawab shuru hote hi yeh "Thought for 4s ›" ban jata hai, tap karke poori soch dekhein. Ab har sawal par aata hai (pehle sirf Think chip par).
- **Commands summary:** jo bhi phone ka kaam Anjoo karta hai (app kholna, alarm, call, SMS, search...) woh live list mein dikhta hai: `… chal raha hai`, `✓ ho gaya`, `! masla`, `✕ nakam`. Jawab ke upar "⌘ Ran 2 commands ›" ke neeche ek line ka khulasa; tap karein to har command aur uska natija. Yeh chat history mein bhi save rehta hai.
- Menu > "Show thinking and commands" se yeh dono band/on kar sakte hain.
- Anjoo ab commands dohrata nahi: sirf ek chhota sachcha jumla batata hai ke kya hua aur kya nahi.

## v39 Sharmila robot
- Screen par ghoomne wala robot ab touch se bhagta hai: robot ko chhuen to ek qadam peechay hop karke hat jata hai, uske bagal mein tap karen to touch se door tez bhag jata hai. Kone mein phans jaye to doosri taraf nikal jata hai. Robot ko ungli se ghaseet kar kahin bhi rakh sakte hain (pehle jaisa).

## v40 Movie jaisa opening (Splash), v69 mein sirf flash + logo
App khulte hi ~3.2 sec ki chhoti film (tap karein to foran skip):
1. **Background:** gehra nebula aasman, taare aur shooting stars.
2. **Flash:** foran safed flash (Symbiotes, Venom aur fight scene hata diye gaye hain).
3. **Logo:** har rang ki shockwaves, background warm hota hai aur Anjoo logo (shakal wahi jo app icon ki hai, rang Claude orange) rays, orbit rings, lens flare aur sparks ke saath ubharta hai. Haptic jhatka bhi aata hai.

## v41 Image upgrade: padhna, text parhna, banana
- **Photo ke quick buttons:** photo lagate hi 📝 Read text, 🔍 Describe, 🌐 Translate, 🧮 Solve, ✏️ Edit ke buttons aate hain. PDF par Summary / Read text / Translate.
- **Text parhna (OCR):** chip "📝 Read text" ya menu se photo chunein. Urdu, Arabic, English, haath ka likha, tables, receipts, screenshots. Text jaisa likha hai waisa hi aata hai (translate/summary ke bina), neeche Copy aur "Translate / Summarize / Fix spelling" ke suggestions.
- **Ek se zyada photos:** gallery se 4 tak photos ek saath (compare, ya kai pages ka text). Photo ki quality OCR ke liye behtar (1800px).
- **Photo par follow-up:** pehle agla sawal aate hi photo bhool jati thi. Ab "ab isko English mein karo" jaise sawal chalte hain. Retry bhi photo ke saath chalta hai.
- **Dusri apps se Share:** Gallery, WhatsApp, Chrome se photo/PDF/text "Share" > Anjoo AI. Seedha chat mein aa jata hai.
- **Image banana:** 🎨 Image chip dabane par Style (Realistic, Anime, 3D, Logo, Oil painting, Cinematic...), Size (1:1, 16:9, 9:16...) aur Versions (1 se 3 ek saath) ke chips. Awaaz ya chat mein "teen options banao" bhi chalta hai.
- **Banai hui picture par:** Save, Share, Edit, **Another** (naya version, usi idea se) aur **More** (background hatao, cartoon, anime, oil painting, black and white, cinematic, HD/sharper, sticker).
- **Zoom viewer:** picture par tap karein: pinch se zoom, double-tap se zoom in/out, ungli se khiskayein, Save/Share neeche.
- Gemini key chahiye (image padhna aur banana dono Google Gemini se). Pehle build ke baad phone par test zaroor karein: yeh badlav is machine par compile nahi kiye ja sake (Android SDK nahi tha).

## v41 WhatsApp ki bheji hui picture kholo aur parho
Bolein ya likhein: "Ahmed ne WhatsApp par jo image bheji hai wo kholo aur parho". Anjoo ye karta hai: WhatsApp kholna, Ahmed ka chat kholna, sabse nayi picture kholna (`tap_image`), phir screen ki picture le kar Gemini se parhwana (`look_at_screen`): picture ka text (Urdu/English/Arabic) aur usmein kya hai.
- Zaroori: Accessibility on honi chahiye. Naye version ke baad **ek dafa Accessibility band karke dobara on karein**, warna screenshot ki nayi ijazat nahi milti.
- Android 11 ya naya chahiye. Gemini key chahiye.
- Agar chat ya picture na mile to Anjoo saaf bata deta hai. Picture ke andar likhi hidayat ko hukm nahi samjha jata.

## v41 "Jo bolo wo karo" (full control)
- Anjoo ab kabhi nahi kehta "tool nahi hai". Har hukm ko steps mein todta hai aur ek tareeqa na chale to doosra ajmata hai (25 steps tak ek hukm mein).
- Naye tools: `list_screen` (screen par kya hai aur kahan), `tap_xy` (kisi bhi point par tap/long press), `swipe`, `wait`, aur keys: lock, screenshot, quick_settings, power_menu. `tap_text` ab text ke paas clickable na ho to us jagah touch karta hai.
- Menu > "⚡ Do it without asking (call, SMS, replies)" on karein to call/SMS/reply bina Yes/No ke seedha ho jate hain. Default off hai (galat naam sunne par galat call se bachne ke liye).
- Hadd: bank/payment apps ya FLAG_SECURE wali screens Android screenshot/touch rok sakta hai; password/OTP daalna Anjoo apni taraf se nahi karta.

## v41 Bank, wallet aur card se door (Guard)
- Anjoo bank/wallet apps (JazzCash, Easypaisa, HBL, UBL, Meezan, SadaPay, NayaPay, PayPal, Google Pay, STC Pay, Al Rajhi waghera) ke andar na parhta hai, na dabata hai, na screenshot leta hai. App kholna theek hai.
- Card number, CVV, PIN, OTP, expiry, password: na parhta, na copy/likhta, na bhejta, na yaad rakhta. Screen, SMS, notifications aur screenshot ke natije mein yeh `[hidden]` ho jate hain; aap ki likhi/boli hui baat mein card number AI ko jane se pehle chhupa diya jata hai.
- Sirf **account number / IBAN**: aap bolein "mera account number 0123456789 copy karo" ya "paste karo" to copy_text/type_text se ho jata hai (bank app ke text box mein bhi likh deta hai, lekin us app mein aur kuch nahi dabata).
- Code: `Guard.kt`.

## v42 Coding: Claude jaisa dikhana, tez edit, behtar check
- **Rang-birangi code (syntax highlighting):** chat ke code blocks, Code Studio ki files aur project card, sab mein keywords, strings, comments, numbers, functions, HTML tags aur CSS alag rang mein, line numbers ke saath. Har block par "kotlin · 42 lines" jaisi detail. 60,000 se bade code mein rang band ho jate hain taake app smooth rahe.
- **Live code dikhna:** jab Anjoo project likh raha hota hai to working card mein asli code (aakhri 10 lines, rang ke saath) saath saath chalta dikhta hai, kaunsi file ban chuki hai (✓) aur kaunsi likhi ja rahi hai, aur kitne seconds se kaam chal raha hai.
- **■ Stop button:** kaam ke dauran ➤ button ■ ban jata hai. Dabate hi screen foran free; background kaam agle step par ruk jata hai (naya model call nahi hota, aur roka hua jawab project par lagta nahi).
- **Tez edits (EDIT blocks):** project badalte waqt model ab poori file dobara nahi likhta, sirf SEARCH/REPLACE tukde likhta hai (Claude Code jaisa). Kam intezar, kam kharcha. Agar koi tukda file se match na kare to sirf wahi files poori dobara likhi jati hain.
- **Behtar auto-check (lint):** bracket ( [ { ka sahi jora (strings aur comments ko chhod kar), HTML ke duplicate id, JavaScript jo aisi id dhoondta hai jo HTML mein hai hi nahi, inline scripts ki jaanch, Python mein tab aur space ki milawat. Yeh nataij reviewer ko haqeeqat ki tarah diye jate hain.
- **Tez build:** Deep think OFF ho aur local check saaf aaye to model review ka extra round chhod diya jata hai.
- **Behtar prompts:** pehle asal maqsad samajhna, sawal poochne ki bajaye samajhdar defaults, poora kaam (empty state, keyboard, error messages) magar bila-zaroorat extras nahi. Har jawab ke aakhir mein "Next:" ke 2 mashware. Ask mode mein pehle seedha jawab, phir wajah, phir theek kiya hua code (file ka naam ke saath).
- Naye/badle files: `Hl.kt` (naya), `Md.kt`, `CodeActivity.kt`, `Coder.kt`.
- **Zaroori:** yeh badlav is machine par compile nahi kiye ja sake (Android SDK/Kotlin compiler nahi tha). Pehle Android Studio mein build karke test karein; agar koi compile error aaye to error ki line bhej dein, foran theek kar dunga.


## v44: Backup mein ab sab kuch (Export / Import)
- Export ab ek **.zip** file banata hai: settings, yaadein, diary, saari chats, **Code Studio ke projects aur unki chat**, chat ke cards ki copy, purane pages/code, Anjoo ki banai hui images, aur chat mein lagayi hui **files (PDF, code, ZIP, photos)**.
- Import purani `.json` backup aur nayi `.zip` dono kholta hai.
- Chat mein ab **ZIP file** bhi attach ho sakti hai: Anjoo uske andar ki text/code files parhta hai (node_modules, .git, binary wagaira chhor deta hai).
- Chat mein lagayi hui file ab chat ke saath save rehti hai; purani chat kholne par "📎 file" par tap karke dobara attach kar sakte hain.

## v45: Prompt aur Coding ki taqat, Python
- **Prompt Maker**: chat mein bolein "is ka prompt bana do" (ChatGPT/Claude/Gemini/image/video/coding). Anjoo Role, Context, Task, Constraints, Output format wala tayyar prompt banata hai. Code Studio mein input ke saath **✨** button: chhoti si baat ko poore engineering brief mein badal deta hai (bhejne se pehle edit kar sakte hain).
- **Coder ke rules behtar**: Python ke liye (bina keyboard input ke chalne wala, demo data, main() guard) aur testability ke naye rules.
- **Python app ke andar chalta hai** (Pyodide, WebView mein, koi install nahi; pehli baar ~10MB download, internet chahiye):
  - Code Studio > ⋮ menu > **🐍 Run Python**: output ya error dikhata hai, error par **Fix with AI**.
  - Chat ke har ```python code block par **▶ Run** button.
  - Coder khud Python project chala kar error milne par theek karta hai (jaise web projects ke liye pehle se tha).
  - Anjoo ka naya tool **run_python**: hisaab, data/text processing, regex, algorithm ki jaanch asal mein chala kar jawab deta hai.
  - tkinter, pygame, Flask/Django, socket jaisi cheezein yahan nahi chalti; unka sirf syntax check hota hai.

## v46: Do mode wali shakhsiyat (Companion / Workhorse)
- `Style.FRIEND` ab ek adaptive prompt hai jo khud mode badalta hai: **Companion** (baat-cheet, jazbaat, mazaaq: garam, witty, insani) aur **Workhorse** (code, debugging, tools, analysis, business writing: seedha, durust, bina fuzool baat ke).
- Mix baat par: pehle 1 chhoti witty/caring line, phir poora Workhorse jawab.
- Sakht rules: code/files/prompt outputs mein mazaaq ya roleplay nahi; code mein TODO ya "..." nahi, hamesha poori chalne wali files; durustgi charm se upar.
- Pehle wale safety rules (bina hukm koi kaam nahi, nateeja verify karke batana, yaad sirf kehne par) barqarar hain. Ye prompt chat aur voice dono mein lagta hai.

## v47: Code Studio attach, ZIP import, auto-backup, history search, CI
- **Code Studio mein 📎**: "Attach a file" (code, text ya ZIP ka andar ka text) aap ke agle message ke saath Anjoo ko milta hai. "Open a ZIP as a new project" kisi bhi zip ko naya project bana deta hai (binary files, node_modules, .git chhor kar), phir edit/ask/run kar sakte hain.
- **Auto-backup**: har 3 din baad khud backup `Downloads/AnjooAI/anjoo-auto-*.zip` mein (API key ke bagair), aakhri 3 rakhe jate hain. Menu > Backup and restore mein on/off.
- **Chat history search** ab sirf title nahi, chat ke andar ke lafz bhi dhoondta hai (kam az kam 2 harf).
- **GitHub Actions**: `.github/workflows/build.yml` har push par Debug APK banata hai aur khali/ghayab APK par fail karta hai.
- versionCode 47.

## v48: Agent features (Hermes jaisa kaam, mobile par)
- **Tasks / Kanban**: Menu > "Tasks (Kanban board)": To do, Doing, Done. Card dabayein: move, edit, delete, ya "Ask Anjoo to do it" (Anjoo background mein kaam karke natija card par likh deta hai). Awaaz/chat se: "task add karo ...", "ye task done karo", "tasks dikhao".
- **Schedule (khud chalne wale kaam)**: "roz subah 8 baje tech news ka khulasa bhejo", "30 minute baad ye price check karo". Waqt par Anjoo agent chalata hai, natija notification (aur Telegram) mein aata hai, aur board par card banta hai. (Sirf yaad dilana ho to purana reminder.)
- **Sub-agents**: delegate_task: researcher (Google Search + sources), coder, planner, writer, analyst. Lambi tehqeeq/likhai/planning akela mahir karke natija deta hai.
- **Browser agent**: app ke andar asli browser (BrowserActivity) jo Anjoo chalata hai: browser_open, read, click, type, scroll, back, close. Aap dekh sakte hain, khud sign-in kar sakte hain. Anjoo password/card/OTP fields mein kabhi nahi likhta; bank/payment/wallet pages par nahi jata; page ka matn untrusted data maana jata hai.
- **Telegram control**: Menu > "Telegram control": @BotFather se apna bot banayein, token paste karein, bot ko `/pair CODE` bhejein. Phir sirf aap ka chat Anjoo ko hukm de sakta hai (agent ke saare tools: browser, tasks, schedule, sub-agents, phone control). Call, SMS aur message-reply Telegram se kabhi nahi hote. Commands: /tasks, /new, /unpair, /help. Token backup mein tab hi jata hai jab "Include key" chunein.
- Naye permission: FOREGROUND_SERVICE_DATA_SYNC (Telegram ki background service ke liye).
- Limits: Android kuch phones par background services band kar deta hai (battery "Unrestricted" karein). Har Telegram message / scheduled job / browser step API calls istemal karta hai.

## v49: Scroll / jhatke (lag) ka fix
- Chat mein jawab likhte waqt har update `fullScroll` se screen ko neeche kheench leta tha (aur keyboard focus bhi chheenta tha): isi se drag karte ya option chunte waqt jhatka lagta tha. Ab `SmartScroll`: ungli screen par ho ya abhi uthi ho to kuch nahi karta; sirf tab neeche follow karta hai jab aap pehle se neeche ke qareeb hon. Apna naya message ya chat kholne par seedha neeche jata hai. Main chat aur Code Studio dono mein.
- Robot (Buddy) ka animation ab 30 frames/sec hai (neend mein 15), aur jab chhupa ho (doosri screen, khali-screen wala avatar, app peeche) to draw nahi karta.

## Awaaz (Urdu + English) behtar banai gayi (v51)
- Jawab bolte waqt Urdu hissa Urdu awaaz mein aur English hissa English awaaz mein bola jata hai (VoiceKit.kt).
- Jawab se pehle star, emoji, links aur code saaf kar diye jate hain, taake "star star" na bola jaye.
- Bolte waqt music/video ki awaaz kam ho jati hai.
- Speech language ab teen tarah ki hai: Urdu, English, aur Urdu + English (auto), jis mein ek hi jumle mein dono zubanein mix ho sakti hain.
- Google recogniser: dono zubanein samajhta hai, behtareen jumla chunta hai, aur sunte waqt notification mein lafz dikhata hai.

## Routine aur aadat engine (v52)
- Anjoo ab yaad rakhta hai ke aap kaun sa kaam kis waqt karte hain (mausam, khabrein, apps, namaz, tasks, calendar, music, raasta, call). Ye sab sirf is phone par rehta hai (Habits.kt).
- Jab koi kaam 3 alag dinon mein lagbhag ek hi waqt par ho, to usi waqt Anjoo mashwara deta hai: notification mein "Haan, karo / Baad mein / Dobara nahi", aur app ki khali screen par "For you" mein.
- Khud ki ba khud suggestions: roz subah mausam/khabrein dekhne walon ko daily briefing, namaz auqaat dekhne walon ko namaz reminders, due ya baqi tasks, agli namaz se pehle yaad dihani, aur do kaam jo aksar saath hon unhein routine banana.
- Hadd: roz zyada se zyada 3 notifications, raat 10 se subah 7 tak koi nahi. Menu mein "Proactive suggestions" on/off aur "What Anjoo has learned" (dekhna, notifications band karna, sab bhula dena).

## v53 Offline mode (internet ke baghair bhi kaam)
Android app mein browser wale LocalStorage / IndexedDB nahi hote; unka sahi Android jawab yeh hai: chhoti cheezein (tasks, reminders, chats) pehle se **SharedPreferences / app files** mein hain, aur ab **notes aur "baad mein bhejo" queue** ek asli **SQLite database** (`LocalDb.kt`) mein hain. Sab kuch phone par, net ke baghair.
- **Notes** (Menu > "Notes"): likhein, edit, pin, search, share, delete. Anjoo se bhi: "note: kal doodh lana", "notes dikhao", "note 2 delete". AI ke naye tools: add_note, list_notes, read_note, delete_note. Notes backup (zip aur json) mein bhi jate hain; restore mein merge hota hai (naya edit jeetta hai), purane notes mitte nahi.
- **Offline banner**: net na ho to chat ke upar "📴 Offline" aata hai (kitne messages intezar mein hain bhi dikhata hai).
- **Offline commands** (bina AI ke, `OfflineBrain` in `Offline.kt`): notes, tasks ("task add: ...", "tasks dikhao", "task 3 done"), yaad dihani ("10 minute baad yaad dilao chai", "shaam 6 baje yaad dilao ..."), alarm, timer, torch, volume, battery, app kholna, waqt/tareekh, calculator ("2*(3+4)"). "help" likhein to list aati hai. Sirf saaf hukm par kaam hota hai.
- **AI wale sawal** jab net na ho: save ho jate hain (Outbox). Net wapas aane par Anjoo **pooch kar** bhejta hai ("Send now / Later / Discard"), ek ke baad ek, aur har message ke saath "[Saved offline at ...]" likha hota hai taake purana waqt pata rahe. Koi purana hukm (call, SMS...) khud se nahi chalta. Agar net ek request ke beech mein toot jaye to bhi message save ho jata hai.
- **Photo/file** bhejne ke liye net chahiye (offline mein bataya jata hai).
- **Doosre phone se sync (bina server)**: Notes screen > ⋮ > "Save sync file" (notes + tasks ki ek chhoti .json file), file doosre phone par bhej kar "Merge from file". Har note ka naya edit rakha jata hai, hataye hue notes wapas nahi aate, tasks sirf naye jode jate hain. (Cloud sync nahi hai; woh server ke baghair mumkin nahi.)
- Naya permission: ACCESS_NETWORK_STATE. versionCode 53.
- **Zaroori:** yeh badlav is machine par compile nahi kiye ja sake (Android SDK nahi). Sirf Kotlin syntax check hua aur parsing wale hisse (calculator, waqt, durations) alag se test hue. Pehle Android Studio / GitHub Actions se build karke phone par test karein.

## Phone Storage Access (naya)
Assistant ab phone ke asal folders mein files save/list/read/delete kar sakta hai (sirf Code Studio ki virtual files nahi).
- Tools: `save_file`, `list_files`, `read_file`, `delete_file`, `save_image`, `export_project`, `storage_setup`
- Setup: Menu > Phone > "Phone storage" (All files access ya ek folder chunein). Download/Documents/Pictures mein Anjoo ki apni files Android 10+ par bina permission ke bhi save hoti hain.
- Overwrite aur delete se pehle hamesha tasdeeq poochta hai; card/OTP jaisa data file mein likhna block hai.
