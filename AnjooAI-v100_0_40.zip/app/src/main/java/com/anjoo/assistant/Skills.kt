package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Android side of the Skills system: installs the bundled pack, routes each request to the skills that apply, gives the model their
 * complete instructions, runs the skill tools (skill_find / skill_read / skill_files / skill_run / skill_verify) and keeps the history.
 * The logic lives in SkillCore (pure) and SkillStore (files + registry); both are unit-tested.
 */
object Skills {
    const val PREF_AUTO = "skillsAuto"
    private const val PREF_PACK = "skillsPackSha"
    private const val PREF_REMOVED = "skillsRemovedBuiltin"
    val TOOL_NAMES = setOf("skill_find", "skill_read", "skill_files", "skill_run", "skill_verify")

    @Volatile private var storeRef: SkillStore? = null
    private val installLock = Any()

    fun store(ctx: Context): SkillStore {
        storeRef?.let { return it }
        synchronized(this) {
            storeRef?.let { return it }
            return SkillStore(File(ctx.applicationContext.filesDir, "skills")).also { storeRef = it }
        }
    }

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    fun autoOn(ctx: Context) = prefs(ctx).getBoolean(PREF_AUTO, true)
    fun setAuto(ctx: Context, on: Boolean) { prefs(ctx).edit().putBoolean(PREF_AUTO, on).apply() }

    // ───────────── installation ─────────────

    /** Installs the bundled pack the first time and whenever the app ships a different pack. Returns a report when something was installed. */
    fun ensureBuiltIn(ctx: Context): String? = synchronized(installLock) {
        val app = ctx.applicationContext
        val st = store(app)
        val shipped = try { app.assets.open("skills_pack.zip.sha256").bufferedReader().readText().trim().substringBefore(' ') } catch (e: Exception) { return null }
        if (prefs(app).getString(PREF_PACK, "") == shipped && st.list().isNotEmpty()) return null
        val bytes = try { app.assets.open("skills_pack.zip").use { it.readBytes() } } catch (e: Exception) { st.log("install", "", "failed", "bundled pack missing: " + e.message); return "The bundled skills pack is missing from the app." }
        if (SkillCore.sha256(bytes) != shipped) { st.log("install", "", "failed", "bundled pack checksum mismatch"); return "The bundled skills pack failed its integrity check and was not installed." }
        val rep = st.importZip(bytes.inputStream(), "bundled", true, app.cacheDir)
        val removed = prefs(app).getStringSet(PREF_REMOVED, emptySet()).orEmpty()
        for (id in removed) st.delete(id)          // the user deleted these before; an app update does not bring them back
        prefs(app).edit().putString(PREF_PACK, shipped).apply()
        st.log("install", (rep.imported + rep.updated).joinToString(", "), if (rep.rejected.isEmpty()) "ok" else "partial", "bundled pack: " + rep.imported.size + " new, " + rep.updated.size + " updated, " + rep.rejected.size + " rejected")
        rep.text()
    }

    /** Import or update from a user ZIP. Never throws; the report says what happened. */
    fun importZip(ctx: Context, input: java.io.InputStream, label: String): SkillStore.ImportReport {
        val st = store(ctx)
        val rep = try { st.importZip(input, "zip:" + label.take(60), false, ctx.applicationContext.cacheDir) } catch (e: Exception) {
            SkillStore.ImportReport(emptyList(), emptyList(), emptyList(), listOf(label to ("Import failed: " + (e.message ?: e.javaClass.simpleName))), emptyList(), emptyList(), emptyList(), emptyMap(), 0)
        }
        // a skill the user re-imports is no longer "removed"
        val re = prefs(ctx).getStringSet(PREF_REMOVED, emptySet()).orEmpty().toMutableSet()
        if (re.removeAll((rep.imported + rep.updated).map { SkillCore.sanitizeId(it.substringBefore(" (")) }.toSet())) prefs(ctx).edit().putStringSet(PREF_REMOVED, re).apply()
        st.log("import", (rep.imported + rep.updated).joinToString(", "), if (rep.rejected.isEmpty() && rep.problems.isEmpty()) "ok" else "issues", label + ": " + rep.imported.size + " new, " + rep.updated.size + " updated, " + rep.unchanged.size + " same, " + rep.rejected.size + " rejected")
        try { AdminAudit.log(ctx, "skills", "Imported skills ZIP", label) } catch (_: Throwable) {}
        return rep
    }

    fun delete(ctx: Context, id: String): Boolean {
        val st = store(ctx)
        val r = st.get(id) ?: return false
        val ok = st.delete(id)
        if (ok && r.builtin) { val s = prefs(ctx).getStringSet(PREF_REMOVED, emptySet()).orEmpty().toMutableSet(); s.add(id); prefs(ctx).edit().putStringSet(PREF_REMOVED, s).apply() }
        if (ok) { st.log("delete", r.name, "ok", "deleted by user"); try { AdminAudit.log(ctx, "skills", "Deleted skill", r.name) } catch (_: Throwable) {} }
        return ok
    }

    // ───────────── per-request activation ─────────────

    class Activation(val picks: List<SkillCore.Pick>, val names: List<String>, val block: String, val sticky: Boolean) {
        @Volatile var verified: Boolean? = null
        @Volatile var verifyNote: String = ""
        val resources = CopyOnWriteArrayList<String>()
        val scripts = CopyOnWriteArrayList<String>()
    }

    @Volatile var current: Activation? = null
    private var lastPicks: List<SkillCore.Pick> = emptyList()
    private var turnsSince = 99

    /** step(key, title, detail, state)  state: 0 running, 1 done, 2 issue, 3 failed — real states, shown in the chat timeline. */
    fun interface StepSink { fun step(key: String, title: String, detail: String, state: Int) }

    private val FILE_MAKERS = setOf("make_document", "edit_document", "skill_run", "save_file", "create_artifact", "write_code", "edit_code", "website_builder", "convert_document", "generate_image", "project_write", "project_files")

    /**
     * Called once per user request, before the model is asked. Detects relevant skills, loads their complete instructions and returns what
     * must be added to the system prompt, or null when no skill applies (nothing is shown then, and no cost is paid).
     */
    fun prepare(ctx: Context, userText: String, attachmentNames: List<String>, sink: StepSink?): Activation? {
        current = null
        try {
            if (!autoOn(ctx)) return null
            ensureBuiltIn(ctx)
            val st = store(ctx)
            val docs = st.enabledDocs()
            if (docs.isEmpty()) return null
            val route = SkillCore.route(userText, docs, attachmentNames)
            var picks = route.picks
            var sticky = false
            // a short follow-up ("make it blue", "ok add a table") continues the skills of the previous request
            if (picks.isEmpty() && lastPicks.isNotEmpty() && turnsSince <= 3 && userText.length < 140) {
                picks = lastPicks.filter { p -> docs.any { it.id == p.skill.id } }; sticky = picks.isNotEmpty()
            }
            if (picks.isEmpty()) { turnsSince++; return null }
            sink?.step("skill_detect", "Detecting relevant skills", "Checked ${docs.size} enabled skills", 0)
            val chosen = picks.joinToString("; ") { it.skill.name + (if (sticky) " (continuing previous task)" else " (matched: ${it.why})") }
            sink?.step("skill_detect", "Selected skills: " + picks.joinToString(", ") { it.skill.name }, chosen, 1)
            sink?.step("skill_load", "Loading skill instructions", picks.joinToString(", ") { it.skill.name }, 0)
            val (block, loaded) = st.composeFor(picks)
            if (block.isEmpty()) { sink?.step("skill_load", "Loading skill instructions", "Could not read SKILL.md of the selected skills", 3); return null }
            val sizes = loaded.joinToString("; ") { l ->
                val cut = block.contains("SKILL.md CUT HERE") && block.indexOf("SKILL: ${l.name} ") >= 0 && l.text.length > SkillCore.PER_SKILL_CHARS
                l.name + " " + String.format(Locale.US, "%,d", l.text.length) + " chars" + if (cut) " (first ${SkillCore.PER_SKILL_CHARS / 1000}k loaded, rest via skill_read)" else ""
            }
            sink?.step("skill_load", "Skill instructions loaded", sizes, 1)
            val res = loaded.joinToString("; ") { l -> l.name + ": " + l.resources.size + " files, " + st.runnableScripts(l.id).size + " runnable scripts" }
            sink?.step("skill_resources", "Skill resources indexed", res, 1)
            val act = Activation(picks, picks.map { it.skill.name }, block, sticky)
            current = act
            lastPicks = picks; turnsSince = 0
            st.log("activate", act.names.joinToString(", "), if (sticky) "continued" else "ok", userText.replace('\n', ' ').take(120))
            return act
        } catch (e: Throwable) {
            sink?.step("skill_detect", "Skills could not be prepared", (e.message ?: e.javaClass.simpleName).take(120), 3)
            try { store(ctx).log("activate", "", "error", e.message ?: e.javaClass.simpleName) } catch (_: Throwable) {}
            return null
        }
    }

    /** Called when the request is done. Returns (state, text) for the final "Verification" step, or null when no skill was active. */
    fun finish(ctx: Context, act: Activation?, toolsRun: List<String>): Pair<Int, String>? {
        if (act == null) return null
        val made = toolsRun.any { it in FILE_MAKERS }
        val (state, text) = when {
            act.verified == true -> 1 to ("Verification passed. " + act.verifyNote)
            act.verified == false -> 3 to ("Verification FAILED. " + act.verifyNote)
            made -> 2 to "Files were produced but skill_verify was not run, so the result is not verified."
            else -> 1 to "No file was produced, so there was nothing to verify; the skill instructions guided the answer."
        }
        try { store(ctx).log("result", act.names.joinToString(", "), when (state) { 1 -> "ok"; 3 -> "failed"; else -> "unverified" }, text + (if (act.resources.isNotEmpty()) " Resources read: " + act.resources.distinct().take(6).joinToString(", ") else "") + (if (act.scripts.isNotEmpty()) " Scripts: " + act.scripts.joinToString(", ") else "")) } catch (_: Throwable) {}
        return state to text
    }

    // ───────────── tools ─────────────

    fun run(ctx: Context, confirm: (String) -> Boolean, name: String, a: JSONObject): String {
        ensureBuiltIn(ctx)
        val st = store(ctx)
        return when (name) {
            "skill_find" -> st.findText(a.optString("query", ""))
            "skill_files" -> st.listFiles(a.optString("name", ""), a.optString("dir", ""))
            "skill_read" -> {
                val n = a.optString("name", "")
                val out = st.readResource(n, a.optString("path", "SKILL.md"), a.optInt("offset", 0), a.optInt("limit", 12000))
                if (out.startsWith("SKILL FILE")) { current?.resources?.add(n + "/" + a.optString("path", "SKILL.md").ifBlank { "SKILL.md" }); st.log("read", n, "ok", a.optString("path", "SKILL.md")) }
                else st.log("read", n, "failed", out.take(120))
                out
            }
            "skill_verify" -> verify(ctx, st, a)
            "skill_run" -> runScript(ctx, st, confirm, a)
            else -> "Unknown skill tool: $name"
        }
    }

    private fun verify(ctx: Context, st: SkillStore, a: JSONObject): String {
        val path = a.optString("path", "").trim()
        if (path.isEmpty()) return "Give path = the file to verify (the path returned when it was saved)."
        val (bytes, err) = FileAccess.bytesOf(ctx, path, 40_000_000)
        if (bytes == null) return "Cannot verify: $err"
        val v = SkillCore.verifyBytes(path.substringAfterLast('/'), bytes)
        current?.let { it.verified = v.ok; it.verifyNote = path.substringAfterLast('/') + " (" + v.checks.count { c -> c.ok } + "/" + v.checks.size + " checks)" }
        st.log("verify", current?.names?.joinToString(", ").orEmpty(), if (v.ok) "ok" else "failed", path.substringAfterLast('/'))
        return v.report() + if (v.ok) "\nThis checks the file's structure, not whether its content is right; still re-read it against the user's request." else "\nFix the problem and verify again; do not tell the user the file is fine."
    }

    private fun runScript(ctx: Context, st: SkillStore, confirm: (String) -> Boolean, a: JSONObject): String {
        val name = a.optString("name", ""); val script = a.optString("script", a.optString("path", ""))
        val (info, err) = st.scriptGate(name, script)
        if (err != null || info == null) { st.log("run", name, "refused", (err ?: "").take(160)); return err ?: "Script not found." }
        val r = st.find(name)!!
        val args = ArrayList<String>()
        val aj = a.optJSONArray("args") ?: JSONArray()
        if (aj.length() > 30) return "Too many arguments (max 30)."
        for (i in 0 until aj.length()) {
            val s = aj.optString(i, "")
            if (s.length > 2000) return "Argument ${i + 1} is too long."
            if (s.startsWith("/") && !s.startsWith("/proj/") || s.split('/', '\\').contains("..")) return "Argument '$s' points outside the script's sandbox. Use relative paths such as _in/file.docx and _out/result.docx."
            args.add(s)
        }
        val inputs = a.optJSONArray("inputs") ?: JSONArray()
        val bin = LinkedHashMap<String, ByteArray>()
        val inNames = ArrayList<String>()
        for (i in 0 until minOf(inputs.length(), 6)) {
            val p = inputs.optString(i, "")
            val (bytes, e) = FileAccess.bytesOf(ctx, p, 12_000_000)
            if (bytes == null) return "Cannot read input file '$p': $e"
            val fname = p.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "input$i" }
            bin["_in/$fname"] = bytes; inNames.add("_in/$fname")
        }
        val shown = (listOf(script) + args).joinToString(" ").take(300)
        if (!confirm(Confirm.msg("run", "Run skill script?", r.name + " › " + shown + (if (inNames.isNotEmpty()) "\nInput files: " + inNames.joinToString(", ") else "") + "\nRuns in an isolated Python sandbox; it cannot touch your phone's files."))) {
            st.log("run", r.name, "declined", script); return "The user declined to run the script."
        }
        // mount the skill's text files (the script, its helper modules, schemas) under skill/<id>/
        val dir = st.skillDir(r.id)
        val files = LinkedHashMap<String, String>()
        var total = 0L
        for (f in st.meta(r.id)?.files.orEmpty()) {
            if (!SkillCore.isTextFile(f.path) || f.size > 600_000) continue
            if (total + f.size > 6_000_000) break
            val txt = try { File(dir, f.path).readText(Charsets.UTF_8) } catch (_: Exception) { continue }
            files["skill/${r.id}/${f.path}"] = txt; total += f.size
        }
        val entry = "skill/${r.id}/${info.path}"
        if (!files.containsKey(entry)) return "The script '${info.path}' could not be read."
        current?.scripts?.add(r.name + "/" + info.path)
        val res = SkillRunner.run(ctx, entry, "skill/${r.id}", args, files, bin)
        val sb = StringBuilder()
        if (!res.loaded) {
            st.log("run", r.name, "failed", "Python runtime did not start")
            return "The Python sandbox did not start (needs internet the first time to fetch the runtime). ${res.err.take(300)}\nScript NOT run."
        }
        if (!res.finished) { st.log("run", r.name, "failed", "timeout"); return "The script did not finish in time and was stopped.\n" + res.out.take(1500) }
        val failed = res.err.contains("Traceback") || res.err.contains("[exit code")
        sb.append(if (failed) "SCRIPT FAILED: " else "SCRIPT RAN: ").append(r.name).append(" › ").append(info.path).append('\n')
        if (res.out.isNotBlank()) sb.append("stdout:\n").append(res.out.trim().take(4000)).append('\n')
        if (res.err.isNotBlank()) sb.append("stderr:\n").append(res.err.trim().takeLast(1800)).append('\n')
        if (res.outputs.isEmpty()) sb.append("No output files (a script writes files to _out/ to hand them back).\n")
        for ((n, bytes) in res.outputs.entries.take(5)) {
            val saved = try { FileAccess.write(ctx, "", n.substringAfterLast('/'), bytes, false) { p -> confirm(Confirm.msg("overwrite", "Overwrite existing file?", p)) } } catch (e: Exception) { "Could not save: " + e.message }
            sb.append("Output ").append(n).append(": ").append(saved).append('\n')
        }
        st.log("run", r.name, if (failed) "failed" else "ok", info.path + " " + args.joinToString(" ").take(80))
        return sb.toString().trimEnd()
    }
}
