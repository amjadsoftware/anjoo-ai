# Private Android signing (v99.2.25)

Signing passwords and the private keystore are no longer embedded in Gradle or shipped in the source ZIP.

To sign a release build, set these values in the machine's environment or in the untracked root `local.properties` file:

```properties
ANJOO_STORE_FILE=/absolute/path/to/your-private-key.jks
ANJOO_STORE_PASSWORD=YOUR_STORE_PASSWORD
ANJOO_KEY_ALIAS=YOUR_KEY_ALIAS
ANJOO_KEY_PASSWORD=YOUR_KEY_PASSWORD
```

Keep `local.properties` and the keystore private. Do not upload either to GitHub or share them in a source archive. The keystore that signed an already-installed Play/store APK must be preserved privately; replacing it creates an APK Android may refuse to install as an update. Without all four values and an existing key file, the release output is unsigned. Debug builds continue to use Gradle's normal debug key.
