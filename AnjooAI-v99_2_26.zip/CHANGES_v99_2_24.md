# Anjoo AI v99.2.24 — Artifacts side-menu shortcut

## Navigation
- Main chat remains the home screen.
- Side-menu shortcut order: Codixa → HS — AI App Builder → Website Builder → Artifacts & Docs.
- The new Artifacts shortcut opens the existing ArtifactActivity library and shows the current saved-item count.
- No duplicate artifact storage or second artifact implementation was introduced.

## Existing Artifact capabilities retained
- Saved web pages, dashboards, small apps, slide decks, documents and reports.
- Live preview, code view, editing, version history/restore, rename, delete, export and sharing.

## App map
- Updated the in-app App Map so Anjoo can explain the new menu route accurately.

## Version
- versionName: 99.2.24
- local fallback versionCode: 99314 (CI may override with BUILD_NUMBER).

## Verification
- Source-level menu and manifest checks performed.
- ZIP integrity checked after packaging.
- Full Android/Gradle build and device interaction test must still be run in an Android build environment.
