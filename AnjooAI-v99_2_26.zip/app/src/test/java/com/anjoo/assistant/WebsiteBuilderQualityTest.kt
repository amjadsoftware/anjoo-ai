package com.anjoo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WebsiteBuilderQualityTest {
    @Test fun detectsPlaceholderAnchorsAndMissingInternalPages() {
        val findings = WebsiteBuilder.interactionFindings(
            mapOf("index.html" to """
                <html lang="en"><head><meta name="viewport" content="width=device-width"><title>Demo</title></head>
                <body><a href="#">Explore</a><a href="services.html">Services</a></body></html>
            """.trimIndent())
        )
        assertTrue(findings.any { it.contains("href='#'") })
        assertTrue(findings.any { it.contains("services.html") && it.contains("not found") })
    }

    @Test fun acceptsExistingInternalPageLinksAndCompleteMetadata() {
        val findings = WebsiteBuilder.interactionFindings(
            mapOf(
                "index.html" to """<html lang="en"><head><meta name="viewport" content="width=device-width"><title>Home</title></head><body><a href="services.html">Services</a></body></html>""",
                "services.html" to """<html lang="en"><head><meta name="viewport" content="width=device-width"><title>Services</title></head><body><h1>Services</h1></body></html>"""
            )
        )
        assertFalse(findings.any { it.contains("not found") })
        assertFalse(findings.any { it.contains("viewport meta missing") })
        assertFalse(findings.any { it.contains("page title missing") })
    }
}
