package com.anjoo.assistant

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView

/** Compact dark workspace drawer: workspace shortcuts, searchable threads and workspace actions. */
class SideMenu(
    private val ctx: Context, private val host: FrameLayout,
    private val bg: Int, private val surface: Int, private val ink: Int, private val muted: Int, private val accent: Int
) {
    class Item(
        val title: String, val selected: Boolean,
        val open: () -> Unit, val copy: () -> Unit, val share: () -> Unit, val delete: () -> Unit,
        val pinned: Boolean = false,
        val rename: ((String) -> Unit)? = null,
        val pin: (() -> Unit)? = null,
        val matches: ((String) -> Boolean)? = null
    )

    private var scrim: View? = null
    private var panel: View? = null
    val isOpen get() = panel != null

    private fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun close() {
        scrim?.let { host.removeView(it) }
        panel?.let { host.removeView(it) }
        scrim = null; panel = null
    }

    fun open(
        heading: String, newLabel: String, onNew: () -> Unit,
        items: () -> List<Item>, footer: List<Pair<String, () -> Unit>>, emptyText: String,
        listLabel: String = "Recent tasks", icon: String = "◦",
        shortcut: Pair<String, () -> Unit>? = null,
        shortcutBelow: Pair<String, () -> Unit>? = null,
        shortcutThird: Pair<String, () -> Unit>? = null,
        shortcutFourth: Pair<String, () -> Unit>? = null
    ) {
        close()
        val s = View(ctx).apply { setBackgroundColor(Color.argb(150, 0, 0, 0)); setOnClickListener { close() } }
        val w = minOf(dp(330), (ctx.resources.displayMetrics.widthPixels * 0.84f).toInt())
        val p = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); isClickable = true
            setPadding(dp(12), dp(34), dp(12), dp(12))
        }
        p.addView(TextView(ctx).apply {
            text = heading; textSize = 20f; setTextColor(ink); typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(dp(6), dp(4), dp(6), dp(12))
        })
        p.addView(TextView(ctx).apply {
            text = "+  " + newLabel; textSize = 14.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER_VERTICAL
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            background = GradientDrawable().apply { setColor(accent); cornerRadius = dp(13).toFloat() }
            setPadding(dp(14), 0, dp(14), 0)
            setOnClickListener { close(); onNew() }
        }, LinearLayout.LayoutParams(-1, dp(46)))
        shortcut?.let { action ->
            p.addView(TextView(ctx).apply {
                text = action.first; textSize = 14.5f; setTextColor(ink)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply { setColor(surface); cornerRadius = dp(12).toFloat() }
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { close(); action.second() }
            }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(8) })
        }
        shortcutBelow?.let { action ->
            p.addView(TextView(ctx).apply {
                text = action.first; textSize = 14.5f; setTextColor(ink)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply { setColor(surface); cornerRadius = dp(12).toFloat(); setStroke(dp(1), Color.argb(65, 92, 190, 135)) }
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { close(); action.second() }
            }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        }
        shortcutThird?.let { action ->
            p.addView(TextView(ctx).apply {
                text = action.first; textSize = 14.5f; setTextColor(ink)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply { setColor(surface); cornerRadius = dp(12).toFloat(); setStroke(dp(1), Color.argb(75, 92, 150, 235)) }
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { close(); action.second() }
            }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        }
        shortcutFourth?.let { action ->
            p.addView(TextView(ctx).apply {
                text = action.first; textSize = 14.5f; setTextColor(ink)
                typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply { setColor(surface); cornerRadius = dp(12).toFloat(); setStroke(dp(1), Color.argb(75, 77, 214, 160)) }
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener { close(); action.second() }
            }, LinearLayout.LayoutParams(-1, dp(44)).apply { topMargin = dp(6) })
        }
        var query = ""
        val search = android.widget.EditText(ctx).apply {
            hint = "Search chats and tasks"; textSize = 14f; setTextColor(ink); setHintTextColor(muted); maxLines = 1; isSingleLine = true
            background = GradientDrawable().apply { setColor(surface); cornerRadius = dp(12).toFloat() }
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        p.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        p.addView(TextView(ctx).apply {
            text = listLabel; textSize = 12f; setTextColor(muted); letterSpacing = 0.05f; setPadding(dp(8), dp(14), 0, dp(2))
        })
        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        p.addView(ScrollView(ctx).apply { addView(list); isVerticalScrollBarEnabled = false },
            LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) })

        var cache: List<Item>? = null
        fun fill(reload: Boolean = false) {
            list.removeAllViews()
            if (reload || cache == null) cache = items()
            val its = cache!!.filter { query.isBlank() || it.title.contains(query.trim(), true) || (query.trim().length >= 2 && it.matches?.invoke(query.trim()) == true) }
            if (its.isEmpty()) {
                list.addView(TextView(ctx).apply { text = emptyText; textSize = 13f; setTextColor(muted); setPadding(dp(8), dp(12), dp(8), dp(12)) })
                return
            }
            for (itm in its) {
                val row = LinearLayout(ctx).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    background = GradientDrawable().apply {
                        setColor(if (itm.selected) surface else Color.TRANSPARENT); cornerRadius = dp(12).toFloat()
                    }
                    setOnClickListener { close(); itm.open() }
                }
                row.addView(TextView(ctx).apply {
                    text = (if (itm.pinned) "◆  " else icon + "  ") + itm.title; textSize = 14f; setTextColor(if (itm.selected) accent else ink)
                    maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(12), dp(12), dp(4), dp(12))
                }, LinearLayout.LayoutParams(0, -2, 1f))
                val dots = TextView(ctx).apply {
                    text = "⋮"; textSize = 20f; setTextColor(muted); gravity = Gravity.CENTER
                }
                dots.setOnClickListener { v ->
                    val pm = PopupMenu(ctx, v)
                    if (itm.rename != null) pm.menu.add("✏️  Rename")
                    if (itm.pin != null) pm.menu.add(if (itm.pinned) "📍  Unpin" else "📌  Pin")
                    pm.menu.add("📋  Copy"); pm.menu.add("📤  Share"); pm.menu.add("🗑  Delete")
                    pm.setOnMenuItemClickListener { m ->
                        val tt = m.title?.toString() ?: ""
                        when {
                            tt.endsWith("Copy") -> itm.copy()
                            tt.endsWith("Share") -> itm.share()
                            tt.endsWith("Pin") || tt.endsWith("Unpin") -> { itm.pin?.invoke(); fill(true) }
                            tt.endsWith("Rename") -> {
                                val et = android.widget.EditText(ctx).apply { setText(itm.title); setSelection(text.length) }
                                AlertDialog.Builder(ctx).setTitle("Rename").setView(et)
                                    .setPositiveButton("Save") { _, _ -> itm.rename?.invoke(et.text.toString()); fill(true) }
                                    .setNegativeButton("Cancel", null).show()
                            }
                            else -> AlertDialog.Builder(ctx).setMessage("Delete \"" + itm.title + "\"?")
                                .setPositiveButton("Delete") { _, _ -> itm.delete(); fill(true) }
                                .setNegativeButton("Cancel", null).show()
                        }
                        true
                    }
                    pm.show()
                }
                row.addView(dots, LinearLayout.LayoutParams(dp(44), dp(44)))
                list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(2) })
            }
        }
        val refill = Runnable { fill() }
        fill()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {
                // Wait a moment after the last key so typing stays smooth (searching reads every chat).
                query = s?.toString() ?: ""
                search.removeCallbacks(refill); search.postDelayed(refill, 180)
            }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })

        if (footer.isNotEmpty()) {
            p.addView(View(ctx).apply { setBackgroundColor(Color.argb(60, 128, 128, 128)) }, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(6) })
            for (f in footer) p.addView(TextView(ctx).apply {
                text = f.first; textSize = 14.5f; setTextColor(ink); setPadding(dp(12), dp(13), dp(12), dp(13))
                setOnClickListener { close(); f.second() }
            })
        }
        host.addView(s, FrameLayout.LayoutParams(-1, -1))
        host.addView(p, FrameLayout.LayoutParams(w, -1, Gravity.START))
        p.translationX = -w.toFloat()
        p.animate().translationX(0f).setDuration(150).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        scrim = s; panel = p
    }
}
