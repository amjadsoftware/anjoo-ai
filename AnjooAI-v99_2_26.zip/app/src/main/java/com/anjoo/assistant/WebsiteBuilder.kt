package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Website Builder agent. It does NOT replace Code Studio: it orchestrates the pieces that already exist
 * (Coder.build / Coder.revise, Runner.check, checkpoints, ZIP export, the preview card) into one staged workflow
 * with saved progress, so an interrupted job resumes at the first unfinished stage instead of starting again.
 *
 * Honest scope on a phone: sites are static (HTML + CSS + vanilla JS) and run in the built-in WebView. There is no Node,
 * npm, database server or hosting account on the device, so server features are reported as "needs server setup",
 * never faked, and nothing is deployed from here. Every line of the final report comes from a check that really ran.
 *
 * Stages: plan -> build -> run_check -> audit -> seo -> deploy_docs -> verify
 */
object WebsiteBuilder {

    private val STAGES = listOf("plan", "build", "premium_review", "run_check", "audit", "seo", "deploy_docs", "verify")

    private val STAGE_LABEL = mapOf(
        "plan" to "Plan and checklist",
        "build" to "Design and build",
        "premium_review" to "Premium design and interaction review",
        "run_check" to "Run in preview",
        "audit" to "Security / accessibility / responsive audit",
        "seo" to "SEO files",
        "deploy_docs" to "Deployment files",
        "verify" to "Final verification"
    )

    // ------------------------------------------------------------------ saved state (outside the project, so it is never exported or overwritten)

    private fun stateFile(ctx: Context, key: String): File {
        val d = File(ctx.filesDir, "website_state").also { it.mkdirs() }
        return File(d, key.replace(Regex("[^A-Za-z0-9_.-]"), "_") + ".json")
    }

    private fun load(ctx: Context, key: String): JSONObject =
        try { JSONObject(stateFile(ctx, key).readText(Charsets.UTF_8)) } catch (e: Exception) { JSONObject() }

    private fun save(ctx: Context, key: String, st: JSONObject) {
        try { stateFile(ctx, key).writeText(st.toString(), Charsets.UTF_8) } catch (e: Exception) { }
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    private fun done(st: JSONObject, stage: String): Boolean = st.optJSONObject("done")?.optBoolean(stage, false) == true

    private fun mark(st: JSONObject, stage: String, ok: Boolean, note: String) {
        val d = st.optJSONObject("done") ?: JSONObject().also { st.put("done", it) }
        d.put(stage, ok)
        val n = st.optJSONObject("notes") ?: JSONObject().also { st.put("notes", it) }
        n.put(stage, note.take(1500))
    }

    private fun findDir(ctx: Context, a: JSONObject): File? {
        val hint = a.optString("project", "").trim().ifEmpty { prefs(ctx).getString("wbLast", "") ?: "" }
        val all = Coder.list(ctx)
        if (hint.isBlank()) return all.firstOrNull()
        return all.firstOrNull { it.name.equals(hint, true) }
            ?: all.firstOrNull { Coder.name(it).equals(hint, true) }
            ?: all.firstOrNull { Coder.name(it).contains(hint, true) }
    }

    // ------------------------------------------------------------------ entry point

    fun run(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val action = a.optString("action", "start").trim().lowercase().replace(' ', '_').replace('-', '_')
        return try {
            when (action) {
                "start", "new", "build" -> start(ctx, confirm, a)
                "continue", "resume" -> resume(ctx, confirm, a)
                "status", "progress", "plan" -> status(ctx, a)
                "change", "edit", "revise" -> change(ctx, confirm, a)
                "audit" -> single(ctx, confirm, a, "audit")
                "seo" -> single(ctx, confirm, a, "seo")
                "deploy", "deploy_docs", "deployment" -> single(ctx, confirm, a, "deploy_docs")
                "verify", "report" -> single(ctx, confirm, a, "verify")
                "export", "export_zip" -> {
                    val dir = findDir(ctx, a) ?: return "Koi website project nahi mila. Pehle action=start se banayen."
                    CodeTools.run(ctx, confirm, "project_studio", JSONObject().put("action", "export_zip").put("project", Coder.name(dir))) ?: "Export nahi ho saka."
                }
                else -> "website_builder actions: start, continue, status, change, audit, seo, deploy, verify, export."
            }
        } catch (e: Exception) {
            "Website Builder rukk gaya: " + (e.message ?: e.javaClass.simpleName) + ". 'continue' se wahin se dobara shuru hoga."
        }
    }

    // ------------------------------------------------------------------ start / resume

    private fun start(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val request = a.optString("message", a.optString("request", a.optString("task", ""))).trim()
        if (request.isBlank()) return "Kaisi website banani hai? message mein requirements likhein (kaam, pages, rang/style, zaban)."
        val log = StringBuilder()

        // 1) PLAN
        val plan = makePlan(ctx, request, a.optString("domain", ""))
        log.append("✔ Plan: ").append(plan.optString("summary", "tayyar")).append('\n')

        // 2) BUILD (Code Studio builder, with the plan + design rules as the brief)
        val (dir, notes) = Coder.build(ctx, brief(request, plan), "auto", true, Coder.deepDefault(ctx), {}, {})
        val key = dir.name
        prefs(ctx).edit().putString("wbLast", Coder.name(dir)).apply()
        val st = JSONObject().put("request", request).put("plan", plan).put("project", Coder.name(dir))
            .put("domain", a.optString("domain", "")).put("created", System.currentTimeMillis())
        mark(st, "plan", true, plan.optString("summary", ""))
        mark(st, "build", true, notes)
        save(ctx, key, st)
        log.append("✔ Build: ").append(Coder.readFiles(dir).size).append(" files\n")

        log.append(runStages(ctx, confirm, dir, st, key))
        return finish(ctx, dir, st, log.toString(), true)
    }

    private fun resume(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val dir = findDir(ctx, a) ?: return "Koi website project nahi mila. Pehle action=start se banayen."
        val st = load(ctx, dir.name)
        if (st.length() == 0) return "Is project ka Website Builder record nahi hai ('" + Coder.name(dir) + "'). action=change se badlav karein ya action=audit chalayein."
        val left = STAGES.filter { !done(st, it) }
        if (left.isEmpty()) return finish(ctx, dir, st, "Sab stages pehle hi mukammal hain.\n", false)
        val log = StringBuilder("Resume: baqi stages: " + left.joinToString(", ") + "\n")
        log.append(runStages(ctx, confirm, dir, st, dir.name))
        return finish(ctx, dir, st, log.toString(), false)
    }

    private fun single(ctx: Context, confirm: (String) -> Boolean, a: JSONObject, stage: String): String {
        val dir = findDir(ctx, a) ?: return "Koi website project nahi mila. Pehle action=start se banayen."
        val st = load(ctx, dir.name)
        val note = runStage(ctx, confirm, dir, st, stage)
        val passed = stagePassed(stage, note)
        mark(st, stage, passed, note)
        save(ctx, dir.name, st)
        return (if (passed) "PASS · " else "BLOCKED · ") + STAGE_LABEL[stage] + ":\n" + note +
            (if (passed) "" else "\n\nIs stage ko complete mark nahi kiya gaya. Masail theek karke action=continue chalayein.") +
            "\n\nPROJECT_EDITED: '" + Coder.name(dir) + "'"
    }

    /** A change request through normal chat: revise the real files, then re-run the checks that depend on them. */
    private fun change(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val dir = findDir(ctx, a) ?: return "Koi website project nahi mila."
        val msg = a.optString("message", a.optString("instruction", "")).trim()
        if (msg.isBlank()) return "Kya badalna hai, message mein likhein."
        // Safety checkpoint before editing, so the previous version can be restored.
        val cp = CodeTools.run(ctx, confirm, "project_studio", JSONObject().put("action", "checkpoint").put("project", Coder.name(dir)).put("message", "Before change: " + msg.take(60))) ?: ""
        val res = Coder.revise(ctx, dir, msg, Coder.deepDefault(ctx), {}, {})
        val st = load(ctx, dir.name)
        for (s in listOf("premium_review", "run_check", "audit", "seo", "deploy_docs", "verify"))
            (st.optJSONObject("done") ?: JSONObject().also { st.put("done", it) }).put(s, false)
        save(ctx, dir.name, st)
        val log = StringBuilder("✔ Change applied. ").append(cp).append('\n').append(res.take(600)).append('\n')
        log.append(runStages(ctx, confirm, dir, st, dir.name))
        return finish(ctx, dir, st, log.toString(), false)
    }

    private fun status(ctx: Context, a: JSONObject): String {
        val dir = findDir(ctx, a) ?: return "Koi website project nahi mila."
        val st = load(ctx, dir.name)
        if (st.length() == 0) return "Project '" + Coder.name(dir) + "' Website Builder se nahi bana; record maujood nahi."
        val sb = StringBuilder("Project: ").append(Coder.name(dir)).append('\n')
        val plan = st.optJSONObject("plan")
        if (plan != null) {
            sb.append("Summary: ").append(plan.optString("summary")).append('\n')
            list(plan.optJSONArray("pages"))?.let { sb.append("Pages: ").append(it).append('\n') }
            list(plan.optJSONArray("features"))?.let { sb.append("Features: ").append(it).append('\n') }
            list(plan.optJSONArray("assumptions"))?.let { sb.append("Assumptions: ").append(it).append('\n') }
            list(plan.optJSONArray("needs_server"))?.let { sb.append("Needs server setup (not built here): ").append(it).append('\n') }
        }
        sb.append("\nStages:\n")
        for (s in STAGES) sb.append(if (done(st, s)) "  [x] " else "  [ ] ").append(STAGE_LABEL[s]).append('\n')
        return sb.toString() + "\nPROJECT_EDITED: '" + Coder.name(dir) + "'"
    }

    // ------------------------------------------------------------------ stage runner

    private fun runStages(ctx: Context, confirm: (String) -> Boolean, dir: File, st: JSONObject, key: String): String {
        val log = StringBuilder()
        for (s in STAGES) {
            if (s == "plan" || s == "build") continue
            if (done(st, s)) continue
            val note = try {
                runStage(ctx, confirm, dir, st, s)
            } catch (e: Exception) {
                save(ctx, key, st)
                log.append("✖ ").append(STAGE_LABEL[s]).append(" ruka: ").append(e.message ?: e.javaClass.simpleName)
                    .append(". 'continue' se yahin se dobara chalega.\n")
                return log.toString()
            }
            val passed = stagePassed(s, note)
            mark(st, s, passed, note)
            save(ctx, key, st)
            log.append(if (passed) "✔ " else "⚠ ").append(STAGE_LABEL[s]).append(": ")
                .append(note.lineSequence().firstOrNull() ?: "").append('\n')
            if (!passed) {
                log.append("  Stage incomplete hai; remaining stages ko run nahi kiya. Masail dur karke action=continue chalayein.\n")
                return log.toString()
            }
        }
        return log.toString()
    }

    /** A stage is complete only when its output proves the required check passed. */
    internal fun stagePassed(stage: String, note: String): Boolean {
        val n = note.lowercase(java.util.Locale.ROOT)
        if (n.isBlank()) return false
        if (n.contains("blocked") || n.contains("ruka:") || n.contains("ruk gaya") || n.contains("failed") || n.contains("nakam")) return false
        return when (stage) {
            "premium_review" -> !n.contains("review blocked") && !n.contains("interaction scan still needs review")
            "run_check" -> n.contains("preview chali:") && !n.contains("masail baqi") && !n.contains("timeout") && !n.contains("load nahi")
            "audit" -> !Regex("\\b[1-9][0-9]* high\\b|\\b[1-9][0-9]* medium\\b").containsMatchIn(n)
            "verify" -> n.contains("entry page:") && n.contains("final preview check saaf") && !n.contains("masail")
            else -> !n.contains("error:") && !n.contains("exception:")
        }
    }

    private fun runStage(ctx: Context, confirm: (String) -> Boolean, dir: File, st: JSONObject, stage: String): String = when (stage) {
        "premium_review" -> premiumReview(ctx, dir, st)
        "run_check" -> runCheck(ctx, dir)
        "audit" -> auditAndFix(ctx, dir)
        "seo" -> seo(dir, st)
        "deploy_docs" -> deployDocs(dir, st)
        "verify" -> verify(ctx, confirm, dir)
        else -> ""
    }

    // ------------------------------------------------------------------ plan

    private fun makePlan(ctx: Context, request: String, domain: String): JSONObject {
        val sys = "You are a principal web architect and UX lead. Output ONLY one JSON object, no markdown, with keys: " +
            "name (short), summary (one sentence), assumptions (array of strings: reasonable assumptions you made), " +
            "pages (array of page names), features (array of concrete working features), roles (array, user roles if any), " +
            "data (array: data the site stores/handles), integrations (array), " +
            "needs_server (array: features that REALLY need a server/database/auth/payment and cannot work in a static site), " +
            "design (object: style, palette as hex list, heading_font, body_font, theme), " +
            "milestones (array of strings), checklist (array of short acceptance checks). " +
            "The site will be built as a static multi-page website (HTML, CSS, vanilla JS) that runs in a WebView; client-side persistence only through localStorage/IndexedDB. " +
            "Do not pretend server features exist. Write in the language of the request for visible content ideas."
        val out = try { Artifacts.askPublic(ctx, sys, "Website request:\n$request" + (if (domain.isNotBlank()) "\nDomain: $domain" else "")) } catch (e: Exception) { "ERR:" + e.message }
        val parsed = try {
            val t = out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
        } catch (e: Exception) { null }
        if (parsed != null) return parsed
        return JSONObject().put("name", "website").put("summary", request.take(120))
            .put("assumptions", JSONArray().put("Plan AI se nahi ban saka, is liye seedhi request par build hua."))
            .put("pages", JSONArray().put("index")).put("features", JSONArray()).put("needs_server", JSONArray())
    }

    private fun brief(request: String, plan: JSONObject): String =
        "WEBSITE BUILDER BRIEF\n\nUser request:\n" + request + "\n\nApproved plan (follow it):\n" + plan.toString(2) + "\n\n" +
        "Technical rules: a static website made of HTML, CSS and vanilla JavaScript that works offline inside an Android WebView. " +
        "No npm, no build step, no CDN-only dependencies. Multi-page if the plan lists several pages, with working navigation between them. " +
        "Persist user data only with localStorage/IndexedDB and make that really work. Do NOT fake server features (login against a fake user list, fake payments, fake API data shown as real): " +
        "implement the client-side part honestly and leave server-only items out of the UI. Never put API keys, tokens or passwords in the code.\n\n" +
        "PREMIUM DESIGN SYSTEM: First create a distinct art direction that fits this exact business. Define reusable CSS tokens for brand colours, neutrals, typography, spacing, grid, radii, borders, elevation, focus rings and motion. " +
        "Use a deliberate type scale and excellent line lengths; align every section to a consistent grid; use strong visual hierarchy, generous but purposeful whitespace, high-quality relevant imagery, polished iconography, nuanced surfaces and subtle micro-interactions. " +
        "Avoid generic AI-template styling, repetitive card grids, excessive gradients, arbitrary rounded boxes, emoji icons, lorem ipsum, empty sections and oversized headings without purpose. Each page must feel intentionally designed, not copied from the homepage.\n\n" +
        "PAGE COMPLETENESS: Create every page required by the plan, with unique content hierarchy and appropriate page-specific sections. Add consistent navigation, footer, breadcrumbs where useful, active navigation state, custom 404, and working internal links. Never create links to pages that do not exist. For multi-page sites, build the complete user journey across all pages.\n\n" +
        "FUNCTIONALITY CONTRACT: Before finishing, inventory every visible button, anchor, icon button, form, menu, tab, filter, toggle and interactive control. Each must have a real, appropriate result. No href=\"#\" placeholders, empty handlers, dead controls, fake success states, fake login/payment/API data, or controls that only look interactive. Validate forms, persist supported local data, and provide loading, empty, success and error states. If a feature requires a server that is unavailable, do not present it as working; explain the requirement and avoid misleading controls.\n\n" +
        "RESPONSIVE AND ACCESSIBLE: Mobile-first layout that is separately considered for small phones, large phones, tablets, laptops, desktops and wide screens; no horizontal overflow. Use semantic landmarks, one meaningful h1 per page, associated labels, descriptive alt text, visible focus, keyboard operation, sufficient contrast, skip link, reduced-motion support, and suitable touch targets. Add html lang, viewport, unique title, meta description and Open Graph metadata on each page.\n\n" +
        "TECHNICAL QUALITY: Use local assets where possible; do not depend on a CDN-only library or network access for core functionality. Use safe DOM APIs and never inject untrusted user input through innerHTML. Never hardcode secrets. Keep CSS, JS and HTML organized and consistent. Test real page navigation, forms, buttons, mobile menu, theme toggle and persistence. Every deliverable must be coherent and runnable in the built-in Android WebView."

    // ------------------------------------------------------------------ premium visual + interaction review

    /** A dedicated second pass targets the specific failure mode of generic-looking, partially wired websites. */
    private fun premiumReview(ctx: Context, dir: File, st: JSONObject): String {
        val before = Coder.readFiles(dir)
        val pages = PreviewServer.pages(dir)
        if (pages.isEmpty()) return "Premium review blocked: koi HTML page nahi mili."
        val staticFindings = interactionFindings(before)
        val plan = st.optJSONObject("plan")?.toString(2) ?: "No saved plan"
        val inventory = before.entries.joinToString("\n") { (path, content) ->
            val summary = when {
                path.endsWith(".html", true) -> "HTML page, ${Regex("(?i)<(button|a\\b|input|select|textarea)\\b").findAll(content).count()} interactive element(s)"
                path.endsWith(".css", true) -> "Stylesheet, ${content.length} chars"
                path.endsWith(".js", true) -> "JavaScript, ${content.length} chars"
                else -> "${content.length} chars"
            }
            "$path — $summary"
        }.take(12000)
        val instruction = """PREMIUM WEBSITE REVIEW — EDIT THE ACTUAL PROJECT FILES.

Saved project brief:
$plan

Current pages: ${pages.joinToString(", ")}
File inventory:
$inventory

Deterministic interaction findings:
${if (staticFindings.isEmpty()) "No simple placeholder/dead-link pattern detected." else staticFindings.joinToString("\n")}

Perform a senior design-team review of the current website, not a generic code review. Inspect all relevant source files and improve the existing implementation while preserving the intended features and content.

PRIORITIES:
1. Make the visual design feel genuinely premium, distinctive and business-specific: improve composition, hierarchy, typography, spacing, colour balance, imagery, navigation, section rhythm, page-specific layouts, responsive behavior, component consistency and micro-interactions.
2. Review every HTML page, not only index.html. Ensure each page has a complete, purposeful layout and the same coherent design system without cloning the same sections across every page.
3. Inspect every button, link, menu item, form, toggle, tab, filter and interactive control. Remove placeholder href="#" behavior, wire valid local navigation, implement meaningful client-side interactions and validation, and show honest outcomes. Never fake server-only functionality.
4. Fix any listed deterministic findings that are valid. Do not remove intended features to make a check pass.
5. Keep the site compatible with Android WebView and offline use. Do not add npm/build requirements, external runtime libraries, or CDN-only dependencies. Preserve safe handling of user input.
6. Respect prefers-reduced-motion, keyboard focus, labels, accessible contrast, image alt text, and small-screen layouts.
7. Keep code maintainable. Make targeted improvements; do not rewrite the entire project unnecessarily or destroy working features.

Return complete file edits using the required project file format. Do not merely describe recommendations. If a backend integration cannot exist in this static project, do not fake it.
""".trimIndent()
        val result = Coder.revise(ctx, dir, instruction, Coder.deepDefault(ctx), {}, {})
        val after = Coder.readFiles(dir)
        val findingsAfter = interactionFindings(after)
        val changed = before.keys.union(after.keys).count { before[it] != after[it] }
        val reviewerFailed = result.isBlank() || result.contains("Pehle Settings mein API key", true) ||
            result.contains("Jawab nahi mila", true) || result.contains("Code nahi ban saka", true) ||
            result.contains("request thori aur saaf", true)
        return (if (reviewerFailed) "Premium review blocked: AI review ka valid result nahi mila." else "Premium review completed: $changed file(s) changed across ${pages.size} HTML page(s).") + "\n" +
            (if (findingsAfter.isEmpty()) "Interaction scan: no simple placeholder/dead-link patterns detected." else "Interaction scan still needs review:\n" + findingsAfter.take(12).joinToString("\n")) +
            "\nReview notes: " + result.take(500).ifBlank { "No valid reviewer output." }
    }

    /** Fast, deterministic checks for common visible dead controls. These are heuristics, not proof of functionality. */
    internal fun interactionFindings(files: Map<String, String>): List<String> {
        val out = ArrayList<String>()
        val htmlFiles = files.filterKeys { it.endsWith(".html", true) || it.endsWith(".htm", true) }
        val knownPages = htmlFiles.keys.map { it.replace('\\', '/') }.toSet()
        for ((path, html) in htmlFiles) {
            val deadAnchors = Regex("(?is)<a\\b[^>]*href\\s*=\\s*['\"]#['\"][^>]*>").findAll(html).count()
            if (deadAnchors > 0) out.add("$path: $deadAnchors anchor(s) use href='#' with no destination")
            val blankButtons = Regex("(?is)<button\\b[^>]*>\\s*(?:Button|Click here|Submit|Learn more)\\s*</button>").findAll(html).count()
            if (blankButtons > 0) out.add("$path: $blankButtons generic button(s) may be unwired")
            val localLinks = Regex("(?is)<a\\b[^>]*href\\s*=\\s*['\"]([^'\"]+\\.html(?:#[^'\"]*)?)['\"][^>]*>").findAll(html)
            for (m in localLinks) {
                val dest = m.groupValues[1].substringBefore('#').trimStart('/')
                if (dest.isNotBlank() && !dest.startsWith("http", true) && dest !in knownPages && dest !in knownPages.map { it.substringAfterLast('/') })
                    out.add("$path: internal link target '$dest' not found")
            }
            if (!html.contains("<title", true)) out.add("$path: page title missing")
            if (!html.contains("name=\"viewport\"", true) && !html.contains("name='viewport'", true)) out.add("$path: viewport meta missing")
        }
        return out.distinct().take(40)
    }

    // ------------------------------------------------------------------ run in preview

    private fun runCheck(ctx: Context, dir: File): String {
        var report = Runner.check(ctx, dir).trim()
        var rounds = 0
        while (report.isNotEmpty() && rounds < 2) {
            rounds++
            Coder.revise(ctx, dir, "Fix these verified preview/runtime problems in the actual files, change nothing else:\n$report", Coder.deepDefault(ctx), {}, {})
            report = Runner.check(ctx, dir).trim()
        }
        return if (report.isEmpty()) "Preview chali: koi console error ya missing file nahi mili" + (if (rounds > 0) " ($rounds fix round ke baad)." else ".")
        else "Fix ke baad bhi ye masail baqi hain:\n$report"
    }

    // ------------------------------------------------------------------ audit (deterministic static checks, then one AI fix round)

    data class Finding(val sev: String, val file: String, val msg: String)

    private val SECRET = listOf(
        Regex("AIza[0-9A-Za-z_\\-]{35}"),
        Regex("sk-[A-Za-z0-9]{20,}"),
        Regex("(?i)(api[_-]?key|secret|token|passw(or)?d)\\s*[:=]\\s*['\"][^'\"\\s]{8,}['\"]")
    )

    fun audit(dir: File): List<Finding> {
        val out = ArrayList<Finding>()
        val files = Coder.readFiles(dir)
        var anyMedia = false
        var anyFocus = false
        var anyDark = false
        var anyAnim = false
        var anyReduced = false
        for ((path, text) in files) {
            val ext = path.substringAfterLast('.', "").lowercase()
            val isHtml = ext == "html" || ext == "htm"
            if (ext == "css" || isHtml) {
                if (text.contains("@media")) anyMedia = true
                if (text.contains("focus-visible") || text.contains(":focus")) anyFocus = true
                if (text.contains("prefers-color-scheme")) anyDark = true
                if (text.contains("@keyframes") || text.contains("transition")) anyAnim = true
                if (text.contains("prefers-reduced-motion")) anyReduced = true
            }
            if (isHtml) {
                if (!Regex("(?i)<meta[^>]+name=[\"']viewport").containsMatchIn(text)) out.add(Finding("medium", path, "viewport meta missing (not mobile friendly)"))
                if (!Regex("(?i)<title>[^<]+</title>").containsMatchIn(text)) out.add(Finding("medium", path, "<title> missing"))
                if (!Regex("(?i)<meta[^>]+name=[\"']description").containsMatchIn(text)) out.add(Finding("low", path, "meta description missing"))
                if (!Regex("(?i)<html[^>]+lang=").containsMatchIn(text)) out.add(Finding("low", path, "<html lang> missing"))
                val h1 = Regex("(?i)<h1[\\s>]").findAll(text).count()
                if (h1 == 0) out.add(Finding("low", path, "no <h1>")) else if (h1 > 1) out.add(Finding("low", path, "more than one <h1>"))
                val noAlt = Regex("(?i)<img\\b(?![^>]*\\balt=)[^>]*>").findAll(text).count()
                if (noAlt > 0) out.add(Finding("medium", path, "$noAlt <img> without alt text"))
                val inputs = Regex("(?i)<(input|select|textarea)\\b(?![^>]*type=[\"'](hidden|submit|button|reset|image)[\"'])[^>]*>").findAll(text).count()
                val labelled = Regex("(?i)<label\\b|aria-label=|aria-labelledby=").findAll(text).count()
                if (inputs > labelled) out.add(Finding("medium", path, "some form fields have no label/aria-label"))
                if (Regex("(?i)<a\\b[^>]*target=[\"']_blank[\"'](?![^>]*rel=[\"'][^\"']*noopener)[^>]*>").containsMatchIn(text))
                    out.add(Finding("low", path, "target=_blank link without rel=noopener"))
                if (Regex("(?i)<script[^>]+src=[\"']http://").containsMatchIn(text)) out.add(Finding("high", path, "script loaded over insecure http://"))
                if (Regex("(?i)<script[^>]+src=[\"']https?://[^\"']*(cdn\\.|cdnjs|unpkg|jsdelivr)").containsMatchIn(text))
                    out.add(Finding("medium", path, "runtime script depends on a CDN (core functionality may fail offline)"))
                if (Regex("(?i)(src|href)=[\"']http://[^\"']+\\.(css|js|png|jpe?g|webp|svg)").containsMatchIn(text)) out.add(Finding("medium", path, "insecure http:// resource (mixed content)"))
            }
            if (isHtml || ext == "js" || ext == "mjs" || ext == "ts" || ext == "jsx" || ext == "tsx") {
                if (Regex("\\beval\\s*\\(|new\\s+Function\\s*\\(").containsMatchIn(text)) out.add(Finding("high", path, "eval()/new Function() used"))
                if (Regex("document\\.write\\s*\\(").containsMatchIn(text)) out.add(Finding("medium", path, "document.write() used"))
                if (Regex("innerHTML\\s*(\\+?=)\\s*[^'\"`;\\s]").containsMatchIn(text)) out.add(Finding("medium", path, "innerHTML assigned from a variable (XSS risk): use textContent or sanitise"))
                if (Regex("(?i)localStorage\\.setItem\\([^)]*(passw|token|secret)").containsMatchIn(text)) out.add(Finding("medium", path, "sensitive value stored in localStorage"))
            }
            if (ext in setOf("html", "htm", "js", "mjs", "ts", "jsx", "tsx", "json", "env", "css")) {
                for (r in SECRET) if (r.containsMatchIn(text)) { out.add(Finding("high", path, "possible secret/API key in source")); break }
            }
        }
        if (files.keys.any { it.endsWith(".html", true) || it.endsWith(".htm", true) }) {
            if (!anyMedia) out.add(Finding("medium", "(css)", "no @media queries: layout is probably not responsive"))
            if (!anyFocus) out.add(Finding("low", "(css)", "no visible focus style (keyboard navigation)"))
            if (!anyDark) out.add(Finding("low", "(css)", "no dark theme (prefers-color-scheme)"))
            if (anyAnim && !anyReduced) out.add(Finding("low", "(css)", "animations without prefers-reduced-motion"))
        }
        return out
    }

    private fun fmt(f: List<Finding>): String = f.joinToString("\n") { "- [" + it.sev + "] " + it.file + ": " + it.msg }

    private fun auditAndFix(ctx: Context, dir: File): String {
        var found = audit(dir)
        val serious = found.filter { it.sev == "high" || it.sev == "medium" }
        if (serious.isNotEmpty()) {
            Coder.revise(ctx, dir, "Fix these verified audit findings in the actual files (keep the design and features unchanged):\n" + fmt(found), Coder.deepDefault(ctx), {}, {})
            found = audit(dir)
        }
        val high = found.count { it.sev == "high" }
        val med = found.count { it.sev == "medium" }
        val low = found.count { it.sev == "low" }
        val head = if (found.isEmpty()) "Audit saaf: koi finding nahi (static checks)." else "Audit baad: $high high, $med medium, $low low."
        return head + (if (found.isNotEmpty()) "\n" + fmt(found) else "") +
            "\n(Ye static code checks hain: injection/XSS patterns, secrets, labels, alt, responsive, focus. Dependency scan, CSRF/auth aur real penetration test is device par nahi hota.)"
    }

    // ------------------------------------------------------------------ SEO + deployment files (never overwrite existing user files)

    private fun writeIfAbsent(dir: File, rel: String, content: String): Boolean =
        if (File(dir, rel).exists()) false else Coder.writeFile(dir, rel, content)

    private fun seo(dir: File, st: JSONObject): String {
        val domain = (st.optString("domain", "").ifBlank { "https://example.com" }).trimEnd('/')
        val pages = PreviewServer.pages(dir).filter { !it.startsWith("docs/") }
        val urls = pages.joinToString("\n") { p ->
            val loc = if (p == "index.html") "$domain/" else "$domain/$p"
            "  <url><loc>$loc</loc></url>"
        }
        val made = ArrayList<String>()
        if (writeIfAbsent(dir, "sitemap.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n$urls\n</urlset>\n")) made.add("sitemap.xml")
        if (writeIfAbsent(dir, "robots.txt", "User-agent: *\nAllow: /\n\nSitemap: $domain/sitemap.xml\n")) made.add("robots.txt")
        val placeholder = if (st.optString("domain", "").isBlank()) " Domain abhi example.com hai: asli domain milne par sitemap.xml aur robots.txt mein badal dein." else ""
        return (if (made.isEmpty()) "SEO files pehle se maujood." else "Banayi: " + made.joinToString(", ") + ".") + placeholder
    }

    private fun deployDocs(dir: File, st: JSONObject): String {
        val name = Coder.name(dir)
        val made = ArrayList<String>()
        if (writeIfAbsent(dir, "_headers", "/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n  X-Frame-Options: SAMEORIGIN\n  Permissions-Policy: camera=(), microphone=(), geolocation=()\n")) made.add("_headers")
        if (writeIfAbsent(dir, "netlify.toml", "[build]\n  publish = \".\"\n\n[[headers]]\n  for = \"/*\"\n  [headers.values]\n    X-Content-Type-Options = \"nosniff\"\n    Referrer-Policy = \"strict-origin-when-cross-origin\"\n    X-Frame-Options = \"SAMEORIGIN\"\n")) made.add("netlify.toml")
        if (writeIfAbsent(dir, "vercel.json", "{\n  \"cleanUrls\": true,\n  \"headers\": [\n    { \"source\": \"/(.*)\", \"headers\": [\n      { \"key\": \"X-Content-Type-Options\", \"value\": \"nosniff\" },\n      { \"key\": \"Referrer-Policy\", \"value\": \"strict-origin-when-cross-origin\" },\n      { \"key\": \"X-Frame-Options\", \"value\": \"SAMEORIGIN\" }\n    ] }\n  ]\n}\n")) made.add("vercel.json")
        val server = list(st.optJSONObject("plan")?.optJSONArray("needs_server"))
        val doc = "# $name: deployment\n\nThis is a static website (HTML, CSS, JavaScript). No build step is needed.\n\n" +
            "## Host it\n- **Netlify**: drag the project folder (or ZIP) onto app.netlify.com/drop, or connect a Git repository. `netlify.toml` and `_headers` add security headers.\n" +
            "- **Vercel**: import the folder/repository; `vercel.json` is included.\n- **GitHub Pages**: push the files, then Settings > Pages > deploy from branch.\n- **Any web server**: upload all files to the web root.\n\n" +
            "## Before going live\n- Replace `https://example.com` in `sitemap.xml` and `robots.txt` with your real domain.\n- Re-test every form and link on the live URL.\n- Add a privacy notice if you collect personal data.\n\n" +
            "## Not included (needs a server)\n" + (if (server != null) "- " + server.replace(", ", "\n- ") else "- Nothing was flagged in the plan.") +
            "\n\nAnjoo AI does not deploy sites by itself and has not deployed this one.\n"
        if (writeIfAbsent(dir, "DEPLOY.md", doc)) made.add("DEPLOY.md")
        if (writeIfAbsent(dir, "README.md", "# $name\n\nStatic website generated with Anjoo AI Website Builder.\n\nOpen `index.html` in a browser, or see `DEPLOY.md` to publish it.\n")) made.add("README.md")
        return if (made.isEmpty()) "Deployment files pehle se maujood." else "Banayi: " + made.joinToString(", ") + ". (Deploy nahi kiya gaya: DEPLOY.md mein steps hain.)"
    }

    // ------------------------------------------------------------------ verify + report

    private fun verify(ctx: Context, confirm: (String) -> Boolean, dir: File): String {
        val files = Coder.readFiles(dir)
        val entry = PreviewServer.entry(dir)
        val report = Runner.check(ctx, dir).trim()
        val cp = CodeTools.run(ctx, confirm, "project_studio", JSONObject().put("action", "checkpoint").put("project", Coder.name(dir)).put("message", "Website Builder: verified build")) ?: ""
        return (if (entry == null) "Koi HTML entry page nahi mili." else "Entry page: $entry, ${files.size} files.") + "\n" +
            (if (report.isEmpty()) "Final preview check saaf." else "Final preview check mein masail:\n$report") + "\n" + cp
    }

    @Suppress("UNUSED_PARAMETER")
    private fun finish(ctx: Context, dir: File, st: JSONObject, log: String, saveZip: Boolean): String {
        val sb = StringBuilder()
        val incomplete = STAGES.filter { !done(st, it) }
        if (incomplete.isEmpty()) {
            sb.append("PROJECT_BUILT: '").append(Coder.name(dir)).append("' ke tamam configured stages pass hue. Chat mein project card, preview aur ZIP download dikhaya jayega.\n\n")
        } else {
            sb.append("PROJECT_IN_PROGRESS: '").append(Coder.name(dir)).append("' bana hai, lekin tamam quality stages pass nahi hue. Pending/blocked: ")
                .append(incomplete.joinToString { STAGE_LABEL[it] ?: it }).append(".\n\n")
        }
        sb.append("Workflow log:\n").append(log).append('\n')
        // Nothing is saved to the phone automatically: the person downloads it from the project card when they want it.
        sb.append("\nFILES KAHAN HAIN:\n- Project Anjoo AI ke andar hai (phone ke Files app mein nahi dikhta). Chat ka project card kholen: preview, files aur ZIP wahin hain.\n")
        sb.append("- Phone mein save karni ho to card ka ⬇ Download ya ZIP card dabayein; tabhi Download/Anjoo mein save hogi, apne aap kuch save nahi hota.\n")
        val notes = st.optJSONObject("notes")
        notes?.optString("audit", "")?.takeIf { it.isNotBlank() }?.let { sb.append("\n").append(it).append('\n') }
        val plan = st.optJSONObject("plan")
        list(plan?.optJSONArray("assumptions"))?.let { sb.append("\nAssumptions: ").append(it).append('\n') }
        list(plan?.optJSONArray("needs_server"))?.let { sb.append("\nSERVER SETUP CHAHIYE (yahan nahi bana, jhoota nahi dikhaya): ").append(it).append('\n') }
        sb.append("\nNOT VERIFIED on device: npm/React/Next builds, database, real auth, unit/e2e tests, dependency CVE scan, live deployment.\n")
        sb.append("\nINSTRUCTION FOR REPLY: user ko chhote jumlon mein sirf yehi verified baatein batao (kya bana, preview result, audit result, files kahan hain, kya baqi hai) aur poochho kya badalna hai. Jo is log mein nahi hai woh mat kaho.")
        return sb.toString()
    }

    private fun list(a: JSONArray?): String? {
        if (a == null || a.length() == 0) return null
        val parts = ArrayList<String>()
        for (i in 0 until a.length()) {
            val v = a.opt(i)
            parts.add(if (v is JSONObject) v.optString("name", v.toString()) else v.toString())
        }
        return parts.joinToString(", ").takeIf { it.isNotBlank() }
    }
}
