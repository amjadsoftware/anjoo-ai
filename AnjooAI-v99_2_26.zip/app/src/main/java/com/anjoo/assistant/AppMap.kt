package com.anjoo.assistant

import java.util.Locale

/**
 * App Map: where every screen, button and setting of Anjoo AI lives.
 * Anjoo uses it (a) as a compact always-in-prompt summary and (b) through the `app_map` tool for details,
 * so it can tell the user exactly "yeh cheez kahan hai" instead of guessing.
 * Keep this in sync with the real menus in MainActivity when UI labels change.
 */
object AppMap {
    /** One entry per screen/area. First line = title, the rest = what is there and how to reach it. */
    private val SECTIONS: List<Pair<String, String>> = listOf(
        "Main chat screen (home)" to
            "Upar: ≡ (chat history / side menu), Anjoo ka chhota buddy icon, title 'Anjoo AI' + subtitle (model; tap = model sheet), + (nayi chat), ⋮ (is chat ka menu). " +
            "Neeche composer: text box 'Chat with…'; '+' (Add To Session: Take Photo, Upload Image, Upload File); model chip (AI/model chunna); " +
            "ek gol button: mic (tap = awaaz se likhna, 2 second dabaye rakho = Live voice on/off), likha ho to SEND, jawab aa raha ho to STOP. " +
            "Live voice chalu ho to upar 'Live voice is on · tap to stop' bar. Lambi chat mein ↓ button latest message par le jata hai.",
        "⋮ Chat menu (header ka ⋮)" to
            "Share chat, Rename, Add to project (+ remove from project), Export chat (PDF / Word / Text), Delete chat, Starred answers, Settings.",
        "≡ Side menu / chat history" to
            "Chats ki list (search, pin, rename, copy, share, delete). Neeche: 'More tools', 'Update your app', 'Settings'. " +
            "Shortcuts order: 'Codixa — Projects, Code, Files & Chat' (CodixaActivity), 'HS — AI App Builder' (HSActivity), 'Website Builder — Professional Websites' (askWebsite chat flow), phir 'Artifacts & Docs' (ArtifactActivity, saved artifact library).",
        "More tools (side menu > More tools)" to
            "Mode: Think, Web search, Coding workspace, Create image (picture style/size/versions poochta hai). Starred answers, Export chat, Add chat to a project, Connectors, Response style, Effort (low/medium/high). " +
            "Tools: Read text from photo, Big project, Models aur keys, Export actual model report, Keys add karo (saari keys paste, company khud pehchan li jati hai).",
        "Settings (side menu ya ⋮ > Settings)" to
            "Workspace: Chat history, Tasks, Notes, Artifacts and docs, Older pages and code. " +
            "Assistant: Custom instructions, Voice and language, Show thinking and commands, Skip confirmations, Proactive suggestions, AI self-check / failure alerts, What Anjoo has learned. " +
            "Phone: Permissions and status, Phone control. " +
            "Connections: API key and model, Models aur keys / health, Export real model report, Telegram. " +
            "App: Anjoo AI folder, Appearance (theme), Live AI hologram style, Backup and restore (Export/Import backup, Auto backup har 3 din). About: Version.",
        "Voice and language (Settings > Voice and language)" to
            "JARVIS mode (ek tap mein wake word + natural voice + tools). Speaking: Assistant voice (tap se sun kar chuno), Natural AI voice, Read chat replies aloud, Read new messages aloud. " +
            "Listening: Speech language, Listening engine (Gemini Live / Always-on Gemini STT / Google speech), Wake word 'Anjoo'. " +
            "Live voice display: 'Live orb' (gol transparent orb, default On), 'Hologram tasveer' (default Off), Floating Buddy character. Help: Voice status (aakhri error).",
        "Live orb aur hologram" to
            "Live voice mein default gol transparent orb dikhta hai (touch nahi leta, tap piche ki screen par jata hai). Hologram tasveer default Off hai; " +
            "Settings > Voice and language > 'Hologram tasveer' On karne se orb ki jagah hologram aata hai; uska style Settings > 'Live AI hologram style' se chunte hain. " +
            "Orb poora band karna ho to 'Live orb' toggle Off. Dono overlay 'Display over other apps' permission se dusri apps ke upar dikhte hain; warna sirf app ke andar.",
        "Phone control (Settings > Phone control)" to
            "Permissions: Grant permissions, Accessibility (typing, taps), Notification access, Exact alarms (reminders). Files: Storage access, Default save folder. Display: Floating Buddy.",
        "Connectors (More tools > Connectors)" to
            "AI companies: Limit meter, API keys, Models aur keys, Export real model report. Apps and services: Telegram, Notifications (naye messages parh kar sunana), Phone control (Accessibility), Files and storage.",
        "Models aur keys" to
            "Kaun si company/model ki key chal rahi hai, kaun sa AI kis kaam ka hai, Limit meter (kis key ki limit khatam). 'Keys add karo' mein saari keys ek saath paste karo. Report PDF/Word/Excel/Text mein export hoti hai.",
        "Anjoo AI folder (Settings > App)" to
            "Permanent folder: chats, documents, projects, images, notes, backups. Actions: Sync now, Backup now, Back up keys (encrypted), Restore from folder, Recovery passphrase, Allow all files access, Folders ki list. Privacy lock yahin se.",
        "Backup and restore" to
            "Settings > Backup and restore: Export backup, Import backup, Anjoo AI folder, Auto backup (har 3 din). Chats, Code Studio projects aur attachments shamil.",
        "Tasks screen" to "Settings > Workspace > Tasks. '+ New' se kaam, har task par tap = edit/move/delete; schedule kiye agent ka natija task mein dikhta hai.",
        "Notes screen" to "Settings > Workspace > Notes. '+ New', search, ⋮ menu (Sync with another phone). Notes sirf is phone par save hote hain.",
        "Artifacts and docs" to "Side menu > 'Artifacts & Docs' (Website Builder ke baad) ya Settings > Workspace > Artifacts and docs: banaye hue web pages, dashboards, small apps, slides, documents aur reports ki library; kholo, live preview, edit, versions restore, export aur share karo.",
        "Codixa (side menu shortcut)" to "Projects, code files, preview aur project chat ek jagah. Project par tap = options, 'Code files', 'Project chat', live PREVIEW.",
        "HS — AI App Builder (side menu shortcut)" to "App banane ka planner/builder ('Plan before building', examples). APK banane ke liye HS APK Builder: GitHub connect, build type, APK download, encrypted cloud token backup.",
        "Website Builder (side menu shortcut)" to "Professional multi-page websites: planning, design, coding, preview, audits, SEO and deployment preparation. Chat mein natural language se bhi website ban sakti hai.",
        "Artifacts (side menu shortcut)" to "Website Builder ke foran baad side menu mein 'Artifacts & Docs'. Saved web pages, dashboards, small apps, slides, documents aur reports ki library; open, live preview, edit, version history, export aur share.",
        "Live preview dock (chat ke upar)" to "Web app ka live panel: ⟳ reload, ⛶ full screen, ▾/▴ chhota/bada, ✕ band.",
        "Permissions and status screen" to "Settings > Phone > Permissions and status: har permission ON/OFF dikhata hai aur sahi settings screen kholta hai.",
        "Updates" to "Side menu > 'Update your app': nayi version check/download."
    )

    /** Compact list that is always inside the system prompt (titles + 1 line). */
    fun promptBlock(): String {
        val sb = StringBuilder("APP MAP (Anjoo AI ki apni screens): Tumhe app ka har button/feature pata hona chahiye. Jab user poochhe 'X kahan hai / kaise karun', ")
        sb.append("pehle app_map tool (query = lafz) chalao, phir seedha raasta batao: 'Settings > Voice and language > ...' jaisi chhoti, sahi chain mein. Andaza mat lagao aur jo cheez map mein na ho use 'yeh app mein nahi' kaho.\n")
        sb.append("Areas: ")
        sb.append(SECTIONS.joinToString("; ") { it.first })
        sb.append(".\n")
        sb.append("Aham jaldi ke raaste: Live voice = mic button 2 second dabao. Models/keys = Settings > Connections ya More tools. Theme = Settings > App > Appearance. ")
        sb.append("Orb/hologram = Settings > Voice and language > Live voice display (orb default On, hologram default Off). Backup = Settings > App > Backup and restore.\n")
        return sb.toString()
    }

    /** Detail for the `app_map` tool. Empty query returns everything. */
    fun lookup(query: String): String {
        val words = query.lowercase(Locale.ROOT).split(Regex("[\\s,;]+")).filter { it.length >= 2 }
        val hits = if (words.isEmpty()) SECTIONS else SECTIONS.filter { (t, d) ->
            val hay = (t + " " + d).lowercase(Locale.ROOT)
            words.any { hay.contains(it) }
        }
        if (hits.isEmpty()) return "App map mein '" + query + "' se koi cheez nahi mili. Poori list ke liye query khaali chhodo. Agar woh feature map mein nahi to app mein nahi hai; user ko sach batao."
        val sb = StringBuilder("ANJOO APP MAP" + (if (query.isNotBlank()) " ('" + query + "')" else "") + ":\n")
        for ((t, d) in hits) sb.append("• ").append(t).append(": ").append(d).append("\n")
        return sb.toString()
    }
}
