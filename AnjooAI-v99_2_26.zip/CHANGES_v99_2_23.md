# Anjoo AI v99.2.23 — Chat workflow and Website Builder navigation

## Navigation order
- Chat remains the main screen.
- Side drawer shortcuts now appear in the requested order: Codixa, HS — AI App Builder, Website Builder.
- Website Builder opens the existing website brief dialog and submits the request into the normal chat/agent workflow.

## In-chat process visibility
- Completed assistant messages with tool activity now show a visible `PROCESS · YAHAN KAAM HUA` timeline directly below the answer's process summary.
- Up to eight real tool steps are shown with their actual status (Done, Issue, Failed, Running) and tool details.
- Tapping the timeline opens the full existing activity timeline.
- The existing generated-file attachment card and project card remain rendered in the chat when their corresponding outputs are actually produced.
- Website Builder tool steps display a clearer task-specific description.

## Verification
- Source edits and ZIP packaging checked.
- Full Android/Gradle build not run in this environment because the Gradle executable and wrapper are unavailable.
