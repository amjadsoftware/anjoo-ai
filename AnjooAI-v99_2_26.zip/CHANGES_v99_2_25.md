# Anjoo AI v99.2.25 — priority systems upgrade

**UI compatibility:** existing home screen, chat layout, drawer/menu, and existing screen navigation are retained. This version adds capabilities behind the existing UI and tools.

## Changes

- **Live process timeline:** existing per-tool/build progress cards remain in the chat. Multi-agent team runs now stream specialist and synthesis progress into the currently running card instead of appearing as one opaque long call.
- **Autonomous agent coordination:** added a bounded specialist team (`delegate_team`) with architect/coder/reviewer, researcher/analyst/reviewer, and planner/writer/reviewer combinations. Each agent works independently; a synthesizer reconciles the reports. Results are stored on the existing Task Board. The team does not execute phone actions.
- **Task recovery:** added `retry_task` so a pending or previously failed Task Board card can be restarted from the existing conversation. The original prompt for Agent Team work is saved separately so it survives progress updates and is available to retry. The new result overwrites the previous run result on that same card. Existing Task Board UI remains unchanged.
- **Website Builder quality gates:** premium review, preview, audit, SEO/deployment documentation, and final verification must pass before the project is described as complete. A failed gate leaves the project in progress and stops later stages until it is fixed.
- **Website runtime checks:** isolated WebView preview checks the rendered page at phone and wide-screen viewports, captures JavaScript console errors, main-frame load failures, HTTP errors, missing local resources, blank pages, horizontal overflow, and load/inspection timeouts. The runner does not click arbitrary controls because that could submit a form or trigger destructive actions.
- **Website audit:** flags externally hosted CDN runtime scripts as a medium-severity offline/dependency concern. Existing high/medium audit findings block completion until resolved.
- **Browser safety:** third-party cookies are disabled; navigation is restricted to HTTP/HTTPS and banking/payment/wallet URLs are blocked.
- **Signing hygiene:** passwords are no longer hard-coded in Gradle. Release signing uses environment variables or a private, untracked `local.properties` file. Keystores and local secrets are excluded from the source ZIP.
- **Regression tests added:** website stage-gate conditions and task-completion failure markers.

## Scope and verification limits

The current phone Website Builder remains a static HTML/CSS/vanilla-JavaScript builder. It does not create a real server/database/authentication/payment backend or deploy a live website. Those integrations require a backend/hosting provider and credentials; they are reported as external setup requirements rather than simulated.

The project could not be built or instrumented in this environment: the source tree does not contain Gradle wrapper scripts/JAR, and no Android SDK or installed Gradle executable is available. Source syntax and the Gemini tool-declaration JSON were checked, but Android compilation, APK installation, runtime behavior on a physical device, and the unit-test suite remain unverified.
