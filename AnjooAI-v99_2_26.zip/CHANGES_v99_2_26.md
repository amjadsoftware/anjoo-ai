# v99.2.26

Restored the fixed signing key (app/anjoo.keystore, same as v99.2.21) for debug and release builds. v99.2.25 removed it, so new builds failed to install over the old app with INSTALL_FAILED_UPDATE_INCOMPATIBLE. Only signing changed.
