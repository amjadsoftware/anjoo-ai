# v85: Kaam ke hisaab se model, multi-key, aur "kaun kya kar raha hai"

- Menu (+) → "🔑 Keys add karo": saari keys ek saath paste karo. Company khud pehchan li jati hai (AIza = Gemini, gsk_ = Groq, sk-or- = OpenRouter, sk-ant- = Claude ... baaqi ko check karke). Ek company ki kayi keys ho sakti hain.
- Har message ek kaam mein baanta jata hai: seedhi baat, phone ke kaam, coding, gehri soch/hisaab, likhna/tarjuma, photo/PDF, web. Us kaam ke liye sab se munasib model jawab deta hai; baaqi sab tayyar rehte hain.
- Ek key ki limit khatam ho to usi company ki doosri key foran lag jati hai; phir doosra model.
- Jawab ke end par: "🤖 Banaya: company · model · kaam · N aur models tayyar". Kaam ke dauran neeche live dikhta hai kaun sa model chal raha hai.
- Menu (+) → "🧭 Models aur keys": kaun si company/kitni keys/har model kis kaam ka, aur abhi har kaam kaun karega.
- Paid companies (OpenAI, Claude, xAI ...) tab hi istemal hoti hain jab unki key add ho; barabar score par free model ko tarjeeh milti hai.
- Settings → AI "Auto" band karne par sirf chuna hua model chalta hai.
- Naya: Errors.kt (har masla "kya hua / wajah / hal"), pichli baar crash ho to agli dafa wajah dikhti hai.


## v91: more companies, each with a direct key link

Added (with their models and the page where the key is made): Cloudflare Workers AI, NVIDIA NIM, Cohere,
Hugging Face, GitHub Models, Alibaba Qwen (DashScope, international), Z.ai (Zhipu GLM), Kilo AI, Chutes.

* Tap "Saari AI ke key links dekho" in AI, model and key. Each row opens the key page directly.
* Cloudflare needs two values in one key box: ACCOUNT_ID:API_TOKEN.
* Tavily, Jina, AssemblyAI, Codeium, Windsurf, Replit and Ampere are listed as links only. They are not chat AIs
  (or have no public chat key), so they have no models.
* All new companies are included in the keys export/import file and in Auto fallback (only if a key is saved).

## v99.1.62 provider-key and catalogue reliability update
- Added named-key aliases for Together AI, Fireworks, Nous, Moonshot/Kimi, Pollinations, Fal.ai, ElevenLabs, Azure Speech, Ollama and additional Hugging Face spellings.
- Added key-prefix recognition for Fireworks, Hugging Face, Chutes, GitHub and ElevenLabs.
- Model discovery now attempts live `/models` catalogues for providers that previously always returned a hard-coded model list; providers that do not expose model-list endpoints still use a lightweight chat probe for key recognition.
- Model selection includes the saved live catalogue, and automatic routing stops preferring a stale saved model once a live catalogue exists.
- Fal.ai keys explicitly labeled `fal=...` are saved without sending a paid image-generation request just to validate the key; the first real image generation request validates access.
- This improves provider recognition and reduces stale-model failures, but API availability still depends on each provider's key permissions, quota, endpoint, billing and current model catalogue.
