# Anjoo AI — JARVIS Mode (v99.1.61)

## What this adds
- One-tap **JARVIS Mode** in Settings → Voice and language.
- Configures wake-word mode (`Anjoo`), natural voice, spoken chat replies, notification reading, hologram/buddy display, and the Live voice engine.
- Restarts the voice service when enabling so the updated engine and wake-word settings take effect; disabling the mode stops background listening.
- Adds a JARVIS-specific behavior profile to the text and voice agent: plan multi-step tasks, use available tools, verify results, recover safely, and be honest about limits.
- Updates Android app version to 99.1.61 / local versionCode 99161.

## Setup on the phone
1. Install/build the updated project.
2. Open **Settings → AI, model and key** and add a valid Gemini API key with access to the configured Live model.
3. Open **Settings → Voice and language → Activate JARVIS Mode**.
4. Grant microphone and notification permissions when Android asks. For floating visuals, grant overlay permission. For screen taps/typing, enable Anjoo AI under Android Accessibility settings.
5. Keep battery usage unrestricted if the phone's battery manager is stopping the foreground service.
6. Say **“Anjoo”**, pause, then give a command. Say “Anjoo, ruko” or “stop” to interrupt where supported.

## Important real-world limits
- Android requires the user to grant permissions and may restrict microphone/background operation, especially after force-stop, reboot, battery restrictions, or vendor-specific power management.
- Wake-word recognition is software speech recognition, not a dedicated low-power hardware wake-word chip; accuracy and battery use vary by phone, language, network, and provider.
- Live voice, online research, AI coding and image generation depend on configured provider keys, model access, connectivity, quotas, and the tools implemented in the app.
- Phone control is limited to Android intents, enabled Accessibility actions, and granted permissions. It cannot bypass lock screens, security prompts, or app protections.
- This is a practical JARVIS-style assistant profile, not a fictional omniscient AI. It does not have universal device, camera, or internet access and should not be described as perfect.
- Calls, messages, purchases, public posts, and destructive actions must continue to use explicit confirmation/safety controls.

## Validation status for this source package
Source-level checks are performed when preparing the archive. An Android SDK/Gradle build and physical-device test must still be run in Android Studio or CI before treating this version as a tested release APK.
