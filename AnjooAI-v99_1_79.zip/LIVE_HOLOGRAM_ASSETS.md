# Live AI Hologram Assets (v99.1.77)

Five generated hologram artwork styles are bundled under `app/src/main/assets/holo/` and keyed out to transparent PNGs for use over the user's current screen.

Default: **Golden AI Agent** to coordinate with the warm Claude-like light appearance. Alternate choices: Golden Assistant, Blue-Cyan Agent, Blue Neon Assistant, Blue Cyber HUD.

In the app: **Settings → Live AI hologram style**. The selected style is saved as the `holoAgentStyle` preference and applies immediately to the in-app/live overlay view. The overlay is deliberately non-focusable and non-touchable; Android's window opacity is kept below the usual obscuring-touch threshold so taps reach the app underneath.

The HUD panels are visual artwork, not interactive controls. Their text may be decorative/static; actual app controls remain in Anjoo AI.
