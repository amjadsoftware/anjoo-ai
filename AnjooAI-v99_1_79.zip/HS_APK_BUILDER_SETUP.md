# HS APK Builder — One-time setup

HS can submit a saved project to GitHub Actions and download the generated APK to the phone. The Android source project is compiled natively when a complete Gradle Android project is found. A static website with `index.html` can instead be packaged as a WebView APK (HTML/CSS/JavaScript inside a small Android shell); that is not the same as rewriting the website into native Android UI.

## 1. Create a private build repository

1. Open https://github.com/new
2. Create a **PRIVATE** repository, for example `hs-apk-builder`, and initialize it with a README.

3. Do not use the Anjoo AI source-code repository. The builder uploads the selected project ZIP as a temporary asset to a GitHub Release in this private repository; it is not a normal source-code commit. After completion, HS attempts to delete the asset, release, and tag. If cleanup is blocked by GitHub permissions or a network failure, open the repository's Releases tab and manually delete the release named `HS temporary source ...`. GitHub Actions build logs and the installed workflow remain in that repository.

## 2. Create a fine-grained token

Create a GitHub fine-grained personal access token at https://github.com/settings/personal-access-tokens/new. Restrict it to the private build repository and grant:

- **Contents:** Read and write
- **Actions:** Read and write
- **Workflows:** Read and write

Keep the token private. By default HS encrypts it in local app storage using Android Keystore. Android clears that local storage on uninstall, so use the optional Supabase cloud vault below if you want to restore it after reinstall. Never paste the GitHub token into the AI prompt or project source.

## 3. Connect HS

Open **HS → Build APK**. Enter your repository as `username/hs-apk-builder` and the token, then press **Save & test connection**. The first build installs `.github/workflows/hs-build-apk.yml` into the repository automatically.

## 4. Build and install

1. Build the app/site in HS first so that it appears in saved projects.
2. Open **Build APK** from the HS project card or from Codixa.
3. Select **Auto detect**, **Native**, or **WebView APK** and press **Build APK**.
4. Keep Anjoo open while the cloud build runs. On success, HS downloads the APK to Android's **Downloads** folder and offers **Install now**.

## Build rules and limits

- Projects are uploaded as a temporary source ZIP release asset in your PRIVATE repository, not as a regular source-code commit. `.env` files, local Gradle properties, key stores, `.jks`, `.pem`, `.p12`, `keys.properties`, `.gradle`, `node_modules`, `build`, and `.git` paths are excluded from the project ZIP.
- The compressed project upload limit is 8 MB in this build. Remove build outputs, `node_modules`, and unneeded large media before retrying.
- Native mode requires a complete Gradle Android project including a `settings.gradle(.kts)` file and `app/build.gradle(.kts)`.
- Auto mode compiles a detected native Android project; otherwise it requires `index.html` and builds a WebView wrapper APK.
- Build failures are shown rather than reported as successes. Open the GitHub Actions build log to inspect Gradle/compiler errors.
- GitHub Actions must be enabled for the private repository, and its permissions/organization policies must allow the workflow to run.
- GitHub-hosted Actions artifacts are kept for 7 days, but an APK downloaded into the phone's Downloads folder remains there until the user removes it.


## 5. Optional: restore the GitHub token after uninstall/reinstall

This adds a private cloud vault to your own Supabase project. It stores one GitHub connection per signed-in Supabase user. The GitHub token is AES-GCM encrypted by the Edge Function before it is written to the database; the app receives it only after email OTP authentication. Do **not** share the Supabase service-role key or GitHub token.

### A. Create the table

1. Open your Supabase project dashboard. The project URL is prefilled in HS as `https://vzlgekjtgqpezuvqcawb.supabase.co`; change it only if that is not the correct project.
2. Open **SQL Editor → New query**.
3. Paste and run `supabase/migrations/202610240001_hs_github_token_vault.sql` from this project ZIP. The table has RLS enabled and no direct read/write policy for `anon` or `authenticated`; only the Edge Function's server-side service role accesses it.

### B. Deploy the Edge Function

1. In Supabase **Edge Functions**, create a function named `hs-github-token`.
2. Paste the full contents of `supabase/functions/hs-github-token/index.ts` from the ZIP.
3. Add the function secret `HS_TOKEN_ENCRYPTION_KEY` with a fresh random 64-character hex value (32 random bytes). Generate it in a trusted terminal with `openssl rand -hex 32`; never store that value in this source ZIP or any client app. Supabase supplies `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to deployed functions automatically.
4. Deploy the function with JWT verification enabled. The included `supabase/config.toml` sets `verify_jwt = true` when deploying through the Supabase CLI.
5. In **Authentication → Providers → Email**, enable email sign-in/OTP and configure email delivery. Test with an email address you control.

### C. Use the cloud vault in HS

1. Open **HS → APK Builder → Permanent cloud backup**.
2. Enter the project's **anon/public publishable key** from Supabase Project Settings → API Keys. This is a public client key, not the service-role key. If you build Anjoo from this repo's GitHub Actions workflow, add repository secret `HS_SUPABASE_ANON_KEY` under **Settings → Secrets and variables → Actions** with that public key as the value. The included workflow passes it into BuildConfig so a new APK can prefill it even after reinstall. Alternatively, paste it into HS; that local setting is cleared on uninstall.
3. Enter your email, tap **Send email code**, then enter the received OTP and tap **Verify & restore**.
4. On the first setup, connect GitHub and press **Back up GitHub token**. Successful GitHub connection also attempts a cloud backup if you are already signed in.
5. After reinstall, sign into the same Supabase user again using the email code; HS will restore the GitHub repository and token from the encrypted vault. You should not need to copy the GitHub token again.

If the function has not been deployed or the encryption secret/OTP provider is misconfigured, cloud backup will fail visibly. Local GitHub connection continues to work. Supabase's public key and project URL may need to be entered again after reinstall unless the public key was baked into the APK; the GitHub token itself is restored from cloud.
