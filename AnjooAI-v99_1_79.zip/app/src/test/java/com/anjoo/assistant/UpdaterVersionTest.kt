package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class UpdaterVersionTest {
    @Test fun ciBuildTagUsesAndroidVersionCode() {
        val parsed = UpdaterVersion.parse("build-1792000000", "Anjoo AI build 1792000000")!!
        assertEquals(1792000000L, parsed.code)
        assertTrue(parsed.usesAndroidVersionCode)
    }

    @Test fun semanticTagRemainsSupported() {
        val parsed = UpdaterVersion.parse("v99.1.61", "Anjoo AI release")!!
        assertEquals(99001061L, parsed.code)
        assertFalse(parsed.usesAndroidVersionCode)
    }

    @Test fun malformedReleaseVersionIsRejected() {
        assertNull(UpdaterVersion.parse("build-not-a-number", "nightly build"))
    }

    @Test fun ciUpdateComparesAndroidVersionCodes() {
        val release = UpdaterVersion.parse("build-1792000001", "Anjoo AI build")!!
        assertTrue(UpdaterVersion.isNewer(release, 1792000000L, "99.1.60"))
        assertFalse(UpdaterVersion.isNewer(release, 1792000001L, "99.1.60"))
    }

    @Test fun legacyUpdateComparesSemanticVersionName() {
        val release = UpdaterVersion.parse("v99.1.61", "Anjoo AI release")!!
        assertTrue(UpdaterVersion.isNewer(release, 1792000000L, "99.1.60 (main)"))
        assertFalse(UpdaterVersion.isNewer(release, 1792000000L, "99.1.61"))
    }
}
