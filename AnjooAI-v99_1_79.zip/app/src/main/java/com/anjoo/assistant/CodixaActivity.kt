package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Codixa: mobile coding-agent workspace for saved projects, files, activity, preview and export. */
class CodixaActivity : Activity() {
    private val bg = Color.rgb(249, 247, 243)
    private val surface = Color.rgb(255, 255, 255)
    private val surface2 = Color.rgb(242, 239, 233)
    private val ink = Color.rgb(48, 46, 42)
    private val muted = Color.rgb(117, 112, 104)
    private val accent = Color.rgb(67, 119, 84)
    private val border = Color.argb(45, 92, 81, 65)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, stroke: Int = border, radius: Int = 14) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        render()
    }

    private fun text(label: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }

    private fun button(label: String, primary: Boolean = false, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 12.5f
        setTextColor(if (primary) Color.WHITE else ink)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        background = rounded(if (primary) accent else surface2, if (primary) accent else border, 10)
        setPadding(dp(11), dp(9), dp(11), dp(9))
        setOnClickListener { action() }
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(surface, border, 0)
        }
        toolbar.addView(button("‹  Back") { finish() }, LinearLayout.LayoutParams(-2, -2))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("Codixa", 18f, ink, true))
        brand.addView(text("CODING WORKSPACE", 9.5f, accent, true).apply { letterSpacing = 0.1f })
        toolbar.addView(brand, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        toolbar.addView(button("+ New task", true) {
            finish()
            Toast.makeText(this, "Anjoo chat mein app, website, ya code change ka task likhein.", Toast.LENGTH_LONG).show()
        })
        root.addView(toolbar, LinearLayout.LayoutParams(-1, -2))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(20))
        }
        content.addView(text("Your projects", 25f, ink, true))
        content.addView(text("Open a workspace to inspect code, review project history, preview the app, or export files.", 13f, muted).apply {
            setLineSpacing(0f, 1.18f)
            setPadding(0, dp(5), 0, dp(15))
        })

        val search = EditText(this).apply {
            hint = "Search projects and files…"
            textSize = 14f
            setTextColor(ink)
            setHintTextColor(muted)
            isSingleLine = true
            background = rounded(surface, border, 12)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        content.addView(search, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val projectList = Coder.list(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list, LinearLayout.LayoutParams(-1, -2))
        fun fill(query: String = "") {
            list.removeAllViews()
            val q = query.trim()
            val projects = projectList.filter { dir ->
                q.isBlank() || Coder.name(dir).contains(q, true) ||
                    dir.name.contains(q, true) || Coder.readFiles(dir).keys.any { it.contains(q, true) }
            }
            if (projects.isEmpty()) {
                val empty = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(surface, border, 16)
                    setPadding(dp(16), dp(18), dp(16), dp(18))
                }
                empty.addView(text(if (q.isBlank()) "No projects yet" else "No matching projects", 17f, ink, true))
                empty.addView(text(
                    if (q.isBlank()) "Build an app or website in Anjoo chat. Saved Code Studio projects will appear here with their files, history and preview." else "Try another project name or file name.",
                    12.5f, muted
                ).apply { setPadding(0, dp(5), 0, dp(12)) })
                empty.addView(button("←  Start a task in Anjoo", true) { finish() }, LinearLayout.LayoutParams(-2, -2))
                list.addView(empty)
                return
            }
            for (dir in projects) list.addView(projectCard(dir), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        }
        fill()
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { fill(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })

        val scroll = ScrollView(this).apply {
            addView(content)
            isVerticalScrollBarEnabled = false
            clipToPadding = false
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("ANJOO AI  ·  CODEX-STYLE PROJECT WORKSPACE", 9.5f, muted, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(12))
        })
        setContentView(root)
    }

    private fun projectCard(dir: File): View {
        val files = Coder.readFiles(dir)
        val hasPreview = PreviewServer.entry(dir) != null
        val size = files.keys.sumOf { File(dir, it).length() }
        val modified = SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(Date(dir.lastModified()))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(surface, border, 16)
            setPadding(dp(15), dp(14), dp(15), dp(13))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val glyph = TextView(this).apply {
            text = "</>"; textSize = 12f; setTextColor(accent); gravity = Gravity.CENTER
            typeface = Typeface.MONOSPACE
            background = rounded(surface2, border, 10)
        }
        head.addView(glyph, LinearLayout.LayoutParams(dp(42), dp(42)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(text(Coder.name(dir), 16f, ink, true).apply { maxLines = 2 })
        titles.addView(text("${files.size} files · ${size / 1024} KB · $modified", 11f, muted).apply {
            setPadding(0, dp(4), 0, 0)
        })
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
        if (hasPreview) head.addView(TextView(this).apply {
            text = "PREVIEW READY"; textSize = 9f; setTextColor(accent); gravity = Gravity.CENTER
            background = rounded(Color.argb(22, Color.red(accent), Color.green(accent), Color.blue(accent)), accent, 8)
            setPadding(dp(7), dp(6), dp(7), dp(6))
        })
        card.addView(head)
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(12), 0, 0)
        }
        actions.addView(button("Open project", true) { projectActions(dir) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        if (hasPreview) actions.addView(button("Preview") {
            startActivity(Intent(this@CodixaActivity, ProjectPreviewActivity::class.java).putExtra("project", dir.absolutePath))
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(5) })
        card.addView(actions)
        card.setOnClickListener { projectActions(dir) }
        return card
    }

    private fun projectActions(dir: File) {
        val files = Coder.readFiles(dir)
        val history = Coder.history(dir)
        val options = mutableListOf("Open code files (${files.size})")
        if (history.isNotEmpty()) options.add("Project chat / history (${history.size} entries)")
        val hasPreview = PreviewServer.entry(dir) != null
        if (hasPreview) options.add("Open live preview")
        options.add("Build APK")
        options.add("Export project ZIP")
        AlertDialog.Builder(this).setTitle(Coder.name(dir)).setItems(options.toTypedArray()) { _, which ->
            when {
                options[which].startsWith("Open code files") -> showFiles(dir)
                options[which].startsWith("Project chat") -> showProjectChat(dir)
                options[which].startsWith("Open live") -> startActivity(Intent(this, ProjectPreviewActivity::class.java).putExtra("project", dir.absolutePath))
                options[which].startsWith("Build APK") -> startActivity(Intent(this, HsApkBuilderActivity::class.java).putExtra("project", dir.absolutePath))
                options[which].startsWith("Export") -> exportZip(dir)
            }
        }.show()
    }

    private fun showFiles(dir: File) {
        val files = Coder.readFiles(dir).toList()
        if (files.isEmpty()) {
            Toast.makeText(this, "Project mein files nahi hain.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this).setTitle("${Coder.name(dir)} — Code files")
            .setItems(files.map { "${it.first}  (${it.second.length} chars)" }.toTypedArray()) { _, i -> showSource(files[i].first, files[i].second) }
            .setNegativeButton("Close", null).show()
    }

    private fun showSource(name: String, source: String) {
        val tv = TextView(this).apply {
            text = source; textSize = 12f; typeface = Typeface.MONOSPACE; setTextColor(ink)
            setTextIsSelectable(true); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        AlertDialog.Builder(this).setTitle(name).setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Copy code") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText(name, source))
                Toast.makeText(this, "Code copied", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Close", null).show()
    }

    private fun showProjectChat(dir: File) {
        val history = Coder.history(dir)
        if (history.isEmpty()) {
            Toast.makeText(this, "Is project ki chat history abhi khaali hai.", Toast.LENGTH_SHORT).show()
            return
        }
        val transcript = history.joinToString("\n\n") { (role, message) -> (if (role == "u") "YOU" else "CODIXA / ANJOO AI") + ":\n" + message }
        val tv = TextView(this).apply {
            text = transcript; textSize = 13f; setTextColor(ink); setTextIsSelectable(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        AlertDialog.Builder(this).setTitle("${Coder.name(dir)} — Project chat")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Copy chat") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("${Coder.name(dir)} chat", transcript))
                Toast.makeText(this, "Project chat copied", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Close", null).show()
    }

    private fun exportZip(dir: File) {
        try {
            Dl.save(this, dir.name + ".zip", Coder.zip(dir))
        } catch (e: Exception) {
            Toast.makeText(this, "ZIP export nahi ho saka: ${e.message ?: "error"}", Toast.LENGTH_LONG).show()
        }
    }
}
