package com.anjoo.assistant

/** Shared budget and completion message for the foreground chat and background voice agent. */
internal object ToolLoopBudget {
    const val MAX_STEPS: Int = 40

    /** Returns an honest incomplete-state message only when the loop really exhausted its budget. */
    fun incompleteMessage(finishedNormally: Boolean, steps: Int): String? {
        if (finishedNormally || steps < MAX_STEPS) return null
        return "Anjoo ne ${MAX_STEPS} tool rounds ki limit poori kar li, is liye task abhi mukammal verify nahi hua. Aakhri verified result check karein ya kaam ko chhote hisson mein karwayein."
    }
}
