package com.anjoo.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Transparent, touch-through holographic AI agent artwork for Live Voice. */
class HoloAgentView(ctx: Context) : View(ctx), Runnable {
    data class Style(val label: String, val asset: String)

    companion object {
        // Warm styles come first to match the default Claude-like light/cream appearance.
        val styles = listOf(
            Style("Golden AI Agent", "holo/gold_agent.png"),
            Style("Golden Assistant", "holo/gold_assistant.png"),
            Style("Blue-Cyan Agent", "holo/blue_cyan.png"),
            Style("Blue Neon Assistant", "holo/blue_agent.png"),
            Style("Blue Cyber HUD", "holo/blue_cyber.png")
        )
    }

    private val density = resources.displayMetrics.density
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { alpha = 224 }
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.1f * density }
    private var bitmap: Bitmap? = null
    private var loadedStyle = -1
    private var running = false
    private val startedAt = SystemClock.uptimeMillis()

    init {
        // The live hologram is visual only. Touches always pass to the app underneath it.
        isClickable = false
        isFocusable = false
        isFocusableInTouchMode = false
        setOnTouchListener { _, _ -> false }
        importantForAccessibility = IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    private fun loadSelectedStyle() {
        val index = context.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
            .getInt("holoAgentStyle", 0).coerceIn(0, styles.lastIndex)
        if (index == loadedStyle && bitmap != null) return
        val decoded = try {
            context.assets.open(styles[index].asset).use { BitmapFactory.decodeStream(it) }
        } catch (_: Exception) { null }
        bitmap?.takeIf { it !== decoded && !it.isRecycled }?.recycle()
        bitmap = decoded
        loadedStyle = index
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        postOnAnimation(this)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(this)
        super.onDetachedFromWindow()
    }

    override fun run() {
        if (!running) return
        invalidate()
        postDelayed(this, 48L)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        loadSelectedStyle()
        val image = bitmap ?: return
        if (width <= 0 || height <= 0) return

        val dst = if (width / density > 300f) {
            // Full-screen overlay: preserve image proportions and crop only the outside edges.
            val scale = max(width.toFloat() / image.width, height.toFloat() / image.height)
            val dw = image.width * scale
            val dh = image.height * scale
            RectF((width - dw) / 2f, (height - dh) / 2f, (width + dw) / 2f, (height + dh) / 2f)
        } else {
            // In-app compact preview: fit the portrait visual in the small centered view.
            val scale = min(width.toFloat() / image.width, height.toFloat() / image.height)
            val dw = image.width * scale
            val dh = image.height * scale
            RectF((width - dw) / 2f, (height - dh) / 2f, (width + dw) / 2f, (height + dh) / 2f)
        }
        canvas.drawBitmap(image, null as Rect?, dst, imagePaint)

        // Small audio-reactive pulse over the hologram while listening/speaking; no buttons or text overlay.
        val state = OrbLevel.state()
        val level = max(OrbLevel.micLevel(), OrbLevel.outLevel())
        if (level > 0.035f || state == OrbState.THINKING || state == OrbState.CONNECTING) {
            val t = (SystemClock.uptimeMillis() - startedAt) / 1000f
            val cx = width / 2f
            val cy = height * 0.50f
            val maxR = min(width, height) * (if (width / density > 300f) 0.23f else 0.39f)
            val rgb = if (styles[loadedStyle].asset.contains("gold")) 0xFFFFC777.toInt() else 0xFF65DFFF.toInt()
            for (i in 0..1) {
                val p = ((t * 0.44f + i * 0.5f) % 1f)
                pulsePaint.color = rgb
                pulsePaint.alpha = ((1f - p) * (16f + level * 42f)).toInt().coerceIn(0, 48)
                pulsePaint.strokeWidth = (0.8f + (1f - p) * 1.1f) * density
                canvas.drawCircle(cx, cy, maxR * (0.48f + p * 0.72f) + sin(t * 3.1f) * density, pulsePaint)
            }
        }
    }
}
