package com.anjoo.assistant

/** Version parsing shared by the GitHub updater and its JVM regression tests. */
internal data class ParsedReleaseVersion(
    val code: Long,
    /** True for CI tags named build-<Android versionCode>; false for legacy v99.1.N tags. */
    val usesAndroidVersionCode: Boolean
)

internal object UpdaterVersion {
    private val buildTag = Regex("""^build-(\d+)$""", RegexOption.IGNORE_CASE)
    private val semanticVersion = Regex("""(\d+)[._](\d+)[._](\d+)""")

    fun parse(tag: String, releaseName: String): ParsedReleaseVersion? {
        val fromBuild = buildTag.matchEntire(tag.trim())?.groupValues?.get(1)?.toLongOrNull()
        if (fromBuild != null && fromBuild > 0L) {
            return ParsedReleaseVersion(fromBuild, usesAndroidVersionCode = true)
        }
        val semantic = semanticCode(tag) ?: semanticCode(releaseName)
        return semantic?.let { ParsedReleaseVersion(it, usesAndroidVersionCode = false) }
    }

    fun semanticCode(value: String): Long? {
        val m = semanticVersion.find(value) ?: return null
        val (major, minor, patch) = m.destructured
        val a = major.toLongOrNull() ?: return null
        val b = minor.toLongOrNull() ?: return null
        val c = patch.toLongOrNull() ?: return null
        if (a > 999_999L || b > 999L || c > 999L) return null
        return a * 1_000_000L + b * 1_000L + c
    }

    fun isNewer(
        release: ParsedReleaseVersion,
        installedVersionCode: Long,
        installedVersionName: String
    ): Boolean {
        val installed = if (release.usesAndroidVersionCode) {
            installedVersionCode
        } else {
            semanticCode(installedVersionName) ?: 0L
        }
        return release.code > installed
    }
}
