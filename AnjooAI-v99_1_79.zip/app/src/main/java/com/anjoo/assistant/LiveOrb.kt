package com.anjoo.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.View
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Real-time audio levels + voice state shared by the in-app and floating holographic orb. */
enum class OrbState { IDLE, CONNECTING, LISTENING, THINKING, SPEAKING, ERROR }

object OrbLevel {
    @Volatile private var mic = 0f
    @Volatile private var micAt = 0L
    @Volatile private var out = 0f
    @Volatile private var outAt = 0L
    @Volatile private var currentState = OrbState.IDLE

    fun feedMic(s: ShortArray, n: Int) {
        if (n <= 0) return
        var sum = 0.0
        for (i in 0 until n) { val v = s[i] / 32768.0; sum += v * v }
        mic = min(1f, (sqrt(sum / n) * 7.0).toFloat())
        micAt = SystemClock.uptimeMillis()
    }

    fun feedOut(pcm: ByteArray) {
        val n = pcm.size / 2
        if (n <= 0) return
        var sum = 0.0
        var i = 0
        while (i + 1 < pcm.size) {
            val v = ((pcm[i].toInt() and 255) or (pcm[i + 1].toInt() shl 8)).toShort() / 32768.0
            sum += v * v; i += 2
        }
        out = min(1f, (sqrt(sum / n) * 6.0).toFloat())
        outAt = SystemClock.uptimeMillis()
    }

    fun outLevel(): Float = if (SystemClock.uptimeMillis() - outAt < 260) out else 0f
    fun micLevel(): Float = if (SystemClock.uptimeMillis() - micAt < 260) mic else 0f
    fun state(): OrbState = currentState

    /** Translate the existing live-voice status into a visible orb state. */
    fun setStatus(text: String) {
        val s = text.lowercase(Locale.ROOT)
        currentState = when {
            listOf("error", "failed", "fail ho", "masla", "issue", "nahi ho saka", "band ho gaya").any { s.contains(it) } -> OrbState.ERROR
            listOf("jud raha", "connect", "dobara jud", "reconnect").any { s.contains(it) } -> OrbState.CONNECTING
            listOf("soch", "kaam kar", "processing", "thinking", "run kar", "check kar").any { s.contains(it) } -> OrbState.THINKING
            listOf("sun raha", "boliye", "listening", "ruk gaya", "bataiye").any { s.contains(it) } -> OrbState.LISTENING
            listOf("band", "idle", "standby").any { s.contains(it) } -> OrbState.IDLE
            else -> currentState
        }
    }

    fun reset() {
        currentState = OrbState.IDLE
        mic = 0f; out = 0f; micAt = 0L; outAt = 0L
    }
}

/**
 * Transparent, audio-reactive assistant visual for live voice.
 * No opaque backdrop is drawn, so the app or content underneath stays visible.
 */
class LiveOrb(ctx: Context) : View(ctx), Runnable {
    init {
        // This visual must never intercept taps intended for the screen beneath it.
        isClickable = false
        isFocusable = false
        isFocusableInTouchMode = false
        setOnTouchListener { _, _ -> false }
    }

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) }
    private val textStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    private val cyan = Color.parseColor("#62F0FF")
    private val violet = Color.parseColor("#8F72FF")
    private val blue = Color.parseColor("#388BFF")
    private val mint = Color.parseColor("#55F4C7")
    private val lavender = Color.parseColor("#D4B9FF")
    private val amber = Color.parseColor("#FFB86B")
    private val whiteBlue = Color.parseColor("#E5FDFF")
    private val baseColors = intArrayOf(cyan, violet, blue, lavender, mint, whiteBlue)
    private val blobs = baseColors.map { c ->
        RadialGradient(0f, 0f, 100f,
            intArrayOf(withA(c, 138), withA(c, 72), withA(c, 0)),
            floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
    }
    private var mask: RadialGradient? = null
    private var haloGradient: RadialGradient? = null
    private var coreGradient: RadialGradient? = null
    private var cachedHaloAccent = 0
    private var cachedCoreAccent = 0
    private val oval = RectF()
    private var amp = 0f
    private var running = false
    private val t0 = SystemClock.uptimeMillis()

    private fun withA(c: Int, a: Int) = Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun accentFor(state: OrbState): Int = when (state) {
        OrbState.CONNECTING, OrbState.THINKING -> violet
        OrbState.LISTENING -> cyan
        OrbState.SPEAKING -> mint
        OrbState.ERROR -> amber
        OrbState.IDLE -> blue
    }

    private fun labelFor(state: OrbState): String = when (state) {
        OrbState.IDLE -> "STANDBY"
        OrbState.CONNECTING -> "CONNECTING"
        OrbState.LISTENING -> "LISTENING"
        OrbState.THINKING -> "PROCESSING"
        OrbState.SPEAKING -> "SPEAKING"
        OrbState.ERROR -> "NEEDS ATTENTION"
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = min(w, h) / 2f
        mask = RadialGradient(w / 2f, h / 2f, r,
            intArrayOf(Color.WHITE, Color.WHITE, Color.TRANSPARENT),
            floatArrayOf(0f, 0.72f, 1f), Shader.TileMode.CLAMP)
        haloGradient = null; coreGradient = null
        cachedHaloAccent = 0; cachedCoreAccent = 0
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; postOnAnimation(this) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(this); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow && !running) { running = true; postOnAnimation(this) }
        if (visibility != VISIBLE) running = false
    }

    override fun run() {
        if (!running) return
        val target = max(OrbLevel.micLevel(), OrbLevel.outLevel())
        amp += (target - amp) * (if (target > amp) 0.36f else 0.075f)
        invalidate()
        postOnAnimation(this)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f; val cy = h / 2f
        val r = min(w, h) * 0.48f
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val stateFromStatus = OrbLevel.state()
        val state = when {
            stateFromStatus == OrbState.ERROR -> OrbState.ERROR
            OrbLevel.outLevel() > 0.045f -> OrbState.SPEAKING
            OrbLevel.micLevel() > 0.055f -> OrbState.LISTENING
            else -> stateFromStatus
        }
        val accent = accentFor(state)
        val fast = if (state == OrbState.SPEAKING || state == OrbState.LISTENING) 1.4f else 1f
        val breathe = 0.025f * sin(t * 1.35f)
        val swell = 1f + amp * 0.24f + breathe

        // Atmospheric halo and softly moving nebula.
        if (haloGradient == null || cachedHaloAccent != accent) {
            haloGradient = RadialGradient(cx, cy, r * 1.02f,
                intArrayOf(withA(accent, 25), withA(violet, 14), withA(blue, 7), Color.TRANSPARENT),
                floatArrayOf(0f, 0.46f, 0.76f, 1f), Shader.TileMode.CLAMP)
            cachedHaloAccent = accent
        }
        fill.shader = haloGradient
        c.drawCircle(cx, cy, r * (0.95f + amp * 0.08f), fill)
        fill.shader = null

        val save = c.saveLayer(0f, 0f, w, h, null)
        for (i in blobs.indices) {
            val speed = (0.24f + 0.075f * i) * fast
            val ph = i * 1.82f
            val orbit = r * (0.18f + 0.055f * (i % 3)) * (1f + amp * 0.62f)
            val x = cx + cos(t * speed + ph) * orbit
            val y = cy + sin(t * speed * 1.18f + ph * 0.72f) * orbit * 0.82f
            val rad = r * (0.48f + 0.105f * ((i + 1) % 3)) * swell
            paint.shader = blobs[i]
            c.save(); c.translate(x, y); c.scale(rad / 100f, rad / 100f)
            c.drawCircle(0f, 0f, 100f, paint)
            c.restore()
        }
        paint.shader = null
        maskPaint.shader = mask
        c.drawRect(0f, 0f, w, h, maskPaint)
        c.restoreToCount(save)

        // Three delicate elliptical orbit paths give the orb a cinematic, physical presence.
        val pulse = 0.5f + 0.5f * sin(t * (1.8f + amp) * fast)
        ring.color = withA(accent, (24 + pulse * 38 + amp * 28).toInt())
        ring.strokeWidth = 1.05f * d
        c.save(); c.rotate(t * 13f * fast, cx, cy)
        oval.set(cx - r * 0.86f, cy - r * 0.43f, cx + r * 0.86f, cy + r * 0.43f)
        c.drawOval(oval, ring)
        c.restore()
        ring.color = withA(violet, (18 + pulse * 34).toInt())
        ring.strokeWidth = 0.9f * d
        c.save(); c.rotate(-t * 18f * fast + 58f, cx, cy)
        oval.set(cx - r * 0.77f, cy - r * 0.31f, cx + r * 0.77f, cy + r * 0.31f)
        c.drawOval(oval, ring)
        c.restore()
        ring.color = withA(whiteBlue, (15 + amp * 34).toInt())
        ring.strokeWidth = 0.8f * d
        c.save(); c.rotate(t * 8f * fast + 118f, cx, cy)
        oval.set(cx - r * 0.66f, cy - r * 0.23f, cx + r * 0.66f, cy + r * 0.23f)
        c.drawOval(oval, ring)
        c.restore()

        // Thin outer energy circle and audio-reactive ripples.
        ring.color = withA(accent, (28 + pulse * 34).toInt())
        ring.strokeWidth = 1.35f * d
        c.drawCircle(cx, cy, r * (0.76f + breathe * 0.5f), ring)
        if (amp > 0.025f || state == OrbState.THINKING || state == OrbState.CONNECTING) {
            for (k in 0..2) {
                val ph = ((t * (0.22f + amp * 0.55f) + k * 0.335f) % 1f)
                val radius = r * (0.58f + 0.44f * ph + amp * 0.12f)
                ring.color = withA(accent, (abs(1f - ph) * (25f + amp * 70f)).toInt().coerceIn(0, 85))
                ring.strokeWidth = (0.8f + (1f - ph) * 1.1f) * d
                c.drawCircle(cx, cy, radius, ring)
            }
        }

        // Tiny moving orbit nodes, like a restrained HUD rather than a toy animation.
        for (i in 0..3) {
            val a = t * (0.42f + i * 0.07f) * fast + i * (Math.PI.toFloat() / 2f)
            val rr = r * (0.81f + (i % 2) * 0.055f)
            val x = cx + cos(a) * rr
            val y = cy + sin(a) * rr * 0.70f
            fill.color = withA(if (i % 2 == 0) accent else lavender, (48 + pulse * 74).toInt())
            c.drawCircle(x, y, (1.5f + amp * 1.6f) * d, fill)
            fill.color = Color.TRANSPARENT
        }

        // Small illuminated core marker is drawn before text so labels stay sharp.
        if (coreGradient == null || cachedCoreAccent != accent) {
            coreGradient = RadialGradient(cx, cy - r * 0.04f, r * 0.20f,
                intArrayOf(withA(whiteBlue, 38), withA(accent, 16), Color.TRANSPARENT),
                floatArrayOf(0f, 0.43f, 1f), Shader.TileMode.CLAMP)
            cachedCoreAccent = accent
        }
        fill.shader = coreGradient
        c.drawCircle(cx, cy - r * 0.04f, r * 0.20f, fill)
        fill.shader = null

        // Minimal live-state indicator only. The old centered "ANJOO BUDDY" title is removed.
        val stateLabel = labelFor(state)
        text.textSize = 7.4f * d
        text.color = withA(accent, 205)
        text.alpha = 205
        textStroke.textSize = text.textSize
        textStroke.strokeWidth = 1.4f * d
        textStroke.color = withA(Color.parseColor("#11142B"), 80)
        val labelY = cy + r * 0.30f
        c.drawText(stateLabel, cx, labelY, textStroke)
        c.drawText(stateLabel, cx, labelY, text)
    }
}
