package com.anjoo.assistant

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Random
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

private const val PIF = 3.1415927f
private const val TWO_PI = 6.2831855f
private const val NSYM = 5          // five shockwave colours

/**
 * Opening scene (all drawn with code, tap to skip):
 *  a bright flash, then the Anjoo logo (same shape as the app icon, in Claude orange) bursts out with
 *  multi-colour shockwaves, god rays, a lens flare and sparks over a deep-space nebula that turns warm orange.
 */
class SplashActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var opened = false
    private var anim: ValueAnimator? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private class Scene(ctx: Context) : View(ctx) {
        var t = 0f // seconds; 0 = the flash
        private val d = resources.displayMetrics.density
        private val rnd = Random(7)
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private val rect = RectF()
        private val CLAUDE = Color.rgb(217, 119, 87)
        private val logo = ctx.resources.getDrawable(R.drawable.ic_launcher_foreground, null).mutate().also { it.setTint(CLAUDE) }
        private var hit = false

        // colours of the shockwave rings
        private val ringCols = intArrayOf(
            Color.rgb(205, 225, 255), Color.rgb(255, 60, 70), Color.rgb(70, 225, 255),
            Color.rgb(150, 255, 70), Color.rgb(255, 95, 230)
        )

        // ---- stars
        private val NST = 110
        private val stX = FloatArray(NST) { rnd.nextFloat() }
        private val stY = FloatArray(NST) { rnd.nextFloat() }
        private val stS = FloatArray(NST) { 0.6f + rnd.nextFloat() * 1.8f }
        private val stP = FloatArray(NST) { rnd.nextFloat() * 6.28f }
        private val stL = FloatArray(NST) { 0.3f + rnd.nextFloat() * 0.9f }

        // ---- sparks of the burst
        private val spAng = FloatArray(56) { rnd.nextFloat() * TWO_PI }
        private val spSpd = FloatArray(56) { 90f + rnd.nextFloat() * 260f }
        private val spSz = FloatArray(56) { 1.2f + rnd.nextFloat() * 2.6f }

        private fun ease(x: Float): Float { val k = x.coerceIn(0f, 1f); return 1f - (1f - k) * (1f - k) * (1f - k) }
        private fun smooth(x: Float): Float { val k = x.coerceIn(0f, 1f); return k * k * (3f - 2f * k) }

        private fun back(x: Float): Float {
            val k = x.coerceIn(0f, 1f) - 1f
            return 1f + 2.70158f * k * k * k + 1.70158f * k * k
        }

        private fun mix(a: Int, b: Int, k: Float): Int {
            val q = k.coerceIn(0f, 1f)
            return Color.rgb(
                (Color.red(a) + (Color.red(b) - Color.red(a)) * q).toInt(),
                (Color.green(a) + (Color.green(b) - Color.green(a)) * q).toInt(),
                (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * q).toInt()
            )
        }

        private fun argb(a: Float, col: Int): Int =
            Color.argb((255f * a.coerceIn(0f, 1f)).toInt(), Color.red(col), Color.green(col), Color.blue(col))

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w == 0f) return
            val cx = w / 2f
            val cy = h * 0.40f

            if (!hit) { hit = true; try { performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) } catch (e: Exception) {} }

            // camera shake that dies down after the flash
            c.save()
            if (t < 0.35f) {
                val shake = 7f * d * (1f - t / 0.35f)
                c.translate(sin(t * 83f) * shake, cos(t * 71f) * shake)
            }

            drawBackground(c, w, h, cx, cy)
            drawLogo(c, w, h, cx, cy)

            c.restore()

            // the flash
            if (t <= 0.4f) c.drawColor(Color.argb((235 * (1f - t / 0.4f)).toInt(), 255, 255, 255))

            // scanlines + vignette for the film look
            p.style = Paint.Style.FILL
            p.color = Color.argb(18, 0, 0, 0)
            var yy = 0f
            while (yy < h) { c.drawRect(0f, yy, w, yy + d, p); yy += 3f * d }
            p.shader = RadialGradient(cx, h / 2f, hypot(w, h) * 0.6f,
                intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(150, 0, 0, 0)), floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
            p.shader = null

            // letterbox bars open up just after the flash
            val bar = h * 0.10f * (1f - ease((t - 0.2f) / 0.7f))
            if (bar > 0f) {
                p.color = Color.BLACK
                c.drawRect(0f, 0f, w, bar, p)
                c.drawRect(0f, h - bar, w, h, p)
            }
        }

        private fun nebula(c: Canvas, x: Float, y: Float, r: Float, col: Int, a: Float) {
            p.shader = RadialGradient(x, y, r, intArrayOf(argb(a, col), argb(0f, col)), null, Shader.TileMode.CLAMP)
            c.drawCircle(x, y, r, p)
            p.shader = null
        }

        /** Deep-space nebula and stars; it turns warm Claude orange right after the flash. */
        private fun drawBackground(c: Canvas, w: Float, h: Float, cx: Float, cy: Float) {
            p.style = Paint.Style.FILL
            val warm = smooth(t / 1.2f)
            p.shader = LinearGradient(0f, 0f, 0f, h,
                mix(Color.rgb(6, 3, 20), Color.rgb(26, 10, 6), warm), mix(Color.rgb(2, 2, 10), Color.rgb(8, 4, 4), warm), Shader.TileMode.CLAMP)
            c.drawRect(-20f * d, -20f * d, w + 20f * d, h + 20f * d, p)
            p.shader = null

            val inten = 0.24f
            val orange = Color.rgb(217, 119, 87)
            val x1 = (w * (0.22f + 0.08f * sin(t * 0.3f)))
            val y1 = (h * (0.18f + 0.05f * cos(t * 0.25f)))
            val x2 = (w * (0.82f + 0.06f * cos(t * 0.27f)))
            val y2 = (h * (0.52f + 0.06f * sin(t * 0.22f)))
            val x3 = (w * (0.35f + 0.07f * sin(t * 0.21f)))
            val y3 = (h * (0.88f + 0.04f * cos(t * 0.3f)))
            nebula(c, x1, y1, w * 0.95f, mix(Color.rgb(125, 45, 210), orange, warm), inten)
            nebula(c, x2, y2, w * 0.85f, mix(Color.rgb(35, 100, 230), Color.rgb(240, 150, 110), warm), inten * 0.9f)
            nebula(c, x3, y3, w * 0.95f, mix(Color.rgb(220, 45, 150), Color.rgb(180, 80, 60), warm), inten * 0.8f)
            nebula(c, cx, cy, w * 0.7f, mix(Color.rgb(40, 200, 200), orange, warm), 0.10f)

            // stars: they twinkle and drift down
            p.strokeCap = Paint.Cap.ROUND
            for (i in 0 until NST) {
                val x = stX[i] * w
                val y = ((stY[i] + t * 0.012f * stL[i]) % 1f) * h
                val tw = 0.35f + 0.65f * (0.5f + 0.5f * sin(t * (1.5f + stL[i] * 2f) + stP[i]))
                val col = if (i % 5 == 0) Color.rgb(255, 215, 190) else if (i % 7 == 0) Color.rgb(190, 210, 255) else Color.WHITE
                p.color = argb(tw, col)
                c.drawCircle(x, y, stS[i] * d * 0.7f, p)
            }

            // shooting stars
            p.style = Paint.Style.STROKE
            for (k in 0..1) {
                val q = (t * 0.55f + k * 0.8f) % 2.4f
                if (q < 0.45f) {
                    val f = q / 0.45f
                    val hx = w * (0.10f + 0.5f * k) + f * w * 0.38f
                    val hy = h * (0.05f + 0.10f * k) + f * h * 0.13f
                    for (s in 0 until 7) {
                        p.strokeWidth = (2.2f - s * 0.28f) * d
                        p.color = argb((1f - f) * (1f - s / 7f), Color.WHITE)
                        c.drawLine(hx - s * 11f * d, hy - s * 3.3f * d, hx - (s + 1) * 11f * d, hy - (s + 1) * 3.3f * d, p)
                    }
                }
            }
            p.style = Paint.Style.FILL
        }

        private fun drawLogo(c: Canvas, w: Float, h: Float, cx: Float, cy: Float) {
            val lt = t
            val ga = ease(lt / 0.6f)
            p.style = Paint.Style.FILL

            // god rays
            val ra = smooth(lt / 0.8f) * 0.30f
            if (ra > 0.01f) {
                val rr = hypot(w, h) * 0.7f
                p.shader = RadialGradient(cx, cy, rr, intArrayOf(argb(ra, Color.rgb(240, 160, 120)), argb(0f, CLAUDE)), null, Shader.TileMode.CLAMP)
                for (k in 0 until 14) {
                    val a = k * TWO_PI / 14f + t * 0.15f
                    path.reset()
                    path.moveTo(cx, cy)
                    path.lineTo(cx + cos(a - 0.07f) * rr, cy + sin(a - 0.07f) * rr)
                    path.lineTo(cx + cos(a + 0.07f) * rr, cy + sin(a + 0.07f) * rr)
                    path.close()
                    c.drawPath(path, p)
                }
                p.shader = null
            }

            // glow behind the logo
            val gr = 190f * d * (1f + 0.04f * sin(t * 3f))
            p.shader = RadialGradient(cx, cy, gr,
                intArrayOf(Color.argb((170 * ga).toInt(), 217, 119, 87), Color.argb((60 * ga).toInt(), 201, 100, 66), Color.argb(0, 60, 30, 20)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, gr, p)
            p.shader = null

            // shockwaves: one ring in each symbiote colour, then Claude orange
            p.style = Paint.Style.STROKE
            for (k in 0..5) {
                val rl = lt - 0.09f * k
                if (rl < 0f || rl > 1.4f) continue
                val f = rl / 1.4f
                p.strokeWidth = (2f + 6f * (1f - f)) * d
                p.color = argb(0.85f * (1f - f), if (k < NSYM) ringCols[k] else CLAUDE)
                c.drawCircle(cx, cy, rl * w * 0.85f, p)
            }

            // two tilted orbit rings
            p.strokeWidth = 2f * d
            for (r in 0..1) {
                c.save()
                c.rotate(if (r == 0) t * 40f else -t * 30f + 60f, cx, cy)
                rect.set(cx - 125f * d, cy - 46f * d, cx + 125f * d, cy + 46f * d)
                p.color = Color.argb((120 * ga).toInt(), 217, 119, 87)
                c.drawOval(rect, p)
                c.restore()
            }
            p.style = Paint.Style.FILL

            // logo pops out (same shape as the app icon, Claude orange)
            val k = back(lt / 0.8f)
            val s = (150f * d * k).toInt()
            if (s > 0) {
                logo.alpha = (255 * ease(lt / 0.3f)).toInt()
                logo.setBounds((cx - s / 2f).toInt(), (cy - s / 2f).toInt(), (cx + s / 2f).toInt(), (cy + s / 2f).toInt())
                logo.draw(c)
            }

            // anamorphic lens flare
            val fa = ga * (0.55f + 0.45f * sin(t * 5f))
            p.shader = LinearGradient(0f, cy, w, cy,
                intArrayOf(Color.argb(0, 217, 119, 87), Color.argb((230 * fa).toInt(), 245, 190, 165), Color.argb(0, 217, 119, 87)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, cy - 1.5f * d, w, cy + 1.5f * d, p)
            p.shader = null

            // spark burst in all the colours
            if (lt < 1.6f) {
                for (i in spAng.indices) {
                    val dist = spSpd[i] * d * lt * (1f - lt * 0.25f)
                    val a = 1f - lt / 1.6f
                    p.color = when (i % 4) {
                        0 -> argb(a, Color.WHITE)
                        1 -> argb(a, CLAUDE)
                        2 -> argb(a, ringCols[i % NSYM])
                        else -> argb(a, Color.rgb(240, 170, 140))
                    }
                    c.drawCircle(cx + cos(spAng[i]) * dist, cy + sin(spAng[i]) * dist, spSz[i] * d * a, p)
                }
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val base = Color.parseColor("#07061A")
        window.setBackgroundDrawable(ColorDrawable(base))
        try { window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = base } catch (e: Exception) {}

        val root = FrameLayout(this)
        val scene = Scene(this)
        root.addView(scene, FrameLayout.LayoutParams(-1, -1))

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; alpha = 0f; translationY = dp(20).toFloat() }
        texts.addView(TextView(this).apply {
            text = "ANJOO AI"; textSize = 34f; setTextColor(Color.WHITE); letterSpacing = 0.22f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setShadowLayer(dp(16).toFloat(), 0f, 0f, Color.parseColor("#88D97757"))
        })
        texts.addView(TextView(this).apply {
            text = "Talk. Chat. Create. Code."; textSize = 14f; setTextColor(Color.parseColor("#F0B49A")); letterSpacing = 0.1f
            setPadding(0, dp(8), 0, 0)
        })
        val top = (resources.displayMetrics.heightPixels * 0.40f + dp(112)).toInt()
        root.addView(texts, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = top })

        val ver = TextView(this).apply {
            text = "v" + BuildConfig.VERSION_NAME.substringBefore(" (")
            textSize = 12f; setTextColor(Color.parseColor("#F0B49A"))
            alpha = 0f; letterSpacing = 0.12f
        }
        root.addView(ver, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).apply { bottomMargin = dp(44) })
        ver.animate().alpha(0.85f).setDuration(800).setStartDelay(900).start()

        setContentView(root)
        texts.animate().alpha(1f).translationY(0f).setDuration(800).setStartDelay(600).start()

        val started = System.nanoTime()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 60000
            interpolator = LinearInterpolator()
            addUpdateListener { scene.t = (System.nanoTime() - started) / 1e9f; scene.invalidate() }
            start()
        }
        ui.postDelayed({ openApp() }, 3200L)
        root.setOnClickListener { openApp() }
    }

    private fun openApp() {
        if (opened) return
        opened = true
        val i = Intent(this, MainActivity::class.java)
        intent?.extras?.let { i.putExtras(it) }
        startActivity(i)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        anim?.cancel()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}