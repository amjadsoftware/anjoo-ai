# Put keys.properties here (see keys.properties.example in the project root)

master_instructions.txt contains Anjoo AI base behavior rules.
