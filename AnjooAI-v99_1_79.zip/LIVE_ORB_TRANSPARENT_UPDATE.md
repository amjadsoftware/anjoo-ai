# Live AI Agent Overlay — v99.1.77

The former center orb is replaced by a transparent, full-screen holographic AI-agent visual for Live Voice. Five generated styles are bundled as transparent PNGs under `app/src/main/assets/holo/`:

- Golden AI Agent (default, warm cream/gold to match light appearance)
- Golden Assistant
- Blue-Cyan Agent
- Blue Neon Assistant
- Blue Cyber HUD

Choose one from **Settings → Live AI hologram style**. The chosen style is stored in app preferences and refreshes immediately while Live Voice is active.

The overlay is non-focusable and non-touchable. Its WindowManager alpha is limited to 0.65 so it remains translucent and underlying apps can receive taps. Decorative HUD artwork is static artwork; actual buttons remain in the underlying app.
