import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json; charset=utf-8",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: corsHeaders });
}
function toB64(bytes: Uint8Array): string {
  let raw = "";
  for (let i = 0; i < bytes.length; i++) raw += String.fromCharCode(bytes[i]);
  return btoa(raw);
}
function fromB64(value: string): Uint8Array {
  const raw = atob(value);
  return Uint8Array.from(raw, (ch) => ch.charCodeAt(0));
}
function encryptionKey(): Promise<CryptoKey> {
  const hex = Deno.env.get("HS_TOKEN_ENCRYPTION_KEY") ?? "";
  if (!/^[0-9a-fA-F]{64}$/.test(hex)) {
    throw new Error("HS_TOKEN_ENCRYPTION_KEY secret must be 64 hex characters (32 random bytes).");
  }
  const bytes = new Uint8Array(hex.match(/.{2}/g)!.map((part) => parseInt(part, 16)));
  return crypto.subtle.importKey("raw", bytes, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "POST required" }, 405);

  try {
    const authorization = req.headers.get("Authorization") ?? "";
    const match = authorization.match(/^Bearer\s+(.+)$/i);
    if (!match) return json({ error: "Sign in first" }, 401);
    const accessToken = match[1];
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    if (!supabaseUrl || !serviceKey) return json({ error: "Supabase function secrets are incomplete" }, 500);

    // The service key is server-side only. The user's access token is verified before any row is accessed.
    const admin = createClient(supabaseUrl, serviceKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });
    const { data: authData, error: authError } = await admin.auth.getUser(accessToken);
    if (authError || !authData.user) return json({ error: "Invalid or expired sign-in session" }, 401);

    const payload = await req.json().catch(() => ({}));
    const action = String(payload?.action ?? "");
    const userId = authData.user.id;

    if (action === "store") {
      const repo = String(payload?.repo ?? "").trim();
      const token = String(payload?.token ?? "");
      if (!/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(repo)) return json({ error: "Invalid repository format" }, 400);
      if (token.length < 20 || token.length > 500 || /\s/.test(token)) return json({ error: "Invalid token format" }, 400);
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const key = await encryptionKey();
      const encrypted = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(token));
      const { error } = await admin.from("hs_github_token_vault").upsert({
        user_id: userId,
        repo,
        encrypted_token: toB64(new Uint8Array(encrypted)),
        nonce: toB64(iv),
        updated_at: new Date().toISOString(),
      }, { onConflict: "user_id" });
      if (error) return json({ error: "Could not save encrypted token" }, 500);
      return json({ ok: true, message: "Encrypted GitHub connection backed up" });
    }

    if (action === "get") {
      const { data, error } = await admin.from("hs_github_token_vault")
        .select("repo, encrypted_token, nonce")
        .eq("user_id", userId)
        .maybeSingle();
      if (error) return json({ error: "Could not read cloud token backup" }, 500);
      if (!data) return json({ hasToken: false });
      const key = await encryptionKey();
      const decrypted = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: fromB64(data.nonce) },
        key,
        fromB64(data.encrypted_token),
      );
      return json({ hasToken: true, repo: data.repo, token: new TextDecoder().decode(decrypted) });
    }

    if (action === "delete") {
      const { error } = await admin.from("hs_github_token_vault").delete().eq("user_id", userId);
      if (error) return json({ error: "Could not delete cloud token backup" }, 500);
      return json({ ok: true, deleted: true });
    }

    return json({ error: "Unknown action" }, 400);
  } catch (error) {
    // Never log request bodies or tokens.
    const message = error instanceof Error ? error.message : "Internal error";
    return json({ error: message.slice(0, 250) }, 500);
  }
});
