-- HS stores one encrypted GitHub connection per signed-in Supabase user.
-- The Android client does not get direct table access; the Edge Function uses service_role.
create table if not exists public.hs_github_token_vault (
  user_id uuid primary key references auth.users(id) on delete cascade,
  repo text not null check (repo ~ '^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$'),
  encrypted_token text not null,
  nonce text not null,
  updated_at timestamptz not null default now()
);

alter table public.hs_github_token_vault enable row level security;
revoke all on table public.hs_github_token_vault from anon, authenticated;
grant all on table public.hs_github_token_vault to service_role;
