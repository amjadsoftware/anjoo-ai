package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** HS is a HappySeeds-inspired, prompt-first app-builder workspace powered by Anjoo's existing builder. */
class HSActivity : Activity() {
    private val bg = Color.rgb(249, 247, 243)
    private val surface = Color.rgb(255, 255, 255)
    private val surface2 = Color.rgb(242, 239, 233)
    private val ink = Color.rgb(48, 46, 42)
    private val muted = Color.rgb(117, 112, 104)
    private val green = Color.rgb(67, 119, 84)
    private val border = Color.argb(45, 92, 81, 65)
    private var selectedMode = Mode.WEB
    private var draft = ""
    private var planFirst = true
    private var showAdvancedOptions = false
    private var promptBox: EditText? = null
    private val selectedFeatures = linkedSetOf<String>()

    private enum class Mode { WEB, ANDROID, MEDIA }
    private data class Template(val icon: String, val name: String, val description: String, val prompt: String)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, stroke: Int = border, radius: Int = 15) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }
    private fun text(label: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = label; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private fun action(label: String, primary: Boolean = false, click: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER
        setTextColor(if (primary) Color.WHITE else ink)
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        background = rounded(if (primary) green else surface2, if (primary) green else border, 11)
        setPadding(dp(13), dp(11), dp(13), dp(11))
        setOnClickListener { click() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = rounded(surface, border, 0)
        }
        toolbar.addView(action("‹ Back") { finish() }, LinearLayout.LayoutParams(-2, -2))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("HS", 19f, ink, true))
        brand.addView(text("APP BUILDER", 9f, green, true).apply { letterSpacing = 0.1f })
        toolbar.addView(brand, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        toolbar.addView(action("Projects") {
            startActivity(Intent(this@HSActivity, CodixaActivity::class.java))
        }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        toolbar.addView(action("⬇ APK", true) {
            startActivity(Intent(this@HSActivity, HsApkBuilderActivity::class.java))
        })
        root.addView(toolbar, LinearLayout.LayoutParams(-1, -2))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(19), dp(16), dp(22))
        }
        content.addView(text("What do you want to build?", 25f, ink, true))
        content.addView(text("Describe your idea. HS chooses a suitable build workflow.", 13f, muted).apply {
            setPadding(0, dp(5), 0, dp(17))
        })

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(surface2, border, 13)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val webTab = TextView(this)
        val androidTab = TextView(this)
        val mediaTab = TextView(this)
        fun styleTab(view: TextView, label: String, active: Boolean) {
            view.text = label
            view.textSize = 12f
            view.gravity = Gravity.CENTER
            view.setTextColor(if (active) Color.WHITE else muted)
            view.typeface = Typeface.create("sans-serif-medium", if (active) Typeface.BOLD else Typeface.NORMAL)
            view.background = rounded(if (active) green else Color.TRANSPARENT, if (active) green else Color.TRANSPARENT, 10)
            view.setPadding(dp(5), dp(12), dp(5), dp(12))
        }
        styleTab(webTab, "Web app", selectedMode == Mode.WEB)
        styleTab(androidTab, "Android", selectedMode == Mode.ANDROID)
        styleTab(mediaTab, "Creative", selectedMode == Mode.MEDIA)
        webTab.setOnClickListener { draft = promptBox?.text?.toString() ?: draft; selectedMode = Mode.WEB; render() }
        androidTab.setOnClickListener { draft = promptBox?.text?.toString() ?: draft; selectedMode = Mode.ANDROID; render() }
        mediaTab.setOnClickListener { draft = promptBox?.text?.toString() ?: draft; selectedMode = Mode.MEDIA; render() }
        tabs.addView(webTab, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(3) })
        tabs.addView(androidTab, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(1); marginEnd = dp(1) })
        tabs.addView(mediaTab, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(3) })
        content.addView(tabs, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(surface, green, 17)
            setPadding(dp(14), dp(13), dp(14), dp(13))
        }
        composer.addView(text(when (selectedMode) {
            Mode.WEB -> "Website or web app"
            Mode.ANDROID -> "Native Android app"
            Mode.MEDIA -> "Image, video or creative work"
        }, 13f, ink, true))
        val et = EditText(this).apply {
            hint = when (selectedMode) {
                Mode.WEB -> "Example: inventory app with stock, sales, reports and login…"
                Mode.ANDROID -> "Example: Android attendance app with employees and Excel export…"
                Mode.MEDIA -> "Example: cinematic product ad for TikTok…"
            }
            setText(draft)
            setTextColor(ink)
            setHintTextColor(Color.rgb(151, 145, 135))
            textSize = 14f
            gravity = Gravity.TOP or Gravity.START
            minLines = 4
            maxLines = 7
            setPadding(dp(1), dp(10), dp(1), dp(10))
            background = null
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { draft = s?.toString() ?: "" }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        promptBox = et
        composer.addView(et, LinearLayout.LayoutParams(-1, -2))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        controls.addView(action(if (showAdvancedOptions) "Options ↑" else "Options ↓") {
            draft = promptBox?.text?.toString() ?: draft
            showAdvancedOptions = !showAdvancedOptions
            render()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        controls.addView(action("Examples") { showExamples() }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        controls.addView(action("Build with AI  ↗", true) { beginBuild() })
        composer.addView(controls, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        content.addView(composer, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        if (showAdvancedOptions) {
            val advanced = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(surface, border, 14)
                setPadding(dp(13), dp(12), dp(13), dp(12))
            }
            val plan = CheckBox(this).apply {
                text = "Plan before building"
                textSize = 13f
                setTextColor(ink)
                isChecked = planFirst
                buttonTintList = android.content.res.ColorStateList.valueOf(green)
                setOnCheckedChangeListener { _, checked -> planFirst = checked }
            }
            advanced.addView(plan)
            if (selectedMode != Mode.MEDIA) {
                advanced.addView(text("Extra features (optional)", 12f, muted, true).apply { setPadding(0, dp(8), 0, dp(8)) })
                val choices = if (selectedMode == Mode.ANDROID)
                    listOf("Login & roles", "Local database", "Notifications", "Camera / file upload", "Admin dashboard", "API / backend")
                else listOf("Login & roles", "Database & saved data", "Payments & subscriptions", "AI features / API", "Admin dashboard", "SEO metadata")
                choices.chunked(2).forEach { pair ->
                    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    pair.forEachIndexed { index, label ->
                        row.addView(capabilityChip(label), LinearLayout.LayoutParams(0, -2, 1f).apply {
                            if (index == 0) rightMargin = dp(4) else leftMargin = dp(4)
                        })
                    }
                    advanced.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
                }
            }
            content.addView(advanced, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        }


        content.addView(text("Tip: describe the required features and how the result should work. Add keys or hosting only when the project actually needs them.", 11.5f, muted).apply {
            setPadding(dp(2), dp(14), dp(2), dp(2))
            setLineSpacing(dp(2).toFloat(), 1.0f)
        })

        // ── APK Download card ─────────────────────────────────────────────
        val apkCard = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.argb(18, 67, 119, 84)); cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.argb(55, 67, 119, 84))
            }
            setPadding(dp(13), dp(14), dp(13), dp(14))
        }
        val apkInfo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        apkInfo.addView(text("Download APK", 14f, green, true))
        apkInfo.addView(text("App ban jaye to seedha APK compile aur download karein", 11.5f, muted).apply { setPadding(0, dp(3), 0, 0) })
        apkCard.addView(apkInfo, LinearLayout.LayoutParams(0, -2, 1f))
        apkCard.addView(action("Build & Download  ↓", true) {
            startActivity(Intent(this@HSActivity, HsApkBuilderActivity::class.java))
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
        apkCard.setOnClickListener { startActivity(Intent(this@HSActivity, HsApkBuilderActivity::class.java)) }
        content.addView(apkCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(4) })
        // ─────────────────────────────────────────────────────────────────────

        val scroll = ScrollView(this).apply {
            addView(content)
            isVerticalScrollBarEnabled = false
            clipToPadding = false
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showExamples() {
        val examples = when (selectedMode) {
            Mode.WEB -> appTemplates().take(5)
            Mode.ANDROID -> androidTemplates().take(5)
            Mode.MEDIA -> mediaTemplates().take(5)
        }
        AlertDialog.Builder(this)
            .setTitle("Choose an example")
            .setItems(examples.map { "${it.icon}  ${it.name} — ${it.description}" }.toTypedArray()) { _, index ->
                draft = examples[index].prompt
                promptBox?.setText(draft)
                promptBox?.setSelection(draft.length)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun tag(label: String) = TextView(this).apply {
        text = label; textSize = 9f; setTextColor(green); typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        background = rounded(Color.argb(30, 125, 222, 158), Color.argb(80, 125, 222, 158), 9)
        setPadding(dp(8), dp(6), dp(8), dp(6))
    }

    private fun capabilityChip(label: String): View {
        val active = selectedFeatures.contains(label)
        return TextView(this).apply {
            text = (if (active) "✓  " else "+  ") + label
            textSize = 11.2f; setTextColor(if (active) green else muted)
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(if (active) Color.argb(27, 125, 222, 158) else surface, if (active) green else border, 10)
            setPadding(dp(9), dp(10), dp(7), dp(10))
            setOnClickListener {
                draft = promptBox?.text?.toString() ?: draft
                if (!selectedFeatures.add(label)) selectedFeatures.remove(label)
                render()
            }
        }
    }

    private fun appTemplates() = listOf(
        Template("⌂", "Business website", "Services, pricing, contact", "Build a polished, responsive business website with Home, Services, Pricing, About and Contact sections. Make navigation, contact form validation and all visible buttons work. Add SEO metadata and realistic demo content. My business details: [add details]."),
        Template("▣", "Online store", "Products, cart and checkout", "Build a responsive online store with product catalogue, search/filter, product details, shopping cart, quantity controls, checkout UI, order summary and an admin-ready product structure. Use sample products and clearly mark any payment integration that requires credentials."),
        Template("◷", "Booking app", "Calendar, slots and accounts", "Build a complete booking web app with calendar/date selection, available time slots, customer details, booking confirmation, cancellation flow and an admin schedule view. Validate forms and persist demo data. Explain backend and authentication setup requirements."),
        Template("▤", "Business tool", "Dashboard, data and reports", "Build a professional business management tool with dashboard KPIs, searchable table, create/edit/delete records, filters, export to CSV, form validation and persistent demo data. Make every visible control work and include empty, loading and error states."),
        Template("✧", "Mini game", "Playable, mobile-friendly", "Build a polished, fully playable mobile-friendly browser game with clear instructions, score, restart button, win/loss states, responsive controls and satisfying visual feedback. No dead buttons or placeholder gameplay."),
        Template("◈", "AI-powered app", "Chat, prompts and settings", "Build an AI-powered web app interface with chat/prompt input, conversation history, settings, responsive states and a clean provider/API configuration panel. Never hardcode secrets; clearly separate demo behavior from a connected AI backend."),
        Template("♙", "Client portal", "Login, roles and records", "Build a client portal with sign-in UI, role-aware dashboard layouts, profile/settings, searchable records and an admin management area. Include secure-backend implementation guidance; do not claim real authentication until connected and tested."),
        Template("⌘", "Custom from scratch", "Your idea, your design", "Plan and build this project from scratch based on my full idea. Create all source files and a realistic interactive preview. Ask only a necessary clarifying question; otherwise make reasonable assumptions and document them.")
    )

    private fun androidTemplates() = listOf(
        Template("▦", "Business app", "Native dashboard and records", "Build a complete native Android business management app in Kotlin with Gradle, Dashboard, searchable records, add/edit/delete forms, reports, settings and persistent local storage. Create a proper Android Studio project with settings.gradle.kts, root build.gradle.kts, app/build.gradle.kts, AndroidManifest.xml, Kotlin source and resources. Also create an interactive index.html preview of the same workflows. No dead buttons; include a README and build instructions."),
        Template("✓", "Task manager", "Tasks, reminders and filters", "Build a complete native Android task manager in Kotlin with task creation/editing, priorities, due dates, filters, search, completion, statistics, preferences and local persistence. Include a complete Gradle project, permissions only where needed, tests for pure logic, an interactive index.html preview, and README. Use a polished responsive UI and verify source consistency."),
        Template("▤", "Inventory app", "Stock, sales and reports", "Build a native Android inventory and sales app in Kotlin with product CRUD, stock movements, low-stock alerts, searchable inventory, sales records, totals, CSV export and locally saved data. Provide all Android Gradle files and resources, a real interactive index.html preview mirroring core screens, sample data, validation, and a README with exact build steps."),
        Template("◈", "Chat app", "Conversations and settings", "Build a native Android messaging app interface in Kotlin with conversation list, message thread, composer, attachment picker mock, unread status, search and settings. Persist local demo conversations. Do not claim real remote messaging/authentication without a backend. Include a complete Gradle Android project, matching interactive index.html preview, and README."),
        Template("⌂", "Booking app", "Calendar and appointments", "Build a native Android booking app in Kotlin with date/time selection, available slots, customer form, booking confirmation/cancellation, appointment list and admin schedule screen. Validate fields and save bookings locally for the demo. Include all Android Gradle files, required source/resources, matching interactive index.html preview, and README."),
        Template("⌘", "Custom Android app", "Your idea, built from scratch", "Plan and build my requested native Android app in Kotlin. Generate a complete importable Android Studio Gradle project with settings.gradle.kts, root build.gradle.kts, app/build.gradle.kts, AndroidManifest.xml, source Kotlin files, resources, and required dependencies. Also generate a working interactive index.html preview of the same main screens. Add tests where practical, run all checks available, and document any external service or credential required. Never claim a successful APK build until the cloud build result confirms it.")
    )

    private fun mediaTemplates() = listOf(
        Template("▧", "Product image", "Premium product visual", "Create a premium commercial product image concept for: [describe product]. Define composition, lighting, background, brand mood, camera feel and clean visual hierarchy. Preserve accurate product details and avoid extra text unless requested."),
        Template("▶", "Promo video", "Short ad for social media", "Create a short, high-quality promotional video concept for: [product/business]. Include scene-by-scene timing, camera movement, transitions, voiceover, subtitles and a strong call to action. Format for vertical 9:16 social media unless otherwise specified."),
        Template("▤", "Social campaign", "Post, caption and variants", "Create a complete social media campaign for: [product/service], including 3 visual directions, platform-appropriate captions, hooks, call-to-action variants and a suggested posting sequence. Keep all claims truthful and brand-consistent."),
        Template("◉", "Image to video", "Animate a reference image", "Turn the supplied/reference product image into a cinematic image-to-video brief. Preserve the subject and branding; add natural camera motion, subtle environmental movement, realistic lighting and a clean ending frame."),
        Template("✦", "Brand kit", "Logo direction and colours", "Create a cohesive brand kit for: [brand], including logo direction, colour palette, typography guidance, social post layout, profile image concept and usage rules. Explain each design choice and generate usable assets where supported."),
        Template("▣", "Video recreation", "Use a reference structure", "Analyse the provided reference video or link if accessible. Describe its scene structure, timing, transitions and visual style, then create a new original version for: [subject], without copying protected brand assets or exact footage." )
    )

    private fun templateCard(template: Template): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(surface, border, 15)
            setPadding(dp(12), dp(12), dp(12), dp(12)); isClickable = true
            setOnClickListener {
                draft = template.prompt
                promptBox?.setText(draft)
                promptBox?.setSelection(draft.length)
                Toast.makeText(this@HSActivity, "Template added — edit the prompt, then Build with AI.", Toast.LENGTH_SHORT).show()
            }
        }
        card.addView(text(template.icon, 21f, green, true))
        card.addView(text(template.name, 13.5f, ink, true).apply { setPadding(0, dp(7), 0, dp(3)) })
        card.addView(text(template.description, 11f, muted).apply { setLineSpacing(dp(1).toFloat(), 1.0f) })
        card.addView(text("Remix this idea  →", 10.5f, green, true).apply { setPadding(0, dp(11), 0, 0) })
        return card
    }

    private fun beginBuild() {
        val raw = promptBox?.text?.toString()?.trim().orEmpty()
        if (raw.isBlank()) {
            Toast.makeText(this, "Pehle batao kya banana hai.", Toast.LENGTH_SHORT).show()
            promptBox?.requestFocus()
            return
        }
        val feats = if (selectedFeatures.isNotEmpty())
            "\n\nADDITIONAL CAPABILITIES: " + selectedFeatures.joinToString(", ") +
            ". Implement all of these fully in the actual project. For auth/database/payments include secure integration points; label any credential or hosted backend required — do not pass off a mock as production-connected."
        else ""

        val instruction = when (selectedMode) {
            Mode.ANDROID -> buildString {
                append("HS ANDROID — MASTER BUILD\n")
                if (planFirst) append(
                    "PLAN PHASE (required, then build without stopping):\n" +
                    "• Screen map with nav flow\n• Data model with all fields\n• Every library and why\n" +
                    "• File/class structure\n• Acceptance criteria per feature\n• Edge cases and risk items\n\n"
                )
                append(
                    "QUALITY STANDARD: Production-grade, installable on Android 8+ (minSdk 26, compileSdk 35, targetSdk 35). " +
                    "Output a COMPLETE, compilable Gradle project: settings.gradle.kts, root build.gradle.kts, app/build.gradle.kts, " +
                    "app/src/main/AndroidManifest.xml, all Kotlin source files, all XML layouts, drawables, strings.xml, colors.xml, themes.xml, " +
                    "proguard-rules.pro, and a root README.md. No placeholder TODO comments — every function must be fully implemented.\n\n" +

                    "ARCHITECTURE: MVVM (ViewModel + LiveData/StateFlow), Repository pattern, Room for local DB, " +
                    "Hilt for DI where appropriate. Use Kotlin coroutines (not threads). " +
                    "Separate concerns: UI layer, domain/use-case layer, data layer.\n\n" +

                    "UI/UX: Material 3 components (MaterialButton, TextInputLayout, RecyclerView with DiffUtil, " +
                    "BottomNavigationView / NavigationDrawer as fits the app, Snackbar for feedback, " +
                    "ShimmerFrameLayout or ProgressBar for loading states). " +
                    "Every screen has empty-state, loading-state and error-state handling. " +
                    "Support dark theme via themes.xml. Adaptive icons (res/mipmap-anydpi-v26).\n\n" +

                    "DATA: Room database with proper @Entity, @Dao, @Database, migrations table. " +
                    "DataStore or SharedPreferences for settings. Export to Excel/CSV via Apache POI or simple CSV writer where relevant.\n\n" +

                    "CODE QUALITY: All Kotlin, no Java mixing. Null safety everywhere. " +
                    "Extension functions for repetitive UI code. Meaningful variable and function names. " +
                    "Inline comments on complex logic. No hardcoded strings — all in strings.xml.\n\n" +

                    "VERIFICATION: After writing all files, re-read key files, check for missing imports, " +
                    "unresolved references and manifest entries for every Activity/Service/Receiver. " +
                    "Fix all compile errors found before summarizing.\n\n" +

                    "APK WORKFLOW: The project root must contain settings.gradle.kts so HS APK Builder can compile it directly " +
                    "via GitHub Actions (Gradle assembleRelease). Include a signed release config stub in app/build.gradle.kts.\n\n" +

                    "USER REQUEST:\n" + raw + feats +

                    "\n\nDELIVERY: List every created file with its path. " +
                    "State what works out-of-the-box, what needs an API key or backend, and exact steps to open in Android Studio and run."
                )
            }

            Mode.WEB -> buildString {
                append("HS WEB — MASTER BUILD\n")
                if (planFirst) append(
                    "PLAN PHASE (required, then build without stopping):\n" +
                    "• Page/route map with user flows\n• Component tree\n• Data model and state management approach\n" +
                    "• Library choices and justification\n• Acceptance criteria per feature\n\n"
                )
                append(
                    "QUALITY STANDARD: A fully functional, production-ready web app — not a wireframe or demo stub. " +
                    "Every button, form and navigation item must actually work. " +
                    "Use semantic HTML5, modern CSS (variables, flexbox/grid, clamp() for responsive typography) and clean ES6+ JS " +
                    "(or React/Vue/Svelte if appropriate for complexity). " +
                    "One self-contained index.html is fine for simple apps; " +
                    "multi-file projects must include all CSS and JS files.\n\n" +

                    "UI/UX: Mobile-first responsive layout (works on 320px to 1440px). " +
                    "Loading states, empty states and error states for every async operation. " +
                    "Smooth transitions (200–300 ms). Accessible: proper ARIA labels, keyboard navigation, " +
                    "color-contrast ratio ≥ 4.5:1. Dark mode via prefers-color-scheme or toggle.\n\n" +

                    "DATA: Use localStorage or IndexedDB for persistence so data survives refresh. " +
                    "Seed with 5–10 realistic demo records so the preview looks live, not empty.\n\n" +

                    "CODE QUALITY: No inline styles beyond CSS vars. " +
                    "Components/modules separated by concern. " +
                    "Input validation with clear error messages. " +
                    "No console errors on load. Minify-ready structure.\n\n" +

                    "VERIFICATION: After writing all files, re-read index.html and main JS. " +
                    "Check every event listener is wired, every referenced function exists, all CSS classes are defined. " +
                    "Fix any missing pieces before summary.\n\n" +

                    "APK OPTION: The project's index.html can be packaged as a WebView APK via HS APK Builder. " +
                    "Keep all assets relative-path so they load from file:///android_asset/.\n\n" +

                    "USER REQUEST:\n" + raw + feats +

                    "\n\nDELIVERY: List every created file. State how to open in a browser and how to connect any backend/API needed."
                )
            }

            Mode.MEDIA -> buildString {
                append("HS CREATIVE STUDIO — MASTER BUILD\n")
                if (planFirst) append("PLAN PHASE: Outline intended output, scene/design structure and acceptance criteria, then create.\n\n")
                append(
                    "QUALITY STANDARD: Production-ready creative output. Use every available image/video/design tool. " +
                    "For each asset: full scene description, dimensions, colour palette, font choices, motion notes if video. " +
                    "If a tool is unavailable, provide a professional prompt/storyboard ready to paste into Midjourney, " +
                    "RunwayML or CapCut — never claim a file was created when it was not.\n\n" +
                    "USER REQUEST:\n" + raw
                )
            }
        }

        val intent = Intent(this, MainActivity::class.java).apply {
            putExtra("habit_prompt", instruction)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(intent)
        finish()
    }
}