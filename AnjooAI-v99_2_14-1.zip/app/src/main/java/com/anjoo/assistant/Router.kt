package com.anjoo.assistant

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/** One AI model Anjoo can talk to: which company, which key (the first one; more keys are tried by [Router.keysFor]), which model. */
class Cand(val pv: Provider, val key: String, val model: String) {
    val id: String get() = pv.id + "|" + model
    val label: String get() = pv.id + " / " + model
}

/** What a request is mostly about. Every model is scored for each of these, and the best one answers. */
enum class Task(val label: String, val hint: String) {
    CHAT("seedhi baat", "tez aur halka model"),
    PHONE("phone ke kaam", "tools sahi chalane wala tez model"),
    CODE("coding", "code ka mahir model"),
    THINK("gehri sochna / hisaab", "bara reasoning model"),
    WRITE("likhna / tarjuma", "acha likhne wala model"),
    VISION("photo / PDF", "tasveer aur PDF samajhne wala model"),
    WEB("web / taaza khabar", "Gemini (search ke saath)")
}

/**
 * Picks which model answers, and learns which ones work.
 *
 * - Every message is sorted into a [Task] (coding, photo, phone command, ...) from its words, attachments and modes.
 * - Every model with a saved key is scored for that task (size, class, speed, special skills such as vision),
 *   and the best one answers. All of them stay ready; only ONE does the work.
 * - A company can have several keys. When one key runs out of limit, the next key of the same company is used at once.
 * - If a model still fails the next best one is tried. Models that worked and answered fast rank higher, failed ones rest.
 * - What it learns is saved on the phone (and in backups / the keys file).
 * - The chosen AI in Settings gets a small bonus, so it wins when two models are equally good.
 */
object Router {

    private class Stat {
        var ok = 0
        var fail = 0
        var consecFail = 0
        var avgMs = 0L
        var coolUntil = 0L
        var lastCode = 0
        var lastFailureAt = 0L
    }

    /** One key of one company: how often used (to spread the load) and when it last hit a limit. */
    private class KeyStat {
        var use = 0
        var consec = 0
        var coolUntil = 0L
        var code = 0   // last error code that put the key to rest (429 = limit, 401/402/403 = refused)
    }

    private val stats = HashMap<String, Stat>()
    private val keyStats = HashMap<String, KeyStat>()
    private const val MAX_TRIES = 25   // auto mode: every model with a key gets its turn

    @Volatile private var stickyId: String? = null
    @Volatile private var stickyUntil = 0L

    /** Text for the screen, e.g. "groq / openai/gpt-oss-120b". Empty until the first answer. */
    @Volatile var lastUsed: String = ""

    // ------------------------------------------------------------ what happened in this run (per thread)

    /** One model that did part of the work in the current run. */
    class Used(val company: String, val model: String, val task: Task, val ms: Long)

    private val runLog = ThreadLocal<ArrayList<Used>>()

    /** Forces the task for the current thread (for example Code Studio is always "coding"). */
    val taskOverride = ThreadLocal<Task?>()

    /** Called with a short live line ("who is working now") while a request runs on this thread. */
    val live = ThreadLocal<((String) -> Unit)?>()

    fun beginRun() { runLog.set(ArrayList()) }

    private fun note(text: String) { try { live.get()?.invoke(text) } catch (e: Exception) {} }

    /** A tool that is not a chat model (picture maker, voice) can record itself, so the footer shows it too. */
    fun noteUsed(company: String, model: String, task: Task) {
        val l = runLog.get() ?: return
        if (l.none { it.company == company && it.model == model }) l.add(Used(company, model, task, 0))
    }

    private fun company(pv: Provider) = pv.label.substringBefore("  ").trim()

    /**
     * The line shown under an answer: who made it, for which kind of work, and how many other models are ready.
     * Empty when nothing was recorded (for example a reply that did not use any AI).
     */
    fun footer(): String {
        val l = runLog.get() ?: return ""
        runLog.remove()
        if (l.isEmpty()) return ""
        val p = Providers.prefsRef
        val names = l.map { it.company + " · " + it.model.substringAfterLast('/') }.distinct()
        val shown = if (names.size <= 2) names.joinToString(" + ") else names.take(2).joinToString(" + ") + " +" + (names.size - 2)
        val task = l.first().task
        val total = if (p != null) universe(p).size else 0
        val others = maxOf(0, total - names.size)
        return "🤖 Banaya: " + shown + "  ·  " + task.label + (if (others > 0) "  ·  " + others + " aur models tayyar" else "")
    }

    // ------------------------------------------------------------ memory (kept on the phone)

    @Volatile private var loaded = false

    /** Reads the saved notes once per app start. Called from Providers.load. */
    @Synchronized fun load(p: SharedPreferences) {
        if (loaded) return
        loaded = true
        importJson(p.getString("routerStats", "") ?: "")
    }

    @Synchronized private fun save() {
        val p = Providers.prefsRef ?: return
        try { p.edit().putString("routerStats", exportJson()).apply() } catch (e: Exception) {}
    }

    @Synchronized fun exportJson(): String {
        val st = JSONObject()
        for ((id, s) in stats) {
            if (s.ok + s.fail == 0) continue
            st.put(id, JSONObject().put("ok", s.ok).put("fail", s.fail).put("cf", s.consecFail).put("ms", s.avgMs)
                .put("cool", s.coolUntil).put("lc", s.lastCode).put("lf", s.lastFailureAt))
        }
        return JSONObject().put("stats", st).put("sticky", stickyId ?: "").put("until", stickyUntil).put("last", lastUsed).toString()
    }

    @Synchronized fun importJson(text: String) {
        if (text.isBlank()) return
        try {
            val root = JSONObject(text)
            root.optJSONObject("stats")?.let { st ->
                val it = st.keys()
                while (it.hasNext()) {
                    val id = it.next()
                    val o = st.getJSONObject(id)
                    val s = stat(id)
                    s.ok = o.optInt("ok"); s.fail = o.optInt("fail"); s.consecFail = o.optInt("cf")
                    s.avgMs = o.optLong("ms"); s.coolUntil = o.optLong("cool")
                    s.lastCode = o.optInt("lc"); s.lastFailureAt = o.optLong("lf")
                }
            }
            lastUsed = root.optString("last", "")
        } catch (e: Exception) { /* bad notes are ignored; they build up again */ }
    }

    // ------------------------------------------------------------ what is this request about?

    private val CODE_RX = Regex("(\\bcode\\b|coding|\\bbug\\b|traceback|exception|compile|\\bdebug|function|script|python|kotlin|java\\b|javascript|typescript|\\bhtml\\b|\\bcss\\b|\\bsql\\b|regex|\\bapi\\b|algorithm|program|github|gradle|android studio|website bana|app bana|project bana|apk|\\bjson\\b|\\bnode\\b|\\breact\\b|flutter)")
    private val THINK_RX = Regex("(hisaab|hisab|calculat|solve|\\bmath|equation|proof|logic|reason|step by step|analy[sz]|compare|tafseel|gehri|gehra|\\bwhy\\b|kyun|strategy|\\bplan\\b|decide|pros and cons|derive|puzzle|probability|statistics)")
    private val WRITE_RX = Regex("(likho|likh do|likh kar|essay|article|story|kahani|letter|\\bemail\\b|\\bmail\\b|caption|poem|shayari|speech|\\bblog|report|summar|translate|tarjuma|tarjama|rewrite|proofread|paragraph|cv\\b|resume)")
    private val PHONE_RX = Regex("(\\bcall\\b|\\bsms\\b|message bhej|whatsapp|alarm|timer|reminder|yaad dila|kholo|\\bopen\\b|volume|torch|flashlight|wifi|wi-fi|bluetooth|brightness|screenshot|\\btap\\b|swipe|contact|battery|music|chalao|band karo|laga do|lagao|\\bset\\b|notification|screen)")

    private fun realUserTurn(contents: JSONArray): JSONObject? {
        for (i in contents.length() - 1 downTo 0) {
            val c = contents.optJSONObject(i) ?: continue
            if (c.optString("role", "user") != "user") continue
            val ps = c.optJSONArray("parts") ?: continue
            for (j in 0 until ps.length()) { val t = ps.optJSONObject(j)?.optString("text", "") ?: ""; if (t.isNotBlank()) return c }
        }
        return null
    }

    /** Sorts a request into a [Task]. Second value: true when it carries a PDF (fewer models can read those). */
    fun taskFor(contents: JSONArray, thinking: Boolean, grounded: Boolean, withTools: Boolean, maxTokens: Int): Pair<Task, Boolean> {
        taskOverride.get()?.let { return Pair(it, false) }
        val turn = realUserTurn(contents)
        val ps = turn?.optJSONArray("parts")
        val sb = StringBuilder()
        var media = false
        var pdf = false
        if (ps != null) for (j in 0 until ps.length()) {
            val o = ps.optJSONObject(j) ?: continue
            if (o.has("text")) sb.append(o.optString("text")).append(' ')
            val d = o.optJSONObject("inlineData")
            if (d != null) { media = true; if (d.optString("mimeType") == "application/pdf") pdf = true }
        }
        val t = sb.toString().lowercase().take(3000)
        val task = when {
            media -> Task.VISION
            grounded -> Task.WEB
            t.contains("```") || CODE_RX.containsMatchIn(t) || maxTokens >= 16000 -> Task.CODE
            thinking -> Task.THINK
            withTools && PHONE_RX.containsMatchIn(t) -> Task.PHONE
            THINK_RX.containsMatchIn(t) -> Task.THINK
            WRITE_RX.containsMatchIn(t) -> Task.WRITE
            else -> Task.CHAT
        }
        return Pair(task, pdf)
    }

    // ------------------------------------------------------------ how good is each model at each task?

    class Prof(val vision: Boolean, val pdf: Boolean, val tools: Boolean, val score: Map<Task, Int>) {
        fun best(): Int = score.values.maxOrNull() ?: 0
    }

    private val profCache = HashMap<String, Prof>()

    private val SMALL_RX = Regex("(lite|nano|mini|small|(^|[^0-9])(1|3|4|7|8)b\\b|instant|haiku|e2b|e4b|flash-8b)")
    private val BIG_RX = Regex("(\\bpro\\b|-pro|opus|sonnet|fable|mythos|gpt-5|gpt-4\\.1|gpt-4o|120b|405b|70b|235b|480b|550b|671b|ultra|large|grok-4|grok-3\\b|reasoner|\\bo3\\b|\\bo1\\b|\\bo4\\b|3\\.8-flash|3\\.6-flash|2\\.5-flash\\b)")
    private val CODER_RX = Regex("(coder|codestral|devstral|-code\\b|code-)")
    private val REASON_RX = Regex("(reasoner|\\br1\\b|thinking|\\bo[134]\\b|-pro|\\bpro\\b|opus|gpt-5|ultra|120b|nemotron|gpt-oss|qwen3|grok-4|fable)")
    /** Newer strong coders (names the older rules did not know), so they rank high for coding and thinking. */
    private val STRONG_RX = Regex("(deepseek-v4|glm-5|kimi-k2\\.[5-9]|kimi-k3|qwen3\\.[5-9]|qwen3-coder|minimax-m[2-9]|hermes-4-405b)")
    private val NO_TOOLS_RX = Regex("(reasoner|\\br1\\b|gemma|\\bo1-|prompt-guard|distill)")

    fun profile(pv: Provider, model: String): Prof = synchronized(profCache) {
        profCache.getOrPut(pv.id + "|" + model) { buildProfile(pv, model) }
    }

    private fun buildProfile(pv: Provider, model: String): Prof {
        val m = model.lowercase()
        val small = SMALL_RX.containsMatchIn(m)
        val big = !small && BIG_RX.containsMatchIn(m)
        val coder = CODER_RX.containsMatchIn(m)
        val reasoner = !small && REASON_RX.containsMatchIn(m)
        val sc = HashMap<Task, Int>()
        for (t in Task.values()) sc[t] = when (t) { Task.CHAT, Task.PHONE -> 6; Task.WEB -> 4; else -> 5 }
        fun add(t: Task, v: Int) { sc[t] = (sc[t] ?: 5) + v }
        if (big) { add(Task.CODE, 2); add(Task.THINK, 3); add(Task.WRITE, 2); add(Task.PHONE, 1); add(Task.VISION, 1) }
        if (small) { add(Task.CHAT, 2); add(Task.PHONE, 1); add(Task.CODE, -1); add(Task.THINK, -2); add(Task.WRITE, -1) }
        if (coder) add(Task.CODE, 3)
        if (!small && STRONG_RX.containsMatchIn(m)) { add(Task.CODE, 3); add(Task.THINK, 2); add(Task.PHONE, 1) }
        if (reasoner) add(Task.THINK, 2)
        when (pv.id) {
            "groq" -> { add(Task.CHAT, 2); add(Task.PHONE, 2) }                          // very fast
            "gemini" -> { add(Task.WRITE, 1); add(Task.VISION, 2); add(Task.WEB, 5); add(Task.PHONE, 1) }
            "anthropic" -> { add(Task.CODE, 1); add(Task.WRITE, 2); add(Task.PHONE, 1); add(Task.VISION, 1) }
            "openai" -> { add(Task.CODE, 1); add(Task.PHONE, 1) }
            "deepseek" -> { add(Task.CODE, 1); add(Task.THINK, 1) }
            "mistral" -> add(Task.WRITE, 1)
            "xai" -> add(Task.THINK, 1)
        }
        val vision = when (pv.id) {
            "gemini", "anthropic" -> !m.contains("gemma-3n") && !m.contains("embedding")
            "openai" -> m.startsWith("gpt-4") || m.startsWith("gpt-5") || m.startsWith("o3") || m.startsWith("o4")
            "xai" -> m.contains("grok-4") || m.contains("vision")
            "mistral" -> m.contains("pixtral") || m.contains("medium") || m.contains("large")
            "github" -> m.contains("gpt-4") || m.contains("gpt-5") || m.contains("llama-4") || m.contains("multimodal")
            "nvidia", "huggingface", "kilo", "chutes", "alibaba", "zai", "cloudflare" ->
                m.contains("vision") || m.contains("-vl") || m.contains("llama-4") || m.contains("4.5v") || m.contains("qwen-vl") || m.contains("gemini") || m.contains("claude") || m.contains("gpt-5")
            "groq", "openrouter" -> m.contains("vision") || m.contains("-vl") || m.contains("llama-4") || m.contains("gemma-4") || m.contains("gemini") || m.contains("gpt-4o") || m.contains("claude")
            else -> false
        }
        val pdf = pv.id == "gemini" || pv.id == "anthropic" || (pv.id == "openai" && vision)
        val tools = !NO_TOOLS_RX.containsMatchIn(m)
        for (k in sc.keys.toList()) sc[k] = (sc[k] ?: 5).coerceIn(0, 10)
        if (!vision) sc[Task.VISION] = 0
        return Prof(vision, pdf, tools, sc)
    }

    private fun isFree(c: Cand): Boolean = when (c.pv.id) {
        "gemini", "groq" -> true
        "openrouter" -> c.model.endsWith(":free") || c.model == "openrouter/free"
        "zai" -> c.model.contains("flash")
        "kilo" -> c.model.contains("free")
        else -> c.pv.free
    }

    // ------------------------------------------------------------ which models exist (from the saved keys)

    private val NOT_CHAT = Regex("(embed|whisper|tts|speech|guard|moderat|safeguard|image|imagen|veo|audio|orpheus|playai|transcri|rerank|aqa|robotics|\\blive|dall|sora|davinci|babbage|computer-use|search-preview|realtime|-vision-only)")
    private const val PER_COMPANY = 14

    private fun catalog(p: SharedPreferences, id: String): List<String> =
        (p.getString("catalog_$id", "") ?: "").split('\n').map { it.trim() }.filter { it.isNotEmpty() }

    /** Every model that can be used right now: for each company with a key, its saved, default and listed models. */
    fun universe(p: SharedPreferences): List<Cand> {
        val out = ArrayList<Cand>()
        for (pv in Providers.ALL) {
            if (pv.group == "image" || pv.group == "voice") continue
            val keys = Providers.allKeys(p, pv.id)
            if (keys.isEmpty()) continue
            if (pv.id == "custom" && (p.getString("base_custom", "") ?: "").isBlank()) continue
            val cat = catalog(p, pv.id).filter { !NOT_CHAT.containsMatchIn(it.lowercase()) }
            val ms = LinkedHashSet<String>()
            val saved = Providers.savedModel(p, pv.id)
            if (cat.isNotEmpty()) {
                // Once a provider has returned a live catalogue, do not keep a stale saved/default
                // model that the provider no longer advertises. This avoids needless 400/404 retries.
                if (saved in cat) ms.add(saved)
                pv.models.filter { it in cat }.forEach { ms.add(it) }
                var extra = cat.filter { it !in ms }
                if (pv.id == "openrouter") extra = extra.filter { it.endsWith(":free") || it == "openrouter/free" }
                extra.sortedByDescending { profile(pv, it).best() }.forEach { ms.add(it) }
            } else {
                if (saved.isNotBlank()) ms.add(saved)
                ms.addAll(pv.models)
            }
            for (m in ms.take(PER_COMPANY)) out.add(Cand(pv, keys[0], m))
        }
        return out
    }

    /** Asks every company that has a key which models its key can use, and keeps the answer on the phone. Blocking: call from a thread. */
    fun refreshCatalog(p: SharedPreferences): Int {
        var n = 0
        for (pv in Providers.ALL) {
            if (pv.id == "custom" || pv.group == "image" || pv.group == "voice") continue
            val keys = Providers.allKeys(p, pv.id)
            for (k in keys) {
                try {
                    val list = Providers.listModels(pv, k)
                    if (list.isNotEmpty()) {
                        p.edit().putString("catalog_" + pv.id, list.take(400).joinToString("\n")).putLong("catalogAt", System.currentTimeMillis()).apply()
                        n++
                        break
                    }
                } catch (e: Exception) { /* try the next key of this company */ }
            }
        }
        return n
    }

    // ------------------------------------------------------------ choosing

    @Synchronized private fun stat(id: String) = stats.getOrPut(id) { Stat() }
    @Synchronized private fun kstat(pv: Provider, key: String) = keyStats.getOrPut(pv.id + "#" + key.takeLast(8)) { KeyStat() }

    /** All keys of one company, the ones not resting and least used first, so the load is shared. */
    @Synchronized fun keysFor(pv: Provider): List<String> {
        val p = Providers.prefsRef ?: return emptyList()
        val now = System.currentTimeMillis()
        return Providers.allKeys(p, pv.id).sortedWith(compareBy({ kstat(pv, it).coolUntil > now }, { kstat(pv, it).use }))
    }

    private fun companyResting(pv: Provider, now: Long): Boolean {
        val p = Providers.prefsRef ?: return false
        val ks = Providers.allKeys(p, pv.id)
        return ks.isNotEmpty() && ks.all { kstat(pv, it).coolUntil > now }
    }

    private fun rate(c: Cand, task: Task, primary: Cand): Double {
        val prof = profile(c.pv, c.model)
        var v = (prof.score[task] ?: 5).toDouble()
        if (c.pv.id == primary.pv.id) v += if (c.model == primary.model) 1.5 else 0.5
        val s = stat(c.id)
        val total = s.ok + s.fail
        if (total > 0) v -= 6.0 * s.fail / total
        if (s.ok >= 2) v -= minOf(4.0, s.avgMs / (if (task == Task.CHAT || task == Task.PHONE) 1500.0 else 5000.0))
        if (s.ok >= 3 && s.consecFail == 0) v += 0.5
        if (!isFree(c)) v -= if (task == Task.THINK || task == Task.CODE || task == Task.VISION) 0.3 else 0.8
        return v
    }

    /** The person's Select Models choice: one exact model, some companies, or (default) everything. Falls back to all if the choice has nothing ready. */
    private fun selected(p: SharedPreferences, pool: MutableList<Cand>): MutableList<Cand> {
        val pin = p.getString("modelPin", "") ?: ""
        if (pin.isNotEmpty()) {
            val one = pool.filter { it.id == pin }
            if (one.isNotEmpty()) return one.toMutableList()
        }
        val f = (p.getString("modelFilter", "") ?: "").split(",").filter { it.isNotBlank() }.toSet()
        if (f.isNotEmpty()) {
            val sub = pool.filter { it.pv.id in f }
            if (sub.isNotEmpty()) return sub.toMutableList()
        }
        return pool
    }

    /** The models to try, best first, for this kind of work. */
    @Synchronized fun plan(primary: Cand, task: Task, needTools: Boolean, needPdf: Boolean): List<Cand> {
        val p = Providers.prefsRef ?: return listOf(primary)
        val now = System.currentTimeMillis()
        var pool = universe(p).toMutableList()
        val chosen = selected(p, pool)
        val picking = chosen !== pool
        pool = chosen
        if (!picking && primary.key.isNotBlank() && pool.none { it.pv.id == primary.pv.id && it.model == primary.model }) pool.add(primary)
        var ok = pool.filter { c ->
            val f = profile(c.pv, c.model)
            (!needTools || f.tools) && (task != Task.VISION || (f.vision && (!needPdf || f.pdf)))
        }
        if (ok.isEmpty()) ok = pool
        val healthy = ok.filter { !cooling(it, now) && !companyResting(it.pv, now) }.map { it to rate(it, task, primary) }.sortedByDescending { it.second }
        val resting = ok.filter { cooling(it, now) || companyResting(it.pv, now) }.map { it to rate(it, task, primary) }.sortedByDescending { it.second }
        // Mix companies: a second model of a company that was just picked is a little less attractive (same limits, same outage).
        val picked = ArrayList<Cand>()
        val left = healthy.toMutableList()
        while (left.isNotEmpty() && picked.size < MAX_TRIES) {
            val best = left.maxByOrNull { (c, r) -> r - 1.0 * picked.count { it.pv.id == c.pv.id } }!!
            picked.add(best.first); left.remove(best)
        }
        for ((c, _) in resting) if (picked.size < MAX_TRIES) picked.add(c)
        return picked
    }

    private fun cooling(c: Cand, now: Long) = stat(c.id).coolUntil > now

    @Synchronized fun success(c: Cand, key: String, task: Task, ms: Long) {
        val s = stat(c.id)
        val hadRepeatedFailures = s.consecFail >= 3
        s.ok++; s.consecFail = 0; s.coolUntil = 0L
        if (hadRepeatedFailures) ModelHealthMonitor.onRecovered(company(c.pv), c.model)
        s.avgMs = if (s.avgMs == 0L) ms else (s.avgMs * 7 + ms * 3) / 10
        val ks = kstat(c.pv, key); ks.use++; ks.consec = 0; ks.code = 0
        lastUsed = c.label
        val l = runLog.get()
        if (l != null && l.none { it.company == company(c.pv) && it.model == c.model }) l.add(Used(company(c.pv), c.model, task, ms))
        save()
    }

    /** A key hit its own limit or was refused (not the model's fault): rest that key, the next key of the company is used. */
    @Synchronized fun keyFailure(pv: Provider, key: String, e: Exception) {
        val ks = kstat(pv, key)
        ks.consec++
        val code = (e as? ApiException)?.code ?: 0
        ks.code = code
        val base = if (code == 429) 60_000L * (1L shl minOf(ks.consec - 1, 4)) else 30L * 60_000
        ks.coolUntil = System.currentTimeMillis() + minOf(base, 30L * 60_000)
    }

    @Synchronized fun failure(c: Cand, e: Exception) {
        val s = stat(c.id)
        s.fail++; s.consecFail++
        val code = (e as? ApiException)?.code ?: 0
        s.lastCode = code
        s.lastFailureAt = System.currentTimeMillis()
        val base = when (code) {
            401, 403, 404 -> 30L * 60_000          // wrong key / model gone: rest a long time
            400, 422 -> 5L * 60_000                // this model could not handle the request
            429 -> 60_000L                         // limit reached: rest, longer each time in a row
            else -> 45_000L                        // server down or no network
        }
        val mult = if (code == 429 || code == 0 || code >= 500) 1L shl minOf(s.consecFail - 1, 5) else 1L
        s.coolUntil = System.currentTimeMillis() + minOf(base * mult, 30L * 60_000)
        save()
        ModelHealthMonitor.onRepeatedFailure(company(c.pv), c.model, code, s.consecFail)
    }

    /** True when the error is about the KEY (limit, refused), so another key of the same company may work. */
    fun isKeyError(e: Exception): Boolean = e is ApiException && (e.code == 401 || e.code == 402 || e.code == 403 || e.code == 429)

    /** True when another model is worth trying after this error. [badRequests] counts earlier 400/422 in this request. */
    fun worthRetrying(e: Exception, badRequests: Int): Boolean {
        if (e is CancelledException) return false
        // Nothing was specified, so keep going: a 400/422 is often just one model not liking the request.
        if (e is ApiException) return if (e.code == 400 || e.code == 422) badRequests < 6 else true
        return true
    }

    /** Called by the sender before each try: shows who is working now. */
    fun announce(c: Cand, task: Task, attempt: Int) {
        note((if (attempt > 0) "⏭ agla: " else "") + company(c.pv) + " · " + c.model.substringAfterLast('/') + "  (" + AgentRoster.label(task) + " · " + task.label + ")")
    }

    fun announceFail(c: Cand, e: Exception) {
        val why = (e as? ApiException)?.code?.let { "error $it" } ?: "jawab nahi aaya"
        note(company(c.pv) + " · " + c.model.substringAfterLast('/') + " ne " + why + " diya, doosra try ho raha hai")
    }

    // ------------------------------------------------------------ map ("kaun kis kaam ka hai?")

    private fun tier(f: Prof): String {
        val strong = maxOf(f.score[Task.THINK] ?: 0, f.score[Task.CODE] ?: 0)
        return when { strong >= 9 -> "bohat taqatwar"; strong >= 8 -> "taqatwar"; strong >= 6 -> "darmiyana"; else -> "halka, tez" }
    }

    private fun goodAt(f: Prof): String {
        val top = f.score.entries.filter { it.key != Task.WEB && it.value >= 7 && (it.key != Task.VISION || f.vision) }
            .sortedByDescending { it.value }.take(3).map { it.key.label }
        val extra = ArrayList<String>()
        if (f.vision) extra.add("photo")
        if (f.pdf) extra.add("PDF")
        return (top + extra).distinct().joinToString(", ")
    }

    class KeyRow(val tail: String, val state: Int, val secs: Long, val code: Int, val uses: Int) // state: 0 ready, 1 resting (limit), 2 refused/error
    class CompanyRow(val name: String, val keys: List<KeyRow>)

    /** Limit meter: every company, every saved key, and whether it is ready, at its limit (429), or refused. */
    @Synchronized fun limitRows(): List<CompanyRow> {
        val p = Providers.prefsRef ?: return emptyList()
        val now = System.currentTimeMillis()
        val out = ArrayList<CompanyRow>()
        for (pv in universe(p).map { it.pv }.distinct()) {
            val rows = Providers.allKeys(p, pv.id).map { k ->
                val ks = kstat(pv, k)
                val left = (ks.coolUntil - now) / 1000
                val st = if (left <= 0) 0 else if (ks.code == 429) 1 else 2
                KeyRow(k.takeLast(4), st, maxOf(left, 0), ks.code, ks.use)
            }
            if (rows.isNotEmpty()) out.add(CompanyRow(company(pv), rows))
        }
        return out
    }

    /** Lets every resting key try again right now (use after a limit reset). */
    @Synchronized fun clearRests() {
        keyStats.values.forEach { it.coolUntil = 0L; it.consec = 0; it.code = 0 }
        stats.values.forEach { it.coolUntil = 0L; it.consecFail = 0 }
        save()
    }

    private fun bar(pct: Int): String { val n = (pct / 10).coerceIn(0, 10); return "▰".repeat(n) + "▱".repeat(10 - n) }

    private fun statName(id: String): String {
        val pid = id.substringBefore('|')
        val co = Providers.ALL.firstOrNull { it.id == pid }?.let { company(it) } ?: pid
        return co + " · " + id.substringAfter('|').substringAfterLast('/')
    }


    private fun failureReason(code: Int): String = when (code) {
        400, 422 -> "request/tool format rejected ($code)"
        401, 403 -> "key/access refused ($code)"
        404 -> "model/endpoint not found (404)"
        408 -> "request timeout (408)"
        429 -> "rate/quota limit (429)"
        in 500..599 -> "provider server error ($code)"
        0 -> "network/transport or unknown error"
        else -> "HTTP/API error ($code)"
    }

    private fun observedStatus(s: Stat, now: Long): String {
        val attempts = s.ok + s.fail
        if (attempts == 0) return "⚪ NOT TESTED"
        val rate = (s.ok * 100.0 / attempts).toInt()
        val issue = if (s.fail > 0) failureReason(s.lastCode) else ""
        return when {
            s.coolUntil > now && s.ok == 0 && s.fail >= 3 -> "🔴 NOT WORKING NOW · 0/$attempts responses · $issue"
            s.coolUntil > now -> "⏸️ COOLDOWN · $issue"
            attempts >= 5 && rate >= 90 -> "✅ STABLE OBSERVED · $rate% API success"
            attempts >= 5 && rate < 60 -> "🔴 UNSTABLE OBSERVED · $rate% API success · $issue"
            s.ok > 0 && s.fail == 0 -> "🟢 RESPONDED · small sample ($attempts tries)"
            else -> "🟡 MIXED RESULTS · $rate% API success · $issue"
        }
    }

    /**
     * The full report (chat, dialog or "report do"): overview, LIVE performance counted on this phone, companies and keys,
     * who can do what, who answers which job, and Anjoo's own experience. Every number comes from real counters: nothing is invented.
     */
    @Synchronized fun report(): String {
        val p = Providers.prefsRef ?: return "Abhi models ki maloomat nahi hai. Pehle Settings me key daalo."
        val now = System.currentTimeMillis()
        val uni = universe(p)
        if (uni.isEmpty()) return "Koi key saved nahi hai. Menu → 🔑 Keys add karo me apni keys paste karo (Gemini, Groq, OpenRouter, OpenAI, Claude ... jo bhi ho)."
        val companies = uni.map { it.pv }.distinct()
        val totalKeys = companies.sumOf { Providers.allKeys(p, it.id).size }
        val line = "━━━━━━━━━━━━━━━━━━━━"
        val sb = StringBuilder("✨ Anjoo AI · Models aur Keys ki Report ✨\n").append(line).append('\n')

        // 1. overview
        val freeCo = companies.count { isFree(Cand(it, "", it.models.firstOrNull() ?: "")) }
        val visionN = uni.count { profile(it.pv, it.model).vision }
        val pdfN = uni.count { profile(it.pv, it.model).pdf }
        val toolsN = uni.count { profile(it.pv, it.model).tools }
        sb.append("\n📊 EK NAZAR MEIN\n")
        sb.append("🏢 ").append(companies.size).append(" company  ·  🔑 ").append(totalKeys).append(" key  ·  🤖 ").append(uni.size).append(" model tayyar\n")
        sb.append("🆓 free: ").append(freeCo).append("   💳 paid: ").append(companies.size - freeCo).append('\n')
        sb.append("👁 photo: ").append(visionN).append("   📄 PDF: ").append(pdfN).append("   🛠 phone tools: ").append(toolsN).append(" model\n")
        if (lastUsed.isNotBlank()) sb.append("🕘 Aakhri jawab: ").append(lastUsed.replace("|", " / ")).append('\n')

        // 2. live performance (real counters, kept on the phone)
        val live = stats.entries.filter { it.value.ok + it.value.fail > 0 }
        val okAll = live.sumOf { it.value.ok }
        val failAll = live.sumOf { it.value.fail }
        sb.append('\n').append(line).append("\n⚡ ASLI PERFORMANCE (is phone ki gintee)\n")
        if (okAll + failAll == 0) {
            sb.append("Abhi koi model test nahi hua, is liye numbers jhoote nahi dunga. Thori chat karein, phir yahan asli natije aayenge.\n")
        } else {
            val rate = okAll * 100 / (okAll + failAll)
            val stars = when { rate >= 95 -> "⭐⭐⭐⭐⭐"; rate >= 85 -> "⭐⭐⭐⭐"; rate >= 70 -> "⭐⭐⭐"; rate >= 50 -> "⭐⭐"; else -> "⭐" }
            sb.append("Sehat ").append(stars).append("  ").append(rate).append("%\n").append(bar(rate)).append("\n")
            sb.append(okAll).append(" jawab theek, ").append(failAll).append(" fail\n")
            live.filter { it.value.ok >= 2 }.minByOrNull { it.value.avgMs }?.let {
                sb.append("🏎 Sab se tez: ").append(statName(it.key)).append(" (").append("%.1f".format(it.value.avgMs / 1000.0)).append("s)\n") }
            live.filter { it.value.ok >= 3 }.sortedWith(compareBy({ it.value.fail * 1.0 / (it.value.ok + it.value.fail) }, { -it.value.ok })).firstOrNull()?.let {
                sb.append("🛡 Sab se bharosemand: ").append(statName(it.key)).append(" (").append(it.value.ok).append(" theek, ").append(it.value.fail).append(" fail)\n") }
            live.maxByOrNull { it.value.ok }?.let {
                sb.append("💪 Sab se zyada kaam: ").append(statName(it.key)).append(" (").append(it.value.ok).append(" jawab)\n") }
        }

        // 3. companies, keys and models
        sb.append('\n').append(line).append("\n🏢 COMPANIES AUR MODELS\n")
        for (pv in companies) {
            val ks = Providers.allKeys(p, pv.id)
            val rest = ks.count { kstat(pv, it).coolUntil > now }
            sb.append("\n▸ ").append(company(pv)).append(" — ").append(ks.size).append(if (ks.size == 1) " key" else " keys")
            if (rest > 0) sb.append(" (").append(rest).append(" aaram par)")
            sb.append(if (isFree(Cand(pv, "", pv.models.firstOrNull() ?: ""))) "  🆓" else "  💳").append('\n')
            val ms = uni.filter { it.pv.id == pv.id }
            for (c in ms.take(5)) {
                val f = profile(c.pv, c.model)
                val s = stat(c.id)
                val attempts = s.ok + s.fail
                sb.append("  ").append(c.model.substringAfterLast('/')).append(" — ").append(tier(f)).append('\n')
                sb.append("     ").append(observedStatus(s, now)).append('\n')
                val g = goodAt(f)
                if (g.isNotEmpty()) sb.append("     Skill profile (model name/provider se inferred): ").append(g).append('\n')
                if (s.ok > 0) sb.append("     Avg successful-response latency: ").append("%.1f".format(s.avgMs / 1000.0)).append("s\n")
                if (attempts > 0) sb.append("     Observed calls: ").append(s.ok).append(" success / ").append(s.fail).append(" failure of ").append(attempts).append(" attempts\n")
                if (s.lastFailureAt > 0 && s.fail > 0) sb.append("     Last failure: ").append(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US).format(java.util.Date(s.lastFailureAt))).append(" · ").append(failureReason(s.lastCode)).append('\n')
                if (!f.tools) sb.append("     Note: tool-calling profile is not supported by this model according to current rules.\n")
            }
            if (ms.size > 5) sb.append("  … aur ").append(ms.size - 5).append(" model\n")
        }

        // 4. weak / currently inaccessible models, based on this app's measured requests only
        sb.append('\n').append(line).append("\n🚨 KAMZOR YA ABHI NA-CHALNE WALI CONNECTIONS\n")
        val attention = live.filter { entry ->
            val s = entry.value; val attempts = s.ok + s.fail
            attempts >= 3 && (s.ok == 0 || (s.ok + s.fail > 0 && s.ok * 100 / (s.ok + s.fail) < 60))
        }.sortedWith(compareBy({ it.value.ok * 100 / (it.value.ok + it.value.fail).coerceAtLeast(1) }, { -it.value.fail }))
        if (attention.isEmpty()) {
            sb.append("Koi model abhi 3+ measured attempts ke baad weak threshold par nahi. Jis model ke samne NOT TESTED hai usko working kehna abhi mumkin nahi.\n")
        } else {
            for ((id, s) in attention.take(8)) {
                val n = s.ok + s.fail
                sb.append("• ").append(statName(id)).append(": ").append(s.ok).append('/').append(n).append(" valid API replies; ")
                    .append(failureReason(s.lastCode)).append(".\n")
                if (s.lastCode == 401 || s.lastCode == 403 || s.lastCode == 404 || s.lastCode == 429)
                    sb.append("  Action: key/access/model/quota issue fix karein; ise intelligence ka proof na samjhein.\n")
                else sb.append("  Action: doosra model/provider try karein; ye API reliability ka signal hai, answer accuracy benchmark nahi.\n")
            }
        }
        sb.append("Important: yeh API response availability/speed ki real app measurements hain. App ne har answer ki factual accuracy independently grade nahi ki; model-name skill profile estimates hain.\n")

        // 5. keys
        val rows = limitRows()
        val readyK = rows.sumOf { r -> r.keys.count { it.state == 0 } }
        val limitK = rows.sumOf { r -> r.keys.count { it.state == 1 } }
        val badK = rows.sumOf { r -> r.keys.count { it.state == 2 } }
        sb.append('\n').append(line).append("\n🔑 KEYS KI HAALAT\n")
        sb.append("✅ tayyar ").append(readyK).append("   ⏸️ limit ").append(limitK).append("   ❌ band/galat ").append(badK).append('\n')
        for (row in rows) {
            sb.append("• ").append(row.name).append(": ")
            sb.append(row.keys.joinToString(", ") { k ->
                "…" + k.tail + when (k.state) { 0 -> " ✅"; 1 -> " ⏸️ (" + k.secs + "s)"; else -> " ❌ (" + k.code + ")" } +
                    (if (k.uses > 0) " · " + k.uses + " baar" else "")
            }).append('\n')
        }

        // 5. who can do what
        sb.append('\n').append(line).append("\n🧩 KAUN KYA KAR SAKTA HAI\n")
        fun names(f: (Prof) -> Boolean): String = uni.filter { f(profile(it.pv, it.model)) }.map { company(it.pv) }.distinct().take(6).joinToString(", ").ifBlank { "koi nahi" }
        sb.append("👁 Photo samajhna: ").append(names { it.vision }).append('\n')
        sb.append("📄 PDF parhna: ").append(names { it.pdf }).append('\n')
        sb.append("🛠 Phone ke kaam (tools): ").append(names { it.tools }).append('\n')
        sb.append("🌐 Taaza khabar (web): ").append(if (companies.any { it.id == "gemini" }) "Gemini (search ke saath)" else "abhi koi nahi (Gemini key lagayen)").append('\n')

        // 6. who answers which job (with the backup)
        sb.append('\n').append(line).append("\n🎯 KAAM → KAUN KAREGA (abhi)\n")
        val prim = Cand(Providers.active, Providers.savedKey(p, Providers.active.id), Providers.savedModel(p, Providers.active.id))
        for (t in Task.values()) {
            val pl = plan(prim, t, true, false)
            val first = pl.firstOrNull() ?: continue
            sb.append("• ").append(t.label).append(": ").append(company(first.pv)).append(" · ").append(first.model.substringAfterLast('/'))
            pl.getOrNull(1)?.let { sb.append("  (warna ").append(company(it.pv)).append(")") }
            sb.append('\n')
        }

        // 7. Anjoo's own experience, built only from the facts above
        sb.append('\n').append(line).append("\n💬 MERA TAJURBA (Anjoo ki zubani)\n")
        if (okAll + failAll == 0) {
            sb.append("Main abhi naya hoon: mere scores model ke naam, size aur company se andaze hain, asli test nahi. Aap jitni chat karenge, main utna seekhunga. Jo model tez aur theek chalega woh upar aayega, jo fail hoga woh aaram karega.\n")
        } else {
            val rate = okAll * 100 / (okAll + failAll)
            sb.append("Ab tak ").append(okAll + failAll).append(" jawabon mein ").append(rate).append("% theek rahe. ")
            sb.append(if (rate >= 90) "Natije bohat acha hai, mujhe is par naaz hai. 😊\n" else if (rate >= 70) "Zyada tar theek hai, par kuch models ko mujhe aaram dena para.\n" else "Kuch connections kamzor hain, neeche mashwara dekhein.\n")
        }
        val tips = ArrayList<String>()
        companies.filter { Providers.allKeys(p, it.id).size == 1 && it.id != "ollama" && it.id != "custom" }.take(3).forEach {
            tips.add(company(it) + " ki sirf 1 key hai: limit lagi to doosri company sambhalegi. Ek aur key laga lein to behtar.") }
        if (visionN == 0) tips.add("Photo samajhne wala koi model nahi: Gemini ya Claude ki key lagayen.")
        if (companies.none { it.id == "gemini" }) tips.add("Taaza khabar ke liye Gemini (free) lagana behtar rahega.")
        live.filter { it.value.consecFail > 0 }.take(2).forEach { tips.add(statName(it.key) + " haal hi mein fail hua: woh aaram par hai, baqi chal rahe hain.") }
        if (badK > 0) tips.add(badK.toString() + " key band ya galat hai: us company ki nayi key paste karein.")
        if (limitK > 0) tips.add(limitK.toString() + " key limit par hai: dusri key khud lag gayi, thori der baad wapas chal paygi.")
        if (freeCo == companies.size && companies.size >= 3) tips.add("Sab free keys par bhi kaam chal raha hai: paisa ek bhi nahi laga. 🎉")
        if (tips.isEmpty()) tips.add("Sab theek hai, filhaal koi mashwara nahi.")
        tips.take(5).forEach { sb.append("• ").append(it).append('\n') }

        sb.append("\nℹ️ Report generated: ").append(java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", java.util.Locale.US).format(java.util.Date(now)))
        sb.append("\nMeasurements: this app's saved success/failure/latency counters only. Skill profile estimates come from provider/model metadata; factual-answer accuracy is not tested automatically. No hidden provider metrics are available.")
        sb.append("\n✅ chal raha  ⚠️ haal hi me fail  ⏸️ aaram par  ⚪ abhi test nahi hua")
        sb.append("\nNotifications: repeated connection failures can alert Boss when Settings > AI self-check / failure alerts is ON.")
        sb.append("\nKeys ko online live test karna model usage counters se alag action hai; use 'refresh model catalogue' ya test request se verify karein.")
        return sb.toString().trim()
    }

    private val ASK_REPORT = Regex("((models?|keys?|anjoo).*(report|performance|tajurba|tajruba|experience)|(report|performance|tajurba|tajruba|experience).*(models?|keys?))")
    private val ASK_REPORT_NOT = Regex("(pdf|docx|word|document|file|excel|\\.zip)")

    private val ASK_ABOUT = Regex("(model|models|connection|connections|provider|groq|gemini|openrouter|\\bkeys?\\b|\\bapi\\b|company|companies)")
    private val ASK_STATUS = Regex("(kon|kaun|konsa|kaunsa|kon sa|kaun sa|which|best|behtar|behtreen|status|strong|taqat|tagat|chal raha|chal rahi|chal rahe|working|haal|report|performance|kitna|kitne|kitni|naqsha|map|available|kis kaam)")
    private val ASK_NOT = Regex("(code|coding|project|website|python|kotlin|likh|bana|script|app |function)")

    /** Requests for a REAL app-generated model report file, rather than asking the chat model to guess one. */
    fun reportExportFormat(text: String): String? {
        val t = text.lowercase().trim()
        if (t.length > 240 || t.contains("```")) return null
        val mentionsModels = Regex("(models?|providers?|connections?|api keys?|keys?)").containsMatchIn(t)
        val mentionsReport = Regex("(report|performance|status|tajurba|tajruba|health|kaisi chal rahi)").containsMatchIn(t)
        val requestsFile = Regex("(pdf|docx|word|xlsx|excel|spreadsheet|txt|text file|document|file|report file)").containsMatchIn(t)
        if (!mentionsModels || !mentionsReport || !requestsFile) return null
        return when {
            Regex("\\b(docx|word)\\b").containsMatchIn(t) -> "docx"
            Regex("\\b(xlsx|excel|spreadsheet)\\b").containsMatchIn(t) -> "xlsx"
            Regex("\\b(txt|text)\\b").containsMatchIn(t) -> "txt"
            else -> "pdf"
        }
    }

    /** True when the message is asking how the models/connections are doing (not asking for help using one). */
    fun asksStatus(text: String): Boolean {
        val t = text.lowercase().trim()
        if (t.length > 110 || t.contains("```")) return false
        if (t == "model status" || t == "models status" || t == "connection status") return true
        if (ASK_REPORT.containsMatchIn(t) && !ASK_REPORT_NOT.containsMatchIn(t)) return true
        return ASK_ABOUT.containsMatchIn(t) && ASK_STATUS.containsMatchIn(t) && !ASK_NOT.containsMatchIn(t)
    }
}
