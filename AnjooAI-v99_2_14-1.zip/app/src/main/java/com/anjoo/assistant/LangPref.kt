package com.anjoo.assistant

import android.content.Context
import java.util.Locale

/**
 * Anjoo AI language system.
 * Five choices: Phone Default, English, Roman Urdu, Urdu (script), Arabic.
 * "phone" follows the device locale. All others force the AI to reply in that language.
 */
object LangPref {

    const val PHONE   = "phone"      // follow device locale
    const val ENGLISH = "en"
    const val ROMAN   = "roman"      // Roman Urdu (Latin letters)
    const val URDU    = "ur"         // اردو script
    const val ARABIC  = "ar"         // العربية

    data class Lang(
        val key: String,
        val label: String,          // shown in settings pill
        val nativeLabel: String,    // in that script
        val rtl: Boolean = false,
    )

    val ALL = listOf(
        Lang(PHONE,   "Phone Default",  "Phone Default"),
        Lang(ENGLISH, "English",        "English"),
        Lang(ROMAN,   "Roman Urdu",     "Roman Urdu"),
        Lang(URDU,    "Urdu",           "اردو",  rtl = true),
        Lang(ARABIC,  "Arabic",         "العربية", rtl = true),
    )

    fun get(ctx: Context): String =
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
           .getString("appLang", PHONE) ?: PHONE

    fun set(ctx: Context, key: String) =
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
           .edit().putString("appLang", key).apply()

    /** Single-line system-prompt instruction injected into every call. */
    fun promptBlock(ctx: Context): String = when (get(ctx)) {
        ENGLISH ->
            "LANGUAGE: Always reply in English only, no matter what language the user writes in. Keep Anjoo's warm, friendly tone in English.\n"

        ROMAN ->
            "LANGUAGE: Hamesha Roman Urdu mein jawab do (English haroof, Urdu alfaz — jaise 'aap kaise hain', 'main samajh gaya'). " +
            "Koi Urdu ya Arabic script nahi, sirf Latin haroof. English technical terms jaise hain waise raho.\n"

        URDU ->
            "LANGUAGE: ہمیشہ خالص اردو رسم الخط میں جواب دیں (نستعلیق/اردو حروف)۔ " +
            "رومن اردو یا انگریزی میں جواب مت دیں۔ تکنیکی اصطلاحات جوں کی توں رکھیں۔\n"

        ARABIC ->
            "LANGUAGE: أجب دائماً باللغة العربية الفصحى (MSA) بغض النظر عن لغة المستخدم. " +
            "لا ترد بالإنجليزية أو الأردية. احتفظ بالمصطلحات التقنية كما هي.\n"

        else -> {  // PHONE — auto-detect from system locale
            val tag = Locale.getDefault().language
            when {
                tag == "ar" ->
                    "LANGUAGE: أجب دائماً باللغة العربية الفصحى.\n"
                tag == "ur" ->
                    "LANGUAGE: Jawab usi script mein do jis mein user ne likha (Urdu script ya Roman Urdu ya English).\n"
                tag.startsWith("en") ->
                    "LANGUAGE: Respond in English. Match the user's language if they switch.\n"
                else ->
                    "LANGUAGE: Reply in the same language the user writes in.\n"
            }
        }
    }

    /** True when current language is RTL. */
    fun isRtl(ctx: Context): Boolean = ALL.firstOrNull { it.key == get(ctx) }?.rtl == true

    /** Label to show in the settings button/pill. */
    fun label(ctx: Context): String = ALL.firstOrNull { it.key == get(ctx) }?.label ?: "Phone Default"
}
