
# HS Master Build + Direct APK Download (HSActivity)
- Build prompts are now master-level for all 3 modes:
  - Android: MVVM + Room + Hilt + Material 3 + dark theme + adaptive icons + ProGuard stub + full file list. No TODO stubs — every function must be complete.
  - Web: Semantic HTML5 + CSS vars + ES6+ (or framework) + responsive + dark mode + accessibility + localStorage persistence + 5-10 demo records seeded.
  - Creative: Production-ready prompt/storyboard per asset; no fake "file created" claims.
- New "⬇ APK" button in HS toolbar (top right) → opens HsApkBuilderActivity directly.
- New "Download APK" card at bottom of HS main screen → one tap to compile & download APK via GitHub Actions.
