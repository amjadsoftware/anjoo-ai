package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.widget.LinearLayout
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * In-app updater. Successful pushes to the repository's default branch publish a GitHub Release
 * tagged "build-<versionCode>" with the release APK attached.
 * The app asks the Releases API for the latest one, and if its versionCode is higher it offers the update,
 * downloads the APK and hands it to Android's installer. Same package + same keystore = installs over the old app,
 * no uninstall needed. After the install, UpdatedReceiver opens the app again.
 */
object Updater {
    private const val ACTION_RESULT = "com.anjoo.assistant.UPDATE_RESULT"
    private val ui = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    private var lastCheck = 0L
    @Volatile private var busy = false
    private var promptedThisRun = false

    private fun prefs(c: Context) = c.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    /** Auto update is ON unless the user switched it off in Settings. */
    fun autoOn(c: Context) = prefs(c).getBoolean("autoUpdate", true)

    class Info(
        val code: Long,
        val name: String,
        val notes: String,
        val url: String,
        val usesAndroidVersionCode: Boolean
    )

    /** Android uses versionCode to decide whether the installed APK can be upgraded. */
    @Suppress("UNUSED_PARAMETER")
    fun currentCode(ctx: Context): Long = BuildConfig.VERSION_CODE.toLong()

    private fun isNewer(info: Info): Boolean = UpdaterVersion.isNewer(
        ParsedReleaseVersion(info.code, info.usesAndroidVersionCode),
        BuildConfig.VERSION_CODE.toLong(),
        BuildConfig.VERSION_NAME
    )

    /** Returns the latest release, or null if there is none / no internet / repo unknown. */
    private fun fetchLatest(): Info? {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return null
        val req = Request.Builder().url("https://api.github.com/repos/$repo/releases/latest")
            .header("Accept", "application/vnd.github+json").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return null
            val j = JSONObject(r.body?.string() ?: return null)
            val name = j.optString("name")
            val releaseVersion = UpdaterVersion.parse(j.optString("tag_name"), name) ?: return null
            val assets = j.optJSONArray("assets") ?: return null
            var url = ""; var fallback = ""
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                val n = a.optString("name")
                if (!n.endsWith(".apk")) continue
                if (fallback.isEmpty()) fallback = a.optString("browser_download_url")
                if (!n.contains("debug", true)) { url = a.optString("browser_download_url"); break }
            }
            if (url.isEmpty()) url = fallback
            if (url.isEmpty()) return null
            return Info(releaseVersion.code, name, j.optString("body").trim(), url, releaseVersion.usesAndroidVersionCode)
        }
    }

    /**
     * Every time the app is opened (at most once per 15 minutes) it quietly asks GitHub for the newest release.
     * Auto update ON: a newer version is downloaded and installed by itself, and the app opens again after it.
     * Auto update OFF: the person is asked first.
     */
    fun checkOnLaunch(act: Activity) {
        val now = System.currentTimeMillis()
        if (busy || now - lastCheck < 15 * 60 * 1000L) return
        lastCheck = now
        Thread {
            val info = try { fetchLatest() } catch (e: Exception) { null }
            if (info != null && isNewer(info)) ui.post {
                if (autoOn(act)) start(act, info, true) else offer(act, info)
            }
        }.start()
    }

    /** Manual "Update your app" button. */
    fun checkNow(act: Activity) {
        Toast.makeText(act, "Update check ho raha hai...", Toast.LENGTH_SHORT).show()
        Thread {
            val info = try { fetchLatest() } catch (e: Exception) { null }
            ui.post {
                when {
                    info == null -> Toast.makeText(act, "Update check nahi ho saka (internet ya GitHub Release check karo).", Toast.LENGTH_LONG).show()
                    isNewer(info) -> offer(act, info)
                    else -> Toast.makeText(act, "Aap latest version par hain.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun offer(act: Activity, info: Info) {
        if (act.isFinishing || act.isDestroyed) return
        val notes = if (info.notes.isNotBlank() && info.notes.length < 400) "\n\n" + info.notes else ""
        AlertDialog.Builder(act).setTitle("Naya update aya hai")
            .setMessage((if (info.name.isNotBlank()) info.name else "Anjoo AI ka naya version") +
                "\n\nUpdate ke baad app khud dobara khul jayegi." + notes)
            .setPositiveButton("Update") { _, _ -> start(act, info, false) }
            .setNegativeButton("Baad mein", null)
            .show()
    }

    private fun start(act: Activity, info: Info, auto: Boolean) {
        if (act.isFinishing || act.isDestroyed || busy) return
        if (!act.packageManager.canRequestPackageInstalls()) {
            // Needed once: without it Android refuses installs from this app. Ask once per run, never nag in a loop.
            if (auto && promptedThisRun) return
            promptedThisRun = true
            Toast.makeText(act, "Auto update ke liye 'Allow from this source' on karo, phir app dobara kholo.", Toast.LENGTH_LONG).show()
            act.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName)))
            return
        }
        // The app can only open itself after an update when "Display over other apps" is on, so ask once before downloading.
        val askedBefore = prefs(act).getBoolean("overlayAsked", false)
        if (!Settings.canDrawOverlays(act) && !askedBefore) {
            prefs(act).edit().putBoolean("overlayAsked", true).apply()
            AlertDialog.Builder(act).setTitle("Update ke baad app khud khule")
                .setMessage("Update install hone ke baad app apne aap dobara khulne ke liye 'Display over other apps' on karein, phir wapas aa kar Update dabayein.")
                .setPositiveButton("On karo") { _, _ ->
                    try { act.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + act.packageName))) } catch (e: Exception) {}
                }
                .setNegativeButton("Aise hi update karo") { _, _ -> start(act, info, auto) }
                .show()
            return
        }
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val label = TextView(act).apply { text = "Download ho raha hai..."; setPadding(0, 0, 0, 24) }
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; setPadding(60, 40, 60, 20)
            addView(label); addView(bar)
        }
        val dlg = AlertDialog.Builder(act).setTitle(if (auto) "Naya version aa raha hai" else "Updating").setView(box).setCancelable(false).create()
        dlg.show()
        busy = true
        Thread {
            try {
                val dir = File(act.cacheDir, "update").apply { mkdirs() }
                val f = File(dir, "AnjooAI.apk")
                http.newCall(Request.Builder().url(info.url).build()).execute().use { r ->
                    if (!r.isSuccessful) throw RuntimeException("HTTP " + r.code)
                    val body = r.body ?: throw RuntimeException("empty")
                    val total = body.contentLength()
                    var done = 0L
                    body.byteStream().use { i ->
                        f.outputStream().use { o ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = i.read(buf); if (n < 0) break
                                o.write(buf, 0, n); done += n
                                if (total > 0) ui.post { bar.progress = (done * 100 / total).toInt() }
                            }
                        }
                    }
                }
                ui.post { label.text = "Install ho raha hai..."; bar.progress = 100 }
                install(act, f)
                ui.post { try { dlg.dismiss() } catch (e: Exception) {} }
                busy = false
            } catch (e: Exception) {
                busy = false
                ui.post {
                    try { dlg.dismiss() } catch (x: Exception) {}
                    Toast.makeText(act, "Update fail: " + (e.message ?: "error"), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun install(ctx: Context, apk: File) {
        val pi = ctx.packageManager.packageInstaller
        val params = PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL)
        // Android 12+: an update from the same installer can go through without the confirmation screen.
        if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED)
        val id = pi.createSession(params)
        pi.openSession(id).use { s ->
            apk.inputStream().use { i ->
                s.openWrite("anjoo", 0, apk.length()).use { o -> i.copyTo(o); s.fsync(o) }
            }
            val intent = Intent(ctx, InstallResultReceiver::class.java).setAction(ACTION_RESULT)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            s.commit(PendingIntent.getBroadcast(ctx, id, intent, flags).intentSender)
        }
    }
}

/** Receives the installer's answer: shows Android's "Update?" screen, or reports a failure. */
class InstallResultReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT) ?: return
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { c.startActivity(confirm) } catch (e: Exception) {}
            }
            PackageInstaller.STATUS_SUCCESS -> {}
            else -> Toast.makeText(c, "Update install nahi hua: " + (i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""),
                Toast.LENGTH_LONG).show()
        }
    }
}

/** Runs inside the NEW version right after an update: cleans up and opens the app again. */
class UpdatedReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        try { File(c.cacheDir, "update").deleteRecursively() } catch (e: Exception) {}
        val launch = c.packageManager.getLaunchIntentForPackage(c.packageName) ?: return
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Android only lets a background app open a screen if it has "Display over other apps".
        if (Settings.canDrawOverlays(c)) {
            try { c.startActivity(launch); return } catch (e: Exception) {}
        }
        // Fallback: a tap-to-open notification.
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
                NotificationChannel("update", "App update", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(c, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val b = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(c, "update")
                    else android.app.Notification.Builder(c)
            nm.notify(7701, b.setSmallIcon(c.applicationInfo.icon).setContentTitle("Anjoo AI update ho gaya")
                .setContentText("Kholne ke liye tap karo").setContentIntent(pi).setAutoCancel(true).build())
        } catch (e: Exception) {}
    }
}
