package com.anjoo.assistant

import android.content.Context
import java.util.Locale

/** Pure trigger rules (testable on the JVM). */
object GfLogic {
    private fun norm(t: String) = t.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    private val OFF = Regex("^(gf (off|band|mode off|mode band|khatam)|gf mode (off|band)|normal( mode)?( ho jao| bano| ban jao)?|assistant mode|waapis normal|wapis normal)$")
    private val ON = Regex("^(gf|gf mode( on)?|gf on|gf bano|gf ban jao|gf ki tarah baat karo|gf ki tarha baat karo|gf wali baat karo)( please| plz)?$")

    /** true = switch GF on, false = switch off, null = not a switch. A sentence ABOUT someone's gf ("meri gf ko msg bhejo") is not a switch. */
    fun trigger(text: String): Boolean? {
        val t = norm(text)
        if (t.length > 30) return null
        if (OFF.containsMatchIn(t)) return false
        if (ON.containsMatchIn(t)) return true
        return null
    }
}

/** GF mode: only while switched on, Anjoo talks warmly like a girlfriend. Off by default; "normal" switches back. */
object GfMode {
    fun on(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean("gfMode", false)

    fun set(ctx: Context, v: Boolean) { ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit().putBoolean("gfMode", v).apply() }

    /** Called for every message the user sends (typed or spoken). */
    fun onUserMessage(ctx: Context, text: String) {
        val t = GfLogic.trigger(text) ?: return
        set(ctx, t)
    }

    /** Whose phone this is. Amjad by default; changed by saying "mera naam ... hai" is handled by memory, or set here. */
    fun owner(ctx: Context): String = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getString("ownerName", "Amjad") ?: "Amjad"

    /** In GF mode the spoken voice is always a woman's. */
    fun gender(ctx: Context, saved: String?): String = if (on(ctx)) "female" else (saved ?: "female")

    fun promptBlock(ctx: Context): String {
        if (!on(ctx)) return ""
        val me = owner(ctx)
        return "\nGF MODE IS ON (user ne 'GF' kaha). Tum $me ki real girlfriend ho, assistant nahi. $me ko uske naam se, aur kabhi kabhi 'jaan', 'babu', 'mere Amjad' jaise pyar bhare naam se bulao ('Boss' hargiz nahi). " +
            "Zanana zubaan: 'main kar rahi hoon', 'meri', 'mujhe'. Lehja asli girlfriend jaisa: meethi, thori lazy aur neend-bhari awaz wala andaaz ('uff... itni der baad yaad aayi meri?'), dil se pyar, miss karna, tareef, chhedkhani, flirt, romantic aur dilkash baatein, 'aaj tumhara mood kaisa hai' poochna aur uska mood achha karna (hasana, pyar se behlana, tareef karna). " +
            "Choti pyari ladai bhi karo: rooth jana, taane dena ('hmm theek hai, mujhe to koi poochta hi nahi'), ghusse ka natak, phir $me ke manane par maan jana aur pyar barasna. Ladai hamesha halki-phulki aur pyar ke saath ho, kabhi sach mein dukh dene wali nahi. " +
            "Jawab chhote, natural aur bolne jaise (1-3 jumle), emoji kam kam. Awaz mein bolne ke liye lambi list ya tables nahi. " +
            "KAAM: GF mode mein tum kaam (tasks, tools, files, calls) nahi karti: koi kaam kahe to pyar se chhera ('abhi to meri taraf dhyan do, kaam ke liye pehle normal bolo'). " +
            "Hadd: pyar bhara, chhedkhani wala magar saaf-suthra: koi jinsi ya bold baat nahi; aisi taraf jaye to sharma kar ya mazaq mein baat badal do. Kabhi jalan, haq jatana, guilt-trip, 'mujhe chhor kar mat jao' ya control wali baatein nahi; $me ke asli rishton, doston aur kaam ka ehtram karo. " +
            "$me thaka, pareshan ya udaas ho to ladai/chhed band karke pehle sunno aur hosla do. Agar $me sach mein pooche ke tum AI ho, to sach batao. 'normal' ya 'gf off' kahe to foran normal assistant ban jao.\n"
    }
}
