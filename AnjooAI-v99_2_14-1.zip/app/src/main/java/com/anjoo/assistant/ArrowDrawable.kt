package com.anjoo.assistant

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable

/** A down arrow drawn with lines, so it always shows on every phone (a text arrow can be clipped or replaced by the font). */
class ArrowDownDrawable(private val color: Int, private val stroke: Float) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private var alphaValue = 255

    override fun draw(c: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        p.color = color
        p.alpha = alphaValue
        p.strokeWidth = stroke
        val cx = b.left + w / 2f
        val top = b.top + h * 0.18f
        val bot = b.top + h * 0.82f
        val wing = w * 0.26f
        c.drawLine(cx, top, cx, bot, p)
        val path = Path()
        path.moveTo(cx - wing, bot - wing)
        path.lineTo(cx, bot)
        path.lineTo(cx + wing, bot - wing)
        c.drawPath(path, p)
    }

    override fun setAlpha(alpha: Int) { alphaValue = alpha }
    override fun setColorFilter(colorFilter: ColorFilter?) { p.colorFilter = colorFilter }
    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
