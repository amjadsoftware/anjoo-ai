package com.anjoo.assistant

import org.junit.Test
import org.junit.Assert.*

class LangPrefTest {
    @Test fun allKeysAreUnique() {
        val keys = LangPref.ALL.map { it.key }
        assertEquals(keys.distinct(), keys)
    }
    @Test fun rtlOnlyForArabicAndUrdu() {
        assertTrue(LangPref.ALL.first { it.key == LangPref.ARABIC }.rtl)
        assertTrue(LangPref.ALL.first { it.key == LangPref.URDU }.rtl)
        assertFalse(LangPref.ALL.first { it.key == LangPref.ENGLISH }.rtl)
        assertFalse(LangPref.ALL.first { it.key == LangPref.ROMAN }.rtl)
    }
    @Test fun fiveOptionsExist() { assertEquals(5, LangPref.ALL.size) }
}
