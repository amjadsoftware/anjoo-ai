# Anjoo AI v99.2.14 (includes everything from 99.2.13)
- Invoices/pages/dashboards render live inside the chat message (MainActivity.inlineArtifactCard), no extra tap.
- Markdown sent for a page/invoice is converted to a styled page; invoice design spec (Artifacts.INVOICE_RULES).
- New tools: paste_text, send_in_app (asks before pressing Send). type_text falls back to clipboard paste.
- When Accessibility is off, the app opens Accessibility settings and explains "Allow restricted settings".
- GF mode rewritten: real-girlfriend tone (loving, lazy-sweet, flirty, playful fights), addresses the owner (Amjad) by name, chat-only, always a woman's voice (GeminiVoice.voiceFor, Speaker). Non-explicit.
- Invoice/bill/receipt requests never go to the coding tools: write_code/create_page/project_studio(build) are redirected to create_artifact (MoreTools.kt, Artifacts.billInstead), plus a "SHOW, DON'T CODE" prompt rule (Style.kt) and tool descriptions (Gemini.kt).
- Auto update: every time the app is opened (max once/15 min) it checks GitHub; a newer release downloads and installs by itself (Updater.checkOnLaunch/start), the app reopens after the update (UpdatedReceiver). Toggle: Settings > "Update app automatically when opened" (default ON). One-time permissions: Install unknown apps + Display over other apps.
