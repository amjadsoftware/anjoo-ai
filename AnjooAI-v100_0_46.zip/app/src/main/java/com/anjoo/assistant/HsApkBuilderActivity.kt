package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.time.Instant
import java.util.Locale
import java.util.UUID
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Cloud APK builder. Uses a user-owned GitHub repository and Actions; no third-party build server is embedded. */
class HsApkBuilderActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private val bg = Color.rgb(249, 247, 243)
    private val surface = Color.rgb(255, 255, 255)
    private val surface2 = Color.rgb(242, 239, 233)
    private val ink = Color.rgb(48, 46, 42)
    private val muted = Color.rgb(117, 112, 104)
    private val green = Color.rgb(67, 119, 84)
    private val border = Color.argb(45, 92, 81, 65)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(90, TimeUnit.SECONDS)
        .callTimeout(150, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
    // Large ZIP uploads on a slow connection need much more than the 150 s call limit of the normal client.
    private val uploadHttp = http.newBuilder().callTimeout(15, TimeUnit.MINUTES).writeTimeout(5, TimeUnit.MINUTES).build()

    private var repoInput: EditText? = null
    private var tokenInput: EditText? = null
    private var cloudUrlInput: EditText? = null
    private var cloudAnonKeyInput: EditText? = null
    private var cloudEmailInput: EditText? = null
    private var cloudOtpInput: EditText? = null
    private var cloudStatusText: TextView? = null
    private var cloudSectionView: View? = null
    private var cloudToggleView: TextView? = null
    private var statusText: TextView? = null
    private var targetViews: List<TextView> = emptyList()
    private var targetToggleView: TextView? = null
    private var selectedTarget = "auto"
    private var progressDialog: AlertDialog? = null
    private var progressLabel: TextView? = null
    private var progressTimeLabel: TextView? = null
    private var buildStartMs = 0L
    private var cancelRunId = -1L           // GitHub run ID for cancel
    private var cancelRepo = ""
    private var cancelToken = ""
    @Volatile private var cancelRequested = false
    private var packageNameInput: EditText? = null
    private var versionInput: EditText? = null
    private var ideaInput: EditText? = null

    private data class BuildRecord(val projectName: String, val filename: String, val runUrl: String, val ts: Long, val ok: Boolean)

    private data class ApiResult(val code: Int, val bytes: ByteArray) {
        val text: String get() = bytes.toString(Charsets.UTF_8)
        fun json(): JSONObject = try { JSONObject(text) } catch (_: Exception) { JSONObject() }
    }
    private data class BuildResult(val uri: Uri, val filename: String, val runUrl: String, val buildInfo: String)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, stroke: Int = border, radius: Int = 15) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }
    private fun text(label: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = label; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private fun button(label: String, primary: Boolean = false, click: () -> Unit) = TextView(this).apply {
        text = label; textSize = 12.5f; gravity = Gravity.CENTER
        setTextColor(if (primary) Color.WHITE else ink)
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        background = rounded(if (primary) green else surface2, if (primary) green else border, 11)
        setPadding(dp(12), dp(11), dp(12), dp(11)); setOnClickListener { click() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        ensurePersonalBootstrapToken()
        render()
        handleMagicLink(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleMagicLink(intent)
    }

    /** Supabase email-confirmation links return directly to this activity, never localhost:3000. */
    private fun handleMagicLink(incoming: Intent?) {
        val raw = incoming?.data?.toString().orEmpty()
        if (!raw.startsWith("anjooai://auth/callback")) return
        // A confirmation link should bring the relevant cloud controls into view automatically.
        cloudSectionView?.visibility = View.VISIBLE
        cloudToggleView?.text = "Permanent cloud backup · hide  −"
        val uri = Uri.parse(raw)
        val fragment = uri.fragment.orEmpty()
        fun part(key: String): String {
            val source = if (fragment.isNotBlank()) fragment else uri.encodedQuery.orEmpty()
            return source.split('&').firstOrNull { it.substringBefore('=') == key }
                ?.substringAfter('=', "")?.let { Uri.decode(it) }.orEmpty()
        }
        val access = part("access_token")
        val refresh = part("refresh_token")
        if (access.isBlank()) {
            cloudStatusText?.text = "Email link opened, but no session token was found. Check {{ .ConfirmationURL }} in the Supabase email template and the app redirect settings."
            return
        }
        try {
            saveCloudSecret("hs_cloud_access_token", access)
            if (refresh.isNotBlank()) saveCloudSecret("hs_cloud_refresh_token", refresh)
            cloudStatusText?.text = "Email verified. Restoring the token from the encrypted cloud vault…"
            Thread {
                try {
                    val remote = cloudVault("get")
                    val token = remote.optString("token")
                    val repo = remote.optString("repo")
                    if (token.isBlank()) throw IOException("Email verified, but no GitHub token is saved in the cloud vault yet. Enter the token once and press Back up GitHub token.")
                    if (repo == TOKEN_ONLY_REPO) saveToken(token)
                    else if (validRepo(repo)) saveConnection(repo, token)
                    else throw IOException("The cloud vault's repository record is invalid.")
                    mainHandler.post {
                        if (repoInput != null && validRepo(repo)) repoInput?.setText(repo)
                        tokenInput?.setText("")
                        tokenInput?.hint = "GitHub token restored from cloud — leave blank to reuse"
                        cloudStatusText?.text = "Email verified. GitHub token restored from encrypted cloud vault ✓"
                        toast("Email confirmation successful — token restored.")
                    }
                } catch (e: Exception) {
                    mainHandler.post { cloudStatusText?.text = "Email verified, but restore failed: ${readableError(e)}" }
                }
            }.start()
        } catch (e: Exception) {
            cloudStatusText?.text = "Email link received, but the session was not saved: ${readableError(e)}"
        }
    }

    /** Tokens must be entered by the owner in-app; never embed a GitHub credential in the APK. */
    private fun ensurePersonalBootstrapToken() { /* intentionally no embedded token */ }

    private fun prefs() = getSharedPreferences("anjoo", MODE_PRIVATE)

    private fun saveBuildRecord(r: BuildRecord) {
        val p = prefs()
        val list = getBuildHistory().toMutableList()
        list.add(0, r)
        val kept = list.take(15)
        val joined = kept.joinToString("|BSEP|") { "${r.projectName}¬${r.filename}¬${r.runUrl}¬${r.ts}¬${r.ok}" }
        // correct: use each item not r
        val joined2 = kept.joinToString("|BSEP|") { b -> "${b.projectName}¬${b.filename}¬${b.runUrl}¬${b.ts}¬${b.ok}" }
        p.edit().putString("hs_build_history", joined2).apply()
    }
    private fun getBuildHistory(): List<BuildRecord> {
        val raw = prefs().getString("hs_build_history", "") ?: return emptyList()
        return raw.split("|BSEP|").filter { it.isNotBlank() }.mapNotNull { s ->
            val p = s.split("¬")
            if (p.size >= 5) try { BuildRecord(p[0], p[1], p[2], p[3].toLong(), p[4].toBoolean()) } catch (_: Exception) { null } else null
        }
    }

    private fun savedToken(): String {
        return try {
            val encoded = prefs().getString("hs_apk_github_token", null) ?: return ""
            val bytes = Base64.decode(encoded, Base64.DEFAULT)
            (Crypt.decrypt(this, bytes) ?: return "").toString(Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    private fun saveToken(token: String) {
        val encrypted = Crypt.encrypt(this, token.toByteArray(Charsets.UTF_8))
            ?: throw IllegalStateException("Could not encrypt the GitHub token with the phone's Android Keystore.")
        prefs().edit()
            .putString("hs_apk_github_token", Base64.encodeToString(encrypted, Base64.NO_WRAP))
            .apply()
    }

    private fun saveConnection(repo: String, token: String) {
        saveToken(token)
        prefs().edit().putString("hs_apk_github_repo", repo.trim()).apply()
    }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(13), dp(11), dp(13), dp(11)); background = rounded(surface, border, 0)
        }
        toolbar.addView(button("‹  Back") { finish() })
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("HS  ·  APK Builder", 18f, ink, true))
        brand.addView(text("BUILD • DOWNLOAD • INSTALL", 9f, green, true).apply { letterSpacing = 0.08f })
        toolbar.addView(brand, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        root.addView(toolbar, LinearLayout.LayoutParams(-1, -2))

        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(15), dp(15), dp(15), dp(22)) }
        content.addView(text("Build an APK", 25f, ink, true))
        content.addView(text("Connect once, then choose a project and build it.", 13f, muted).apply {
            setPadding(0, dp(4), 0, dp(15))
        })

        val connect = section("Connect GitHub", "One-time setup. Create a PRIVATE repository initialized with a README. The builder workflow is added there automatically; do not select the Anjoo source repository.")
        repoInput = EditText(this).apply {
            hint = "Private GitHub repository: username/hs-apk-builder"
            setText(prefs().getString("hs_apk_github_repo", "") ?: "")
            isSingleLine = true; textSize = 13.5f; setTextColor(ink); setHintTextColor(muted)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            background = rounded(surface2, border, 10); setPadding(dp(12), dp(11), dp(12), dp(11))
        }
        connect.addView(repoInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        tokenInput = EditText(this).apply {
            hint = if (savedToken().isNotBlank()) "GitHub token saved — leave blank to reuse" else "GitHub fine-grained token"
            isSingleLine = true; textSize = 13.5f; setTextColor(ink); setHintTextColor(muted)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            background = rounded(surface2, border, 10); setPadding(dp(12), dp(11), dp(12), dp(11))
        }
        connect.addView(tokenInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        connect.addView(text("Use a separate PRIVATE repository, not your Anjoo source repo. Token permissions: Contents read/write, Actions read/write, Workflows read/write. Keep the token private; it is encrypted on this phone and sent only to GitHub's API.", 11f, muted).apply {
            setLineSpacing(dp(1).toFloat(), 1.05f); setPadding(dp(1), 0, dp(1), dp(9))
        })
        val links = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        links.addView(button("Create repo ↗") { openUrl("https://github.com/new") }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(4) })
        links.addView(button("Create token ↗") { openUrl("https://github.com/settings/personal-access-tokens/new") }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
        connect.addView(links, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val connectionActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        connectionActions.addView(button("Save & test connection", true) { testConnection() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(4) })
        connectionActions.addView(button("Clear saved token") {
            prefs().edit().remove("hs_apk_github_token").apply()
            tokenInput?.setText("")
            tokenInput?.hint = "GitHub fine-grained token"
            Toast.makeText(this@HsApkBuilderActivity, "Saved token cleared", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
        connect.addView(connectionActions, LinearLayout.LayoutParams(-1, -2))
        connect.visibility = View.GONE
        lateinit var githubToggle: TextView
        githubToggle = button("GitHub connection · ${if (savedToken().isNotBlank()) "token saved" else "setup once"}  +", true) {
            val open = connect.visibility != View.VISIBLE
            connect.visibility = if (open) View.VISIBLE else View.GONE
            githubToggle.text = if (open) "GitHub connection · hide  −" else "GitHub connection · ${if (savedToken().isNotBlank()) "token saved" else "setup once"}  +"
        }
        content.addView(githubToggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        content.addView(connect, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val cloud = section(
            "Permanent cloud backup",
            "Save the GitHub token in the encrypted Supabase vault. After reinstalling, restore it with the email confirmation link or email code. The Supabase SQL + Edge Function must be deployed first."
        )
        cloudUrlInput = EditText(this).apply {
            hint = "Supabase project URL"
            setText(prefs().getString("hs_cloud_supabase_url", DEFAULT_SUPABASE_URL) ?: DEFAULT_SUPABASE_URL)
            isSingleLine = true; textSize = 12.5f; setTextColor(ink); setHintTextColor(muted)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            background = rounded(surface2, border, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        cloud.addView(cloudUrlInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        cloudAnonKeyInput = EditText(this).apply {
            hint = "Supabase anon / publishable key"
            setText(prefs().getString("hs_cloud_supabase_anon_key", BuildConfig.HS_SUPABASE_ANON_KEY) ?: BuildConfig.HS_SUPABASE_ANON_KEY)
            isSingleLine = true; textSize = 12.5f; setTextColor(ink); setHintTextColor(muted)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            background = rounded(surface2, border, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        cloud.addView(cloudAnonKeyInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        cloudEmailInput = EditText(this).apply {
            hint = "Your email address"
            setText(prefs().getString("hs_cloud_email", "") ?: "")
            isSingleLine = true; textSize = 12.5f; setTextColor(ink); setHintTextColor(muted)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            background = rounded(surface2, border, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        cloud.addView(cloudEmailInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        cloudOtpInput = EditText(this).apply {
            hint = "Email code (if your email contains one)"
            isSingleLine = true; textSize = 12.5f; setTextColor(ink); setHintTextColor(muted)
            inputType = InputType.TYPE_CLASS_NUMBER
            background = rounded(surface2, border, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        cloud.addView(cloudOtpInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val cloudAuthButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        cloudAuthButtons.addView(button("Send sign-in email") { sendCloudCode() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(4) })
        cloudAuthButtons.addView(button("Verify code / restore", true) { verifyCloudCode() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
        cloud.addView(cloudAuthButtons, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        val cloudBackupButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        cloudBackupButtons.addView(button("Back up GitHub token", true) { backUpCloudToken() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(4) })
        cloudBackupButtons.addView(button("Delete cloud copy") { deleteCloudToken() }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
        cloud.addView(cloudBackupButtons, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        cloudStatusText = text("Not signed in. Expand cloud backup to connect your email.", 11f, muted).apply { setPadding(dp(1), dp(5), dp(1), 0) }
        cloud.addView(cloudStatusText)
        cloud.visibility = View.GONE
        cloudSectionView = cloud
        lateinit var cloudToggle: TextView
        cloudToggle = button("Permanent cloud backup · manage  +") {
            val open = cloud.visibility != View.VISIBLE
            cloud.visibility = if (open) View.VISIBLE else View.GONE
            cloudToggle.text = if (open) "Permanent cloud backup · hide  −" else "Permanent cloud backup · manage  +"
        }
        cloudToggleView = cloudToggle
        content.addView(cloudToggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        content.addView(cloud, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val target = section("Build type", "Auto detects a native Gradle Android project. If only a website exists, Auto builds a WebView APK from index.html.")
        val targetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; background = rounded(surface2, border, 12)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val choices = listOf("Auto detect" to "auto", "Native" to "native", "WebView APK" to "web")
        val made = mutableListOf<TextView>()
        choices.forEachIndexed { index, pair ->
            val tv = TextView(this).apply {
                text = pair.first; textSize = 12f; gravity = Gravity.CENTER
                setPadding(dp(4), dp(10), dp(4), dp(10))
                setOnClickListener { selectedTarget = pair.second; applyTargetStyles(); targetToggleView?.text = "Build type · ${pair.first}  +" }
            }
            made.add(tv)
            targetRow.addView(tv, LinearLayout.LayoutParams(0, -2, 1f).apply {
                if (index == 0) marginEnd = dp(3) else marginStart = dp(3)
            })
        }
        targetViews = made
        target.addView(targetRow, LinearLayout.LayoutParams(-1, -2))
        target.visibility = View.GONE
        lateinit var targetToggle: TextView
        targetToggle = button("Build type · Auto detect  +") {
            val open = target.visibility != View.VISIBLE
            target.visibility = if (open) View.VISIBLE else View.GONE
            targetToggle.text = if (open) "Build type · hide  −" else "Build type · ${when (selectedTarget) { "native" -> "Native"; "web" -> "WebView APK"; else -> "Auto detect" }}  +"
        }
        targetToggleView = targetToggle
        content.addView(targetToggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        content.addView(target, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })
        applyTargetStyles()

        // ── App Metadata (package + version) ─────────────────────────────
        val meta = section("App info (optional)", "Customize the package name and version number. If left blank, HS uses safe defaults derived from the project name.")
        packageNameInput = EditText(this).apply {
            hint = "Package name: com.yourname.appname"
            setText(prefs().getString("hs_pkg_name", "") ?: "")
            isSingleLine = true; textSize = 13f; setTextColor(ink); setHintTextColor(muted)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            background = rounded(surface2, border, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        versionInput = EditText(this).apply {
            hint = "Version name: 1.0.0"
            setText(prefs().getString("hs_version_name", "1.0") ?: "1.0")
            isSingleLine = true; textSize = 13f; setTextColor(ink); setHintTextColor(muted)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            background = rounded(surface2, border, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        meta.addView(packageNameInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        meta.addView(versionInput, LinearLayout.LayoutParams(-1, -2))
        meta.visibility = View.GONE
        var metaToggle: TextView? = null
        metaToggle = button("App info · optional  +") {
            val open = meta.visibility != View.VISIBLE
            meta.visibility = if (open) View.VISIBLE else View.GONE
            metaToggle?.text = if (open) "App info · hide  −" else "App info · optional  +"
        }
        content.addView(metaToggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        content.addView(meta, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })

        val idea = section("Idea → APK", "Write what you want: an app, a tool or an HTML5 game. Anjoo builds it in the chat as a self-contained app, then this screen offers to turn it into an APK.")
        ideaInput = EditText(this).apply {
            hint = "Example: a 2-player Ludo game with dice animation"
            isSingleLine = false; minLines = 3; maxLines = 6; gravity = Gravity.TOP
            textSize = 13.5f; setTextColor(ink); setHintTextColor(muted)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = rounded(surface2, border, 10); setPadding(dp(12), dp(11), dp(12), dp(11))
        }
        idea.addView(ideaInput, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        idea.addView(button("Build my app  ✨", true) { startIdeaBuild() }, LinearLayout.LayoutParams(-1, -2))
        content.addView(idea, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        content.addView(text("Choose a project", 19f, ink, true).apply { setPadding(1, 0, 0, dp(5)) })
        content.addView(text("A finished build is downloaded as an APK file. You can install it on this Android phone.", 12f, muted).apply { setPadding(1, 0, 0, dp(11)) })
        content.addView(button("Import ZIP from phone  📦", true) { pickZip() }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        content.addView(text("Pick any project ZIP (an Android Gradle project, or a website with index.html). It is saved in your projects and can be built into an APK right away.", 11f, muted).apply {
            setLineSpacing(dp(1).toFloat(), 1.05f); setPadding(dp(1), 0, dp(1), dp(11))
        })
        val projectList = Coder.list(this)
        val requested = intent.getStringExtra("project")
        val projects = if (requested.isNullOrBlank()) projectList else projectList.sortedBy { if (it.absolutePath == requested) 0 else 1 }
        if (projects.isEmpty()) {
            val empty = section("No saved projects", "Import a ZIP above, or build an app or website in HS first. Then compile and download its APK here.")
            empty.addView(button("Open HS builder", true) {
                startActivity(Intent(this, HSActivity::class.java)); finish()
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
            content.addView(empty)
        } else {
            projects.forEach { dir ->
                val allFiles = try { dir.walkTopDown().filter { it.isFile && !it.name.startsWith(".anjoo") }.take(30000).toList() } catch (_: Exception) { emptyList() }
                val nativeProject = allFiles.any { it.name == "settings.gradle.kts" || it.name == "settings.gradle" }
                val hasIndex = allFiles.any { it.name.equals("index.html", true) }
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL; background = rounded(surface, border, 15)
                    setPadding(dp(13), dp(13), dp(13), dp(13))
                }
                card.addView(text(Coder.name(dir), 15.5f, ink, true).apply { maxLines = 2 })
                card.addView(text("${allFiles.size} files  ·  ${if (nativeProject) "Gradle project detected" else if (hasIndex) "Website preview file detected" else "Project type will be checked in cloud"}", 10.5f, muted).apply {
                    setPadding(0, dp(4), 0, dp(10))
                })
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                row.addView(button("Build APK ↓", true) { startCloudBuild(dir) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
                row.addView(button("Open Codixa") { startActivity(Intent(this@HsApkBuilderActivity, CodixaActivity::class.java)) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
                card.addView(row)
                content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }
        }

        // ── Build History ─────────────────────────────────────────────────
        val history = getBuildHistory()
        if (history.isNotEmpty()) {
            content.addView(text("Recent builds", 17f, ink, true).apply { setPadding(1, dp(14), 0, dp(6)) })
            val fmt = java.text.SimpleDateFormat("d MMM, HH:mm", java.util.Locale.ENGLISH)
            history.take(8).forEach { rec ->
                val hCard = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                    background = rounded(surface, border, 12); setPadding(dp(12), dp(10), dp(12), dp(10))
                }
                val statusDot = text(if (rec.ok) "●" else "✕", 13f, if (rec.ok) green else Color.parseColor("#D0594F"), true)
                hCard.addView(statusDot, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(10) })
                val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                info.addView(text(rec.projectName, 13f, ink, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END })
                info.addView(text("${fmt.format(java.util.Date(rec.ts))}  ·  ${rec.filename.take(28)}", 10.5f, muted))
                hCard.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                if (rec.runUrl.isNotBlank()) hCard.addView(button("Log ↗") { openUrl(rec.runUrl) }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
                content.addView(hCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            }
        }

        content.addView(text("What the cloud build does", 15f, ink, true).apply { setPadding(1, dp(14), 0, dp(5)) })
        content.addView(text("• Native Android Gradle project → compile its actual Android app.\n• Website project with index.html → package its local HTML/CSS/JS into a WebView APK.\n• Missing project files or compile errors → show the failed build instead of pretending it succeeded.\n\nThe source ZIP is uploaded as a temporary release asset in your PRIVATE repository (not a regular source-code commit), then HS attempts to delete that release and its tag after the build. Check Releases if cleanup is blocked. Build workflow and logs remain in your GitHub repository.", 11.5f, muted).apply {
            setLineSpacing(dp(2).toFloat(), 1.05f); setPadding(dp(1), 0, dp(1), 0)
        })
        val readyStatus = text("Connect GitHub once. For reinstall-safe token restore, sign in to the cloud vault and back up your connection.", 11.5f, muted).apply { setPadding(0, dp(14), 0, 0) }
        statusText = readyStatus
        content.addView(readyStatus)
        val scroll = ScrollView(this).apply { addView(content); isVerticalScrollBarEnabled = false; clipToPadding = false }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("HS APK BUILDER  ·  GITHUB ACTIONS", 9f, muted, true).apply { gravity = Gravity.CENTER; setPadding(dp(8), dp(12), dp(8), dp(12)) })
        setContentView(root)
    }

    private fun section(title: String, description: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = rounded(surface, border, 15)
        setPadding(dp(13), dp(13), dp(13), dp(13))
        addView(text(title, 15f, ink, true))
        addView(text(description, 11.5f, muted).apply { setLineSpacing(dp(1).toFloat(), 1.05f); setPadding(0, dp(4), 0, dp(10)) })
    }

    private fun applyTargetStyles() {
        val options = listOf("auto", "native", "web")
        targetViews.forEachIndexed { index, view ->
            val active = options.getOrNull(index) == selectedTarget
            view.setTextColor(if (active) Color.WHITE else muted)
            view.typeface = Typeface.create("sans-serif-medium", if (active) Typeface.BOLD else Typeface.NORMAL)
            view.background = rounded(if (active) green else Color.TRANSPARENT, if (active) green else Color.TRANSPARENT, 9)
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Exception) { Toast.makeText(this, "The browser did not open.", Toast.LENGTH_SHORT).show() }
    }

    private fun valuesFromUi(): Triple<String, String, String> = Triple(
        repoInput?.text?.toString()?.trim().orEmpty(),
        tokenInput?.text?.toString()?.trim().orEmpty(),
        selectedTarget
    )

    private fun cloudConfigFromUi(): Pair<String, String> {
        val url = cloudUrlInput?.text?.toString()?.trim()?.trimEnd('/').orEmpty()
        val anon = cloudAnonKeyInput?.text?.toString()?.trim().orEmpty()
        if (!url.startsWith("https://") || !url.endsWith(".supabase.co")) {
            throw IOException("Enter a valid Supabase Project URL (https://....supabase.co).")
        }
        if (anon.isBlank()) throw IOException("The Supabase anon/publishable key is missing. Copy the public key from Project Settings → API Keys.")
        prefs().edit().putString("hs_cloud_supabase_url", url).putString("hs_cloud_supabase_anon_key", anon).apply()
        return url to anon
    }

    private fun cloudConfig(): Pair<String, String> =
        (prefs().getString("hs_cloud_supabase_url", DEFAULT_SUPABASE_URL) ?: DEFAULT_SUPABASE_URL).trimEnd('/') to
            (prefs().getString("hs_cloud_supabase_anon_key", BuildConfig.HS_SUPABASE_ANON_KEY) ?: BuildConfig.HS_SUPABASE_ANON_KEY)

    private fun saveCloudSecret(name: String, value: String) {
        val encrypted = Crypt.encrypt(this, value.toByteArray(Charsets.UTF_8))
            ?: throw IllegalStateException("Could not encrypt the cloud session with the Android Keystore.")
        prefs().edit().putString(name, Base64.encodeToString(encrypted, Base64.NO_WRAP)).apply()
    }

    private fun readCloudSecret(name: String): String {
        return try {
            val encoded = prefs().getString(name, null) ?: return ""
            val bytes = Base64.decode(encoded, Base64.DEFAULT)
            (Crypt.decrypt(this, bytes) ?: return "").toString(Charsets.UTF_8)
        } catch (_: Exception) { "" }
    }

    private fun cloudRequest(url: String, anon: String, method: String, body: JSONObject, bearer: String? = null): ApiResult {
        val req = Request.Builder().url(url)
            .header("apikey", anon)
            .header("Accept", "application/json")
            .header("Content-Type", "application/json")
            .header("User-Agent", "AnjooAI-HS-TokenVault")
        if (!bearer.isNullOrBlank()) req.header("Authorization", "Bearer $bearer")
        req.method(method, body.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
        return http.newCall(req.build()).execute().use { response ->
            val bytes = response.body?.bytes() ?: ByteArray(0)
            if (bytes.size > 1024 * 1024) throw IOException("The Supabase response is larger than the expected size.")
            ApiResult(response.code, bytes)
        }
    }

    private fun sendCloudCode() {
        val email = cloudEmailInput?.text?.toString()?.trim().orEmpty()
        val (url, anon) = try { cloudConfigFromUi() } catch (e: Exception) { toast(e.message ?: "Check the Supabase settings."); return }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) { toast("Enter a valid email address."); return }
        prefs().edit().putString("hs_cloud_email", email).apply()
        showProgress("Sending the email sign-in code…")
        Thread {
            try {
                val otpUrl = "$url/auth/v1/otp?redirect_to=" + java.net.URLEncoder.encode("anjooai://auth/callback", "UTF-8")
                val result = cloudRequest(otpUrl, anon, "POST", JSONObject().put("email", email).put("create_user", true))
                if (result.code !in 200..299) throw IOException("Supabase email code send failed (HTTP ${result.code}): ${result.json().optString("msg", result.json().optString("message", result.text.take(350)))}")
                mainHandler.post {
                    finishProgress()
                    cloudStatusText?.text = "Sign-in email sent to $email. If it contains a code, enter it below; if it contains a link, tap the link to return to Anjoo AI."
                    toast("Sign-in email sent.")
                }
            } catch (e: Exception) { mainHandler.post { finishProgress(); showError("Cloud sign-in failed", readableError(e)) } }
        }.start()
    }

    private fun verifyCloudCode() {
        val email = cloudEmailInput?.text?.toString()?.trim().orEmpty()
        val otp = cloudOtpInput?.text?.toString()?.trim().orEmpty()
        val (url, anon) = try { cloudConfigFromUi() } catch (e: Exception) { toast(e.message ?: "Check the Supabase settings."); return }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() || otp.length !in 6..8) {
            toast("Enter the email and the verification code that came in the email. If you got a link, tap it."); return
        }
        showProgress("Verifying the email and restoring the cloud token…")
        Thread {
            try {
                val result = cloudRequest("$url/auth/v1/verify", anon, "POST", JSONObject().put("email", email).put("token", otp).put("type", "email"))
                if (result.code !in 200..299) throw IOException("Email verification failed (HTTP ${result.code}): ${result.json().optString("msg", result.json().optString("message", result.text.take(350)))}")
                val data = result.json()
                val access = data.optString("access_token")
                val refresh = data.optString("refresh_token")
                if (access.isBlank()) throw IOException("Supabase did not return an access token. Check the Auth email OTP settings.")
                saveCloudSecret("hs_cloud_access_token", access)
                if (refresh.isNotBlank()) saveCloudSecret("hs_cloud_refresh_token", refresh)
                val remote = try { cloudVault("get") } catch (e: Exception) {
                    mainHandler.post { finishProgress(); showError("Email verified, vault not ready", "Email verified, but could not connect to the cloud vault. Check the Supabase function deploy/secrets.\n\n${readableError(e)}") }
                    return@Thread
                }
                val token = remote.optString("token")
                val repo = remote.optString("repo")
                if (remote.optBoolean("hasToken", token.isNotBlank()) && token.isNotBlank()) {
                    val tokenOnly = repo == TOKEN_ONLY_REPO
                    if (tokenOnly) saveToken(token) else if (validRepo(repo)) saveConnection(repo, token)
                    else throw IOException("The repository record in the cloud vault is invalid.")
                    mainHandler.post {
                        if (!tokenOnly) repoInput?.setText(repo)
                        tokenInput?.setText("")
                        tokenInput?.hint = "GitHub token restored from cloud — leave blank to reuse"
                        cloudStatusText?.text = if (tokenOnly)
                            "Signed in as $email. GitHub token restored from encrypted cloud vault ✓ Add a private repo when ready to build."
                        else "Signed in as $email. GitHub connection restored from encrypted cloud vault ✓"
                        finishProgress()
                        toast("GitHub token restored from the cloud. You do not need to paste the token again.")
                    }
                } else {
                    // First cloud sign-in: automatically back up the built-in personal token if available.
                    val localToken = savedToken()
                    if (localToken.isNotBlank()) {
                        val currentRepo = repoInput?.text?.toString()?.trim().orEmpty()
                        val repoForVault = if (validRepo(currentRepo)) currentRepo else TOKEN_ONLY_REPO
                        cloudVault("store", JSONObject().put("repo", repoForVault).put("token", localToken))
                        mainHandler.post {
                            cloudStatusText?.text = "Signed in as $email. Personal GitHub token automatically backed up to encrypted cloud vault ✓"
                            finishProgress()
                            toast("Email verified — GitHub token cloud backup successful.")
                        }
                    } else {
                        mainHandler.post {
                            cloudStatusText?.text = "Signed in as $email, but no GitHub token was available to back up."
                            finishProgress()
                        }
                    }
                }
            } catch (e: Exception) { mainHandler.post { finishProgress(); showError("Cloud sign-in failed", readableError(e)) } }
        }.start()
    }

    private fun cloudVault(action: String, extras: JSONObject = JSONObject()): JSONObject {
        val (url, anon) = cloudConfig()
        if (url.isBlank() || anon.isBlank()) throw IOException("Supabase Project URL/public key is not configured. Follow the cloud token backup guide.")
        var access = readCloudSecret("hs_cloud_access_token")
        if (access.isBlank()) throw IOException("Not signed in to the cloud. Use Verify & restore with the email code.")
        fun invoke(bearer: String): ApiResult {
            val body = JSONObject(extras.toString()).put("action", action)
            return cloudRequest("$url/functions/v1/hs-github-token", anon, "POST", body, bearer)
        }
        var result = invoke(access)
        if (result.code == 401) {
            val refresh = readCloudSecret("hs_cloud_refresh_token")
            if (refresh.isNotBlank()) {
                val refreshed = cloudRequest("$url/auth/v1/token?grant_type=refresh_token", anon, "POST", JSONObject().put("refresh_token", refresh))
                if (refreshed.code in 200..299) {
                    val data = refreshed.json()
                    access = data.optString("access_token", access)
                    saveCloudSecret("hs_cloud_access_token", access)
                    data.optString("refresh_token").takeIf { it.isNotBlank() }?.let { saveCloudSecret("hs_cloud_refresh_token", it) }
                    result = invoke(access)
                }
            }
        }
        if (result.code !in 200..299) {
            val err = result.json().optString("error", result.json().optString("message", result.text.take(500)))
            throw IOException("Cloud vault request failed (HTTP ${result.code}): $err")
        }
        return result.json()
    }

    private fun backUpCloudToken() {
        val repo = repoInput?.text?.toString()?.trim().orEmpty()
        val token = tokenInput?.text?.toString()?.trim().orEmpty().ifBlank { savedToken() }
        if (repo.isNotBlank() && !validRepo(repo)) { toast("The repository format must be username/repository."); return }
        if (token.isBlank()) { toast("No personal token available. Enter a GitHub token."); return }
        val repoForVault = if (validRepo(repo)) repo else TOKEN_ONLY_REPO
        try { cloudConfigFromUi() } catch (e: Exception) { toast(e.message ?: "Supabase config missing."); return }
        showProgress("Saving the GitHub token in the secure cloud vault…")
        Thread {
            try {
                cloudVault("store", JSONObject().put("repo", repoForVault).put("token", token))
                mainHandler.post {
                    finishProgress()
                    cloudStatusText?.text = "GitHub token saved in the encrypted cloud vault. Restore it with the email code after reinstalling."
                    toast("Secure cloud backup successful.")
                }
            } catch (e: Exception) { mainHandler.post { finishProgress(); showError("Cloud backup failed", readableError(e)) } }
        }.start()
    }

    private fun deleteCloudToken() {
        AlertDialog.Builder(this).setTitle("Delete cloud token backup?")
            .setMessage("The saved GitHub token and repository will be deleted from the cloud vault. The token saved locally on the phone stays separate.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Delete") { _, _ ->
                showProgress("Deleting the cloud backup…")
                Thread {
                    try {
                        cloudVault("delete")
                        mainHandler.post { finishProgress(); cloudStatusText?.text = "Cloud token backup deleted."; toast("Cloud backup deleted.") }
                    } catch (e: Exception) { mainHandler.post { finishProgress(); showError("Delete failed", readableError(e)) } }
                }.start()
            }.show()
    }

    private fun testConnection() {
        val (repo, enteredToken, _) = valuesFromUi()
        val token = enteredToken.ifBlank { savedToken() }
        if (!validRepo(repo)) { toast("Write the repository in this format: username/repository"); return }
        if (token.isBlank()) { toast("Enter a GitHub token; leaving the token field blank only reuses the saved token."); return }
        showProgress("Checking the GitHub connection…")
        Thread {
            try {
                val result = request(token, "GET", repoUrl(repo), null)
                requireCode(result, 200, "Repository access was not verified")
                val data = result.json()
                if (!data.optBoolean("private", false)) throw IOException("For security this repository must be PRIVATE. Make it Private in the repository Settings on GitHub, then test again.")
                if (data.optString("default_branch").isBlank()) throw IOException("The repository's default branch was not found.")
                saveConnection(repo, token)
                val cloudBackupNote = if (readCloudSecret("hs_cloud_access_token").isNotBlank() && cloudConfig().second.isNotBlank()) {
                    try {
                        cloudVault("store", JSONObject().put("repo", repo).put("token", token))
                        " · cloud backup saved"
                    } catch (e: Exception) { " · cloud backup not saved: ${e.message.orEmpty().take(100)}" }
                } else ""
                mainHandler.post {
                    finishProgress()
                    statusText?.text = "Connected ✓  $repo  ·  branch ${data.optString("default_branch")}$cloudBackupNote"
                    tokenInput?.setText("")
                    tokenInput?.hint = "GitHub token saved — leave blank to reuse"
                    Toast.makeText(this, "GitHub connection saved and tested.", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                mainHandler.post { finishProgress(); showError("Connection failed", readableError(e)) }
            }
        }.start()
    }

    private fun ideaInstruction(idea: String): String =
        "HS IDEA → APK — MASTER BUILD\n" +
        "Build the complete, working app below. It will be packaged into an Android APK as a WebView app, so follow these rules:\n" +
        "• ONE self-contained index.html (CSS and JavaScript inline or in relative files). No CDN links, no external fonts, no backend: it must work offline inside the APK.\n" +
        "• Mobile-first, touch-friendly (buttons at least 44px), works from 320px wide, portrait first. Smooth, polished, modern design with a clear colour theme.\n" +
        "• Every button, menu and screen must really work. Keep data in localStorage so it survives closing the app. Seed realistic demo data so nothing looks empty.\n" +
        "• For a game: HTML5 canvas or DOM with touch controls, requestAnimationFrame loop, pause when the page is hidden, score/progress saved, sound optional via WebAudio.\n" +
        "• Put the app's real name in <title>. Name the project with that short app name.\n" +
        "• After writing, re-read index.html and fix missing functions, wrong ids and console errors before you finish.\n" +
        "• Do not stop to ask questions; make sensible choices and build everything.\n\n" +
        "USER IDEA:\n" + idea + "\n\n" +
        "DELIVERY: List the files. Then tell the user to open HS → APK Builder, which will offer to build the APK."

    private fun startIdeaBuild() {
        val idea = ideaInput?.text?.toString()?.trim().orEmpty()
        if (idea.length < 8) { toast("Write what you want to build first (a few words are enough)."); return }
        val repo = prefs().getString("hs_apk_github_repo", "").orEmpty()
        if (!validRepo(repo) || savedToken().isBlank()) {
            toast("First open \"GitHub connection\" above and press Save & test connection (one time), so the APK can be built afterwards.")
            return
        }
        prefs().edit().putLong("hs_idea_ts", System.currentTimeMillis()).putString("hs_idea_text", idea.take(500)).apply()
        startActivity(Intent(this, MainActivity::class.java).apply {
            putExtra("habit_prompt", ideaInstruction(idea))
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        })
        finish()
    }

    override fun onResume() {
        super.onResume()
        checkPendingIdea()
    }

    /** After "Idea → APK", the finished project is offered for building as soon as this screen is opened again. */
    private fun checkPendingIdea() {
        val ts = prefs().getLong("hs_idea_ts", 0L)
        if (ts <= 0L || progressDialog != null) return
        fun clearPending() { prefs().edit().remove("hs_idea_ts").remove("hs_idea_text").apply() }
        if (System.currentTimeMillis() - ts > 6L * 60 * 60 * 1000) { clearPending(); return }
        val dir = Coder.list(this).firstOrNull { d ->
            d.lastModified() > ts && d.walkTopDown().any { it.isFile && (it.name.equals("index.html", true) || it.name == "settings.gradle.kts" || it.name == "settings.gradle") }
        } ?: return
        val newest = try { dir.walkTopDown().filter { it.isFile }.maxOfOrNull { it.lastModified() } ?: 0L } catch (_: Exception) { 0L }
        if (System.currentTimeMillis() - newest < 15_000L) {
            toast("Anjoo is still writing the app. Open this screen again in a moment.")
            return
        }
        clearPending()
        val count = dir.walkTopDown().count { it.isFile && !it.name.startsWith(".anjoo") }
        AlertDialog.Builder(this)
            .setTitle("Your app is ready")
            .setMessage("${Coder.name(dir)}  ·  $count files\n\nBuild the APK now? If Anjoo is still working on it, choose Later.")
            .setPositiveButton("Build APK") { _, _ -> startCloudBuild(dir) }
            .setNegativeButton("Later", null)
            .show()
    }

    private fun pickZip() {
        try {
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream"))
            }
            startActivityForResult(pick, REQ_PICK_ZIP)
        } catch (e: Exception) { toast("Could not open the file picker: ${e.message.orEmpty()}") }
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK_ZIP || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        importPickedZip(uri)
    }

    private fun importPickedZip(uri: Uri) {
        var name = "project.zip"
        var size = -1L
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    val si = c.getColumnIndex(android.provider.OpenableColumns.SIZE)
                    if (ni >= 0) name = c.getString(ni) ?: name
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                }
            }
        } catch (_: Exception) {}
        if (size > MAX_PICK_ZIP_BYTES) { toast("This ZIP is ${size / 1024 / 1024} MB; the limit is ${MAX_PICK_ZIP_BYTES / 1024 / 1024} MB."); return }
        val reading = AlertDialog.Builder(this).setMessage("Reading the ZIP…").setCancelable(false).create().also { it.show() }
        Thread {
            val dir = try { contentResolver.openInputStream(uri)?.use { Coder.importBuildZip(this, it, name) } } catch (_: Exception) { null }
            mainHandler.post {
                try { reading.dismiss() } catch (_: Exception) {}
                if (dir == null) {
                    showError("ZIP could not be imported", "The file is not a valid ZIP, has no usable files, or is larger than the unpacked limit (250 MB). node_modules, .git, build and .gradle folders are skipped automatically.")
                } else {
                    val count = dir.walkTopDown().count { it.isFile && !it.name.startsWith(".anjoo") }
                    AlertDialog.Builder(this)
                        .setTitle("ZIP imported")
                        .setMessage("${Coder.name(dir)}  ·  $count files\n\nBuild the APK now?")
                        .setPositiveButton("Build APK") { _, _ -> startCloudBuild(dir) }
                        .setNegativeButton("Later") { _, _ -> render() }
                        .show()
                }
            }
        }.start()
    }

    private fun startCloudBuild(project: File) {
        val (repo, typedToken, target) = valuesFromUi()
        val token = typedToken.ifBlank { savedToken() }
        if (!validRepo(repo)) { toast("First enter the GitHub repository in username/repository format."); return }
        if (token.isBlank()) { toast("First enter the GitHub token and press Save & test connection."); return }
        if (project.walkTopDown().none { it.isFile && !it.name.startsWith(".anjoo") }) {
            toast("This project has no files to build."); return
        }
        val pkgName = packageNameInput?.text?.toString()?.trim().orEmpty()
        val versionName = versionInput?.text?.toString()?.trim().orEmpty().ifBlank { "1.0" }
        if (pkgName.isNotBlank()) prefs().edit().putString("hs_pkg_name", pkgName).putString("hs_version_name", versionName).apply()
        cancelRequested = false
        cancelRepo = repo; cancelToken = token
        showProgress("Preparing the project…")
        val projectName = Coder.name(project)
        Thread {
            var runUrl = "https://github.com/$repo/actions"
            var buildOk = false
            try {
                val result = performBuild(project, repo, token, target, pkgName, versionName)
                runUrl = result.runUrl
                buildOk = true
                saveBuildRecord(BuildRecord(projectName, result.filename, result.runUrl, System.currentTimeMillis(), true))
                sendBuildNotification(projectName, true)
                mainHandler.post {
                    finishProgress()
                    statusText?.text = "APK downloaded: ${result.filename}"
                    AlertDialog.Builder(this)
                        .setTitle("APK is ready")
                        .setMessage(result.filename + "\n\n" + result.buildInfo.ifBlank { "Build successful." } + "\n\nSaved in the Downloads folder. Install now?")
                        .setPositiveButton("Install") { _, _ -> installApk(result.uri) }
                        .setNeutralButton("Build log") { _, _ -> openUrl(result.runUrl) }
                        .setNegativeButton("Done", null)
                        .show()
                }
            } catch (e: Exception) {
                saveBuildRecord(BuildRecord(projectName, "", runUrl, System.currentTimeMillis(), false))
                sendBuildNotification(projectName, false)
                mainHandler.post {
                    finishProgress()
                    statusText?.text = "Build failed. Read the message and fix the project or the GitHub permissions."
                    val msg = readableError(e)
                    val foundUrl = Regex("""https://github.com/[^\s]+/actions/runs/[0-9]+""").find(msg)?.value ?: runUrl
                    AlertDialog.Builder(this).setTitle("✕  APK build fail")
                        .setMessage(msg)
                        .setPositiveButton("OK", null)
                        .setNeutralButton("Build logs") { _, _ -> openUrl(foundUrl) }
                        .setNegativeButton("Copy error") { _, _ ->
                            try {
                                val cm = getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                cm.setPrimaryClip(android.content.ClipData.newPlainText("HS build error", msg))
                                toast("Error copied")
                            } catch (_: Exception) {}
                        }
                        .show()
                }
            }
        }.start()
    }

    private fun performBuild(project: File, repo: String, token: String, target: String, pkgName: String = "", versionName: String = "1.0"): BuildResult {
        if (!validRepo(repo)) throw IOException("The repository format is wrong. Use username/repository.")
        updateProgress("Verifying the GitHub repository and permissions…")
        val repoResult = request(token, "GET", repoUrl(repo), null)
        requireCode(repoResult, 200, "The GitHub repository could not be opened")
        val repoInfo = repoResult.json()
        if (!repoInfo.optBoolean("private", false)) throw IOException("For security the build repository must be PRIVATE. The source was not uploaded to a public repository.")
        val branch = repoInfo.optString("default_branch").ifBlank { "main" }
        saveConnection(repo, token)

        val workflowBytes = assets.open("hs-build-apk.yml").use { it.readBytes() }
        updateProgress("Setting up the APK build workflow…")
        ensureWorkflow(token, repo, branch, workflowBytes)

        val buildId = UUID.randomUUID().toString().replace("-", "").take(20)
        val archive = projectZip(project)
        if (archive.isEmpty()) throw IOException("The project ZIP is empty; check the project files.")
        if (archive.size > MAX_UPLOAD_BYTES) throw IOException("The compressed project ZIP is ${archive.size / 1024 / 1024} MB. This builder's per-build upload limit is ${MAX_UPLOAD_BYTES / 1024 / 1024} MB; remove node_modules, build output or large media files and try again.")

        val sourceTag = "hs-build-$buildId"
        var temporaryReleaseCreated = false
        var runUrl = "https://github.com/$repo/actions"
        var buildResult: BuildResult? = null
        var cleanupWarning = ""
        try {
            updateProgress("Creating a private temporary source release…")
            val releaseBody = JSONObject()
                .put("tag_name", sourceTag)
                .put("target_commitish", branch)
                .put("name", "HS temporary source $buildId")
                .put("body", "Temporary source asset for HS APK build. HS attempts to remove the asset, release and tag when the build completes.")
                .put("draft", false)
                .put("prerelease", true)
            val releaseResult = request(token, "POST", "https://api.github.com/repos/$repo/releases", releaseBody)
            requireCode(releaseResult, 201, "The temporary source release was not created")
            temporaryReleaseCreated = true
            val release = releaseResult.json()
            val uploadTemplate = release.optString("upload_url")
            if (uploadTemplate.isBlank()) throw IOException("GitHub did not give the release asset upload URL.")
            val uploadUrl = uploadTemplate.substringBefore("{?") + "?name=source.zip"

            updateProgress("Uploading the source ZIP as a private release asset…")
            val assetResult = requestBytes(token, "POST", uploadUrl, archive, "application/zip")
            requireCode(assetResult, 201, "The source ZIP was not uploaded")

            updateProgress("Starting the cloud Android build…")
            val startTime = System.currentTimeMillis()
            val dispatch = JSONObject()
                .put("ref", branch)
                .put("inputs", JSONObject()
                    .put("build_id", buildId)
                    .put("source_tag", sourceTag)
                    .put("project_name", Coder.name(project).take(90))
                    .put("target", target)
                    .put("pkg_name", pkgName.ifBlank { "" })
                    .put("version_name", versionName.ifBlank { "1.0" }))
            val dispatchResult = request(token, "POST", "https://api.github.com/repos/$repo/actions/workflows/hs-build-apk.yml/dispatches", dispatch)
            requireCode(dispatchResult, 204, "Could not start GitHub Actions")

            val run = waitForRun(repo, token, branch, startTime, buildId)
            runUrl = run.optString("html_url", runUrl)
            if (run.optString("conclusion") != "success") {
                val conclusion = run.optString("conclusion", "failed")
                updateProgress("Build failed. Reading the error from the build log…")
                val detail = if (conclusion == "failure") fetchFailureSummary(repo, token, run.optLong("id")) else ""
                throw IOException("Cloud build $conclusion. Build log: $runUrl" + (if (detail.isNotBlank()) "\n\n$detail" else ""))
            }

            updateProgress("Build successful. Downloading the APK artifact…")
            val artifactBytes = fetchArtifact(repo, token, run.optLong("id"), buildId)
            val artifactEntries = unzipArtifact(artifactBytes)
            val apkEntry = artifactEntries.entries.firstOrNull { it.key.lowercase(Locale.ROOT).endsWith(".apk") }
                ?: throw IOException("The build was reported successful, but no APK was found in the artifact ZIP.")
            val info = artifactEntries.entries.firstOrNull { it.key.substringAfterLast('/').equals("BUILD-INFO.txt", true) }?.value?.toString(Charsets.UTF_8)?.trim().orEmpty()
            val filename = safeFileName(Coder.name(project)) + "-" + buildId.take(6) + ".apk"
            updateProgress("Saving the APK in the phone's Downloads folder…")
            val uri = saveToDownloads(filename, apkEntry.value)
            buildResult = BuildResult(uri, filename, runUrl, info)
        } finally {
            if (temporaryReleaseCreated) {
                updateProgress("Cleaning up the temporary source release…")
                try {
                    deleteTemporaryRelease(token, repo, sourceTag)
                } catch (e: Exception) {
                    cleanupWarning = "WARNING: Could not auto-delete the temporary GitHub source release. Delete the '$sourceTag' release manually in the Releases tab of the private repository. Detail: ${e.message.orEmpty().take(300)}"
                }
            }
        }
        val result = buildResult ?: throw IOException("APK build result unavailable.")
        return if (cleanupWarning.isBlank()) result else result.copy(buildInfo = listOf(result.buildInfo, cleanupWarning).filter { it.isNotBlank() }.joinToString("\n\n"))
    }

    private fun ensureWorkflow(token: String, repo: String, branch: String, wanted: ByteArray) {
        val path = ".github/workflows/hs-build-apk.yml"
        val endpoint = contentUrl(repo, path, branch)
        val existing = request(token, "GET", endpoint, null)
        if (existing.code == 200) {
            val current = existing.json()
            val raw = try { Base64.decode(current.optString("content").replace("\n", ""), Base64.DEFAULT) } catch (_: Exception) { ByteArray(0) }
            if (!raw.contentEquals(wanted)) {
                putContents(token, repo, branch, path, wanted, "HS: update Android APK build workflow", current.optString("sha").takeIf { it.isNotBlank() })
            }
        } else if (existing.code == 404) {
            putContents(token, repo, branch, path, wanted, "HS: add Android APK build workflow", null)
        } else {
            requireCode(existing, 200, "Could not read the existing build workflow")
        }
        // GitHub's workflow registry can lag just behind the Contents API commit.
        repeat(8) {
            val check = request(token, "GET", "https://api.github.com/repos/$repo/actions/workflows/hs-build-apk.yml", null)
            if (check.code == 200 && check.json().optString("state") == "active") return
            Thread.sleep(2000)
        }
        throw IOException("GitHub Actions did not activate hs-build-apk.yml. Check the repository Actions settings, default branch and Workflows write permission.")
    }

    private fun waitForRun(repo: String, token: String, branch: String, startTime: Long, buildId: String): JSONObject {
        val url = "https://api.github.com/repos/$repo/actions/workflows/hs-build-apk.yml/runs?branch=${Uri.encode(branch)}&event=workflow_dispatch&per_page=10"
        var tracked: JSONObject? = null
        for (attempt in 0 until 120) {
            val result = request(token, "GET", url, null)
            requireCode(result, 200, "Could not read the build status")
            val runs = result.json().optJSONArray("workflow_runs")
            if (runs != null) {
                for (i in 0 until runs.length()) {
                    val candidate = runs.optJSONObject(i) ?: continue
                    val createdAt = try { Instant.parse(candidate.optString("created_at")).toEpochMilli() } catch (_: Exception) { 0L }
                    val titleMatches = candidate.optString("display_title").contains(buildId, ignoreCase = true)
                    if ((titleMatches || createdAt >= startTime - 30_000) && candidate.optString("head_branch") == branch) {
                        if (tracked == null || candidate.optLong("id") > tracked!!.optLong("id")) tracked = candidate
                    }
                }
            }
            val run = tracked
            if (cancelRequested) {
                val rId = run?.optLong("id") ?: 0L
                if (rId > 0L) try { request(token, "POST", "https://api.github.com/repos/$repo/actions/runs/$rId/cancel", JSONObject()) } catch (_: Exception) {}
                throw IOException("The build was cancelled.")
            }
            if (run != null) {
                cancelRunId = run.optLong("id")
                val status = run.optString("status")
                if (status == "completed") return run
                val elapsed = (System.currentTimeMillis() - buildStartMs) / 1000
                updateProgress("Build is running… ${elapsed}s\n${run.optString("display_title", "HS APK build")}")
            } else {
                val elapsed = (System.currentTimeMillis() - buildStartMs) / 1000
                updateProgress("Waiting for the GitHub runner to start… ${elapsed}s")
            }
            // Adaptive polling: fast at first, slower later
            Thread.sleep(if (attempt < 6) 6_000L else 12_000L)
        }
        val urlFinal = tracked?.optString("html_url").orEmpty()
        throw IOException("The GitHub Actions build did not complete in 20 minutes. Check: ${urlFinal.ifBlank { "https://github.com/$repo/actions" }}")
    }

    /** Reads the failed step and the key error lines from the GitHub job log; returns "" if anything is unavailable. */
    private fun fetchFailureSummary(repo: String, token: String, runId: Long): String {
        return try {
            val jobsResult = request(token, "GET", "https://api.github.com/repos/$repo/actions/runs/$runId/jobs?per_page=10", null)
            if (jobsResult.code != 200) return ""
            val jobs = jobsResult.json().optJSONArray("jobs") ?: return ""
            var jobId = 0L
            var stepName = ""
            for (i in 0 until jobs.length()) {
                val job = jobs.optJSONObject(i) ?: continue
                if (job.optString("conclusion") != "failure") continue
                jobId = job.optLong("id")
                val steps = job.optJSONArray("steps")
                if (steps != null) {
                    for (s in 0 until steps.length()) {
                        val step = steps.optJSONObject(s) ?: continue
                        if (step.optString("conclusion") == "failure") { stepName = step.optString("name"); break }
                    }
                }
                break
            }
            if (jobId <= 0L) return ""
            // The log can take a few seconds to become available right after the run completes.
            var logText = ""
            for (attempt in 0 until 4) {
                val logResult = request(token, "GET", "https://api.github.com/repos/$repo/actions/jobs/$jobId/logs", null)
                if (logResult.code == 200 && logResult.bytes.isNotEmpty()) { logText = logResult.text; break }
                Thread.sleep(2500)
            }
            val summary = BuildLogParser.summarize(logText, 1300)
            if (summary.isBlank()) "" else (if (stepName.isNotBlank()) "Failed step: $stepName\n\n" else "") + summary
        } catch (_: Exception) { "" }
    }

    private fun fetchArtifact(repo: String, token: String, runId: Long, buildId: String): ByteArray {
        repeat(5) { attempt ->
            val listResult = request(token, "GET", "https://api.github.com/repos/$repo/actions/runs/$runId/artifacts?per_page=100", null)
            requireCode(listResult, 200, "Could not access the APK artifact list")
            val artifacts = listResult.json().optJSONArray("artifacts")
            var selected: JSONObject? = null
            if (artifacts != null) {
                for (i in 0 until artifacts.length()) {
                    val item = artifacts.optJSONObject(i) ?: continue
                    if (item.optString("name") == "hs-apk-$buildId" && !item.optBoolean("expired", false)) { selected = item; break }
                }
            }
            if (selected != null) {
                val download = request(token, "GET", "https://api.github.com/repos/$repo/actions/artifacts/${selected!!.optLong("id")}/zip", null)
                requireCode(download, 200, "APK artifact download failed")
                return download.bytes
            }
            if (attempt < 4) Thread.sleep(2500)
        }
        throw IOException("The build was successful, but no matching APK artifact was found. Check the artifacts of the GitHub Actions run.")
    }

    private fun projectZip(project: File): ByteArray {
        val output = ByteArrayOutputStream()
        var filesAdded = 0
        ZipOutputStream(output).use { zip ->
            val base = project.canonicalFile
            val excludedDirs = setOf(".git", ".gradle", "node_modules", "build", "target", ".idea", ".kotlin")
            for (file in base.walkTopDown()) {
                if (file == base) continue
                val relative = file.relativeTo(base).path.replace(File.separatorChar, '/')
                if (relative.split('/').any { it in excludedDirs }) continue
                if (file.isDirectory) continue
                if (relative.isBlank() || relative.startsWith("../") || relative.startsWith("/")) continue
                val lower = relative.lowercase(Locale.ROOT)
                val baseName = file.name.lowercase(Locale.ROOT)
                if (relative == ".anjoo-meta.json" || baseName == ".env" || baseName.startsWith(".env.") ||
                    lower.endsWith(".keystore") || lower.endsWith(".jks") || baseName == "local.properties" ||
                    baseName == "keys.properties" || baseName.endsWith(".pem") || baseName.endsWith(".p12")) continue
                val entry = ZipEntry(relative)
                zip.putNextEntry(entry)
                file.inputStream().use { input ->
                    val buffer = ByteArray(16 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        zip.write(buffer, 0, count)
                        if (output.size() > MAX_UPLOAD_BYTES + 1024 * 1024) throw IOException("The project archive is larger than the ${MAX_UPLOAD_BYTES / 1024 / 1024} MB upload limit; remove build output/node_modules/large media files.")
                    }
                }
                zip.closeEntry()
                filesAdded++
            }
        }
        if (filesAdded == 0) return ByteArray(0)
        return output.toByteArray()
    }

    private fun unzipArtifact(bytes: ByteArray): Map<String, ByteArray> {
        if (bytes.isEmpty()) throw IOException("The GitHub artifact ZIP is empty.")
        val out = linkedMapOf<String, ByteArray>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                val name = entry.name.replace('\\', '/')
                if (entry.isDirectory || name.startsWith("/") || name.split('/').any { it == ".." }) { zip.closeEntry(); continue }
                val buffer = ByteArrayOutputStream()
                val chunk = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val n = zip.read(chunk)
                    if (n < 0) break
                    total += n
                    if (total > MAX_APK_BYTES) throw IOException("The APK/artifact file has an unexpected size.")
                    buffer.write(chunk, 0, n)
                }
                out[name] = buffer.toByteArray()
                zip.closeEntry()
            }
        }
        return out
    }

    private fun saveToDownloads(filename: String, bytes: ByteArray): Uri {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) throw IOException("Automatic saving to Downloads is supported on Android 10 or newer. Download the APK manually from the GitHub artifact.")
        if (bytes.isEmpty() || bytes.size < 1024) throw IOException("The APK file is empty or incomplete.")
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IOException("The file could not be created in the phone's Downloads folder.")
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                ?: throw IOException("The APK write stream could not be opened.")
            values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            return uri
        } catch (e: Exception) {
            try { contentResolver.delete(uri, null, null) } catch (_: Exception) {}
            throw e
        }
    }

    private fun installApk(uri: Uri) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "The APK is saved in the Downloads folder. Open the APK from the file manager. ${e.message.orEmpty()}", Toast.LENGTH_LONG).show()
        }
    }

    private fun deleteTemporaryRelease(token: String, repo: String, tag: String) {
        val encodedTag = Uri.encode(tag)
        val fetched = request(token, "GET", "https://api.github.com/repos/$repo/releases/tags/$encodedTag", null)
        if (fetched.code == 404) return
        requireCode(fetched, 200, "The temporary release could not be located")
        val release = fetched.json()
        val releaseId = release.optLong("id")
        val assets = release.optJSONArray("assets")
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val asset = assets.optJSONObject(i) ?: continue
                val assetId = asset.optLong("id")
                if (assetId <= 0L) continue
                val removeAsset = request(token, "DELETE", "https://api.github.com/repos/$repo/releases/assets/$assetId", null)
                if (removeAsset.code != 204 && removeAsset.code != 404) requireCode(removeAsset, 204, "The temporary source asset was not deleted")
            }
        }
        if (releaseId > 0L) {
            val removeRelease = request(token, "DELETE", "https://api.github.com/repos/$repo/releases/$releaseId", null)
            if (removeRelease.code != 204 && removeRelease.code != 404) requireCode(removeRelease, 204, "The temporary source release was not deleted")
        }
        val removeTag = request(token, "DELETE", "https://api.github.com/repos/$repo/git/refs/tags/$encodedTag", null)
        if (removeTag.code != 204 && removeTag.code != 404 && removeTag.code != 422) requireCode(removeTag, 204, "Temporary tag cleanup failed")
    }

    private fun putContents(token: String, repo: String, branch: String, path: String, bytes: ByteArray, message: String, sha: String?) {
        val body = JSONObject()
            .put("message", message)
            .put("content", Base64.encodeToString(bytes, Base64.NO_WRAP))
            .put("branch", branch)
        if (!sha.isNullOrBlank()) body.put("sha", sha)
        val result = request(token, "PUT", contentUrl(repo, path, null), body)
        if (result.code != 200 && result.code != 201) requireCode(result, 201, "The file was not uploaded to the GitHub repository")
    }

    private fun request(token: String, method: String, url: String, json: JSONObject?): ApiResult {
        val builder = Request.Builder().url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "AnjooAI-HS-APK-Builder")
        if (json == null) {
            if (method == "GET") builder.get() else if (method == "DELETE") builder.delete() else builder.method(method, null)
        } else {
            builder.method(method, json.toString().toRequestBody("application/vnd.github+json; charset=utf-8".toMediaType()))
        }
        return try {
            http.newCall(builder.build()).execute().use { response ->
                val body = response.body?.bytes() ?: ByteArray(0)
                if (body.size > MAX_DOWNLOAD_BYTES) throw IOException("The GitHub response is too large. Check the size of the build artifact.")
                ApiResult(response.code, body)
            }
        } catch (e: IOException) { throw e }
        catch (e: Exception) { throw IOException("GitHub request failed: ${e.message ?: e.javaClass.simpleName}") }
    }

    private fun requestBytes(token: String, method: String, url: String, bytes: ByteArray, mimeType: String): ApiResult {
        val request = Request.Builder().url(url)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "AnjooAI-HS-APK-Builder")
            .method(method, bytes.toRequestBody(mimeType.toMediaType()))
            .build()
        return try {
            uploadHttp.newCall(request).execute().use { response ->
                val body = response.body?.bytes() ?: ByteArray(0)
                if (body.size > MAX_DOWNLOAD_BYTES) throw IOException("The GitHub response is too large.")
                ApiResult(response.code, body)
            }
        } catch (e: IOException) { throw e }
        catch (e: Exception) { throw IOException("GitHub release upload failed: ${e.message ?: e.javaClass.simpleName}") }
    }

    private fun requireCode(result: ApiResult, expected: Int, prefix: String) {
        if (result.code == expected) return
        val data = result.json()
        val detail = data.optString("message").ifBlank { result.text.take(300).ifBlank { "No response body" } }
        val permissionsHint = when (result.code) {
            401 -> " The token is invalid or expired."
            403 -> " Check that the token permissions include Contents, Actions and Workflows Read/Write; GitHub Actions must be enabled."
            404 -> " The repository/path was not found or the token has no access."
            422 -> " GitHub rejected the request; check the workflow permissions/branch/input."
            else -> ""
        }
        throw IOException("$prefix (HTTP ${result.code}): $detail.$permissionsHint")
    }

    private fun repoUrl(repo: String) = "https://api.github.com/repos/$repo"
    private fun contentUrl(repo: String, path: String, branch: String?): String {
        val encoded = path.split('/').joinToString("/") { Uri.encode(it) }
        return "https://api.github.com/repos/$repo/contents/$encoded" + (branch?.let { "?ref=${Uri.encode(it)}" } ?: "")
    }
    private fun validRepo(repo: String) = Regex("^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$").matches(repo.trim())
    private fun safeFileName(input: String): String = input.replace(Regex("[^A-Za-z0-9._-]+"), "-").trim('-', '.', '_').take(50).ifBlank { "HS-App" }
    private fun readableError(e: Exception): String = (e.message ?: e.javaClass.simpleName).take(1800)

    private fun showProgress(initial: String) {
        buildStartMs = System.currentTimeMillis()
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(18), dp(20), dp(18)); background = rounded(surface, border, 15)
        }
        column.addView(text("HS — building the APK", 16f, ink, true))
        val bar = android.widget.ProgressBar(this).apply { isIndeterminate = true }
        column.addView(bar, LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(12); bottomMargin = dp(10) })
        progressLabel = text(initial, 13f, ink).apply { setLineSpacing(dp(2).toFloat(), 1.1f) }
        progressTimeLabel = text("0s", 11f, muted)
        column.addView(progressLabel)
        column.addView(progressTimeLabel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        // Elapsed timer tick
        val timerHandler = Handler(Looper.getMainLooper())
        val timerTick = object : Runnable {
            override fun run() {
                if (progressDialog?.isShowing == true) {
                    val s = (System.currentTimeMillis() - buildStartMs) / 1000
                    progressTimeLabel?.text = "Elapsed: ${s / 60}m ${s % 60}s  ·  Avg build ~4–8 min"
                    timerHandler.postDelayed(this, 1000)
                }
            }
        }
        timerHandler.postDelayed(timerTick, 1000)
        val cancelBtn = button("Cancel build") {
            cancelRequested = true
            progressLabel?.text = "Cancelling…"
        }
        column.addView(cancelBtn, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14); gravity = android.view.Gravity.END })
        progressDialog = AlertDialog.Builder(this).setView(column).setCancelable(false).create().also { it.show() }
    }

    private fun sendBuildNotification(projectName: String, success: Boolean) {
        try {
            val nm = getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            val channelId = "hs_apk_build"
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                val ch = android.app.NotificationChannel(channelId, "HS APK Build", android.app.NotificationManager.IMPORTANCE_HIGH)
                nm.createNotificationChannel(ch)
            }
            val intent = android.app.PendingIntent.getActivity(this, 0,
                Intent(this, HsApkBuilderActivity::class.java),
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE)
            val n = android.app.Notification.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(if (success) "✓ APK ready: $projectName" else "✕ Build fail: $projectName")
                .setContentText(if (success) "Saved in Downloads. Tap to install." else "Open to see the build log.")
                .setContentIntent(intent)
                .setAutoCancel(true)
                .build()
            nm.notify(("hs_apk_$projectName".hashCode()), n)
        } catch (_: Exception) {}
    }

    private fun updateProgress(message: String) {
        mainHandler.post { progressLabel?.text = message; statusText?.text = message }
    }
    private fun finishProgress() { progressDialog?.dismiss(); progressDialog = null; progressLabel = null }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    private fun showError(title: String, message: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK", null).show()
    }

    companion object {
        private const val DEFAULT_SUPABASE_URL = "https://vzlgekjtgqpezuvqcawb.supabase.co"
        private const val TOKEN_ONLY_REPO = "anjoo-personal/token-vault-only"
        private const val MAX_UPLOAD_BYTES = 25 * 1024 * 1024
        private const val MAX_PICK_ZIP_BYTES = 100L * 1024 * 1024
        private const val REQ_PICK_ZIP = 4711
        private const val MAX_APK_BYTES = 120 * 1024 * 1024
        private const val MAX_DOWNLOAD_BYTES = 160 * 1024 * 1024
    }
}
