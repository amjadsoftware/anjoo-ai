# Website Builder (Anjoo AI v99.2.16)

Module: `WebsiteBuilder.kt`. Tool: `website_builder` (actions: start, continue, status, change, audit, seo, deploy, verify, export).
It reuses Code Studio (`Coder.build/revise`), `Runner.check` (WebView preview diagnostics), checkpoints, ZIP export and the chat project card. Nothing existing was replaced.

## Workflow (state saved in files/website_state/<project>.json, so `continue` resumes at the first unfinished stage)
1. plan (AI JSON plan: pages, features, assumptions, needs_server, design, checklist)  2. build (Code Studio with the plan and design/quality rules as the brief)
3. run_check (preview in WebView; up to 2 fix rounds on real console errors / missing files)  4. audit (deterministic static checks, one AI fix round, re-audit)
5. seo (sitemap.xml, robots.txt)  6. deploy_docs (DEPLOY.md, README.md, _headers, netlify.toml, vercel.json)  7. verify (final check + checkpoint)
Existing files are never overwritten by the seo/deploy stages. `change` makes a checkpoint first.

## Audit checks (static, run on-device)
viewport/title/description/lang, h1 count, img alt, form labels, target=_blank rel, http:// scripts/mixed content, eval/new Function, document.write,
innerHTML from variables, sensitive localStorage, API-key/secret patterns, @media, focus styles, dark theme, reduced motion.

## Limits (reported honestly in every result)
Static HTML/CSS/vanilla JS only. No npm/React/Next builds, no database/auth/payment servers, no unit/e2e tests, no dependency CVE scan, no live deployment, no browser screenshots.
Server-only features are listed under "needs_server" and are not faked. Configuration variables: none new (uses the existing API key setting).
