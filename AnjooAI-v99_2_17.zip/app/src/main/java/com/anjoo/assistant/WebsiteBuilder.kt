package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Website Builder agent. It does NOT replace Code Studio: it orchestrates the pieces that already exist
 * (Coder.build / Coder.revise, Runner.check, checkpoints, ZIP export, the preview card) into one staged workflow
 * with saved progress, so an interrupted job resumes at the first unfinished stage instead of starting again.
 *
 * Honest scope on a phone: sites are static (HTML + CSS + vanilla JS) and run in the built-in WebView. There is no Node,
 * npm, database server or hosting account on the device, so server features are reported as "needs server setup",
 * never faked, and nothing is deployed from here. Every line of the final report comes from a check that really ran.
 *
 * Stages: plan -> build -> run_check -> audit -> seo -> deploy_docs -> verify
 */
object WebsiteBuilder {

    private val STAGES = listOf("plan", "build", "run_check", "audit", "seo", "deploy_docs", "verify")

    private val STAGE_LABEL = mapOf(
        "plan" to "Plan and checklist",
        "build" to "Design and build",
        "run_check" to "Run in preview",
        "audit" to "Security / accessibility / responsive audit",
        "seo" to "SEO files",
        "deploy_docs" to "Deployment files",
        "verify" to "Final verification"
    )

    // ------------------------------------------------------------------ saved state (outside the project, so it is never exported or overwritten)

    private fun stateFile(ctx: Context, key: String): File {
        val d = File(ctx.filesDir, "website_state").also { it.mkdirs() }
        return File(d, key.replace(Regex("[^A-Za-z0-9_.-]"), "_") + ".json")
    }

    private fun load(ctx: Context, key: String): JSONObject =
        try { JSONObject(stateFile(ctx, key).readText(Charsets.UTF_8)) } catch (e: Exception) { JSONObject() }

    private fun save(ctx: Context, key: String, st: JSONObject) {
        try { stateFile(ctx, key).writeText(st.toString(), Charsets.UTF_8) } catch (e: Exception) { }
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    private fun done(st: JSONObject, stage: String): Boolean = st.optJSONObject("done")?.optBoolean(stage, false) == true

    private fun mark(st: JSONObject, stage: String, ok: Boolean, note: String) {
        val d = st.optJSONObject("done") ?: JSONObject().also { st.put("done", it) }
        d.put(stage, ok)
        val n = st.optJSONObject("notes") ?: JSONObject().also { st.put("notes", it) }
        n.put(stage, note.take(1500))
    }

    private fun findDir(ctx: Context, a: JSONObject): File? {
        val hint = a.optString("project", "").trim().ifEmpty { prefs(ctx).getString("wbLast", "") ?: "" }
        val all = Coder.list(ctx)
        if (hint.isBlank()) return all.firstOrNull()
        return all.firstOrNull { it.name.equals(hint, true) }
            ?: all.firstOrNull { Coder.name(it).equals(hint, true) }
            ?: all.firstOrNull { Coder.name(it).contains(hint, true) }
    }

    // ------------------------------------------------------------------ entry point

    fun run(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val action = a.optString("action", "start").trim().lowercase().replace(' ', '_').replace('-', '_')
        return try {
            when (action) {
                "start", "new", "build" -> start(ctx, confirm, a)
                "continue", "resume" -> resume(ctx, confirm, a)
                "status", "progress", "plan" -> status(ctx, a)
                "change", "edit", "revise" -> change(ctx, confirm, a)
                "audit" -> single(ctx, confirm, a, "audit")
                "seo" -> single(ctx, confirm, a, "seo")
                "deploy", "deploy_docs", "deployment" -> single(ctx, confirm, a, "deploy_docs")
                "verify", "report" -> single(ctx, confirm, a, "verify")
                "export", "export_zip" -> {
                    val dir = findDir(ctx, a) ?: return "Koi website project nahi mila. Pehle action=start se banayen."
                    CodeTools.run(ctx, confirm, "project_studio", JSONObject().put("action", "export_zip").put("project", Coder.name(dir))) ?: "Export nahi ho saka."
                }
                else -> "website_builder actions: start, continue, status, change, audit, seo, deploy, verify, export."
            }
        } catch (e: Exception) {
            "Website Builder rukk gaya: " + (e.message ?: e.javaClass.simpleName) + ". 'continue' se wahin se dobara shuru hoga."
        }
    }

    // ------------------------------------------------------------------ start / resume

    private fun start(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val request = a.optString("message", a.optString("request", a.optString("task", ""))).trim()
        if (request.isBlank()) return "Kaisi website banani hai? message mein requirements likhein (kaam, pages, rang/style, zaban)."
        val log = StringBuilder()

        // 1) PLAN
        val plan = makePlan(ctx, request, a.optString("domain", ""))
        log.append("✔ Plan: ").append(plan.optString("summary", "tayyar")).append('\n')

        // 2) BUILD (Code Studio builder, with the plan + design rules as the brief)
        val (dir, notes) = Coder.build(ctx, brief(request, plan), "auto", true, Coder.deepDefault(ctx), {}, {})
        val key = dir.name
        prefs(ctx).edit().putString("wbLast", Coder.name(dir)).apply()
        val st = JSONObject().put("request", request).put("plan", plan).put("project", Coder.name(dir))
            .put("domain", a.optString("domain", "")).put("created", System.currentTimeMillis())
        mark(st, "plan", true, plan.optString("summary", ""))
        mark(st, "build", true, notes)
        save(ctx, key, st)
        log.append("✔ Build: ").append(Coder.readFiles(dir).size).append(" files\n")

        log.append(runStages(ctx, confirm, dir, st, key))
        return finish(dir, st, log.toString())
    }

    private fun resume(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val dir = findDir(ctx, a) ?: return "Koi website project nahi mila. Pehle action=start se banayen."
        val st = load(ctx, dir.name)
        if (st.length() == 0) return "Is project ka Website Builder record nahi hai ('" + Coder.name(dir) + "'). action=change se badlav karein ya action=audit chalayein."
        val left = STAGES.filter { !done(st, it) }
        if (left.isEmpty()) return finish(dir, st, "Sab stages pehle hi mukammal hain.\n")
        val log = StringBuilder("Resume: baqi stages: " + left.joinToString(", ") + "\n")
        log.append(runStages(ctx, confirm, dir, st, dir.name))
        return finish(dir, st, log.toString())
    }

    private fun single(ctx: Context, confirm: (String) -> Boolean, a: JSONObject, stage: String): String {
        val dir = findDir(ctx, a) ?: return "Koi website project nahi mila. Pehle action=start se banayen."
        val st = load(ctx, dir.name)
        val note = runStage(ctx, confirm, dir, st, stage)
        mark(st, stage, true, note)
        save(ctx, dir.name, st)
        return STAGE_LABEL[stage] + ":\n" + note + "\n\nPROJECT_EDITED: '" + Coder.name(dir) + "'"
    }

    /** A change request through normal chat: revise the real files, then re-run the checks that depend on them. */
    private fun change(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val dir = findDir(ctx, a) ?: return "Koi website project nahi mila."
        val msg = a.optString("message", a.optString("instruction", "")).trim()
        if (msg.isBlank()) return "Kya badalna hai, message mein likhein."
        // Safety checkpoint before editing, so the previous version can be restored.
        val cp = CodeTools.run(ctx, confirm, "project_studio", JSONObject().put("action", "checkpoint").put("project", Coder.name(dir)).put("message", "Before change: " + msg.take(60))) ?: ""
        val res = Coder.revise(ctx, dir, msg, Coder.deepDefault(ctx), {}, {})
        val st = load(ctx, dir.name)
        for (s in listOf("run_check", "audit", "seo", "verify")) (st.optJSONObject("done") ?: JSONObject().also { st.put("done", it) }).put(s, false)
        save(ctx, dir.name, st)
        val log = StringBuilder("✔ Change applied. ").append(cp).append('\n').append(res.take(600)).append('\n')
        log.append(runStages(ctx, confirm, dir, st, dir.name))
        return finish(dir, st, log.toString())
    }

    private fun status(ctx: Context, a: JSONObject): String {
        val dir = findDir(ctx, a) ?: return "Koi website project nahi mila."
        val st = load(ctx, dir.name)
        if (st.length() == 0) return "Project '" + Coder.name(dir) + "' Website Builder se nahi bana; record maujood nahi."
        val sb = StringBuilder("Project: ").append(Coder.name(dir)).append('\n')
        val plan = st.optJSONObject("plan")
        if (plan != null) {
            sb.append("Summary: ").append(plan.optString("summary")).append('\n')
            list(plan.optJSONArray("pages"))?.let { sb.append("Pages: ").append(it).append('\n') }
            list(plan.optJSONArray("features"))?.let { sb.append("Features: ").append(it).append('\n') }
            list(plan.optJSONArray("assumptions"))?.let { sb.append("Assumptions: ").append(it).append('\n') }
            list(plan.optJSONArray("needs_server"))?.let { sb.append("Needs server setup (not built here): ").append(it).append('\n') }
        }
        sb.append("\nStages:\n")
        for (s in STAGES) sb.append(if (done(st, s)) "  [x] " else "  [ ] ").append(STAGE_LABEL[s]).append('\n')
        return sb.toString() + "\nPROJECT_EDITED: '" + Coder.name(dir) + "'"
    }

    // ------------------------------------------------------------------ stage runner

    private fun runStages(ctx: Context, confirm: (String) -> Boolean, dir: File, st: JSONObject, key: String): String {
        val log = StringBuilder()
        for (s in STAGES) {
            if (s == "plan" || s == "build") continue
            if (done(st, s)) continue
            val note = try {
                runStage(ctx, confirm, dir, st, s)
            } catch (e: Exception) {
                save(ctx, key, st)
                log.append("✖ ").append(STAGE_LABEL[s]).append(" ruka: ").append(e.message ?: e.javaClass.simpleName)
                    .append(". 'continue' se yahin se dobara chalega.\n")
                return log.toString()
            }
            mark(st, s, true, note)
            save(ctx, key, st)
            log.append("✔ ").append(STAGE_LABEL[s]).append(": ").append(note.lineSequence().firstOrNull() ?: "").append('\n')
        }
        return log.toString()
    }

    private fun runStage(ctx: Context, confirm: (String) -> Boolean, dir: File, st: JSONObject, stage: String): String = when (stage) {
        "run_check" -> runCheck(ctx, dir)
        "audit" -> auditAndFix(ctx, dir)
        "seo" -> seo(dir, st)
        "deploy_docs" -> deployDocs(dir, st)
        "verify" -> verify(ctx, confirm, dir)
        else -> ""
    }

    // ------------------------------------------------------------------ plan

    private fun makePlan(ctx: Context, request: String, domain: String): JSONObject {
        val sys = "You are a principal web architect and UX lead. Output ONLY one JSON object, no markdown, with keys: " +
            "name (short), summary (one sentence), assumptions (array of strings: reasonable assumptions you made), " +
            "pages (array of page names), features (array of concrete working features), roles (array, user roles if any), " +
            "data (array: data the site stores/handles), integrations (array), " +
            "needs_server (array: features that REALLY need a server/database/auth/payment and cannot work in a static site), " +
            "design (object: style, palette as hex list, heading_font, body_font, theme), " +
            "milestones (array of strings), checklist (array of short acceptance checks). " +
            "The site will be built as a static multi-page website (HTML, CSS, vanilla JS) that runs in a WebView; client-side persistence only through localStorage/IndexedDB. " +
            "Do not pretend server features exist. Write in the language of the request for visible content ideas."
        val out = try { Artifacts.askPublic(ctx, sys, "Website request:\n$request" + (if (domain.isNotBlank()) "\nDomain: $domain" else "")) } catch (e: Exception) { "ERR:" + e.message }
        val parsed = try {
            val t = out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
        } catch (e: Exception) { null }
        if (parsed != null) return parsed
        return JSONObject().put("name", "website").put("summary", request.take(120))
            .put("assumptions", JSONArray().put("Plan AI se nahi ban saka, is liye seedhi request par build hua."))
            .put("pages", JSONArray().put("index")).put("features", JSONArray()).put("needs_server", JSONArray())
    }

    private fun brief(request: String, plan: JSONObject): String =
        "WEBSITE BUILDER BRIEF\n\nUser request:\n" + request + "\n\nApproved plan (follow it):\n" + plan.toString(2) + "\n\n" +
        "Technical rules: a static website made of HTML, CSS and vanilla JavaScript that works offline inside an Android WebView. " +
        "No npm, no build step, no CDN-only dependencies. Multi-page if the plan lists several pages, with working navigation between them. " +
        "Persist user data only with localStorage/IndexedDB and make that really work. Do NOT fake server features (login against a fake user list, fake payments, fake API data shown as real): " +
        "implement the client-side part honestly and leave server-only items out of the UI. Never put API keys, tokens or passwords in the code.\n\n" +
        "Design rules: modern, premium and professional. CSS variables for colour, spacing (8px scale), radius, shadow and type scale; light AND dark theme (prefers-color-scheme plus a visible toggle); " +
        "mobile-first and fully responsive for phone, tablet, desktop and large screens (fluid type, CSS grid/flex, no horizontal scroll); real components (header with working menu, hero, cards, forms with validation, dialogs, footer), " +
        "subtle animations that respect prefers-reduced-motion; loading, empty, success and error states; real written content, no lorem ipsum.\n\n" +
        "Quality rules: semantic landmarks (header, nav, main, footer), one h1 per page, labels for every input, alt text for every image, visible :focus-visible, skip link, good contrast, keyboard operable controls, " +
        "<html lang>, viewport meta, title, meta description and Open Graph tags on every page, rel=\"noopener\" on target=_blank links, no inline eval, no innerHTML with user data. " +
        "Every button and link must do something real."

    // ------------------------------------------------------------------ run in preview

    private fun runCheck(ctx: Context, dir: File): String {
        var report = Runner.check(ctx, dir).trim()
        var rounds = 0
        while (report.isNotEmpty() && rounds < 2) {
            rounds++
            Coder.revise(ctx, dir, "Fix these verified preview/runtime problems in the actual files, change nothing else:\n$report", Coder.deepDefault(ctx), {}, {})
            report = Runner.check(ctx, dir).trim()
        }
        return if (report.isEmpty()) "Preview chali: koi console error ya missing file nahi mili" + (if (rounds > 0) " ($rounds fix round ke baad)." else ".")
        else "Fix ke baad bhi ye masail baqi hain:\n$report"
    }

    // ------------------------------------------------------------------ audit (deterministic static checks, then one AI fix round)

    data class Finding(val sev: String, val file: String, val msg: String)

    private val SECRET = listOf(
        Regex("AIza[0-9A-Za-z_\\-]{35}"),
        Regex("sk-[A-Za-z0-9]{20,}"),
        Regex("(?i)(api[_-]?key|secret|token|passw(or)?d)\\s*[:=]\\s*['\"][^'\"\\s]{8,}['\"]")
    )

    fun audit(dir: File): List<Finding> {
        val out = ArrayList<Finding>()
        val files = Coder.readFiles(dir)
        var anyMedia = false
        var anyFocus = false
        var anyDark = false
        var anyAnim = false
        var anyReduced = false
        for ((path, text) in files) {
            val ext = path.substringAfterLast('.', "").lowercase()
            val isHtml = ext == "html" || ext == "htm"
            if (ext == "css" || isHtml) {
                if (text.contains("@media")) anyMedia = true
                if (text.contains("focus-visible") || text.contains(":focus")) anyFocus = true
                if (text.contains("prefers-color-scheme")) anyDark = true
                if (text.contains("@keyframes") || text.contains("transition")) anyAnim = true
                if (text.contains("prefers-reduced-motion")) anyReduced = true
            }
            if (isHtml) {
                if (!Regex("(?i)<meta[^>]+name=[\"']viewport").containsMatchIn(text)) out.add(Finding("medium", path, "viewport meta missing (not mobile friendly)"))
                if (!Regex("(?i)<title>[^<]+</title>").containsMatchIn(text)) out.add(Finding("medium", path, "<title> missing"))
                if (!Regex("(?i)<meta[^>]+name=[\"']description").containsMatchIn(text)) out.add(Finding("low", path, "meta description missing"))
                if (!Regex("(?i)<html[^>]+lang=").containsMatchIn(text)) out.add(Finding("low", path, "<html lang> missing"))
                val h1 = Regex("(?i)<h1[\\s>]").findAll(text).count()
                if (h1 == 0) out.add(Finding("low", path, "no <h1>")) else if (h1 > 1) out.add(Finding("low", path, "more than one <h1>"))
                val noAlt = Regex("(?i)<img\\b(?![^>]*\\balt=)[^>]*>").findAll(text).count()
                if (noAlt > 0) out.add(Finding("medium", path, "$noAlt <img> without alt text"))
                val inputs = Regex("(?i)<(input|select|textarea)\\b(?![^>]*type=[\"'](hidden|submit|button|reset|image)[\"'])[^>]*>").findAll(text).count()
                val labelled = Regex("(?i)<label\\b|aria-label=|aria-labelledby=").findAll(text).count()
                if (inputs > labelled) out.add(Finding("medium", path, "some form fields have no label/aria-label"))
                if (Regex("(?i)<a\\b[^>]*target=[\"']_blank[\"'](?![^>]*rel=[\"'][^\"']*noopener)[^>]*>").containsMatchIn(text))
                    out.add(Finding("low", path, "target=_blank link without rel=noopener"))
                if (Regex("(?i)<script[^>]+src=[\"']http://").containsMatchIn(text)) out.add(Finding("high", path, "script loaded over insecure http://"))
                if (Regex("(?i)(src|href)=[\"']http://[^\"']+\\.(css|js|png|jpe?g|webp|svg)").containsMatchIn(text)) out.add(Finding("medium", path, "insecure http:// resource (mixed content)"))
            }
            if (isHtml || ext == "js" || ext == "mjs" || ext == "ts" || ext == "jsx" || ext == "tsx") {
                if (Regex("\\beval\\s*\\(|new\\s+Function\\s*\\(").containsMatchIn(text)) out.add(Finding("high", path, "eval()/new Function() used"))
                if (Regex("document\\.write\\s*\\(").containsMatchIn(text)) out.add(Finding("medium", path, "document.write() used"))
                if (Regex("innerHTML\\s*(\\+?=)\\s*[^'\"`;\\s]").containsMatchIn(text)) out.add(Finding("medium", path, "innerHTML assigned from a variable (XSS risk): use textContent or sanitise"))
                if (Regex("(?i)localStorage\\.setItem\\([^)]*(passw|token|secret)").containsMatchIn(text)) out.add(Finding("medium", path, "sensitive value stored in localStorage"))
            }
            if (ext in setOf("html", "htm", "js", "mjs", "ts", "jsx", "tsx", "json", "env", "css")) {
                for (r in SECRET) if (r.containsMatchIn(text)) { out.add(Finding("high", path, "possible secret/API key in source")); break }
            }
        }
        if (files.keys.any { it.endsWith(".html", true) || it.endsWith(".htm", true) }) {
            if (!anyMedia) out.add(Finding("medium", "(css)", "no @media queries: layout is probably not responsive"))
            if (!anyFocus) out.add(Finding("low", "(css)", "no visible focus style (keyboard navigation)"))
            if (!anyDark) out.add(Finding("low", "(css)", "no dark theme (prefers-color-scheme)"))
            if (anyAnim && !anyReduced) out.add(Finding("low", "(css)", "animations without prefers-reduced-motion"))
        }
        return out
    }

    private fun fmt(f: List<Finding>): String = f.joinToString("\n") { "- [" + it.sev + "] " + it.file + ": " + it.msg }

    private fun auditAndFix(ctx: Context, dir: File): String {
        var found = audit(dir)
        val serious = found.filter { it.sev == "high" || it.sev == "medium" }
        if (serious.isNotEmpty()) {
            Coder.revise(ctx, dir, "Fix these verified audit findings in the actual files (keep the design and features unchanged):\n" + fmt(found), Coder.deepDefault(ctx), {}, {})
            found = audit(dir)
        }
        val high = found.count { it.sev == "high" }
        val med = found.count { it.sev == "medium" }
        val low = found.count { it.sev == "low" }
        val head = if (found.isEmpty()) "Audit saaf: koi finding nahi (static checks)." else "Audit baad: $high high, $med medium, $low low."
        return head + (if (found.isNotEmpty()) "\n" + fmt(found) else "") +
            "\n(Ye static code checks hain: injection/XSS patterns, secrets, labels, alt, responsive, focus. Dependency scan, CSRF/auth aur real penetration test is device par nahi hota.)"
    }

    // ------------------------------------------------------------------ SEO + deployment files (never overwrite existing user files)

    private fun writeIfAbsent(dir: File, rel: String, content: String): Boolean =
        if (File(dir, rel).exists()) false else Coder.writeFile(dir, rel, content)

    private fun seo(dir: File, st: JSONObject): String {
        val domain = (st.optString("domain", "").ifBlank { "https://example.com" }).trimEnd('/')
        val pages = PreviewServer.pages(dir).filter { !it.startsWith("docs/") }
        val urls = pages.joinToString("\n") { p ->
            val loc = if (p == "index.html") "$domain/" else "$domain/$p"
            "  <url><loc>$loc</loc></url>"
        }
        val made = ArrayList<String>()
        if (writeIfAbsent(dir, "sitemap.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n$urls\n</urlset>\n")) made.add("sitemap.xml")
        if (writeIfAbsent(dir, "robots.txt", "User-agent: *\nAllow: /\n\nSitemap: $domain/sitemap.xml\n")) made.add("robots.txt")
        val placeholder = if (st.optString("domain", "").isBlank()) " Domain abhi example.com hai: asli domain milne par sitemap.xml aur robots.txt mein badal dein." else ""
        return (if (made.isEmpty()) "SEO files pehle se maujood." else "Banayi: " + made.joinToString(", ") + ".") + placeholder
    }

    private fun deployDocs(dir: File, st: JSONObject): String {
        val name = Coder.name(dir)
        val made = ArrayList<String>()
        if (writeIfAbsent(dir, "_headers", "/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n  X-Frame-Options: SAMEORIGIN\n  Permissions-Policy: camera=(), microphone=(), geolocation=()\n")) made.add("_headers")
        if (writeIfAbsent(dir, "netlify.toml", "[build]\n  publish = \".\"\n\n[[headers]]\n  for = \"/*\"\n  [headers.values]\n    X-Content-Type-Options = \"nosniff\"\n    Referrer-Policy = \"strict-origin-when-cross-origin\"\n    X-Frame-Options = \"SAMEORIGIN\"\n")) made.add("netlify.toml")
        if (writeIfAbsent(dir, "vercel.json", "{\n  \"cleanUrls\": true,\n  \"headers\": [\n    { \"source\": \"/(.*)\", \"headers\": [\n      { \"key\": \"X-Content-Type-Options\", \"value\": \"nosniff\" },\n      { \"key\": \"Referrer-Policy\", \"value\": \"strict-origin-when-cross-origin\" },\n      { \"key\": \"X-Frame-Options\", \"value\": \"SAMEORIGIN\" }\n    ] }\n  ]\n}\n")) made.add("vercel.json")
        val server = list(st.optJSONObject("plan")?.optJSONArray("needs_server"))
        val doc = "# $name: deployment\n\nThis is a static website (HTML, CSS, JavaScript). No build step is needed.\n\n" +
            "## Host it\n- **Netlify**: drag the project folder (or ZIP) onto app.netlify.com/drop, or connect a Git repository. `netlify.toml` and `_headers` add security headers.\n" +
            "- **Vercel**: import the folder/repository; `vercel.json` is included.\n- **GitHub Pages**: push the files, then Settings > Pages > deploy from branch.\n- **Any web server**: upload all files to the web root.\n\n" +
            "## Before going live\n- Replace `https://example.com` in `sitemap.xml` and `robots.txt` with your real domain.\n- Re-test every form and link on the live URL.\n- Add a privacy notice if you collect personal data.\n\n" +
            "## Not included (needs a server)\n" + (if (server != null) "- " + server.replace(", ", "\n- ") else "- Nothing was flagged in the plan.") +
            "\n\nAnjoo AI does not deploy sites by itself and has not deployed this one.\n"
        if (writeIfAbsent(dir, "DEPLOY.md", doc)) made.add("DEPLOY.md")
        if (writeIfAbsent(dir, "README.md", "# $name\n\nStatic website generated with Anjoo AI Website Builder.\n\nOpen `index.html` in a browser, or see `DEPLOY.md` to publish it.\n")) made.add("README.md")
        return if (made.isEmpty()) "Deployment files pehle se maujood." else "Banayi: " + made.joinToString(", ") + ". (Deploy nahi kiya gaya: DEPLOY.md mein steps hain.)"
    }

    // ------------------------------------------------------------------ verify + report

    private fun verify(ctx: Context, confirm: (String) -> Boolean, dir: File): String {
        val files = Coder.readFiles(dir)
        val entry = PreviewServer.entry(dir)
        val report = Runner.check(ctx, dir).trim()
        val cp = CodeTools.run(ctx, confirm, "project_studio", JSONObject().put("action", "checkpoint").put("project", Coder.name(dir)).put("message", "Website Builder: verified build")) ?: ""
        return (if (entry == null) "Koi HTML entry page nahi mili." else "Entry page: $entry, ${files.size} files.") + "\n" +
            (if (report.isEmpty()) "Final preview check saaf." else "Final preview check mein masail:\n$report") + "\n" + cp
    }

    private fun finish(dir: File, st: JSONObject, log: String): String {
        val sb = StringBuilder()
        sb.append("PROJECT_BUILT: '").append(Coder.name(dir)).append("' website tayyar hai. Chat mein project card, preview aur ZIP download dikhaya jayega.\n\n")
        sb.append("Workflow log:\n").append(log).append('\n')
        val notes = st.optJSONObject("notes")
        notes?.optString("audit", "")?.takeIf { it.isNotBlank() }?.let { sb.append("\n").append(it).append('\n') }
        val plan = st.optJSONObject("plan")
        list(plan?.optJSONArray("assumptions"))?.let { sb.append("\nAssumptions: ").append(it).append('\n') }
        list(plan?.optJSONArray("needs_server"))?.let { sb.append("\nSERVER SETUP CHAHIYE (yahan nahi bana, jhoota nahi dikhaya): ").append(it).append('\n') }
        sb.append("\nNOT VERIFIED on device: npm/React/Next builds, database, real auth, unit/e2e tests, dependency CVE scan, live deployment.\n")
        sb.append("\nINSTRUCTION FOR REPLY: user ko chhote jumlon mein sirf yehi verified baatein batao (kya bana, preview result, audit result, kya baqi hai) aur poochho kya badalna hai. Jo is log mein nahi hai woh mat kaho.")
        return sb.toString()
    }

    private fun list(a: JSONArray?): String? {
        if (a == null || a.length() == 0) return null
        val parts = ArrayList<String>()
        for (i in 0 until a.length()) {
            val v = a.opt(i)
            parts.add(if (v is JSONObject) v.optString("name", v.toString()) else v.toString())
        }
        return parts.joinToString(", ").takeIf { it.isNotBlank() }
    }
}
