package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** A WebView that serves a project's files from https://app.local/, so pages, css, scripts and images link up. */
object ProjectWeb {

    fun create(ctx: Context, base: File): WebView {
        val wv = WebView(ctx)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true      // localStorage + IndexedDB, kept on the phone between launches
        @Suppress("DEPRECATION") run { wv.settings.databaseEnabled = true }
        wv.tag = base
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        wv.setBackgroundColor(Color.WHITE)
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                return PreviewServer.serve(base, u)
            }
        }
        return wv
    }

    /** Opens the main page, or [page] (a path inside the project). */
    fun load(wv: WebView, page: String? = null) {
        val base = wv.tag as? File
        val origin = if (base != null) PreviewServer.origin(base) else "https://app.local/"
        wv.loadUrl(origin + if (page == null) "" else Uri.encode(page, "/"))
    }
}

/**
 * Full-screen preview of a whole project (all its pages, styles and scripts) with the chat-style actions:
 * reload, pages, download as zip, and open in Code Studio. Opened from the project card in the chat.
 */
class ProjectPreviewActivity : Activity() {
    private lateinit var dir: File
    private var wv: WebView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        dir = File(intent.getStringExtra("project") ?: "")
        if (!dir.isDirectory || PreviewServer.entry(dir) == null) {
            Toast.makeText(this, "Is project ka preview nahi ban sakta.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#1B1B1F"))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        fun btn(label: String, a: () -> Unit) = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(Color.WHITE)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { a() }
        }
        bar.addView(btn("✕") { finish() })
        bar.addView(TextView(this).apply {
            text = Coder.name(dir); textSize = 14f; setTextColor(Color.WHITE)
            maxLines = 1; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(btn("⟳") { wv?.reload() })
        if (PreviewServer.pages(dir).size > 1) bar.addView(btn("📄") { pickPage() })
        bar.addView(btn("⬇") { download() })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        val w = ProjectWeb.create(this, dir)
        wv = w
        // Device switcher: Phone (real size), Mobile, Tablet, MacBook, PC. The page is laid out at that device's CSS width
        // (so its @media queries really switch layout) and scaled to fit the screen; zoom and rotate are available.
        val chips = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(4), dp(6), dp(4)) }
        chipsRow = chips
        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.parseColor("#26262B"))
            addView(chips)
        }
        root.addView(chipScroll, LinearLayout.LayoutParams(-1, -2))
        val hs = HorizontalScrollView(this).apply {
            isFillViewport = true; isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.parseColor("#3A3A40"))
        }
        val outer = FrameLayout(this)
        val wrap = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        wrap.addView(w, FrameLayout.LayoutParams(-1, -1))
        outer.addView(wrap, FrameLayout.LayoutParams(-1, -1))
        hs.addView(outer, FrameLayout.LayoutParams(-1, -1))
        hScroll = hs; outerBox = outer; wrapBox = wrap
        root.addView(hs, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        device = getSharedPreferences("anjoo", Context.MODE_PRIVATE).getString("previewDevice", "Phone") ?: "Phone"
        buildChips()
        hs.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) hs.post { applyDevice() }
        }
        applyDevice()
        ProjectWeb.load(w)
    }

    private class Dev(val name: String, val label: String, val w: Int, val h: Int, val turns: Boolean)
    private val devs = listOf(
        Dev("Phone", "📲 Phone", 0, 0, false),
        Dev("Mobile", "📱 Mobile", 390, 844, true),
        Dev("Tablet", "📋 Tablet", 820, 1180, true),
        Dev("MacBook", "💻 MacBook", 1440, 900, false),
        Dev("PC", "🖥 PC", 1920, 1080, false)
    )
    private var device = "Phone"
    private var landscape = false
    private var zoom = 1f
    private var chipsRow: LinearLayout? = null
    private var hScroll: HorizontalScrollView? = null
    private var outerBox: FrameLayout? = null
    private var wrapBox: FrameLayout? = null
    private var infoView: TextView? = null

    private fun buildChips() {
        val row = chipsRow ?: return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        row.removeAllViews()
        fun chip(label: String, on: Boolean, a: () -> Unit) = TextView(this).apply {
            text = label; textSize = 13f
            setTextColor(if (on) Color.parseColor("#1B1B1F") else Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(if (on) Color.WHITE else Color.parseColor("#3A3A40"))
            }
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { a() }
        }
        val lp = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) } }
        for (dv in devs) row.addView(chip(dv.label, dv.name == device) {
            device = dv.name; landscape = false; zoom = 1f
            getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit().putString("previewDevice", device).apply()
            buildChips(); applyDevice()
        }, lp())
        val cur = devs.firstOrNull { it.name == device }
        if (cur != null && cur.turns) row.addView(chip(if (landscape) "↻ Landscape" else "↻ Portrait", false) { landscape = !landscape; buildChips(); applyDevice() }, lp())
        if (cur != null && cur.w > 0) {
            row.addView(chip("－", false) { zoom = (zoom / 1.25f).coerceAtLeast(1f); applyDevice() }, lp())
            row.addView(chip("＋", false) { zoom = (zoom * 1.25f).coerceAtMost(4f); applyDevice() }, lp())
        }
        val info = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#B8B8C0")); setPadding(dp(6), 0, dp(10), 0) }
        infoView = info
        row.addView(info)
    }

    /** Lays the website out at the chosen device's width and scales it to fit (touch, scrolling and media queries all work). */
    private fun applyDevice() {
        val hs = hScroll ?: return
        val outer = outerBox ?: return
        val wrap = wrapBox ?: return
        val w = wv ?: return
        val availW = hs.width
        val availH = hs.height
        if (availW <= 0 || availH <= 0) { hs.post { applyDevice() }; return }
        val dv = devs.firstOrNull { it.name == device }
        val density = resources.displayMetrics.density
        if (dv == null || dv.w == 0) {
            // Phone: the page at this phone's own size.
            wrap.layoutParams = FrameLayout.LayoutParams(-1, -1)
            w.layoutParams = FrameLayout.LayoutParams(-1, -1)
            w.scaleX = 1f; w.scaleY = 1f
            infoView?.text = "Is phone ka asli size"
            return
        }
        val cssW = if (landscape && dv.turns) dv.h else dv.w
        val cssH = if (landscape && dv.turns) dv.w else dv.h
        val fit = Math.min(1f, availW / (cssW * density))   // never enlarge beyond real size
        val s = fit * zoom
        val wpx = (cssW * density).toInt()
        val hpx = Math.max((availH / s).toInt(), (200 * density).toInt())
        val boxW = Math.max((wpx * s).toInt(), if (zoom == 1f) 0 else availW)
        outer.layoutParams = FrameLayout.LayoutParams(Math.max(boxW, availW), -1)
        wrap.layoutParams = FrameLayout.LayoutParams((wpx * s).toInt(), availH, Gravity.CENTER_HORIZONTAL)
        w.layoutParams = FrameLayout.LayoutParams(wpx, hpx)
        w.pivotX = 0f; w.pivotY = 0f
        w.scaleX = s; w.scaleY = s
        outer.requestLayout()
        infoView?.text = dv.name + " " + cssW + "×" + cssH + " px  ·  " + Math.round(s * 100) + "%"
    }

    private fun pickPage() {
        val pages = PreviewServer.pages(dir)
        AlertDialog.Builder(this)
            .setTitle("Pages")
            .setItems(pages.toTypedArray()) { _, i -> wv?.let { ProjectWeb.load(it, pages[i]) } }
            .show()
    }

    private fun download() {
        val slug = Coder.name(dir).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "project" }
        Thread {
            val bytes = try { Coder.zip(dir) } catch (e: Exception) { null }
            runOnUiThread {
                if (bytes == null) Toast.makeText(this, "Zip nahi ban saki.", Toast.LENGTH_SHORT).show()
                else Dl.save(this, "$slug.zip", bytes)
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != 77 || resultCode != RESULT_OK || uri == null) return
        Thread {
            val ok = try {
                contentResolver.openOutputStream(uri)?.use { it.write(Coder.zip(dir)) }
                true
            } catch (e: Exception) { false }
            runOnUiThread { Toast.makeText(this, if (ok) "Zip save ho gayi." else "Zip save nahi ho saki.", Toast.LENGTH_SHORT).show() }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val w = wv
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        try { wv?.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }
}
