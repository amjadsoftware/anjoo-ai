package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream

/**
 * Code Studio: build a multi-file project from an idea, edit it by asking, ask questions about it,
 * read and copy every file, preview web projects, and export everything as a zip.
 */
class CodeActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var th: CyberTheme
    private var dir: File? = null
    private var cur: String? = null
    private var busy = false
    private var web: WebView? = null

    private lateinit var titleTv: TextView
    private lateinit var status: TextView
    private lateinit var tabs: LinearLayout
    private lateinit var area: FrameLayout
    private lateinit var logBox: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var codeWrap: LinearLayout
    private lateinit var codeText: TextView
    private lateinit var codeName: TextView
    private lateinit var input: EditText
    private lateinit var goBtn: TextView
    private lateinit var host: FrameLayout
    private lateinit var chipRow: LinearLayout
    private var side: SideMenu? = null
    private lateinit var quickRow: HorizontalScrollView
    private val jsErrors = StringBuilder()
    private var mode = 2 // 0 ask, 1 edit, 2 build new

    private fun toggleThink() {
        val p = getSharedPreferences("anjoo", MODE_PRIVATE)
        p.edit().putBoolean("codeThink", !p.getBoolean("codeThink", true)).apply()
        val on = p.getBoolean("codeThink", true)
        Toast.makeText(this, if (on) "Deep think ON" else "Deep think OFF", Toast.LENGTH_SHORT).show()
    }

    private fun setMode(m: Int) {
        mode = m
        input.hint = when (m) {
            0 -> "Code ke bare mein poochein..."
            1 -> "Kya badalna hai?"
            else -> "Kya banana hai? (naya project)"
        }
        chipRow.removeAllViews()
        val names = listOf("💬 Ask", "✏️ Edit", "⚡ Build")
        for (i in listOf(2, 1, 0)) {
            val sel = i == m
            chipRow.addView(TextView(this).apply {
                text = names[i]; textSize = 12.5f; gravity = Gravity.CENTER
                setTextColor(if (sel) th.bg else th.muted)
                background = box(if (sel) th.accent else Color.TRANSPARENT, if (sel) th.accent else faint(), dp(16))
                setPadding(dp(14), dp(5), dp(14), dp(5))
                setOnClickListener { setMode(i) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
    }

    private fun openSide() {
        val sm = side ?: SideMenu(this, host, th.bg, th.surface, th.ink, th.muted, th.accent).also { side = it }
        sm.open("Code Studio", "New project", { if (!busy) newProject() },
            {
                Coder.list(this).map { d ->
                    SideMenu.Item(Coder.name(d), d == dir,
                        { if (!busy) openProject(d) },
                        { copy(transcript(d)) },
                        { share(transcript(d)) },
                        { Coder.delete(d); if (dir == d) newProject() },
                        false,
                        { nt -> Coder.rename(d, nt); if (dir == d) titleTv.text = Coder.name(d) },
                        null)
                }
            },
            listOf(mi("💬  Back to Anjoo chat") { finish() }),
            "Abhi koi project nahi. Kuch banane ko bolein.", "Your projects", "📁")
    }

    private fun mi(l: String, f: () -> Unit) = Pair(l, f)

    private fun fixErrors() {
        if (busy) return
        if (dir == null) { Toast.makeText(this, "Pehle project banayein.", Toast.LENGTH_SHORT).show(); return }
        val e = jsErrors.toString().trim()
        if (e.isEmpty()) { Toast.makeText(this, "Preview chalayein; abhi koi error nahi mila.", Toast.LENGTH_SHORT).show(); return }
        jsErrors.setLength(0)
        input.setText("Preview mein ye errors aa rahe hain, inko theek karo:\n" + e.take(1500))
        go(1)
    }

    private fun undoEdit() {
        val d = dir ?: return
        if (busy) return
        if (!Coder.canUndo(this, d)) { Toast.makeText(this, "Undo ke liye kuch nahi.", Toast.LENGTH_SHORT).show(); return }
        if (Coder.undo(this, d)) { openProject(d); Toast.makeText(this, "Pichla badlav wapas ho gaya.", Toast.LENGTH_SHORT).show() }
    }

    private fun transcript(d: File): String {
        val sb = StringBuilder(Coder.name(d)).append("\n\n")
        for ((r, t) in Coder.history(d)) sb.append(if (r == "u") "You: " else "Anjoo: ").append(t).append("\n\n")
        return sb.toString().trim()
    }

    private fun moreMenu(v: View) {
        val pm = android.widget.PopupMenu(this, v)
        pm.menu.add("▶️  Run preview"); pm.menu.add("🛠  Fix preview errors"); pm.menu.add("↩️  Undo last edit"); pm.menu.add("📦  Download zip")
        pm.menu.add(if (getSharedPreferences("anjoo", MODE_PRIVATE).getBoolean("codeThink", true)) "🧠  Deep think: ON" else "🧠  Deep think: OFF")
        pm.menu.add("🗑  Delete project")
        pm.setOnMenuItemClickListener { m ->
            val tt = m.title?.toString() ?: ""
            when {
                tt.endsWith("Run preview") -> preview()
                tt.endsWith("Download zip") -> exportZip()
                tt.endsWith("Fix preview errors") -> fixErrors()
                tt.endsWith("Undo last edit") -> undoEdit()
                tt.contains("Deep think") -> toggleThink()
                else -> deleteProject()
            }
            true
        }
        pm.show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int, r: Int) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = r.toFloat()
    }

    private fun btn(t: String, a: () -> Unit): Button = Button(this).apply {
        text = t; isAllCaps = false; textSize = 11f; setTextColor(th.accent)
        background = box(th.surface, th.accent, dp(8))
        minWidth = 0; minimumWidth = 0; setPadding(dp(10), 0, dp(10), 0)
        layoutParams = LinearLayout.LayoutParams(-2, dp(36)).apply { leftMargin = dp(5) }
        setOnClickListener { a() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        th = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        Style.bars(window, th)

        host = FrameLayout(this).apply { setBackgroundColor(th.bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        host.addView(root, FrameLayout.LayoutParams(-1, -1))

        fun icon(t: String, a: (View) -> Unit) = TextView(this).apply {
            text = t; textSize = 22f; setTextColor(th.ink); gravity = Gravity.CENTER
            setOnClickListener { a(this) }
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(icon("≡") { openSide() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        titleTv = TextView(this).apply {
            text = "Code Studio"; setTextColor(th.ink); textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        bar.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
        bar.addView(icon("+") { if (!busy) newProject() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        bar.addView(icon("⋮") { moreMenu(it) }, LinearLayout.LayoutParams(dp(42), dp(42)))
        root.addView(bar)
        root.addView(View(this).apply { setBackgroundColor(faint()) }, LinearLayout.LayoutParams(-1, dp(1)))

        status = TextView(this).apply { setTextColor(th.muted); textSize = 11f; typeface = Typeface.MONOSPACE; setPadding(0, dp(4), 0, dp(4)) }
        root.addView(status)

        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabScroll.addView(tabs)
        root.addView(tabScroll, LinearLayout.LayoutParams(-1, dp(44)))

        area = FrameLayout(this)
        logBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(2)) }
        logScroll = ScrollView(this).apply { addView(logBox) }

        codeName = TextView(this).apply { setTextColor(th.accent); typeface = Typeface.MONOSPACE; textSize = 12f }
        val crow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(2), 0, dp(4)) }
        crow.addView(codeName, LinearLayout.LayoutParams(0, -2, 1f))
        crow.addView(btn("Edit") { editFile() })
        crow.addView(btn("Copy") { copy(codeText.text.toString()) })
        crow.addView(btn("Share") { share(codeText.text.toString()) })
        codeText = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(th.ink); setTextIsSelectable(true)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val hs = HorizontalScrollView(this).apply { addView(codeText) }
        val vs = ScrollView(this).apply { addView(hs); setBackgroundColor(Color.argb(120, 0, 0, 0)) }
        codeWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        codeWrap.addView(crow)
        codeWrap.addView(vs, LinearLayout.LayoutParams(-1, 0, 1f))

        area.addView(logScroll, FrameLayout.LayoutParams(-1, -1))
        area.addView(codeWrap, FrameLayout.LayoutParams(-1, -1))
        root.addView(area, LinearLayout.LayoutParams(-1, 0, 1f))

        quickRow = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; visibility = View.GONE }
        val qBox = LinearLayout(this).apply { setPadding(dp(2), dp(6), dp(2), 0) }
        val quicks = listOf(
            Triple("🐞 Find bugs", "Review the whole project for bugs, edge cases and crashes. Fix every real problem you find and list what you fixed.", 1),
            Triple("⚡ Optimize", "Optimize performance and clean the code without changing behaviour. Explain what improved.", 1),
            Triple("🧪 Add tests", "Add automated tests (or a test page / test script for web projects) covering the main features and edge cases.", 1),
            Triple("📝 Explain", "Explain how this project works file by file in simple words.", 0),
            Triple("🎨 Better UI", "Make the interface look more polished and professional: spacing, typography, colors, animations and mobile friendliness. Keep all features.", 1),
            Triple("🔒 Security", "Do a security review (input validation, XSS, secrets, unsafe storage) and fix the issues you find.", 1),
            Triple("🧹 Clean up", "Refactor for readability: clear names, small functions, helpful comments. Keep behaviour identical.", 1),
            Triple("📱 Responsive", "Make it fully responsive and touch friendly for phones, tablets and desktop.", 1)
        )
        for ((label, ins, k) in quicks) {
            qBox.addView(TextView(this).apply {
                text = label; textSize = 12f; setTextColor(th.accent); gravity = Gravity.CENTER
                background = box(Color.TRANSPARENT, th.accent, dp(16))
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener { quick(ins, k) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        quickRow.addView(qBox)
        root.addView(quickRow)
        chipRow = LinearLayout(this).apply { setPadding(dp(2), dp(8), 0, dp(2)) }
        root.addView(chipRow)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, 0) }
        input = EditText(this).apply {
            setHintTextColor(th.muted); setTextColor(th.ink); textSize = 15f
            background = box(th.surface, faint(), dp(22))
            setPadding(dp(16), dp(10), dp(16), dp(10))
            maxLines = 5
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        goBtn = TextView(this).apply {
            text = "➤"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(th.bg)
            background = GradientDrawable().apply { setColor(th.accent); shape = GradientDrawable.OVAL }
            setOnClickListener { go(mode) }
        }
        row.addView(goBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        root.addView(row)

        setContentView(host)
        setMode(2)
        welcome()
        handle(intent)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        handle(i)
    }

    private fun handle(i: Intent?) {
        val p = i?.getStringExtra("project") ?: return
        val d = File(p)
        if (d.isDirectory) openProject(d)
    }

    // ---------- state ----------

    private fun welcome() {
        logBox.removeAllViews()
        addLog("a", "👋 Assalam o alaikum! Main Code Studio hoon.\n\n" +
            "⚡ BUILD: likhein kya banana hai (website, app, script, game...). Main pehle plan banata hoon, phir poora project likhta hoon aur khud check karta hoon.\n" +
            "✏️ EDIT: project khulne ke baad likhein 'dark mode lagao', 'login page add karo'. Har edit ke baad dikhata hoon kaunsi file mein kya badla.\n" +
            "💬 ASK: koi bhi code sawal ya bug poochein.\n" +
            "🚀 Project khulne par upar ke quick buttons se Find bugs, Optimize, Add tests, Better UI, Security jaise kaam ek tap mein chalayein.\n" +
            "📦 Files tabs mein hain, ▶ Preview se chalayein, 📦 Zip se poora project save karein.")
    }

    private fun say(s: String) {
        status.text = s
        if (liveCard != null && s.isNotBlank()) {
            if (stepList.lastOrNull() != s) stepList.add(s)
            liveSteps?.text = stepList.mapIndexed { i, x -> (if (i < stepList.size - 1) "✓  " else "▸  ") + x }.joinToString("\n")
            liveNow?.text = ""
        }
    }

    // ---- live activity card: shows what Anjoo is doing while it thinks and codes ----
    private var liveCard: LinearLayout? = null
    private var liveSteps: TextView? = null
    private var liveNow: TextView? = null
    private var liveThought: TextView? = null
    private val stepList = ArrayList<String>()
    private var lastLive = 0L

    private fun startLive() {
        stepList.clear()
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(th.surface, th.accent, dp(12))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        c.addView(TextView(this).apply {
            text = "●  Anjoo is working"; textSize = 13f; setTextColor(th.accent)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        })
        liveSteps = TextView(this).apply { textSize = 12.5f; setTextColor(th.ink); setPadding(0, dp(8), 0, 0) }
        liveNow = TextView(this).apply { textSize = 12.5f; setTextColor(th.accent); setPadding(0, dp(4), 0, 0) }
        liveThought = TextView(this).apply {
            textSize = 12f; setTextColor(th.muted); setTypeface(null, Typeface.ITALIC); setPadding(0, dp(6), 0, 0)
            maxLines = 7; ellipsize = android.text.TextUtils.TruncateAt.START
        }
        c.addView(liveSteps); c.addView(liveNow); c.addView(liveThought)
        logBox.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        liveCard = c
        Coder.live = { thought, answer -> onLive(thought, answer) }
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun onLive(thought: String, answer: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastLive < 150) return
        lastLive = now
        ui.post {
            if (liveCard == null) return@post
            if (answer.isBlank()) {
                if (thought.isNotBlank()) liveThought?.text = "💭 " + thought.replace("*", "").takeLast(600)
            } else {
                val m = Regex("=== FILE: (.+?) ===").findAll(answer).lastOrNull()
                val kb = String.format(java.util.Locale.US, "%.1f", answer.length / 1000.0)
                liveNow?.text = if (m != null) "✍  Writing " + m.groupValues[1].trim() + "  (" + kb + "k characters so far)"
                    else "✍  Writing the answer...  (" + kb + "k characters so far)"
                liveThought?.visibility = View.GONE
            }
            logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun stopLive() {
        Coder.live = null
        liveCard?.let { logBox.removeView(it) }
        liveCard = null; liveSteps = null; liveNow = null; liveThought = null
    }

    private fun setBusy(b: Boolean) {
        busy = b
        goBtn.isEnabled = !b
        goBtn.alpha = if (b) 0.4f else 1f
    }

    private fun newProject() {
        if (busy) return
        dir = null; cur = null
        titleTv.text = "Code Studio"
        welcome(); refreshTabs(); show(null)
        setMode(2)
        say("")
    }

    private fun openProject(d: File) {
        dir = d; cur = null
        titleTv.text = Coder.name(d)
        logBox.removeAllViews()
        val h = Coder.history(d)
        if (h.isEmpty()) addLog("a", "Project khul gaya. Badlav likhein ya sawal poochein.")
        for ((r, t) in h) addLog(r, t)
        addProjectCard(d, false)
        setMode(1)
        refreshTabs(); show(null)
        say(Coder.readFiles(d).size.toString() + " files")
    }

    private fun pickProject() { openSide() }

    private fun pickProjectOld() {
        val ps = Coder.list(this)
        if (ps.isEmpty()) { Toast.makeText(this, "Abhi koi project nahi. Kuch banane ko bolein.", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Projects")
            .setItems(ps.map { Coder.name(it) }.toTypedArray()) { _, i -> if (!busy) openProject(ps[i]) }.show()
    }

    private fun deleteProject() {
        val d = dir ?: return
        AlertDialog.Builder(this).setMessage("Delete project '" + Coder.name(d) + "'?")
            .setPositiveButton("Delete") { _, _ -> Coder.delete(d); newProject() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- tabs and viewers ----------

    private fun fileIcon(p: String): String = when (p.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "🌐"
        "css" -> "🎨"
        "js", "ts", "jsx", "tsx" -> "⚙️"
        "py" -> "🐍"
        "json" -> "📋"
        "md", "txt" -> "📝"
        "kt", "java" -> "☕"
        "png", "jpg", "jpeg", "svg", "gif", "webp" -> "🖼️"
        else -> "📄"
    }

    private fun quick(instruction: String, kind: Int) {
        if (busy || dir == null) return
        input.setText(instruction)
        go(kind)
    }

    private fun refreshTabs() {
        tabs.removeAllViews()
        fun tab(label: String, sel: Boolean, a: () -> Unit) {
            val t = TextView(this).apply {
                text = label; textSize = 12f; typeface = Typeface.MONOSPACE
                setTextColor(if (sel) th.bg else th.accent)
                background = box(if (sel) th.accent else th.surface, th.accent, dp(8))
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setOnClickListener { a() }
            }
            tabs.addView(t, LinearLayout.LayoutParams(-2, dp(34)).apply { rightMargin = dp(5); topMargin = dp(4) })
        }
        tab("💬 CHAT", cur == null) { show(null) }
        quickRow.visibility = if (dir == null) View.GONE else View.VISIBLE
        val d = dir ?: return
        for (p in Coder.readFiles(d).keys) tab(fileIcon(p) + " " + p, cur == p) { show(p) }
    }

    private fun show(path: String?) {
        cur = path
        web?.visibility = View.GONE
        if (path == null) {
            logScroll.visibility = View.VISIBLE
            codeWrap.visibility = View.GONE
        } else {
            val d = dir
            val text = if (d != null) try { File(d, path).readText(Charsets.UTF_8) } catch (e: Exception) { "File nahi khuli." } else ""
            codeName.text = path
            codeText.text = text
            logScroll.visibility = View.GONE
            codeWrap.visibility = View.VISIBLE
        }
        refreshTabs()
    }

    private fun editFile() {
        val d = dir ?: return
        val p = cur ?: return
        editFileDialog(d, p) {
            show(p)
            if (web?.visibility == View.VISIBLE) preview()
        }
    }

    private fun editFileDialog(d: File, p: String, saved: () -> Unit) {
        val et = EditText(this).apply {
            setText(try { File(d, p).readText(Charsets.UTF_8) } catch (e: Exception) { "" })
            typeface = Typeface.MONOSPACE; textSize = 12f
            setHorizontallyScrolling(true); gravity = Gravity.TOP or Gravity.START
            minLines = 12
        }
        AlertDialog.Builder(this).setTitle(p).setView(et)
            .setPositiveButton("Save") { _, _ ->
                Coder.writeFile(d, p, et.text.toString())
                saved()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun copy(t: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Anjoo", t))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun share(t: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Share"))
    }

    // ---------- chat log ----------

    private fun addLog(role: String, text: String, thought: String = "") {
        val user = role == "u"
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = box(if (user) th.user else th.surface, if (user) th.user else faint(), dp(12))
        }
        if (user) {
            v.addView(TextView(this).apply { this.text = text; setTextColor(th.ink); textSize = 14.5f; setTextIsSelectable(true) })
        } else {
            if (thought.isNotBlank()) {
                val body = TextView(this).apply {
                    this.text = thought; textSize = 12.5f; setTextColor(th.muted); visibility = View.GONE
                    setPadding(dp(8), dp(2), dp(4), dp(8))
                }
                v.addView(TextView(this).apply {
                    this.text = "Thought process  ▸"; textSize = 12f; setTextColor(th.muted); setPadding(0, dp(2), 0, dp(6))
                    setOnClickListener {
                        val open = body.visibility == View.VISIBLE
                        body.visibility = if (open) View.GONE else View.VISIBLE
                        this.text = if (open) "Thought process  ▸" else "Thought process  ▾"
                    }
                })
                v.addView(body)
            }
            v.addView(Md.render(this, text, th))
        }
        logBox.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun faint() = Color.argb(70, 128, 128, 128)

    /** A project card inside the chat: file list, code viewer and live preview, all without leaving the chat. */
    private fun addProjectCard(d: File, open: Boolean) {
        val files = Coder.readFiles(d)
        if (files.isEmpty()) return
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(th.surface, th.accent, dp(12))
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            this.text = Coder.name(d) + "  ·  " + files.size + " files"; setTextColor(th.accent)
            textSize = 13.5f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val codeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val prevBox = FrameLayout(this).apply { visibility = View.GONE }
        var wv: WebView? = null
        val name = files.keys.firstOrNull { it.equals("index.html", true) }
            ?: files.keys.firstOrNull { it.equals("README.md", true) } ?: files.keys.first()
        val codeText2 = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(th.ink); setTextIsSelectable(true)
            setPadding(dp(10), dp(6), dp(10), dp(10))
        }
        var curName = name
        fun load(n: String) {
            curName = n
            codeText2.text = try { File(d, n).readText(Charsets.UTF_8) } catch (e: Exception) { "File nahi khuli." }
        }
        val fileRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (n in files.keys) {
            fileRow.addView(TextView(this).apply {
                this.text = n; textSize = 11.5f; typeface = Typeface.MONOSPACE; setTextColor(th.accent)
                background = box(Color.TRANSPARENT, faint(), dp(8)); setPadding(dp(9), dp(5), dp(9), dp(5))
                setOnClickListener { load(n) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        codeBox.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(fileRow) })
        val hsv = HorizontalScrollView(this).apply { addView(codeText2) }
        val vsv = ScrollView(this).apply {
            addView(hsv); setBackgroundColor(Color.argb(140, 0, 0, 0))
            setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
        }
        codeBox.addView(vsv, LinearLayout.LayoutParams(-1, dp(300)).apply { topMargin = dp(6) })
        val bar = LinearLayout(this).apply { gravity = Gravity.END }
        bar.addView(TextView(this).apply {
            this.text = "Copy file"; textSize = 12f; setTextColor(th.accent); setPadding(dp(8), dp(8), dp(8), dp(4))
            setOnClickListener { copy(codeText2.text.toString()) }
        })
        bar.addView(TextView(this).apply {
            this.text = "Edit"; textSize = 12f; setTextColor(th.accent); setPadding(dp(8), dp(8), dp(8), dp(4))
            setOnClickListener { editFileDialog(d, curName) { load(curName) } }
        })
        codeBox.addView(bar)
        load(name)

        fun showCode() { codeBox.visibility = if (codeBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE; prevBox.visibility = View.GONE }
        fun showPrev() {
            val entry = if (files.keys.any { it == "index.html" }) "index.html" else files.keys.firstOrNull { it.endsWith(".html") }
            if (entry == null) { Toast.makeText(this, "Preview sirf web (HTML) projects ke liye hai.", Toast.LENGTH_SHORT).show(); return }
            if (prevBox.visibility == View.VISIBLE) { prevBox.visibility = View.GONE; return }
            if (wv == null) {
                val w = projectWebView(d)
                w.setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
                w.loadUrl("https://app.local/" + entry)
                prevBox.addView(w, FrameLayout.LayoutParams(-1, -1))
                wv = w
            } else wv?.reload()
            codeBox.visibility = View.GONE
            prevBox.visibility = View.VISIBLE
        }
        val acts = LinearLayout(this).apply { setPadding(0, dp(6), 0, 0) }
        acts.addView(btn("▶ Preview") { showPrev() }, LinearLayout.LayoutParams(-2, dp(36)).apply { leftMargin = 0 })
        acts.addView(btn("⛶ Full screen") { dir = d; preview() })
        acts.addView(btn("{ } Code") { showCode() })
        acts.addView(btn("🛠 Fix") { dir = d; fixErrors() })
        acts.addView(btn("↩ Undo") { dir = d; undoEdit() })
        acts.addView(btn("📦 Zip") { dir = d; exportZip() })
        card.addView(top)
        card.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(acts) })
        card.addView(codeBox, LinearLayout.LayoutParams(-1, -2))
        card.addView(prevBox, LinearLayout.LayoutParams(-1, dp(420)).apply { topMargin = dp(6) })
        logBox.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        if (open) {
            if (files.keys.any { it == "index.html" } && files.keys.none { it == "package.json" || it.startsWith("server") }) showPrev() else showCode()
        }
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun mime(n: String): String = when (n.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "css" -> "text/css"
        "js", "mjs" -> "application/javascript"
        "json" -> "application/json"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        else -> "text/plain"
    }

    /** A WebView that serves the project's files from https://app.local/ (so css/js/images link up). */
    private fun projectWebView(base: File): WebView {
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.setBackgroundColor(Color.WHITE)
        wv.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onConsoleMessage(m: android.webkit.ConsoleMessage?): Boolean {
                if (m != null && m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR && jsErrors.length < 3000)
                    jsErrors.append(m.message()).append(" (").append((m.sourceId() ?: "").substringAfterLast('/')).append(":").append(m.lineNumber()).append(")\n")
                return true
            }
        }
        wv.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request?.isForMainFrame == true) view?.loadData("<body style='font-family:sans-serif;padding:24px'><h3>Preview load nahi hua</h3><p>Is project ko server chahiye ho sakta hai. Code tab mein files dekhein.</p></body>", "text/html", "UTF-8")
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                if (u.host != "app.local") return null
                val f = File(base, (u.path ?: "").trimStart('/'))
                return try {
                    if (f.isFile && f.canonicalPath.startsWith(base.canonicalPath)) WebResourceResponse(mime(f.name), "UTF-8", FileInputStream(f))
                    else WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                } catch (e: Exception) { null }
            }
        }
        return wv
    }

    // ---------- work ----------

    private fun go(kind: Int) {
        val t = input.text.toString().trim()
        if (t.isEmpty() || busy) return
        input.setText("")
        addLog("u", t)
        if (cur != null) show(null)
        setBusy(true)
        startLive()
        say(if (kind == 0) "Reading your question..." else "Working...")
        val d = dir
        val deep = getSharedPreferences("anjoo", MODE_PRIVATE).getBoolean("codeThink", true)
        val thoughts = StringBuilder()
        Thread {
            try {
                if (kind == 0) {
                    val ans = Coder.ask(this, d, t, deep, { tt -> thoughts.append(tt).append("\n") })
                    ui.post { stopLive(); addLog("a", ans, thoughts.toString().trim()); say(""); setBusy(false) }
                } else if (d == null || kind == 2) {
                    val r = Coder.build(this, t, "auto", true, deep, { tt -> thoughts.append(tt).append("\n\n") }) { s -> ui.post { say(s) } }
                    ui.post {
                        stopLive()
                        dir = r.first
                        setMode(1)
                        titleTv.text = Coder.name(r.first)
                        addLog("a", r.second, thoughts.toString().trim())
                        addProjectCard(r.first, true)
                        say(Coder.readFiles(r.first).size.toString() + " files ready")
                        setBusy(false); refreshTabs()
                    }
                } else {
                    Coder.snapshot(this, d)
                    val notes = Coder.revise(this, d, t, deep, { tt -> thoughts.append(tt).append("\n\n") }) { s -> ui.post { say(s) } }
                    ui.post {
                        stopLive()
                        val sum = Coder.changes(this, d)
                        addLog("a", notes + (if (sum.isNotBlank()) "\n\n" + sum else ""), thoughts.toString().trim())
                        addProjectCard(d, true)
                        say("Updated")
                        setBusy(false)
                        if (cur != null && !File(d, cur!!).exists()) cur = null
                        refreshTabs()
                        if (web?.visibility == View.VISIBLE) preview()
                    }
                }
            } catch (e: Exception) {
                ui.post { stopLive(); addLog("a", "Error: " + (e.message ?: e.javaClass.simpleName)); say(""); setBusy(false) }
            }
        }.start()
    }

    // ---------- preview and export ----------

    private fun preview() {
        val d = dir
        if (d == null) { Toast.makeText(this, "Pehle project banayein.", Toast.LENGTH_SHORT).show(); return }
        val files = Coder.readFiles(d).keys
        val entry = if ("index.html" in files) "index.html" else files.firstOrNull { it.endsWith(".html") }
        if (entry == null) { Toast.makeText(this, "Preview sirf web (HTML) projects ke liye hai.", Toast.LENGTH_LONG).show(); return }
        val w = web ?: projectWebView(d).also { area.addView(it, FrameLayout.LayoutParams(-1, -1)); web = it }
        logScroll.visibility = View.GONE
        codeWrap.visibility = View.GONE
        w.visibility = View.VISIBLE
        w.loadUrl("https://app.local/" + entry)
        say("Preview: " + entry)
    }

    private fun exportZip() {
        val d = dir
        if (d == null) { Toast.makeText(this, "Pehle project banayein.", Toast.LENGTH_SHORT).show(); return }
        val slug = Coder.name(d).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "project" }
        try {
            startActivityForResult(
                Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/zip").putExtra(Intent.EXTRA_TITLE, "$slug.zip"), 41
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Zip save nahi ho saka.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 41 || res != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        val d = dir ?: return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(Coder.zip(d)) }
            Toast.makeText(this, "Zip save ho gaya.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Zip save nahi ho saka.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        if (side?.isOpen == true) { side?.close(); return }
        val w = web
        if (w != null && w.visibility == View.VISIBLE) { show(cur); return }
        if (cur != null) { show(null); return }
        super.onBackPressed()
    }
}
