# Anjoo AI: Android awaazi assistant

Mic dabayein aur bolein. Gemini hukm samajhta hai aur phone par kaam karta hai.

## Kya kar sakta hai
- Koi bhi installed app kholna ("WhatsApp kholo", "YouTube kholo")
- Contacts se naam dhoond kar call karna (call se pehle "Haan/Nahi" poochta hai)
- SMS bhejna (bhejne se pehle poochta hai)
- WhatsApp chat kholna aur paigham likh dena (send ka button aap dabate hain)
- Alarm aur timer lagana
- Web search, website kholna, Maps mein rasta
- Jawab awaaz mein bhi sunata hai (agar phone mein Urdu/English voice maujood ho)

## Jo nahi kar sakta
- Doosri apps ke andar khud tap karna (jaise bank app mein paise bhejna). Yeh jaan boojh kar nahi rakha.
- WhatsApp ka paigham khud send karna. Android is ki ijazat nahi deta, aap ko ek tap karna hota hai.

## Banane ke qadam (pehli baar)
1. Computer par Android Studio install karein (developer.android.com/studio).
2. Android Studio mein File > Open, aur is `AnjooAI` folder ko kholein. Gradle sync poora hone dein (internet chahiye, pehli baar kuch minute lagte hain).
3. Phone mein Settings > About phone > Build number par 7 baar tap karein, phir Developer options mein USB debugging on karein.
4. Phone ko USB se jorain, Android Studio mein upar ka hara Run button dabayein. App phone par install ho jayegi.
   (Ya Build > Build APK(s) se APK bana kar phone mein copy karke install karein.)

## Pehli dafa istemal
1. App kholte hi Settings aayegi. Apni Gemini API key dalein: aistudio.google.com/apikey par apne Google account se "Create API key" dabayein. Model "gemini-3.8-flash" rakhein (ya wahan ki list se jo naam dikhe).
2. Mic, contacts, call aur SMS ki ijazat "Allow" karein.
3. Mic dabayein aur bolein: "Ahmed ko call karo", "Subah 6 baje ka alarm lagao", "WhatsApp kholo".
   Zubaan ka button "اردو / English" bolne ki zubaan badalta hai.

## Zaroori baatein
- Gemini Pro subscription aur API key do alag cheezein hain. Key AI Studio se banti hai, us par free limit hoti hai aur us se zyada istemal par kharcha ho sakta hai. Key kisi ko na dein; yeh sirf aap ke phone mein rehti hai.
- WhatsApp ke liye "0300..." wale number Pakistan ke code (92) mein badal diye jate hain.
- Awaaz pehchaan Google ki service use karti hai, is liye internet aur Google app chahiye.
- Pehle kuch din call/SMS ki tasdeeq wali screen par nazar rakhein ke naam aur number sahi hain.

## v12 naye kaam
- Naya Anjoo AI app icon (robot + neon circuit).
- Markhor hata diya: ab ek cute robot (Buddy) screen par ghoomta hai, aapki baat par chehre ke expressions badalta hai (khush, pyar, udaas, hairan, soch, sunna, neend).
- Mouse jaisa arrow (cursor): jab Anjoo koi kaam kare (tap, likhna, back/home, scroll, app kholna) to arrow dusri apps ke upar bhi dikhta hai ke kahan ja raha hai. Iske liye Accessibility on honi chahiye.
- Awaaz pehchan behtar aur tez: jumla 0.7 sec khamoshi par poora, jawab ki awaz pehle jumle se shuru, Anjoo soch raha ho tab bhi aapki nayi baat sunta hai, aur samajhne par chhoti beep aati hai.

## v14 Code Studio (Claude jaisi coding)
- Menu > "Code Studio": likhein ya bolein kya banana hai. Pehle architecture plan, phir poora multi-file project (README aur dependency file samet), phir bug review.
- Project ke har file ka tab: dekhein, Copy, Share, haath se Edit/Save.
- Badlav: "dark mode lagao", "login add karo" likhein, sirf zaroori files badalti hain. Ask: koi bhi code ya bug ka sawal, project dekh kar jawab.
- Web projects ke liye Run (live preview), Zip se poora project save.
- Awaaz se: "Anjoo, ek calculator app banao" (write_code) ya "isme history add karo" (edit_code).

## v15 Professional chat app
- Boot lines ("loading...") aur screen par ghoomta robot hata diya. Ab saaf chat screen hai; robot sirf chhote avatar ki tarah header mein (expressions ke saath) aur khali screen par.
- Header: history, avatar, naam + model, naya chat, menu. Khali chat par suggestions (Claude/ChatGPT/Gemini jaisa).
- Jawab Markdown mein: headings, lists, bold, code blocks (Copy ke saath), links. Har jawab ke neeche Copy, Listen, Share, Retry.
- Think (DeepSeek jaisa gehri soch, "Thought process" dikhta hai) aur Web (Google Search se taaza maloomat + sources) chips.
- "+" se Photo, Camera, PDF/text/code file attach (Kimi jaisa lambi file parhna).
- Custom instructions (ChatGPT jaisa), Code Studio, Live voice (mic button), phone control sab isi app mein.
- Settings grouped: Voice and language, Phone control, Appearance, Backup, API key.

## v16 Coding aur Thinking advanced
- Chat mein code likhwayein to jawab ke code block par Code | Preview tabs aate hain (HTML/SVG ka live preview usi chat mein), saath Full screen, Studio, Copy.
- Code Studio ki chat mein har project ka card: files, code viewer, live Preview aur Edit, sab usi chat ke andar.
- Deep think (Code Studio mein ON/OFF): pehle gehra analysis (requirements, edge cases, test scenarios), phir code, phir 2 round review/test. "Thought process" dekh sakte hain.
- Main chat ka Think chip ab advanced level (high thinking) par chalta hai.

## v31 naya icon, opening scene, image generation, behtar coding
- Naya icon: koi harf nahi, ek roshan "spark" aur ghoomta hua orbit ring (gradient background). Android 13+ par themed icon bhi.
- App khulte hi chhoti film jaisi scene: raat ka aasman, taare, aurora, ubharta hua orb, shooting star, jugnu, aur beech mein Anjoo spark. Tap karein to foran skip.
- Chat mein image banana: "Image" chip dabayein ya seedha likhein/bolein "ek sheer ki tasveer banao". Picture chat mein aati hai; tap par full screen, Save (Pictures/AnjooAI), Share, Edit (photo bhej kar "isko cartoon bana do" bhi chalta hai). Model: gemini-2.5-flash-image (agar aapke account par na ho to khud doosre model par chala jata hai).
- Coding: ab har web project banne ke baad chhupe hue browser mein khud chalta hai; JavaScript errors, missing files ya khali page mile to Anjoo khud theek karta hai (2 round). Naye rules: behtar UI design, games, tests, scripts, backend.

## Naye AI providers (v34)
Settings mein ab teen cheezein chunni hoti hain: **AI** (Google Gemini free by default, OpenAI, Claude, OpenRouter, Groq, DeepSeek, Mistral, xAI, ya Custom URL), phir **Model** (list se tap karke, ya "Load all models" se poori list), phir us ki **API key**. Har provider ki key alag save hoti hai.
Voice typing, Gemini voice aur picture banana hamesha Google Gemini key se chalte hain, chahe chat kisi aur AI se ho.

## v38 Claude jaisa interface, Thinking aur Commands summary
- **Look:** naye themes "Claude Light" (garam cream + terracotta) aur "Claude Dark". Pehli dafa phone ke dark/light mode ke mutabiq khud lag jate hain; Menu > Appearance se badal sakte hain (purane themes bhi maujood hain). Jawab serif font mein, bubble ke baghair, har jawab ke neeche ✦ ke saath Copy/Listen/Share/Retry. Composer gol card jaisa, khali screen par waqt ke mutabiq salam.
- **Thinking:** jawab se pehle live card: "✦ Thinking… 4s" aur model ki soch ka khulasa. Jawab shuru hote hi yeh "Thought for 4s ›" ban jata hai, tap karke poori soch dekhein. Ab har sawal par aata hai (pehle sirf Think chip par).
- **Commands summary:** jo bhi phone ka kaam Anjoo karta hai (app kholna, alarm, call, SMS, search...) woh live list mein dikhta hai: `… chal raha hai`, `✓ ho gaya`, `! masla`, `✕ nakam`. Jawab ke upar "⌘ Ran 2 commands ›" ke neeche ek line ka khulasa; tap karein to har command aur uska natija. Yeh chat history mein bhi save rehta hai.
- Menu > "Show thinking and commands" se yeh dono band/on kar sakte hain.
- Anjoo ab commands dohrata nahi: sirf ek chhota sachcha jumla batata hai ke kya hua aur kya nahi.

## v39 Sharmila robot
- Screen par ghoomne wala robot ab touch se bhagta hai: robot ko chhuen to ek qadam peechay hop karke hat jata hai, uske bagal mein tap karen to touch se door tez bhag jata hai. Kone mein phans jaye to doosri taraf nikal jata hai. Robot ko ungli se ghaseet kar kahin bhi rakh sakte hain (pehle jaisa).

## v40 Movie jaisa opening (Splash)
App khulte hi ~6 sec ki chhoti film: letterbox, terminal boot lines, hara code barish ki tarah girta hai, 10 parasite tentacles (chamakte hue, suckers aur roshan nok ke saath) char taraf se rengte hain, code ko pakar kar jhatke dete hain (glitch aur camera shake), phir sab kuch center mein khinch kar safed flash aur shockwave, tentacles teal rang mein shant ho jate hain aur Anjoo logo orbit rings, lens flare aur sparks ke saath ubharta hai. Haptic jhatka bhi aata hai. Tap karein to foran skip.
