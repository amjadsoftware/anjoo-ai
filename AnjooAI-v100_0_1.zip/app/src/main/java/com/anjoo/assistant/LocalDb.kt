package com.anjoo.assistant

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

/**
 * Offline storage on the phone. This is the Android counterpart of the browser's localStorage + IndexedDB:
 *  - small settings, tasks, reminders and chats live in SharedPreferences / app files (localStorage-like, already offline);
 *  - notes and the "send when back online" queue live in this SQLite database (IndexedDB-like: real rows, search, indexes).
 * Notes, outbox and default knowledge storage stay on-device; optional semantic embeddings use a separate opt-in API path.
 */
class LocalDb private constructor(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "anjoo_local.db", null, 3) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE notes (id TEXT PRIMARY KEY, title TEXT NOT NULL DEFAULT '', body TEXT NOT NULL DEFAULT '', " +
                "pinned INTEGER NOT NULL DEFAULT 0, created INTEGER NOT NULL, updated INTEGER NOT NULL, deleted INTEGER NOT NULL DEFAULT 0)"
        )
        db.execSQL("CREATE INDEX notes_updated ON notes(deleted, pinned, updated)")
        db.execSQL("CREATE TABLE outbox (id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, created INTEGER NOT NULL)")
        createKnowledgeTables(db)
        createSemanticTables(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) createKnowledgeTables(db)
        if (oldVersion < 3) createSemanticTables(db)
    }

    private fun createKnowledgeTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS knowledge_docs (" +
            "id TEXT PRIMARY KEY, title TEXT NOT NULL DEFAULT '', source TEXT NOT NULL DEFAULT '', mime TEXT NOT NULL DEFAULT 'text/plain', " +
            "checksum TEXT NOT NULL DEFAULT '', chars INTEGER NOT NULL DEFAULT 0, chunks INTEGER NOT NULL DEFAULT 0, " +
            "created INTEGER NOT NULL, updated INTEGER NOT NULL, pinned INTEGER NOT NULL DEFAULT 0, deleted INTEGER NOT NULL DEFAULT 0)")
        db.execSQL("CREATE INDEX IF NOT EXISTS knowledge_docs_updated ON knowledge_docs(deleted, pinned, updated)")
        db.execSQL("CREATE TABLE IF NOT EXISTS knowledge_chunks (id INTEGER PRIMARY KEY AUTOINCREMENT, doc_id TEXT NOT NULL, ordinal INTEGER NOT NULL, content TEXT NOT NULL, " +
            "FOREIGN KEY(doc_id) REFERENCES knowledge_docs(id) ON DELETE CASCADE)")
        db.execSQL("CREATE INDEX IF NOT EXISTS knowledge_chunks_doc ON knowledge_chunks(doc_id, ordinal)")
        // FTS4 is available in Android's SQLite builds. Metadata columns are UNINDEXED so IDs never pollute searches.
        try {
            db.execSQL("CREATE VIRTUAL TABLE IF NOT EXISTS knowledge_fts USING fts4(docid UNINDEXED, chunkid UNINDEXED, title, content, tokenize=unicode61)")
        } catch (_: Exception) {
            // The KnowledgeBase retains a LIKE-based fallback on unusual SQLite builds.
        }
    }

    private fun createSemanticTables(db: SQLiteDatabase) {
        // Optional Gemini semantic vectors. Text stays local unless the user explicitly enables semantic indexing.
        db.execSQL("CREATE TABLE IF NOT EXISTS knowledge_embeddings (chunk_id INTEGER PRIMARY KEY, doc_id TEXT NOT NULL, model TEXT NOT NULL, dimensions INTEGER NOT NULL, vector BLOB NOT NULL, updated INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX IF NOT EXISTS knowledge_embeddings_doc ON knowledge_embeddings(doc_id)")
    }

    companion object {
        @Volatile private var inst: LocalDb? = null
        fun get(ctx: Context): LocalDb = inst ?: synchronized(this) { inst ?: LocalDb(ctx).also { inst = it } }
    }
}

class Note(val id: String, val title: String, val body: String, val pinned: Boolean, val created: Long, val updated: Long)

/** The user's notes. Work with no internet. Deleting keeps a hidden "tombstone" so a merge from another phone does not bring a note back. */
object Notes {

    private fun db(ctx: Context) = LocalDb.get(ctx).writableDatabase

    private fun row(c: android.database.Cursor) = Note(
        c.getString(0), c.getString(1), c.getString(2), c.getInt(3) == 1, c.getLong(4), c.getLong(5)
    )

    private const val COLS = "id, title, body, pinned, created, updated"

    @Synchronized
    fun add(ctx: Context, title: String, body: String): Note {
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString()
        val t = title.trim().take(120).ifEmpty { body.trim().lines().firstOrNull().orEmpty().take(60) }
        val cv = ContentValues().apply {
            put("id", id); put("title", t); put("body", body.trim().take(20000))
            put("pinned", 0); put("created", now); put("updated", now); put("deleted", 0)
        }
        db(ctx).insertOrThrow("notes", null, cv)
        return Note(id, t, body.trim(), false, now, now)
    }

    @Synchronized
    fun update(ctx: Context, id: String, title: String, body: String): Boolean {
        val cv = ContentValues().apply {
            put("title", title.trim().take(120)); put("body", body.trim().take(20000)); put("updated", System.currentTimeMillis())
        }
        return db(ctx).update("notes", cv, "id=? AND deleted=0", arrayOf(id)) > 0
    }

    @Synchronized
    fun setPinned(ctx: Context, id: String, pinned: Boolean) {
        val cv = ContentValues().apply { put("pinned", if (pinned) 1 else 0); put("updated", System.currentTimeMillis()) }
        db(ctx).update("notes", cv, "id=?", arrayOf(id))
    }

    @Synchronized
    fun delete(ctx: Context, id: String) {
        val cv = ContentValues().apply { put("deleted", 1); put("body", ""); put("title", ""); put("updated", System.currentTimeMillis()) }
        db(ctx).update("notes", cv, "id=?", arrayOf(id))
    }

    @Synchronized
    fun all(ctx: Context, query: String = ""): List<Note> {
        val q = query.trim()
        val out = ArrayList<Note>()
        val sel = if (q.isEmpty()) "deleted=0" else "deleted=0 AND (title LIKE ? ESCAPE '\\' OR body LIKE ? ESCAPE '\\')"
        val like = "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        val args = if (q.isEmpty()) null else arrayOf(like, like)
        db(ctx).query("notes", arrayOf("id", "title", "body", "pinned", "created", "updated"), sel, args, null, null, "pinned DESC, updated DESC")
            .use { c -> while (c.moveToNext()) out.add(row(c)) }
        return out
    }

    fun count(ctx: Context): Int = all(ctx).size

    /** The Nth note (1 = first) of the list as shown by [summary]. */
    fun byNumber(ctx: Context, n: Int): Note? = all(ctx).getOrNull(n - 1)

    fun summary(ctx: Context, query: String = "", max: Int = 12): String {
        val l = all(ctx, query)
        if (l.isEmpty()) return if (query.isBlank()) "Abhi koi note nahi hai." else "Is lafz ka koi note nahi mila."
        val sb = StringBuilder()
        for ((i, n) in l.take(max).withIndex()) {
            sb.append(i + 1).append(". ").append(if (n.pinned) "📌 " else "").append(n.title.ifEmpty { "(no title)" })
            val prev = n.body.replace('\n', ' ').take(70)
            if (prev.isNotEmpty() && prev != n.title) sb.append(" — ").append(prev)
            sb.append("\n")
        }
        if (l.size > max) sb.append("... aur ").append(l.size - max).append(" notes.")
        return sb.toString().trim()
    }

    // ---- sync file (move notes between phones with no server) ----

    @Synchronized
    fun exportArray(ctx: Context): JSONArray {
        val a = JSONArray()
        db(ctx).query("notes", arrayOf("id", "title", "body", "pinned", "created", "updated", "deleted"), null, null, null, null, "updated DESC").use { c ->
            while (c.moveToNext()) {
                a.put(JSONObject().put("id", c.getString(0)).put("title", c.getString(1)).put("body", c.getString(2))
                    .put("pinned", c.getInt(3) == 1).put("created", c.getLong(4)).put("updated", c.getLong(5)).put("deleted", c.getInt(6) == 1))
            }
        }
        return a
    }

    /** Merges notes from another phone or a backup. The newer edit of each note wins. Returns how many notes changed here. */
    @Synchronized
    fun merge(ctx: Context, incoming: JSONArray): Int {
        val d = db(ctx)
        var changed = 0
        d.beginTransaction()
        try {
            for (i in 0 until incoming.length()) {
                val o = incoming.optJSONObject(i) ?: continue
                val id = o.optString("id")
                if (id.isEmpty()) continue
                val upd = o.optLong("updated", 0L)
                var have = -1L
                d.rawQuery("SELECT updated FROM notes WHERE id=?", arrayOf(id)).use { c -> if (c.moveToFirst()) have = c.getLong(0) }
                if (have >= upd && have != -1L) continue
                val cv = ContentValues().apply {
                    put("id", id); put("title", o.optString("title").take(120)); put("body", o.optString("body").take(20000))
                    put("pinned", if (o.optBoolean("pinned")) 1 else 0)
                    put("created", o.optLong("created", upd)); put("updated", upd); put("deleted", if (o.optBoolean("deleted")) 1 else 0)
                }
                d.insertWithOnConflict("notes", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
                changed++
            }
            d.setTransactionSuccessful()
        } finally { d.endTransaction() }
        return changed
    }
}

/** Messages typed while there was no internet and AI was needed. They wait here and are only sent after you say yes. */
object Outbox {
    class Item(val id: Long, val text: String, val at: Long)

    private fun db(ctx: Context) = LocalDb.get(ctx).writableDatabase

    @Synchronized
    fun add(ctx: Context, text: String) {
        val t = text.trim().take(4000)
        if (t.isEmpty()) return
        val cv = ContentValues().apply { put("text", t); put("created", System.currentTimeMillis()) }
        db(ctx).insert("outbox", null, cv)
    }

    @Synchronized
    fun all(ctx: Context): List<Item> {
        val out = ArrayList<Item>()
        db(ctx).query("outbox", arrayOf("id", "text", "created"), null, null, null, null, "id ASC").use { c ->
            while (c.moveToNext()) out.add(Item(c.getLong(0), c.getString(1), c.getLong(2)))
        }
        return out
    }

    fun count(ctx: Context) = all(ctx).size

    @Synchronized
    fun remove(ctx: Context, id: Long) { db(ctx).delete("outbox", "id=?", arrayOf(id.toString())) }

    @Synchronized
    fun clear(ctx: Context) { db(ctx).delete("outbox", null, null) }
}

/** Notes + tasks in one small file, so two phones can be brought together without any server. */
object SyncFile {
    fun export(ctx: Context): String =
        JSONObject().put("app", "AnjooAI-sync").put("version", 1).put("at", System.currentTimeMillis())
            .put("notes", Notes.exportArray(ctx)).put("tasks", Tasks.all(ctx)).toString()

    /** Returns a short human message. Safe to call with any text: a wrong file is refused. */
    fun merge(ctx: Context, text: String): String {
        val root = try { JSONObject(text) } catch (e: Exception) { return "Ye Anjoo ki sync file nahi lagti." }
        if (root.optString("app") != "AnjooAI-sync") return "Ye Anjoo ki sync file nahi lagti."
        val n = Notes.merge(ctx, root.optJSONArray("notes") ?: JSONArray())
        var t = 0
        val tasks = root.optJSONArray("tasks") ?: JSONArray()
        for (i in 0 until tasks.length()) if (Tasks.importOne(ctx, tasks.getJSONObject(i))) t++
        return String.format(Locale.ENGLISH, "Merge ho gaya: %d notes aur %d naye tasks.", n, t)
    }
}
