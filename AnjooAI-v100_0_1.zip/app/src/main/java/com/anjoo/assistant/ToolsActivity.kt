package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Searchable capability directory and privacy-safe execution history for Anjoo's tool system. */
class ToolsActivity : Activity() {
    private val bg = Color.rgb(247, 246, 243)
    private val surface = Color.WHITE
    private val ink = Color.rgb(32, 37, 43)
    private val muted = Color.rgb(105, 112, 120)
    private val accent = Color.rgb(37, 111, 194)
    private val line = Color.rgb(225, 228, 232)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var search: EditText
    private lateinit var categoryRail: LinearLayout
    private var selectedCategory: ToolRegistry.Category? = null
    private var historyMode = false
    private var query = ""

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(22), dp(16), dp(12))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        top.addView(TextView(this).apply {
            text = "‹"; textSize = 32f; setTextColor(ink); gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(46), dp(48)))
        top.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@ToolsActivity).apply { text = "Tools Hub"; textSize = 24f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD })
            addView(TextView(this@ToolsActivity).apply { text = "Capabilities, access readiness and activity"; textSize = 12.5f; setTextColor(muted) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = "↻"; textSize = 25f; setTextColor(accent); gravity = Gravity.CENTER
            setOnClickListener { refreshContent() }
        }, LinearLayout.LayoutParams(dp(42), dp(46)))
        root.addView(top)

        search = EditText(this).apply {
            hint = "Search tools, tasks or capability…"
            textSize = 14f; setTextColor(ink); setHintTextColor(muted); isSingleLine = true
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(surface, dp(13), line)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(14) })
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { query = s?.toString() ?: ""; render() }
            override fun afterTextChanged(s: Editable?) {}
        })

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tabs.addView(tab("All tools") { historyMode = false; selectedCategory = null; render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
        tabs.addView(tab("Recent activity") { historyMode = true; render() }, LinearLayout.LayoutParams(0, dp(40), 1f))
        root.addView(tabs, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        categoryRail = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(categoryRail)
        }, LinearLayout.LayoutParams(-1, dp(43)).apply { topMargin = dp(3) })

        val scroll = ScrollView(this).apply { isFillViewport = false; clipToPadding = false }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(24)) }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(4) })
        setContentView(root)
        render()
    }

    private fun rounded(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun tab(label: String, action: () -> Unit): TextView = TextView(this).apply {
        text = label; gravity = Gravity.CENTER; textSize = 14f; setTextColor(ink)
        setOnClickListener { action() }
    }

    private fun render() {
        content.removeAllViews()
        renderCategoryRail()
        if (historyMode) renderHistory() else renderTools()
    }

    private fun renderCategoryRail() {
        categoryRail.removeAllViews()
        val cats = listOf(null) + ToolRegistry.categories()
        for (cat in cats) {
            val label = cat?.title ?: "All categories"
            val chosen = selectedCategory == cat
            val chip = TextView(this).apply {
                text = label; textSize = 12f; gravity = Gravity.CENTER
                setTextColor(if (chosen) Color.WHITE else ink)
                background = rounded(if (chosen) accent else surface, dp(18), if (chosen) accent else line)
                setPadding(dp(13), 0, dp(13), 0)
                setOnClickListener { selectedCategory = cat; historyMode = false; render() }
            }
            categoryRail.addView(chip, LinearLayout.LayoutParams(-2, dp(32)).apply { rightMargin = dp(7); topMargin = dp(4) })
        }
        categoryRail.visibility = if (historyMode) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun renderTools() {
        val all = ToolRegistry.search(query, selectedCategory)
        val ready = all.count { ToolRegistry.readiness(this, it) == ToolRegistry.Readiness.READY }
        content.addView(TextView(this).apply {
            text = "${all.size} tools  ·  $ready ready now  ·  ${all.size - ready} need setup or device check"
            textSize = 12.5f; setTextColor(muted); setPadding(dp(3), dp(4), dp(3), dp(10))
        })
        if (all.isEmpty()) {
            content.addView(empty("No matching tools. Try another search.")); return
        }
        for (cat in ToolRegistry.categories()) {
            val items = all.filter { it.category == cat }
            if (items.isEmpty()) continue
            content.addView(TextView(this).apply {
                text = "${cat.icon}  ${cat.title}  ·  ${items.size}"
                textSize = 15f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(3), dp(14), dp(3), dp(7))
            })
            for (item in items) {
                val readyState = ToolRegistry.readiness(this, item)
                val status = when (readyState) {
                    ToolRegistry.Readiness.READY -> "READY"
                    ToolRegistry.Readiness.NEEDS_PERMISSION -> "PERMISSION"
                    ToolRegistry.Readiness.NEEDS_SETUP -> "SETUP"
                    ToolRegistry.Readiness.CHECK_DEVICE -> "OFFLINE?"
                }
                val statusColor = when (readyState) {
                    ToolRegistry.Readiness.READY -> Color.rgb(27, 128, 82)
                    ToolRegistry.Readiness.NEEDS_PERMISSION, ToolRegistry.Readiness.NEEDS_SETUP -> Color.rgb(179, 111, 28)
                    ToolRegistry.Readiness.CHECK_DEVICE -> muted
                }
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(surface, dp(13), line)
                    setPadding(dp(13), dp(10), dp(13), dp(10))
                    setOnClickListener { showDetails(item, status) }
                }
                val titleRow = LinearLayout(this@ToolsActivity).apply { gravity = Gravity.CENTER_VERTICAL }
                titleRow.addView(TextView(this@ToolsActivity).apply {
                    text = item.name; textSize = 14f; setTextColor(ink); typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                }, LinearLayout.LayoutParams(0, -2, 1f))
                titleRow.addView(TextView(this@ToolsActivity).apply {
                    text = status; textSize = 10f; setTextColor(statusColor); typeface = Typeface.DEFAULT_BOLD
                })
                card.addView(titleRow)
                card.addView(TextView(this@ToolsActivity).apply {
                    text = item.description; textSize = 12f; setTextColor(muted); maxLines = 3
                    setPadding(0, dp(4), 0, dp(5))
                })
                card.addView(TextView(this@ToolsActivity).apply {
                    text = item.risk.label + "  ·  " + item.requirement
                    textSize = 10.5f; setTextColor(muted)
                })
                content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            }
        }
        content.addView(TextView(this).apply {
            text = "Readiness means local prerequisites were checked. It does not prove every provider API or external app will succeed."
            textSize = 11f; setTextColor(muted); setPadding(dp(4), dp(12), dp(4), dp(8))
        })
    }

    private fun showDetails(tool: ToolRegistry.ToolInfo, status: String) {
        val props = tool.parameters.optJSONObject("properties") ?: org.json.JSONObject()
        val args = props.keys().asSequence().toList().joinToString(", ").ifBlank { "No arguments" }
        val required = tool.parameters.optJSONArray("required")?.let { a -> (0 until a.length()).joinToString(", ") { a.optString(it) } } ?: "None declared"
        AlertDialog.Builder(this)
            .setTitle(tool.name)
            .setMessage(buildString {
                append(tool.description).append("\n\nCategory: ").append(tool.category.title)
                append("\nRisk: ").append(tool.risk.label)
                append("\nReadiness: ").append(status)
                append("\nRequirement: ").append(tool.requirement)
                append("\n\nParameters: ").append(args)
                append("\nRequired: ").append(required)
                append("\n\nThe AI calls tools when your request needs them. Confirmation and Android permissions still apply.")
            })
            .setPositiveButton("Done", null)
            .show()
    }

    private fun renderHistory() {
        val rows = ToolRunLog.entries(this).filter { query.isBlank() || it.name.contains(query, true) || it.status.contains(query, true) || it.category.contains(query, true) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(TextView(this).apply {
            text = "${rows.size} recent executions (max 80)"; textSize = 12.5f; setTextColor(muted)
        }, LinearLayout.LayoutParams(0, dp(40), 1f))
        bar.addView(Button(this).apply {
            text = "Clear"; isAllCaps = false; textSize = 12f
            setOnClickListener {
                AlertDialog.Builder(this@ToolsActivity).setMessage("Clear the local tool activity history? No chat or files will be deleted.")
                    .setPositiveButton("Clear history") { _, _ -> ToolRunLog.clear(this@ToolsActivity); render() }
                    .setNegativeButton("Cancel", null).show()
            }
        })
        content.addView(bar)
        if (rows.isEmpty()) { content.addView(empty("No matching tool activity yet.")); return }
        val fmt = SimpleDateFormat("d MMM yyyy · HH:mm:ss", Locale.getDefault())
        for (e in rows) {
            val color = when (e.status) {
                "DONE" -> Color.rgb(27, 128, 82)
                "CANCELLED" -> muted
                "SETUP" -> Color.rgb(179, 111, 28)
                else -> Color.rgb(191, 65, 56)
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = rounded(surface, dp(13), line)
                setPadding(dp(13), dp(11), dp(13), dp(11))
            }
            val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            top.addView(TextView(this).apply { text = e.name; textSize = 14f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0, -2, 1f))
            top.addView(TextView(this).apply { text = e.status; textSize = 10f; setTextColor(color); typeface = Typeface.DEFAULT_BOLD })
            card.addView(top)
            card.addView(TextView(this).apply {
                text = "${e.category}  ·  ${fmt.format(Date(e.at))}  ·  ${e.durationMs} ms"
                textSize = 11.5f; setTextColor(muted); setPadding(0, dp(4), 0, 0)
            })
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
        content.addView(TextView(this).apply {
            text = "Privacy: tool arguments, messages, file contents, API keys and raw outputs are not stored in this history."
            textSize = 11f; setTextColor(muted); setPadding(dp(4), dp(10), dp(4), dp(8))
        })
    }

    private fun empty(label: String) = TextView(this).apply {
        text = label; textSize = 13f; setTextColor(muted); gravity = Gravity.CENTER
        setPadding(dp(16), dp(35), dp(16), dp(35))
    }

    override fun onResume() {
        super.onResume()
        refreshContent()
    }

    private fun refreshContent() {
        if (!::content.isInitialized) return
        render()
    }
}
