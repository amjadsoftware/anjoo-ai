package com.anjoo.assistant

import org.json.JSONObject
import java.util.Locale

/**
 * Offline-first software-engineering intelligence for Code Studio.
 * These checks are deliberately static: they never claim that code compiled, ran, or passed tests.
 */
object Engineering {
    enum class Level(val rank: Int) { BLOCKER(4), HIGH(3), REVIEW(2), INFO(1) }

    data class Finding(
        val level: Level,
        val code: String,
        val path: String,
        val line: Int,
        val title: String,
        val detail: String,
        val recommendation: String
    )

    private val codeExtensions = setOf(
        "kt", "kts", "java", "py", "js", "mjs", "cjs", "jsx", "ts", "tsx", "html", "htm", "css", "scss",
        "go", "rs", "php", "dart", "swift", "c", "cc", "cpp", "h", "hpp", "cs", "rb", "sh", "sql", "xml", "gradle", "toml", "yaml", "yml", "json"
    )

    private val credentialAssignment = Regex(
        "(?i)\\b(?:api[_-]?key|client[_-]?secret|access[_-]?token|auth[_-]?token|password|passwd|private[_-]?key)\\b\\s*[:=]\\s*[\"']([^\"'\\\\]{12,})[\"']"
    )
    private val placeholderValue = Regex("(?i)(your[_ -]?|change[_ -]?me|example|sample|placeholder|dummy|test[_ -]?key|xxxx|xxxxx|\\$\\{|<[^>]+>)")
    private val privateKeyMarker = Regex("-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")
    private val hardcodedTokenPatterns = listOf(
        Regex("\\bsk-[A-Za-z0-9_-]{20,}\\b"),
        Regex("\\bgh[pousr]_[A-Za-z0-9]{20,}\\b"),
        Regex("\\bAIza[0-9A-Za-z_-]{30,}\\b"),
        Regex("\\bxox[baprs]-[A-Za-z0-9-]{20,}\\b")
    )

    fun findings(files: Map<String, String>): List<Finding> {
        val out = ArrayList<Finding>()
        val sorted = files.toSortedMap()

        for ((path, source) in sorted) {
            val lowerPath = path.lowercase(Locale.ROOT)
            val ext = lowerPath.substringAfterLast('.', "")
            if (lowerPath == ".env" || lowerPath.endsWith("/.env")) {
                out.add(Finding(Level.HIGH, "ENV_FILE_INCLUDED", path, 1,
                    "A live environment file is inside the project", "An actual .env file may contain credentials and should not be shipped in source archives.",
                    "Remove the live .env file from the project, rotate any exposed credentials, and keep only a sanitized .env.example."))
            }
            if (ext !in codeExtensions || lowerPath.endsWith(".example") || lowerPath.contains("/docs/") || lowerPath.startsWith("docs/")) continue

            val lines = source.lines()
            for ((index, raw) in lines.withIndex()) {
                val line = raw.trim()
                if (line.isEmpty()) continue
                val number = index + 1
                if (privateKeyMarker.containsMatchIn(line)) {
                    out.add(Finding(Level.BLOCKER, "PRIVATE_KEY_MATERIAL", path, number,
                        "Private key material appears in source", "A private-key header is present. The key content is intentionally not reproduced.",
                        "Remove the key, rotate/revoke it immediately, and load credentials from a secure server-side secret store."))
                }
                val assigned = credentialAssignment.find(line)?.groupValues?.getOrNull(1)
                val tokenLike = hardcodedTokenPatterns.any { it.containsMatchIn(line) }
                if ((assigned != null && !placeholderValue.containsMatchIn(assigned)) || tokenLike) {
                    out.add(Finding(Level.HIGH, "POSSIBLE_HARDCODED_SECRET", path, number,
                        "Possible hard-coded credential", "A credential-like value is embedded in source (value redacted). This is a static heuristic and may need manual review.",
                        "Move the value to a secure secret store or environment configuration; rotate it if it was ever committed."))
                }

                if (ext in setOf("js", "mjs", "cjs", "jsx", "ts", "tsx", "html")) {
                    if (Regex("\\beval\\s*\\(").containsMatchIn(line) || Regex("\\bnew\\s+Function\\s*\\(").containsMatchIn(line)) {
                        out.add(Finding(Level.HIGH, "DYNAMIC_CODE_EXECUTION", path, number,
                            "Dynamic code execution detected", "eval() or the Function constructor can execute constructed strings and increases injection risk.",
                            "Prefer explicit functions and safe data parsing. If unavoidable, strictly isolate and validate the input."))
                    }
                    if (Regex("\\.innerHTML\\s*=").containsMatchIn(line) || Regex("document\\.write\\s*\\(").containsMatchIn(line)) {
                        out.add(Finding(Level.REVIEW, "UNSAFE_DOM_SINK", path, number,
                            "Potentially unsafe DOM insertion", "innerHTML/document.write can interpret untrusted strings as markup; this is not automatically exploitable.",
                            "Use textContent or DOM node creation for untrusted text; sanitize HTML with a trusted sanitizer when HTML is required."))
                    }
                    if (Regex("(?i)https?://").containsMatchIn(line) && Regex("(?i)http://").containsMatchIn(line) &&
                        !Regex("(?i)(localhost|127\\.0\\.0\\.1|0\\.0\\.0\\.0)").containsMatchIn(line)) {
                        out.add(Finding(Level.REVIEW, "CLEARTEXT_HTTP_URL", path, number,
                            "Non-local cleartext HTTP URL", "An HTTP URL may expose data in transit or cause mixed-content problems.",
                            "Use HTTPS where the service supports it; retain HTTP only for a documented local or development endpoint."))
                    }
                    if (Regex("(?i)Access-Control-Allow-Origin\\s*['\"]?\\s*:\\s*['\"]?\\*").containsMatchIn(line) ||
                        Regex("(?i)allow-origin\\s*[:=]\\s*['\"]\\*['\"]").containsMatchIn(line)) {
                        out.add(Finding(Level.REVIEW, "WILDCARD_CORS", path, number,
                            "Wildcard CORS policy", "A wildcard origin policy may be unsafe when the API exposes private or authenticated data.",
                            "Restrict allowed origins to the actual application domains and review credential handling."))
                    }
                    if (Regex("(?i)dangerouslySetInnerHTML").containsMatchIn(line)) {
                        out.add(Finding(Level.REVIEW, "REACT_RAW_HTML", path, number,
                            "Raw HTML rendering sink", "dangerouslySetInnerHTML bypasses React's normal text escaping.",
                            "Render plain text by default and sanitize trusted HTML before inserting it."))
                    }
                }

                if (ext in setOf("kt", "kts", "java", "xml")) {
                    if (Regex("(?i)usesCleartextTraffic\\s*=\\s*['\"]true['\"]").containsMatchIn(line)) {
                        out.add(Finding(Level.REVIEW, "ANDROID_CLEARTEXT_ENABLED", path, number,
                            "Android cleartext traffic is enabled", "The application may permit HTTP traffic. Confirm that this is required.",
                            "Disable cleartext traffic for production and add narrowly scoped network security exceptions only when necessary."))
                    }
                    if (Regex("setJavaScriptEnabled\\s*\\(\\s*true\\s*\\)").containsMatchIn(line)) {
                        out.add(Finding(Level.INFO, "WEBVIEW_JAVASCRIPT", path, number,
                            "WebView JavaScript is enabled", "This is common for interactive previews, but unsafe if untrusted pages or bridges are loaded.",
                            "Restrict WebView navigation, avoid exposing privileged JavaScript bridges, and load only trusted local content."))
                    }
                }

                if (ext == "py" && Regex("(?i)subprocess\\.(?:run|Popen|call|check_output)\\s*\\(.*shell\\s*=\\s*True").containsMatchIn(line)) {
                    out.add(Finding(Level.REVIEW, "PYTHON_SHELL_TRUE", path, number,
                        "Python subprocess uses shell=True", "Shell command construction can become command injection when arguments contain untrusted data.",
                        "Pass an argument list with shell=False and validate each external input."))
                }
                if (ext in setOf("js", "mjs", "cjs", "ts", "tsx") &&
                    Regex("(?:SELECT|INSERT|UPDATE|DELETE)\\b.*(?:\\+|\\$\\{)", RegexOption.IGNORE_CASE).containsMatchIn(line)) {
                    out.add(Finding(Level.REVIEW, "SQL_STRING_CONCATENATION", path, number,
                        "Possible SQL built with string concatenation", "Dynamic SQL text can permit injection when user-controlled values are concatenated.",
                        "Use prepared statements or parameterized query APIs."))
                }
            }
        }

        // A .gitignore should protect secrets and generated build output before a repository is pushed.
        val ignore = sorted.entries.firstOrNull { it.key.substringAfterLast('/') == ".gitignore" }?.value.orEmpty()
        if (ignore.isNotEmpty() && !Regex("(?m)^\\s*\\.env(?:\\s|$)").containsMatchIn(ignore)) {
            out.add(Finding(Level.REVIEW, "GITIGNORE_ENV", ".gitignore", 1,
                ".env is not clearly ignored", "The project's .gitignore does not include a direct .env ignore rule.",
                "Add .env and other local secret files to .gitignore; keep .env.example sanitized and safe to commit."))
        }
        return out.distinctBy { "${it.code}:${it.path}:${it.line}" }.sortedWith(compareByDescending<Finding> { it.level.rank }.thenBy { it.path }.thenBy { it.line })
    }

    fun report(project: String, files: Map<String, String>, action: String): String {
        if (files.isEmpty()) return "Project '$project' mein koi readable text source file nahi mili."
        return when (action.trim().lowercase(Locale.ROOT).replace('-', '_').replace(' ', '_')) {
            "security", "security_review" -> securityReport(project, files)
            "dependencies", "deps", "dependency_inventory" -> dependenciesReport(project, files)
            "architecture", "architecture_map" -> architectureReport(project, files)
            "metrics", "stats", "code_metrics" -> metricsReport(project, files)
            "release", "release_check", "release_readiness" -> releaseReport(project, files)
            "quality", "quality_gate", "audit", "full", "overview" -> qualityReport(project, files)
            else -> "Action chunein: quality_gate, security, dependencies, architecture, metrics, release_check."
        }
    }

    private fun qualityReport(project: String, files: Map<String, String>): String {
        val findings = findings(files)
        val lint = Coder.lint(files).trim()
        val blocker = findings.count { it.level == Level.BLOCKER }
        val high = findings.count { it.level == Level.HIGH }
        val review = findings.count { it.level == Level.REVIEW }
        val info = findings.count { it.level == Level.INFO }
        val status = when {
            blocker > 0 || high > 0 -> "BLOCKED — security issue(s) need attention"
            findings.isNotEmpty() || lint.isNotEmpty() -> "REVIEW — inspect findings before release"
            else -> "STATIC CHECKS CLEAN — runtime/build tests still required"
        }
        return buildString {
            append("ENGINEERING QUALITY GATE: ").append(project).append('\n')
            append("STATUS: ").append(status).append('\n')
            append("Files: ").append(files.size).append(" · Source lines: ").append(sourceLines(files)).append('\n')
            append("Findings: ").append(blocker).append(" blocker · ").append(high).append(" high · ").append(review).append(" review · ").append(info).append(" info\n")
            append("\nSECURITY / ENGINEERING FINDINGS\n")
            append(renderFindings(findings, 80).ifBlank { "No findings from the enabled static security heuristics." })
            append("\n\nEXISTING CODE STUDIO STATIC LINT\n")
            append(lint.ifBlank { "No issues detected by the built-in structural lint." })
            append("\n\nNOT VERIFIED BY THIS REPORT\n")
            append("This is static analysis only. It does not compile native projects, contact vulnerability databases, run all test suites, or prove production security. Use project_check action=run/test for supported actual execution, and run the target platform's native build/CI before release.")
        }
    }

    private fun securityReport(project: String, files: Map<String, String>): String {
        val list = findings(files)
        return buildString {
            append("STATIC SECURITY REVIEW: ").append(project).append('\n')
            append("Findings: ").append(list.size).append(" (BLOCKER ").append(list.count { it.level == Level.BLOCKER })
                .append(", HIGH ").append(list.count { it.level == Level.HIGH }).append(", REVIEW ").append(list.count { it.level == Level.REVIEW })
                .append(", INFO ").append(list.count { it.level == Level.INFO }).append(")\n\n")
            append(renderFindings(list, 100).ifBlank { "No findings from the enabled static security heuristics." })
            append("\n\nLimitations: heuristic scan only; false positives and missed issues are possible. No dependency CVE database or live penetration test was used. Secret values are never included in this report.")
        }
    }

    private fun renderFindings(list: List<Finding>, limit: Int): String = if (list.isEmpty()) "" else buildString {
        for (f in list.take(limit)) {
            append('[').append(f.level.name).append("] ").append(f.code).append(" — ").append(f.title).append('\n')
            append("  ").append(f.path).append(if (f.line > 0) ":" + f.line else "").append("\n")
            append("  ").append(f.detail).append('\n')
            append("  Fix: ").append(f.recommendation).append("\n\n")
        }
        if (list.size > limit) append("... ").append(list.size - limit).append(" additional findings omitted.\n")
    }.trim()

    private fun dependenciesReport(project: String, files: Map<String, String>): String {
        val entries = ArrayList<Pair<String, String>>()
        val manifests = ArrayList<String>()
        val lockFiles = ArrayList<String>()
        for ((path, text) in files.toSortedMap()) {
            val name = path.substringAfterLast('/').lowercase(Locale.ROOT)
            when (name) {
                "package.json" -> {
                    manifests.add(path)
                    try {
                        val root = JSONObject(text)
                        for (section in listOf("dependencies", "devDependencies", "peerDependencies", "optionalDependencies")) {
                            val deps = root.optJSONObject(section) ?: continue
                            for (key in deps.keys()) entries.add("npm/$section" to (key + " @ " + deps.optString(key)))
                        }
                    } catch (_: Exception) { entries.add("ERROR" to "$path could not be parsed as JSON") }
                }
                "requirements.txt" -> {
                    manifests.add(path)
                    text.lines().map { it.substringBefore('#').trim() }.filter { it.isNotEmpty() && !it.startsWith("-") }.forEach { entries.add("pip" to it) }
                }
                "pyproject.toml" -> {
                    manifests.add(path)
                    text.lines().map { it.trim() }.filter { it.startsWith('"') && it.contains("=") || it.startsWith("'") && it.contains("=") }
                        .forEach { entries.add("pyproject (raw)" to it.take(180)) }
                }
                "cargo.toml" -> {
                    manifests.add(path)
                    var inDeps = false
                    for (line in text.lines()) {
                        val t = line.trim()
                        if (t.startsWith("[")) inDeps = t.startsWith("[dependencies") || t.startsWith("[dev-dependencies") || t.startsWith("[build-dependencies")
                        else if (inDeps && t.contains('=')) entries.add("cargo" to t.take(180))
                    }
                }
                "go.mod" -> {
                    manifests.add(path)
                    text.lines().map { it.trim() }.filter { it.startsWith("require ") || it.matches(Regex("^[A-Za-z0-9._/-]+\\s+v[^\\s]+.*")) }
                        .forEach { entries.add("go" to it.take(180)) }
                }
                "pubspec.yaml" -> {
                    manifests.add(path)
                    var section = ""
                    for (line in text.lines()) {
                        if (!line.startsWith(" ") && line.trimEnd().endsWith(':')) section = line.trim().removeSuffix(":")
                        else if (section in setOf("dependencies", "dev_dependencies") && line.startsWith("  ") && line.contains(':')) entries.add("flutter/$section" to line.trim().take(180))
                    }
                }
                "pom.xml" -> {
                    manifests.add(path)
                    val matches = Regex("(?s)<dependency>\\s*<groupId>(.*?)</groupId>\\s*<artifactId>(.*?)</artifactId>(?:\\s*<version>(.*?)</version>)?").findAll(text)
                    matches.forEach { entries.add("maven" to (it.groupValues[1] + ":" + it.groupValues[2] + " : " + it.groupValues[3]).trim()) }
                }
                "build.gradle", "build.gradle.kts" -> {
                    manifests.add(path)
                    Regex("(?m)^\\s*(?:implementation|api|compileOnly|runtimeOnly|testImplementation|androidTestImplementation)\\s*\\(?[\"']([^\"']+)[\"']\\)?")
                        .findAll(text).forEach { entries.add("gradle" to it.groupValues[1]) }
                }
                "package-lock.json", "npm-shrinkwrap.json", "pnpm-lock.yaml", "yarn.lock", "poetry.lock", "pipfile.lock", "cargo.lock", "go.sum", "pubspec.lock", "composer.lock" -> lockFiles.add(path)
            }
        }
        return buildString {
            append("DEPENDENCY INVENTORY: ").append(project).append('\n')
            append("Manifest files: ").append(manifests.size).append(" · Lockfiles: ").append(lockFiles.size).append(" · Parsed/raw entries: ").append(entries.size).append("\n\n")
            if (manifests.isEmpty()) append("No supported dependency manifest detected.\n")
            for (p in manifests) append("MANIFEST: ").append(p).append('\n')
            append("\nDEPENDENCIES\n")
            if (entries.isEmpty()) append("No dependency entries were parsed. Check the manifest syntax or ecosystem format.\n")
            else for ((ecosystem, dep) in entries.take(250)) append("- [").append(ecosystem).append("] ").append(dep).append('\n')
            if (entries.size > 250) append("... ").append(entries.size - 250).append(" more entries omitted.\n")
            append("\nLOCKFILES\n").append(if (lockFiles.isEmpty()) "No recognized lockfile detected." else lockFiles.joinToString("\n"))
            append("\n\nSecurity limitation: versions are inventoried from project files only. No live package registry or CVE advisory database was queried; this is not a vulnerability clearance.")
        }
    }

    private fun architectureReport(project: String, files: Map<String, String>): String {
        val byExt = files.keys.groupingBy { it.substringAfterLast('.', "[no extension]").lowercase(Locale.ROOT) }.eachCount().toSortedMap()
        val roots = files.keys.map { it.substringBefore('/') }.distinct().sorted()
        val candidates = files.keys.filter { path ->
            val base = path.substringAfterLast('/').lowercase(Locale.ROOT)
            base in setOf("main.py", "app.py", "manage.py", "index.js", "server.js", "main.kt", "main.java", "main.dart", "main.go", "main.rs", "index.html", "app.html") ||
                base.endsWith(".xcodeproj") || base == "androidmanifest.xml"
        }
        val dirs = files.keys.mapNotNull { p -> p.substringBeforeLast('/', "").takeIf { it.isNotBlank() } }.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(25)
        val dependencyHints = ArrayList<String>()
        val importPatterns = listOf(
            "\\bfrom\\s+([A-Za-z_][\\w.]*)\\s+import\\b" to "Python",
            "\\bimport\\s+([A-Za-z_][\\w.]*)" to "Python/Java/Kotlin",
            "(?:from\\s+|require\\s*\\()\\s*[\"'](\\.{1,2}/[^\"']+)[\"']" to "JS/TS relative"
        )
        for ((path, source) in files) {
            for ((pattern, label) in importPatterns) {
                val re = Regex(pattern)
                for (m in re.findAll(source).take(20)) dependencyHints.add("$label: ${m.groupValues[1]}  ←  $path")
            }
        }
        return buildString {
            append("ARCHITECTURE MAP: ").append(project).append('\n')
            append("Readable files: ").append(files.size).append(" · Top-level roots: ").append(roots.size).append("\n")
            append("\nLANGUAGES / FILE TYPES\n")
            for ((ext, count) in byExt) append("- .").append(ext).append(": ").append(count).append(" file(s)\n")
            append("\nTOP-LEVEL PATHS\n").append(roots.joinToString("\n").ifBlank { "(root files only)" })
            append("\n\nBUSY MODULE DIRECTORIES\n")
            append(if (dirs.isEmpty()) "(no nested directories)" else dirs.joinToString("\n") { "- ${it.key}/ — ${it.value} file(s)" })
            append("\n\nPOSSIBLE ENTRY POINTS\n")
            append(if (candidates.isEmpty()) "No common entry-point filename detected; inspect the build manifest." else candidates.joinToString("\n"))
            append("\n\nIMPORT / MODULE HINTS\n")
            append(if (dependencyHints.isEmpty()) "No common static import patterns detected." else dependencyHints.distinct().take(80).joinToString("\n"))
            append("\n\nNote: this is a filename/import heuristic map, not a compiler-generated dependency graph. Dynamic imports, reflection and framework wiring may not appear.")
        }
    }

    private fun metricsReport(project: String, files: Map<String, String>): String {
        val rows = files.map { (path, text) ->
            val lines = text.lines()
            val code = lines.count { it.isNotBlank() }
            Triple(path, lines.size, code)
        }.sortedByDescending { it.second }
        val todo = files.entries.sumOf { (_, source) -> Regex("(?i)\\b(TODO|FIXME|HACK|XXX)\\b").findAll(source).count() }
        val testFiles = files.keys.filter { path ->
            val n = path.substringAfterLast('/').lowercase(Locale.ROOT)
            n.startsWith("test_") || n.endsWith("_test.py") || n.endsWith(".test.js") || n.endsWith(".spec.js") || n.endsWith(".test.ts") || n.endsWith(".spec.ts") || n.contains("/tests/") || n.contains("/test/")
        }
        val lang = files.keys.groupingBy { languageName(it) }.eachCount().entries.sortedByDescending { it.value }
        return buildString {
            append("CODE METRICS: ").append(project).append('\n')
            append("Files: ").append(files.size).append(" · Lines (incl. blanks): ").append(rows.sumOf { it.second })
                .append(" · Non-empty lines: ").append(rows.sumOf { it.third }).append('\n')
            append("TODO/FIXME/HACK/XXX markers: ").append(todo).append(" · Test-looking files: ").append(testFiles.size).append("\n\n")
            append("LANGUAGE MIX\n").append(lang.joinToString("\n") { "- ${it.key}: ${it.value} file(s)" })
            append("\n\nLARGEST FILES\n")
            append(rows.take(15).joinToString("\n") { "- ${it.first}: ${it.second} lines (${it.third} non-empty)" })
            append("\n\nTEST FILE CANDIDATES\n").append(if (testFiles.isEmpty()) "No test-looking files detected." else testFiles.joinToString("\n"))
        }
    }

    private fun releaseReport(project: String, files: Map<String, String>): String {
        val names = files.keys.map { it.lowercase(Locale.ROOT) }
        val notes = ArrayList<String>()
        fun check(ok: Boolean, yes: String, no: String) { notes.add((if (ok) "[PRESENT] " else "[MISSING] ") + (if (ok) yes else no)) }
        check(names.any { it.substringAfterLast('/') in setOf("readme.md", "readme.txt", "readme") }, "README / run instructions", "README with install, run, test and configuration instructions")
        check(names.any { it.substringAfterLast('/') in setOf("license", "license.md", "license.txt") }, "License file", "License file (when the project will be distributed)")
        check(names.any { it.contains(".github/workflows/") || it.contains(".gitlab-ci") || it.substringAfterLast('/') in setOf("azure-pipelines.yml", "jenkinsfile") }, "CI workflow", "Automated CI workflow")
        check(names.any { it.substringAfterLast('/') == ".gitignore" }, ".gitignore", ".gitignore for build output, local settings and secrets")
        check(names.any { it.substringAfterLast('/') in setOf(".env.example", ".env.sample", "example.env") }, "Sanitized environment template", ".env.example listing required configuration (without real secrets)")
        check(names.any { p -> p.substringAfterLast('/').let { it.startsWith("test_") || it.endsWith(".test.js") || it.endsWith(".spec.js") || it.endsWith(".test.ts") || it.endsWith(".spec.ts") || it.endsWith("_test.py") } || p.contains("/tests/") }, "Automated test files", "Automated tests for core behaviour and edge cases")
        check(names.any { it.substringAfterLast('/') in setOf("package-lock.json", "pnpm-lock.yaml", "yarn.lock", "poetry.lock", "pipfile.lock", "cargo.lock", "go.sum", "pubspec.lock", "composer.lock") }, "Dependency lockfile", "Lockfile for reproducible dependency resolution")
        val findings = findings(files)
        check(findings.none { it.level == Level.BLOCKER || it.level == Level.HIGH }, "No blocker/high static security findings", "Resolve blocker/high static security findings")
        return buildString {
            append("RELEASE READINESS CHECKLIST: ").append(project).append('\n')
            append(notes.joinToString("\n"))
            append("\n\nStatic security findings: ").append(findings.size).append(" total; ")
                .append(findings.count { it.level == Level.BLOCKER || it.level == Level.HIGH }).append(" blocker/high.\n")
            append("\nThis checklist inspects project files only. It cannot validate signing keys, production secrets, store policy, runtime behaviour, app-store compliance, live services or a successful platform build. Complete the actual target-platform build and tests before release.")
        }
    }

    private fun sourceLines(files: Map<String, String>): Int = files.values.sumOf { it.lines().count(String::isNotBlank) }

    private fun languageName(path: String): String = when (path.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
        "kt", "kts" -> "Kotlin"
        "java" -> "Java"
        "py" -> "Python"
        "js", "mjs", "cjs", "jsx" -> "JavaScript"
        "ts", "tsx" -> "TypeScript"
        "html", "htm" -> "HTML"
        "css", "scss" -> "CSS"
        "go" -> "Go"
        "rs" -> "Rust"
        "php" -> "PHP"
        "dart" -> "Dart"
        "swift" -> "Swift"
        "c", "cc", "cpp", "h", "hpp" -> "C/C++"
        "cs" -> "C#"
        "rb" -> "Ruby"
        "sh" -> "Shell"
        "sql" -> "SQL"
        "json" -> "JSON"
        "xml" -> "XML"
        "gradle" -> "Gradle"
        else -> "Other"
    }
}
