package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ModelRegistryTest {
    private fun raw(model: String, vision: Boolean = false, tools: Boolean = true, code: Int = 5, think: Int = 5,
                    verified: Set<String> = emptySet(), ok: Int = 0, listed: Boolean? = null, company: String = "Acme") =
        ModelRegistry.Raw("acme", company, model, vision, false, tools,
            mapOf("code" to code, "think" to think, "write" to 5), verified, ok, 0, 0L, listed)

    @Test fun observedAbilityIsVerifiedAndGuessesStayGuesses() {
        val i = ModelRegistry.info(raw("big-1", vision = true, code = 9, verified = setOf("code")))
        assertEquals(ModelRegistry.Level.VERIFIED, i.level("code"))
        assertEquals(ModelRegistry.Level.LIKELY, i.level("vision"))
        assertEquals(ModelRegistry.Level.UNKNOWN, i.level("think"))
        assertEquals(ModelRegistry.Level.UNLIKELY, ModelRegistry.info(raw("tiny", vision = false)).level("vision"))
    }

    @Test fun weakNameScoresAreUnlikelyNotUnknown() {
        assertEquals(ModelRegistry.Level.UNLIKELY, ModelRegistry.info(raw("mini", think = 3)).level("think"))
    }

    @Test fun filterRemovesModelsThatProbablyCannotDoTheJob() {
        val a = ModelRegistry.info(raw("a-vision", vision = true))
        val b = ModelRegistry.info(raw("b-text", vision = false))
        val r = ModelRegistry.filter(listOf(a, b), "", setOf("vision"), false)
        assertEquals(listOf("a-vision"), r.map { it.raw.model })
    }

    @Test fun verifiedOnlyNeedsRealObservation() {
        val a = ModelRegistry.info(raw("a", code = 9, verified = setOf("code")))
        val b = ModelRegistry.info(raw("b", code = 9))
        assertEquals(listOf("a"), ModelRegistry.filter(listOf(a, b), "", setOf("code"), true).map { it.raw.model })
        assertEquals(listOf("a"), ModelRegistry.filter(listOf(a, b), "", emptySet(), true).map { it.raw.model })
        assertEquals(2, ModelRegistry.filter(listOf(a, b), "", setOf("code"), false).size)
    }

    @Test fun verifiedModelsComeFirstAndSearchMatchesNameOrCompany() {
        val a = ModelRegistry.info(raw("zeta", code = 9))
        val b = ModelRegistry.info(raw("alpha", code = 9, verified = setOf("code")))
        assertEquals(listOf("alpha", "zeta"), ModelRegistry.filter(listOf(a, b), "", setOf("code"), false).map { it.raw.model })
        assertEquals(listOf("zeta"), ModelRegistry.filter(listOf(a, b), "ZET", emptySet(), false).map { it.raw.model })
        assertEquals(2, ModelRegistry.filter(listOf(a, b), "acme", emptySet(), false).size)
    }

    @Test fun lineNeverClaimsContextOrPriceAndSaysWhenUntried() {
        val l = ModelRegistry.line(ModelRegistry.info(raw("m1", listed = true)))
        assertTrue(l.contains("context aur price: maloom nahi"))
        assertTrue(l.contains("abhi tak is app mein use nahi hua"))
        assertTrue(l.contains("company ki list mein: haan"))
        assertFalse(l.contains("$"))
    }

    @Test fun taskSuccessMapsToTheCapabilityItProves() {
        assertEquals("tools", ModelRegistry.capForTask("PHONE"))
        assertEquals("vision", ModelRegistry.capForTask("VISION"))
        assertEquals("code", ModelRegistry.capForTask("CODE"))
        assertEquals("chat", ModelRegistry.capForTask("CHAT"))
    }

    @Test fun registryIncludesPremiumModelCapabilityCategories() {
        val keys = ModelRegistry.CAPS.map { it.key }.toSet()
        assertTrue(keys.containsAll(setOf("chat", "think", "code", "vision", "pdf", "imagegen", "audio", "speech", "video", "translate", "embedding", "rerank", "math", "longcontext", "moderation")))
    }

    @Test fun modelNameHintsNeverPretendToBeVerified() {
        val image = ModelRegistry.info(raw("dall-e-3"))
        assertEquals(ModelRegistry.Level.LIKELY, image.level("imagegen"))
        assertFalse(image.level("imagegen") == ModelRegistry.Level.VERIFIED)
        val embedding = ModelRegistry.info(raw("text-embedding-3-large"))
        assertEquals(ModelRegistry.Level.LIKELY, embedding.level("embedding"))
    }

    @Test fun extendedTaskNamesMapToTheirCapability() {
        assertEquals("imagegen", ModelRegistry.capForTask("IMAGEGEN"))
        assertEquals("embedding", ModelRegistry.capForTask("EMBEDDING"))
        assertEquals("moderation", ModelRegistry.capForTask("MODERATION"))
    }
}
