package com.anjoo.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Keeps Anjoo AI listening in the background. Say "Anjoo" followed by a command.
 * Call and SMS ask for a spoken "haan" first.
 */
class VoiceService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_STOP = "com.anjoo.assistant.STOP"
        const val ACTION_LISTEN = "com.anjoo.assistant.LISTEN"
        private const val CHANNEL = "anjoo_voice"
        private const val NOTIF_ID = 7

        @Volatile
        var running = false

        @Volatile
        var inst: VoiceService? = null

        /** Read a line out loud (for example a new chat message), without the mic hearing it. */
        fun announce(text: String) { inst?.announce(text) }

        private val WAKE = listOf("anjoo", "anju", "anjo", "انجو", "آنجو", "انجُو")
        private val YES = setOf(
            "haan", "han", "haa", "ha", "yes", "yeah", "ji", "jee", "ok", "okay", "theek", "thik",
            "bilkul", "kardo", "karo", "ہاں", "جی", "ٹھیک", "بالکل", "کردو", "کرو"
        )
        private val STOPW = listOf("ruko", "rukiye", "ruk jao", "bas karo", "bas kar", "chup", "khamosh", "stop", "band karo",
            "رکو", "رکیے", "رک جاؤ", "بس کرو", "بس کر", "چپ", "خاموش", "بند کرو")
        private val NO = setOf("nahi", "nahin", "na", "no", "mat", "nope", "نہیں", "نہ", "مت", "نا")
    }

    private enum class Mode { LISTEN, CONFIRM, BUSY, SPEAKING }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    @Volatile private var liveSession: GeminiLiveSession? = null
    @Volatile private var liveSessionToken: Any? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var urduOk = false
    private lateinit var agent: Agent
    private lateinit var actions: Actions
    private var overlay: View? = null

    @Volatile private var mode = Mode.LISTEN
    private var awaitingCommand = false
    private var stopped = false
    private var speakSeq = 0
    private var lastStart = 0L
    private var lastDiag = 0L
    private val pendingAnn = ArrayList<String>()
    private var ear: Ear? = null
    private var ignoreUntil = 0L
    private var lastBarge = 0L
    @Volatile private var queuedCmd: String? = null
    @Volatile private var dropReply = false
    private var lastSttDiag = 0L
    private var speakingId = ""
    private var lastPartial = 0L
    @Volatile private var lastLiveStatusAt = 0L
    private var partialShown = false
    private var bargeCaptureActive = false
    private var bargeStopOnly = false
    private val IDLE_TEXT = "Sun raha hoon. Bolein: Anjoo, phir hukm."
    private var bubble: BuddyView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var confirmLatch: CountDownLatch? = null
    @Volatile private var confirmAnswer = false

    // ---------- lifecycle ----------

    override fun onCreate() {
        super.onCreate()
        running = true
        inst = this
        createChannel()
        try {
            val n = notification("Sun raha hoon. Bolein: Anjoo, phir hukm.")
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Background mode shuru nahi ho saka (mic ya notification ki ijazat check karein).", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        addOverlay()
        addBubble()
        actions = Actions(this) { askYesNo(it) }
        agent = Agent(this, actions)
        tts = TextToSpeech(this, this)
        // Move older default Google installs to the requested native Live experience once.
        val voicePrefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        if (!voicePrefs.getBoolean("liveVoiceMigrationDone", false)) {
            if (voicePrefs.getString("engine", null) == "google") voicePrefs.edit().putString("engine", "live").apply()
            voicePrefs.edit().putBoolean("liveVoiceMigrationDone", true).apply()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_LISTEN -> main.post {
                awaitingCommand = true
                if (mode == Mode.LISTEN) startListening(0)
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopped = true
        running = false
        inst = null
        removeBubble()
        main.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
        GeminiVoice.stop()
        VoiceKit.focusOff(this)
        ear?.stop()
        liveSession?.close()
        liveSession = null
        liveSessionToken = null
        tts?.shutdown()
        confirmLatch?.countDown()
        removeOverlay()
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        val t = tts
        if (status == TextToSpeech.SUCCESS && t != null) {
            ttsReady = true
            urduOk = t.isLanguageAvailable(Locale("ur", "PK")) >= TextToSpeech.LANG_AVAILABLE
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId?.contains('#') == true) return   // a middle part of a longer reply
                    main.post { onSpeakDone(utteranceId ?: "") }
                }
                override fun onError(utteranceId: String?) {
                    if (utteranceId?.contains('#') == true) return
                    main.post { onSpeakDone(utteranceId ?: "") }
                }
            })
        }
        agent.urduScriptVoice = urduOk
        if (!useEar() && !useLive() && !SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Is phone par awaaz pehchaan maujood nahi. Google app install karein.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        startListening(500)
        main.postDelayed(watchdog, 15000)
    }

    // ---------- keep the recogniser alive ----------

    private val watchdog = object : Runnable {
        override fun run() {
            if (stopped) return
            if (useLive()) { if (liveSession == null) startLiveSession() }
            else if (useEar()) ensureEar()
            else if (mode == Mode.LISTEN && SystemClock.elapsedRealtime() - lastStart > 40000) startListening(0)
            main.postDelayed(this, 15000)
        }
    }

    private fun engine() = getSharedPreferences("anjoo", MODE_PRIVATE).getString("engine", "live") ?: "live"
    private fun useEar() = engine() == "ear"
    private fun useLive() = engine() == "live"
    private fun resumeLiveMic(delayMs: Long = 180L) {
        if (useLive()) main.postDelayed({ if (!stopped) liveSession?.resumeMicrophone() }, delayMs)
    }

    private fun startListening(delayMs: Long) {
        if (stopped) return
        if (useLive() && mode != Mode.CONFIRM) {
            main.postDelayed({ startLiveSession() }, delayMs)
            return
        }
        if (useEar()) {
            main.postDelayed({ ensureEar() }, delayMs)
            return
        }
        main.postDelayed({ doStart() }, delayMs)
    }

    private fun startLiveSession() {
        if (stopped || !useLive() || liveSession != null) return
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        val key = Providers.geminiKey(prefs)
        if (key.isBlank()) {
            Toast.makeText(this, "Gemini Live ke liye Settings mein Gemini API key chahiye. Google speech par switch kar raha hoon.", Toast.LENGTH_LONG).show()
            prefs.edit().putString("engine", "google").apply()
            startListening(200)
            return
        }
        val model = prefs.getString("liveModel", "gemini-3.8-live") ?: "gemini-3.8-live"
        val wakeRule = if (prefs.getBoolean("wake", false)) "\nWAKE WORD: this user enabled wake-word mode. Do not answer or execute anything until the user says Anjoo (or a clear variant) and gives a command; ignore unrelated nearby speech." else ""
        val sessionToken = Any()
        liveSessionToken = sessionToken
        val session = GeminiLiveSession(key, model, GeminiVoice.voiceFor(this), agent.liveSystemPrompt() + wakeRule, object : GeminiLiveSession.Listener {
            override fun onReady() { main.post { if (!stopped) setStatus("Live sun raha hoon. Boliye.") } }
            override fun onStatus(text: String) {
                main.post {
                    if (stopped) return@post
                    if (text.startsWith("Sun raha hoon:")) {
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastLiveStatusAt < 700) return@post
                        lastLiveStatusAt = now
                    }
                    setStatus(text)
                }
            }
            override fun onUserTranscript(text: String) {
                main.post {
                    if (stopped || text.isBlank()) return@post
                    if (mode == Mode.CONFIRM) {
                        confirmAnswer = isYes(text)
                        confirmLatch?.countDown()
                    } else {
                        Buddy.post(0, text)
                        ChatStore.append(this@VoiceService, 0, text)
                    }
                }
            }
            override fun onAssistantTranscript(text: String) {
                main.post {
                    if (!stopped && text.isNotBlank()) {
                        Buddy.post(1, text)
                        ChatStore.append(this@VoiceService, 1, text)
                    }
                }
            }
            override fun onPlaybackStarted() {
                main.post {
                    if (!stopped) {
                        VoiceKit.focusOn(this@VoiceService)
                        mode = Mode.SPEAKING
                        bubble?.setMood(Mood.HAPPY, 5000)
                    }
                }
            }
            override fun onPlaybackFinished() {
                main.post {
                    VoiceKit.focusOff(this@VoiceService)
                    if (!stopped && mode == Mode.SPEAKING) {
                        mode = Mode.LISTEN
                        setStatus("Live sun raha hoon. Boliye.")
                    }
                }
            }
            override fun onInterrupted() {
                main.post {
                    VoiceKit.focusOff(this@VoiceService)
                    if (!stopped) {
                        mode = Mode.LISTEN
                        setStatus("Ji, sun raha hoon...")
                    }
                }
            }
            override fun onToolCalls(calls: JSONArray) {
                Thread {
                    val responses = JSONArray()
                    for (i in 0 until calls.length()) {
                        val call = calls.optJSONObject(i) ?: continue
                        val name = call.optString("name")
                        val args = call.optJSONObject("args") ?: JSONObject()
                        main.post { if (!stopped) { mode = Mode.BUSY; setStatus("Kaam kar raha hoon: $name") } }
                        val result = try { actions.run(name, args) } catch (e: Exception) { "Kaam nahi ho saka: " + (e.message ?: e.javaClass.simpleName) }
                        val item = JSONObject().put("name", name).put("response", JSONObject().put("result", result))
                        if (call.has("id")) item.put("id", call.optString("id"))
                        responses.put(item)
                    }
                    liveSession?.sendToolResponses(responses)
                }.start()
            }
            override fun onFailure(message: String) {
                main.post {
                    if (stopped || liveSessionToken !== sessionToken) return@post
                    liveSession?.close()
                    liveSession = null
                    liveSessionToken = null
                    val p = getSharedPreferences("anjoo", MODE_PRIVATE)
                    p.edit().putString("engine", "google").apply()
                    Buddy.post(3, "[LIVE] $message — Google speech fallback")
                    Toast.makeText(this@VoiceService, "Live voice connect nahi hui; Google speech par switch kiya. API key, model access aur internet check karein.", Toast.LENGTH_LONG).show()
                    mode = Mode.LISTEN
                    startListening(250)
                }
            }
        })
        liveSession = session
        session.start()
    }

    // ---------- always-open microphone ----------

    private fun ensureEar() {
        if (stopped || ear?.isRunning() == true) return
        ear?.stop()
        ear = Ear({ pcm -> main.post { onUtterance(pcm) } }, { msg ->
            main.post {
                Buddy.post(3, "[MIC] $msg")
                if (!stopped) main.postDelayed({ ensureEar() }, 4000)
            }
        }).also { it.start() }
    }

    private fun onUtterance(pcm: ByteArray) {
        if (stopped) return
        val now = SystemClock.elapsedRealtime()
        when (mode) {
            Mode.BUSY -> transcribeAsync(pcm) { text -> main.post { onBusyText(text) } }
            Mode.SPEAKING -> {
                if (now - lastBarge < 1500) return
                lastBarge = now
                transcribeAsync(pcm) { text -> main.post { onBargeText(text) } }
            }
            else -> {
                if (now < ignoreUntil) return
                val m = mode
                transcribeAsync(pcm) { text -> main.post { onEarText(text, m) } }
            }
        }
    }

    private fun transcribeAsync(pcm: ByteArray, done: (String) -> Unit) {
        Thread {
            val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
            val key = Providers.geminiKey(prefs)
            val model = prefs.getString("sttModel", null) ?: "gemini-3.5-flash-lite"
            val lang = prefs.getString("lang", "ur-PK") ?: "ur-PK"
            val text = try {
                if (key.isEmpty()) "" else Gemini.transcribe(key, model, pcm, lang)
            } catch (e: Exception) {
                val t = SystemClock.elapsedRealtime()
                if (t - lastSttDiag > 15000) {
                    lastSttDiag = t
                    Buddy.post(3, "[MIC] awaaz samajhne mein masla: " + (e.message ?: "").take(80))
                }
                ""
            }
            if (text.isNotBlank()) done(text)
        }.start()
    }

    private fun onEarText(text: String, wasMode: Mode) {
        if (stopped || mode != wasMode) return
        when (wasMode) {
            Mode.CONFIRM -> {
                confirmAnswer = isYes(text)
                confirmLatch?.countDown()
            }
            Mode.LISTEN -> handleHeard(text)
            else -> {}
        }
    }

    /** While Anjoo is talking: saying its name or "ruko/bas" stops it, and anything after the name is a new order. */
    private fun onBargeText(text: String) {
        if (stopped || mode != Mode.SPEAKING || speakingId == "confirm") return
        val lower = text.lowercase(Locale.ROOT)
        val named = WAKE.any { lower.contains(it) }
        val stopWord = STOPW.any { lower.contains(it) }
        if (!named && !stopWord) return
        GeminiVoice.stop()
        try { tts?.stop() } catch (e: Exception) {}
        VoiceKit.focusOff(this)
        speakSeq++
        mode = Mode.LISTEN
        ignoreUntil = SystemClock.elapsedRealtime() + 300
        Buddy.post(3, "[MIC] beech mein rok diya")
        if (named) handleHeard(text)
    }

    private fun startBargeListening(delayMs: Long) {
        if (stopped || useEar() || useLive()) return // Live API handles full-duplex barge-in on its own stream.
        main.postDelayed({ if (!stopped && mode == Mode.SPEAKING) doStart(allowSpeaking = true) }, delayMs)
    }

    private fun doStart(allowSpeaking: Boolean = false) {
        if (stopped || (mode != Mode.LISTEN && mode != Mode.CONFIRM && !(allowSpeaking && mode == Mode.SPEAKING))) return
        try {
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(listener)
            recognizer = r
            val lang0 = getSharedPreferences("anjoo", MODE_PRIVATE).getString("lang", "ur-PK") ?: "ur-PK"
            val lang = if (lang0 == "auto") "ur-PK" else lang0
            val other = if (lang == "en-US") "ur-PK" else "en-US"
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                // also understand the other language, so Urdu and English can be mixed in one sentence
                .putExtra("android.speech.extra.ADDITIONAL_LANGUAGES", arrayOf(other))
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            lastStart = SystemClock.elapsedRealtime()
            r.startListening(i)
        } catch (e: Exception) {
            if (allowSpeaking) startBargeListening(1500) else startListening(3000)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {
            val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim().orEmpty()
            if (p.isBlank()) return
            if (mode == Mode.SPEAKING) {
                val lower = p.lowercase(Locale.ROOT)
                val hasWake = WAKE.any { lower.contains(it) }
                val hasStop = STOPW.any { lower.contains(it) }
                // Explicit barge cues reduce false triggers when the recognizer hears TTS echo.
                if (hasWake || hasStop) {
                    bargeCaptureActive = true
                    bargeStopOnly = hasStop && !hasWake
                    stopSpeakingForBarge()
                }
                return
            }
            if (mode != Mode.LISTEN) return
            val now = SystemClock.elapsedRealtime()
            if (now - lastPartial > 400) {
                lastPartial = now
                partialShown = true
                setStatus("Sun raha hoon: " + p.takeLast(80))
            }
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (stopped) return
            if (partialShown) { partialShown = false; setStatus(IDLE_TEXT) }
            when (mode) {
                Mode.CONFIRM -> {
                    confirmAnswer = false
                    confirmLatch?.countDown()
                }
                Mode.SPEAKING -> {
                    val wait = if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) 180L else 900L
                    startBargeListening(wait)
                }
                Mode.LISTEN -> {
                    if (bargeCaptureActive) { bargeCaptureActive = false; bargeStopOnly = false }
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        stopSelf()
                        return
                    }
                    if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT &&
                        SystemClock.elapsedRealtime() - lastDiag > 15000
                    ) {
                        lastDiag = SystemClock.elapsedRealtime()
                        Buddy.post(3, "[MIC] awaaz pehchaan ka masla (code $error)" +
                            if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                                error == SpeechRecognizer.ERROR_SERVER) " - internet check karein" else "")
                    }
                    val wait = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 150L
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER -> 4000L
                        else -> 1500L
                    }
                    startListening(wait)
                }
                else -> {}
            }
        }

        override fun onResults(results: Bundle?) {
            if (stopped) return
            if (partialShown) { partialShown = false; setStatus(IDLE_TEXT) }
            val text = pickBest(
                results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf(),
                results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
            )
            val fromBarge = bargeCaptureActive
            bargeCaptureActive = false
            val stopOnly = bargeStopOnly && text.trim().split(Regex("\\s+")).size <= 3 && WAKE.none { text.lowercase(Locale.ROOT).contains(it) }
            bargeStopOnly = false
            if (stopOnly) {
                mode = Mode.LISTEN
                setStatus("Ruk gaya. Bolein.")
                startListening(150)
                return
            }
            when (mode) {
                Mode.CONFIRM -> {
                    confirmAnswer = isYes(text)
                    confirmLatch?.countDown()
                }
                Mode.LISTEN -> handleHeard(text, fromBarge)
                Mode.SPEAKING -> {
                    val lower = text.lowercase(Locale.ROOT)
                    val hasWake = WAKE.any { lower.contains(it) }
                    val hasStop = STOPW.any { lower.contains(it) }
                    if (!hasWake && !hasStop) {
                        startBargeListening(150)
                    } else {
                        stopSpeakingForBarge()
                        val stopOnlyResult = hasStop && !hasWake && text.trim().split(Regex("\\s+")).size <= 3
                        if (stopOnlyResult) {
                            setStatus("Ruk gaya. Bolein.")
                            startListening(150)
                        } else handleHeard(text, fromBarge = true)
                    }
                }
                else -> {}
            }
        }
    }

    /** Of the candidate sentences, prefer one that has the wake word, then the most confident one. */
    private fun pickBest(list: List<String>, conf: FloatArray?): String {
        if (list.isEmpty()) return ""
        val hit = list.firstOrNull { c -> val l = c.lowercase(Locale.ROOT); WAKE.any { l.contains(it) } }
        if (hit != null) return hit
        if (conf != null && conf.size == list.size) {
            var bi = 0
            for (i in list.indices) if (conf[i] > conf[bi]) bi = i
            return list[bi]
        }
        return list[0]
    }

    private fun stopSpeakingForBarge() {
        if (mode != Mode.SPEAKING) return
        GeminiVoice.stop()
        try { tts?.stop() } catch (e: Exception) {}
        VoiceKit.focusOff(this)
        speakSeq++
        mode = Mode.LISTEN
        ignoreUntil = SystemClock.elapsedRealtime() + 100
        setStatus("Ji, sun raha hoon...")
    }

    // ---------- what was heard ----------

    private fun handleHeard(text: String, fromBarge: Boolean = false) {
        val heard = text.trim()
        if (heard.isEmpty()) {
            startListening(150)
            return
        }
        val lower = heard.lowercase(Locale.ROOT)
        var found: String? = null
        for (w in WAKE) {
            val i = lower.indexOf(w)
            if (i >= 0) {
                found = heard.substring(i + w.length).trim().trimStart(',', '.', '،', ':', '-', ' ')
                break
            }
        }
        val needWake = getSharedPreferences("anjoo", MODE_PRIVATE).getBoolean("wake", false)
        val command: String = found ?: if (awaitingCommand || !needWake || fromBarge) heard else {
            startListening(150)
            return
        }
        if (command.isBlank()) {
            awaitingCommand = true
            mode = Mode.SPEAKING
            speak("Ji?", "ack")
            return
        }
        awaitingCommand = false
        beep()
        Buddy.post(0, command)
        ChatStore.append(this, 0, command)
        process(command)
    }

    /** A tiny sound the moment a command is understood, so the user knows Anjoo heard it. */
    private fun beep() {
        try {
            val tg = android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 45)
            tg.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 110)
            main.postDelayed({ try { tg.release() } catch (e: Exception) {} }, 400)
        } catch (e: Exception) {}
    }

    private fun process(command: String) {
        mode = Mode.BUSY
        bubble?.setMood(Mood.THINKING, 0)
        try { recognizer?.cancel() } catch (e: Exception) {}
        setStatus("Soch raha hoon...")
        Thread {
            val answer = try {
                agent.ask(command)
            } catch (e: Exception) {
                "Masla aaya. " + (e.message ?: "").take(80)
            }
            main.post { deliver(answer) }
        }.start()
    }

    private fun onBusyText(text: String) {
        if (stopped || mode != Mode.BUSY || text.isBlank()) return
        val lower = text.lowercase(Locale.ROOT)
        if (STOPW.any { lower.contains(it) }) { dropReply = true; queuedCmd = null; return }
        queuedCmd = if (queuedCmd == null) text.trim() else queuedCmd + " " + text.trim()
    }

    private fun deliver(text: String) {
        if (stopped) return
        if (dropReply) {
            dropReply = false
            mode = Mode.LISTEN
            setStatus("Ruk gaya. Bolein.")
            startListening(150)
            return
        }
        val q = queuedCmd
        if (q != null) {
            queuedCmd = null
            Buddy.post(0, q)
            ChatStore.append(this, 0, q)
            process(q)
            return
        }
        setStatus("Sun raha hoon. Bolein: Anjoo, phir hukm.")
        if (text.isBlank()) {
            mode = Mode.LISTEN
            startListening(300)
            return
        }
        mode = Mode.SPEAKING
        Buddy.post(1, text)
        ChatStore.append(this, 1, text)
        bubble?.setMood(Mood.fromText(text) ?: Mood.HAPPY, 6000)
        bubble?.talk(minOf(8000L, text.length * 70L))
        speak(text, "reply")
    }

    // ---------- spoken yes/no for call and SMS ----------

    private fun isYes(text: String): Boolean {
        val words = text.lowercase(Locale.ROOT).split(Regex("[\\s,.!?؟،]+")).filter { it.isNotEmpty() }
        if (words.any { it in NO }) return false
        return words.any { it in YES }
    }

    /** Called from the agent thread: speaks the question, listens once, returns true only on a clear yes. */
    private fun askYesNo(message: String): Boolean {
        liveSession?.pauseMicrophone()
        val latch = CountDownLatch(1)
        confirmLatch = latch
        confirmAnswer = false
        main.post {
            mode = Mode.SPEAKING
            try { recognizer?.cancel() } catch (e: Exception) {}
            speak(Confirm.plain(message).replace('\n', ' ') + ". Haan ya nahi bolein.", "confirm")
        }
        val finished = latch.await(45, TimeUnit.SECONDS)
        main.post {
            try { recognizer?.cancel() } catch (e: Exception) {}
            mode = Mode.BUSY
        }
        resumeLiveMic(250)
        return finished && confirmAnswer
    }

    // ---------- speaking ----------

    private fun speak(text: String, id: String) {
        speakingId = id
        if (useLive()) liveSession?.pauseMicrophone()
        startBargeListening(100)
        if (GeminiVoice.enabled(this) && Providers.geminiKey(getSharedPreferences("anjoo", MODE_PRIVATE)).isNotEmpty()) {
            val seq = ++speakSeq
            main.postDelayed({
                if (seq == speakSeq && mode == Mode.SPEAKING) onSpeakDone(id)
            }, 15000L + text.length * 200L)
            Thread {
                val ok = GeminiVoice.say(this, text)
                main.post {
                    if (stopped) return@post
                    if (ok) { if (seq == speakSeq) onSpeakDone(id) } else systemSpeak(text, id)
                }
            }.start()
            return
        }
        systemSpeak(text, id)
    }

    private fun systemSpeak(text: String, id: String) {
        val t = tts
        if (t == null || !ttsReady) {
            main.post { onSpeakDone(id) }
            return
        }
        val o = Style.officer(this)
        VoiceKit.focusOn(this)
        // each Urdu or English part is spoken with its own voice
        if (!VoiceKit.speak(t, text, id, urduOk, o.pitch, o.rate)) {
            main.post { onSpeakDone(id) }
            return
        }
        // If the speech engine never reports back, do not stay deaf forever.
        val seq = ++speakSeq
        main.postDelayed({
            if (seq == speakSeq && mode == Mode.SPEAKING) onSpeakDone(id)
        }, 8000L + text.length * 150L)
    }

    private fun onSpeakDone(id: String) {
        VoiceKit.focusOff(this)
        if (stopped || mode != Mode.SPEAKING) return
        speakSeq++
        ignoreUntil = SystemClock.elapsedRealtime() + 350
        when (id) {
            "confirm" -> {
                mode = Mode.CONFIRM
                startListening(150)
            }
            "ack" -> {
                mode = Mode.LISTEN
                awaitingCommand = true
                resumeLiveMic()
                startListening(150)
            }
            else -> {
                mode = Mode.LISTEN
                resumeLiveMic()
                if (pendingAnn.isNotEmpty()) announce(pendingAnn.removeAt(0)) else startListening(400)
            }
        }
    }

    // ---------- announcements and the floating markhor ----------

    private fun announce(text: String) {
        main.post {
            if (stopped) return@post
            if (mode == Mode.LISTEN) {
                mode = Mode.SPEAKING
                try { recognizer?.cancel() } catch (e: Exception) {}
                Buddy.post(3, "[MSG] $text")
                bubble?.setMood(Mood.SURPRISED, 2500)
                systemSpeak(text, "ann")
            } else if (pendingAnn.size < 5) {
                pendingAnn.add(text)
            }
        }
    }

    fun setBubbleVisible(show: Boolean) {
        main.post { bubble?.visibility = if (show) View.VISIBLE else View.GONE }
    }

    private fun addBubble() {
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        if (!Settings.canDrawOverlays(this) || !prefs.getBoolean("bubble", true)) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val d = resources.displayMetrics.density
            val lp = WindowManager.LayoutParams(
                (130 * d).toInt(), (150 * d).toInt(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = (10 * d).toInt()
            lp.y = (260 * d).toInt()
            val accent = Style.themes[prefs.getInt("theme", 0).coerceIn(0, Style.themes.size - 1)].accent
            val v = BuddyView(this, accent)
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            v.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx
                        val dy = e.rawY - sy
                        if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true
                        if (moved) {
                            lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                            try { wm.updateViewLayout(v, lp) } catch (x: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) v.onTap(e.x, e.y)
                }
                true
            }
            wm.addView(v, lp)
            bubble = v
            bubbleLp = lp
        } catch (e: Exception) {}
    }

    private fun removeBubble() {
        try {
            bubble?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        } catch (e: Exception) {}
        bubble = null
    }

    // ---------- notification and overlay ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Anjoo AI", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP), flags
        )
        val talk = PendingIntent.getService(
            this, 2, Intent(this, VoiceService::class.java).setAction(ACTION_LISTEN), flags
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Anjoo AI chal raha hai")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now), "Bolein", talk
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Band karein", stop
                ).build()
            )
            .build()
    }

    private fun setStatus(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(text))
        } catch (e: Exception) {}
    }

    /**
     * A 1-pixel invisible window. Android lets a background app open other apps
     * (needed for "WhatsApp kholo") only while it has a visible overlay window.
     */
    private fun addOverlay() {
        try {
            if (!Settings.canDrawOverlays(this)) return
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val v = View(this)
            v.setBackgroundColor(Color.argb(1, 0, 0, 0))
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            overlay = v
        } catch (e: Exception) {}
    }

    private fun removeOverlay() {
        try {
            overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        } catch (e: Exception) {}
        overlay = null
    }
}
