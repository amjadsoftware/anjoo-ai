plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.anjoo.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.anjoo.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 62
        versionName = "77.3"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}


dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
