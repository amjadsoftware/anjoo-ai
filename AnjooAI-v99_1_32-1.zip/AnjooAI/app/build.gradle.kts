plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.anjoo.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.anjoo.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 99132
        versionName = "99.1.32"
    }

    buildTypes {
        release {
            // R8 shrinks and obfuscates the release APK. Rules live in proguard-rules.pro.
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        // Reports are produced on every CI run; they do not block a build.
        abortOnError = false
        checkReleaseBuilds = false
        htmlReport = true
        xmlReport = true
    }

    testOptions {
        unitTests {
            // Android stubs return defaults instead of throwing, so pure-Kotlin logic can be tested on the JVM.
            isReturnDefaultValues = true
        }
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    testImplementation("junit:junit:4.13.2")
    // The Android SDK's org.json is only a stub on the JVM, so tests use the real library.
    testImplementation("org.json:json:20240303")
}
