package com.anjoo.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** Sound levels of the live voice (your mic and Anjoo's voice), fed by GeminiLiveSession and read by LiveOrb. */
object OrbLevel {
    @Volatile private var mic = 0f
    @Volatile private var micAt = 0L
    @Volatile private var out = 0f
    @Volatile private var outAt = 0L

    fun feedMic(s: ShortArray, n: Int) {
        if (n <= 0) return
        var sum = 0.0
        for (i in 0 until n) { val v = s[i] / 32768.0; sum += v * v }
        mic = min(1f, (sqrt(sum / n) * 7.0).toFloat()); micAt = SystemClock.uptimeMillis()
    }

    fun feedOut(pcm: ByteArray) {
        val n = pcm.size / 2
        if (n <= 0) return
        var sum = 0.0
        var i = 0
        while (i + 1 < pcm.size) {
            val v = ((pcm[i].toInt() and 255) or (pcm[i + 1].toInt() shl 8)).toShort() / 32768.0
            sum += v * v; i += 2
        }
        out = min(1f, (sqrt(sum / n) * 6.0).toFloat()); outAt = SystemClock.uptimeMillis()
    }

    /** Anjoo's voice level now (0 when silent for a moment). */
    fun outLevel(): Float = if (SystemClock.uptimeMillis() - outAt < 260) out else 0f
    fun micLevel(): Float = if (SystemClock.uptimeMillis() - micAt < 260) mic else 0f
}

/**
 * A soft, light circle in Claude's warm colours that flows like water or a cloud and swells and ripples
 * when you or Anjoo speak. It is translucent, so the screen behind it stays visible.
 */
class LiveOrb(ctx: Context) : View(ctx), Runnable {
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN) }
    private val cols = intArrayOf(
        Color.parseColor("#D97757"), Color.parseColor("#F2A07B"), Color.parseColor("#C96442"),
        Color.parseColor("#F7D9C4"), Color.parseColor("#E8896A"), Color.parseColor("#FBE9DC")
    )
    private val blobs = cols.map { c -> RadialGradient(0f, 0f, 100f, intArrayOf(withA(c, 235), withA(c, 120), withA(c, 0)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP) }
    private var mask: RadialGradient? = null
    private var amp = 0f
    private var running = false
    private val t0 = SystemClock.uptimeMillis()

    private fun withA(c: Int, a: Int) = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val r = min(w, h) / 2f
        mask = RadialGradient(w / 2f, h / 2f, r, intArrayOf(Color.WHITE, Color.WHITE, Color.TRANSPARENT), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); running = true; postOnAnimation(this) }
    override fun onDetachedFromWindow() { running = false; removeCallbacks(this); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(v: View, vis: Int) {
        super.onVisibilityChanged(v, vis)
        if (vis == VISIBLE && isAttachedToWindow && !running) { running = true; postOnAnimation(this) }
        if (vis != VISIBLE) running = false
    }

    override fun run() {
        if (!running) return
        val target = max(OrbLevel.micLevel(), OrbLevel.outLevel())
        amp += (target - amp) * (if (target > amp) 0.35f else 0.08f)
        invalidate()
        postOnAnimation(this)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        if (w <= 0f) return
        val cx = w / 2f; val cy = h / 2f
        val r = min(w, h) / 2f
        val t = (SystemClock.uptimeMillis() - t0) / 1000f
        val breathe = 0.04f * sin(t * 1.3f)
        val swell = 1f + amp * 0.35f + breathe
        val sc = c.saveLayer(0f, 0f, w, h, null)
        for (i in blobs.indices) {
            val sp = 0.35f + 0.11f * i
            val ph = i * 1.9f
            val orbit = r * (0.20f + 0.05f * (i % 3)) * (1f + amp * 0.9f)
            val x = cx + cos(t * sp + ph) * orbit
            val y = cy + sin(t * sp * 1.27f + ph * 0.7f) * orbit
            val rad = r * (0.62f + 0.07f * ((i + 1) % 3)) * swell
            paint.shader = blobs[i]
            c.save(); c.translate(x, y); c.scale(rad / 100f, rad / 100f)
            c.drawCircle(0f, 0f, 100f, paint)
            c.restore()
        }
        paint.shader = null
        maskPaint.shader = mask
        c.drawRect(0f, 0f, w, h, maskPaint)
        c.restoreToCount(sc)
        // gentle ripples when somebody speaks
        if (amp > 0.06f) for (k in 0..1) {
            val ph = ((t * 0.55f + k * 0.5f) % 1f)
            ring.color = withA(cols[0], (abs(1f - ph) * amp * 150f).toInt().coerceIn(0, 150))
            ring.strokeWidth = 2f * d
            c.drawCircle(cx, cy, r * (0.55f + 0.42f * ph), ring)
        }
    }
}
