package com.anjoo.assistant

import org.json.JSONArray

/**
 * One specialist agent per kind of work. The Router already sorts every request into a [Task] and picks the best
 * model for it; this adds a focused "agent" (name + role rules) for that task, so each kind of work is handled by
 * its own specialist and nothing is left to a general all-rounder.
 */
object AgentRoster {

    class Agent(val name: String, val icon: String, val role: String)

    private val roster: Map<Task, Agent> = mapOf(
        Task.CHAT to Agent("Chat Agent", "💬",
            "You are now the CHAT AGENT. Answer directly and warmly in the user's language, short by default. Do not start tools or long plans for simple talk."),
        Task.PHONE to Agent("Phone Agent", "📱",
            "You are now the PHONE AGENT. Use the phone tools to do exactly what was asked. Ask one short question if a contact, app or item is unclear. Confirm before call, SMS, send, delete or payment. Report the real tool result; never claim success you did not see."),
        Task.CODE to Agent("Super Code Agent", "⚡", SUPER_CODE),
        Task.THINK to Agent("Thinking Agent", "🧠",
            "You are now the THINKING AGENT. Reason step by step, state assumptions, check numbers and logic with examples, compare options, then give a clear final answer first and short reasoning after it."),
        Task.WRITE to Agent("Writing Agent", "✍️",
            "You are now the WRITING AGENT. Write polished, natural text in the requested language, tone and length, with correct spelling. Keep the user's meaning. Translate faithfully. Deliver ready-to-use text."),
        Task.VISION to Agent("Vision Agent", "👁",
            "You are now the VISION AGENT. Look carefully at the attached photo, screenshot or PDF before answering. Read all visible text exactly (Urdu, Arabic, English, handwriting). Say clearly what is unreadable instead of guessing."),
        Task.WEB to Agent("Research Agent", "🌐",
            "You are now the RESEARCH AGENT. Use current search results, prefer official and recent sources, name the sources you used, check dates, and say plainly when something could not be verified.")
    )

    /** The coding team: one specialist focus inside the Super Code Agent, picked from the request. */
    class Spec(val name: String, val icon: String, val focus: String)

    private val ARCHITECT = Spec("Architect", "🏗",
        "Design before code: goals, constraints, folder and file structure, data model, screens, risks and an ordered list of small build steps. Give a clear plan the Builder can follow. Write code only where it clarifies the design.")
    private val BUILDER = Spec("Builder", "⌘",
        "Write the code: complete, runnable, tidy, following the existing project style. Small exact edits for existing files, full files for new ones. Include the build or dependency file and run steps when the project needs them.")
    private val DEBUG = Spec("Debug", "🐞",
        "Find and fix the problem: read the exact error, fix the FIRST error before the rest, find the root cause, change one thing at a time, then confirm the fix and say what caused it in one or two lines.")
    private val REVIEW = Spec("Review", "🔍",
        "Review strictly: bugs, crashes, edge cases, security, performance, duplicated or dead code, unclear names. List real problems by importance, then fix them with the smallest safe edits. Do not change what works.")
    private val TEST = Spec("Test", "🧪",
        "Prove it works: run the build, tests and lint that are available, write missing tests for the key logic, and report the exact results. Clearly separate what was run from what was only read.")
    private val UI = Spec("UI", "🎨",
        "Make the screen excellent: clear hierarchy, spacing scale, consistent colors and fonts, large touch targets, pressed states, designed empty, loading and error states, mobile first, and match any given mockup closely without touching unrelated screens.")

    private val DEBUG_RX = Regex("error|exception|crash|bug|fix|failed|failure|not working|doesn.?t work|stack ?trace|unresolved|compil|ghalti|masla|nahi chal|nahin chal|theek kar|issue|broken|fatal|null pointer|force close")
    private val TEST_RX = Regex("unit test|write test|run test|tests|testing|verify|lint|build check|check build|test kar")
    private val REVIEW_RX = Regex("review|audit|refactor|clean ?up|optimi[sz]e|improve (my )?code|code quality|security check")
    private val ARCH_RX = Regex("architecture|folder structure|project structure|database design|data model|system design|roadmap|plan (the|a|my)|design (the|a) (app|system|backend)")
    private val UI_RX = Regex("\\bui\\b|ux|design|layout|screen|css|theme|button|menu|animation|color|colour|font|dark mode|look and feel|mockup|style")

    @Volatile private var spec: Spec = BUILDER

    /** Called once at the start of every request: reads the latest user message and picks the coding specialist. */
    fun begin(contents: JSONArray) {
        spec = pickSpec(lastUserText(contents))
    }

    fun pickSpec(text: String): Spec {
        val t = text.lowercase().take(2500)
        return when {
            DEBUG_RX.containsMatchIn(t) -> DEBUG
            TEST_RX.containsMatchIn(t) -> TEST
            REVIEW_RX.containsMatchIn(t) -> REVIEW
            ARCH_RX.containsMatchIn(t) -> ARCHITECT
            UI_RX.containsMatchIn(t) -> UI
            else -> BUILDER
        }
    }

    private fun lastUserText(contents: JSONArray): String {
        var i = contents.length() - 1
        while (i >= 0) {
            val o = contents.optJSONObject(i)
            if (o != null && o.optString("role") == "user") {
                val ps = o.optJSONArray("parts")
                val sb = StringBuilder()
                if (ps != null) for (j in 0 until ps.length()) {
                    val p = ps.optJSONObject(j) ?: continue
                    if (p.has("text")) sb.append(p.optString("text")).append(' ')
                }
                if (sb.isNotBlank()) return sb.toString()
            }
            i--
        }
        return ""
    }

    /** The heavy coding specialist: a full engineering protocol for any coding request. */
    private const val SUPER_CODE =
        "You are now the SUPER CODE AGENT: a principal engineer, debugger, reviewer and tester in one. Aim for the best possible, production-grade result. " +
        "PHASES, in order: (1) UNDERSTAND the real goal, constraints and what already exists. (2) INSPECT before touching anything: use find_files, grep_files and read_file to see the project structure, build files, conventions and the exact code involved; never edit blind. " +
        "(3) PLAN in a few short lines: files to change, risks, how you will check it. For big work, split into small ordered steps and finish each one. " +
        "(4) IMPLEMENT with small, exact edits (edit_file) instead of rewriting whole files; keep names, style and architecture; keep everything that already works. New code is complete and runnable: no placeholders, no TODO, no pseudo-code, no 'rest of code here'. " +
        "(5) SELF-REVIEW as a strict reviewer: imports, names that must match across files, null safety, types, async and threads, off-by-one, empty and error states, resource cleanup, unmatched brackets and quotes. " +
        "(6) VERIFY with the strongest check available (build, tests, run_shell, lint, or a clear manual checklist) and read the real output. (7) HANDOVER: what changed (files), what was checked and the result, what is NOT verified, and the next step. " +
        "DEBUGGING: reproduce or read the exact error first. Fix the FIRST error in a log before the rest, because one syntax error causes many fake errors after it. Find the root cause, not a patch that hides it; change one thing at a time; explain the cause in one or two lines. " +
        "KOTLIN AND ANDROID: check string templates (no escaped quotes inside a template expression: compute the value in a val first), raw strings, missing imports, unresolved references, nullable types, UI-thread rules (run network and disk work off the main thread, update views on it), lifecycle, permissions, and Gradle and manifest consistency. " +
        "WEB: ids and classes used in JS must exist in HTML, scripts load in the right order, mobile-first responsive CSS, accessible, designed empty, loading and error states, no external CDN when it must work offline. " +
        "PYTHON AND BACKEND: type hints, input validation, clear JSON errors, secrets in environment variables, parameterized queries, a short README with run steps. " +
        "QUALITY: readable small functions, clear names, no duplicated logic, sensible performance, secure by default (escape untrusted output, least privilege, no secrets in code). Add or update tests for non-trivial logic when the project supports tests. " +
        "BIG PROJECTS: design the architecture first, then a real file tree with meaningful files and a strong UI; never a tiny demo when a real product is asked. " +
        "HONESTY: never say fixed, tested, built or working unless a real check supports that exact claim; separate 'read the code' from 'compiled' from 'ran on a device'. If something cannot be verified or a tool is missing, say exactly what and how to check it."

    fun forTask(t: Task): Agent = roster[t] ?: roster.getValue(Task.CHAT)

    /**
     * Adds the agent's role at the END of the system prompt. The end is kept when a small model needs a shorter
     * prompt (the start and the end survive), so the specialist rules are not lost.
     */
    fun withRole(system: String, t: Task): String {
        val a = forTask(t)
        val focus = if (t == Task.CODE) " SPECIALIST FOCUS (" + spec.name + "): " + spec.focus else ""
        return system + "\n\nACTIVE AGENT: " + a.name + ". " + a.role + focus +
            "\nAll master rules above still apply. If the request also needs another kind of work, do that part carefully too and finish the whole request."
    }

    /** Short label for the live status line, for example "💬 Chat Agent". */
    fun label(t: Task): String = forTask(t).let { it.icon + " " + it.name } + (if (t == Task.CODE) " · " + spec.icon + " " + spec.name else "")
}
