# v100.0.57 — build never stopped (30+ min) after an error
Cause: waitForRun() kept the FIRST snapshot of the GitHub run. It only replaced the tracked run when a run with a HIGHER id appeared
(`>`), so the same run's updated status (completed / failure) was never read. The dialog showed "Build is running…" until the
workflow's own 30-minute timeout / the app's 36-minute limit, even though GitHub had failed the job in ~20 s.
Fix: refresh the same run on every poll (`>=`). Failures now show within ~4-8 s with the failed step and log lines.
Also: polls every 4 s (then 8 s) and stops after 4 min if GitHub never starts the run.
