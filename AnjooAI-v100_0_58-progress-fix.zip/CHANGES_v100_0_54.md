# v100.0.54 — APK Builder preflight

Run #8 passed "Set up Android SDK" (v100.0.53 fix worked) but failed in "Safely extract project and determine build type":
"No buildable Android Gradle project or index.html was found". The uploaded project had neither
settings.gradle(.kts)+app/build.gradle(.kts) nor an index.html (build/, node_modules, .git etc. are not uploaded).

- New `preflightProject()` runs the same detection locally before uploading. If nothing buildable exists it stops immediately
  with the list of files found, instead of spending a cloud run.
