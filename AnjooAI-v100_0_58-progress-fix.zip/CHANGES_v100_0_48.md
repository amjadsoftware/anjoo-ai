# v100.0.48

HS APK Builder, improvement 6: check the project before building.

- New `ProjectCheck.kt` (pure Kotlin) runs in a second on the phone before the upload and finds common problems that otherwise appear only after a long cloud build.
- Native Android projects: settings include(":app"), AndroidManifest.xml present, source files present, namespace present, Kotlin plugin when .kt files exist, android.useAndroidX when AndroidX is used, launcher activity (warning), @mipmap/@drawable icon files and @string values used by the manifest exist, declared activities have a source file, key-file reference warning (key files are never uploaded).
- Websites: index.html present and not empty, source-only pages (.jsx/.tsx/.ts/.vue/.svelte, which would show a blank page) are an error, missing files and paths starting with / are warnings, scripts or styles loaded from the internet are a warning (the app may not work offline).
- If something is found, a dialog lists it with Build anyway / Cancel / Copy report. A project with no findings builds immediately, as before.
- Tests: `ProjectCheckTest.kt` (6 cases).
- Not compiled or run here (no network/Android SDK in this session); the GitHub build compiles it and runs the tests.
