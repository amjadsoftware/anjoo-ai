# v100.0.46

HS APK Builder, improvement 4: Idea -> APK.

- New **Idea -> APK** box in HS - APK Builder: describe an app, tool or HTML5 game and press "Build my app". It requires the GitHub connection to be saved first (one time).
- The idea is sent to the main chat with a master prompt written for APK packaging (one self-contained index.html, works offline, touch-friendly, real app name in the title, localStorage, no CDN, game rules for HTML5 games).
- When the project is finished and you open APK Builder again, it finds the new project and asks "Build the APK now?". (If files were written in the last 15 seconds it asks you to come back in a moment.) The pending request expires after 6 hours.
- The existing "APK" button on a finished project card in the chat still works as before.
- Uses the WebView APK path, which is the most reliable one. Native Android projects written by AI often need fixes to compile, so they are not the default here.
- Not compiled or run here (no network/Android SDK in this session).
