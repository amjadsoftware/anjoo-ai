# v100.0.51

HS APK Builder, improvement 8: builds run in the background; no waiting on the screen.

- New `HsBuildService` (foreground service, type dataSync, already permitted in the manifest) keeps the app alive while a cloud build runs, even with the screen off or the app closed from view. It shows an ongoing notification "Building APK: <project>" with a running timer, the current step, and a **Cancel build** button.
- The progress dialog has a new **Hide - keep building** button; the Back button now hides it too (before, Back was blocked until the build finished). Opening the builder again (or tapping the progress notification) shows the running build again; tapping Build APK while one runs shows it instead of starting a second build.
- When the build finishes you get a notification: **APK ready** (tap installs the APK), **Build fail** with the reason (first line, expandable; the full reason opens when you tap it), or **Build cancelled**.
- Cancel now also works while the project is being uploaded and from the notification (it used to work only while waiting for GitHub). A cancelled build is not treated as a failure.
- The screen no longer crashes or shows dialogs on a closed screen when a build ends after you left the app.
- Android 13+: asks for notification permission when a build starts, if not yet granted.
- Not changed: the workflow, the build steps, limits, signing.
- Not compiled or run here (no network/Android SDK in this session); the GitHub build compiles it.
