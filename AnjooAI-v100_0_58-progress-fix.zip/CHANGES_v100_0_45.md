# v100.0.45

HS APK Builder, improvement 3: a better WebView APK (for website / HTML / game projects).

Changed only in `app/src/main/assets/hs-build-apk.yml` (the workflow HS installs into your private build repository; the next build updates it automatically):
- Back button goes back inside the page, and closes the app only when there is nothing to go back to.
- File pickers work (`<input type="file">`), so upload buttons in websites no longer do nothing.
- Rotating the phone no longer reloads the page and loses its state.
- Links to other websites, `tel:` and `mailto:` open in the phone's own apps instead of inside the app (iframes and local pages are unaffected).
- Video/audio can start without an extra tap.

Not changed: the Kotlin app code, signing key, limits.
Checked here: the workflow YAML parses and the wrapper generator runs and writes valid-looking files. The generated Java was not compiled (no Android SDK/network in this session); the GitHub build will compile it.
Not done: camera/microphone/location inside the web app, and fetch() of local JSON files from file:// pages.
