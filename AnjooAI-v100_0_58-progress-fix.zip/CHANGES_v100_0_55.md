# v100.0.55 — pipeline audit (Idea → APK)
- WebView wrapper: manifest gets windowSoftInputMode=adjustResize so the keyboard no longer covers input fields.
- ProjectCheck: warns when index.html uses <script type="module" src=...> (blocked on file:// in WebView = blank page).
