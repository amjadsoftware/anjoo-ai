# v100.0.50

HS APK Builder, improvement 7: long builds and failures you could not read.

Seen in your screenshots: a build running 15 minutes 36 seconds ("Avg build 4-8 min"), later a notification "Build fail: Offline Battle Royale - Open to see the build log." with no reason.

- The app gave up waiting after about 23 minutes (120 checks) while the GitHub build is allowed 30 minutes, and its message said "20 minutes". It now waits up to 36 minutes (time based), and when it stops waiting it says the build may still be running or finished on GitHub, with the link.
- A failure is now saved. When the builder is opened (for example by tapping the notification) the reason is shown once, with Build logs / Copy error, even if the screen was off or the app was in the background when it failed. Before, the reason was only shown if the screen was open at that moment.
- The failure notification now shows the first line of the reason and expands to about 400 characters (failed step and key error lines when the log could be read).
- Not changed: workflow, limits, signing.
- Not compiled or run here (no network/Android SDK in this session); the GitHub build compiles it.
