package com.anjoo.assistant

/** Turns a ZIP or project file name into a clean app name for the HS APK Builder. Pure Kotlin so it can be unit tested. */
object AppNaming {
    private val extension = Regex("""(?i)\.(zip|apk|rar|7z|tar|gz)$""")
    private val copySuffix = Regex("""(?i)\s*(\(\d+\)|[-_ ]copy( \d+)?)$""")
    private val versionSuffix = Regex("""(?i)[\s._-]+(v\d+([._]\d+)*|\d+([._]\d+)+)$""")
    private val separators = Regex("""[_\-.]+""")
    private val spaces = Regex("""\s+""")
    private val camelLowerUpper = Regex("""(?<=[a-z0-9])(?=[A-Z])""")
    private val camelAcronym = Regex("""(?<=[A-Z])(?=[A-Z][a-z])""")

    /** "AnjooAI-v100_0_51.zip" gives "Anjoo AI"; "offline_battle_royale (1).zip" gives "Offline Battle Royale". */
    fun fromZipName(raw: String, maxLen: Int = 30): String {
        var s = raw.trim()
        s = extension.replace(s, "")
        s = copySuffix.replace(s, "")
        s = versionSuffix.replace(s, "")
        s = separators.replace(s, " ").trim()
        if (!s.contains(' ')) {
            s = camelLowerUpper.replace(s, " ")
            s = camelAcronym.replace(s, " ")
        }
        s = spaces.replace(s, " ").trim()
        s = s.split(" ").joinToString(" ") { w ->
            if (w.isNotEmpty() && w[0].isLowerCase() && w.none { it.isUpperCase() }) w[0].uppercaseChar() + w.substring(1) else w
        }
        if (s.length > maxLen) {
            val cut = s.take(maxLen)
            val at = cut.lastIndexOf(' ')
            s = if (at >= 8) cut.substring(0, at) else cut
        }
        s = s.trim()
        return s.ifBlank { "My App" }
    }
}
