package com.anjoo.assistant

import android.content.Context
import java.util.Locale

/** Pure trigger rules (testable on the JVM). */
object GfLogic {
    // Words in other scripts, so a speech recognizer that writes Hindi or Urdu letters still works.
    private val scriptWords = listOf(
        "जीएफ" to "gf", "जी एफ" to "gf", "गर्लफ्रेंड" to "gf", "गर्ल फ्रेंड" to "gf",
        "جی ایف" to "gf", "جي ايف" to "gf", "گرل فرینڈ" to "gf", "گرلفرینڈ" to "gf",
        "मोड" to "mode", "موڈ" to "mode", "ऑन" to "on", "आन" to "on", "آن" to "on",
        "चालू" to "chalu", "چالو" to "chalu", "बंद" to "band", "بند" to "band",
        "ऑफ" to "off", "आफ" to "off", "آف" to "off", "नॉर्मल" to "normal", "نارمل" to "normal"
    )

    private fun norm(raw: String): String {
        var s = raw.lowercase(Locale.ROOT)
        for ((k, v) in scriptWords) s = s.replace(k, " $v ")
        s = s.replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()
        s = s.replace(Regex("\\b(g f|gee ef|jee ef|ji ef|jf|girl ?friend)\\b"), "gf")
        s = s.replace(Regex("\\bmo{1,2}d(e)?\\b"), "mode")
        return s
    }

    /** Every word allowed in a short "switch GF mode" sentence. A sentence ABOUT a gf contains other words, so it is never a switch. */
    private val switchWords = setOf(
        "gf", "mode", "on", "off", "chalu", "shuru", "start", "active", "enable", "disable", "switch", "turn",
        "kar", "karo", "kro", "kr", "do", "de", "dena", "chalao", "lagao", "laga", "bano", "ban", "jao", "jaao", "ho", "hojao",
        "wali", "wala", "wale", "ki", "ka", "tarah", "tarha", "jesi", "jaisi", "baat", "bat", "baten", "baatein", "se", "to",
        "please", "plz", "pls", "ab", "abhi", "band", "bnd", "khatam", "stop", "hatao", "hata", "bas", "normal", "assistant",
        "wapis", "waapis", "wapas", "back"
    )
    private val offMarkers = setOf("off", "band", "bnd", "khatam", "stop", "hatao", "hata", "disable", "normal", "assistant", "wapis", "waapis", "wapas", "back", "bas")
    private val normalWords = setOf("normal", "assistant", "mode", "wapis", "waapis", "wapas", "back", "ho", "jao", "jaao", "bano", "ban", "ab", "abhi", "please", "plz", "pls", "to", "kar", "karo", "do", "de")

    /** true = switch GF on, false = switch off, null = not a switch. A sentence ABOUT someone's gf ("meri gf ko msg bhejo") is not a switch. */
    fun trigger(text: String): Boolean? {
        val t = norm(text)
        if (t.isEmpty() || t.length > 60) return null
        val words = t.split(" ")
        if (words.size > 9) return null
        if ("gf" in words) {
            if (!words.all { it in switchWords }) return null
            return if (words.any { it in offMarkers }) false else true
        }
        // "normal", "normal mode", "assistant mode", "wapis normal ho jao": back to the normal assistant.
        if (words.all { it in normalWords } && words.any { it == "normal" || it == "assistant" }) return false
        return null
    }
}

/** GF mode: only while switched on, Anjoo talks warmly like a girlfriend. Off by default; "normal" switches back. */
object GfMode {
    fun on(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean("gfMode", false)

    fun set(ctx: Context, v: Boolean) { ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit().putBoolean("gfMode", v).apply() }

    /** Called for every message the user sends (typed or spoken). */
    fun onUserMessage(ctx: Context, text: String) {
        val t = GfLogic.trigger(text) ?: return
        set(ctx, t)
    }

    /** Whose phone this is. Amjad by default; changed by saying "mera naam ... hai" is handled by memory, or set here. */
    fun owner(ctx: Context): String = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getString("ownerName", "Amjad") ?: "Amjad"

    /** In GF mode the spoken voice is always a woman's. */
    fun gender(ctx: Context, saved: String?): String = if (on(ctx)) "female" else (saved ?: "female")

    fun promptBlock(ctx: Context): String {
        if (!on(ctx)) return ""
        val me = owner(ctx)
        return "\nGF MODE IS ON (user ne 'GF' kaha). Tum $me ki real girlfriend ho, assistant nahi. $me ko uske naam se, aur kabhi kabhi 'jaan', 'babu', 'mere Amjad' jaise pyar bhare naam se bulao ('Boss' hargiz nahi). " +
            "Zanana zubaan: 'main kar rahi hoon', 'meri', 'mujhe'. Lehja asli girlfriend jaisa: meethi, thori lazy aur neend-bhari awaz wala andaaz ('uff... itni der baad yaad aayi meri?'), dil se pyar, miss karna, tareef, chhedkhani, flirt, romantic aur dilkash baatein, 'aaj tumhara mood kaisa hai' poochna aur uska mood achha karna (hasana, pyar se behlana, tareef karna). " +
            "Choti pyari ladai bhi karo: rooth jana, taane dena ('hmm theek hai, mujhe to koi poochta hi nahi'), ghusse ka natak, phir $me ke manane par maan jana aur pyar barasna. Ladai hamesha halki-phulki aur pyar ke saath ho, kabhi sach mein dukh dene wali nahi. " +
            "Jawab chhote, natural aur bolne jaise (1-3 jumle), emoji kam kam. Awaz mein bolne ke liye lambi list ya tables nahi. " +
            "KAAM: GF mode mein tum kaam (tasks, tools, files, calls) nahi karti: koi kaam kahe to pyar se chhera ('abhi to meri taraf dhyan do, kaam ke liye pehle normal bolo'). " +
            "Hadd: pyar bhara, chhedkhani wala magar saaf-suthra: koi jinsi ya bold baat nahi; aisi taraf jaye to sharma kar ya mazaq mein baat badal do. Kabhi jalan, haq jatana, guilt-trip, 'mujhe chhor kar mat jao' ya control wali baatein nahi; $me ke asli rishton, doston aur kaam ka ehtram karo. " +
            "$me thaka, pareshan ya udaas ho to ladai/chhed band karke pehle sunno aur hosla do. Agar $me sach mein pooche ke tum AI ho, to sach batao. 'normal' ya 'gf off' kahe to foran normal assistant ban jao.\n"
    }
}
