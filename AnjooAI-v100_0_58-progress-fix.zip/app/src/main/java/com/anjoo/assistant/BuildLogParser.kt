package com.anjoo.assistant

/**
 * Turns a raw GitHub Actions job log into a short, readable error summary for the HS APK Builder.
 * Pure Kotlin (no Android classes) so it can be unit tested.
 */
object BuildLogParser {
    private val timestamp = Regex("""^\uFEFF?\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z ?""")
    private val ansi = Regex("""\u001B\[[0-9;]*[A-Za-z]""")
    private val runnerPath = Regex("""/home/runner/work/[^/\s]+/[^/\s]+/""")
    private val errorLine = Regex(
        """(^e: |\berror:|: error |##\[error\]|Unresolved reference|Execution failed for task|FAILURE: Build failed|""" +
            """Could not resolve|Could not find |AAPT: |Manifest merger failed|SDK location not found|Duplicate class|""" +
            """Task '.*' not found|Unsupported class file|[Cc]annot find symbol|No matching variant|Plugin .* was not found|""" +
            """Unsupported Gradle|requires Java|Invalid keystore|Keystore file)"""
    )
    private const val EXIT_NOISE = "Process completed with exit code"

    private fun clean(raw: String): String =
        runnerPath.replace(ansi.replace(timestamp.replace(raw, ""), ""), "").trimEnd()

    /** Returns at most [maxChars] characters describing why the build failed ("" if the log is blank). */
    fun summarize(log: String, maxChars: Int = 1300): String {
        val lines = log.lineSequence().map { clean(it) }.toList()
        if (lines.none { it.isNotBlank() }) return ""

        val parts = mutableListOf<String>()
        val seen = mutableSetOf<String>()

        // Gradle's own explanation: "* What went wrong:" followed by a few lines.
        val wrong = lines.indexOfFirst { it.trim().startsWith("* What went wrong:") }
        if (wrong >= 0) {
            var taken = 0
            var i = wrong + 1
            while (i < lines.size && taken < 4) {
                val l = lines[i].trim()
                if (l.startsWith("* Try:") || l.startsWith("* Exception is:")) break
                if (l.isNotBlank()) { parts += l.take(240); seen += l; taken++ }
                i++
            }
        }

        // Compiler / tool error lines, in the order they appeared.
        var errorCount = 0
        for (line in lines) {
            val l = line.trim()
            if (l.isBlank() || l.startsWith("##[group]") || l.startsWith("##[endgroup]")) continue
            if (l.contains(EXIT_NOISE)) continue
            if (!errorLine.containsMatchIn(l)) continue
            if (!seen.add(l)) continue
            parts += l.take(240)
            if (++errorCount >= 10) break
        }

        // Nothing recognisable: show the end of the log instead.
        if (parts.isEmpty()) {
            val tail = lines.map { it.trim() }.filter { it.isNotBlank() && !it.contains(EXIT_NOISE) }.takeLast(12)
            parts += tail.map { it.take(240) }
        }

        val out = StringBuilder()
        for (p in parts) {
            if (out.length + p.length + 1 > maxChars) break
            if (out.isNotEmpty()) out.append('\n')
            out.append(p)
        }
        return out.toString().trim()
    }
}
