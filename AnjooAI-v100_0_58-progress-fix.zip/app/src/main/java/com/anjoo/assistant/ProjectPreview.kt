package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** A WebView that serves a project's files from https://app.local/, so pages, css, scripts and images link up. */
object ProjectWeb {

    fun create(ctx: Context, base: File, onFinished: ((WebView) -> Unit)? = null): WebView {
        val wv = WebView(ctx)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true      // localStorage + IndexedDB, kept on the phone between launches
        @Suppress("DEPRECATION") run { wv.settings.databaseEnabled = true }
        wv.tag = base
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        wv.setBackgroundColor(Color.WHITE)
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                return PreviewServer.serve(base, u)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (view != null) try { onFinished?.invoke(view) } catch (_: Exception) { }
            }
        }
        return wv
    }

    /** Opens the main page, or [page] (a path inside the project). */
    fun load(wv: WebView, page: String? = null) {
        val base = wv.tag as? File
        val origin = if (base != null) PreviewServer.origin(base) else "https://app.local/"
        wv.loadUrl(origin + if (page == null) "" else Uri.encode(page, "/"))
    }
}

/**
 * Full-screen preview of a whole project (all its pages, styles and scripts) with the chat-style actions:
 * reload, pages, download as zip, and open in Code Studio. Opened from the project card in the chat.
 */
class ProjectPreviewActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private lateinit var dir: File
    private var wv: WebView? = null
    private var editBridgeAdded = false
    private var editOn = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        dir = File(intent.getStringExtra("project") ?: "")
        if (!dir.isDirectory || PreviewServer.entry(dir) == null) {
            Toast.makeText(this, "A preview cannot be made for this project.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#1B1B1F"))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        // Tap targets of at least 44 x 48 dp so the buttons are easy to hit with a thumb.
        fun btn(label: String, a: () -> Unit) = TextView(this).apply {
            text = label; textSize = 16f; setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            minimumWidth = dp(44); minimumHeight = dp(48)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { a() }
        }
        bar.addView(btn("✕") { finish() })
        bar.addView(TextView(this).apply {
            text = Coder.name(dir); textSize = 14f; setTextColor(Color.WHITE)
            maxLines = 1; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(btn("✏️") {
            val x = wv ?: return@btn
            if (!editBridgeAdded) { x.addJavascriptInterface(SiteEditor.Bridge(dir) { editOn = false }, "AnjooEdit"); editBridgeAdded = true }
            editOn = true
            x.evaluateJavascript(SiteEditor.JS, null)
            Toast.makeText(this, "Edit mode: tap to change, then press Save. To follow links, press Browse in the panel.", Toast.LENGTH_LONG).show()
        })
        bar.addView(btn("⟳") { wv?.reload() })
        if (PreviewServer.pages(dir).size > 1) bar.addView(btn("📄") { pickPage() })
        bar.addView(btn("🌐") { publishSite() })
        bar.addView(btn("⬇") { download() })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        // Edit mode follows you to the next pages: the panel is added again after every page load until you press Done.
        val w = ProjectWeb.create(this, dir) { v -> if (editOn) v.evaluateJavascript(SiteEditor.JS, null) }
        wv = w
        // Device switcher: Phone (real size), Mobile, Tablet, MacBook, PC. The page is laid out at that device's CSS width
        // (so its @media queries really switch layout) and scaled to fit the screen; zoom and rotate are available.
        val chips = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(4), dp(6), dp(4)) }
        chipsRow = chips
        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.parseColor("#26262B"))
            addView(chips)
        }
        root.addView(chipScroll, LinearLayout.LayoutParams(-1, -2))
        val hs = HorizontalScrollView(this).apply {
            isFillViewport = true; isHorizontalScrollBarEnabled = false
            setBackgroundColor(Color.parseColor("#3A3A40"))
        }
        val outer = FrameLayout(this)
        val wrap = FrameLayout(this).apply { setBackgroundColor(Color.WHITE) }
        wrap.addView(w, FrameLayout.LayoutParams(-1, -1))
        outer.addView(wrap, FrameLayout.LayoutParams(-1, -1))
        hs.addView(outer, FrameLayout.LayoutParams(-1, -1))
        hScroll = hs; outerBox = outer; wrapBox = wrap
        root.addView(hs, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        device = getSharedPreferences("anjoo", Context.MODE_PRIVATE).getString("previewDevice", "Phone") ?: "Phone"
        buildChips()
        hs.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob ->
            if (r - l != orr - ol || b - t != ob - ot) hs.post { applyDevice() }
        }
        applyDevice()
        ProjectWeb.load(w)
    }

    private class Dev(val name: String, val label: String, val w: Int, val h: Int, val turns: Boolean)
    private val devs = listOf(
        Dev("Phone", "📲 Phone", 0, 0, false),
        Dev("Mobile", "📱 Mobile", 390, 844, true),
        Dev("Tablet", "📋 Tablet", 820, 1180, true),
        Dev("MacBook", "💻 MacBook", 1440, 900, false),
        Dev("PC", "🖥 PC", 1920, 1080, false)
    )
    private var device = "Phone"
    private var landscape = false
    private var zoom = 1f
    private var chipsRow: LinearLayout? = null
    private var hScroll: HorizontalScrollView? = null
    private var outerBox: FrameLayout? = null
    private var wrapBox: FrameLayout? = null
    private var infoView: TextView? = null

    private fun buildChips() {
        val row = chipsRow ?: return
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        row.removeAllViews()
        fun chip(label: String, on: Boolean, a: () -> Unit) = TextView(this).apply {
            text = label; textSize = 13f
            setTextColor(if (on) Color.parseColor("#1B1B1F") else Color.WHITE)
            background = android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(if (on) Color.WHITE else Color.parseColor("#3A3A40"))
            }
            setPadding(dp(12), dp(6), dp(12), dp(6))
            setOnClickListener { a() }
        }
        val lp = { LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) } }
        for (dv in devs) row.addView(chip(dv.label, dv.name == device) {
            device = dv.name; landscape = false; zoom = 1f
            getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit().putString("previewDevice", device).apply()
            buildChips(); applyDevice()
        }, lp())
        val cur = devs.firstOrNull { it.name == device }
        if (cur != null && cur.turns) row.addView(chip(if (landscape) "↻ Landscape" else "↻ Portrait", false) { landscape = !landscape; buildChips(); applyDevice() }, lp())
        if (cur != null && cur.w > 0) {
            row.addView(chip("－", false) { zoom = (zoom / 1.25f).coerceAtLeast(1f); applyDevice() }, lp())
            row.addView(chip("＋", false) { zoom = (zoom * 1.25f).coerceAtMost(4f); applyDevice() }, lp())
        }
        val info = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#B8B8C0")); setPadding(dp(6), 0, dp(10), 0) }
        infoView = info
        row.addView(info)
    }

    /** Lays the website out at the chosen device's width and scales it to fit (touch, scrolling and media queries all work). */
    private fun applyDevice() {
        val hs = hScroll ?: return
        val outer = outerBox ?: return
        val wrap = wrapBox ?: return
        val w = wv ?: return
        val availW = hs.width
        val availH = hs.height
        if (availW <= 0 || availH <= 0) { hs.post { applyDevice() }; return }
        val dv = devs.firstOrNull { it.name == device }
        val density = resources.displayMetrics.density
        if (dv == null || dv.w == 0) {
            // Phone: the page at this phone's own size.
            wrap.layoutParams = FrameLayout.LayoutParams(-1, -1)
            w.layoutParams = FrameLayout.LayoutParams(-1, -1)
            w.scaleX = 1f; w.scaleY = 1f
            infoView?.text = "Is phone ka asli size"
            return
        }
        val cssW = if (landscape && dv.turns) dv.h else dv.w
        val cssH = if (landscape && dv.turns) dv.w else dv.h
        val fit = Math.min(1f, availW / (cssW * density))   // never enlarge beyond real size
        val s = fit * zoom
        val wpx = (cssW * density).toInt()
        val hpx = Math.max((availH / s).toInt(), (200 * density).toInt())
        val boxW = Math.max((wpx * s).toInt(), if (zoom == 1f) 0 else availW)
        outer.layoutParams = FrameLayout.LayoutParams(Math.max(boxW, availW), -1)
        wrap.layoutParams = FrameLayout.LayoutParams((wpx * s).toInt(), availH, Gravity.CENTER_HORIZONTAL)
        w.layoutParams = FrameLayout.LayoutParams(wpx, hpx)
        w.pivotX = 0f; w.pivotY = 0f
        w.scaleX = s; w.scaleY = s
        outer.requestLayout()
        infoView?.text = dv.name + " " + cssW + "×" + cssH + " px  ·  " + Math.round(s * 100) + "%"
    }

    private fun pickPage() {
        val pages = PreviewServer.pages(dir)
        AlertDialog.Builder(this)
            .setTitle("Pages")
            .setItems(pages.toTypedArray()) { _, i -> wv?.let { ProjectWeb.load(it, pages[i]) } }
            .show()
    }

    /** One-tap publish to Netlify: asks for a token once, confirms, uploads, then shows the live address. */
    private fun publishSite() {
        AlertDialog.Builder(this).setTitle("🌐 Where to publish?")
            .setItems(arrayOf("Netlify (easiest)", "GitHub Pages")) { _, which -> if (which == 0) publishNetlify() else publishGitHub() }
            .setNegativeButton("Cancel", null).show()
    }

    /** GitHub Pages: token asked once, then everything goes in one commit to a public repository named after the project. */
    private fun publishGitHub() {
        if (!GitHubPages.hasToken(this)) { askGitHubToken(); return }
        AlertDialog.Builder(this)
            .setTitle("🌐 GitHub Pages par publish?")
            .setMessage("A PUBLIC repository will be created in your GitHub account (or the same one updated) and the site will appear on the internet. Pages can take 1 to 2 minutes to go live.")
            .setPositiveButton("Publish") { _, _ ->
                Toast.makeText(this, "Publishing to GitHub...", Toast.LENGTH_LONG).show()
                Thread {
                    val r = try { Result.success(GitHubPages.publish(this, dir) { m -> runOnUiThread { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() } }) } catch (e: Exception) { Result.failure<String>(e) }
                    runOnUiThread { showPublishResult(r) }
                }.start()
            }
            .setNeutralButton("Token badlein") { _, _ -> askGitHubToken() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun askGitHubToken() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val input = android.widget.EditText(this).apply { hint = "GitHub token"; setSingleLine(true); setPadding(pad, pad, pad, pad) }
        AlertDialog.Builder(this)
            .setTitle("GitHub token")
            .setMessage("github.com > Settings > Developer settings > Personal access tokens > Tokens (classic) > Generate new token, tick 'repo'. Paste the token here. It stays only on your phone.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val t = input.text.toString().trim()
                if (t.length < 20) Toast.makeText(this, "The token looks too short, please check again.", Toast.LENGTH_LONG).show()
                else { GitHubPages.saveToken(this, t); publishGitHub() }
            }
            .setNeutralButton("Open GitHub") { _, _ -> try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/settings/tokens/new"))) } catch (_: Exception) { } }
            .setNegativeButton("Cancel", null).show()
    }

    private fun publishNetlify() {
        if (!SitePublisher.hasToken(this)) { askNetlifyToken(); return }
        AlertDialog.Builder(this)
            .setTitle("🌐 Publish the website?")
            .setMessage("This site will become public on the internet on Netlify. Publishing again updates the same address.")
            .setPositiveButton("Publish") { _, _ ->
                Toast.makeText(this, "Publishing...", Toast.LENGTH_LONG).show()
                Thread {
                    val r = try { Result.success(SitePublisher.publish(this, dir)) } catch (e: Exception) { Result.failure<String>(e) }
                    runOnUiThread { showPublishResult(r) }
                }.start()
            }
            .setNeutralButton("Token badlein") { _, _ -> askNetlifyToken() }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun askNetlifyToken() {
        val pad = (16 * resources.displayMetrics.density).toInt()
        val input = android.widget.EditText(this).apply {
            hint = "Netlify personal access token"
            setSingleLine(true)
            setPadding(pad, pad, pad, pad)
        }
        AlertDialog.Builder(this)
            .setTitle("Netlify token")
            .setMessage("Create a free account at app.netlify.com. Then User settings > Applications > Personal access tokens > New access token. Paste the token here. It stays only on your phone.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val t = input.text.toString().trim()
                if (t.length < 20) Toast.makeText(this, "The token looks too short, please check again.", Toast.LENGTH_LONG).show()
                else { SitePublisher.saveToken(this, t); publishNetlify() }
            }
            .setNeutralButton("Open Netlify") { _, _ -> try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://app.netlify.com/user/applications"))) } catch (_: Exception) { } }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPublishResult(r: Result<String>) {
        val url = r.getOrNull()
        if (url == null) {
            AlertDialog.Builder(this).setTitle("Not published")
                .setMessage(r.exceptionOrNull()?.message ?: "Unknown error")
                .setPositiveButton("OK", null).show()
            return
        }
        AlertDialog.Builder(this).setTitle("Site is live ✔").setMessage(url)
            .setPositiveButton("Open") { _, _ -> try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { } }
            .setNeutralButton("Copy") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("site", url))
                Toast.makeText(this, "Address copied.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Band", null).show()
    }

    private fun download() {
        val slug = Coder.name(dir).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "project" }
        Thread {
            val bytes = try { Coder.zip(dir) } catch (e: Exception) { null }
            runOnUiThread {
                if (bytes == null) Toast.makeText(this, "Could not create the ZIP.", Toast.LENGTH_SHORT).show()
                else Dl.save(this, "$slug.zip", bytes)
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != 77 || resultCode != RESULT_OK || uri == null) return
        Thread {
            val ok = try {
                contentResolver.openOutputStream(uri)?.use { it.write(Coder.zip(dir)) }
                true
            } catch (e: Exception) { false }
            runOnUiThread { Toast.makeText(this, if (ok) "ZIP saved." else "Could not save the ZIP.", Toast.LENGTH_SHORT).show() }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val w = wv
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        try { wv?.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }
}
