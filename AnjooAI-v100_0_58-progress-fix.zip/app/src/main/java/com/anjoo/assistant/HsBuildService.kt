package com.anjoo.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

/**
 * Keeps the HS cloud APK build alive in the background and shows its progress as a notification
 * (with a Cancel button), so nobody has to stay on the screen. The build itself runs in HsApkBuilderActivity's
 * worker thread; this service keeps the app process alive and holds the shared state (progress, cancel flag).
 */
class HsBuildService : Service() {
    companion object {
        const val ACTION_START = "com.anjoo.assistant.HS_BUILD_START"
        const val ACTION_CANCEL = "com.anjoo.assistant.HS_BUILD_CANCEL"
        private const val CHANNEL = "hs_apk_build_progress"
        private const val NOTIFICATION_ID = 7301

        @Volatile var running = false
        @Volatile var cancelFlag = false
        @Volatile var projectName = ""
        @Volatile var progress = ""
        @Volatile var startedWall = 0L

        fun begin(ctx: Context, project: String, initial: String) {
            cancelFlag = false
            projectName = project
            progress = initial
            startedWall = System.currentTimeMillis()
            running = true
            try {
                val i = Intent(ctx, HsBuildService::class.java).setAction(ACTION_START)
                ctx.startForegroundService(i)
            } catch (_: Exception) {}
        }

        fun update(ctx: Context, text: String) {
            progress = text
            if (!running) return
            try {
                (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification(ctx))
            } catch (_: Exception) {}
        }

        fun requestCancel(ctx: Context) {
            cancelFlag = true
            update(ctx, "Cancelling…")
        }

        fun end(ctx: Context) {
            running = false
            try { ctx.stopService(Intent(ctx, HsBuildService::class.java)) } catch (_: Exception) {}
        }

        private fun notification(ctx: Context): Notification {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "HS APK build progress", NotificationManager.IMPORTANCE_LOW))
            val open = PendingIntent.getActivity(
                ctx, 7303,
                Intent(ctx, HsApkBuilderActivity::class.java).putExtra("show_progress", true)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val cancel = PendingIntent.getService(
                ctx, 7304,
                Intent(ctx, HsBuildService::class.java).setAction(ACTION_CANCEL),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val line = progress.lineSequence().firstOrNull { it.isNotBlank() }?.take(110) ?: "Working…"
            val builder = Notification.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Building APK: $projectName")
                .setContentText(line)
                .setStyle(Notification.BigTextStyle().bigText(progress.take(400)))
                .setContentIntent(open)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(true)
                .setWhen(startedWall)
                .setUsesChronometer(true)
                .setProgress(0, 0, true)
            builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel build", cancel)
            return builder.build()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            requestCancel(this)
            if (!running) stopSelf()
            return START_NOT_STICKY
        }
        val n = notification(this)
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            else startForeground(NOTIFICATION_ID, n)
        } catch (_: Exception) {}
        if (!running) stopSelf()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        super.onDestroy()
    }
}
