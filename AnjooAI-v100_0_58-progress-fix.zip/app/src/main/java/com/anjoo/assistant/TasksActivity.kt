package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/** The Kanban board: three columns (To do, Doing, Done). Tap a card to move, edit or delete it. */
class TasksActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }


    private lateinit var th: CyberTheme
    private lateinit var tabs: LinearLayout
    private lateinit var list: LinearLayout
    private var col = "todo"
    private val refreshHandler = Handler(Looper.getMainLooper())
    private val refreshLoop = object : Runnable {
        override fun run() {
            if (!isFinishing && !isDestroyed) {
                refresh()
                refreshHandler.postDelayed(this, 1800L)
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(fill: Int, stroke: Int, r: Int) = GradientDrawable().apply { setColor(fill); setStroke(dp(1), stroke); cornerRadius = r.toFloat() }
    private fun faint() = Color.argb(70, 128, 128, 128)

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        Touch.feedback(window.decorView, ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        th = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        window.statusBarColor = th.bg
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(th.bg); setPadding(dp(12), dp(30), dp(12), dp(8)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text = "‹"; textSize = 28f; setTextColor(th.ink); setPadding(dp(8), 0, dp(14), dp(4)); setOnClickListener { finish() } })
        head.addView(TextView(this).apply { text = "📋 Tasks"; textSize = 20f; setTextColor(th.ink); typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) },
            LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(this).apply {
            text = "+  New"; textSize = 14f; setTextColor(th.bg); gravity = Gravity.CENTER
            background = box(th.accent, th.accent, dp(18)); setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnClickListener { edit(null) }
        })
        root.addView(head)
        tabs = LinearLayout(this).apply { setPadding(0, dp(12), 0, dp(8)) }
        root.addView(tabs)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refreshHandler.removeCallbacks(refreshLoop)
        refresh()
        refreshHandler.postDelayed(refreshLoop, 1800L)
    }

    override fun onPause() {
        refreshHandler.removeCallbacks(refreshLoop)
        super.onPause()
    }

    private fun refresh() {
        val all = Tasks.all(this)
        val items = (0 until all.length()).map { all.getJSONObject(it) }
        tabs.removeAllViews()
        for (c in Tasks.COLUMNS) {
            val n = items.count { it.optString("status") == c }
            val sel = c == col
            tabs.addView(TextView(this).apply {
                text = Tasks.LABELS[c] + "  " + n; textSize = 13f; gravity = Gravity.CENTER
                setTextColor(if (sel) th.bg else th.muted)
                background = box(if (sel) th.accent else Color.TRANSPARENT, if (sel) th.accent else faint(), dp(16))
                setPadding(dp(14), dp(6), dp(14), dp(6))
                setOnClickListener { col = c; refresh() }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
        }
        list.removeAllViews()
        val shown = items.filter { it.optString("status") == col }.sortedByDescending { it.optLong("at") }
        if (shown.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (items.isEmpty()) "No tasks yet.\nTap \"+ New\", or tell Anjoo: \"add task: call the supplier tomorrow\"." else "Nothing in this column."
                textSize = 14f; setTextColor(th.muted); setPadding(dp(6), dp(24), dp(6), 0)
            })
            return
        }
        for (o in shown) list.addView(card(o), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun card(o: JSONObject): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = box(th.surface, faint(), dp(12)); setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener { menu(o) }
        }
        c.addView(TextView(this).apply { text = "#" + o.optInt("id") + "  " + o.optString("title"); textSize = 15f; setTextColor(th.ink) })
        if (o.optString("note").isNotEmpty()) c.addView(TextView(this).apply { text = o.optString("note"); textSize = 13f; setTextColor(th.muted); setPadding(0, dp(4), 0, 0) })
        if (o.optString("due").isNotEmpty()) c.addView(TextView(this).apply { text = "⏰ " + o.optString("due"); textSize = 12f; setTextColor(th.accent); setPadding(0, dp(4), 0, 0) })
        if (o.has("agentStage")) {
            c.addView(TextView(this).apply {
                text = "🤖 " + o.optString("agentStage") + if (o.optString("agentActivity").isNotBlank()) "  ·  " + o.optString("agentActivity") else ""
                textSize = 12f; setTextColor(th.accent); setPadding(0, dp(6), 0, 0); maxLines = 2
            })
            val steps = o.optJSONArray("agentSteps")
            if (steps != null && steps.length() > 0) {
                val labels = ArrayList<String>()
                for (i in 0 until minOf(steps.length(), 6)) {
                    val st = steps.optJSONObject(i) ?: continue
                    val mark = when (st.optString("state")) { "done" -> "✓"; "doing" -> "›"; "review" -> "!"; else -> "○" }
                    labels.add("$mark " + st.optString("title"))
                }
                if (labels.isNotEmpty()) c.addView(TextView(this).apply {
                    text = labels.joinToString("\n"); textSize = 12f; setTextColor(th.muted); setPadding(0, dp(4), 0, 0)
                })
            }
        }
        if (o.optString("result").isNotEmpty()) c.addView(TextView(this).apply {
            text = "🤖 " + o.optString("result").take(400) + (if (o.optString("result").length > 400) "…" else "")
            textSize = 12.5f; setTextColor(th.ink); setPadding(0, dp(6), 0, 0)
        })
        return c
    }

    private fun menu(o: JSONObject) {
        val id = o.getInt("id")
        val actions = ArrayList<Pair<String, () -> Unit>>()
        val currentStatus = o.optString("status")
        val stage = o.optString("agentStage")
        for (c in Tasks.COLUMNS) if (c != currentStatus) {
            actions.add("➡️  Move to " + Tasks.LABELS[c] to {
                Tasks.move(this, id, c)
                refresh()
            })
        }
        if (o.has("agentStage") && currentStatus == "doing") {
            if (stage.equals("Paused", true) || stage.equals("Pausing", true)) {
                actions.add("▶️  Resume agent" to {
                    AgentOrchestrator.resume(this, id)
                    refresh()
                })
            } else {
                actions.add("⏸  Pause agent" to {
                    AgentOrchestrator.pause(this, id)
                    refresh()
                })
            }
            actions.add("⛔  Cancel agent run" to {
                AlertDialog.Builder(this).setMessage("Cancel this agent run? It will stop at the next safe checkpoint.")
                    .setPositiveButton("Cancel run") { _, _ -> AgentOrchestrator.cancel(this, id); refresh() }
                    .setNegativeButton("Keep running", null).show()
            })
        }
        actions.add("✏️  Edit" to { edit(o) })
        actions.add("▶️  Ask Anjoo to do it" to { runNow(o) })
        actions.add("🗑  Delete" to {
            AlertDialog.Builder(this).setMessage("Delete this task?")
                .setPositiveButton("Delete") { _, _ ->
                    if (o.optString("status") == "doing" && o.has("agentStage")) AgentOrchestrator.cancel(this, id)
                    Tasks.delete(this, id)
                    refresh()
                }
                .setNegativeButton("Cancel", null).show()
        })
        AlertDialog.Builder(this).setTitle(o.optString("title"))
            .setItems(actions.map { it.first }.toTypedArray()) { _, which -> actions.getOrNull(which)?.second?.invoke() }
            .show()
    }

    /** Lets Anjoo's agent work on the task in the background; the answer is written onto the card. */
    private fun runNow(o: JSONObject) {
        val id = o.getInt("id")
        Tasks.move(this, id, "doing")
        refresh()
        Toast.makeText(this, "Anjoo is working; the result will appear on the card.", Toast.LENGTH_LONG).show()
        val savedPrompt = o.optString("agentPrompt").trim()
        val prompt = savedPrompt.ifBlank { o.optString("title") + (if (o.optString("note").isNotEmpty()) "\n" + o.optString("note") else "") }
        AgentJobs.runTask(this, id, prompt)
    }

    private fun edit(o: JSONObject?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val t = EditText(this).apply { hint = "Task"; setText(o?.optString("title") ?: "") }
        val n = EditText(this).apply { hint = "Note (optional)"; setText(o?.optString("note") ?: "") }
        val d = EditText(this).apply { hint = "Due (optional, e.g. kal 5 baje)"; setText(o?.optString("due") ?: "") }
        box.addView(t); box.addView(n); box.addView(d)
        AlertDialog.Builder(this).setTitle(if (o == null) "New task" else "Edit task").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val title = t.text.toString().trim()
                if (title.isEmpty()) return@setPositiveButton
                if (o == null) Tasks.add(this, title, n.text.toString(), col, d.text.toString())
                else Tasks.update(this, o.getInt("id")) { it.put("title", title.take(120)).put("note", n.text.toString().trim().take(800)).put("due", d.text.toString().trim().take(40)) }
                refresh()
            }.setNegativeButton("Cancel", null).show()
    }
}
