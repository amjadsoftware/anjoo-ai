package com.anjoo.assistant

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Artifacts and docs: web pages, dashboards, small apps, slide decks (HTML) and documents, reports (Markdown) that Anjoo builds,
 * keeps in a library, can change later (every change is a saved version), and hands over as a file or a Wi-Fi link.
 * Phone storage is private to Anjoo: <filesDir>/artifacts/<id>/{meta.json, content.html|md, history/}.
 */
object Artifacts {
    const val AUTH = "com.anjoo.assistant.artifacts"
    val KINDS = listOf("page", "dashboard", "app", "slides", "document", "report")
    private const val MAX_CHARS = 2_000_000

    class Meta(val id: String, var title: String, var kind: String, val format: String, val created: Long, var updated: Long, var version: Int)

    // ---------- storage ----------

    private fun root(ctx: Context) = File(ctx.filesDir, "artifacts").also { it.mkdirs() }
    fun dir(ctx: Context, id: String) = File(root(ctx), id)
    fun formatOf(kind: String) = if (kind == "document" || kind == "report") "md" else "html"

    fun icon(kind: String) = when (kind) {
        "dashboard" -> "📊"; "app" -> "🧩"; "slides" -> "🎞"; "document" -> "📄"; "report" -> "📑"; else -> "🌐"
    }

    private fun readMeta(d: File): Meta? = try {
        val j = JSONObject(File(d, "meta.json").readText(Charsets.UTF_8))
        Meta(j.getString("id"), j.optString("title", "Untitled"), j.optString("kind", "page"), j.optString("format", "html"),
            j.optLong("created"), j.optLong("updated"), j.optInt("version", 1))
    } catch (e: Exception) { null }

    private fun writeMeta(ctx: Context, m: Meta) {
        val d = dir(ctx, m.id)
        d.mkdirs()
        File(d, "meta.json").writeText(JSONObject().put("id", m.id).put("title", m.title).put("kind", m.kind).put("format", m.format)
            .put("created", m.created).put("updated", m.updated).put("version", m.version).toString(), Charsets.UTF_8)
    }

    fun list(ctx: Context): List<Meta> =
        (root(ctx).listFiles()?.filter { it.isDirectory && !it.name.startsWith("_") } ?: emptyList()).mapNotNull { readMeta(it) }.sortedByDescending { it.updated }

    fun meta(ctx: Context, id: String): Meta? = readMeta(dir(ctx, id))

    private fun contentFile(ctx: Context, m: Meta) = File(dir(ctx, m.id), "content." + m.format)

    fun source(ctx: Context, m: Meta): String = try { contentFile(ctx, m).readText(Charsets.UTF_8) } catch (e: Exception) { "" }

    /** Finds an artifact by list number (1 = newest), id, exact title or part of the title. Blank / "latest" = newest. */
    fun find(ctx: Context, ref: String): Meta? {
        val all = list(ctx)
        if (all.isEmpty()) return null
        val r = ref.trim()
        if (r.isEmpty() || r.equals("latest", true) || r.equals("last", true)) return all.first()
        val n = r.toIntOrNull()
        if (n != null && n in 1..all.size) return all[n - 1]
        return all.firstOrNull { it.id == r } ?: all.firstOrNull { it.title.equals(r, true) } ?: all.firstOrNull { it.title.contains(r, true) }
    }

    /** Writes new content. The old content is kept as a version (last 25). */
    fun write(ctx: Context, m: Meta, content: String) {
        val d = dir(ctx, m.id)
        val cf = contentFile(ctx, m)
        if (cf.isFile) {
            val h = File(d, "history").also { it.mkdirs() }
            val old = File(h, m.version.toString() + "." + m.format)
            try { cf.copyTo(old, true); old.setLastModified(m.updated) } catch (e: Exception) {}
            val fs = h.listFiles()?.sortedByDescending { it.nameWithoutExtension.toIntOrNull() ?: 0 } ?: emptyList()
            for (f in fs.drop(25)) f.delete()
            m.version += 1
        }
        d.mkdirs()
        cf.writeText(content, Charsets.UTF_8)
        m.updated = System.currentTimeMillis()
        writeMeta(ctx, m)
    }

    class Ver(val number: Int, val time: Long, val current: Boolean)

    fun versions(ctx: Context, m: Meta): List<Ver> {
        val out = ArrayList<Ver>()
        out.add(Ver(m.version, m.updated, true))
        File(dir(ctx, m.id), "history").listFiles()?.forEach { f ->
            val n = f.nameWithoutExtension.toIntOrNull()
            if (n != null) out.add(Ver(n, f.lastModified(), false))
        }
        return out.sortedByDescending { it.number }
    }

    fun versionText(ctx: Context, m: Meta, number: Int): String? {
        if (number == m.version) return source(ctx, m)
        val f = File(File(dir(ctx, m.id), "history"), number.toString() + "." + m.format)
        return try { f.readText(Charsets.UTF_8) } catch (e: Exception) { null }
    }

    fun restore(ctx: Context, m: Meta, number: Int): Boolean {
        val t = versionText(ctx, m, number) ?: return false
        if (number == m.version) return true
        write(ctx, m, t)
        return true
    }

    fun rename(ctx: Context, m: Meta, title: String) {
        m.title = title.trim().take(80).ifEmpty { m.title }
        writeMeta(ctx, m)
    }

    fun delete(ctx: Context, m: Meta) { dir(ctx, m.id).deleteRecursively() }

    private fun newId(): String = "a" + java.lang.Long.toString(System.currentTimeMillis(), 36) + (1000 + (Math.random() * 8999).toInt())

    fun slug(t: String): String = t.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(32).ifEmpty { "artifact" }

    fun ago(t: Long): String {
        val s = (System.currentTimeMillis() - t) / 1000
        return when {
            s < 60 -> "just now"
            s < 3600 -> (s / 60).toString() + " min ago"
            s < 86400 -> (s / 3600).toString() + " h ago"
            else -> (s / 86400).toString() + " d ago"
        }
    }

    // ---------- rendering ----------

    /** True when an "html" artifact actually holds Markdown (no real HTML tags) - e.g. the model sent "# Invoice | **Date:**" text. */
    fun looksLikeMarkdown(src: String): Boolean {
        val h = src.take(6000)
        if (Regex("(?is)<(html|!doctype|body|div|table|section|main|header|h[1-6]|p|span|style)\\b").containsMatchIn(h)) return false
        return Regex("(?m)^\\s{0,3}#{1,6}\\s+\\S").containsMatchIn(h) || h.contains("**") ||
            Regex("(?m)^\\s*\\|.*\\|\\s*$").containsMatchIn(h) || Regex("(?m)^\\s*[-*]\\s+\\S").containsMatchIn(h)
    }

    private fun ensureHtml(src: String, title: String): String =
        if (Regex("(?is)<html|<!doctype").containsMatchIn(src.take(3000))) src
        else if (looksLikeMarkdown(src)) MdHtml.page(title, MdHtml.render(src))
        else "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>" +
            MdHtml.esc(title) + "</title></head><body>" + src + "</body></html>"

    /** The complete page for the viewer, the Wi-Fi link and HTML export. */
    fun pageHtml(m: Meta, src: String): String =
        if (m.format == "html") ensureHtml(src, m.title) else MdHtml.page(m.title, MdHtml.render(src))

    private fun plainText(m: Meta, src: String): String {
        if (m.format == "md") return src
        var s = Regex("(?is)<(script|style|head)\\b.*?</\\1>").replace(src, " ")
        s = Regex("(?is)<br\\s*/?>|</(p|div|li|tr|h[1-6]|section)>").replace(s, "\n")
        s = Regex("(?s)<[^>]+>").replace(s, "")
        s = s.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&amp;", "&")
        return s.replace(Regex("[ \\t]+"), " ").replace(Regex("\\n\\s*\\n+"), "\n\n").trim()
    }

    /** One export file: (file name, bytes, mime). format = html | md | txt | doc. Returns null when that format does not fit. */
    fun export(ctx: Context, m: Meta, format: String): Triple<String, ByteArray, String>? {
        val src = source(ctx, m)
        val base = slug(m.title) + "-v" + m.version
        return when (format.lowercase().removePrefix(".")) {
            "html", "htm" -> Triple("$base.html", pageHtml(m, src).toByteArray(Charsets.UTF_8), "text/html")
            "md", "markdown" -> if (m.format == "md") Triple("$base.md", src.toByteArray(Charsets.UTF_8), "text/markdown") else null
            "txt", "text" -> Triple("$base.txt", plainText(m, src).toByteArray(Charsets.UTF_8), "text/plain")
            "doc", "word", "docx" -> {
                val body = if (m.format == "md") MdHtml.render(src) else Regex("(?is)<body[^>]*>(.*?)</body>").find(src)?.groupValues?.get(1) ?: src
                Triple("$base.doc", MdHtml.wordDoc(m.title, body).toByteArray(Charsets.UTF_8), "application/msword")
            }
            else -> null
        }
    }

    // ---------- opening and sharing ----------

    fun openLibrary(ctx: Context) {
        ctx.startActivity(Intent(ctx, ArtifactActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun open(ctx: Context, id: String, print: Boolean = false) {
        ctx.startActivity(Intent(ctx, ArtifactActivity::class.java).putExtra("id", id).putExtra("print", print)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }

    private fun toClipboard(ctx: Context, label: String, text: String) {
        Handler(Looper.getMainLooper()).post {
            try { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text)) } catch (e: Exception) {}
        }
    }

    /** Opens the system share sheet with the artifact as a file (html / md / doc). */
    fun shareFile(ctx: Context, m: Meta, format: String): String {
        val ex = export(ctx, m, format) ?: return "Is artifact ko '" + format + "' (Markdown is only for documents/reports). Choose html, txt or doc."
        val d = File(root(ctx), "_share").also { it.mkdirs() }
        d.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 24 * 3600 * 1000L) it.delete() }
        File(d, ex.first).writeBytes(ex.second)
        val uri = Uri.parse("content://$AUTH/" + Uri.encode(ex.first))
        val i = Intent(Intent.ACTION_SEND).setType(ex.third).putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_SUBJECT, m.title)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri(ex.first, uri)
        ctx.startActivity(Intent.createChooser(i, "Share " + m.title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened the share screen: " + ex.first + " (" + ex.second.size + " bytes). Choose the app you want to send it with."
    }

    fun shareText(ctx: Context, m: Meta): String {
        val t = plainText(m, source(ctx, m))
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, m.title)
            .putExtra(Intent.EXTRA_TEXT, t), "Share " + m.title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Opened the share screen (as text)."
    }

    /** Starts the Wi-Fi link (asks first). Returns the links, or an explanation. */
    fun shareLink(ctx: Context, m: Meta, confirm: (String) -> Boolean): String {
        if (!confirm(Confirm.msg("action", "Share '" + m.title + "' on Wi-Fi?",
                "A link will be created that opens on another phone or laptop connected to this same Wi-Fi/hotspot. Only this artifact will be shown, and it stops after 60 minutes. Anyone who has the link can view it."))) {
            return "The user declined to create the link."
        }
        val r = ArtifactServer.share(ctx, m.id)
        if (r.startsWith("ERR:")) return r.removePrefix("ERR:")
        val first = r.lines().first()
        toClipboard(ctx, "Anjoo link", first)
        return "Link ready (also copied):\n" + r + "\n\nThis only works on this same Wi-Fi/hotspot, while the Anjoo app is running, and it stops after 60 minutes. " +
            "A link visible to everyone on the internet (hosting) is not available in this app; share the file for that."
    }

    // ---------- generation (the model writes the artifact) ----------

    private const val HTML_RULES = "You build ONE complete, self-contained, production-quality HTML file. Output ONLY the HTML (start with <!doctype html>), no markdown fences, no explanation. " +
        "Inline all CSS and JavaScript in the file. No external images; draw with CSS, inline SVG, canvas or emoji. If you need a library, load it only from https://cdnjs.cloudflare.com with a pinned version. " +
        "Mobile-first and responsive (viewport meta tag, flexible layout, touch-friendly 44px targets), works in portrait and landscape. Use CSS variables and support both light and dark mode with prefers-color-scheme. " +
        "Distinctive, polished design: a deliberate colour palette, good typography with system font stack, spacing, subtle shadows and transitions; never a plain default look. " +
        "Interactive parts must really work (no placeholders or TODO). Handle empty and error states. Use realistic sample data only when the user gave none. " +
        "Do not use localStorage for anything required to function (keep state in JavaScript variables); it is fine only for small optional conveniences wrapped in try/catch. " +
        "Write the visible text in the language the user used (Urdu, Roman Urdu or English); for Urdu add dir=\"rtl\" where needed."

    private val MAP_WORDS = Regex("(?i)\\b(world map|map|maps|naqsha|naqshe|atlas|globe|earth)\\b")
    private const val MAP_RULES = " MAP DESIGN (mandatory): build a REAL working map, never an empty box. Load Leaflet 1.9.4 (leaflet.min.css as <link> and leaflet.min.js as <script>) from https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/ and OpenStreetMap tiles https://tile.openstreetmap.org/{z}/{x}/{y}.png with attribution. The map container must have an explicit height (use 100dvh minus the toolbar) and you must call map.invalidateSize() after load and on resize. World view: center [20,0], zoom 2, minZoom 2, maxBounds [[-85,-180],[85,180]]. Pinch/drag zoom, +/- buttons, a search box that calls https://nominatim.openstreetmap.org/search?format=json&q= and flies to the result, and a My location button using navigator.geolocation. If tiles or the library fail to load (offline), show a clear message in Urdu/English: Internet chahiye, map load nahi hua, with a Retry button. Do not draw a fake map with CSS."
    private val INVOICE_WORDS = Regex("(?i)\\b(invoice|bill|receipt|quotation|quote|estimate|challan|voucher|purchase order|statement)\\b|invoice|bill")

    private val BILL_REQ = Regex("(?i)(\\b(invoice|receipt|quotation|challan|voucher|bill|payslip|salary slip)\\b|इनवॉइस|इन्वॉइस|इनवाइस|रसीद|(^|\\s)(बिल|انوائس|بل|رسید)(\\s|$|[.،?!]))")
    private val REAL_CODE_REQ = Regex("(?i)\\b(code|coding|html|css|javascript|python|kotlin|java|script|program|api|backend|apk|github|source)\\b")

    /** An invoice / bill / receipt request is a document to SHOW, never a coding project. */
    fun isBillRequest(text: String): Boolean = BILL_REQ.containsMatchIn(text) && !REAL_CODE_REQ.containsMatchIn(text)

    private val MAKE_VERB = Regex("(?i)(\\b(bana|banao|bnao|bna|banado|banana|banaye|banayen|create|make|generate|design|template|dikhao|dikha|dikhana|show|draw)\\b|बना|दिखा|بنا|دکھا)")

    /** A request to MAKE/show a bill (not a question about a bill, like "bijli ka bill kitna hai"). */
    fun isBillMake(text: String): Boolean = isBillRequest(text) && MAKE_VERB.containsMatchIn(text)

    private val SHOW_HERE = Regex("(?i)(chat\\s*(mein|me|m)\\s*(do|dikha|dikhao|show)|yahan\\s*(dikha|do|show)|yahin|show (it )?here|dikhao yahan|यहां|चैट में|یہاں)")

    /** True when the person asks to see the thing right here in the chat. */
    fun wantsHere(text: String): Boolean = SHOW_HERE.containsMatchIn(text)

    /** Builds the bill as an artifact (rendered live in the chat) when the model wrongly picked a coding tool. */
    fun billInstead(ctx: Context, text: String): String =
        create(ctx, JSONObject().put("kind", "page").put("title", text.take(60)).put("description", text))

    private const val INVOICE_RULES = " INVOICE / BILL DESIGN (mandatory): output real HTML+CSS, never Markdown symbols (#, **, |, ---). Layout on a white A4-style card (max-width 800px, centered, 16-24px radius on screen, soft shadow, 28px padding; on print remove shadow, margin 0). " +
        "1) Header: coloured band or top accent bar with the shop name as a big bold logo-style wordmark (CSS/emoji monogram, no external images) on the left; on the right a large 'INVOICE' label, invoice number, issue date and due date. " +
        "2) Two-column 'Billed To' and 'From' blocks (name, address, phone, NTN/GST no.) in small muted uppercase labels with bold values; stack them on narrow screens. " +
        "3) Items table: <table> with thead (#, Item description, Qty, Unit price, Amount), zebra rows, right-aligned numeric columns with tabular-nums, currency shown like 'Rs 1,200' or 'PKR 1,200' with thousands separators, wrapped in an overflow-x:auto container. " +
        "4) Payment summary: a separate right-aligned card (Subtotal, Discount if any, GST/Tax with rate, bold Total Due in a highlighted accent box); the numbers MUST be arithmetically correct (recompute sums and tax). " +
        "5) Footer: payment method/bank or Easypaisa/JazzCash details only if the user gave them, terms and notes, a 'Thank you for shopping with us' line, website/helpline, and a status badge (PAID / UNPAID) as a rounded pill. " +
        "Use one accent colour (e.g. brand red or teal) as a CSS variable, system font stack, 15-16px base size, generous spacing, a Print / Save PDF button hidden in @media print, and light + dark mode. Use real item rows the user gave; if none were given, make realistic sample rows and say they are sample data."

    private const val DOC_RULES = "You write ONE complete, well-organised document in Markdown. Output ONLY the Markdown (no code fences around the whole thing, no preface or closing remarks). " +
        "Start with a single # title, then a short intro, then clear ## sections and ### subsections, lists, tables where comparing, **bold** for key terms. " +
        "Be specific and substantive, not generic; use real numbers, names and steps from the user's request. Finish every section (no TODO or placeholders). " +
        "Write in the language the user used (Urdu, Roman Urdu or English)."

    private const val KIND_HINT = "page = a web page or landing page; dashboard = charts/tables/KPIs with filters; app = a working small tool, calculator or game; " +
        "slides = a slide deck as one HTML page with a slide per screen, next/previous buttons, arrow-key and swipe navigation and a progress indicator; " +
        "document = letter, resume, guide, notes, article, proposal or plan; report = structured analysis with summary, findings and recommendations."

    private fun strip(s: String): String {
        var t = s.trim()
        if (t.startsWith("```")) t = t.substringAfter("\n")
        if (t.endsWith("```")) t = t.substringBeforeLast("```")
        return t.trim()
    }

    /** Asks the model. Returns the content, or a text starting with "ERR:". */
    /** One plain model call (used by the Website Builder planner). Returns "ERR:..." on failure. */
    fun askPublic(ctx: Context, system: String, text: String): String = ask(ctx, system, text)

    private fun ask(ctx: Context, system: String, text: String): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        Providers.load(p)
        val key = p.getString("key", "") ?: ""
        if (key.isEmpty()) return "ERR:Add an API key in Settings first."
        val model = p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
        val out = try {
            strip(Gemini.plain(key, model, system, JSONArray().put(JSONObject().put("text", text)), 14000))
        } catch (e: Exception) { return "ERR:" + (e.message ?: e.javaClass.simpleName) }
        return if (out.isBlank()) "ERR:Nothing could be created, please try again." else out
    }

    private fun looksComplete(format: String, out: String): Boolean =
        if (format == "html") out.contains("</html>", true) || out.contains("</body>", true) || out.length < 3000 else true

    // ---------- tools ----------

    fun create(ctx: Context, a: JSONObject): String {
        val title0 = a.optString("title", "").trim()
        val desc = a.optString("description", "").trim()
        val given = a.optString("content", "")
        var kind = a.optString("kind", "").trim().lowercase().ifEmpty { "page" }
        if (kind !in KINDS) kind = when {
            kind.contains("dash") -> "dashboard"; kind.contains("slide") || kind.contains("deck") || kind.contains("ppt") -> "slides"
            kind.contains("report") -> "report"; kind.contains("doc") || kind.contains("letter") || kind.contains("resume") || kind.contains("cv") -> "document"
            kind.contains("app") || kind.contains("tool") || kind.contains("game") || kind.contains("calc") -> "app"
            else -> "page"
        }
        if (title0.isEmpty() && desc.isEmpty() && given.isBlank()) return "What should I create? Give a title or description."
        if (Guard.hasCardData(desc) || Guard.hasCardData(given)) return Guard.CARD_MSG
        val format = formatOf(kind)
        val title = title0.ifEmpty { desc.take(50) }.take(80)
        var content = strip(given)
        // The model sometimes passes Markdown for a page/invoice. Never store that as the page: generate real styled HTML instead.
        if (format == "html" && content.isNotBlank() && looksLikeMarkdown(content)) {
            if (INVOICE_WORDS.containsMatchIn(title + " " + desc)) {
                val ref = content
                content = ""
                val d2 = (desc.ifEmpty { title }) + "\n\nUse exactly these details/items (convert them into the designed HTML invoice):\n" + ref.take(6000)
                val out = ask(ctx, HTML_RULES + " Kind: $kind. ($KIND_HINT)" + INVOICE_RULES, "Title: $title\nWhat to build:\n$d2")
                content = if (out.startsWith("ERR:")) MdHtml.page(title, MdHtml.render(ref)) else out
            } else content = MdHtml.page(title, MdHtml.render(content))
        }
        if (content.isBlank()) {
            val sys = (if (format == "html") HTML_RULES else DOC_RULES) + " Kind: $kind. ($KIND_HINT)" +
                (if (INVOICE_WORDS.containsMatchIn(title + " " + desc)) INVOICE_RULES else "") +
                (if (format == "html" && MAP_WORDS.containsMatchIn(title + " " + desc)) MAP_RULES else "")
            content = ask(ctx, sys, "Title: $title\nWhat to build:\n" + desc.ifEmpty { title })
            if (content.startsWith("ERR:")) return content.removePrefix("ERR:")
        }
        if (content.length > MAX_CHARS) return "The content is too large (over 2 MB)."
        val now = System.currentTimeMillis()
        val m = Meta(newId(), title, kind, format, now, now, 1)
        write(ctx, m, content)
        val inChat = ctx is MainActivity
        if (!inChat) open(ctx, m.id)
        val warn = if (!looksComplete(format, content)) "\nNote: the output looks incomplete; ask update_artifact to 'finish it'." else ""
        return (if (inChat) "Artifact created, the chat will show the card and preview: '" else "Artifact created and opened on screen: '") +
            title + "' (" + kind + ", " + content.length + " chars, id " + m.id + ")." + warn +
            "\nNext: update_artifact (changes), export_artifact (html/doc/txt/md/pdf), share_artifact (file or Wi-Fi link)." +
            (if (inChat) " [artifact:" + m.id + "]" else "")
    }

    fun update(ctx: Context, a: JSONObject): String {
        val m = find(ctx, a.optString("artifact", "")) ?: return "No such artifact found. Check with list_artifacts."
        val cur = source(ctx, m)
        val oldT = a.optString("old_text", "")
        val instr = a.optString("instruction", "").trim()
        if (Guard.hasCardData(oldT) || Guard.hasCardData(a.optString("new_text", "")) || Guard.hasCardData(instr)) return Guard.CARD_MSG
        val next: String
        if (oldT.isNotEmpty()) {
            val nw = a.optString("new_text", "")
            val n = cur.split(oldT).size - 1
            if (n == 0) return "old_text not found in the artifact. Read the exact text with read_artifact and give it again."
            if (n > 1 && !a.optBoolean("replace_all", false)) return "old_text appears in $n places; give a longer part or pass replace_all=true."
            next = if (a.optBoolean("replace_all", false)) cur.replace(oldT, nw) else cur.replaceFirst(oldT, nw)
        } else if (instr.isNotEmpty()) {
            val sys = (if (m.format == "html") HTML_RULES else DOC_RULES) +
                (if (m.format == "html" && INVOICE_WORDS.containsMatchIn(m.title)) INVOICE_RULES else "") +
                (if (m.format == "html" && MAP_WORDS.containsMatchIn(m.title)) MAP_RULES else "") +
                " You are EDITING the file below. Apply ONLY the change the user asks for, keep everything else exactly as it is (same design, content, structure), and return the COMPLETE updated file."
            val out = ask(ctx, sys, "CURRENT FILE:\n" + cur + "\n\nCHANGE REQUESTED:\n" + instr)
            if (out.startsWith("ERR:")) return out.removePrefix("ERR:")
            if (cur.length > 2000 && out.length < cur.length * 0.4) return "The model's answer was much shorter than the original, so nothing was changed (to avoid breaking something). Ask again or make a small change with old_text/new_text."
            next = out
        } else return "What should change? Give an instruction, or old_text + new_text."
        if (next.length > MAX_CHARS) return "The content is too large (over 2 MB)."
        write(ctx, m, next)
        val inChat = ctx is MainActivity
        if (!inChat) open(ctx, m.id)
        return "Artifact '" + m.title + "' updated (version " + m.version + "). The old version is in the history." +
            (if (inChat) " The chat will show the new card and preview. [artifact:" + m.id + "]" else "")
    }

    fun read(ctx: Context, a: JSONObject): String {
        val m = find(ctx, a.optString("artifact", "")) ?: return "No such artifact found. Check with list_artifacts."
        val lines = source(ctx, m).split("\n")
        val off = a.optInt("offset", 1).coerceAtLeast(1)
        val lim = a.optInt("limit", 200).coerceIn(1, 600)
        if (off > lines.size) return "offset ($off) is outside the file's lines (" + lines.size + ")."
        val end = minOf(lines.size, off - 1 + lim)
        val sb = StringBuilder("ARTIFACT '" + m.title + "' (" + m.kind + ", " + m.format + ", v" + m.version + ") lines $off-$end of " + lines.size + ":\n")
        for (i in (off - 1) until end) sb.append(i + 1).append("\t").append(lines[i].take(600)).append('\n')
        if (end < lines.size) sb.append("[more: offset=").append(end + 1).append(" to continue]")
        return sb.toString().trimEnd()
    }

    fun listText(ctx: Context, q: String): String {
        val all = list(ctx)
        val shown = all.withIndex().filter { q.isBlank() || it.value.title.contains(q, true) || it.value.kind.contains(q, true) }
        if (shown.isEmpty()) return if (all.isEmpty()) "There are no artifacts yet. Create one with create_artifact." else "No artifact with this name found."
        return shown.joinToString("\n") { (i, m) -> "${i + 1}. " + icon(m.kind) + " " + m.title + " [" + m.kind + ", v" + m.version + ", " + ago(m.updated) + ", id " + m.id + "]" }
    }

    fun exportTool(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val m = find(ctx, a.optString("artifact", "")) ?: return "No such artifact found. Check with list_artifacts."
        val fmt = a.optString("format", "html").trim().lowercase().ifEmpty { "html" }
        if (fmt == "pdf") {
            open(ctx, m.id, true)
            return "Opened the print screen: choose 'Save as PDF' there (the PDF is saved on the phone)."
        }
        val ex = export(ctx, m, fmt) ?: return "Is artifact ko '" + fmt + "' (md is only for documents/reports). Choose html, txt, doc or pdf."
        val folder0 = a.optString("folder", "").ifBlank { FileAccess.defaultFolder(ctx).ifBlank { "Documents/Anjoo" } }
        return FileAccess.write(ctx, "$folder0/Artifacts", ex.first, ex.second, false) { p -> confirm(Confirm.msg("overwrite", "Overwrite this file?", p)) }
    }

    fun shareTool(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val m = find(ctx, a.optString("artifact", "")) ?: return "No such artifact found. Check with list_artifacts."
        return when (a.optString("how", "file").trim().lowercase()) {
            "link", "wifi", "url" -> shareLink(ctx, m, confirm)
            "text" -> shareText(ctx, m)
            else -> shareFile(ctx, m, a.optString("format", "html").ifBlank { "html" })
        }
    }

    fun deleteTool(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val m = find(ctx, a.optString("artifact", "")) ?: return "No such artifact found."
        if (!confirm(Confirm.msg("delete", "Delete this artifact?", m.title + " (" + m.kind + ", v" + m.version + ") and all its versions will be removed permanently."))) return "The user declined to delete it."
        delete(ctx, m)
        return "'" + m.title + "' deleted."
    }

    fun tool(ctx: Context, confirm: (String) -> Boolean, name: String, a: JSONObject): String? = when (name) {
        "create_artifact" -> create(ctx, a)
        "update_artifact" -> update(ctx, a)
        "read_artifact" -> read(ctx, a)
        "list_artifacts" -> listText(ctx, a.optString("query", ""))
        "open_artifact" -> (find(ctx, a.optString("artifact", ""))?.let { if (ctx is MainActivity) "The chat will show the card and preview: " + it.title + " [artifact:" + it.id + "]" else { open(ctx, it.id); "Opened on screen: " + it.title } } ?: "No such artifact found. Check with list_artifacts.")
        "export_artifact" -> exportTool(ctx, confirm, a)
        "share_artifact" -> shareTool(ctx, confirm, a)
        "stop_sharing" -> { ArtifactServer.stop(); "Wi-Fi link stopped." }
        "delete_artifact" -> deleteTool(ctx, confirm, a)
        else -> null
    }
}
