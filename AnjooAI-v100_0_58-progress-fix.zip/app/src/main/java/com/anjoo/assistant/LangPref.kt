package com.anjoo.assistant

import android.content.Context
import java.util.Locale

/**
 * Anjoo AI language system.
 * Choices: Any language (default, answers in the language the user speaks), Phone Default, English, Roman Urdu, Urdu (script), Arabic.
 * "phone" follows the device locale. All others force the AI to reply in that language.
 */
object LangPref {

    const val MATCH   = "match"      // understand any language and answer in the language the user spoke
    const val PHONE   = "phone"      // follow device locale
    const val ENGLISH = "en"
    const val ROMAN   = "roman"      // Roman Urdu (Latin letters)
    const val URDU    = "ur"         // اردو script
    const val ARABIC  = "ar"         // العربية

    data class Lang(
        val key: String,
        val label: String,          // shown in settings pill
        val nativeLabel: String,    // in that script
        val rtl: Boolean = false,
    )

    val ALL = listOf(
        Lang(MATCH,   "Any language (auto)", "Any language"),
        Lang(PHONE,   "Phone Default",  "Phone Default"),
        Lang(ENGLISH, "English",        "English"),
        Lang(ROMAN,   "Roman Urdu",     "Roman Urdu"),
        Lang(URDU,    "Urdu",           "اردو",  rtl = true),
        Lang(ARABIC,  "Arabic",         "العربية", rtl = true),
    )

    fun get(ctx: Context): String =
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
           .getString("appLang", MATCH) ?: MATCH

    fun set(ctx: Context, key: String) =
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
           .edit().putString("appLang", key).apply()

    /** The user may speak any language; the answer must be in that same language and script. */
    const val MIRROR = "LANGUAGE: You understand and speak every language. Always reply in the exact language and script the user used in their latest message or speech " +
        "(English to English, Urdu script to Urdu script, Roman Urdu to Roman Urdu, Hindi, Arabic, Punjabi, Pashto, Sindhi, Bengali, Turkish, French, Spanish, Chinese and any other). " +
        "If they switch language, switch in your very next reply. If they mix languages, mix the same way. " +
        "Never fall back to English or Urdu when they spoke another language; if their speech was unclear, ask briefly in the language you think they used.\n"

    /** Single-line system-prompt instruction injected into every call. */
    fun promptBlock(ctx: Context): String = when (get(ctx)) {
        MATCH -> MIRROR

        ENGLISH ->
            "LANGUAGE: Always reply in English only, no matter what language the user writes in. Keep Anjoo's warm, friendly tone in English.\n"

        ROMAN ->
            "LANGUAGE: Hamesha Roman Urdu mein jawab do (English haroof, Urdu alfaz — jaise 'aap kaise hain', 'main samajh gaya'). " +
            "Koi Urdu ya Arabic script nahi, sirf Latin haroof. English technical terms jaise hain waise raho.\n"

        URDU ->
            "LANGUAGE: ہمیشہ خالص اردو رسم الخط میں جواب دیں (نستعلیق/اردو حروف)۔ " +
            "رومن اردو یا انگریزی میں جواب مت دیں۔ تکنیکی اصطلاحات جوں کی توں رکھیں۔\n"

        ARABIC ->
            "LANGUAGE: أجب دائماً باللغة العربية الفصحى (MSA) بغض النظر عن لغة المستخدم. " +
            "لا ترد بالإنجليزية أو الأردية. احتفظ بالمصطلحات التقنية كما هي.\n"

        else -> {  // PHONE — auto-detect from system locale
            val tag = Locale.getDefault().language
            when {
                tag == "ar" ->
                    "LANGUAGE: أجب دائماً باللغة العربية الفصحى.\n"
                tag == "ur" ->
                    "LANGUAGE: Jawab usi script mein do jis mein user ne likha (Urdu script ya Roman Urdu ya English).\n"
                tag.startsWith("en") -> MIRROR
                else ->
                    "LANGUAGE: Reply in the same language the user writes in.\n"
            }
        }
    }

    /** True when current language is RTL. */
    fun isRtl(ctx: Context): Boolean = ALL.firstOrNull { it.key == get(ctx) }?.rtl == true

    /** Label to show in the settings button/pill. */
    fun label(ctx: Context): String = ALL.firstOrNull { it.key == get(ctx) }?.label ?: "Phone Default"
}

/** Which language(s) the phone's speech recognizers should listen for. Pure, so it can be tested on the JVM. */
object SpeechLang {
    /** Returns the main language and the extra languages to listen for, for the saved "lang" preference. */
    fun pick(pref: String, deviceTag: String): Pair<String, Array<String>> = when (pref) {
        "any" -> Pair(deviceTag.ifBlank { "en-US" }, arrayOf("en-US", "ur-PK", "hi-IN", "ar-SA", "pa-IN").filter { !it.equals(deviceTag, true) }.toTypedArray())
        "en-US" -> Pair("en-US", arrayOf("ur-PK"))
        else -> Pair("ur-PK", arrayOf("en-US"))   // "ur-PK" and "auto" (Urdu + English mixed)
    }
}
