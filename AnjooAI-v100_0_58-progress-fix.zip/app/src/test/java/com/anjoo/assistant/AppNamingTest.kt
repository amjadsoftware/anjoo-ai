package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AppNamingTest {
    @Test fun versionsCopiesAndSeparatorsAreCleaned() {
        assertEquals("Anjoo AI", AppNaming.fromZipName("AnjooAI-v100_0_51.zip"))
        assertEquals("Offline Battle Royale", AppNaming.fromZipName("offline_battle_royale (1).zip"))
        assertEquals("My Game", AppNaming.fromZipName("my-game-1.2.3.zip"))
        assertEquals("PUBG Mobile", AppNaming.fromZipName("PUBGMobile-v2.zip"))
    }

    @Test fun realNamesAreKept() {
        assertEquals("Ludo Game 2", AppNaming.fromZipName("Ludo Game 2.zip"))
        assertEquals("iPhone Game", AppNaming.fromZipName("iPhone Game.zip"))
        assertEquals("Offline Battle Royale", AppNaming.fromZipName("Offline Battle Royale"))
    }

    @Test fun emptyAndLongNamesAreHandled() {
        assertEquals("My App", AppNaming.fromZipName("   .zip"))
        val long = AppNaming.fromZipName("VeryLongNameThatKeepsGoingAndGoingForever.zip")
        assertTrue(long, long.length <= 30 && long.startsWith("Very Long Name"))
    }
}
