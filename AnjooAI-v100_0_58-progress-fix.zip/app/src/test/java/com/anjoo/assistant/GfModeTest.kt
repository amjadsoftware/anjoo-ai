package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class GfModeTest {
    @Test fun gfSwitchesOn() {
        assertEquals(true, GfLogic.trigger("GF"))
        assertEquals(true, GfLogic.trigger("gf mode on"))
        assertEquals(true, GfLogic.trigger("gf ban jao!"))
    }
    @Test fun normalSwitchesOff() {
        assertEquals(false, GfLogic.trigger("normal"))
        assertEquals(false, GfLogic.trigger("GF off"))
    }
    @Test fun talkingAboutAGfIsNotASwitch() {
        assertNull(GfLogic.trigger("meri gf ko message bhejo"))
        assertNull(GfLogic.trigger("gf ke liye gift idea do"))
        assertNull(GfLogic.trigger("aaj mausam kaisa hai"))
        assertNull(GfLogic.trigger("is it normal"))
    }
    @Test fun naturalAndMisheardPhrasesWork() {
        assertEquals(true, GfLogic.trigger("gf mode on kar do"))
        assertEquals(true, GfLogic.trigger("GF mod on karo"))
        assertEquals(true, GfLogic.trigger("G F mode on"))
        assertEquals(true, GfLogic.trigger("girlfriend mode on"))
        assertEquals(true, GfLogic.trigger("ab gf mode chalu karo"))
        assertEquals(false, GfLogic.trigger("gf mode band karo"))
        assertEquals(false, GfLogic.trigger("GF mode off kar do"))
        assertEquals(false, GfLogic.trigger("wapis normal ho jao"))
        assertEquals(false, GfLogic.trigger("assistant mode"))
    }
    @Test fun urduAndHindiLettersWork() {
        assertEquals(true, GfLogic.trigger("جی ایف موڈ آن"))
        assertEquals(false, GfLogic.trigger("जीएफ मोड बंद"))
    }
    @Test fun longSentencesAreNeverSwitches() {
        assertNull(GfLogic.trigger("gf mode on karo aur phir mujhe kal ka mausam bhi batao please"))
    }
}
