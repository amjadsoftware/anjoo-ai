package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class ProjectCheckTest {
    @get:Rule val tmp = TemporaryFolder()

    private fun write(root: File, rel: String, text: String) {
        val f = File(root, rel)
        f.parentFile?.mkdirs()
        f.writeText(text)
    }

    private fun goodNative(root: File) {
        write(root, "settings.gradle.kts", "rootProject.name = \"Demo\"\ninclude(\":app\")\n")
        write(root, "build.gradle.kts", "plugins { id(\"com.android.application\") version \"8.5.2\" apply false }\n")
        write(root, "gradle.properties", "android.useAndroidX=true\n")
        write(root, "app/build.gradle.kts",
            "plugins { id(\"com.android.application\"); id(\"org.jetbrains.kotlin.android\") }\n" +
            "android { namespace = \"com.demo.app\"; defaultConfig { applicationId = \"com.demo.app\" } }\n" +
            "dependencies { implementation(\"androidx.core:core-ktx:1.13.1\") }\n")
        write(root, "app/src/main/AndroidManifest.xml",
            "<manifest xmlns:android=\"http://schemas.android.com/apk/res/android\"><application android:label=\"@string/app_name\" android:icon=\"@mipmap/ic_launcher\">" +
            "<activity android:name=\".MainActivity\" android:exported=\"true\"><intent-filter><category android:name=\"android.intent.category.LAUNCHER\"/></intent-filter></activity></application></manifest>")
        write(root, "app/src/main/res/values/strings.xml", "<resources><string name=\"app_name\">Demo</string></resources>")
        write(root, "app/src/main/res/mipmap-hdpi/ic_launcher.png", "png")
        write(root, "app/src/main/java/com/demo/app/MainActivity.kt", "package com.demo.app\nclass MainActivity\n")
    }

    @Test fun completeNativeProjectHasNoFindings() {
        val root = tmp.newFolder("native")
        goodNative(root)
        val r = ProjectCheck.check(root)
        assertEquals("native", r.kind)
        assertTrue(r.findings.toString(), r.findings.isEmpty())
    }

    @Test fun nativeProjectProblemsAreReported() {
        val root = tmp.newFolder("broken")
        goodNative(root)
        File(root, "app/src/main/AndroidManifest.xml").delete()
        File(root, "gradle.properties").delete()
        val texts = ProjectCheck.check(root).errors.map { it.text }
        assertTrue(texts.any { it.contains("AndroidManifest.xml is missing") })
        assertTrue(texts.any { it.contains("android.useAndroidX") })
    }

    @Test fun missingIconAndStringAndActivityAreErrors() {
        val root = tmp.newFolder("res")
        goodNative(root)
        File(root, "app/src/main/res/mipmap-hdpi/ic_launcher.png").delete()
        File(root, "app/src/main/res/values/strings.xml").writeText("<resources></resources>")
        File(root, "app/src/main/java/com/demo/app/MainActivity.kt").delete()
        write(root, "app/src/main/java/com/demo/app/Other.kt", "package com.demo.app\nclass Other\n")
        val texts = ProjectCheck.check(root).errors.map { it.text }
        assertTrue(texts.any { it.contains("@mipmap/ic_launcher") })
        assertTrue(texts.any { it.contains("@string/app_name") })
        assertTrue(texts.any { it.contains("MainActivity") })
    }

    @Test fun websiteWithRelativeFilesIsClean() {
        val root = tmp.newFolder("web")
        write(root, "index.html", "<html><head><link rel=\"stylesheet\" href=\"style.css\"></head><body><h1>Hello app</h1><p>This page has enough text to not look empty at all, really.</p><script src=\"app.js\"></script></body></html>")
        write(root, "style.css", "body{}")
        write(root, "app.js", "console.log(1)")
        val r = ProjectCheck.check(root)
        assertEquals("web", r.kind)
        assertTrue(r.findings.toString(), r.findings.isEmpty())
    }

    @Test fun sourceOnlyWebsiteIsAnErrorAndCdnIsAWarning() {
        val root = tmp.newFolder("vite")
        write(root, "index.html", "<html><body><div id=\"root\"></div><script type=\"module\" src=\"/src/main.jsx\"></script><script src=\"https://cdn.example.com/lib.js\"></script>padding padding padding padding padding padding padding padding</body></html>")
        val r = ProjectCheck.check(root)
        assertTrue(r.errors.any { it.text.contains("source files") })
        assertTrue(r.warnings.any { it.text.contains("cdn.example.com") })
    }

    @Test fun emptyFolderHasNothingToBuild() {
        val r = ProjectCheck.check(tmp.newFolder("empty"))
        assertEquals("none", r.kind)
        assertEquals(1, r.errors.size)
    }
}
