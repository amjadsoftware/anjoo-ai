package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BuildLogParserTest {
    @Test fun gradleWhatWentWrongAndKotlinErrorsAreKept() {
        val log = listOf(
            "2026-11-20T10:00:00.1234567Z ##[group]Run gradle assembleDebug",
            "2026-11-20T10:00:05.0000000Z > Task :app:compileDebugKotlin FAILED",
            "2026-11-20T10:00:05.0000001Z e: file:///home/runner/work/hs/hs/hs-work/source/app/src/Main.kt:12:5 Unresolved reference: foo",
            "2026-11-20T10:00:06.0000000Z FAILURE: Build failed with an exception.",
            "2026-11-20T10:00:06.0000001Z * What went wrong:",
            "2026-11-20T10:00:06.0000002Z Execution failed for task ':app:compileDebugKotlin'.",
            "2026-11-20T10:00:06.0000003Z > Compilation error. See log for more details",
            "2026-11-20T10:00:06.0000004Z * Try:",
            "2026-11-20T10:00:07.0000000Z ##[error]Process completed with exit code 1."
        ).joinToString("\n")
        val out = BuildLogParser.summarize(log)
        assertTrue(out.startsWith("Execution failed for task ':app:compileDebugKotlin'."))
        assertTrue(out.contains("Unresolved reference: foo"))
        assertFalse(out.contains("2026-11-20"))
        assertFalse(out.contains("Process completed with exit code"))
        assertFalse(out.contains("/home/runner/work"))
    }

    @Test fun unknownLogFallsBackToItsEnd() {
        val log = (1..30).joinToString("\n") { "line $it" }
        val out = BuildLogParser.summarize(log)
        assertTrue(out.contains("line 30"))
        assertFalse(out.contains("line 1\n"))
    }

    @Test fun blankLogGivesEmptySummaryAndLengthIsCapped() {
        assertEquals("", BuildLogParser.summarize("  \n\n"))
        val long = (1..50).joinToString("\n") { "e: Main.kt:$it:1 Unresolved reference: " + "x".repeat(200) }
        assertTrue(BuildLogParser.summarize(long, 500).length <= 500)
    }
}
