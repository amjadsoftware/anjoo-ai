package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SpeechLangTest {
    @Test fun urduEnglishAndAutoKeepTheirOldBehaviour() {
        assertEquals("ur-PK", SpeechLang.pick("ur-PK", "en-US").first)
        assertEquals(listOf("en-US"), SpeechLang.pick("ur-PK", "en-US").second.toList())
        assertEquals("en-US", SpeechLang.pick("en-US", "ur-PK").first)
        assertEquals(listOf("ur-PK"), SpeechLang.pick("en-US", "ur-PK").second.toList())
        assertEquals("ur-PK", SpeechLang.pick("auto", "en-US").first)
    }

    @Test fun anyLanguageListensForManyLanguages() {
        val (main, extra) = SpeechLang.pick("any", "en-GB")
        assertEquals("en-GB", main)
        assertTrue(extra.contains("ur-PK") && extra.contains("hi-IN") && extra.contains("ar-SA"))
        assertFalse(extra.contains("en-GB"))
    }
}
