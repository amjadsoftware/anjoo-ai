# v100.0.58 — "Creating the project failed. The code could not be created"
Cause: Gemini.plainFull() silently returned an empty text whenever the model gave no parts (all output tokens spent on thinking =
finishReason MAX_TOKENS, safety block, or a hiccup). Coder.build then only said "please try again", hiding the real reason.
- Coder.gen: if the answer is empty it retries once without deep thinking and with the normal token limit.
- Gemini.Reply now carries `reason`; the final error says why (blocked by safety filter / used all tokens thinking / stopped with reason X).
