# v100.0.49

Live voice: every language. GF Mode: reliable.

## Why Live was "English fixed"
- Anjoo's language setting defaulted to "Phone Default", which on an English phone told the AI "Respond in English" and only weakly "match the user if they switch". The Live prompt also named only Urdu, Roman Urdu and English.

## What changed (language)
- New default language setting **Any language (auto)**: the AI understands every language and answers in the exact language and script the user spoke (English, Urdu, Roman Urdu, Hindi, Arabic, Punjabi, Pashto, Sindhi, Bengali, Turkish, French, Spanish, Chinese and others), switches the moment the user switches, and mixes the same way when the user mixes. "Phone Default" on an English phone now behaves the same way. The fixed choices (English, Roman Urdu, Urdu, Arabic) still force that one language when the user picks them.
- Live voice prompt now carries a "LIVE LANGUAGE (highest priority)" rule for the same behaviour (not added when a fixed language is chosen).
- Speech language (Urdu / English / Urdu + English) has a fourth choice, **Every language (auto-detect)**, for the phone's own speech recognizer, Whisper (no language hint) and Gemini transcription. Gemini Live itself already hears every language.

## Why GF Mode worked only sometimes
1. Live voice sends the user's words in small pieces ("GF", "mode", "on"). Every piece was saved as its own chat message, and GF Mode checked each piece alone. So "GF mode off" turned GF ON (the piece "GF" matched), and "meri gf ko msg bhejo" could switch it on by accident.
2. The Live session reads its instructions and voice only when it starts, so a GF switch said during Live changed nothing until Live was restarted. The Live "Boss" persona was also added after the GF instructions and contradicted them.
3. The trigger phrases were an exact list ("gf mode on karo", "gf mod on", "G F mode" and Urdu/Hindi letters did not match).

## What changed (GF Mode)
- Live pieces are joined into ONE message after a short pause (also fixes the broken one-word chat lines), and GF is checked on the whole sentence.
- When GF flips during Live, the live session restarts after the current reply (new instructions and the soft female voice), and again when GF is turned off.
- In GF mode the Live prompt uses a GF note instead of the Boss persona.
- Trigger rewritten: any short sentence made only of GF/mode/on/off/band/chalu/kar/karo/... words switches, including "G F", "girlfriend", "mod/mood", and Urdu or Hindi letters; any sentence with other words ("meri gf ko msg bhejo") is still not a switch.
- Tests: `GfModeTest` (6 cases), `SpeechLangTest`.

## Not changed / limits
- Typing "gf mode on" in the main chat while Live is running does not restart Live; it applies the next time Live starts.
- The phone's own recognizer and Whisper can only be as good as their own language support. Live (Gemini) is the best for rarer languages.
- Not compiled or run here (no network/Android SDK in this session); the GitHub build compiles it and runs the tests.
