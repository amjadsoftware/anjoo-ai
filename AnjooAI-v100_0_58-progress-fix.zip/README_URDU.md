# Anjoo AI — README (v99.2.51)

## v99.2.51 — Memory & Knowledge
- Memory & Knowledge dashboard mein saved preferences, facts, people aur tasks ko search, add, edit, pin, complete aur delete kar sakte hain.
- Knowledge Base mein TXT/MD/CSV/JSON/XML/HTML/code, Word, Excel, PowerPoint, OpenDocument aur RTF documents import, search, read, edit aur delete hote hain. PDF/image OCR ke liye configured vision AI provider ko pages/image bhejne se pehle alag confirmation aati hai.
- Documents local SQLite database mein chunks aur full-text index ke saath store hote hain. Chat mein matching excerpts bhejna default OFF hai; `Use Knowledge in AI answers` on karne se pehle privacy notice accept karna hota hai.
- Optional AI Semantic Search default OFF hai. Enable karne par document chunks aur search queries Google Gemini Embedding API ko bheje jate hain; API quota/billing lag sakti hai. Build Index, status aur semantic index delete controls shamil hain.
- Memory/Knowledge exports aur full backup active data ke saath per-item deletion records aur global clear marker bhi rakhte hain, taake purane/offline backups se delete ki hui yaadein wapas na aayein. External AI data-sharing consents doosre device ke backup se auto-enable nahi hotin; har device par alag opt-in zaroori hai.
- SQLite v3 additive migration ke saath purane notes aur knowledge data preserve karta hai.
- JVM smoke checks pass hue; Android APK build, device test aur live API integration is runtime mein execute nahi hue.

# Anjoo AI — README (v99.1.61)

## v99.1.61 — JARVIS Mode
- Settings → Voice and language mein one-tap JARVIS Mode add kiya.
- Wake word, Live voice, natural voice, spoken replies, notification reading aur floating assistant UI configure hotay hain.
- Mode on karne par voice service restart hoti hai; mode off karne par background listening band hoti hai. Android permissions user ke control mein rehti hain.
- Agent ko multi-step task planning, tools se kaam, result verification aur honest error reporting ke liye JARVIS-specific instructions milti hain.
- Setup aur limitations ke liye `JARVIS_MODE.md` dekhein.
- Android version metadata 99.1.61 / 99161 par update ki.


## v99.1.60 — Agent reliability
- Agar AI 40 tool rounds ke andar kaam mukammal na kar sake to chat saaf batati hai ke task abhi incomplete hai.
- Voice agent mein pehle wali galat 25-step warning fix ki gayi; ab voice aur chat dono ek hi limit use karte hain.
- Stop/Cancel ko voice agent ke aglay model/tool action se pehle check kiya jata hai.
- App version metadata 99.1.60 se align kiya gaya. Successful default-branch CI builds release APK ko GitHub Release par publish karte hain, taake in-app updater ko actual APK mil sake.
- Is runtime mein Android SDK available na hone ki wajah se APK/device test nahi chala; CI workflow mein existing automated build/test steps maujood hain.

## v99.1.44 — Image-reference Chat UI and attachments
- Pending image uploads now appear in a horizontal thumbnail rail (up to four); multi-file selection is enabled for regular files as well.
- User message cards render image thumbnails or individual file cards; tapping an image opens a zoomable viewer, and multi-file bundles offer individual downloads plus a ZIP download.
- File-card taps attempt a direct save into `Download/Anjoo`; if Android storage policy blocks it, the system Save As picker is offered.
- The new `Problem…` shortcut fills the composer with debugging, tests, bug-fix, UI, security-review or file-explanation prompts; it does not send automatically.
- Long fenced code blocks have compact/expanded heights and a real full-screen selectable/copyable view. Existing Copy, Python Run, HTML/SVG Preview and Code Studio actions remain.
- Processing history has explicit DONE / ISSUE / FAILED / RUNNING badges; long action details and output can be expanded by tapping.
- Uploading multiple source-code files attempts to create a Code Studio project, so a follow-up edit request can operate on the actual files.
- ZIP is packed with the full project under one `AnjooAI/` folder so `.github/workflows` stays inside that folder and does not land on top of a repository root during extraction.
- Verification: source checks and ZIP integrity are run; Android APK build/device testing are only claimed if actually available.


Mic dabayein aur bolein, ya chat mein likhein. Anjoo AI multiple AI providers, built-in tools aur Android permissions ke zariye mukhtalif kaam karta hai.

## Kya kar sakta hai
- Roman Urdu, Urdu aur English mein sawal samajhna, likhna aur voice se jawab dena.
- Multi-step tasks ke liye tools chalana, output check karna aur error aaye to recovery ki koshish karna.
- Code likhna, maujooda project inspect/edit karna, bugs dhoondhna, supported lint/tests chalana, HTML preview aur project ZIP export karna.
- Websites, scripts, app source projects, API integrations aur database schemas tayyar karne mein madad dena.
- Supported AI providers ke zariye images generate/edit karna; image/file uploads ko analyze karna.
- PDF, Word, Excel, PowerPoint aur text files create, read, convert, compare aur merge karna (format aur phone permissions ke mutabiq).
- Web search, web pages read karna, reminders/tasks/notes manage karna aur supported app actions karna.
- Accessibility permission enabled ho to screen controls par interaction ki koshish karna; warna jo permissions missing hon unki nishandahi karna.
- Chats, projects aur supported app data ka local backup/restore karna.

## Zaroori hudood
- Phone actions ke liye mutaliqa Android permissions/Accessibility enable honi chahiye; har third-party app ka UI har waqt reliably control nahi hota.
- AI features ke liye internet aur valid provider API key ki zaroorat ho sakti hai. Provider ki free limits, model availability aur fees badal sakti hain.
- Android APK build/device test ke liye Android SDK/Gradle aur test device chahiye; Code Studio ka source generate karna APK ko automatically build/test karne ke barabar nahi.
- Anjoo login, OTP, bank/card security ya Android ke security controls ko bypass nahi karta. Sensitive/destructive actions par confirmation zaroori reh sakti hai.
- Koi AI har kaam mein 100% perfect nahi. App actual tool results ke mutabiq failure ya incomplete task bataye; ise guarantee na samjhein.

## Banane ke qadam (pehli baar)
1. Computer par Android Studio install karein (developer.android.com/studio).
2. Android Studio mein File > Open, aur is `AnjooAI` folder ko kholein. Gradle sync poora hone dein (internet chahiye, pehli baar kuch minute lagte hain).
3. Phone mein Settings > About phone > Build number par 7 baar tap karein, phir Developer options mein USB debugging on karein.
4. Phone ko USB se jorain, Android Studio mein upar ka hara Run button dabayein. App phone par install ho jayegi.
   (Ya Build > Build APK(s) se APK bana kar phone mein copy karke install karein.)

## Pehli dafa istemal
1. App kholte hi Settings aayegi. Apni Gemini API key dalein: aistudio.google.com/apikey par apne Google account se "Create API key" dabayein. Model "gemini-3.8-flash" rakhein (ya wahan ki list se jo naam dikhe).
2. Mic, contacts, call aur SMS ki ijazat "Allow" karein.
3. Mic dabayein aur bolein: "Ahmed ko call karo", "Subah 6 baje ka alarm lagao", "WhatsApp kholo".
   Zubaan ka button "اردو / English" bolne ki zubaan badalta hai.

## Zaroori baatein
- Gemini Pro subscription aur API key do alag cheezein hain. Key AI Studio se banti hai, us par free limit hoti hai aur us se zyada istemal par kharcha ho sakta hai. Key kisi ko na dein; yeh sirf aap ke phone mein rehti hai.
- WhatsApp ke liye "0300..." wale number Pakistan ke code (92) mein badal diye jate hain.
- Awaaz pehchaan Google ki service use karti hai, is liye internet aur Google app chahiye.
- Pehle kuch din call/SMS ki tasdeeq wali screen par nazar rakhein ke naam aur number sahi hain.

## v12 naye kaam
- Naya Anjoo AI app icon (robot + neon circuit).
- Markhor hata diya: ab ek cute robot (Buddy) screen par ghoomta hai, aapki baat par chehre ke expressions badalta hai (khush, pyar, udaas, hairan, soch, sunna, neend).
- Mouse jaisa arrow (cursor): jab Anjoo koi kaam kare (tap, likhna, back/home, scroll, app kholna) to arrow dusri apps ke upar bhi dikhta hai ke kahan ja raha hai. Iske liye Accessibility on honi chahiye.
- Awaaz pehchan behtar aur tez: jumla 0.7 sec khamoshi par poora, jawab ki awaz pehle jumle se shuru, Anjoo soch raha ho tab bhi aapki nayi baat sunta hai, aur samajhne par chhoti beep aati hai.

## v14 Code Studio (Claude jaisi coding)
- Menu > "Code Studio": likhein ya bolein kya banana hai. Pehle architecture plan, phir poora multi-file project (README aur dependency file samet), phir bug review.
- Project ke har file ka tab: dekhein, Copy, Share, haath se Edit/Save.
- Badlav: "dark mode lagao", "login add karo" likhein, sirf zaroori files badalti hain. Ask: koi bhi code ya bug ka sawal, project dekh kar jawab.
- Web projects ke liye Run (live preview), Zip se poora project save.
- Awaaz se: "Anjoo, ek calculator app banao" (write_code) ya "isme history add karo" (edit_code).

## v15 Professional chat app
- Boot lines ("loading...") aur screen par ghoomta robot hata diya. Ab saaf chat screen hai; robot sirf chhote avatar ki tarah header mein (expressions ke saath) aur khali screen par.
- Header: history, avatar, naam + model, naya chat, menu. Khali chat par suggestions (Claude/ChatGPT/Gemini jaisa).
- Jawab Markdown mein: headings, lists, bold, code blocks (Copy ke saath), links. Har jawab ke neeche Copy, Listen, Share, Retry.
- Think (DeepSeek jaisa gehri soch, "Thought process" dikhta hai) aur Web (Google Search se taaza maloomat + sources) chips.
- "+" se Photo, Camera, PDF/text/code file attach (Kimi jaisa lambi file parhna).
- Custom instructions (ChatGPT jaisa), Code Studio, Live voice (mic button), phone control sab isi app mein.
- Settings grouped: Voice and language, Phone control, Appearance, Backup, API key.

## v16 Coding aur Thinking advanced
- Chat mein code likhwayein to jawab ke code block par Code | Preview tabs aate hain (HTML/SVG ka live preview usi chat mein), saath Full screen, Studio, Copy.
- Code Studio ki chat mein har project ka card: files, code viewer, live Preview aur Edit, sab usi chat ke andar.
- Deep think (Code Studio mein ON/OFF): pehle gehra analysis (requirements, edge cases, test scenarios), phir code, phir 2 round review/test. "Thought process" dekh sakte hain.
- Main chat ka Think chip ab advanced level (high thinking) par chalta hai.

## v31 naya icon, opening scene, image generation, behtar coding
- Naya icon: koi harf nahi, ek roshan "spark" aur ghoomta hua orbit ring (gradient background). Android 13+ par themed icon bhi.
- App khulte hi chhoti film jaisi scene: raat ka aasman, taare, aurora, ubharta hua orb, shooting star, jugnu, aur beech mein Anjoo spark. Tap karein to foran skip.
- Chat mein image banana: "Image" chip dabayein ya seedha likhein/bolein "ek sheer ki tasveer banao". Picture chat mein aati hai; tap par full screen, Save (Pictures/AnjooAI), Share, Edit (photo bhej kar "isko cartoon bana do" bhi chalta hai). Model: gemini-2.5-flash-image (agar aapke account par na ho to khud doosre model par chala jata hai).
- Coding: ab har web project banne ke baad chhupe hue browser mein khud chalta hai; JavaScript errors, missing files ya khali page mile to Anjoo khud theek karta hai (2 round). Naye rules: behtar UI design, games, tests, scripts, backend.

## Naye AI providers (v34)
Settings mein ab teen cheezein chunni hoti hain: **AI** (Google Gemini free by default, OpenAI, Claude, OpenRouter, Groq, DeepSeek, Mistral, xAI, ya Custom URL), phir **Model** (list se tap karke, ya "Load all models" se poori list), phir us ki **API key**. Har provider ki key alag save hoti hai.
Voice typing, Gemini voice aur picture banana hamesha Google Gemini key se chalte hain, chahe chat kisi aur AI se ho.

## v38 Claude jaisa interface, Thinking aur Commands summary
- **Look:** naye themes "Claude Light" (garam cream + terracotta) aur "Claude Dark". Pehli dafa phone ke dark/light mode ke mutabiq khud lag jate hain; Menu > Appearance se badal sakte hain (purane themes bhi maujood hain). Jawab serif font mein, bubble ke baghair, har jawab ke neeche ✦ ke saath Copy/Listen/Share/Retry. Composer gol card jaisa, khali screen par waqt ke mutabiq salam.
- **Thinking:** jawab se pehle live card: "✦ Thinking… 4s" aur model ki soch ka khulasa. Jawab shuru hote hi yeh "Thought for 4s ›" ban jata hai, tap karke poori soch dekhein. Ab har sawal par aata hai (pehle sirf Think chip par).
- **Commands summary:** jo bhi phone ka kaam Anjoo karta hai (app kholna, alarm, call, SMS, search...) woh live list mein dikhta hai: `… chal raha hai`, `✓ ho gaya`, `! masla`, `✕ nakam`. Jawab ke upar "⌘ Ran 2 commands ›" ke neeche ek line ka khulasa; tap karein to har command aur uska natija. Yeh chat history mein bhi save rehta hai.
- Menu > "Show thinking and commands" se yeh dono band/on kar sakte hain.
- Anjoo ab commands dohrata nahi: sirf ek chhota sachcha jumla batata hai ke kya hua aur kya nahi.

## v39 Sharmila robot
- Screen par ghoomne wala robot ab touch se bhagta hai: robot ko chhuen to ek qadam peechay hop karke hat jata hai, uske bagal mein tap karen to touch se door tez bhag jata hai. Kone mein phans jaye to doosri taraf nikal jata hai. Robot ko ungli se ghaseet kar kahin bhi rakh sakte hain (pehle jaisa).

## v40 Movie jaisa opening (Splash), v69 mein sirf flash + logo
App khulte hi ~3.2 sec ki chhoti film (tap karein to foran skip):
1. **Background:** gehra nebula aasman, taare aur shooting stars.
2. **Flash:** foran safed flash (Symbiotes, Venom aur fight scene hata diye gaye hain).
3. **Logo:** har rang ki shockwaves, background warm hota hai aur Anjoo logo (shakal wahi jo app icon ki hai, rang Claude orange) rays, orbit rings, lens flare aur sparks ke saath ubharta hai. Haptic jhatka bhi aata hai.

## v41 Image upgrade: padhna, text parhna, banana
- **Photo ke quick buttons:** photo lagate hi 📝 Read text, 🔍 Describe, 🌐 Translate, 🧮 Solve, ✏️ Edit ke buttons aate hain. PDF par Summary / Read text / Translate.
- **Text parhna (OCR):** chip "📝 Read text" ya menu se photo chunein. Urdu, Arabic, English, haath ka likha, tables, receipts, screenshots. Text jaisa likha hai waisa hi aata hai (translate/summary ke bina), neeche Copy aur "Translate / Summarize / Fix spelling" ke suggestions.
- **Ek se zyada photos:** gallery se 4 tak photos ek saath (compare, ya kai pages ka text). Photo ki quality OCR ke liye behtar (1800px).
- **Photo par follow-up:** pehle agla sawal aate hi photo bhool jati thi. Ab "ab isko English mein karo" jaise sawal chalte hain. Retry bhi photo ke saath chalta hai.
- **Dusri apps se Share:** Gallery, WhatsApp, Chrome se photo/PDF/text "Share" > Anjoo AI. Seedha chat mein aa jata hai.
- **Image banana:** 🎨 Image chip dabane par Style (Realistic, Anime, 3D, Logo, Oil painting, Cinematic...), Size (1:1, 16:9, 9:16...) aur Versions (1 se 3 ek saath) ke chips. Awaaz ya chat mein "teen options banao" bhi chalta hai.
- **Banai hui picture par:** Save, Share, Edit, **Another** (naya version, usi idea se) aur **More** (background hatao, cartoon, anime, oil painting, black and white, cinematic, HD/sharper, sticker).
- **Zoom viewer:** picture par tap karein: pinch se zoom, double-tap se zoom in/out, ungli se khiskayein, Save/Share neeche.
- Gemini key chahiye (image padhna aur banana dono Google Gemini se). Pehle build ke baad phone par test zaroor karein: yeh badlav is machine par compile nahi kiye ja sake (Android SDK nahi tha).

## v41 WhatsApp ki bheji hui picture kholo aur parho
Bolein ya likhein: "Ahmed ne WhatsApp par jo image bheji hai wo kholo aur parho". Anjoo ye karta hai: WhatsApp kholna, Ahmed ka chat kholna, sabse nayi picture kholna (`tap_image`), phir screen ki picture le kar Gemini se parhwana (`look_at_screen`): picture ka text (Urdu/English/Arabic) aur usmein kya hai.
- Zaroori: Accessibility on honi chahiye. Naye version ke baad **ek dafa Accessibility band karke dobara on karein**, warna screenshot ki nayi ijazat nahi milti.
- Android 11 ya naya chahiye. Gemini key chahiye.
- Agar chat ya picture na mile to Anjoo saaf bata deta hai. Picture ke andar likhi hidayat ko hukm nahi samjha jata.

## v41 "Jo bolo wo karo" (full control)
- Anjoo ab kabhi nahi kehta "tool nahi hai". Har hukm ko steps mein todta hai aur ek tareeqa na chale to doosra ajmata hai (25 steps tak ek hukm mein).
- Naye tools: `list_screen` (screen par kya hai aur kahan), `tap_xy` (kisi bhi point par tap/long press), `swipe`, `wait`, aur keys: lock, screenshot, quick_settings, power_menu. `tap_text` ab text ke paas clickable na ho to us jagah touch karta hai.
- Menu > "⚡ Do it without asking (call, SMS, replies)" on karein to call/SMS/reply bina Yes/No ke seedha ho jate hain. Default off hai (galat naam sunne par galat call se bachne ke liye).
- Hadd: bank/payment apps ya FLAG_SECURE wali screens Android screenshot/touch rok sakta hai; password/OTP daalna Anjoo apni taraf se nahi karta.

## v41 Bank, wallet aur card se door (Guard)
- Anjoo bank/wallet apps (JazzCash, Easypaisa, HBL, UBL, Meezan, SadaPay, NayaPay, PayPal, Google Pay, STC Pay, Al Rajhi waghera) ke andar na parhta hai, na dabata hai, na screenshot leta hai. App kholna theek hai.
- Card number, CVV, PIN, OTP, expiry, password: na parhta, na copy/likhta, na bhejta, na yaad rakhta. Screen, SMS, notifications aur screenshot ke natije mein yeh `[hidden]` ho jate hain; aap ki likhi/boli hui baat mein card number AI ko jane se pehle chhupa diya jata hai.
- Sirf **account number / IBAN**: aap bolein "mera account number 0123456789 copy karo" ya "paste karo" to copy_text/type_text se ho jata hai (bank app ke text box mein bhi likh deta hai, lekin us app mein aur kuch nahi dabata).
- Code: `Guard.kt`.

## v42 Coding: Claude jaisa dikhana, tez edit, behtar check
- **Rang-birangi code (syntax highlighting):** chat ke code blocks, Code Studio ki files aur project card, sab mein keywords, strings, comments, numbers, functions, HTML tags aur CSS alag rang mein, line numbers ke saath. Har block par "kotlin · 42 lines" jaisi detail. 60,000 se bade code mein rang band ho jate hain taake app smooth rahe.
- **Live code dikhna:** jab Anjoo project likh raha hota hai to working card mein asli code (aakhri 10 lines, rang ke saath) saath saath chalta dikhta hai, kaunsi file ban chuki hai (✓) aur kaunsi likhi ja rahi hai, aur kitne seconds se kaam chal raha hai.
- **■ Stop button:** kaam ke dauran ➤ button ■ ban jata hai. Dabate hi screen foran free; background kaam agle step par ruk jata hai (naya model call nahi hota, aur roka hua jawab project par lagta nahi).
- **Tez edits (EDIT blocks):** project badalte waqt model ab poori file dobara nahi likhta, sirf SEARCH/REPLACE tukde likhta hai (Claude Code jaisa). Kam intezar, kam kharcha. Agar koi tukda file se match na kare to sirf wahi files poori dobara likhi jati hain.
- **Behtar auto-check (lint):** bracket ( [ { ka sahi jora (strings aur comments ko chhod kar), HTML ke duplicate id, JavaScript jo aisi id dhoondta hai jo HTML mein hai hi nahi, inline scripts ki jaanch, Python mein tab aur space ki milawat. Yeh nataij reviewer ko haqeeqat ki tarah diye jate hain.
- **Tez build:** Deep think OFF ho aur local check saaf aaye to model review ka extra round chhod diya jata hai.
- **Behtar prompts:** pehle asal maqsad samajhna, sawal poochne ki bajaye samajhdar defaults, poora kaam (empty state, keyboard, error messages) magar bila-zaroorat extras nahi. Har jawab ke aakhir mein "Next:" ke 2 mashware. Ask mode mein pehle seedha jawab, phir wajah, phir theek kiya hua code (file ka naam ke saath).
- Naye/badle files: `Hl.kt` (naya), `Md.kt`, `CodeActivity.kt`, `Coder.kt`.
- **Zaroori:** yeh badlav is machine par compile nahi kiye ja sake (Android SDK/Kotlin compiler nahi tha). Pehle Android Studio mein build karke test karein; agar koi compile error aaye to error ki line bhej dein, foran theek kar dunga.


## v44: Backup mein ab sab kuch (Export / Import)
- Export ab ek **.zip** file banata hai: settings, yaadein, diary, saari chats, **Code Studio ke projects aur unki chat**, chat ke cards ki copy, purane pages/code, Anjoo ki banai hui images, aur chat mein lagayi hui **files (PDF, code, ZIP, photos)**.
- Import purani `.json` backup aur nayi `.zip` dono kholta hai.
- Chat mein ab **ZIP file** bhi attach ho sakti hai: Anjoo uske andar ki text/code files parhta hai (node_modules, .git, binary wagaira chhor deta hai).
- Chat mein lagayi hui file ab chat ke saath save rehti hai; purani chat kholne par "📎 file" par tap karke dobara attach kar sakte hain.

## v45: Prompt aur Coding ki taqat, Python
- **Prompt Maker**: chat mein bolein "is ka prompt bana do" (ChatGPT/Claude/Gemini/image/video/coding). Anjoo Role, Context, Task, Constraints, Output format wala tayyar prompt banata hai. Code Studio mein input ke saath **✨** button: chhoti si baat ko poore engineering brief mein badal deta hai (bhejne se pehle edit kar sakte hain).
- **Coder ke rules behtar**: Python ke liye (bina keyboard input ke chalne wala, demo data, main() guard) aur testability ke naye rules.
- **Python app ke andar chalta hai** (Pyodide, WebView mein, koi install nahi; pehli baar ~10MB download, internet chahiye):
  - Code Studio > ⋮ menu > **🐍 Run Python**: output ya error dikhata hai, error par **Fix with AI**.
  - Chat ke har ```python code block par **▶ Run** button.
  - Coder khud Python project chala kar error milne par theek karta hai (jaise web projects ke liye pehle se tha).
  - Anjoo ka naya tool **run_python**: hisaab, data/text processing, regex, algorithm ki jaanch asal mein chala kar jawab deta hai.
  - tkinter, pygame, Flask/Django, socket jaisi cheezein yahan nahi chalti; unka sirf syntax check hota hai.

## v46: Do mode wali shakhsiyat (Companion / Workhorse)
- `Style.FRIEND` ab ek adaptive prompt hai jo khud mode badalta hai: **Companion** (baat-cheet, jazbaat, mazaaq: garam, witty, insani) aur **Workhorse** (code, debugging, tools, analysis, business writing: seedha, durust, bina fuzool baat ke).
- Mix baat par: pehle 1 chhoti witty/caring line, phir poora Workhorse jawab.
- Sakht rules: code/files/prompt outputs mein mazaaq ya roleplay nahi; code mein TODO ya "..." nahi, hamesha poori chalne wali files; durustgi charm se upar.
- Pehle wale safety rules (bina hukm koi kaam nahi, nateeja verify karke batana, yaad sirf kehne par) barqarar hain. Ye prompt chat aur voice dono mein lagta hai.

## v47: Code Studio attach, ZIP import, auto-backup, history search, CI
- **Code Studio mein 📎**: "Attach a file" (code, text ya ZIP ka andar ka text) aap ke agle message ke saath Anjoo ko milta hai. "Open a ZIP as a new project" kisi bhi zip ko naya project bana deta hai (binary files, node_modules, .git chhor kar), phir edit/ask/run kar sakte hain.
- **Auto-backup**: har 3 din baad khud backup `Downloads/AnjooAI/anjoo-auto-*.zip` mein (API key ke bagair), aakhri 3 rakhe jate hain. Menu > Backup and restore mein on/off.
- **Chat history search** ab sirf title nahi, chat ke andar ke lafz bhi dhoondta hai (kam az kam 2 harf).
- **GitHub Actions**: `.github/workflows/build.yml` har push par Debug APK banata hai aur khali/ghayab APK par fail karta hai.
- versionCode 47.

## v48: Agent features (Hermes jaisa kaam, mobile par)
- **Tasks / Kanban**: Menu > "Tasks (Kanban board)": To do, Doing, Done. Card dabayein: move, edit, delete, ya "Ask Anjoo to do it" (Anjoo background mein kaam karke natija card par likh deta hai). Awaaz/chat se: "task add karo ...", "ye task done karo", "tasks dikhao".
- **Schedule (khud chalne wale kaam)**: "roz subah 8 baje tech news ka khulasa bhejo", "30 minute baad ye price check karo". Waqt par Anjoo agent chalata hai, natija notification (aur Telegram) mein aata hai, aur board par card banta hai. (Sirf yaad dilana ho to purana reminder.)
- **Sub-agents**: delegate_task: researcher (Google Search + sources), coder, planner, writer, analyst. Lambi tehqeeq/likhai/planning akela mahir karke natija deta hai.
- **Browser agent**: app ke andar asli browser (BrowserActivity) jo Anjoo chalata hai: browser_open, read, click, type, scroll, back, close. Aap dekh sakte hain, khud sign-in kar sakte hain. Anjoo password/card/OTP fields mein kabhi nahi likhta; bank/payment/wallet pages par nahi jata; page ka matn untrusted data maana jata hai.
- **Telegram control**: Menu > "Telegram control": @BotFather se apna bot banayein, token paste karein, bot ko `/pair CODE` bhejein. Phir sirf aap ka chat Anjoo ko hukm de sakta hai (agent ke saare tools: browser, tasks, schedule, sub-agents, phone control). Call, SMS aur message-reply Telegram se kabhi nahi hote. Commands: /tasks, /new, /unpair, /help. Token backup mein tab hi jata hai jab "Include key" chunein.
- Naye permission: FOREGROUND_SERVICE_DATA_SYNC (Telegram ki background service ke liye).
- Limits: Android kuch phones par background services band kar deta hai (battery "Unrestricted" karein). Har Telegram message / scheduled job / browser step API calls istemal karta hai.

## v49: Scroll / jhatke (lag) ka fix
- Chat mein jawab likhte waqt har update `fullScroll` se screen ko neeche kheench leta tha (aur keyboard focus bhi chheenta tha): isi se drag karte ya option chunte waqt jhatka lagta tha. Ab `SmartScroll`: ungli screen par ho ya abhi uthi ho to kuch nahi karta; sirf tab neeche follow karta hai jab aap pehle se neeche ke qareeb hon. Apna naya message ya chat kholne par seedha neeche jata hai. Main chat aur Code Studio dono mein.
- Robot (Buddy) ka animation ab 30 frames/sec hai (neend mein 15), aur jab chhupa ho (doosri screen, khali-screen wala avatar, app peeche) to draw nahi karta.

## Awaaz (Urdu + English) behtar banai gayi (v51)
- Jawab bolte waqt Urdu hissa Urdu awaaz mein aur English hissa English awaaz mein bola jata hai (VoiceKit.kt).
- Jawab se pehle star, emoji, links aur code saaf kar diye jate hain, taake "star star" na bola jaye.
- Bolte waqt music/video ki awaaz kam ho jati hai.
- Speech language ab teen tarah ki hai: Urdu, English, aur Urdu + English (auto), jis mein ek hi jumle mein dono zubanein mix ho sakti hain.
- Google recogniser: dono zubanein samajhta hai, behtareen jumla chunta hai, aur sunte waqt notification mein lafz dikhata hai.

## Routine aur aadat engine (v52)
- Anjoo ab yaad rakhta hai ke aap kaun sa kaam kis waqt karte hain (mausam, khabrein, apps, namaz, tasks, calendar, music, raasta, call). Ye sab sirf is phone par rehta hai (Habits.kt).
- Jab koi kaam 3 alag dinon mein lagbhag ek hi waqt par ho, to usi waqt Anjoo mashwara deta hai: notification mein "Haan, karo / Baad mein / Dobara nahi", aur app ki khali screen par "For you" mein.
- Khud ki ba khud suggestions: roz subah mausam/khabrein dekhne walon ko daily briefing, namaz auqaat dekhne walon ko namaz reminders, due ya baqi tasks, agli namaz se pehle yaad dihani, aur do kaam jo aksar saath hon unhein routine banana.
- Hadd: roz zyada se zyada 3 notifications, raat 10 se subah 7 tak koi nahi. Menu mein "Proactive suggestions" on/off aur "What Anjoo has learned" (dekhna, notifications band karna, sab bhula dena).

## v53 Offline mode (internet ke baghair bhi kaam)
Android app mein browser wale LocalStorage / IndexedDB nahi hote; unka sahi Android jawab yeh hai: chhoti cheezein (tasks, reminders, chats) pehle se **SharedPreferences / app files** mein hain, aur ab **notes aur "baad mein bhejo" queue** ek asli **SQLite database** (`LocalDb.kt`) mein hain. Sab kuch phone par, net ke baghair.
- **Notes** (Menu > "Notes"): likhein, edit, pin, search, share, delete. Anjoo se bhi: "note: kal doodh lana", "notes dikhao", "note 2 delete". AI ke naye tools: add_note, list_notes, read_note, delete_note. Notes backup (zip aur json) mein bhi jate hain; restore mein merge hota hai (naya edit jeetta hai), purane notes mitte nahi.
- **Offline banner**: net na ho to chat ke upar "📴 Offline" aata hai (kitne messages intezar mein hain bhi dikhata hai).
- **Offline commands** (bina AI ke, `OfflineBrain` in `Offline.kt`): notes, tasks ("task add: ...", "tasks dikhao", "task 3 done"), yaad dihani ("10 minute baad yaad dilao chai", "shaam 6 baje yaad dilao ..."), alarm, timer, torch, volume, battery, app kholna, waqt/tareekh, calculator ("2*(3+4)"). "help" likhein to list aati hai. Sirf saaf hukm par kaam hota hai.
- **AI wale sawal** jab net na ho: save ho jate hain (Outbox). Net wapas aane par Anjoo **pooch kar** bhejta hai ("Send now / Later / Discard"), ek ke baad ek, aur har message ke saath "[Saved offline at ...]" likha hota hai taake purana waqt pata rahe. Koi purana hukm (call, SMS...) khud se nahi chalta. Agar net ek request ke beech mein toot jaye to bhi message save ho jata hai.
- **Photo/file** bhejne ke liye net chahiye (offline mein bataya jata hai).
- **Doosre phone se sync (bina server)**: Notes screen > ⋮ > "Save sync file" (notes + tasks ki ek chhoti .json file), file doosre phone par bhej kar "Merge from file". Har note ka naya edit rakha jata hai, hataye hue notes wapas nahi aate, tasks sirf naye jode jate hain. (Cloud sync nahi hai; woh server ke baghair mumkin nahi.)
- Naya permission: ACCESS_NETWORK_STATE. versionCode 53.
- **Zaroori:** yeh badlav is machine par compile nahi kiye ja sake (Android SDK nahi). Sirf Kotlin syntax check hua aur parsing wale hisse (calculator, waqt, durations) alag se test hue. Pehle Android Studio / GitHub Actions se build karke phone par test karein.

## Phone Storage Access (naya)
Assistant ab phone ke asal folders mein files save/list/read/delete kar sakta hai (sirf Code Studio ki virtual files nahi).
- Tools: `save_file`, `list_files`, `read_file`, `delete_file`, `save_image`, `export_project`, `storage_setup`
- Setup: Menu > Phone > "Phone storage" (All files access ya ek folder chunein). Download/Documents/Pictures mein Anjoo ki apni files Android 10+ par bina permission ke bhi save hoti hain.
- Overwrite aur delete se pehle hamesha tasdeeq poochta hai; card/OTP jaisa data file mein likhna block hai.


## v71: Code Studio mein Claude jaisa file flow
- Upload ki hui file chat mein card ban kar dikhti hai (naam, lines, size, UPLOADED badge). Tap karein to khulti hai, ⬇ se download.
- Har build/edit ke baad "Files created / Files changed" card aata hai: har file ka +/− count, tap karke diff (hara = add, laal = remove).
- Kaam ke baad "✓ Checked and done" card: plan, likhna, review, run-check ke saare steps (tap karke dekhein).
- Har file ke saath ⬇ Download (phone mein save), Files button se poori file list, aur 📦 Download all (zip).
- ZIP import bhi chat mein card ki tarah dikhta hai.


## v72: Main Anjoo chat mein Claude jaisa file flow
- Aap ki bheji file (ZIP, PDF, photo, code) message ke upar tile ban kar dikhti hai (type badge + naam). Tap karein: View / Download / Attach again.
- Anjoo ki files chat mein file cards hain (type badge, naam, lines, size). Tap se kholein, ⬇ se phone mein download.
- Ek se zyada files hon to ZIP card bhi aata hai (poori zip download).
- Edit ke baad "N files changed +a −d" aur har file par "See what changed" (hara/laal diff).
- Steps ka fold: "✓ N steps done (plan, write, review, run check)".


## v73: Claude jaisa activity summary aur progress timeline
- Har jawab ke upar ek summary line: "Thought for 12s, wrote 3 files, ran 4 steps ›".
- Us par tap karne se neeche se sheet khulti hai: step-by-step timeline (plan, files likhna, review, run check), beech mein Roman Urdu progress notes aur model ki thought headings.
- Har file ka step: "Created index.html · 120 lines" ya "Edited app.js · +12 −3".


## v74: Anjoo ke file/code tools mukammal (Claude ke Read/Write/Edit/Glob/Grep/Bash jaise)
- read_file: ab offset/limit se bari file ka koi bhi hissa (lines number ke saath).
- find_files (Glob): '**/*.py', '*.{kt,java}' jaise pattern se subfolders samet file dhoondo.
- grep_files (Grep): files ke andar lafz/regex dhoondo, file + line number + aas paas ki lines.
- run_shell (Bash): phone par ek shell command; har baar user se poochta hai, time limit, khatarnak commands band.
- Pehle se: save_file (Write), edit_file (Edit), list_files, delete_file, run_python.


## v75: Web tools (WebSearch / WebFetch jaise)
- search_web (WebSearch): internet par search karke asli natije (title, link, snippet) Anjoo ko wapas milte hain. Koi API key nahi chahiye (DuckDuckGo, na mile to Bing). site='example.com' aur max_results (1-10) bhi de sakte hain.
- fetch_page (WebFetch): koi bhi http/https page saaf text mein parhta hai (headings, lists, tables). Lambe page ke liye offset aur max_chars, links=true se page ke links bhi. 5 minute ka chhota cache.
- Hifazat: local/private network ke address band, har redirect dobara check hota hai, size aur time ki limit, PDF/picture nahi parhta, card jaisa data wale query/link block. Web ka sab content untrusted data hai, uske andar likhi hidayat par amal nahi hota.
- Purana web_search (browser mein Google kholna) waisa hi hai; ab Anjoo jawab dhoondne ke liye search_web + fetch_page use karta hai aur source ka naam batata hai.
- **Zaroori:** yeh badlav is machine par compile ya live test nahi ho sake (Android SDK aur internet nahi). Parsing ke regex alag se test hue. Pehle Android Studio / GitHub Actions se build karke phone par test karein (jaise "aaj ka petrol price kya hai" ya "is link ka khulasa do").


## v76: Artifacts aur docs (web page, dashboard, document bana kar rakhna, badalna, bhejna)
Anjoo ab "banane wali" cheezein library mein save karta hai (Menu > "Artifacts and docs"), jo baad mein badli aur share ki ja sakti hain. Purane create_page, Code Studio aur "Older pages and code" waise hi hain.
- **Kya banta hai (kind):** page (web page, landing page, invitation), dashboard (charts/tables), app (chhota tool/calculator/game), slides (presentation, next/previous aur swipe), document (letter, resume, guide, proposal), report (summary + findings + sifarishat).
- **Tools:** create_artifact, update_artifact, read_artifact, list_artifacts, open_artifact, export_artifact, share_artifact, stop_sharing, delete_artifact.
- **Banana:** "ek sales dashboard banao", "meri resume likho", "birthday invitation page banao". Ban kar screen par khul jata hai (Preview). Page/dashboard/app/slides HTML hote hain (light/dark mode, mobile-first); document/report Markdown se saaf styled page ban jate hain (headings, lists, tables, task lists, code, links).
- **Viewer:** Preview, Code (select/copy), Edit (haath se likh kar Save), Versions, Rename, Delete. Har badlav ek nayi version banata hai (aakhri 25 rehti hain); purani version dekh kar Restore ho sakti hai.
- **Badlav:** "dark mode lagao", "table mein column add karo" (update_artifact instruction se, baqi sab waisa hi rehta hai) ya exact old_text/new_text. Agar model ka jawab asal se bohat chhota aaye to badlav rok diya jata hai (kuch kharab nahi hota).
- **Bhejna (share):** file (HTML, Word .doc, txt, md) share screen se WhatsApp/Gmail/Drive mein; text ki surat mein; ya Wi-Fi link.
- **Wi-Fi link:** isi Wi-Fi/hotspot par jude doosre phone ya laptop mein khulta hai (http://phone-ip:8787/p/<secret>). Har artifact ka alag random secret, sirf wahi artifact dikhta hai, user se poochta hai, 60 minute baad band, aur sirf jab tak Anjoo app chal rahi ho. **Internet par sab ko dikhne wala link (hosting) is app mein nahi hai**; uske liye file share karein.
- **Save to phone:** html, doc (Word mein khulti hai), txt, md. Overwrite se pehle tasdeeq. PDF: Print screen khulti hai, "Save as PDF" chunein.
- **Hifazat:** card/OTP/password jaisa data wala content block; web link wala server sirf GET deta hai; document mein likha raw HTML escape hota hai aur javascript: links hat jate hain.
- Naya: ArtifactActivity, ArtifactProvider (file share ke liye) manifest mein; koi naya permission nahi.
- **Zaroori:** yeh badlav is machine par compile ya phone par test nahi ho sake (Android SDK nahi). Brackets aur tool JSON check hui, parsing ke regex alag se test hue. Pehle Android Studio / GitHub Actions se build karke test karein (neeche ke tests dekhein).

## v78 Auto free AI (Groq / Gemini / OpenRouter)
- Settings me jis AI ko chuna hai wo pehle use hota hai. Jab uski free limit poori ho ya wo band ho, Anjoo khud agle free AI par chala jaata hai (jis ki key saved ho): Groq, Gemini, OpenRouter (sirf :free model).
- Phone par har key haath se dalne ki jagah `keys.properties.example` ko `app/src/main/assets/keys.properties` naam se copy karke keys bhar do aur app build karo. Pehli dafa chalne par keys apne aap save ho jaati hain.
- Is file ko GitHub par na dalein aur is se bani APK kisi ko na dein.
- Awaaz sunne ke liye Groq key ho to free Whisper pehle use hota hai.

---

## Privacy lock (v99.1.6): sirf "Anjoo AI" folder

- **Andar (Anjoo AI folder + sub-folders):** Anjoo parh, likh aur badal sakta hai. Chats, projects, notes, backups, attachments, created images **AES-256-GCM se encrypted** hain (key Android Keystore mein). Sirf `Documents`, `Downloads`, `Chats/Exports`, `Images/Saved` normal files hain, taake aap unhein Word/PDF/Gallery mein khol sakein.
- **Bahar (baaqi folders):** Anjoo aap ki **ijazat** (har folder ke liye ek baar) se sirf **folder ke naam** dekh sakta hai. Wahan ki files, photos, videos **na kholta, na parhta, na copy, na edit, na delete** karta hai. Nayi file sirf aap kahen aur ijazat den tab likh sakta hai (maujooda file overwrite nahi).
- Gallery / Photos / file-manager / video apps ki screen nahi parhta, na screenshot leta hai.
- `run_shell` / `run_python` ka code agar Anjoo AI folder ke bahar ki storage chhooye to nahi chalta.
- **Reinstall:** Menu > Anjoo AI folder > Privacy > *Recovery passphrase* set karein (ya Keys backup karein, wo bhi yehi recovery save karta hai). Passphrase ke bina purane encrypted chats/projects nahi khulenge.
- Switch: Menu > Anjoo AI folder > Privacy lock (default ON).

## Copy / Select (v99.1.7)
- Prompt ab **Prompt card** mein aata hai (text wrap hota hai) aur uska apna **Copy prompt** button hai; code block ka apna **Copy**.
- Jawab mein sirf ek prompt/code ho to neeche **Copy prompt / Copy code** sirf wahi copy karta hai, **Copy all** poora jawab.
- File card par 📋 (us file ka content copy) aur ⬇ (download).
- **Select** button (aur apne message par long-press > Select text): poora text ek screen par, jo hissa chaho chun kar copy karo.

## v99.1.33: Document Studio (PDF, Word, Excel, PowerPoint aur files)
- **Nayi file banao:** PDF, editable DOCX (Word), XLSX (Excel), PPTX (PowerPoint), CSV, TXT, Markdown, HTML, JSON, XML, SVG aur RTF. Tables, headings, lists aur Urdu/Arabic text ko support karne ki koshish.
- **Existing file par kaam:** `read_document`, `document_info`, `convert_document`, `edit_document`, `compare_documents`, `merge_documents`, `search_document`. Original file ko overwrite nahi karta; edit/convert/merge nayi copy banate hain.
- **Chat attachments:** Word/Excel/PowerPoint/OpenDocument/RTF/CSV/text files ka original private app storage mein cache hota hai, taa-ke usi file par tools kaam kar saken. Generated file 6 MB tak ho to chat mein Download card bhi aata hai; bari output ke liye phone ka saved path dikhaya jata hai. Uploaded file ko dobara download karne par original bytes use hote hain, parsed text nahi.
- **PDF:** scanned PDF ka OCR/transcription karke page order mein Word/PDF ya doosre format mein badal sakta hai; edit/convert pipeline zyada se zyada 200 pages aur 25 MB source tak. OCR mein ghalati ho sakti hai.
- **Hadd:** yeh extracted text se nayi file rebuild karta hai—original fonts, pagination, columns, charts, images, macros, formulas, embedded objects aur pixel-perfect layout har dafa preserve nahi hote. Purane binary `.doc`, `.xls`, `.ppt` ko pehle modern `.docx`, `.xlsx`, `.pptx` ya PDF mein save karein. OpenDocument files read hoti hain, lekin output modern Office formats mein banta hai.
- **Build check:** source/JSON syntax checks kiye gaye; is environment mein Android SDK available nahi tha, is liye APK compile ya device test verify nahi hua. Android Studio se build karke phone par test karna zaroori hai.



## v99.1.34 Rich Workspace (tools + preview)
- Assistant prompt ab actual deliverables ko tarjeeh deta hai: image generation/editing, runnable code, Code Studio preview, interactive artifacts, charts/tables, document tools, research, aur multi-step browser work.
- Code/app request par sirf code ka dump nahi: project banane, run/check karne, preview kholne aur ZIP/export dene ki hidayat.
- File edit/convert mein original safe rakhna, generated output read-back verify karna aur attachment/save/share flow use karna.
- Tool discovery aur anti-repeat behavior: pehle relevant tool/schema dekho, result verify karo, same failed call ko repeat na karo.
- Honest capability boundary: external API keys, permissions aur unsupported UI features ko clear batana; ChatGPT ke private models/backend ki exact copy ka dawa nahi.

**Note:** Yeh prompt/workflow upgrade hai; naye external model providers ya APIs ki service apne aap include nahi hoti. Image generation, web access, preview aur document actions existing app code, selected provider/model, API key, internet aur Android permissions par depend karte hain.


## v99.1.35 — Tool reliability aur live readiness checks
- AI ke tool workflow ki 25-step limit ab chhup kar purana jawab nahi dikhati: limit tak pahunchne par assistant saaf batata hai ke completion verify nahi hui.
- Agar model khaali jawab de, chat mein khaali bubble ke bajaye troubleshooting message milta hai.
- Har request ke system context mein ab AI API key aur internet ki live readiness bhi shamil hoti hai, taake missing setup ko pehle hi pehchana ja sake.
- Yeh source update hai; API keys, internet, Android permissions aur provider ki availability phir bhi zaroori hain. Is environment mein Android SDK/Gradle installed na hone ki wajah se APK build aur physical-device testing verify nahi ki ja saki.


## v99.1.36 — Code Studio directly inside chat
- Main chat ko explicit in-chat Code Workspace workflow diya: simple snippets chat mein, multi-file projects `write_code` se, aur existing projects `project_*` tools se isi conversation mein manage/edit/check kiye jaate hain.
- Project tree, search, line-numbered read, exact edit, write, replace, templates, lint/run/test, history/checkpoint/diff/undo/restore, project/file management aur export ke liye assistant ko relevant tools khud call karne ki hidayat hai; user ko tool names ya JSON type karne ki zaroorat nahi.
- Har project change ke baad real `project_check` run karne aur sirf actual test results report karne ki hidayat add ki.
- Yeh chat-routing/system-prompt update hai, har external provider ko unlock karne wala change nahi. API keys, Android permissions, supported runtimes aur feature implementation ki boundaries ab bhi apply hoti hain. Is environment mein Gradle/Android SDK available na hone ki wajah se APK compile aur device test verify nahi hua.


## v99.1.37 — ZIP project review directly in chat
- Uploaded ZIPs with project files are routed to the real Code Studio project for review requests such as analyze, audit, report, explain, check, or test.
- Review mode returns a structured code/project report in chat and runs the available static check. Explicit run/test requests also invoke the project's supported run/test check.
- ZIP import/export preserves binary assets (such as images, fonts and media) within configured size limits; binary contents are not sent to the AI model.
- Review mode does not intentionally edit project files; use a clear fix/change request to enter the edit workflow.
- Results distinguish tool output from model analysis; actual execution depends on the supported project type/runtime.


## v99.1.38 — Code Studio ke controls main chat mein

Ab chat tool workflow mein `project_studio` quick actions bhi shamil hain: `preview` (project card par in-chat preview), `run_python`, `run`, `test`, `lint`, `fix_preview_errors`, `undo`, `diff`, `history`, `checkpoint`, `restore`, `compare_checkpoint`, `stats`, `deps`, `format`, `export_zip`, `export_html`, `deep_think`, `rename`, `delete`, aur `list_projects`. Existing project tree/read/write/edit/search/replace/manage/history/template tools pehle se available rehte hain.

Jab chat se Code Studio project tool chalta hai, reply ab affected project ka card attach karta hai (jab project resolve ho): files, Preview, Full screen, Download ZIP aur Code Studio buttons. HTML export aur ZIP export downloadable file card banane ke liye phone storage ki existing file workflow use karte hain. Python run aur runtime checks current in-app runner/available dependencies ki limitations ke adheen hain; har language/platform ko phone par run karne ki guarantee nahi.


## v99.1.39 — Code Studio ke modes ab main chat mein

- Main chat tool `project_studio` se Build, project-aware Ask, Edit/Revise aur Prompt Enhancer use kiye ja sakte hain.
- Har chat ke project card ke `⋯ Tools` menu se Run/Test/Lint/Python, bug-fix, optimization, tests, UI, security, responsive, undo/diff/history/checkpoint, stats/dependencies/format/export aur Deep Think tak seedha access milta hai.
- Code Studio ke quick actions (Find bugs, Optimize, Add tests, Better UI, Security review, Cleanup, Responsive) chat se project ki asal files revise karte hain.
- Existing project tools (`project_tree/read/write/edit/search/replace/manage/check/history/template`) aur chat project card (file view/copy/download, inline web preview, ZIP download, optional Code Studio) saath rehte hain.
- Run, Python, preview fix diagnostics, undo/history/checkpoints, stats/dependencies/format aur exports `project_studio` actions ke zariye expose hain.
- Runtime capability har project/language ke liye ek jaisi nahi. Python runtime/libraries unsupported hon ya web preview ka entry na ho to app woh limitation bataye; build/test ko successful tabhi kahe jab result waqai confirm kare.
- Is source update ke ZIP integrity checks build ki jagah nahi lete. Android APK build aur device QA alag se karna zaroori hai.


## v99.1.40 — Chat typography aur answer layout

- AI jawabat ab **sans-serif** font mein render hote hain; body text 16sp aur line spacing/paragraph gaps ko zyada readable banaya gaya hai.
- Markdown heading hierarchy: `#` = 25sp main heading, `##` = 21sp section, `###` = 18.5sp subsection, `####` = 17sp, aur chhoti subheadings 16sp. Main heading theme accent colour mein hoti hai.
- Bullets aur numbered points ko alag marker colour, consistent indentation aur line wrapping milti hai. Quotes accent strip/card mein render hote hain.
- Markdown tables ab horizontal-scrollable styled rows/cells mein dikhte hain; header row bold aur theme accent se alag nazar aati hai.
- AI prompt ko bhi behtar response structure, paragraph length, headings, lists, bold emphasis aur code fences ki hidayat di gayi hai. Live streaming text mein bhi serif se sans-serif typography use hoti hai.
- Android build aur device rendering is environment mein run nahi ho saki; final visual spacing ko Android Studio build aur phone par verify karna abhi baqi hai.


## v99.1.41 — Live Voice: Cinematic Orb + Boss Persona

- Live voice ka central/floating orb ab futuristic holographic nebula, orbital rings, particles aur audio-reactive ripples use karta hai.
- Visual state actual session/mic/output ke hisaab se `CONNECTING`, `LISTENING`, `PROCESSING`, `SPEAKING` ya `NEEDS ATTENTION` dikha sakta hai.
- Orb ko zyada visible kiya gaya hai; voice session band hone par stale animation state reset hoti hai.
- Live voice persona user ki request ke mutabiq unhein naturally `Boss` kehti hai, normal aur personal conversation mein warm/candid rehti hai, aur task/API/permission issues ko chhupati nahi.
- Persona real consciousness ya human emotions ka jhoota claim nahi karti; confirmations, tool verification aur safety rules barqarar hain.


## v99.1.42 — Live Voice display toggle, proactive health alerts & real model report

- Voice and language settings now include an immediate ON/OFF toggle for the Live Voice Buddy center hologram. When overlay permission is unavailable, the in-app orb follows the same toggle.
- Settings include AI self-check/failure alerts. After repeated measured failures for the same model, Anjoo can send a low-volume diagnostic notification with the likely key, quota, model, request or server category. It never puts keys or raw provider responses in notifications. A successful response after a previously alerted failure can trigger one recovery notice.
- Model reports show real local API success/failure counters, successful-response latency, last measured error class, sample size, and untested models. Inferred skill profiles are labeled as estimates. The app explicitly does not pretend these counters measure factual answer accuracy.
- Models/keys menu can export the app's report as an actual PDF, Word (.docx), Excel (.xlsx), or TXT file and open Android's share sheet.
- Coding instructions emphasize real project inspection, maintainable multi-file edits, strongest available tests, and honest verification status.

Build status: source-level checks only in this environment; Android SDK/Gradle wrapper was not available for a local APK build or on-device test.


## v99.1.43 — Buddy terminology and controls
- Settings → Voice and language now uses the correct **Live Voice Buddy — center hologram** label (not “busy orb”).
- Added a separate **Floating Buddy character** toggle for the small mascot overlay. Both controls work without restarting an active voice session.
- The central live hologram now identifies itself as **ANJOO BUDDY** while its status continues to show the actual listening/processing/speaking/error state.
- Floating Buddy respects the existing foreground/background visibility behavior when toggled back on.


## v99.1.59 — Universal AI behavior upgrade
Master instructions ko mazboot kiya gaya hai: assistant ab available tools ke zariye sirf mashwara dene ke bajaye kaam execute karne, files/project inspect karne, coding changes verify karne, requested artifacts banane, aur limitations sach-sach batane par focus karega. Existing features preserve kiye gaye hain. Yeh update khud se unavailable apps/services ya device permissions add nahi karta.

## v99.1.63 — Codixa + Preview Fidelity
- Sidebar mein New chat ke bilkul neeche Codixa shortcut add hai.
- Codixa se saved projects, project files/code, project build history/chat, live web preview aur ZIP export khol sakte hain.
- Product builds ab implementation audit force karte hain, taa-ke sirf notes mein feature claim karna kaafi na ho.
- Native Android/Flutter ya backend projects ke liye WebView preview ko native compiled app na samjhein; preview prototype ko same core screens/workflows cover karna chahiye.


## v99.1.64 — Codex-style workspace UI
- App ko Midnight dark-blue workspace theme par migrate kiya gaya; baad mein user apni Appearance setting se theme badal sakta hai.
- Home screen par task cards: app build, code fix, UI improvement aur project review. In cards se prompt composer mein aata hai; khud se send nahi hota.
- Composer ke paas Think, Web, Code, Image aur Big project ke persistent mode controls add kiye gaye. Code mode coding-agent workflow instructions aur higher response budget select karta hai.
- Answer activity ko alag Thinking aur Results tabs mein dikhaya jata hai. Results tab recorded actions, status, files aur available preview link dikhata hai; raw private reasoning text display nahi hota.
- Codixa ko project search, compact project cards, code files, project chat/history, preview aur ZIP export ke saath restyle kiya gaya. Sidebar shortcut ke liye missing optional parameter bhi register kiya gaya.

Build status: ZIP integrity, manifest XML, and source-structure checks passed. Android SDK aur Gradle wrapper executable is environment mein available nahi thay, is liye APK build aur device testing nahi hui; compile success ka dawa nahi hai.


## v99.1.65 — HS AI App Builder
- Main history/menu mein Codixa ke neeche HS shortcut add kiya.
- Home workspace mein bhi HS shortcut diya.
- HS screen mein Websites & Apps aur Images & Videos modes, Plan first toggle, editable prompt composer, templates, saved projects aur available previews ke shortcuts hain.
- Build action selected prompt ko Anjoo chat mein prefill karta hai; generation, integrations aur publishing actual project/API credentials aur hosting support par depend karte hain.

Note: HS ka Build button task ko MainActivity ke existing submit handler se submit karta hai. Full cloud publishing, live database, auth aur payment processing ki availability unke actual provider/configuration par depend karti hai; screen khud se ye services provision nahi karti.

## v99.1.66 — HS native app mode + cloud APK builder
- HS mein Web Apps, Android APK aur Media ke alag modes add hain. Android mode complete Kotlin/Gradle Android Studio project aur matching interactive `index.html` prototype banane ki instruction deta hai.
- HS aur Codixa project cards par **Build APK** action add hai.
- Naya HS APK Builder user-owned private GitHub repository aur fine-grained token se connect hota hai. Token Android Keystore-backed encryption se app storage mein save hota hai.
- Builder selected project ZIP upload karta hai, GitHub Actions workflow provision/dispatch karta hai, run status/artifact poll karta hai aur successful APK ko phone ke Downloads folder mein save karke Install now option deta hai.
- Auto mode native Gradle project detect karta hai; static website par WebView APK wrapper ban sakta hai. WebView APK website ko native Android UI mein convert nahi karta.
- Project ZIP mein `.env`, keystores aur listed secret/build directories exclude kiye gaye hain. Source ZIP temporary private GitHub Release asset ke taur par upload hota hai, normal code commit nahi; build ke baad asset/release/tag delete karne ki koshish hoti hai. Cleanup permission fail ho to GitHub repository ke Releases tab mein `HS temporary source ...` item manually delete karein. GitHub Actions run/log history repository mein rehti hai.
- Setup guide: `HS_APK_BUILDER_SETUP.md`.

Build status: AndroidManifest XML parse, workflow YAML parse, embedded Python syntax and simulated safe extraction/WebView wrapper checks passed. Is environment mein Android SDK aur usable Gradle installation available nahi thi, is liye Anjoo APK compile ya physical-device test nahi kiya gaya.


## v99.1.67 — HS cloud token vault
- HS APK Builder mein optional Supabase email-OTP login, remote encrypted token backup, restore, aur delete buttons add kiye.
- GitHub token ke liye server-side AES-GCM vault Edge Function plus RLS-protected table migration shamil hai. GitHub token APK/source mein hardcode nahi hota.
- Uninstall ke baad GitHub PAT restore karne ke liye same Supabase account par email OTP login karein; local Android Keystore data reinstall se survive nahi karta.
- Activation ke liye Supabase SQL migration, `hs-github-token` Edge Function, `HS_TOKEN_ENCRYPTION_KEY` secret, email OTP aur Supabase public anon/publishable key configure karna zaroori hai.

Build status: source-level checks only; Android SDK/usable Gradle install aur deployed Supabase credentials available nahi thay. Isliye APK build, Edge Function deployment, aur live cloud restore test nahi hue.


## v99.1.68 — HS Supabase project selected
- HS Cloud Token Vault ka default Supabase URL user ke naye project `https://vzlgekjtgqpezuvqcawb.supabase.co` par set kiya.
- Public anon/publishable key, Edge Function deployment, aur encryption secret abhi dashboard mein configure karna zaroori hai; URL set hone se backend apne aap deploy nahi hota.

## v99.2.52 — Voice aur Multimodal
Voice and language menu mein **Voice & Multimodal readiness report** add hui hai. Is se microphone permission, Google speech, Groq/Gemini STT, Gemini Live prerequisites, cloud/Android TTS, image aur document capabilities ka status dekha ja sakta hai. Report se voice test bhi chala sakte hain. Yeh local readiness checks hain; provider ki live quota ya model access ki guarantee nahi. Arbitrary video files ki understanding ko supported mark nahi kiya gaya.

## v99.2.53 — Agent System / Autonomous Execution
- `agent_execute` tool complex multi-step task ko pehle plan karta hai, 3–7 checkpoints Task Board par save karta hai, phir existing Anjoo tools se kaam execute karta hai.
- Assistant simple sawal ya ek seedhe action ke liye extra agent run nahi chalata; end-to-end multi-step kaam par orchestrator use karta hai.
- Task Board cards par agent ka current stage, activity aur checklist live refresh hoti hai. Running task ko Pause, Resume ya Cancel kiya ja sakta hai; control current model/tool operation ke baad apply hota hai.
- Incomplete ya blocked kaam Done mark nahi hota; Retry saved prompt se dobara run karta hai.
- Background agent required confirmation ko bypass nahi karta. Call/SMS, delete/overwrite aur doosre confirmation-gated actions bina user approval ke complete nahi honge.

Build status: tool declaration JSON, new orchestrator Kotlin syntax/type check with minimal stubs and source integration checks passed. Full Android Gradle build / phone test pending because this environment has no Gradle executable, Gradle wrapper launcher/JAR or Android SDK.
