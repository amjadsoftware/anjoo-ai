# v100.0.43

HS APK Builder, improvement 1: real build errors inside the app.

- When the cloud build fails, the app now reads the failed step and the key error lines (Gradle "What went wrong", Kotlin `e:` lines, manifest/resource errors) from the GitHub job log and shows them in the failure dialog, instead of only a link.
- New **Copy error** button in the failure dialog.
- New `BuildLogParser.kt` (pure Kotlin) with `BuildLogParserTest.kt`.
- Not changed: build flow, workflow file, token handling, upload limit.
- Not compiled or run here (no network/Android SDK in this session); the GitHub build will compile it.
