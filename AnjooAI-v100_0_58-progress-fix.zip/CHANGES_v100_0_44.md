# v100.0.44

HS APK Builder, improvement 2: build an APK from any ZIP on the phone.

- New **Import ZIP from phone** button in HS - APK Builder: pick a ZIP, it is unpacked into your projects, then "Build APK now?".
- New `Coder.importBuildZip`: keeps deep Android source paths (the old import dropped paths deeper than 7 folders and anything after 400 files) and allows up to 20000 files / 250 MB unpacked. node_modules, .git, build, .gradle and similar folders are skipped; unsafe paths are rejected.
- Upload limit raised from 8 MB to 25 MB (compressed); uploads use a client with a 15-minute limit so slow connections do not time out.
- Project cards no longer read every file's text on the UI thread (only counts files), so large imported projects do not freeze the screen.
- Limits: a React/Vite *source* project without a built index.html will give a blank WebView page; build it first or import its built folder.
- Not compiled or run here (no network/Android SDK in this session).
