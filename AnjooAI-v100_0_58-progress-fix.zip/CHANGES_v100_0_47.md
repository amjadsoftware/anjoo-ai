# v100.0.47

HS APK Builder, improvement 5: native builds use the project's own Gradle.

Changed only in `app/src/main/assets/hs-build-apk.yml` (installed into your private build repository automatically on the next build):
- If the project has a complete Gradle wrapper (`gradlew`, `gradle/wrapper/gradle-wrapper.jar`, `gradle-wrapper.properties`), that wrapper is used.
- If the wrapper is incomplete (for example only `gradle-wrapper.properties`), a wrapper for the Gradle version named there is created.
- If there is no wrapper at all, the Android Gradle Plugin version is read from the build files (`id("com.android.application") version`, `com.android.tools.build:gradle:`, or `agp =` in `libs.versions.toml`) and the Gradle version it needs is used (table for AGP 7.0 to 8.13).
- Otherwise Gradle 8.7 as before. The chosen Gradle is written to BUILD-INFO.txt and shown in the "APK is ready" dialog.

Bug fixed (existed before): when a package name was typed in "App info", the script that patches `applicationId` and `versionName` had unbalanced quotes in its regular expressions and stopped with a SyntaxError, so every native build with a package name failed. It now works, validates the package name and version, and cannot be broken by special characters.

Checked here: the workflow YAML parses, the shell script passes `bash -n`, both embedded Python scripts compile, and the version picker and the patch script were run on sample projects. Gradle itself was not run (no network in this session); the GitHub build will show it.
