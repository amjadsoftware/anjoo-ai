# v100.0.53 — APK Builder fix (Set up Android SDK failed)

## Cause
GitHub Actions failed at "Set up Android SDK" in 22 s: `android-actions/setup-android@v3` runs
`sdkmanager tools platform-tools` by default, and the newer cmdline-tools no longer contain a
package named `tools` -> "Warning: Failed to find package 'tools'", exit code 1.

## Fixes
1. `app/src/main/assets/hs-build-apk.yml` (and `.github/workflows/tests.yml`): `setup-android` now gets
   `packages: 'platform-tools'`, so the missing `tools` package is no longer requested. The later
   step still installs the platform + build-tools the project needs.
2. `HsApkBuilderActivity.waitForRun`: a single network timeout while polling GitHub (the plain
   "timeout" error on weak mobile data) no longer aborts the build. It retries; only after 8
   consecutive failures does it stop, and then with the build-log link.

The app re-uploads the fixed workflow into your private GitHub repo automatically on the next build.
