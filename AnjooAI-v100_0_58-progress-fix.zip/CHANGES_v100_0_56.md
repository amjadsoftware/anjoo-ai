# v100.0.56 — fixes from the Idea → APK audit
1. Unfinished projects (build interrupted by network loss / Stop / usage limit) are now flagged "⚠ Unfinished" in the APK Builder list,
   are not offered as "Your app is ready", and building them shows which files are missing (with "Build anyway" override).
   New: Coder.missingFiles(dir).
2. WebView wrapper (hs-build-apk.yml):
   - Camera / microphone: getUserMedia now works (runtime permission prompt; manifest permissions added, hardware not required).
   - Downloads: normal http(s) links (DownloadManager), blob: and data: URLs (e.g. "export JSON/CSV" buttons) are saved to Downloads.
   - Status bar takes the page's <meta name="theme-color"> colour.
   - Still not supported: Web Speech API (speech recognition), push notifications.
