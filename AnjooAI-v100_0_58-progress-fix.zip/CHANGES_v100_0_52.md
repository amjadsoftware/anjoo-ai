# v100.0.52

HS APK Builder, improvement 9: app name from the ZIP, and a default icon.

- **App name:** a ZIP picked with "Import ZIP from phone" now names the app from the ZIP file name, cleaned: extension, version tails (-v1.2, _v100_0_51, -1.2.3), "(1)"/copy suffixes and underscores/dashes are removed, CamelCase is split ("AnjooAI" -> "Anjoo AI", "PUBGMobile" -> "PUBG Mobile"), words are capitalised, at most 30 characters, "My App" if nothing is left. The name is shown in the "ZIP imported" dialog and is the app label of the installed WebView APK. Names that are already clean (for example "Offline Battle Royale", "Ludo Game 2") are unchanged. `AppNaming.kt` + `AppNamingTest.kt`.
- **Icon:** WebView APKs now have their own launcher icon (before, they got the plain default Android icon): a small green Android robot on a dark green background with a small Anjoo AI badge (terracotta circle with a white star) at the bottom right. It is an adaptive vector icon (no image files), so it stays sharp on every phone and works with round, square and squircle icon shapes. A preview image is included next to the zip: HS-APK-default-icon-preview.png.
- Changed only: workflow `hs-build-apk.yml` (icon resources and manifest icon attributes), `Coder.importBuildZip` (name), the builder's project_name input and the import dialog text.
- Not changed: native Gradle projects keep the name and icon inside the project; packages, signing, limits.
- Not compiled or run here (no network/Android SDK in this session). Checked here: the workflow YAML parses, the wrapper generator runs and writes the icon, the vector XML is well-formed, and the icon was drawn to a preview image from the same shapes.
