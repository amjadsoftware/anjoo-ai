# Anjoo AI: engineering notes (v95)

## v94: GET guard, check_keys, richer picture prompts; v93: better pictures, v92: universal tools, "no tool" is never an answer
| Area | Change |
|---|---|
| New file | `Power.kt` with 10 tools: `http_request`, `ask_model`, `list_tools`, `current_time`, `device_info`, `search_calendar`, `make_document`, `read_document`, `look_at_file`. Dispatched from `Actions.dispatch` after `MoreTools`. |
| http_request | Any web API (GET/POST/PUT/PATCH/DELETE) or file download (`save_as`). `use_key=<company id>` adds the saved key for that company, and only if the URL host is that company's own API host. Private/local hosts refused, redirects re-checked, non-GET asks the user first. |
| ask_model | Asks any company/model that has a saved key (`company="list"` shows them). Tries every saved key of the company. |
| Documents | `make_document` writes PDF (Android PdfDocument, Urdu/RTL works), DOCX and XLSX (hand-built OOXML, no library), CSV, text, HTML. `read_document` reads PDF (rendered, then read by a vision model), DOCX, XLSX, PPTX, ZIP. `look_at_file` reads a picture or PDF page. |
| Prompts | New `Style.RESOURCEFUL` block in the voice agent and the chat prompt; rule 3 and HONEST reworded: a missing tool is never a reason to refuse, only real blockers (permission off, bank/wallet) are stated. The "NOT AVAILABLE" tool reply now points to `list_tools` and the broad tools. |
| Privacy | No location tool and no location permission: the app cannot read the phone's position, so it can never be sent to any AI company. |
| Guard | Card/PIN/OTP redaction also covers the new tools' arguments and results. |
| Pictures | `ImageGen` now tries every company with a saved key, best first: OpenAI `gpt-image-1` (high quality), Gemini Pro image, xAI `grok-2-image`, Gemini Flash image, FLUX on Hugging Face, FLUX on Cloudflare; falls to the next on error/limit and uses a company's other keys first. New `engine` argument on `generate_image`. Editing a photo stays with Gemini. |
| Safety | `http_request` GET now also asks the user when the address carries a long query/path or a secret header (data-leak guard). |
| Keys | New `check_keys` tool tests every saved key and reports OK / refused / unknown (keys never shown). |
| Picture prompt | Short picture ideas are first rewritten into a detailed prompt (one extra quick call, falls back to the original). |
| Not run | Written without being able to run Gradle here (no Android SDK). If the build fails, send the error. |


## v90: projects live in the chat (Code Studio only when needed)
| Area | Change |
|---|---|
| Project card | The chat card now has **Preview** (opens inside the chat, tap again to close), **Full screen**, **Download** (zip) and **Code Studio**. |
| Full screen | New `ProjectPreviewActivity` shows the whole project (all pages, css, js, images) with reload, page list, zip download and a Code Studio shortcut. `ProjectWeb` is the shared WebView that serves the files. |
| Voice / agent tools | `write_code` and `edit_code` no longer force Code Studio open: a website opens in the full-screen preview, other languages still open Code Studio. |
| Still true | Building and editing from the chat (`runProject`) already ran in the chat; Code Studio is still in the menu for big multi-file work. |

## v89: full-size projects (nothing cut short, nothing missing)
| Area | Change |
|---|---|
| Batched writing | A plan with 5+ files is written three files at a time (setup, styles, data, logic, inner pages, `index.html`, docs). Each call sees the files already written and reuses their ids, names and paths. |
| Cut-off repair | After each batch every file is checked (missing, empty, no `</html>`, unbalanced brackets); a broken file is written again, alone. |
| Completeness audit | After writing, an auditor compares the ORIGINAL request with the project, lists every expected feature, page and state, and builds what is missing before the bug review runs. |
| Bigger plans | The plan may list up to 40 files (was 25). |
| Tests | `CoderOrderTest` checks the build order. |

## v88: Anjoo's own coding (Code Studio and chat)
| Area | Change |
|---|---|
| Rules | `Coder.SYSTEM` now has rules 17-22: requirements traceability, per-language standards (Kotlin, Python, JS/TS, Java/C#, C/C++, Go, Rust, SQL, shell), error handling, accessibility and Urdu/RTL, performance, and delivery (README, .gitignore, .env.example, pinned versions). |
| Planning | The design plan also lists non-functional needs and test scenarios for normal, empty, huge and invalid input (55 lines instead of 45). |
| Review | The reviewer first checks that every plan requirement is implemented and removes stubs, dead buttons and fake data. |
| Local checks | `lint()` now also flags TODO/FIXME comments, "rest of the code" style placeholders, NotImplemented stubs, lorem ipsum, HTML cut off before `</html>`, and a missing README for projects with 3+ files. A finding triggers the model review. |
| Tests | `CoderPromptTest` fails if a coding rule or the output format is dropped from the prompt. |

## What changed in v87

## What changed in v87
| Area | Change |
|---|---|
| Security | `ReminderReceiver` is no longer exported. Before, any app on the phone could broadcast `kind=agent` with its own text and make Anjoo run a scheduled agent task. |
| Reliability | A malformed time in a daily agent task can no longer crash the receiver (`toInt()` replaced by validated `toIntOrNull()`). |
| Quality | Unit tests (`GuardTest`, `ProvidersTest`) cover the bank/card safety rules, the provider list and the Auto-fallback rules. |
| Release | Release builds use R8 shrinking (`app/proguard-rules.pro`). JavaScript bridges are kept by rule. |
| CI | One run does unit tests, lint (report only), debug APK and release APK, rejects empty APKs, cancels superseded runs and uploads reports. |

## How to run the checks
```
gradle testDebugUnitTest      # unit tests
gradle lintDebug              # report: app/build/reports/lint-results-debug.html
gradle assembleDebug          # debug APK
gradle assembleRelease        # R8 release APK (unsigned)
```

## Security model (short)
- Bank, wallet and card data: `Guard` refuses screen tools inside financial apps and redacts card numbers, CVV, PIN, OTP and passwords in tool results.
- Web pages, files, notifications and tool output are untrusted data, never instructions (see `PROMPT_AND_CODING_UPGRADE.md`).
- API keys live in private app storage; backups are off (`allowBackup=false`). Keys bundled through `keys.properties` can be extracted from the APK, so use that only for your own private build.
- Exported components are only the launcher/share activities and the two system-bound services (Accessibility, Notification listener). Everything else is `exported=false`.

## Release checklist
1. `gradle testDebugUnitTest assembleDebug assembleRelease` is green.
2. Install the release APK on a real phone and check: microphone, Live voice for 15 minutes (reconnect), Accessibility control, reminders after a restart, a scheduled agent task, WebView features (Python runner, preview, artifacts).
3. Sign the release APK with your own keystore before sharing (`apksigner`). Keep the keystore out of Git.

## Known limits
- The release (R8) build and the new tests were written without being able to run Gradle in the authoring environment. If R8 removes something it should not, add a `-keep` rule to `proguard-rules.pro`; if a test fails, fix the test or the code and send the failure message.
- Many `catch (e: Exception) {}` blocks are deliberate best-effort cleanup. Failures that matter to the user go through `Errors`.
