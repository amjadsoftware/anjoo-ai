package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import java.security.MessageDigest

/**
 * Keys work normally in the app. Only EXPORTING them is locked: "Export keys", the encrypted Keys-backup and a backup
 * "with key" all ask for the passcode first. The passcode is stored only as a salted SHA-256 hash (not as text).
 * After the right passcode, export is open for 5 minutes, then locks again.
 * Limit: this stops export through the app. It cannot stop someone who has the APK or a rooted phone.
 */
object KeyLock {
    private const val HASH = "cd55aa2032243ace8be2cac4675e08b498662c8bafe3bdae467fe8d6d555072a"
    const val MESSAGE = "Export is locked. Enter the passcode first."

    @Volatile private var openUntil = 0L
    private var wrong = 0
    private var blockedUntil = 0L

    fun isUnlocked(): Boolean = System.currentTimeMillis() < openUntil

    fun matches(code: String): Boolean {
        val d = MessageDigest.getInstance("SHA-256").digest(("anjoo-keylock|" + code.trim()).toByteArray(Charsets.UTF_8))
        val hex = d.joinToString("") { "%02x".format(it) }
        return MessageDigest.isEqual(hex.toByteArray(), HASH.toByteArray())
    }

    /** Asks for the passcode; runs [onOk] only when it is right. */
    fun ask(act: Activity, onOk: () -> Unit) {
        if (isUnlocked()) { onOk(); return }
        val now = System.currentTimeMillis()
        if (now < blockedUntil) {
            Toast.makeText(act, "Too many wrong tries. Wait " + ((blockedUntil - now) / 1000 + 1) + " seconds.", Toast.LENGTH_LONG).show()
            return
        }
        val et = EditText(act).apply {
            hint = "Passcode"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(act).setTitle("🔒 Export lock")
            .setMessage("Keys can be exported only with the passcode.")
            .setView(et)
            .setPositiveButton("Unlock") { _, _ ->
                if (matches(et.text.toString())) {
                    wrong = 0
                    openUntil = System.currentTimeMillis() + 5 * 60_000L
                    onOk()
                } else {
                    wrong++
                    if (wrong >= 5) { blockedUntil = System.currentTimeMillis() + 60_000L; wrong = 0 }
                    Toast.makeText(act, "Wrong passcode.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null).show()
    }
}
