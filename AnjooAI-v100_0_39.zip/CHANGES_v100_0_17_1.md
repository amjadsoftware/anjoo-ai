# v100.0.17.1
Full version: English-only UI (everything from 100.0.16.0 to 100.0.16.7 combined) plus the Claude-style live progress line and Summary sheet.
See CHANGES_v100_0_16_*.md for details. Recognisers and AI-facing prompts were intentionally left unchanged.
