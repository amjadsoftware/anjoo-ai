# v100.0.24 - App map completed (verified against the real menus)

- AppMap now covers what the v100.0.22 audit listed as missing: exact Settings order, Text size, Anjoo language, Live AI hologram style, Privacy lock, Agent System (Workspace list), the "Fix the problem" pop-up, and how to talk to ChatGPT/Gemini/other AIs (ask_model).
- Every label was checked against MainMenus.kt, MainActivity.kt and strings.xml; nothing was added that is not in the code.
- Test: AppMapTest.settingsDisplayAgentAndFixAreKnown.
- Version 100.0.24 / fallback code 100024. Not built with Gradle here (no Android SDK); check the build and tests in CI.
- Not changed: the fixed signing password in build.gradle.kts (anjooFixed, needed so new APKs install over old ones). The Supabase publishable key in build.gradle.kts is a public-style key, but move it to an environment variable if you can.
