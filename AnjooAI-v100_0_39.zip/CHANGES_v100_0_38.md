## v100.0.38 — Admin Center, part 1 (local mode, no Supabase, no payments)
Built so you can check what really works before connecting anything. Everything is measured on this phone.

- New **Admin Center** (Workspace menu: "🛠 Admin Center") with the 12 sections of the plan. Each section shows an honest status chip: Ready, Partly ready, Needs backend, or Not built yet. A section that is not built is not tappable, so there is no button that does nothing. The top card shows "N of 12 sections ready".
  - Ready: Overview (opens Operations), Memory & Knowledge (opens the Overview tab), Security & Audit (new).
  - Partly ready: AI Models (health is in Overview; providers and keys are in Settings), Agents (Agent runs, limits and permissions), Tasks & Workflows (Task Board).
  - Needs backend: Users (multi-user, roles, subscriptions).
  - Not built yet: Finance & Billing, System Monitoring, Notifications, Reports & Analytics, Settings.
- The separate "Operations" and "Agent runs" menu entries are now inside the Admin Center (no duplicates).
- New **Security & Audit** screen backed by `AdminAudit`, an audit log of events that really happen:
  - key-export passcode accepted, wrong passcode (with attempt number), export locked after too many wrong tries;
  - actions blocked by the bank/wallet/card safety rule;
  - tools paused after repeated failures (v100.0.34 rule).
  The log is append-only inside the app (no edit or clear), keeps the newest 500 events, and never stores prompts, keys, passcodes or tool output. Identical events within 30 seconds are logged once.
- Suspicious-activity check (rule based, from the log): 3+ wrong passcodes, 5+ money-safety blocks or 3+ tool pauses in 10 minutes show a "Needs attention" box and are counted in the Admin Center.
- Filters by category (security, agent, admin, system), 24-hour counts, "Show more" paging.
- Tests: `AdminAuditTest` (encoding, trimming, repeat skipping, the three attention rules).
- Not done and not faked: user accounts, roles, subscriptions, payments, revenue, server/database monitoring, notifications, reports, central settings. The "admin" and "system" log categories exist but nothing writes to them yet (the admin settings and monitoring sections do not exist yet).
- The new screens follow the app theme (light/dark). Operations and Agent runs still use a fixed light style; to be unified later.
- Verification: source review and bracket-balance check only. Not compiled and the new tests were not run (no Gradle/Android SDK here).

### Next small steps (one zip each)
1. AI Model Control Center (providers, primary model, fallback order, model test) 2. Agent controls (admin-set step and retry limits and a tool allow/deny list, enforced) 3. Finance (local token cost, budgets, estimates marked as estimates) 4. System Monitoring (real on-phone metrics) 5. Notifications 6. Reports with CSV/PDF export 7. Central Settings 8. Backend-ready schema (SQL files and sync interface, not connected).
