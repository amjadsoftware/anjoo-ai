# v100.0.19.3
Real Git for Code Studio projects: new tool `project_git` (clone, init, status, diff, commit, pull, branch, checkout, log, PR). Works through the GitHub API (the phone has no git binary), so it needs internet and a GitHub token.
- New: Git.kt. The project keeps a small file `.anjoo-git.json` (repository, branch, base commit, and the real Git blob id of every tracked file). "What changed" is computed exactly like git does it, with no second copy of the files.
- clone: repo = owner/name or a GitHub URL (ref = branch, project = new project name). Downloads one zip, so it is fast.
- init: turns a project into a NEW repository (private by default, private=false for public). Asks first.
- status: new / changed / deleted files, and whether the remote branch has newer commits. diff: line-by-line changes (path optional).
- commit: ONE real commit on the current branch with every change, sent straight to GitHub (there is no local-only commit and no separate push). Refuses when the remote has newer commits (pull first). Asks first.
- pull: 3-way merge. Your edits stay, remote edits come in, files changed on both sides get `<<<<<<< local / ======= / >>>>>>> remote` markers (strategy=markers, default), or strategy=theirs / ours. A commit is refused while markers are still in a file. A pull can be undone with project_history undo.
- branch (list or create + switch), checkout (switch with the same merge), log, pr (open a pull request), prs (open PRs), pr_merge (squash / merge / rebase). Asks first.
- Secret guard: a commit stops when a changed file looks like it holds a secret (.env, keys.properties, keystores, GitHub / AWS / Google / AI provider keys, private keys, key = "..." assignments). Only the file and the kind are shown, never the value. allow_secrets=true overrides it.
- .gitignore is honoured (names, *.ext, dir/, /rooted, ** patterns); tracked files are never hidden by it.
- Settings > "GitHub (project_git ...)" > GitHub token (hidden input, Save, Test). It is the same token that Publish to GitHub Pages uses. The AI is told never to ask for the token in chat.
- Tool registry: category Code, risk External, readiness "needs setup" until a token is saved. Prompt (Style.PROJECT_TOOLS) explains the workflow: status first, pull when the remote is newer, merge markers before committing.
Limits: no rebase, amend or force push; executable bits and symlinks are not kept; files over 25 MB and repositories over 3,000 files are not handled; there is no local-only commit; GitHub only (no GitLab or Bitbucket).
Tests: GitTest (10 tests: real git blob ids, repository name parsing, status, 3-way pull plan, .gitignore, conflict markers, secret finder, unified diff, folder scan). NOTE: this build was written without a Kotlin compiler available, so run `./gradlew testDebugUnitTest` once before releasing.
