# v100.0.22 - Knowledge pack: performance, architecture, agent patterns

- Added three built-in knowledge files (assets/kb_pack): 08 Android performance and architecture, 09 AI agent design patterns, 10 Anjoo improvement roadmap. Based on Android developer documentation (Baseline Profiles, architecture recommendations) and published agent-design guides.
- KnowledgeSeed VERSION 1 -> 2 so existing installs load the new files once. Existing files are not duplicated (KnowledgeBase.addText skips content with the same checksum).
- Audit result: MainActivity.kt is ~6,100 lines; no Baseline Profile or lifecycle/coroutines libraries yet; AppMap lacks Agent System, Text size, Anjoo Language, Fix the problem, Data and privacy, Live AI agent appearance; signing password is in build.gradle.kts.
- Version 100.0.22 / fallback code 100022. Not built with Gradle here; check the build in CI.
