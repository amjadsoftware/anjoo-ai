# v100.0.26 - Faster replies and smarter thinking

- **Live streaming for OpenAI-style providers and Claude.** Before, only Gemini streamed; every other company's answer appeared only after it was completely written. Now words appear as they arrive (new `SseParse.kt`, used by `Providers.post`). Tool calls, usage ledger and the Gemini-shape conversion are unchanged. A server that ignores streaming still works (plain JSON fallback); a 400/422 mentioning "stream" retries once without streaming.
- **Smaller tool list for everyday chat.** Normal questions and phone commands now send 77 tools (about 23 KB) instead of all 159 (about 74 KB). Requests about projects, files, documents, code, browser or agents, attachments, and any chat that already used tools keep the full list. See `QuickChat.isLean` / `LEAN_TOOLS`.
- **Adaptive Gemini thinking.** Plain chat and phone commands use low thinking (first words sooner); hard problems (maths, analysis, comparing, explaining, Think mode) use high thinking (better answers). Falls back automatically if a model rejects the setting. `Gemini.thinkLevel`.
- **Less waiting on limits.** In Auto mode a 429 wait is capped at 6 s (then the next model is used instead of waiting up to 25 s); retry pauses after server-busy errors are shorter; connect timeout 20 s -> 10 s.
- Router "think" detection also catches explain/difference/recommend/estimate/formula style questions so they go to stronger models.
- Tests: SseParseTest (parsers compiled and run on the JVM here with a stub org.json; the Android build and full test run still need CI).
- Not changed: signing password and Supabase key notes from v100.0.24.
