## v100.0.33 — Enterprise upgrade, step 3: Agent runs history
- New screen `AgentRunsActivity` (menu: Workspace > "Agent runs"). Lists every autonomous run on the Task Board; tap one to see the task given, plan steps, a timeline of the stages the run really went through, and the saved result.
- `AgentOrchestrator` now records a per-run timeline (`agentLog`: time, stage, short activity line) every time the stage changes, including pause, resume, cancel, blocked and verification. Repeats are not logged twice; at most 80 events are kept (the first plus the newest). A new run starts a new timeline.
- Privacy: the timeline stores only stage names and short activity lines, never prompts, tool arguments or tool output.
- Honest limits shown on screen: plan step marks are only set when a run ends (they are not tracked step by step), and runs made before this version have no timeline.
- Verification: source review and bracket-balance check only. Not compiled or run (no Gradle/Android SDK here). Please build and run an agent task, then open Workspace > Agent runs.
