## v100.0.36 — Fix: model repetition loop
- Bug (screenshot): an answer repeated one line again and again ("11. Enterprise-Level School Management ERP: ... 12. ... 13. ..."). The app showed whatever the model streamed, with no check.
- New `RepetitionGuard`: three identical repeats in a row (a sentence, or a block of up to 4 sentences; numbering and bullets ignored) count as a loop. Sentences under 25 characters and everything inside ``` code blocks are ignored, so normal answers are not cut.
- Streams stop as soon as a loop is found (Gemini stream reader and OpenAI-style stream reader), the answer is cut back to its first copy, and a short note is added: "The model started repeating itself, so I stopped it here...". The cut text is also what goes into the chat history, so the loop does not feed the next request.
- Safety net for every provider and for non-streamed answers: the final answer of the main chat and of the agent loop goes through the same fix before it is shown.
- Not covered: the Anthropic-style stream reader stops late (the final-answer fix still cuts the text); loops inside code blocks are left alone on purpose.
- Tests: `RepetitionGuardTest` (numbered loop cut to one copy, idempotent, normal text unchanged, short repeats and code ignored, two-sentence loop, stream watch).
- Verification: source review only. Not compiled and the new tests were not run (no Gradle/Android SDK here). Gemini.kt shows the same bracket-count difference as the original file, which is the crude checker, not a change.
