# v100.0.18.4
3. Process: under a finished reply it is now one long line, full width, "≡  Process · 10 steps · 24s  ›" with the arrow at the end. Tap it to open the Summary sheet with every step. The list of 8 steps and "+2 aur steps" that used to sit below it is gone.
