# v100.0.19.9 — Deploy tool (project_deploy) and env secrets

New AI tool `project_deploy` (Code Studio, static sites):
- `publish` to Netlify, Vercel, Cloudflare Pages or GitHub Pages (asks first; same address on re-publish).
- `deploys` recent deploy history, `status`, `token_check`.
- Environment variables: `env_list` (names only), `env_push` (reads KEY=VALUE from the project's .env, values never shown to the AI),
  `env_set`, `env_delete`. Netlify, Vercel and Cloudflare Pages are supported (GitHub Pages has none).
- Settings > Deploy tokens: Netlify, Vercel, Cloudflare (API token + Account ID), with a Test button.

Security fixes found on the way:
- Netlify and GitHub Pages publishing used to upload EVERYTHING in the project, including `.env` and key files. They are now excluded
  (shared `DeployCore.collect`). A site that contains a real-looking secret is blocked unless allow_secrets=true.

Limits: static sites only (no build on the phone); env vars only reach serverless functions/builds on the host;
GitHub Actions secrets are not supported; the Vercel and Cloudflare upload flows were written from their API docs and have not
been run against the live services yet (the BLAKE3 hash used by Cloudflare is verified against the official library).
