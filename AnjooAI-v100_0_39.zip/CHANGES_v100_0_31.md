## v100.0.31 — Enterprise upgrade, step 1: audit and plan
- Added ENTERPRISE_AUDIT.md: spec-versus-source map, items that need a backend or credentials, and a one-task-per-zip plan.
- Version bumped to 100.0.31 / 100031. No other code changed.
- Not compiled or run here (no Gradle/Android SDK).
