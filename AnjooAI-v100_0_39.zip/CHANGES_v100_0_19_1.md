# v100.0.19.1
run_code completed:
- Backup server: if the main Judge0 server is busy (429), down, refuses (401/403) or cannot be reached, the run falls back to Wandbox (wandbox.org) for every language except Kotlin, Dart and R. The newest stable compiler is chosen (gcc for C/C++, cpython for Python, nodejs for JavaScript; "head" builds skipped; versions compared as numbers). The answer says which server ran it.
- Settings > "Code runner (run_code ...)": fields for your own Judge0 URL (https only) and key, Save, and a Test button that runs a tiny program and shows the real result or the real error.
- The user prompt now says the code may also go to wandbox.org.
- If both servers fail the answer says the code was NOT run, so the AI cannot claim a pass.
Tests: RunCodeTest now also covers Wandbox compiler choice and output format (35 tests in total across the new files).
Still not supported: multi-file builds (Gradle/Cargo/Maven) - one source file per run.
