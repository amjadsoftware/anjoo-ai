## v100.0.39 — Admin Center, part 2: Finance & Billing and System Monitoring (local mode)

Same rule as before: every number is real, nothing is invented, and what is not connected is said plainly.

### Finance & Billing (new screen, Admin Center > Finance)
- **Estimates and actual money are kept apart.**
  - *Estimate* = tokens measured on this phone (TokenLedger) × the prices you entered. With no price for a model the cost shows "unknown" / "≥", never 0.
  - *Actual* = payments you record yourself from a provider invoice (provider, amount, note). Stored privately in the app (`finance_records.tsv`), can be deleted with a confirmation.
- This month: tokens, requests, estimated cost, straight-line projection for the whole month, monthly budget bar (OK / near 80% / over). The budget only warns; requests are never blocked.
- Today, cost by model (this month), real tokens-per-day bars for the last 14 days.
- Edit prices and set the monthly budget from the screen. Both changes are written to the audit log (category "admin", first writer of that category).
- **CSV export** through the share sheet. Rows are labelled `ESTIMATE` or `ACTUAL (recorded by owner)`. Cells that start with `=`, `+` or `@` are neutralised so a spreadsheet cannot run them as formulas.
- Not built, not faked: revenue, subscription plans, online payments. They need a payment provider and a backend.

### System Monitoring (new screen)
- Read from the phone at the moment you open or refresh it: battery (level, charging, temperature), free storage, free device memory, app heap, app uptime, app data size, network type and whether the connection is verified, local database files and sizes, tasks running now.
- Measured by the app: per-model calls, failure % and average time (Router), tool runs (done, problems, needs setup, average and slowest time).
- Automatic alerts: battery ≤15% and not charging, free storage <10% or <500 MB, Android low-memory flag, no network, app heap ≥85%. Each problem is written to Security & Audit (category "system"), at most once an hour.
- Listed honestly as "Not connected": cloud server health, cloud database, job queues, server resource use (they need a backend).

### Admin Center
- Finance & Billing and System Monitoring are now "Partly ready" and open their screens.

### Tests
- New: `FinanceCoreTest`, `MonitorCoreTest`.
- Verification here: the pure logic (`FinanceCore`, `UsageBook`, `MonitorCore`) was compiled with the Kotlin 2.0.21 compiler bundled with Gradle and 10 checks were run and passed (record round-trip, bad-row rejection, unknown price, budget states, projection, amount parsing, CSV quoting/formula safety, money format, all five alert rules, formatting). The Android screens (`FinanceActivity`, `MonitorActivity`, the Admin Center edit, manifest) were NOT compiled: there is no Android SDK or network here. Bracket balance and API levels (minSdk 26) were checked by hand.

### Next small steps
1. AI Model Control Center (primary model, fallback order, model test) 2. Agent controls (step/retry limits, tool allow/deny, enforced) 3. Notifications center 4. Reports with PDF/CSV for every module 5. Central Settings and backup 6. Backend-ready schema (Supabase SQL, sync interface, not connected) for Users, roles and subscriptions.
