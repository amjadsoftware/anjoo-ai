# v100.0.18.0
6. Context compaction. When a chat gets long (more than 22 messages or about 48k characters), the oldest part is no longer cut off: the AI writes a short summary (goals, decisions, names, files, what is open, language) and keeps the newest 8 messages word for word. A second round merges the old summary with the new part. The summary is saved per chat and restored when the chat is reopened. If the summary call fails, nothing changes. New file: Compaction.kt.
8. Font choice. Settings > "Font (chat ke jawab)": Sans (default), Serif, Rounded, Mono. Applies to chat answers (and the streaming text). New file: FontPref.kt.
9. Download card. Under a long or structured answer (or any answer with a table) a file card appears with .pdf / .docx buttons, and .xlsx when the answer has a table (each table becomes a sheet). The "More" menu of every answer also has Download PDF / Word / Excel. New file: AnswerExport.kt.
Tests: CompactionTest, AnswerExportTest, FontPrefTest.
