# v100.0.16.6
English-only UI, step 6: Power (documents, web request, calendar), Actions (phone actions), MoreTools (notes, reminders, prayer, diary), APK Builder, Artifacts, Browser, Web, ImageGen. ToolRunLog classifier now recognises the English messages.
