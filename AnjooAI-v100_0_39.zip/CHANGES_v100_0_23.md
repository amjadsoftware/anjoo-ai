# v100.0.23 - Study mode: Anjoo learns from the internet (with your approval)

- New `Study.kt` + a STUDY MODE block in the always-on prompt (Style.extra). When you say "seekho / learn / study <topic>" or ask for best templates/structure/frameworks, Anjoo runs several search_web queries, reads the best pages with fetch_page, writes a short note in its own words with source links, and shows it to you.
- Real approval gate in code (not only in the prompt): `knowledge_add` with an http(s) source now shows a Confirm card (title, source, preview) and saves nothing if you decline. Notes are capped at 6,000 characters and always carry their source link. Non-web knowledge_add is unchanged.
- AppMap has a "Study mode" entry so Anjoo can tell where learned notes are (Manage Memory & Knowledge > Knowledge).
- Test: StudyTest (tools named in prompt, web-source detection, note length/source, preview size).
- Version 100.0.23 / fallback code 100023. Not built with Gradle here; Android SDK is not available in this environment. Check the build and tests in CI.
- Limits: Anjoo studies when asked (or when the model decides it needs to); it does not browse by itself in the background. A scheduled "study this every week" can be added later with schedule_agent.
