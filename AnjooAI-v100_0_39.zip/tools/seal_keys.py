#!/usr/bin/env python3
"""Seals your API keys into app/src/main/assets/keys.sealed so they are not readable as plain text inside the APK.

Run it on YOUR computer (Python 3, no extra packages), so the keys never leave it:
    1. copy keys.properties.example to keys.properties here and fill in your keys
    2. python tools/seal_keys.py keys.properties
    3. build the app. Delete keys.properties afterwards and never upload it anywhere.

Honest limit: the unlock key is inside the app, so this stops casual extraction (unzip, strings), not a determined
reverse engineer. Keep the APK and the repository private.
"""
import hashlib, hmac, os, sys

PARTS = ["anjoo", "ai", "sealed", "keys", "v1", "7f3c", "d41e", "9b20"]   # must match SealedKeys.kt
KEY = hashlib.sha256("|".join(PARTS).encode("utf-8")).digest()

def stream(nonce, n):
    out = b""; i = 0
    while len(out) < n:
        out += hashlib.sha256(KEY + nonce + i.to_bytes(4, "big")).digest(); i += 1
    return out[:n]

def seal(text, nonce=None):
    nonce = nonce or os.urandom(16)
    plain = text.encode("utf-8")
    ct = bytes(a ^ b for a, b in zip(plain, stream(nonce, len(plain))))
    return b"ANJ1" + nonce + ct + hmac.new(KEY, nonce + ct, hashlib.sha256).digest()

if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "keys.properties"
    dst = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "assets", "keys.sealed")
    open(dst, "wb").write(seal(open(src, encoding="utf-8").read()))
    print("Sealed ->", os.path.normpath(dst), "(now delete", src, "and do not share the APK)")
