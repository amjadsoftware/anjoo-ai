# v100.0.17.4
Prompt caching.
- Anthropic (Claude): the tool list is always marked cacheable; the system text + chat so far are marked cacheable from the 2nd round of a tool loop (same system text), so long agent runs cost much less and start faster.
- OpenAI: sends prompt_cache_key (automatic prefix caching is routed better).
- Gemini: implicit caching is automatic; cached tokens are now counted.
- Token report: new line "Cached input today". Anthropic cached tokens are now included in input totals (before they were missed).
No setting needed. Other providers are unchanged.
