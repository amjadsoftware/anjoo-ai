# v100.0.18.5
4. Project card buttons (Preview, Full, APK, Tools): smaller text and padding, shorter labels, and they share the width equally in one row, so nothing runs off the screen any more (the sideways scroll is gone). "Close preview" is now "Close".
