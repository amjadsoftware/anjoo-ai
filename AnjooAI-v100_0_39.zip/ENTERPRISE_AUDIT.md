# Anjoo AI: Enterprise Spec Audit (v100.0.31)

Step 1 of the enterprise upgrade. This is an inspection and plan only. No app code was changed except the version number.
Nothing here is marked done unless it exists in the source today. Gradle and the Android SDK are not available in this environment, so nothing was compiled or run.

## What Anjoo is today
A single-user, on-device Android app (about 47,000 lines of Kotlin, about 140 files, 53 unit-test files). Its only server pieces are the Supabase GitHub-token vault (`supabase/functions/hs-github-token`, one migration) and GitHub CI. Keys, chats, memory and tasks live on the phone.

## Spec section vs. what exists

| Spec section | Already in the source | Missing / gap |
|---|---|---|
| 2 Intelligence engine | `Router` (task typing and model scoring), `Compaction` (long-chat summaries), `AgentRoster` (specialist agents), `Master` prompt sections | Self-verification pass before final answers, feedback learning from outcomes |
| 3 Agents | `AgentOrchestrator` (plan, run, checkpoints, pause/cancel, honest completion state), `AgentJobs`, `ToolLoopBudget`, `ParallelTools`, `ToolRegistry`, `Confirm` | Per-agent permission and execution-limit table shown to the user, bounded retry policy per tool |
| 4 Admin dashboard | `TokenLedger` (tokens, prices, daily budget), `ModelHealthMonitor`, `ToolRunLog`, `Tasks` board | No users, roles, subscriptions, revenue, moderation or announcements. These need a real multi-user backend that does not exist |
| 5 Memory | `LongMemory`, `KnowledgeBase` (SQLite chunks), `KnowledgeEmbeddings` (opt-in semantic index), `Projects` instructions, `Tasks`, `MemoryActivity` (user control) | One screen showing all layers together, memory correction flow |
| 6 Software engineering | `Coder`, `CodeTools`, `Engineering`, `SecretScan`, `Linter`, `RunTests`, `SelfTests`, `PyTests`, `Git`, `Deps`, `Debug` | Kotlin/Java tests only as small self-test programs, no real Gradle runs on device |
| 7 Website builder | `WebsiteBuilder`, `SiteBlueprints`, `SiteEditor`, `SiteImages`, `SitePublisher`, `GitHubPages`, `Deploy`, `VisualCheck` | Backend/auth/database for generated sites is limited to what the user's own services provide |
| 8 Workflow lifecycle | Task Board checkpoints, `AgentOrchestrator` stages | A single "Task history" screen to inspect each step |
| 9 UI | Claude-style simple UI (`SIMPLE_UI`), light and dark themes, `SideMenu` | Keep as is. Spec says preserve the main interface |
| 10 Reliability | `Crypt` (AES-256-GCM in Keystore), `Vault`, `KeyLock`, `Guard`, `Backup`, `Offline` and `BgDrain` (outbox), `Errors`, CI workflow | Rate limiting per provider surfaced to the user, recovery guide |

## Items that need external services or credentials
- Multi-user accounts, roles, subscriptions, revenue, moderation, announcements: needs a hosted backend (Supabase could host it) and payment provider credentials.
- Live server, database and queue health: only meaningful once that backend exists.
- Vector search beyond the opt-in Gemini index: needs an embedding provider key.

## Proposed order (one small task per "next", one zip each)
1. (this zip) Audit and plan.
2. On-device Operations dashboard: real numbers only, from `TokenLedger`, `ModelHealthMonitor`, `ToolRunLog` and `Tasks` (requests, tokens, cost from user-entered prices, errors, task completion, per-model health).
3. Task history screen: inspect each agent run step by step, from stored checkpoints.
4. Agent permission and limit table (what each agent may use, its step cap, retry cap).
5. Answer verification pass for coding and file outputs (reuse the existing file-check logic).
6. Memory overview screen: all layers in one place, with correct and delete.
7. Decide with you whether to build the multi-user backend (Supabase) for items in section 4 that need it.

Existing features are preserved. No fake analytics, mock data or non-working buttons will be added.
