# v100.0.27 - Video upload

- Videos can now be attached: Add menu -> "🎬 Choose a video", the Files option, or sharing a video to Anjoo from the Gallery/WhatsApp. Before, a video was treated as a broken text file and refused.
- The phone cuts 6 to 12 evenly spaced frames (about one per 5 seconds, max 1024 px) out of the video with MediaMetadataRetriever and sends them as pictures with a short note (video length, frame times, "no sound"). This works with every AI that can see pictures, and with any video length or size.
- Limits: no audio/speech is sent, and fast on-screen details between frames can be missed. A full-video upload through the Gemini Files API would be a possible later step.
- Android build/device test not run here (no Android SDK): please build in CI and try one short video.

# v100.0.28 - Video: speech and screen understanding

- When a Gemini key is saved, an attached video (up to 300 MB) is uploaded to Google's Gemini Files API (new `VideoUnderstand.kt`). Gemini watches the whole video and listens to its sound and writes a report: speech with times, what is on screen over time, and a summary. The report is added to the message, so ANY AI the user chats with (OpenAI, Claude, Groq...) can explain what is said and what is shown. The uploaded copy is deleted afterwards.
- The picture frames are still attached for visual checking. Without a Gemini key, a bigger video, or on any failure, only the frames are sent and the AI is told it could not hear the sound.
- Takes about 1-2 minutes for a short video (upload + processing). Not built or device-tested here (no Android SDK).

# v100.0.29 - Keys locked inside the app

- Keys that come with the build (assets/keys.sealed or keys.properties) lock the app (`KeyLock`): "Export keys", the encrypted Keys-backup and the "with key" backup are refused, and the extra keys ("keys_<id>") are no longer included in any backup (they were not filtered before). The key box already shows dots with copy disabled.
- New `tools/seal_keys.py` + `SealedKeys.kt`: run it on your own computer to turn keys.properties into assets/keys.sealed, so keys are not plain text inside the APK. The app prefers keys.sealed and falls back to keys.properties. Tested: file made by Python opens in Kotlin, tampering is rejected.
- Honest limit: the unlock key is inside the app, so this stops casual extraction only. Keep the APK and the repository private. Real protection = keys kept on a server.
- .gitignore now lists keys.properties.

# v100.0.30 - Export lock with passcode
- Keys work exactly as before (add, edit, use). Only EXPORT is locked: Export keys, the encrypted Keys-backup and a backup "with key" ask for the passcode first (`KeyLock.ask`). After the right passcode export is open for 5 minutes. 5 wrong tries block it for 1 minute.
- The passcode is stored only as a salted SHA-256 hash. The automatic "lock when keys come from the build" of v100.0.29 was removed.
- Backups without key no longer contain the extra keys either.
