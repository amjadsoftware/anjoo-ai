# v100.0.18.3
2. "Made by" line: the chat now shows only the company names ("🤖 Made by: Google Gemini + Mistral +2  ›"). Tap it to open a small sheet with each company's model, the kind of work and how many more models are ready; its "Saare models" button opens the full model map as before. The saved text is unchanged. New file: MadeBy.kt (+ MadeByTest).
