# v100.0.17.5
Parallel tool calls. When the AI asks for several read-only tools in one turn (search_web, fetch_page, read_file, find_files, grep_files, list_files, read_document, search_document, document_info, weather, news) they run at the same time (up to 5) instead of one by one.
Every other tool (anything that writes, taps, calls, sends or changes the phone/project) still runs one after another in order. Stop still cancels. New file: ParallelTools.kt. The loop guard in Actions.run is now thread-safe.
Deep Research prompt now tells the AI to batch independent searches.
