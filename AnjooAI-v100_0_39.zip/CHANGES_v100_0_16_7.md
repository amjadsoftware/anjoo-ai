# v100.0.16.7 - English-only UI (final pass)
All user-visible text is now English: Voice statuses, Habits suggestions, Vault/backup messages, Long memory, Agent jobs/orchestrator,
Telegram, Accessibility actions, Updater, Knowledge base, Dictation, Reminders, Notifications, BgDrain, report export, App Map, text-size labels, summary sheet.
Kept on purpose (not shown to the user): voice-command/intent recognisers (Roman Urdu words still understood), Gemini tool descriptions,
AI persona/system prompts (Style, GfMode, LangPref, Credit, Agent policy), and ledger kind keys.
Marker strings used in logic (ToolRunLog, AgentJobs, WebsiteBuilder, LiveOrb, BuddyView) were updated together; tests adjusted.
