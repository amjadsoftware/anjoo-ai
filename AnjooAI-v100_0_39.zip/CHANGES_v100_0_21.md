# v100.0.21 - App Map: Anjoo knows more of its own screens

- AppMap.kt now also describes: Memory & Knowledge (tabs, switches, semantic search, export/merge/delete), HS APK Builder (GitHub, cloud backup, build type, build), HS builder example cards, Codixa project actions and engineering audit, the Permissions list, Task Board states, Notes sync and Artifact sharing.
- Found by comparing the real button labels in the activities with the map: those screens had no entry before, so Anjoo could not answer "where is X" for them.
- Test added: AppMapTest.memoryAndApkBuilderScreensAreKnown. Not built with Gradle here.
- Next ideas (one at a time): audit the main chat screen labels (MainActivity) against the map; then internet "learn" step (best templates and structures into the Knowledge Base, shown to the user for approval).
