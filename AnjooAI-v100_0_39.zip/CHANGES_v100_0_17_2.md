# v100.0.17.2
Edit with branches: long-press one of your messages > Edit and resend. Edit the text and send; the replies after it are replaced and the old version stays under a ‹ n/N › switcher on that message (switch back and forth).
If the message is too old to match the saved model history, it falls back to the previous behaviour (text goes to the input box).
Retry and the answer version switcher already existed and are unchanged.
