# v100.0.17.3
Deep Research mode. + menu > Deep Research (sticky chip), or start a message with "deep research" or "/research" for one message.
The AI plans sub-questions, runs many search_web + fetch_page calls, cross-checks, and writes a report with [1] citations and a Sources list. Uses a larger answer limit (16000 tokens).
No new tools were added; it uses the existing search_web / fetch_page tools.
