# v100.0.19.0
New tool: run_code. Compiles and runs real source code in Kotlin, Java, C, C++, C#, Go, Rust, PHP, Ruby, Node.js, TypeScript, Swift, Bash, Dart, SQL, R, Lua, Perl, Scala, Haskell and Python on an online Judge0 sandbox, and returns the real output, compiler errors or crash text (with time and memory). The AI can now write, run, read the error and fix, instead of only checking brackets.
- Input: code, or project + path (one file of a Code Studio project; the entry file is guessed from main.kt, Main.java, main.go, src/main.rs, index.js ...), optional stdin.
- The server's language list is read once and the newest version of each language is used; built-in ids are the fallback.
- Default server https://ce.judge0.com (public, rate limited). Own server: settings keys judge0_url (https only) and judge0_key (X-Auth-Token).
- The code leaves the phone, so the user is asked once per app run. Errors say clearly when nothing was run, so the AI cannot claim a pass.
- project_check action=run on a Kotlin/Java/Go/Rust/... project now tells the AI to use run_code with the right language and entry file.
- Registered in the tool catalog (Data, external risk, needs internet), tool label "Run code online", and the Code Studio prompt now tells the AI to run and fix.
Limits: one file per run (no multi-file Gradle/Cargo builds), no network inside the sandbox, no GUI.
Tests: RunCodeTest.
