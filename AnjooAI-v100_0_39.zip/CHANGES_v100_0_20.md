# v100.0.20 - Version bump

- Version raised from 100.0.19.25 to 100.0.20 (versionName "100.0.20", local versionCode 100020).
- No functional code changes; everything from v100.0.19.25 (project_git "ci" build runner) is included.
