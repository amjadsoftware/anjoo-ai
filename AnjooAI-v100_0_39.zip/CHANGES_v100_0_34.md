## v100.0.34 — Enterprise upgrade, step 4: agent limits and permissions
- New "Limits & permissions" view inside Agent runs. It is generated from `AgentPolicy`, which reads the real constants (tool-round cap, team size, specialist token cap, model candidate cap), so the screen cannot drift from the code.
- New enforced rule: a tool that fails 4 times in a row is paused until 5 minutes after its last failure (`AgentPolicy.FailureTracker`, checked in `Actions.run`). A success clears the count; cancelled runs and policy/setup messages do not count. The paused tool returns a STOP message telling the agent to report the blocker or use a different tool.
- `Router.MAX_TRIES` is now `internal` and `AgentJobs` uses `AgentPolicy.TEAM_MAX` / `SUBAGENT_MAX_TOKENS` instead of literals (same values: 25, 3, 4096).
- `AgentRoster.entries()` added (read-only).
- Honest finding shown on screen: roster agents (Chat, Phone, Code, ...) are role rules inside the prompt. Tool access is the same for all of them and is NOT restricted per agent. Restricting tools per agent would risk breaking requests the Router classified wrongly, so it was not done.
- Tests: `AgentPolicyTest` (cap, success reset, window expiry, conservative failure detection).
- Verification: source review and bracket-balance check only. Not compiled and the new tests were not run (no Gradle/Android SDK here). Please build and run the unit tests.
