'use strict';
/*
 * Anjoo mini test runner. Runs in plain Node.js (12 or newer) on the online sandbox, as ONE file:
 * this harness + the project's files registered with __anjooReg(path, source, isTest) + __anjooRun(tests, coverage).
 * Supports: describe/it/test (+ .skip .only .each), beforeAll/afterAll/beforeEach/afterEach, async tests and done(),
 * expect(...) matchers (+ .not, .resolves, .rejects), jest.fn / vi.fn / spyOn, node:assert, CommonJS require and
 * simple ES modules (import/export). Real line coverage comes from the V8 inspector when the server has it.
 * Keep the syntax old-style (no ?. or ??) so it also works on Node 12.
 */
var __util = require('util');
var __vm = require('vm');
var __pathLib = require('path').posix;
var __nodeRequire = require;
var __mods = {};
var __cache = {};
var __rootSuite = null;
var __cur = null;
var __curFile = '';
var __onlyUsed = false;
var __loadErrors = [];
var __stray = [];
var __covSession = null;
var __covWhy = '';
var __TEST_TIMEOUT = 5000;
var __BUILTINS = {};
try { __nodeRequire('module').builtinModules.forEach(function (n) { __BUILTINS[n] = true; }); } catch (e) { }

function __newSuite(name, parent) {
  return { name: name, parent: parent, items: [], beforeAll: [], afterAll: [], beforeEach: [], afterEach: [], skip: false, only: false };
}
__rootSuite = __newSuite('', null);
__cur = __rootSuite;

function __fmt(v) {
  var s;
  try { s = __util.inspect(v, { depth: 4, breakLength: 100, maxArrayLength: 20 }); } catch (e) { s = String(v); }
  return s.length > 300 ? s.slice(0, 300) + '...' : s;
}

function __anjooReg(path, src, isTest) {
  __mods[path] = { src: src, isTest: !!isTest, wrapped: '', prefixLen: 0, srcLines: 0, loaded: false };
}

// ------------------------------------------------------------------ ES modules -> CommonJS (line count is kept)

function __newlines(s) { var m = s.match(/\n/g); return m ? new Array(m.length + 1).join('\n') : ''; }

function __esmToCjs(src) {
  if (!/^\s*(import|export)\s/m.test(src)) return src;
  var tail = [];
  var out = src + '\n';
  var framework = /^(vitest|@jest\/globals|node:test|mocha|jest)$/;
  function importPart(names, spec, lines) {
    if (framework.test(spec)) return lines;
    var req = "require(" + JSON.stringify(spec) + ")";
    if (/^\*\s+as\s+(\w+)$/.test(names)) return 'const ' + names.replace(/^\*\s+as\s+/, '') + ' = ' + req + ';' + lines;
    var def = null, named = null;
    var m = names.match(/^(\w+)\s*,\s*\{([\s\S]*)\}$/);
    if (m) { def = m[1]; named = m[2]; }
    else if (/^\{[\s\S]*\}$/.test(names)) { named = names.replace(/^\{|\}$/g, ''); }
    else { def = names; }
    var res = '';
    if (named !== null) {
      var parts = named.split(',').map(function (x) { return x.trim().replace(/\s+as\s+/, ': '); }).filter(Boolean);
      res += 'const { ' + parts.join(', ') + ' } = ' + req + ';';
    }
    if (def) res += 'const ' + def + ' = __anjooDefault(' + req + ');';
    return res + lines;
  }
  out = out.replace(/^(\s*)import\s+([\w*{][\s\S]*?)\s+from\s+['"]([^'"]+)['"]\s*;?/gm, function (all, ind, names, spec) {
    return ind + importPart(names.trim(), spec, __newlines(all));
  });
  out = out.replace(/^(\s*)import\s+['"]([^'"]+)['"]\s*;?/gm, function (all, ind, spec) {
    return ind + (framework.test(spec) ? '' : 'require(' + JSON.stringify(spec) + ');') + __newlines(all);
  });
  out = out.replace(/^(\s*)export\s+default\s+(async\s+function|function|class)\s*\*?\s*(?!extends\b)([A-Za-z_$][\w$]*)/gm, function (all, ind, kw, name) {
    tail.push('exports.default = ' + name + ';');
    return ind + kw + ' ' + name;
  });
  out = out.replace(/^(\s*)export\s+default\s+/gm, function (all, ind) { return ind + 'exports.default = '; });
  out = out.replace(/^(\s*)export\s+(async\s+function|function|class)\s*\*?\s*([A-Za-z_$][\w$]*)/gm, function (all, ind, kw, name) {
    tail.push('exports.' + name + ' = ' + name + ';');
    return ind + kw + ' ' + name;
  });
  out = out.replace(/^(\s*)export\s+(const|let|var)\s+/gm, function (all, ind, kind, offset, whole) {
    var after = whole.slice(offset + all.length, offset + all.length + 300);
    var d = /^\{([^}]*)\}/.exec(after);
    if (d) {
      d[1].split(',').forEach(function (x) {
        var nm = x.trim().split(/\s*:\s*/).pop().split(/\s*=/)[0].trim();
        if (nm) tail.push('exports.' + nm + ' = ' + nm + ';');
      });
    } else {
      var one = /^([A-Za-z_$][\w$]*)/.exec(after);
      if (one) tail.push('exports.' + one[1] + ' = ' + one[1] + ';');
    }
    return ind + kind + ' ';
  });
  out = out.replace(/^(\s*)export\s*\{([\s\S]*?)\}\s*(?:from\s+['"]([^'"]+)['"])?\s*;?/gm, function (all, ind, list, from) {
    var parts = list.split(',').map(function (x) { return x.trim(); }).filter(Boolean);
    var res = '';
    parts.forEach(function (p) {
      var mm = p.split(/\s+as\s+/);
      var local = mm[0], exp = mm[1] || mm[0];
      if (from) res += 'exports.' + exp + ' = require(' + JSON.stringify(from) + ').' + local + ';';
      else tail.push('exports.' + exp + ' = ' + local + ';');
    });
    return ind + res + __newlines(all);
  });
  return out + '\n' + tail.join('\n') + (tail.length ? '\n' : '');
}

function __anjooDefault(m) {
  if (m && typeof m === 'object' && Object.prototype.hasOwnProperty.call(m, 'default')) return m['default'];
  return m;
}

global.__anjooDefault = __anjooDefault;

// ------------------------------------------------------------------ require

function __resolve(from, spec) {
  var joined = __pathLib.join(__pathLib.dirname(from), spec);
  var tries = [joined, joined + '.js', joined + '.mjs', joined + '.cjs', joined + '.json', joined + '/index.js'];
  for (var i = 0; i < tries.length; i++) if (__mods[tries[i]]) return tries[i];
  return null;
}

function __require(from, spec) {
  if (spec.indexOf('./') === 0 || spec.indexOf('../') === 0 || spec === '.' || spec === '..') {
    var p = __resolve(from, spec);
    if (!p) throw new Error("Cannot find module '" + spec + "' from '" + from + "' (the file is not in the project or was not found)");
    return __load(p);
  }
  var name = spec.replace(/^node:/, '');
  if (name === '@jest/globals' || name === 'vitest') return __globalsObject();
  if (name === 'test') return { describe: describe, it: it, test: test, before: beforeAll, after: afterAll, beforeEach: beforeEach, afterEach: afterEach };
  if (__BUILTINS[name]) return __nodeRequire(name);
  throw new Error("Package '" + spec + "' is not available: npm packages cannot be installed in the online sandbox. Use only Node built-in modules and the project's own files.");
}

function __load(path) {
  if (__cache[path]) return __cache[path].exports;
  var m = __mods[path];
  var module = { exports: {}, id: path, filename: path };
  __cache[path] = module;
  m.loaded = true;
  if (/\.json$/.test(path)) { module.exports = JSON.parse(m.src); return module.exports; }
  var code = __esmToCjs(m.src);
  var prefix = '(function (module, exports, require, __filename, __dirname) {';
  var wrapped = prefix + code + '\n})';
  m.wrapped = wrapped;
  m.prefixLen = prefix.length;
  m.srcLines = m.src.split('\n').length;
  var fn = new __vm.Script(wrapped, { filename: path }).runInThisContext();
  var req = function (spec) { return __require(path, spec); };
  fn.call(module.exports, module, module.exports, req, path, __pathLib.dirname(path));
  return module.exports;
}

// ------------------------------------------------------------------ deep equality and matchers

function __eq(a, b, strict, seen) {
  if (Object.is(a, b)) return true;
  if (typeof a !== 'object' || typeof b !== 'object' || a === null || b === null) return false;
  seen = seen || [];
  for (var s = 0; s < seen.length; s++) if (seen[s][0] === a && seen[s][1] === b) return true;
  seen.push([a, b]);
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  if (a instanceof Date || b instanceof Date) return (a instanceof Date) && (b instanceof Date) && a.getTime() === b.getTime();
  if (a instanceof RegExp || b instanceof RegExp) return String(a) === String(b);
  if (a instanceof Error && b instanceof Error) return a.message === b.message && a.name === b.name;
  if (strict && Object.getPrototypeOf(a) !== Object.getPrototypeOf(b)) return false;
  if (a instanceof Map && b instanceof Map) {
    if (a.size !== b.size) return false;
    var ok = true;
    a.forEach(function (v, k) { if (!b.has(k) || !__eq(v, b.get(k), strict, seen)) ok = false; });
    return ok;
  }
  if (a instanceof Set && b instanceof Set) {
    if (a.size !== b.size) return false;
    var allIn = true;
    a.forEach(function (v) {
      var found = false;
      b.forEach(function (w) { if (!found && __eq(v, w, strict, seen)) found = true; });
      if (!found) allIn = false;
    });
    return allIn;
  }
  function keys(o) {
    var ks = Object.keys(o);
    return strict ? ks : ks.filter(function (k) { return o[k] !== undefined; });
  }
  var ka = keys(a), kb = keys(b);
  if (ka.length !== kb.length) return false;
  for (var i = 0; i < ka.length; i++) {
    if (!Object.prototype.hasOwnProperty.call(b, ka[i])) return false;
    if (!__eq(a[ka[i]], b[ka[i]], strict, seen)) return false;
  }
  return true;
}

function __subset(a, e) {
  if (Object.is(a, e)) return true;
  if (typeof e !== 'object' || e === null || typeof a !== 'object' || a === null) return false;
  if (Array.isArray(e)) {
    if (!Array.isArray(a) || a.length !== e.length) return false;
    for (var i = 0; i < e.length; i++) if (!__subset(a[i], e[i])) return false;
    return true;
  }
  var ks = Object.keys(e);
  for (var j = 0; j < ks.length; j++) if (!__subset(a[ks[j]], e[ks[j]])) return false;
  return true;
}

function __getPath(obj, path) {
  var parts = Array.isArray(path) ? path : String(path).replace(/\[(\d+)\]/g, '.$1').split('.').filter(Boolean);
  var cur = obj;
  for (var i = 0; i < parts.length; i++) {
    if (cur === null || cur === undefined || !(parts[i] in Object(cur))) return { found: false };
    cur = cur[parts[i]];
  }
  return { found: true, value: cur };
}

function __isMock(f) { return typeof f === 'function' && f.__isMock === true; }

var __M = {
  toBe: function (a, e) { return { pass: Object.is(a, e), desc: 'to be', args: [e] }; },
  toEqual: function (a, e) { return { pass: __eq(a, e, false), desc: 'to equal', args: [e] }; },
  toStrictEqual: function (a, e) { return { pass: __eq(a, e, true), desc: 'to strictly equal', args: [e] }; },
  toBeTruthy: function (a) { return { pass: !!a, desc: 'to be truthy', args: [] }; },
  toBeFalsy: function (a) { return { pass: !a, desc: 'to be falsy', args: [] }; },
  toBeNull: function (a) { return { pass: a === null, desc: 'to be null', args: [] }; },
  toBeUndefined: function (a) { return { pass: a === undefined, desc: 'to be undefined', args: [] }; },
  toBeDefined: function (a) { return { pass: a !== undefined, desc: 'to be defined', args: [] }; },
  toBeNaN: function (a) { return { pass: typeof a === 'number' && isNaN(a), desc: 'to be NaN', args: [] }; },
  toBeGreaterThan: function (a, e) { return { pass: a > e, desc: 'to be greater than', args: [e] }; },
  toBeGreaterThanOrEqual: function (a, e) { return { pass: a >= e, desc: 'to be greater than or equal to', args: [e] }; },
  toBeLessThan: function (a, e) { return { pass: a < e, desc: 'to be less than', args: [e] }; },
  toBeLessThanOrEqual: function (a, e) { return { pass: a <= e, desc: 'to be less than or equal to', args: [e] }; },
  toBeCloseTo: function (a, e, d) { var digits = d === undefined ? 2 : d; return { pass: Math.abs(a - e) < Math.pow(10, -digits) / 2, desc: 'to be close to', args: [e] }; },
  toBeInstanceOf: function (a, e) { return { pass: a instanceof e, desc: 'to be an instance of', args: [e && e.name ? e.name : e] }; },
  toContain: function (a, e) {
    var pass = typeof a === 'string' ? a.indexOf(e) >= 0 : (a && typeof a.indexOf === 'function' ? Array.prototype.indexOf.call(a, e) >= 0 : false);
    return { pass: pass, desc: 'to contain', args: [e] };
  },
  toContainEqual: function (a, e) {
    var pass = false;
    if (a && typeof a.length === 'number') for (var i = 0; i < a.length; i++) if (__eq(a[i], e, false)) pass = true;
    return { pass: pass, desc: 'to contain an item equal to', args: [e] };
  },
  toHaveLength: function (a, e) { return { pass: a !== null && a !== undefined && a.length === e, desc: 'to have length', args: [e], extra: a !== null && a !== undefined ? ' (actual length ' + a.length + ')' : '' }; },
  toMatch: function (a, e) { return { pass: typeof a === 'string' && (e instanceof RegExp ? e.test(a) : a.indexOf(e) >= 0), desc: 'to match', args: [e] }; },
  toMatchObject: function (a, e) { return { pass: __subset(a, e), desc: 'to match object', args: [e] }; },
  toHaveProperty: function (a, path, val) {
    var r = a === null || a === undefined ? { found: false } : __getPath(a, path);
    var pass = r.found && (arguments.length < 3 || __eq(r.value, val, false));
    return { pass: pass, desc: 'to have property', args: arguments.length < 3 ? [path] : [path, val] };
  },
  toThrow: function (fn, e) {
    var thrown = false, err;
    try { fn(); } catch (x) { thrown = true; err = x; }
    var pass = thrown;
    if (thrown && e !== undefined) {
      var msg = err && err.message !== undefined ? String(err.message) : String(err);
      if (typeof e === 'string') pass = msg.indexOf(e) >= 0;
      else if (e instanceof RegExp) pass = e.test(msg);
      else if (typeof e === 'function') pass = err instanceof e;
    }
    return { pass: pass, desc: 'to throw', args: e === undefined ? [] : [e], extra: thrown ? ' (it threw ' + __fmt(err && err.message !== undefined ? err.message : err) + ')' : ' (it did not throw)', fnActual: true };
  },
  toHaveBeenCalled: function (f) { return { pass: __isMock(f) && f.mock.calls.length > 0, desc: 'to have been called', args: [], mockActual: true }; },
  toHaveBeenCalledTimes: function (f, n) { return { pass: __isMock(f) && f.mock.calls.length === n, desc: 'to have been called times', args: [n], extra: __isMock(f) ? ' (called ' + f.mock.calls.length + ' times)' : '', mockActual: true }; },
  toHaveBeenCalledWith: function (f) {
    var want = Array.prototype.slice.call(arguments, 1);
    var pass = false;
    if (__isMock(f)) f.mock.calls.forEach(function (c) { if (__eq(c, want, false)) pass = true; });
    return { pass: pass, desc: 'to have been called with', args: want, extra: __isMock(f) ? ' (calls: ' + __fmt(f.mock.calls) + ')' : '', mockActual: true };
  },
  toHaveBeenLastCalledWith: function (f) {
    var want = Array.prototype.slice.call(arguments, 1);
    var pass = __isMock(f) && f.mock.calls.length > 0 && __eq(f.mock.calls[f.mock.calls.length - 1], want, false);
    return { pass: pass, desc: 'to have been last called with', args: want, mockActual: true };
  }
};
__M.toBeCalled = __M.toHaveBeenCalled;
__M.toBeCalledWith = __M.toHaveBeenCalledWith;
__M.toBeCalledTimes = __M.toHaveBeenCalledTimes;

function __matcherSet(getActual, negate, mode) {
  var set = {};
  Object.keys(__M).forEach(function (name) {
    set[name] = function () {
      var args = Array.prototype.slice.call(arguments);
      var apply = function (actual) {
        var r = __M[name].apply(null, [actual].concat(args));
        if (negate ? r.pass : !r.pass) {
          var shown = r.fnActual ? 'function' : (r.mockActual ? 'mock' : __fmt(actual));
          var msg = 'expected ' + shown + ' ' + (negate ? 'not ' : '') + r.desc + (r.args.length ? ' ' + r.args.map(__fmt).join(', ') : '') + (r.extra || '');
          if (!r.fnActual && !r.mockActual && (name === 'toEqual' || name === 'toStrictEqual' || name === 'toMatchObject') && !negate) msg += '\n  Expected: ' + __fmt(args[0]) + '\n  Received: ' + __fmt(actual);
          var e = new Error(msg);
          e.__matcher = true;
          throw e;
        }
      };
      if (!mode) return apply(getActual());
      return Promise.resolve(getActual()).then(function (v) {
        if (mode === 'rejects') throw new Error('expected the promise to reject, but it resolved with ' + __fmt(v));
        return apply(v);
      }, function (err) {
        if (mode === 'resolves') throw new Error('expected the promise to resolve, but it rejected with ' + __fmt(err && err.message !== undefined ? err.message : err));
        return apply(name === 'toThrow' ? function () { throw err; } : err);
      });
    };
  });
  return set;
}

function expect(actual) {
  var api = __matcherSet(function () { return actual; }, false, null);
  api.not = __matcherSet(function () { return actual; }, true, null);
  api.resolves = __matcherSet(function () { return actual; }, false, 'resolves');
  api.rejects = __matcherSet(function () { return actual; }, false, 'rejects');
  api.resolves.not = __matcherSet(function () { return actual; }, true, 'resolves');
  api.rejects.not = __matcherSet(function () { return actual; }, true, 'rejects');
  return api;
}
expect.anything = function () { return {}; };

// ------------------------------------------------------------------ mocks (jest.fn / vi.fn / spyOn)

function __mockFn(impl) {
  var once = [];
  var current = impl;
  var f = function () {
    var args = Array.prototype.slice.call(arguments);
    f.mock.calls.push(args);
    f.mock.instances.push(this);
    var res = { type: 'return', value: undefined };
    try {
      var use = once.length ? once.shift() : current;
      res.value = use ? use.apply(this, args) : undefined;
    } catch (e) { res = { type: 'throw', value: e }; f.mock.results.push(res); throw e; }
    f.mock.results.push(res);
    return res.value;
  };
  f.__isMock = true;
  f.mock = { calls: [], instances: [], results: [] };
  f.mockImplementation = function (fn) { current = fn; return f; };
  f.mockImplementationOnce = function (fn) { once.push(fn); return f; };
  f.mockReturnValue = function (v) { current = function () { return v; }; return f; };
  f.mockReturnValueOnce = function (v) { once.push(function () { return v; }); return f; };
  f.mockResolvedValue = function (v) { current = function () { return Promise.resolve(v); }; return f; };
  f.mockRejectedValue = function (v) { current = function () { return Promise.reject(v); }; return f; };
  f.mockClear = function () { f.mock = { calls: [], instances: [], results: [] }; return f; };
  f.mockReset = function () { f.mockClear(); current = undefined; once = []; return f; };
  f.mockRestore = function () { f.mockReset(); if (f.__restore) f.__restore(); };
  return f;
}

var __jest = {
  fn: function (impl) { return __mockFn(impl); },
  spyOn: function (obj, method) {
    var orig = obj[method];
    var spy = __mockFn(function () { return orig.apply(this, arguments); });
    spy.__restore = function () { obj[method] = orig; };
    obj[method] = spy;
    return spy;
  },
  clearAllMocks: function () { },
  restoreAllMocks: function () { },
  setTimeout: function (ms) { __TEST_TIMEOUT = ms; },
  mock: function () { throw new Error('jest.mock / vi.mock is not supported in the online runner. Pass dependencies as arguments or use jest.fn().'); },
  useFakeTimers: function () { throw new Error('Fake timers are not supported in the online runner. Use short real delays.'); }
};

// ------------------------------------------------------------------ test registration

function __describe(name, fn, flags) {
  var suite = __newSuite(String(name), __cur);
  suite.skip = !!(flags && flags.skip) || __cur.skip;
  suite.only = !!(flags && flags.only);
  if (suite.only) __onlyUsed = true;
  __cur.items.push({ kind: 'suite', suite: suite });
  var saved = __cur;
  __cur = suite;
  try { fn(); } catch (e) { __loadErrors.push({ file: __curFile, message: 'describe("' + name + '") threw: ' + (e && e.message), err: e }); }
  __cur = saved;
}

function __it(name, fn, flags) {
  var t = { kind: 'test', name: String(name), fn: fn, file: __curFile, suite: __cur, skip: !!(flags && flags.skip) || typeof fn !== 'function', only: !!(flags && flags.only) };
  if (t.only) __onlyUsed = true;
  __cur.items.push(t);
}

function __withEach(base, mk) {
  return function (table) {
    return function (name, fn, timeout) {
      table.forEach(function (row) {
        var args = Array.isArray(row) ? row : [row];
        var title = __util.format.apply(null, [String(name)].concat(args));
        mk(title, function () { return fn.apply(null, args); }, timeout);
      });
    };
  };
}

function describe(name, fn) { __describe(name, fn, null); }
describe.skip = function (name, fn) { __describe(name, fn, { skip: true }); };
describe.only = function (name, fn) { __describe(name, fn, { only: true }); };
describe.each = __withEach(describe, function (title, fn) { __describe(title, fn, null); });
var context = describe;
var suite = describe;

function it(name, fn, timeout) { __it(name, fn, null); }
it.skip = function (name, fn) { __it(name, fn, { skip: true }); };
it.only = function (name, fn) { __it(name, fn, { only: true }); };
it.todo = function (name) { __it(name, null, { skip: true }); };
it.each = __withEach(it, function (title, fn) { __it(title, fn, null); });
var test = it;
var specify = it;
test.skip = it.skip; test.only = it.only; test.todo = it.todo; test.each = it.each;
it.concurrent = it;

function beforeAll(fn) { __cur.beforeAll.push(fn); }
function afterAll(fn) { __cur.afterAll.push(fn); }
function beforeEach(fn) { __cur.beforeEach.push(fn); }
function afterEach(fn) { __cur.afterEach.push(fn); }
var before = beforeAll;
var after = afterAll;

function __globalsObject() {
  return { describe: describe, it: it, test: test, expect: expect, beforeAll: beforeAll, afterAll: afterAll, beforeEach: beforeEach, afterEach: afterEach, jest: __jest, vi: __jest };
}
var __g = __globalsObject();
Object.keys(__g).forEach(function (k) { global[k] = __g[k]; });
global.context = describe; global.specify = it; global.before = beforeAll; global.after = afterAll; global.suite = describe;

// ------------------------------------------------------------------ running

function __callWithTimeout(fn, ms) {
  return new Promise(function (resolve, reject) {
    var finished = false;
    var timer = setTimeout(function () {
      if (!finished) { finished = true; reject(new Error('Timeout: it took more than ' + ms + ' ms' + (fn.length > 0 ? ' (done() was never called)' : ' (a promise never finished, or the code is waiting on something)'))); }
    }, ms);
    function ok() { if (!finished) { finished = true; clearTimeout(timer); resolve(); } }
    function bad(e) { if (!finished) { finished = true; clearTimeout(timer); reject(e); } }
    try {
      if (fn.length > 0) {
        fn(function (err) { if (err) bad(err instanceof Error ? err : new Error(String(err))); else ok(); });
      } else {
        var r = fn();
        if (r && typeof r.then === 'function') r.then(ok, bad); else ok();
      }
    } catch (e) { bad(e); }
  });
}

function __hasRunnable(suite, inOnly) {
  if (suite.skip) return false;
  var only = inOnly || suite.only;
  for (var i = 0; i < suite.items.length; i++) {
    var it2 = suite.items[i];
    if (it2.kind === 'test') { if (!it2.skip && (!__onlyUsed || only || it2.only)) return true; }
    else if (__hasRunnable(it2.suite, only)) return true;
  }
  return false;
}

function __frames(err) {
  var res = [];
  var stack = err && err.stack ? String(err.stack).split('\n') : [];
  var sx = stack.length ? /^(.+?):(\d+)\s*$/.exec(stack[0]) : null;
  if (sx && __mods[sx[1]]) res.push({ file: sx[1], line: parseInt(sx[2], 10), col: 0 });
  for (var i = 0; i < stack.length; i++) {
    var m = /\(?([^\s()]+?):(\d+):(\d+)\)?\s*$/.exec(stack[i]);
    if (m && __mods[m[1]]) res.push({ file: m[1], line: parseInt(m[2], 10), col: parseInt(m[3], 10) });
  }
  return res;
}

function __where(err) {
  var fr = __frames(err);
  if (!fr.length) return '';
  var pick = null;
  for (var i = 0; i < fr.length; i++) if (!__mods[fr[i].file].isTest) { pick = fr[i]; break; }
  var first = fr[0];
  var text = '';
  var lines = [];
  if (pick && pick !== first) lines.push(pick);
  lines.push(first);
  lines.forEach(function (f) {
    var srcLine = (__mods[f.file].src.split('\n')[f.line - 1] || '').trim();
    text += '\n      at ' + f.file + ':' + f.line + (srcLine ? '   ' + srcLine.slice(0, 110) : '');
  });
  return text;
}

async function __runHooks(list, label, rec, errors) {
  for (var i = 0; i < list.length; i++) {
    try { await __callWithTimeout(list[i], __TEST_TIMEOUT); }
    catch (e) { errors.push({ label: label, err: e }); }
  }
}

async function __runSuite(suite, names, beEach, afEach, inOnly, results) {
  var be = beEach.concat(suite.beforeEach);
  var ae = suite.afterEach.concat(afEach);
  var only = inOnly || suite.only;
  var runnable = __hasRunnable(suite, inOnly);
  var hookErrors = [];
  if (runnable) await __runHooks(suite.beforeAll, 'beforeAll', null, hookErrors);
  for (var i = 0; i < suite.items.length; i++) {
    var item = suite.items[i];
    if (item.kind === 'suite') {
      await __runSuite(item.suite, names.concat(item.suite.name), be, ae, only, results);
      continue;
    }
    var rec = { file: item.file, names: names.concat(item.name), status: 'pass', err: null, ms: 0 };
    if (suite.skip || item.skip || (__onlyUsed && !only && !item.only)) { rec.status = 'skip'; results.push(rec); continue; }
    var started = Date.now();
    var errs = [];
    if (hookErrors.length) { errs = hookErrors.map(function (h) { return h.err; }); }
    else {
      var beErrs = [];
      await __runHooks(be, 'beforeEach', rec, beErrs);
      if (beErrs.length) errs = beErrs.map(function (h) { return h.err; });
      else {
        try { await __callWithTimeout(item.fn, __TEST_TIMEOUT); } catch (e) { errs.push(e); }
      }
      var afErrs = [];
      await __runHooks(ae, 'afterEach', rec, afErrs);
      afErrs.forEach(function (h) { errs.push(h.err); });
    }
    rec.ms = Date.now() - started;
    if (errs.length) { rec.status = 'fail'; rec.err = errs[0]; }
    results.push(rec);
  }
  if (runnable) {
    var afterErrors = [];
    await __runHooks(suite.afterAll, 'afterAll', null, afterErrors);
    if (afterErrors.length) results.push({ file: __curFile, names: names.concat('(afterAll hook)'), status: 'fail', err: afterErrors[0].err, ms: 0 });
  }
}

function __covStart() {
  try {
    var inspector = __nodeRequire('inspector');
    var s = new inspector.Session();
    s.connect();
    s.post('Profiler.enable');
    s.post('Profiler.startPreciseCoverage', { callCount: true, detailed: true });
    __covSession = s;
  } catch (e) { __covSession = null; __covWhy = (e && e.message) || 'inspector not available'; }
}

function __covTake() {
  if (!__covSession) return null;
  var got = null;
  try { __covSession.post('Profiler.takePreciseCoverage', function (err, res) { if (!err && res) got = res.result; }); } catch (e) { __covWhy = (e && e.message) || 'coverage failed'; }
  if (!got) __covWhy = __covWhy || 'no coverage data returned';
  return got;
}

function __rangesText(nums) {
  var out = [], i = 0;
  while (i < nums.length) {
    var j = i;
    while (j + 1 < nums.length && nums[j + 1] === nums[j] + 1) j++;
    out.push(j > i ? nums[i] + '-' + nums[j] : String(nums[i]));
    i = j + 1;
  }
  return out.join(', ');
}

function __fileCoverage(m, fnList) {
  var n = m.wrapped.length;
  var counts = new Array(n);
  var ranges = [];
  fnList.forEach(function (f) { f.ranges.forEach(function (r) { ranges.push(r); }); });
  ranges.sort(function (a, b) { return (a.startOffset - b.startOffset) || (b.endOffset - a.endOffset); });
  ranges.forEach(function (r) { counts.fill(r.count, r.startOffset, Math.min(r.endOffset, n)); });
  var lines = m.wrapped.split('\n');
  var offset = 0, total = 0, hit = 0, missed = [];
  for (var i = 0; i < lines.length && i < m.srcLines; i++) {
    var line = lines[i];
    var skipFrom = i === 0 ? m.prefixLen : 0;
    var rest = line.slice(skipFrom);
    var trimmed = rest.trim();
    var isCode = trimmed.length > 0 && !/^(\/\/|\/\*|\*)/.test(trimmed) && !/^[{}()\[\];,]*$/.test(trimmed);
    if (isCode) {
      var p = offset + skipFrom + (rest.length - rest.replace(/^\s+/, '').length);
      var c = counts[p];
      total++;
      if (c === undefined || c > 0) hit++; else missed.push(i + 1);
    }
    offset += line.length + 1;
  }
  return { total: total, hit: hit, missed: missed };
}

function __coverageReport() {
  var data = __covTake();
  if (!data) return 'COVERAGE: not available on this server' + (__covWhy ? ' (' + __covWhy + ')' : '') + '.';
  var byUrl = {};
  data.forEach(function (s) { if (__mods[s.url]) byUrl[s.url] = s.functions; });
  var names = Object.keys(__mods).filter(function (p) { return !__mods[p].isTest && /\.(m?js|cjs)$/.test(p); }).sort();
  var rows = [], T = 0, H = 0;
  names.forEach(function (p) {
    var m = __mods[p];
    if (!m.loaded) { var cnt = m.src.split('\n').filter(function (l) { var t = l.trim(); return t && !/^(\/\/|\/\*|\*)/.test(t) && !/^[{}()\[\];,]*$/.test(t); }).length; rows.push({ file: p, pct: 0, text: '0% (0/' + cnt + ') never loaded by any test' }); T += cnt; return; }
    var fns = byUrl[p];
    if (!fns) return;
    var r = __fileCoverage(m, fns);
    T += r.total; H += r.hit;
    var pct = r.total ? Math.round(100 * r.hit / r.total) : 100;
    rows.push({ file: p, pct: pct, text: pct + '% (' + r.hit + '/' + r.total + ')' + (r.missed.length ? ' not run: ' + __rangesText(r.missed.slice(0, 60)) + (r.missed.length > 60 ? ', ...' : '') : '') });
  });
  if (!rows.length) return 'COVERAGE: no project source file was loaded by the tests.';
  var out = ['COVERAGE (lines, V8): ' + (T ? Math.round(100 * H / T) : 100) + '% overall (' + H + '/' + T + ' lines)'];
  rows.slice(0, 15).forEach(function (r) { out.push('  ' + r.file + '  ' + r.text); });
  if (rows.length > 15) out.push('  ... and ' + (rows.length - 15) + ' more files');
  return out.join('\n');
}

function __briefMessage(err) {
  var msg = err && err.message !== undefined ? String(err.message) : String(err);
  if (!err || err.__matcher !== true) {
    var name = err && err.name && err.name !== 'Error' ? err.name + ': ' : '';
    msg = name + msg;
  }
  if (msg.length > 700) msg = msg.slice(0, 700) + '...';
  return msg.split('\n').map(function (l, i) { return i === 0 ? l : '      ' + l.trim(); }).join('\n');
}

async function __anjooRun(testFiles, withCoverage) {
  process.on('unhandledRejection', function (r) { __stray.push(r && r.message ? r.message : String(r)); });
  process.on('uncaughtException', function (e) { __stray.push((e && e.message) || String(e)); });
  if (withCoverage) __covStart();
  var files = [];
  testFiles.forEach(function (f) {
    __curFile = f;
    console.log('LOADING ' + f);
    try { __load(f); files.push(f); }
    catch (e) { __loadErrors.push({ file: f, message: (e && e.name && e.name !== 'Error' ? e.name + ': ' : '') + (e && e.message), err: e }); }
  });
  var results = [];
  await __runSuite(__rootSuite, [], [], [], false, results);
  var pass = 0, fail = 0, skip = 0;
  results.forEach(function (r) { if (r.status === 'pass') pass++; else if (r.status === 'fail') fail++; else skip++; });
  var errors = __loadErrors.length;
  var ran = pass + fail;
  var verdict = errors || fail ? 'FAIL' : (ran === 0 ? 'NONE' : 'PASS');
  var out = [];
  out.push('RESULT: ' + verdict + ' ran=' + ran + ' passed=' + pass + ' failed=' + fail + ' skipped=' + skip + ' errors=' + errors);
  if (errors) {
    out.push('', 'FILES THAT COULD NOT LOAD:');
    __loadErrors.forEach(function (e) { out.push('  ERROR ' + e.file + ': ' + __briefMessage({ message: e.message }) + __where(e.err)); });
  }
  if (fail) {
    out.push('', 'FAILED TESTS:');
    var shown = 0, used = 0;
    results.forEach(function (r) {
      if (r.status !== 'fail') return;
      var block = '  FAIL ' + r.file + ' > ' + r.names.join(' > ') + '\n      ' + __briefMessage(r.err) + __where(r.err);
      if (used + block.length > 3500) { shown++; return; }
      used += block.length;
      out.push(block);
    });
    if (shown) out.push('  ... ' + shown + ' more failed tests not shown (fix these first, then run again)');
  }
  if (__stray.length) out.push('', 'UNHANDLED ERRORS DURING TESTS (' + __stray.length + '): ' + __stray.slice(0, 3).join(' | '));
  if (withCoverage) out.push('', __coverageReport());
  if (ran > 0 && ran <= 40) {
    out.push('', 'TESTS:');
    results.forEach(function (r) { out.push('  ' + (r.status === 'pass' ? 'PASS' : r.status === 'fail' ? 'FAIL' : 'SKIP') + '  ' + r.names.join(' > ')); });
  } else if (ran > 40) {
    out.push('', 'TESTS: ' + pass + ' passed (list left out, there are many)');
  }
  process.stdout.write(out.join('\n') + '\n', function () { process.exit(0); });
}
