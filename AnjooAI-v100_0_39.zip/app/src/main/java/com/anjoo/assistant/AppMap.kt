package com.anjoo.assistant

import java.util.Locale

/**
 * App Map: where every screen, button and setting of Anjoo AI lives.
 * Anjoo uses it (a) as a compact always-in-prompt summary and (b) through the `app_map` tool for details,
 * so it can tell the user exactly "where is this" instead of guessing.
 * Keep this in sync with the real menus in MainActivity when UI labels change.
 */
object AppMap {
    /** One entry per screen/area. First line = title, the rest = what is there and how to reach it. */
    private val SECTIONS: List<Pair<String, String>> = listOf(
        "Main chat screen (home)" to
            "Top: ≡ (chat history / side menu), Anjoo's small buddy icon, title 'Anjoo AI' + subtitle (model; tap = model sheet), + (new chat), ⋮ (this chat's menu). " +
            "Bottom composer: text box 'Chat with…'; '+' (Add To Session: Take Photo, Upload Image, Upload File); model chip (choose the AI/model); " +
            "one round button: mic (tap = dictate by voice, hold 2 seconds = Live voice on/off), SEND when there is text, STOP while an answer is coming. " +
            "When Live voice is running, a 'Live voice is on · tap to stop' bar shows at the top. In a long chat the ↓ button jumps to the latest message.",
        "⋮ Chat menu (the ⋮ in the header)" to
            "Share chat, Rename, Add to project (+ remove from project), Export chat (PDF / Word / Text), Delete chat, Starred answers, Settings.",
        "≡ Side menu / chat history" to
            "List of chats (search, pin, rename, copy, share, delete). At the bottom: 'More tools', 'Update your app', 'Settings'. " +
            "Shortcuts order: 'Codixa — Projects, Code, Files & Chat' (CodixaActivity), 'HS — AI App Builder' (HSActivity), 'Website Builder — Professional Websites' (askWebsite chat flow), then 'Artifacts & Docs' (ArtifactActivity, saved artifact library).",
        "More tools (side menu > More tools)" to
            "Mode: Think, Deep Research (many searches + sourced report; also by starting a message with 'deep research' or '/research'), Web search, Coding workspace, Create image (asks for picture style/size/versions). Starred answers, Export chat, Add chat to a project, Connectors, Response style, Effort (low/medium/high). " +
            "Tools: Read text from photo, Big project, Models and keys, Export actual model report, Add keys (paste all keys; the company is detected automatically).",
        "Settings (side menu or ⋮ > Settings)" to
            "Workspace: Chat history, Tasks, Notes, Artifacts and docs, Older pages and code. " +
            "Assistant: Custom instructions, Voice and language, Show thinking and commands, Skip confirmations, Proactive suggestions, AI self-check / failure alerts, What Anjoo has learned. " +
            "Phone: Permissions and status, Phone control. " +
            "Connections: API key and model, Models and keys / health, Export real model report, Telegram. " +
            "App: Anjoo AI folder, Appearance (theme), Live AI hologram style, Backup and restore (Export/Import backup, Auto backup (every 3 days)). About: Version.",
        "Voice and language (Settings > Voice and language)" to
            "JARVIS mode (wake word + natural voice + tools in one tap). Speaking: Assistant voice (tap to listen and choose), Natural AI voice, Read chat replies aloud, Read new messages aloud. " +
            "Listening: Speech language, Listening engine (Gemini Live / Always-on Gemini STT / Google speech), Wake word 'Anjoo'. " +
            "Live voice display: 'Live orb' (gol transparent orb, default On), 'Hologram image' (default Off), Floating Buddy character. Help: Voice status (last error).",
        "Live orb and hologram" to
            "Live voice shows a round transparent orb by default (it takes no touches; taps go to the screen behind it). The Hologram image is Off by default; " +
            "turning on Settings > Voice and language > 'Hologram image' shows the hologram instead of the orb; choose its style in Settings > 'Live AI hologram style'. " +
            "To turn the orb off completely, switch the 'Live orb' toggle Off. Both overlays show above other apps with the 'Display over other apps' permission; otherwise only inside the app.",
        "Phone control (Settings > Phone control)" to
            "Permissions: Grant permissions, Accessibility (typing, taps), Notification access, Exact alarms (reminders). Files: Storage access, Default save folder. Display: Floating Buddy.",
        "Connectors (More tools > Connectors)" to
            "AI companies: Limit meter, API keys, Models and keys, Export real model report. Apps and services: Telegram, Notifications (reads new messages aloud), Phone control (Accessibility), Files and storage.",
        "Models and keys" to
            "Which company/model key is working, which AI is used for what, Limit meter (which key's limit is used up). Paste all keys at once in 'Add keys'. The report can be exported as PDF/Word/Excel/Text.",
        "Anjoo AI folder (Settings > App)" to
            "Permanent folder: chats, documents, projects, images, notes, backups. Actions: Sync now, Backup now, Back up keys (encrypted), Restore from folder, Recovery passphrase, Allow all files access, List of folders. Privacy lock is here.",
        "Backup and restore" to
            "Settings > Backup and restore: Export backup, Import backup, Anjoo AI folder, Auto backup (every 3 days). Includes chats, Code Studio projects and attachments.",
        "Tasks screen" to "Settings > Workspace > Tasks. Add tasks with '+ New'; tap a task = edit/move/delete; the result of a scheduled agent shows in the task.",
        "Notes screen" to "Settings > Workspace > Notes. '+ New', search, ⋮ menu (Sync with another phone). Notes are saved only on this phone.",
        "Artifacts and docs" to "Side menu > 'Artifacts & Docs' (after Website Builder) or Settings > Workspace > Artifacts and docs: a library of created web pages, dashboards, small apps, slides, documents and reports; open, live preview, edit, restore versions, export and share.",
        "Tools Hub" to "More tools (+ button) > Tools Hub or Settings > Connections > Tools Hub: browse all registered tools by category and search; open each tool's purpose, risk, parameters and current permission/setup readiness; Recent activity shows the status/time/duration of the last 80 executions. The history does not store message text, tool arguments, files or raw output.",
        "Codixa (side menu shortcut)" to "Projects, code files, preview and project chat in one place. Project par tap = options, 'Code files', 'Project chat', live PREVIEW.",
        "HS — AI App Builder (side menu shortcut)" to "A planner/builder for making apps ('Plan before building', examples). To make an APK use HS APK Builder: GitHub connect, build type, APK download, encrypted cloud token backup.",
        "Website Builder (side menu shortcut)" to "Professional multi-page websites: planning, design, coding, preview, audits, SEO and deployment preparation. A website can also be made in chat with natural language.",
        "Artifacts (side menu shortcut)" to "'Artifacts & Docs' comes right after Website Builder in the side menu. A library of saved web pages, dashboards, small apps, slides, documents and reports; open, live preview, edit, version history, export and share.",
        "Live preview dock (above the chat)" to "The web app's live panel: ⟳ reload, ⛶ full screen, ▾/▴ smaller/larger, ✕ close.",
        "Permissions and status screen" to "Settings > Phone > Permissions and status: shows each permission ON/OFF and opens the right settings screen.",
        "Memory & Knowledge (Settings > row 'Manage Memory & Knowledge')" to
            "In Settings the memory rows are: 'Save Memory (Yes / No)', 'Auto Memory' (remember preferences, people and ongoing work automatically) and 'Manage Memory & Knowledge'. " +
            "That screen has two tabs: Memories (+ Add memory, search, pin/edit/delete, types like Preference / Person, 'View all memories') and Knowledge (+ Add text, import a local document, search documents, 'Use Knowledge in AI answers' switch, 'AI Semantic Search' + 'Build AI Index'). " +
            "Also: Export Memory & Knowledge JSON, Merge from Memory & Knowledge JSON, Delete all memories / knowledge / AI semantic index, privacy note. Everything stays private on this device.\n",
        "HS APK Builder (HS screen > APK Builder, or Codixa > Build APK)" to
            "Builds a real APK on GitHub Actions: 1) 'Connect GitHub' (fine-grained token, 'Create repo' / 'Create token' links, 'Save & test connection', 'Clear saved token'); " +
            "2) optional 'Permanent cloud backup' of the token (Supabase email sign-in, 'Back up GitHub token', 'Delete cloud copy'); 3) 'Choose a project'; " +
            "4) 'Build type' = Auto detect / Native / WebView APK; 5) 'App info' (optional name/version); 6) 'Build APK'. Then 'Recent builds', APK download and Install. 'Open Codixa' / 'Open HS builder' jump to the project or planner.",
        "HS builder examples (HS — AI App Builder)" to
            "Question 'What do you want to build?' with groups Android / Website or web app / Creative (image, video). Example cards: Business website, Online store, Booking app, Business tool, Mini game, AI-powered app, Client portal, Custom from scratch; " +
            "Android: Business app, Task manager, Inventory app, Chat app, Calendar and appointments, Custom Android app; Creative: Product image, Promo video, Social campaign, Image to video, Brand kit, Video recreation. " +
            "Options (↑↓) include Login & roles, Local database, Admin dashboard, Payments & subscriptions, SEO metadata. Buttons: 'Build with AI', 'Build & Download'.",
        "Codixa project actions (Codixa > a project)" to
            "Tap a project: Open project, Open live preview, Open code files, Project chat (copy chat), Build APK, Export project ZIP, and the Engineering audit (Full quality gate, Security review, Dependency inventory, Architecture map, Code metrics, Release readiness, Copy report). " +
            "In code files: Edit file, Copy code, Save changes (detects concurrent changes). Top: '+ New task' (start a task in Anjoo), search 'Search projects and files…'.",
        "Permissions list (Settings > Phone > Permissions and status)" to
            "Rows: Microphone (voice commands, wake word), Phone calls, Send SMS, Read SMS, Contacts, Calendar, Call log, Phone state, Location, Camera, Photos/videos/audio, Bluetooth, Notifications, Exact alarms (reminders), Run in background (keeps live voice and Telegram alive), Display over other apps (pointer arrow, orb). " +
            "'Grant missing permissions' asks all that are off; 'Open Android app settings' opens the system page.",
        "Task Board (Tasks screen details)" to
            "States: Paused, Done, Cancelled, Issue. Task menu: Edit task, Move to, 'Ask Anjoo to do it', Pause agent / Resume agent, Cancel agent run, Delete. A finished agent job offers 'Open Task Board'.",
        "Notes screen details" to
            "Notes: search, + New note, edit, pin/unpin, share text, delete; Sync with another phone by 'Save sync file' / 'Merge from file'. Saved only on this phone.",
        "Artifact screen details" to
            "Per artifact: Copy source, Share as text, Wi-Fi link (share on Wi-Fi: 'Make link' / 'Stop sharing'), Save to phone, New artifact.",
        "Study mode (learn from the internet)" to "No button: just tell Anjoo in chat 'seekho / learn / study <topic>' or 'best templates dhoondo'. Anjoo runs several web searches, reads the best pages, writes a short note in its own words with source links, shows it to you and asks. Only after you tap Confirm it saves the note to Settings > Manage Memory & Knowledge > Knowledge. You can search, edit or delete it there. For a repeating topic say 'roz subah 8 baje <topic> par seekho': a scheduled job researches and sends a short note as a notification (it saves nothing by itself; say \"save kar do\" later). Weekly schedules are not available yet, only daily or one time. See the card on the Task Board.",
        "Settings layout (exact order)" to
            "Settings is one list with these sections in order: Setup (AI provider / model, API key), Display (Text size, Anjoo language, Appearance, Live AI hologram style), Assistant (Custom instructions, Voice and language, What Anjoo has learned), " +
            "Behavior (switches: Show thinking and commands, Skip confirmations, Update app automatically when opened, Proactive suggestions, AI self-check / failure alerts), Connections (AI models and keys, Telegram), Phone (Permissions and status, Phone control), " +
            "Data and privacy (Anjoo AI folder, Backup and restore), Advanced, Starred answers, Export this chat, Add this chat to a project, About.",
        "Text size (Settings > Display > Text size)" to "Changes the text size of the whole app; the screen reloads so every label changes. Also available inside the API key and model screen ('Text size (poori app)').",
        "Anjoo language (Settings > Display > Anjoo language)" to "Choose the language Anjoo uses to talk to you. Also shown as 'Anjoo Language' in the API key and model screen. Speech language for listening is separate: Settings > Voice and language.",
        "Live AI hologram style (Settings > Display)" to "Opens 'Live AI agent appearance': pick the look of the hologram character. It only shows when 'Hologram image' is On in Voice and language; the default Live voice display is the orb.",
        "Privacy lock (Settings > Data and privacy > Anjoo AI folder > Privacy)" to "'Privacy lock' ON = Anjoo works only inside the Anjoo AI folder (encrypted) and files in other folders are off-limits. Tap to turn it ON; turning it OFF asks for confirmation.",
        "Agent System (Workspace list)" to "Workspace list (opened from the app's tools menu) has: Codixa, HS, Website Builder, Artifacts and docs, Tasks, Notes, Tools Hub, 'Agent System' (autonomous runs, checkpoints and results; button 'Open Task Board'), continue previous website work, Older pages and code (only if any), Recently deleted (undo a deleted note or task, kept 14 days), Activity timeline (what Anjoo did and whether it worked).",
        "Fix the problem (pop-up)" to "Not a menu: this pop-up appears by itself after an AI error. Key invalid/disabled (401/403) = enter a correct key; model or Base URL wrong (404) = open Settings; provider limit reached (429) = pick another key or model. Button 'Open Settings' or 'Later'.",
        "Talk to ChatGPT, Gemini and other AIs" to "No screen needed: tell Anjoo 'ChatGPT se poochho' or 'second opinion lo'. Anjoo uses the 'Ask another AI model' tool with the keys you saved (Settings > Connections > AI models and keys). company='list' shows which companies have a key. Only companies with a saved key can be asked.",
        "Updates" to "Side menu > 'Update your app': check/download the new version."
    )

    /** Compact list that is always inside the system prompt (titles + 1 line). */
    fun promptBlock(): String {
        val sb = StringBuilder("APP MAP (Anjoo AI's own screens): you must know every button/feature of the app. When the user asks 'where is X / how do I do X', ")
        sb.append("first run the app_map tool (query = a word), then give the path directly as a short, correct chain like 'Settings > Voice and language > ...'. Do not guess, and say 'this is not in the app' for anything that is not in the map.\n")
        sb.append("Areas: ")
        sb.append(SECTIONS.joinToString("; ") { it.first })
        sb.append(".\n")
        sb.append("Key shortcuts: Live voice = hold the mic button for 2 seconds. Models/keys = Settings > Connections or More tools. Theme = Settings > App > Appearance. ")
        sb.append("Orb/hologram = Settings > Voice and language > Live voice display (orb default On, hologram default Off). Backup = Settings > App > Backup and restore.\n")
        return sb.toString()
    }

    /** Detail for the `app_map` tool. Empty query returns everything. */
    fun lookup(query: String): String {
        val words = query.lowercase(Locale.ROOT).split(Regex("[\\s,;]+")).filter { it.length >= 2 }
        val hits = if (words.isEmpty()) SECTIONS else SECTIONS.filter { (t, d) ->
            val hay = (t + " " + d).lowercase(Locale.ROOT)
            words.any { hay.contains(it) }
        }
        if (hits.isEmpty()) return "Nothing matching '" + query + "' was found in the app map. Leave the query empty for the full list. If the feature is not in the map it is not in the app; tell the user the truth."
        val sb = StringBuilder("ANJOO APP MAP" + (if (query.isNotBlank()) " ('" + query + "')" else "") + ":\n")
        for ((t, d) in hits) sb.append("• ").append(t).append(": ").append(d).append("\n")
        return sb.toString()
    }
}
