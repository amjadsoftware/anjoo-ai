package com.anjoo.assistant

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Agent runs: the history of every autonomous run on the Task Board, and for each run its prompt, plan,
 * step marks, the timeline of stages the orchestrator really went through, and the saved result.
 * Everything shown is read from the stored task card. Runs made before v100.0.33 have no timeline; the screen says so.
 */
class AgentRunsActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private val bg = Color.rgb(247, 246, 243)
    private val surface = Color.WHITE
    private val ink = Color.rgb(32, 37, 43)
    private val muted = Color.rgb(105, 112, 120)
    private val accent = Color.rgb(37, 111, 194)
    private val line = Color.rgb(225, 228, 232)
    private val good = Color.rgb(46, 125, 50)
    private val bad = Color.rgb(198, 40, 40)
    private val warn = Color.rgb(230, 126, 0)
    private lateinit var titleView: TextView
    private lateinit var subtitleView: TextView
    private lateinit var content: LinearLayout
    private var openId = 0
    private var showPolicy = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat(); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(22), dp(16), dp(12))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        top.addView(TextView(this).apply {
            text = "‹"; textSize = 32f; setTextColor(ink); gravity = Gravity.CENTER
            setOnClickListener { goBack() }
        }, LinearLayout.LayoutParams(dp(46), dp(48)))
        titleView = TextView(this).apply { textSize = 24f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD }
        subtitleView = TextView(this).apply { textSize = 12.5f; setTextColor(muted) }
        top.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(titleView); addView(subtitleView)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = "↻"; textSize = 25f; setTextColor(accent); gravity = Gravity.CENTER
            setOnClickListener { render() }
        }, LinearLayout.LayoutParams(dp(42), dp(46)))
        root.addView(top)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(content); isVerticalScrollBarEnabled = false },
            LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) })
        setContentView(root)
        render()
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) render() }

    private fun goBack() { if (openId > 0 || showPolicy) { openId = 0; showPolicy = false; render() } else finish() }

    @Suppress("DEPRECATION")
    override fun onBackPressed() { if (openId > 0 || showPolicy) { openId = 0; showPolicy = false; render() } else super.onBackPressed() }

    private fun time(ms: Long): String = if (ms <= 0) "-" else SimpleDateFormat("d MMM, HH:mm:ss", Locale.getDefault()).format(Date(ms))

    private fun duration(ms: Long): String {
        val s = ms / 1000
        return when { s < 60 -> "${s}s"; s < 3600 -> "${s / 60}m ${s % 60}s"; else -> "${s / 3600}h ${(s % 3600) / 60}m" }
    }

    private fun stageColor(stage: String): Int = when (stage) {
        "Done" -> good
        "Blocked", "Needs attention", "Needs setup", "Stopped" -> bad
        "Paused", "Pausing", "Cancelling" -> warn
        else -> accent
    }

    private fun addText(parent: LinearLayout, s: String, color: Int = muted, size: Float = 13f, bold: Boolean = false, selectable: Boolean = false) {
        parent.addView(TextView(this).apply {
            text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
            if (selectable) setTextIsSelectable(true)
            setPadding(0, dp(4), 0, 0)
        })
    }

    private fun card(body: LinearLayout.() -> Unit, onClick: (() -> Unit)? = null) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(surface, dp(14), line)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            if (onClick != null) setOnClickListener { onClick() }
        }
        c.body()
        content.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
    }

    private fun runs(): List<JSONObject> {
        val a = Tasks.all(this)
        val out = ArrayList<JSONObject>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (o.has("agentStage") || o.optString("title").startsWith("🤖 Agent:")) out.add(o)
        }
        return out.sortedByDescending { maxOf(it.optLong("agentUpdatedAt"), it.optLong("agentStartedAt"), it.optLong("at")) }
    }

    private fun render() {
        content.removeAllViews()
        if (openId > 0) { renderDetail(); return }
        if (showPolicy) { renderPolicy(); return }
        titleView.text = "Agent runs"
        val list = runs()
        subtitleView.text = if (list.isEmpty()) "No runs yet" else "${list.size} run" + (if (list.size == 1) "" else "s") + " on the Task Board"
        card({
            addText(this, "Limits & permissions  ›", accent, 14f, true)
            addText(this, "What agents may do, step and retry limits, and what the app enforces.", muted, 12f)
        }) { showPolicy = true; render() }
        if (list.isEmpty()) {
            card({ addText(this, "No autonomous run has been made yet. When Anjoo runs an agent task, it is listed here with its plan, timeline and result.") })
            return
        }
        for (o in list) {
            val stage = o.optString("agentStage", o.optString("status"))
            card({
                addText(this, "#" + o.optInt("id") + "  " + o.optString("title").removePrefix("🤖 Agent:").trim(), ink, 14.5f, true)
                addText(this, stage + (if (o.optString("agentActivity").isNotBlank()) "  ·  " + o.optString("agentActivity") else ""), stageColor(stage), 12.5f)
                val started = o.optLong("agentStartedAt"); val finished = o.optLong("agentFinishedAt")
                var meta = "Started " + time(started)
                if (started > 0 && finished > started) meta += "  ·  took " + duration(finished - started)
                else if (finished == 0L && o.optLong("agentUpdatedAt") > 0) meta += "  ·  last update " + time(o.optLong("agentUpdatedAt"))
                addText(this, meta, muted, 11.5f)
            }) { openId = o.optInt("id"); render() }
        }
    }

    private fun renderPolicy() {
        titleView.text = "Limits & permissions"
        subtitleView.text = "Generated from the app's real settings"
        for ((heading, lines) in AgentPolicy.sections()) card({
            addText(this, heading, ink, 14f, true)
            for (l in lines) addText(this, "•  $l", muted, 12.5f)
        })
    }

    private fun renderDetail() {
        val o = Tasks.all(this).let { a -> (0 until a.length()).mapNotNull { a.optJSONObject(it) }.firstOrNull { it.optInt("id") == openId } }
        if (o == null) { openId = 0; render(); return }
        val stage = o.optString("agentStage", o.optString("status"))
        titleView.text = "Run #" + o.optInt("id")
        subtitleView.text = stage

        card({
            addText(this, o.optString("title").removePrefix("🤖 Agent:").trim(), ink, 15f, true)
            addText(this, stage + (if (o.optString("agentActivity").isNotBlank()) "  ·  " + o.optString("agentActivity") else ""), stageColor(stage), 12.5f)
            val started = o.optLong("agentStartedAt"); val finished = o.optLong("agentFinishedAt")
            addText(this, "Started: " + time(started), muted, 12f)
            if (finished > 0) addText(this, "Finished: " + time(finished) + (if (started > 0 && finished > started) "  (took " + duration(finished - started) + ")" else ""), muted, 12f)
            else if (o.optLong("agentUpdatedAt") > 0) addText(this, "Last update: " + time(o.optLong("agentUpdatedAt")) + ". If the app was closed during the run, it may not have finished.", muted, 12f)
        })

        if (o.optString("agentPrompt").isNotBlank()) card({
            addText(this, "Task given to the agent", ink, 14f, true)
            addText(this, o.optString("agentPrompt").take(1500), muted, 12.5f, selectable = true)
        })

        val steps = o.optJSONArray("agentSteps")
        if (steps != null && steps.length() > 0) card({
            addText(this, "Plan steps", ink, 14f, true)
            for (i in 0 until steps.length()) {
                val st = steps.optJSONObject(i) ?: continue
                val mark = when (st.optString("state")) { "done" -> "✓"; "doing" -> "›"; "review" -> "!"; else -> "○" }
                addText(this, "$mark  " + st.optString("title"), ink, 12.5f)
            }
            addText(this, "Step marks are set when the run ends (all ✓ only if completion was verified). They are not tracked one by one during the run.", muted, 11f)
        })

        val log = o.optJSONArray("agentLog")
        card({
            addText(this, "Timeline", ink, 14f, true)
            if (log == null || log.length() == 0) addText(this, "No timeline was recorded for this run (runs made before v100.0.33 do not have one).", muted, 12.5f)
            else {
                for (i in 0 until log.length()) {
                    val e = log.optJSONObject(i) ?: continue
                    val label = e.optString("label")
                    addText(this, time(e.optLong("at")) + "  ·  " + label, stageColor(label), 12.5f, true)
                    if (e.optString("detail").isNotBlank()) addText(this, e.optString("detail"), muted, 12f)
                }
                addText(this, "At most the first and the last 80 events of a run are kept. Prompts, tool arguments and tool output are not stored in the timeline.", muted, 11f)
            }
        })

        if (o.optString("result").isNotBlank()) card({
            addText(this, "Saved result", ink, 14f, true)
            addText(this, o.optString("result"), ink, 12.5f, selectable = true)
        })
    }
}
