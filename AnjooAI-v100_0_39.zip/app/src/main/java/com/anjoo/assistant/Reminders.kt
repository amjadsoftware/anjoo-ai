package com.anjoo.assistant

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

/** Reminders, the daily briefing and prayer-time alerts, all kept as alarms. */
object Reminders {
    private fun p(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    @Synchronized
    fun list(ctx: Context): JSONArray =
        try { JSONArray(p(ctx).getString("reminders", "[]")) } catch (e: Exception) { JSONArray() }

    @Synchronized
    private fun save(ctx: Context, a: JSONArray) {
        p(ctx).edit().putString("reminders", a.toString()).apply()
    }

    @Synchronized
    fun add(ctx: Context, at: Long, text: String, kind: String): Int {
        val id = p(ctx).getInt("remId", 100) + 1
        p(ctx).edit().putInt("remId", id).apply()
        val a = list(ctx)
        a.put(JSONObject().put("id", id).put("at", at).put("text", text).put("kind", kind))
        save(ctx, a)
        schedule(ctx, id, at, kind, text)
        return id
    }

    private fun pending(ctx: Context, id: Int, kind: String, text: String): PendingIntent {
        val i = Intent(ctx, ReminderReceiver::class.java)
            .setAction("com.anjoo.assistant.ALARM")
            .putExtra("id", id).putExtra("kind", kind).putExtra("text", text)
        return PendingIntent.getBroadcast(ctx, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun schedule(ctx: Context, id: Int, at: Long, kind: String, text: String) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, id, kind, text)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    @Synchronized
    fun removeWhere(ctx: Context, pred: (JSONObject) -> Boolean): Int {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val old = list(ctx)
        val keep = JSONArray()
        var n = 0
        for (i in 0 until old.length()) {
            val o = old.getJSONObject(i)
            if (pred(o)) {
                am.cancel(pending(ctx, o.getInt("id"), o.optString("kind"), o.optString("text")))
                n++
            } else keep.put(o)
        }
        save(ctx, keep)
        return n
    }

    fun remove(ctx: Context, id: Int) { removeWhere(ctx) { it.getInt("id") == id } }
    fun removeKind(ctx: Context, kind: String) = removeWhere(ctx) { it.optString("kind") == kind }

    fun nextAt(hour: Int, minute: Int): Long {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, hour); c.set(Calendar.MINUTE, minute)
        c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        if (c.timeInMillis <= System.currentTimeMillis() + 5000) c.add(Calendar.DAY_OF_YEAR, 1)
        return c.timeInMillis
    }

    fun scheduleBrief(ctx: Context) {
        val t = p(ctx).getString("briefTime", "") ?: ""
        if (!t.contains(":")) return
        removeKind(ctx, "brief")
        add(ctx, nextAt(t.substringBefore(":").toInt(), t.substringAfter(":").toInt()), "", "brief")
    }

    fun scheduleRefresh(ctx: Context) {
        if ((p(ctx).getString("prayerCity", "") ?: "").isEmpty()) return
        removeKind(ctx, "prayer_refresh")
        add(ctx, nextAt(2, 30), "", "prayer_refresh")
    }

    /** After a reboot all alarms are gone, so put them back. */
    fun restoreAll(ctx: Context) {
        val now = System.currentTimeMillis()
        val a = list(ctx)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getLong("at") > now) schedule(ctx, o.getInt("id"), o.getLong("at"), o.optString("kind"), o.optString("text"))
        }
        removeWhere(ctx) { it.getLong("at") <= now }
        if ((p(ctx).getString("briefTime", "") ?: "").isNotEmpty()) scheduleBrief(ctx)
        scheduleRefresh(ctx)
        try { Habits.schedule(ctx) } catch (e: Exception) {}
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Reminders.restoreAll(ctx)
            try { Telegram.start(ctx) } catch (e: Exception) {}
            return
        }
        val id = intent.getIntExtra("id", 0)
        val kind = intent.getStringExtra("kind") ?: "reminder"
        val text = intent.getStringExtra("text") ?: ""
        Reminders.remove(ctx, id)
        if (kind == "brief") Reminders.scheduleBrief(ctx)
        if (kind == "prayer_refresh") Reminders.scheduleRefresh(ctx)
        if (kind == "agent_daily") {
            // repeat every day at the same time
            val hm = text.split("|", limit = 3).getOrNull(1) ?: ""
            val h = hm.substringBefore(":").trim().toIntOrNull()
            val m = hm.substringAfter(":").trim().toIntOrNull()
            if (hm.contains(":") && h != null && m != null && h in 0..23 && m in 0..59) {
                Reminders.add(ctx, Reminders.nextAt(h, m), text, kind)
            }
        }
        try {
            ctx.startForegroundService(Intent(ctx, AlertService::class.java).putExtra("kind", kind).putExtra("text", text))
        } catch (e: Exception) {
            AlertService.post(ctx, AlertService.title(kind), AlertService.message(kind, text))
        }
    }
}

/** Short-lived service that speaks a reminder or the morning briefing, then stops. */
class AlertService : Service() {

    companion object {
        private const val CH = "anjoo_alert"

        fun title(kind: String) = when (kind) {
            "brief" -> "Morning briefing"
            "prayer" -> "Prayer time"
            "agent", "agent_daily" -> "Anjoo is working"
            else -> "Reminder"
        }

        fun message(kind: String, text: String) = when (kind) {
            "prayer" -> "It is prayer time: $text"
            "brief" -> "Good morning! Preparing your briefing..."
            "agent", "agent_daily" -> "Running the scheduled task..."
            else -> "Yaad dihani: $text"
        }

        private fun channel(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Anjoo yaad dihani", NotificationManager.IMPORTANCE_HIGH))
        }

        fun build(ctx: Context, title: String, text: String): Notification {
            channel(ctx)
            val open = PendingIntent.getActivity(
                ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            return Notification.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
        }

        fun post(ctx: Context, title: String, text: String) {
            try {
                ctx.getSystemService(NotificationManager::class.java)
                    .notify((System.nanoTime() % 100000).toInt() + 1000, build(ctx, title, text))
            } catch (e: Exception) {}
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val kind = intent?.getStringExtra("kind") ?: "reminder"
        val text = intent?.getStringExtra("text") ?: ""
        try {
            val n = build(this, title(kind), message(kind, text))
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(77, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(77, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        Thread {
            try {
                when (kind) {
                    "brief" -> {
                        val said = try {
                            val ag = Agent(this, Actions(this) { false })
                            ag.urduScriptVoice = true
                            ag.ask("Good morning! Give me my morning briefing: the weather for my city (guess the city from the timezone), today's calendar events, my reminders, and today's remaining tasks on the task board. In 3-4 short sentences, in a friendly tone.")
                        } catch (e: Exception) {
                            "Good morning! Have a good day."
                        }
                        post(this, "Morning briefing", said)
                        Speaker.say(this, said)
                    }
                    "prayer_refresh" -> MoreTools.refreshPrayers(this)
                    "agent", "agent_daily" -> AgentJobs.runScheduled(this, kind, text)
                    else -> {
                        post(this, title(kind), message(kind, text))
                        Speaker.say(this, message(kind, text))
                    }
                }
            } catch (e: Exception) {
            } finally {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }.start()
        return START_NOT_STICKY
    }
}
