package com.anjoo.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * One-shot voice typing for the chat box. It listens once, then hands the text back so the user can
 * check and fix it before sending. Uses the same engine choice as live voice (Gemini "ear" or Google).
 * All callbacks arrive on the main thread.
 */
class Dictation(private val ctx: Context) {

    interface Listener {
        fun onPartial(text: String)
        /** [alts] are other versions the recogniser thought of (may be empty). */
        fun onResult(best: String, alts: List<String>)
        fun onFail(msg: String)
    }

    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var ear: Ear? = null
    private var timeout: Runnable? = null
    @Volatile var active = false
        private set
    private var gen = 0

    private fun prefs() = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    private fun useEar() = (prefs().getString("engine", "google") ?: "google") == "ear"

    fun start(l: Listener) {
        stop()
        active = true
        val my = ++gen
        if (useEar()) startEar(l, my) else startGoogle(l, my)
    }

    /** Stops listening. With the Google engine the text heard so far still comes back; with Gemini it is dropped. */
    fun stop() {
        timeout?.let { main.removeCallbacks(it) }; timeout = null
        try { ear?.stop() } catch (e: Exception) {}
        ear = null
        try { rec?.stopListening() } catch (e: Exception) {}
        if (rec == null) active = false
    }

    fun destroy() {
        gen++
        active = false
        timeout?.let { main.removeCallbacks(it) }; timeout = null
        try { ear?.stop() } catch (e: Exception) {}
        ear = null
        try { rec?.cancel(); rec?.destroy() } catch (e: Exception) {}
        rec = null
    }

    private fun finish(my: Int, f: () -> Unit) { main.post { if (my == gen) { active = false; f() } } }

    // ---------- Google recogniser ----------

    private fun startGoogle(l: Listener, my: Int) {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { active = false; l.onFail("Speech recognition is not available on this phone. Install the Google app."); return }
        try {
            rec?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(ctx)
            rec = r
            r.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
                override fun onPartialResults(p: Bundle?) {
                    val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                    if (my == gen && t.isNotBlank()) l.onPartial(t)
                }
                override fun onResults(res: Bundle?) {
                    val all = (res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()).map { it.trim() }.filter { it.isNotEmpty() }.distinct()
                    rec = null
                    if (all.isEmpty()) finish(my) { l.onFail("Nothing was heard. Press the mic again.") }
                    else finish(my) { l.onResult(all[0], all.drop(1).take(3)) }
                }
                override fun onError(error: Int) {
                    rec = null
                    val msg = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Nothing was heard. Press the mic again."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is needed."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> "Check the internet for speech recognition."
                        SpeechRecognizer.ERROR_CLIENT -> ""   // we cancelled it ourselves
                        else -> "Could not understand the speech (code $error)."
                    }
                    if (msg.isEmpty()) { if (my == gen) active = false } else finish(my) { l.onFail(msg) }
                }
            })
            val lang0 = prefs().getString("lang", "ur-PK") ?: "ur-PK"
            val lang = if (lang0 == "auto") "ur-PK" else lang0
            val other = if (lang == "en-US") "ur-PK" else "en-US"
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra("android.speech.extra.ADDITIONAL_LANGUAGES", arrayOf(other))
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 4)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1300L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000L)
            r.startListening(i)
        } catch (e: Exception) { active = false; l.onFail("The mic could not start: " + (e.message ?: "")) }
    }

    // ---------- Gemini "ear" ----------

    private fun startEar(l: Listener, my: Int) {
        if (!Stt.available(prefs())) { active = false; l.onFail("A Groq or Google Gemini key is needed to transcribe speech (Settings), or choose the Google engine in the Voice menu."); return }
        val e = Ear({ pcm ->
            main.post {
                if (my != gen) return@post
                timeout?.let { main.removeCallbacks(it) }; timeout = null
                try { ear?.stop() } catch (x: Exception) {}
                ear = null
                l.onPartial("…")
                Thread {
                    val lang = prefs().getString("lang", "ur-PK") ?: "ur-PK"
                    val text = try { Stt.transcribe(prefs(), pcm, lang).trim() } catch (x: Exception) { "" }
                    if (text.isEmpty()) finish(my) { l.onFail("Could not understand the speech. Press the mic again.") }
                    else finish(my) { l.onResult(text, emptyList()) }
                }.start()
            }
        }, { msg -> finish(my) { l.onFail("The mic did not open: $msg") } })
        ear = e
        e.start()
        val t = Runnable { if (my == gen && ear != null) { try { ear?.stop() } catch (x: Exception) {}; ear = null; active = false; l.onFail("Nothing was heard. Press the mic again.") } }
        timeout = t
        main.postDelayed(t, 15000)
    }
}
