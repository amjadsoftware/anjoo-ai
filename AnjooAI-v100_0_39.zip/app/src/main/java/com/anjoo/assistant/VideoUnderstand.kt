package com.anjoo.assistant

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Lets the AI really "watch and listen" to a video: the file is sent to Google Gemini (Files API, resumable upload),
 * which reads the pictures AND the sound, and its written analysis (speech with times, what is on screen, summary) is
 * returned as text. That text is then handed to whichever AI the user chats with, so this works with every provider.
 * Needs a Gemini key. Every failure returns null and the caller falls back to the picture frames only.
 */
object VideoUnderstand {
    private const val BASE = "https://generativelanguage.googleapis.com"
    /** Larger videos are not uploaded over mobile data; frames are used instead. */
    const val MAX_BYTES = 300L * 1024 * 1024

    private const val PROMPT = "Watch this whole video and listen to all of its sound. Write a complete, exact report with these parts:\n" +
        "1) SPEECH: everything that is said, in order, with times like [0:12]. Keep the spoken language and script (Urdu, Hindi, English, Roman Urdu...). If nobody speaks, say so.\n" +
        "2) SCREEN: what is shown over time with times: every app, screen, page, button, menu and chart; read any text on screen exactly; list each feature that is demonstrated and the steps in the order they happen.\n" +
        "3) SUMMARY: what the software or product is, who it is for, its main features, the likely technology, and anything the speaker stresses.\n" +
        "Be complete and precise. Never invent details that are not in the video; write 'unclear' when something cannot be seen or heard."

    private fun sizeOf(ctx: Context, uri: Uri): Long {
        try {
            ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { if (it.length > 0) return it.length }
        } catch (_: Exception) { }
        try {
            ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.SIZE)
                if (i >= 0 && c.moveToFirst()) return c.getLong(i)
            }
        } catch (_: Exception) { }
        return -1L
    }

    private fun readAll(c: HttpURLConnection): String {
        val s = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        return s?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
    }

    /** Blocking (call from a thread). Returns the analysis text, or null when it could not be made. */
    fun analyse(ctx: Context, uri: Uri, name: String, mimeIn: String, key: String): String? {
        val size = sizeOf(ctx, uri)
        if (size <= 0L || size > MAX_BYTES || key.isBlank()) return null
        val mime = if (mimeIn.startsWith("video/")) mimeIn else "video/mp4"
        var fileName = ""
        try {
            // 1) start a resumable upload
            val c1 = URL("$BASE/upload/v1beta/files").openConnection() as HttpURLConnection
            c1.requestMethod = "POST"; c1.connectTimeout = 15000; c1.readTimeout = 30000; c1.doOutput = true
            c1.setRequestProperty("x-goog-api-key", key)
            c1.setRequestProperty("X-Goog-Upload-Protocol", "resumable")
            c1.setRequestProperty("X-Goog-Upload-Command", "start")
            c1.setRequestProperty("X-Goog-Upload-Header-Content-Length", size.toString())
            c1.setRequestProperty("X-Goog-Upload-Header-Content-Type", mime)
            c1.setRequestProperty("Content-Type", "application/json")
            c1.outputStream.use { it.write(JSONObject().put("file", JSONObject().put("display_name", name.take(80))).toString().toByteArray(Charsets.UTF_8)) }
            if (c1.responseCode !in 200..299) return null
            val upUrl = c1.getHeaderField("x-goog-upload-url") ?: return null

            // 2) send the bytes straight from the phone's storage
            val c2 = URL(upUrl).openConnection() as HttpURLConnection
            c2.requestMethod = "POST"; c2.connectTimeout = 15000; c2.readTimeout = 180000; c2.doOutput = true
            c2.setFixedLengthStreamingMode(size)
            c2.setRequestProperty("X-Goog-Upload-Offset", "0")
            c2.setRequestProperty("X-Goog-Upload-Command", "upload, finalize")
            val ins = ctx.contentResolver.openInputStream(uri) ?: return null
            ins.use { input -> c2.outputStream.use { out -> input.copyTo(out, 64 * 1024) } }
            val up = readAll(c2)
            if (c2.responseCode !in 200..299) return null
            val f = JSONObject(up).optJSONObject("file") ?: return null
            fileName = f.optString("name", "")
            val fileUri = f.optString("uri", "")
            var state = f.optString("state", "")
            if (fileName.isEmpty() || fileUri.isEmpty()) return null

            // 3) wait while Google prepares the video
            val deadline = System.currentTimeMillis() + 150_000L
            while (state == "PROCESSING" && System.currentTimeMillis() < deadline) {
                Thread.sleep(3000)
                val c3 = URL("$BASE/v1beta/$fileName").openConnection() as HttpURLConnection
                c3.connectTimeout = 15000; c3.readTimeout = 30000
                c3.setRequestProperty("x-goog-api-key", key)
                val t = readAll(c3)
                if (c3.responseCode in 200..299) state = JSONObject(t).optString("state", state)
            }
            if (state != "ACTIVE") return null

            // 4) ask Gemini to watch + listen and write the report
            val parts = JSONArray()
                .put(JSONObject().put("fileData", JSONObject().put("mimeType", mime).put("fileUri", fileUri)))
                .put(JSONObject().put("text", PROMPT))
            val model = Providers.ALL[0].models.first()
            val out = Gemini.plain(key, model, "You are a careful video analyst.", parts, 8000, 0.2, true)
            return out.ifBlank { null }
        } catch (e: Exception) {
            return null
        } finally {
            if (fileName.isNotEmpty()) {
                try {
                    val d = URL("$BASE/v1beta/$fileName").openConnection() as HttpURLConnection
                    d.requestMethod = "DELETE"; d.connectTimeout = 10000; d.readTimeout = 10000
                    d.setRequestProperty("x-goog-api-key", key)
                    d.responseCode
                } catch (_: Exception) { }
            }
        }
    }
}
