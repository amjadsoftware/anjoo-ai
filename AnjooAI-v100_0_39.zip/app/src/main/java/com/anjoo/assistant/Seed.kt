package com.anjoo.assistant

import android.content.Context
import java.util.Properties

/**
 * Optional default API keys. If the file app/src/main/assets/keys.properties exists when the app is built,
 * every key written there is filled in on first run, so the app works without typing keys on the phone.
 * Keys the user already saved are never overwritten.
 *
 * Note: anything bundled in an APK can be extracted by whoever gets the APK. Use this only for your own
 * private build, and never share the APK or upload keys.properties to a public repository.
 */
object Seed {
    private val IDS: List<String> get() = Providers.ALL.map { it.id }.filter { it != "custom" }

    fun apply(ctx: Context) {
        val props = Properties()
        // keys.sealed (made by tools/seal_keys.py) is preferred: it is not readable as plain text inside the APK.
        val sealed = try { ctx.assets.open("keys.sealed").use { SealedKeys.open(it.readBytes()) } } catch (e: Exception) { null }
        if (sealed != null) {
            try { props.load(java.io.StringReader(sealed)) } catch (e: Exception) { return }
        } else {
            try { ctx.assets.open("keys.properties").use { props.load(it) } } catch (e: Exception) { return }
        }
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val ed = p.edit()
        var changed = false
        for (id in IDS) {
            val v = props.getProperty(id, "").trim()
            if (v.isNotEmpty() && (p.getString("key_$id", "") ?: "").isBlank()) {
                ed.putString("key_$id", v)
                changed = true
            }
        }
        // One-time: choose the default provider, and mirror its key/model into the "active" fields the app reads.
        val prov = props.getProperty("default_provider", "").trim()
        if (prov.isNotEmpty() && !p.getBoolean("seedProviderDone", false)) {
            val pv = Providers.byId(prov)
            val key = props.getProperty(pv.id, "").trim().ifEmpty { p.getString("key_" + pv.id, "") ?: "" }
            if (key.isNotEmpty()) {
                val model = props.getProperty("model_" + pv.id, "").trim().ifEmpty { pv.models.firstOrNull() ?: "" }
                ed.putString("provider", pv.id).putString("key", key).putString("model", model)
                ed.putString("model_" + pv.id, model)
                ed.putBoolean("seedProviderDone", true)
                changed = true
            }
        }
        // Gemini is the default provider: its key also goes into the "active key" slot the app reads.
        val g = props.getProperty("gemini", "").trim()
        val activeId = p.getString("provider", "gemini") ?: "gemini"
        if (g.isNotEmpty() && activeId == "gemini" && (prov.isEmpty() || Providers.byId(prov).id == "gemini") && (p.getString("key", "") ?: "").isBlank()) {
            ed.putString("key", g)
            changed = true
        }
        if (changed) ed.apply()
    }
}
