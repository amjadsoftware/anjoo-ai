package com.anjoo.assistant

import android.content.Context

/**
 * Self-test programs for Kotlin, Java and Go projects. There is no JUnit, kotlin.test or build tool on the online runner,
 * so the test is one small program with its own entry point that prints PASS/FAIL lines and a final
 * "SELFTEST passed=N failed=M" line. It is compiled together with the project's other files, WITHOUT the project's own
 * entry file (two entry points would clash), and run on the online runner after the user agreed.
 */
object SelfTests {
    val LANGS = setOf("kotlin", "java", "go")

    private val TEST_FILE = Regex("(^|/)tests/(SelfTest\\.(kt|java)|selftest\\.go)$")

    fun isSelfTest(path: String): Boolean = TEST_FILE.containsMatchIn(path)

    fun files(paths: Collection<String>): List<String> = paths.filter { isSelfTest(it) }.sorted()

    fun inTestsDir(path: String): Boolean = path.startsWith("tests/") || path.contains("/tests/")

    private fun ext(lang: String) = when (lang) { "kotlin" -> ".kt"; "java" -> ".java"; else -> ".go" }

    /** The self-test file of [lang] among [paths], or null. */
    fun fileFor(lang: String, paths: Collection<String>): String? = files(paths).firstOrNull { it.endsWith(ext(lang)) }

    private val FUNC = Regex(
        "(?m)^\\s*(?:(?:public|private|internal|protected|static|final|override|suspend|inline)\\s+)*(?:fun|func)\\s+\\w+|" +
            "^\\s*(?:public|protected)?\\s*static\\s+[\\w<>\\[\\], ]+\\s+\\w+\\s*\\("
    )

    /** Files with testable functions: same language, not the entry file, not in tests/. */
    fun modules(files: Map<String, String>, entry: String, lang: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for ((k, v) in files) {
            if (k == entry || inTestsDir(k)) continue
            if (RunCode.normLang(k.substringAfterLast('/')) != lang) continue
            if (FUNC.containsMatchIn(v)) out[k] = v
        }
        return out
    }

    /** The files of one run: all files of [lang] except the project's entry and tests/, plus the test file moved next to them. Returns (entry path, files). */
    fun runSet(files: Map<String, String>, entry: String, lang: String, testPath: String): Pair<String, Map<String, String>> {
        val dir = entry.substringBeforeLast('/', "")
        val runPath = (if (dir.isEmpty()) "" else "$dir/") + testPath.substringAfterLast('/')
        val m = LinkedHashMap<String, String>()
        for ((k, v) in files) {
            if (k == entry || inTestsDir(k)) continue
            if (RunCode.normLang(k.substringAfterLast('/')) == lang) m[k] = v
        }
        m[runPath] = files.getValue(testPath)
        return runPath to m
    }

    private val RESULT = Regex("SELFTEST passed=(\\d+) failed=(\\d+)")

    /** The online runner's report -> the same Outcome the Python tests use. ran=false when it cannot be judged. */
    fun outcome(lang: String, report: String): PyTests.Outcome {
        if (report.contains("The user declined") || report.contains("Could not reach") || report.contains("was not run") || report.contains("No server language"))
            return PyTests.Outcome(false, 0, 0, 0, 0, report.take(300))
        val body = report.substringAfter("OUTPUT:", report).substringBefore("\n\nResult:").trim()
        val m = RESULT.find(report)
        if (m != null) {
            val p = m.groupValues[1].toInt(); val f = m.groupValues[2].toInt()
            return PyTests.Outcome(true, p + f, f, 0, 0, body)
        }
        val v = Coder.compileVerdict(lang, report)
        if (v.isNotEmpty()) return PyTests.Outcome(true, 0, 0, 1, 0, v)
        return PyTests.Outcome(false, 0, 0, 0, 0, report.take(300))
    }

    /** Blocking. Runs the self-test of [lang] on the online runner (asks the user once through [confirm]). */
    fun run(ctx: Context, confirm: (String) -> Boolean, files: Map<String, String>, entry: String, lang: String, testPath: String): PyTests.Outcome {
        val (runEntry, set) = runSet(files, entry, lang, testPath)
        val report = try {
            if (set.size >= 2) {
                if (RunCode.plan(lang, runEntry, set) == null) return PyTests.Outcome(false, 0, 0, 0, 0, "No whole-project recipe for $lang.")
                RunCode.runMulti(ctx, confirm, lang, runEntry, set, "")
            } else RunCode.runSource(ctx, confirm, lang, set.getValue(runEntry), "")
        } catch (e: CancelledException) { throw e } catch (e: Exception) { return PyTests.Outcome(false, 0, 0, 0, 0, "The self-test could not run: " + (e.message ?: e.javaClass.simpleName)) }
        return outcome(lang, report)
    }

    fun systemPrompt(lang: String): String {
        val name = when (lang) { "kotlin" -> "Kotlin"; "java" -> "Java"; else -> "Go" }
        val file = when (lang) {
            "kotlin" -> "tests/SelfTest.kt with a top level fun main() (exit with kotlin.system.exitProcess(1) when something failed)"
            "java" -> "tests/SelfTest.java with public class SelfTest and public static void main(String[] args) (call System.exit(1) when something failed)"
            else -> "tests/selftest.go with package main and func main() (call os.Exit(1) when something failed)"
        }
        return "You are the TEST AGENT. The project is $name. There is no JUnit, kotlin.test, testing package or build tool here, so write ONE small self-test PROGRAM: $file. " +
            "It calls the functions of the modules below, compares each result with the expected value and prints one line per check: PASS <name> or FAIL <name>: expected <x> got <y>. " +
            "At the very end it prints exactly: SELFTEST passed=<N> failed=<M>. " +
            "The project's own entry file (its main) is NOT compiled together with your file, so never call it and never depend on it; test only code in the other files. " +
            "Use the same package as the modules (the same package line, or none when they have none) and only the standard library. " +
            "Test only functions and classes that really exist, with their exact names, signatures and visibility. For each important function write a normal case, an edge case (empty, zero, negative, invalid input) and every branch you see: 4 to 12 checks in all. " +
            "Work out every expected value by hand from the code; if you are not sure of a value, skip that check. No network, files, clock, randomness or stdin. Do not change any source file. " +
            "Output only the test file as a complete FILE block in the format below. If nothing in the project can be tested this way, output exactly NO_CHANGES."
    }
}
