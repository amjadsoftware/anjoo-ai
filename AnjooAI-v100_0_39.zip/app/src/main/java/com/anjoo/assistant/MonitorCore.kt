package com.anjoo.assistant

import java.util.Locale

/** Rules and formatting for System Monitoring. Pure Kotlin so it can be unit tested. Inputs are values really read from the phone; -1 means "not available". */
object MonitorCore {
    data class Alert(val action: String, val detail: String)

    fun alerts(
        batteryPct: Int, charging: Boolean,
        freeStorage: Long, totalStorage: Long,
        lowMemory: Boolean, online: Boolean,
        heapUsed: Long, heapMax: Long
    ): List<Alert> {
        val out = ArrayList<Alert>()
        if (batteryPct in 0..15 && !charging) out.add(Alert("Battery low", "$batteryPct% and not charging. Background agents may stop."))
        if (totalStorage > 0 && freeStorage >= 0 && (freeStorage * 100 / totalStorage < 10 || freeStorage < 500L * 1024 * 1024))
            out.add(Alert("Storage low", "${bytes(freeStorage)} free of ${bytes(totalStorage)}."))
        if (lowMemory) out.add(Alert("Device memory low", "Android reports low memory. Other apps may be closed."))
        if (!online) out.add(Alert("No network", "AI requests cannot be sent until the phone is online."))
        if (heapMax > 0 && heapUsed * 100 / heapMax >= 85) out.add(Alert("App memory high", "${bytes(heapUsed)} of ${bytes(heapMax)} in use."))
        return out
    }

    fun pct(part: Long, whole: Long): Int = if (whole <= 0) 0 else (part * 100 / whole).toInt().coerceIn(0, 100)

    fun bytes(n: Long): String = when {
        n < 0 -> "n/a"
        n >= 1L shl 30 -> String.format(Locale.US, "%.1f GB", n / (1024.0 * 1024 * 1024))
        n >= 1L shl 20 -> String.format(Locale.US, "%.1f MB", n / (1024.0 * 1024))
        n >= 1L shl 10 -> String.format(Locale.US, "%.0f KB", n / 1024.0)
        else -> "$n B"
    }

    fun duration(ms: Long): String {
        val s = (ms / 1000).coerceAtLeast(0)
        val d = s / 86400; val h = (s % 86400) / 3600; val m = (s % 3600) / 60
        return when { d > 0 -> "${d}d ${h}h"; h > 0 -> "${h}h ${m}m"; m > 0 -> "${m}m"; else -> "${s}s" }
    }

    /** Failure percentage, rounded down; 0 when nothing was measured. */
    fun failPct(ok: Int, fail: Int): Int = if (ok + fail <= 0) 0 else fail * 100 / (ok + fail)
}
