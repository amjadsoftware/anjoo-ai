package com.anjoo.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.util.TreeMap

/**
 * Reads a streamed answer (server-sent events, request sent with "stream": true) from an OpenAI-style or an
 * Anthropic API and rebuilds the SAME JSON that the non-streamed call would have returned. The rest of the app
 * (tool calls, usage ledger, Gemini-shape conversion) therefore does not change, but the first words now appear
 * on screen as soon as the model writes them instead of after the whole answer is finished.
 *
 * Pure Kotlin + org.json, so it can be unit-tested on the JVM.
 */
internal object SseParse {

    /** org.json turns a JSON null into the text "null" on Android; this gives "" instead. */
    private fun str(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")

    /**
     * Calls [onData] with (event name, data text) for every SSE event. Lines that are not part of SSE are collected and
     * returned: a server that ignored "stream": true sends one ordinary JSON body, which the caller then parses as usual.
     */
    private fun events(r: BufferedReader, onData: (String, String) -> Unit): String {
        val plain = StringBuilder()
        var ev = ""
        while (true) {
            val line = r.readLine() ?: break
            if (line.isEmpty()) { ev = ""; continue }
            when {
                line.startsWith("data:") -> {
                    val d = line.substring(5).trim()
                    if (d.isNotEmpty() && d != "[DONE]") onData(ev, d)
                }
                line.startsWith("event:") -> ev = line.substring(6).trim()
                line.startsWith(":") || line.startsWith("id:") || line.startsWith("retry:") -> { }
                else -> plain.append(line).append('\n')
            }
        }
        return plain.toString()
    }

    /** OpenAI-style (chat/completions) stream. [onText] gets the whole answer so far, [onThought] the reasoning so far. */
    fun openAi(r: BufferedReader, onText: (String) -> Unit, onThought: ((String) -> Unit)?): JSONObject {
        val text = StringBuilder()
        val reason = StringBuilder()
        val names = TreeMap<Int, String>()
        val args = TreeMap<Int, StringBuilder>()
        var finish = ""
        var usage: JSONObject? = null
        var sawEvent = false
        val watch = RepetitionGuard.Watch()
        val plain = try { events(r) { _, d ->
            sawEvent = true
            val o = try { JSONObject(d) } catch (e: Exception) { null }
            if (o == null) return@events
            val err = o.optJSONObject("error")
            if (err != null) throw IOException(str(err, "message").ifBlank { "The AI stopped the answer." })
            o.optJSONObject("usage")?.let { usage = it }
            val ch = o.optJSONArray("choices")?.optJSONObject(0) ?: return@events
            val fr = str(ch, "finish_reason")
            if (fr.isNotEmpty()) finish = fr
            val delta = ch.optJSONObject("delta") ?: return@events
            val c = delta.opt("content")
            if (c is String && c.isNotEmpty()) {
                text.append(c); onText(text.toString())
                if (watch.tripped(text.toString())) {   // repetition loop: keep the first copy and stop reading
                    val fixed = RepetitionGuard.fix(text.toString())
                    text.setLength(0); text.append(fixed)
                    throw RepetitionGuard.Stop()
                }
            }
            val rs = str(delta, "reasoning_content").ifEmpty { str(delta, "reasoning") }
            if (rs.isNotEmpty()) { reason.append(rs); onThought?.invoke(reason.toString()) }
            val tcs = delta.optJSONArray("tool_calls")
            if (tcs != null) {
                for (i in 0 until tcs.length()) {
                    val tc = tcs.optJSONObject(i) ?: continue
                    val idx = tc.optInt("index", i)
                    val fn = tc.optJSONObject("function") ?: continue
                    val n = str(fn, "name")
                    if (n.isNotEmpty() && (names[idx] ?: "").isEmpty()) names[idx] = n
                    val a = str(fn, "arguments")
                    if (a.isNotEmpty() || args[idx] == null) args.getOrPut(idx) { StringBuilder() }.append(a)
                }
            }
        } } catch (e: RepetitionGuard.Stop) { "" }
        if (!sawEvent && plain.isNotBlank()) return JSONObject(plain)
        val msg = JSONObject().put("content", text.toString())
        if (reason.isNotEmpty()) msg.put("reasoning_content", reason.toString())
        if (names.isNotEmpty() || args.isNotEmpty()) {
            val calls = JSONArray()
            for (i in (names.keys + args.keys).toSortedSet()) {
                calls.put(JSONObject().put("function", JSONObject().put("name", names[i] ?: "").put("arguments", args[i]?.toString() ?: "")))
            }
            msg.put("tool_calls", calls)
        }
        val out = JSONObject().put("choices", JSONArray().put(JSONObject().put("message", msg).put("finish_reason", finish)))
        usage?.let { out.put("usage", it) }
        return out
    }

    private fun mergeUsage(into: JSONObject, from: JSONObject) {
        val ks = from.keys()
        while (ks.hasNext()) {
            val k = ks.next()
            if (!from.isNull(k)) into.put(k, from.get(k))
        }
    }

    private class Blk(val type: String, val name: String) { val sb = StringBuilder() }

    /** Anthropic (messages) stream. Same contract as [openAi]. */
    fun anthropic(r: BufferedReader, onText: (String) -> Unit, onThought: ((String) -> Unit)?): JSONObject {
        val blocks = TreeMap<Int, Blk>()
        val shown = StringBuilder()
        val thought = StringBuilder()
        var stop = ""
        val usage = JSONObject()
        var sawEvent = false
        val plain = events(r) { ev, d ->
            sawEvent = true
            val o = try { JSONObject(d) } catch (e: Exception) { null }
            if (o == null) return@events
            when (str(o, "type").ifEmpty { ev }) {
                "message_start" -> o.optJSONObject("message")?.optJSONObject("usage")?.let { mergeUsage(usage, it) }
                "content_block_start" -> {
                    val cb = o.optJSONObject("content_block")
                    if (cb != null) blocks[o.optInt("index")] = Blk(str(cb, "type"), str(cb, "name"))
                }
                "content_block_delta" -> {
                    val b = blocks[o.optInt("index")]
                    val dl = o.optJSONObject("delta")
                    if (b != null && dl != null) {
                        when (str(dl, "type")) {
                            "text_delta" -> { val t = str(dl, "text"); b.sb.append(t); shown.append(t); onText(shown.toString()) }
                            "thinking_delta" -> { val t = str(dl, "thinking"); b.sb.append(t); thought.append(t); onThought?.invoke(thought.toString()) }
                            "input_json_delta" -> b.sb.append(str(dl, "partial_json"))
                        }
                    }
                }
                "message_delta" -> {
                    val sr = o.optJSONObject("delta")?.let { str(it, "stop_reason") } ?: ""
                    if (sr.isNotEmpty()) stop = sr
                    o.optJSONObject("usage")?.let { mergeUsage(usage, it) }
                }
                "error" -> throw IOException((o.optJSONObject("error")?.let { str(it, "message") } ?: "").ifBlank { "The AI stopped the answer." })
            }
        }
        if (!sawEvent && plain.isNotBlank()) return JSONObject(plain)
        val content = JSONArray()
        for (b in blocks.values) {
            when (b.type) {
                "text" -> content.put(JSONObject().put("type", "text").put("text", b.sb.toString()))
                "thinking" -> content.put(JSONObject().put("type", "thinking").put("thinking", b.sb.toString()))
                "tool_use" -> {
                    val input = try { JSONObject(b.sb.toString().ifBlank { "{}" }) } catch (e: Exception) { JSONObject() }
                    content.put(JSONObject().put("type", "tool_use").put("name", b.name).put("input", input))
                }
            }
        }
        return JSONObject().put("content", content).put("stop_reason", stop).put("usage", usage)
    }
}
