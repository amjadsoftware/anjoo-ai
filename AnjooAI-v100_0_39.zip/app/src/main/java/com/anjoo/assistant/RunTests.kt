package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * JavaScript tests for Code Studio projects (project_check action=test / action=coverage).
 *
 * The online sandbox runs ONE file per run, so the project's source files, its test files and a small
 * Jest/Mocha-style runner (assets/js_test_harness.js) are packed into a single Node.js program and run with
 * [RunCode.runSource]. The runner prints a "RESULT: PASS|FAIL ..." line, the failed tests with the source line
 * they failed at, and real line coverage. The AI then fixes the code and runs the same check again.
 * Only files that a test file imports (directly or through other files) are packed, to stay under the size limit.
 */
object RunTests {
    private val JS_FILE = Regex("\\.(m?js|cjs)$")
    private val JS_TEST_NAME = Regex("(\\.(test|spec)\\.(m?js|cjs)$)|((^|/)test\\.(m?js|cjs)$)")
    private val JS_TEST_DIR = Regex("(^|/)(__tests__|tests?)/")
    private val SPEC = Regex("(?:require\\s*\\(\\s*|from\\s+|import\\s+)['\"]([^'\"]+)['\"]")
    private val RESULT = Regex("RESULT: (PASS|FAIL|NONE) ran=(\\d+) passed=(\\d+) failed=(\\d+) skipped=(\\d+) errors=(\\d+)")

    /** True for a JavaScript test file: name.test.js / name.spec.mjs, or any .js file inside test/, tests/ or __tests__/. */
    fun isJsTest(path: String): Boolean {
        if (path.contains("node_modules/")) return false
        if (!JS_FILE.containsMatchIn(path)) return false
        return JS_TEST_NAME.containsMatchIn(path) || JS_TEST_DIR.containsMatchIn(path)
    }

    fun jsTestFiles(paths: Collection<String>): List<String> = paths.filter { isJsTest(it) }.sorted()

    /** Relative imports of a file: require('./a'), import x from '../b', import './c'. */
    fun specs(src: String): List<String> {
        val out = ArrayList<String>()
        for (m in SPEC.findAll(src)) {
            val s = m.groupValues[1]
            if (s.startsWith("./") || s.startsWith("../")) out.add(s)
        }
        return out
    }

    /** "a/b/../c/./d" -> "a/c/d"; null when the path climbs out of the project. */
    fun normalize(p: String): String? {
        val out = ArrayList<String>()
        for (part in p.split('/')) {
            if (part.isEmpty() || part == ".") continue
            if (part == "..") {
                if (out.isEmpty()) return null
                out.removeAt(out.size - 1)
            } else out.add(part)
        }
        return out.joinToString("/")
    }

    /** The project file that [spec] (written inside [from]) points to, like Node would find it, or null. */
    fun resolve(from: String, spec: String, known: Set<String>): String? {
        val dir = if (from.contains('/')) from.substringBeforeLast('/') else ""
        val joined = normalize(if (dir.isEmpty()) spec else "$dir/$spec") ?: return null
        val tries = listOf(joined, "$joined.js", "$joined.mjs", "$joined.cjs", "$joined.json", "$joined/index.js")
        for (t in tries) if (t in known) return t
        return null
    }

    /** The test files plus every project file they import, directly or through other files. */
    fun reachable(files: Map<String, String>, tests: List<String>): Set<String> {
        val known = files.keys
        val seen = LinkedHashSet<String>()
        val queue = java.util.ArrayDeque<String>()
        for (t in tests) if (seen.add(t)) queue.add(t)
        while (true) {
            val cur = queue.poll() ?: break
            if (cur.endsWith(".json")) continue
            val src = files[cur] ?: continue
            for (s in specs(src)) {
                val r = resolve(cur, s, known) ?: continue
                if (seen.add(r)) queue.add(r)
            }
        }
        return seen
    }

    /** The single Node.js program: harness, then every packed file, then the call that runs the tests. */
    fun bundle(harness: String, files: Map<String, String>, tests: List<String>, coverage: Boolean): String {
        val include = reachable(files, tests)
        val sb = StringBuilder(harness)
        sb.append('\n')
        for (p in include) {
            val src = files[p] ?: continue
            sb.append("__anjooReg(").append(JSONObject.quote(p)).append(", ").append(JSONObject.quote(src)).append(", ")
                .append(if (p in tests) "true" else "false").append(");\n")
        }
        sb.append("__anjooRun(").append(JSONArray(tests).toString()).append(", ").append(if (coverage) "true" else "false").append(");\n")
        return sb.toString()
    }

    /** JavaScript source files that no test imports (so no test can cover them). */
    fun untested(files: Map<String, String>, tests: List<String>): List<String> {
        val used = reachable(files, tests)
        return files.keys.filter { JS_FILE.containsMatchIn(it) && !it.contains("node_modules/") && it !in used }.sorted()
    }

    /** What the AI should do next, added below the raw run report. */
    fun summarize(report: String, untested: List<String>): String {
        val sb = StringBuilder("JS TEST RUN (Node.js on the online sandbox)\n").append(report.trim()).append("\n\n")
        val m = RESULT.find(report)
        if (m == null) {
            val low = report.lowercase()
            when {
                low.contains("declined") -> sb.append("The tests were NOT run (the user declined). Do not claim anything about the tests.")
                low.contains("not run") || low.contains("could not reach") || low.contains("online runner") ->
                    sb.append("The tests were NOT run (server problem above). Do not claim they passed; try again later or tell the user.")
                low.contains("time limit") ->
                    sb.append("The tests did not finish: time limit exceeded, most likely an endless loop or a very slow test. The last LOADING line shows which test file was running. Run only that file (project_check action=test path=<that file>), find the loop in the source and fix it.")
                else ->
                    sb.append("No RESULT line came back, so the tests did not run properly. Read the output above (a syntax error in a test or source file is the usual reason), fix it and run again.")
            }
            return sb.toString().trim()
        }
        val verdict = m.groupValues[1]
        val ran = m.groupValues[2]
        val failed = m.groupValues[4]
        val errors = m.groupValues[6]
        when (verdict) {
            "PASS" -> {
                sb.append("All $ran tests passed in this run. Say so only with this RESULT line as proof.")
                if (report.contains("not run:")) sb.append(" Lines after 'not run:' were never executed by any test; add tests for the ones that matter.")
            }
            "NONE" -> sb.append("The test files loaded and nothing threw, but no describe/it tests were registered. A plain assert script that loads without error has passed. For a proper test list and coverage write tests with describe(...) / it(...) / expect(...) and run again.")
            else -> sb.append("FIX LOOP: $failed test(s) failed and $errors file(s) could not load. Read the FAILED TESTS / FILES THAT COULD NOT LOAD part: it shows the message and the file:line. Open that file with project_read, fix the SOURCE code (change a test only if the test itself is wrong), then run project_check action=test again. Repeat until RESULT: PASS. Do not say the tests pass before that.")
        }
        if (untested.isNotEmpty()) {
            sb.append("\nSource files that no test imports: ").append(untested.take(8).joinToString(", "))
            if (untested.size > 8) sb.append(", ...")
            sb.append(" (no tests, so no coverage for them).")
        }
        return sb.toString().trim()
    }

    /** Message when the project has no JavaScript test file: says what is missing and what can be done instead. */
    fun noTests(paths: Collection<String>): String {
        fun has(f: (String) -> Boolean) = paths.any(f)
        val ts = has { Regex("\\.(test|spec)\\.tsx?$").containsMatchIn(it) }
        val jvm = has { Regex("(^|/)src/test/").containsMatchIn(it) && (it.endsWith(".kt") || it.endsWith(".java")) || Regex("Tests?\\.(kt|java)$").containsMatchIn(it) }
        val other = has { it.endsWith("_test.go") || it.endsWith("_test.rs") || Regex("(^|/)test_.*\\.(rb|php)$").containsMatchIn(it) }
        return when {
            ts -> "TypeScript test files were found, but the online runner cannot run TypeScript tests yet. Write the tests as .js files (tests/name.test.js), or run a single file with run_code."
            jvm -> "Kotlin/Java unit tests (JUnit) cannot run here: the online sandbox has no Gradle or JUnit. Workaround: write a small main() that calls the functions, compares the results and prints PASS or FAIL, then run that file with run_code (all project files of that language are sent together)."
            other -> "Tests in this language cannot run here as a suite (no build tool; all project files of that language are sent together by run_code). Write a small main() that checks the results and prints PASS or FAIL, then run it with run_code."
            else -> "No test file found. For JavaScript create tests/name.test.js (describe / it / expect, require('../src/file')) with project_write; for Python create test_*.py. Then run project_check action=test."
        }
    }

    /** project_check action=test (JavaScript): pack, run on the online sandbox, add the next-step advice. */
    fun run(ctx: Context, confirm: (String) -> Boolean, files: Map<String, String>, a: JSONObject): String {
        var tests = jsTestFiles(files.keys)
        val only = a.optString("path", "").trim()
        if (only.isNotEmpty()) {
            val hit = tests.filter { it == only || it.endsWith("/$only") }
            if (hit.isEmpty()) return "No JavaScript test file matches '$only'. Test files in this project: " + tests.joinToString(", ")
            tests = hit
        }
        if (tests.isEmpty()) return noTests(files.keys)
        val harness = try {
            ctx.assets.open("js_test_harness.js").bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            return "The test runner file (js_test_harness.js) is missing from the app, so JavaScript tests cannot run."
        }
        val coverage = a.optBoolean("coverage", true)
        val code = bundle(harness, files, tests, coverage)
        val report = RunCode.runSource(ctx, confirm, "javascript", code, "")
        return summarize(report, untested(files, tests))
    }
}
