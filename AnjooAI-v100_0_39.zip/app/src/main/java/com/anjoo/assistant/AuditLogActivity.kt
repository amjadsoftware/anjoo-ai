package com.anjoo.assistant

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Security & Audit: the audit log (see AdminAudit) with category filters and a rule-based check for unusual activity. */
class AuditLogActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private lateinit var theme: CyberTheme
    private lateinit var content: LinearLayout
    private val bad = Color.rgb(198, 40, 40)
    private val good = Color.rgb(46, 125, 50)
    private var filter = ""      // "" = all
    private var shown = 50

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun faint() = Color.argb(70, 128, 128, 128)
    private fun shape(fill: Int, stroke: Int = faint(), radius: Int = 14) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(radius).toFloat()
    }
    private fun label(text: String, size: Float = 14f, color: Int = theme.ink, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        theme = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        Style.bars(window, theme)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(theme.bg)
            setPadding(dp(14), dp(28), dp(14), dp(10))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("‹", 30f).apply { setPadding(dp(6), 0, dp(18), dp(4)); setOnClickListener { finish() } })
        header.addView(label("Security & Audit", 20f, theme.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("↻", 24f, theme.accent).apply { setPadding(dp(14), 0, dp(6), dp(2)); setOnClickListener { render() } })
        root.addView(header)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        setContentView(root)
        render()
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) render() }

    private fun render() {
        content.removeAllViews()
        val now = System.currentTimeMillis()
        val all = AdminAudit.entries(this)
        val flags = AdminAudit.suspicious(all, now)

        val status = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(theme.surface); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        if (flags.isEmpty()) status.addView(label("Nothing unusual in the last 10 minutes.", 13.5f, good, true))
        else {
            status.addView(label("Needs attention", 14f, bad, true))
            for (f in flags) status.addView(label("• $f", 12.5f, bad).apply { setPadding(0, dp(4), 0, 0) })
        }
        val day = all.filter { now - it.at <= 24 * 3600_000L }
        status.addView(label("Last 24 hours: ${day.count { it.category == "security" }} security, ${day.count { it.category == "agent" }} agent, ${day.count { it.category == "admin" }} admin, ${day.count { it.category == "system" }} system events.", 12f, theme.muted).apply { setPadding(0, dp(6), 0, 0) })
        status.addView(label("The log is append-only: it cannot be edited or cleared inside the app, and keeps the newest ${AdminAudit.MAX} events. It never stores prompts, keys, passcodes or tool output.", 11.5f, theme.muted).apply { setPadding(0, dp(6), 0, 0) })
        content.addView(status, LinearLayout.LayoutParams(-1, -2))

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((key, name) in listOf("" to "All", "security" to "Security", "agent" to "Agent", "admin" to "Admin", "system" to "System")) {
            val on = filter == key
            chips.addView(label(name, 12.5f, if (on) theme.bg else theme.ink, true).apply {
                background = shape(if (on) theme.accent else Color.TRANSPARENT, if (on) theme.accent else faint(), 16)
                setPadding(dp(11), dp(6), dp(11), dp(6))
                setOnClickListener { filter = key; shown = 50; render() }
            }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        }
        content.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val list = if (filter.isEmpty()) all else all.filter { it.category == filter }
        if (list.isEmpty()) {
            content.addView(label(if (all.isEmpty()) "No events yet. Events appear here when something security-related or agent-related really happens, for example a wrong export passcode or a tool paused after repeated failures." else "No events in this category.", 13f, theme.muted).apply { setPadding(dp(4), dp(18), dp(4), dp(8)) })
            return
        }
        val fmt = SimpleDateFormat("d MMM, HH:mm:ss", Locale.getDefault())
        for (e in list.take(shown)) {
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(theme.surface); setPadding(dp(14), dp(10), dp(14), dp(10)) }
            card.addView(label(e.action, 13.5f, theme.ink, true))
            if (e.detail.isNotBlank()) card.addView(label(e.detail, 12.5f, theme.muted).apply { setPadding(0, dp(2), 0, 0) })
            card.addView(label(fmt.format(Date(e.at)) + "  ·  " + e.category, 11.5f, theme.muted).apply { setPadding(0, dp(3), 0, 0) })
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        if (list.size > shown) {
            content.addView(label("Show more (${list.size - shown} older)", 13f, theme.accent, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(14), 0, dp(14)); setOnClickListener { shown += 50; render() }
            }, LinearLayout.LayoutParams(-1, -2))
        }
    }
}
