package com.anjoo.assistant

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.TreeMap
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * project_deps: real dependency management for a Code Studio project. A phone has no npm or pip, so this talks to the
 * public registries directly and edits the manifest files (package.json, requirements.txt):
 *
 *  list ........ what the manifests declare, plus imports in the code that no manifest declares
 *  info ........ latest version, license, deprecation and (pip) wheel type of one package
 *  add / remove  put a package into (or take it out of) the manifest at its latest or a chosen version
 *  outdated .... declared version vs latest (patch / minor / MAJOR)
 *  update ...... bump manifest entries (major bumps only when asked)
 *  audit ....... known vulnerabilities (OSV.dev database: GitHub advisories, PyPA, CVE) for every declared version
 *  vendor ...... web projects: download an npm package's browser file from jsDelivr into vendor/ and give the tag
 *
 * Python projects: requirements.txt is also installed at run time (run_python / project_check) through micropip, see PyRun.
 * Limits: no lock file and no dependency-tree resolution (the manifest version is taken as the installed version);
 * only npm and pip; Node projects are not installed on the phone (run_code has no npm).
 */
object Deps {

    private const val CAP = 7000
    private const val MAX_PARALLEL = 6
    private const val MAX_DEPS = 60
    private const val MAX_VENDOR = 3L * 1024 * 1024
    private val JSON = "application/json".toMediaType()
    private val SKIP_DIRS = setOf("node_modules", ".git", "__pycache__", "build", ".gradle", "venv", ".venv", "vendor")

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS).build()
    }

    class Dep(val eco: String, val name: String, val spec: String, val dev: Boolean, val manifest: String)
    class Manifest(val path: String, val eco: String)
    class Latest(val version: String, val summary: String, val license: String, val deprecated: String?, val pure: Boolean?)

    // ============================================================ pure helpers (unit tested)

    fun normEco(s: String): String = when (s.trim().lowercase()) {
        "npm", "node", "nodejs", "js", "javascript", "yarn", "pnpm" -> "npm"
        "pip", "pypi", "python", "py" -> "pip"
        else -> ""
    }

    fun osvEco(eco: String) = if (eco == "pip") "PyPI" else "npm"

    fun pipKey(name: String): String = name.lowercase().replace(Regex("[-_.]+"), "-")

    fun validName(eco: String, name: String): Boolean =
        if (eco == "npm") Regex("^(@[a-z0-9~._-]+/)?[a-z0-9~._-]+$").matches(name) && name.length <= 214
        else Regex("^[A-Za-z0-9][A-Za-z0-9._-]*$").matches(name) && name.length <= 100

    fun parseNpm(text: String, path: String = "package.json"): List<Dep> {
        val root = try { JSONObject(text) } catch (_: Exception) { return emptyList() }
        val out = ArrayList<Dep>()
        for (section in listOf("dependencies", "devDependencies", "optionalDependencies")) {
            val o = root.optJSONObject(section) ?: continue
            val keys = o.keys().asSequence().toList().sorted()
            for (k in keys) out.add(Dep("npm", k, o.optString(k), section == "devDependencies", path))
        }
        return out
    }

    private val PIP_LINE = Regex("^([A-Za-z0-9][A-Za-z0-9._-]*)\\s*(?:\\[[^\\]]*\\])?\\s*(.*)$")

    /** One requirements.txt line to (name, spec); null for comments, options (-r, -e, --index-url) and URLs. */
    fun parsePipLine(raw: String): Pair<String, String>? {
        val line = raw.substringBefore('#').substringBefore(';').trim()
        if (line.isEmpty() || line.startsWith("-") || line.contains("://") || line.startsWith("git+")) return null
        val m = PIP_LINE.find(line) ?: return null
        return Pair(m.groupValues[1], m.groupValues[2].replace(" ", ""))
    }

    fun parsePip(text: String, path: String = "requirements.txt"): List<Dep> =
        text.lines().mapNotNull { l -> parsePipLine(l)?.let { Dep("pip", it.first, it.second, false, path) } }

    /** The version a spec points at: first number in "^1.2.3", "~=2.31", ">=2.0,<3", "==1.0". null for "*", "latest", urls. */
    fun baseVersion(spec: String): String? {
        val s = spec.trim()
        if (s.isEmpty() || s.contains("://") || s.startsWith("git") || s.startsWith("file:") || s.startsWith("workspace:")) return null
        return Regex("\\d+(?:\\.\\d+){0,3}").find(s)?.value
    }

    private fun nums(v: String): List<Long> =
        Regex("\\d+").findAll(v.substringBefore('-').substringBefore('+')).mapNotNull { it.value.toLongOrNull() }.toList()

    fun compareVersions(a: String, b: String): Int {
        val x = nums(a); val y = nums(b)
        for (i in 0 until maxOf(x.size, y.size)) {
            val c = (x.getOrElse(i) { 0L }).compareTo(y.getOrElse(i) { 0L })
            if (c != 0) return c
        }
        return 0
    }

    /** "major" | "minor" | "patch" | "none" for moving from [cur] to [latest] (0.x minor bumps count as major). */
    fun bump(cur: String, latest: String): String {
        if (compareVersions(latest, cur) <= 0) return "none"
        val x = nums(cur); val y = nums(latest)
        val a = x.getOrElse(0) { 0L }; val b = y.getOrElse(0) { 0L }
        if (a != b) return "major"
        if (a == 0L && x.getOrElse(1) { 0L } != y.getOrElse(1) { 0L }) return "major"
        if (x.getOrElse(1) { 0L } != y.getOrElse(1) { 0L }) return "minor"
        return "patch"
    }

    /** The manifest spec after moving to [latest], keeping the style the project used. null = leave it (open range). */
    fun newSpec(eco: String, old: String, latest: String): String? {
        val s = old.trim()
        if (eco == "npm") {
            return when {
                s.startsWith("^") -> "^$latest"
                s.startsWith("~") -> "~$latest"
                Regex("^\\d").containsMatchIn(s) -> latest
                s.isEmpty() || s == "*" || s == "latest" -> null
                else -> "^$latest"
            }
        }
        return when {
            s.startsWith("==") -> "==$latest"
            s.startsWith("~=") -> "~=$latest"
            s.startsWith(">=") && !s.contains(',') -> ">=$latest"
            s.isEmpty() -> null
            else -> null
        }
    }

    /** Turns a user version into a pip specifier: "2.31.0" -> "==2.31.0", ">=2" stays. */
    fun pipSpec(v: String): String {
        val s = v.trim().replace(" ", "")
        return if (s.isEmpty()) "" else if (Regex("^\\d").containsMatchIn(s)) "==$s" else s
    }

    /** package.json text with [name] set (dependencies / devDependencies sorted like npm does). null = invalid JSON. */
    fun setNpm(text: String, name: String, spec: String, dev: Boolean): String? {
        val root = try { JSONObject(if (text.isBlank()) "{}" else text) } catch (_: Exception) { return null }
        val section = if (dev) "devDependencies" else "dependencies"
        val other = if (dev) "dependencies" else "devDependencies"
        root.optJSONObject(other)?.let { if (it.has(name)) it.remove(name) }
        val cur = root.optJSONObject(section) ?: JSONObject()
        val sorted = TreeMap<String, String>()
        for (k in cur.keys()) sorted[k] = cur.optString(k)
        sorted[name] = spec
        val fresh = JSONObject()
        for ((k, v) in sorted) fresh.put(k, v)
        root.put(section, fresh)
        return root.toString(2) + "\n"
    }

    /** package.json text without [name]; Pair(newText, removed). */
    fun removeNpm(text: String, name: String): Pair<String, Boolean>? {
        val root = try { JSONObject(text) } catch (_: Exception) { return null }
        var hit = false
        for (section in listOf("dependencies", "devDependencies", "optionalDependencies")) {
            val o = root.optJSONObject(section) ?: continue
            if (o.has(name)) { o.remove(name); hit = true }
        }
        return Pair(root.toString(2) + "\n", hit)
    }

    /** requirements.txt text with the package set to name+spec (replaces its line, else appends). */
    fun setPip(text: String, name: String, spec: String): String {
        val key = pipKey(name)
        val out = ArrayList<String>()
        var done = false
        for (l in text.lines()) {
            val p = parsePipLine(l)
            if (p != null && pipKey(p.first) == key) { if (!done) { out.add(name + spec); done = true } }
            else out.add(l)
        }
        if (!done) {
            while (out.isNotEmpty() && out.last().isBlank()) out.removeAt(out.size - 1)
            out.add(name + spec)
        }
        return out.joinToString("\n").trimEnd('\n') + "\n"
    }

    fun removePip(text: String, name: String): Pair<String, Boolean> {
        val key = pipKey(name)
        var hit = false
        val out = text.lines().filter { l ->
            val p = parsePipLine(l)
            val match = p != null && pipKey(p.first) == key
            if (match) hit = true
            !match
        }
        return Pair(out.joinToString("\n").trimEnd('\n') + (if (out.any { it.isNotBlank() }) "\n" else ""), hit)
    }

    /** Requirement strings micropip can install (used by PyRun): requirements.txt entries without options or URLs. */
    fun pipRequirements(files: Map<String, String>): List<String> {
        val text = files["requirements.txt"] ?: return emptyList()
        return text.lines().mapNotNull { l -> parsePipLine(l)?.let { it.first + it.second } }.distinct().take(25)
    }

    /** Lowest "fixed" version above [base] that an OSV advisory lists for this package; null when none is listed. */
    fun fixedVersion(vuln: JSONObject, eco: String, name: String, base: String): String? {
        val affected = vuln.optJSONArray("affected") ?: return null
        val fixes = ArrayList<String>()
        for (i in 0 until affected.length()) {
            val af = affected.optJSONObject(i) ?: continue
            val pkg = af.optJSONObject("package") ?: continue
            if (pkg.optString("ecosystem") != osvEco(eco)) continue
            val same = if (eco == "pip") pipKey(pkg.optString("name")) == pipKey(name) else pkg.optString("name") == name
            if (!same) continue
            val ranges = af.optJSONArray("ranges") ?: continue
            for (r in 0 until ranges.length()) {
                val evs = ranges.optJSONObject(r)?.optJSONArray("events") ?: continue
                for (e in 0 until evs.length()) {
                    val f = evs.optJSONObject(e)?.optString("fixed").orEmpty()
                    if (f.isNotEmpty() && compareVersions(f, base) > 0) fixes.add(f)
                }
            }
        }
        return fixes.sortedWith(Comparator { x, y -> compareVersions(x, y) }).firstOrNull()
    }

    fun severityOf(vuln: JSONObject): String {
        val s = vuln.optJSONObject("database_specific")?.optString("severity").orEmpty()
        return if (s.isBlank()) "unknown" else s.lowercase()
    }

    private val NODE_BUILTIN = setOf("fs", "path", "os", "http", "https", "url", "util", "events", "stream", "crypto", "child_process", "assert",
        "buffer", "cluster", "dns", "net", "readline", "tls", "zlib", "querystring", "string_decoder", "timers", "vm", "worker_threads", "process", "module", "perf_hooks", "http2", "tty", "dgram")

    private val PY_STDLIB = setOf("abc", "argparse", "array", "ast", "asyncio", "base64", "bisect", "builtins", "calendar", "collections", "colorsys", "contextlib",
        "copy", "csv", "ctypes", "dataclasses", "datetime", "decimal", "difflib", "email", "enum", "errno", "fnmatch", "fractions", "functools", "gc", "getpass", "glob",
        "gzip", "hashlib", "heapq", "hmac", "html", "http", "importlib", "inspect", "io", "itertools", "json", "keyword", "logging", "math", "mimetypes", "multiprocessing",
        "numbers", "operator", "os", "pathlib", "pickle", "platform", "pprint", "queue", "random", "re", "secrets", "select", "shelve", "shlex", "shutil", "signal", "socket",
        "sqlite3", "ssl", "statistics", "string", "struct", "subprocess", "sys", "tempfile", "textwrap", "threading", "time", "timeit", "tkinter", "traceback", "types",
        "typing", "unicodedata", "unittest", "urllib", "uuid", "warnings", "weakref", "webbrowser", "xml", "zipfile", "zlib", "zoneinfo", "__future__", "turtle", "curses", "cmd", "code", "codecs", "locale", "sched", "stat", "sysconfig", "tarfile", "token", "tokenize", "wave", "winreg")

    private val PY_IMPORT_TO_PKG = mapOf("cv2" to "opencv-python", "PIL" to "pillow", "yaml" to "pyyaml", "bs4" to "beautifulsoup4", "sklearn" to "scikit-learn",
        "dotenv" to "python-dotenv", "dateutil" to "python-dateutil", "jwt" to "pyjwt", "serial" to "pyserial", "telebot" to "pytelegrambotapi", "Crypto" to "pycryptodome")

    /** Packages the source imports that no manifest declares (JS bare imports, Python third-party imports). */
    fun undeclared(files: Map<String, String>, declared: List<Dep>): List<String> {
        val npmDeclared = declared.filter { it.eco == "npm" }.map { it.name }.toSet()
        val pipDeclared = declared.filter { it.eco == "pip" }.map { pipKey(it.name) }.toSet()
        val local = files.keys.map { it.substringBefore('/').substringBeforeLast('.') }.toSet()
        val out = java.util.TreeSet<String>()
        for ((p, c) in files) {
            val ext = p.substringAfterLast('.', "").lowercase()
            if (ext in setOf("js", "mjs", "cjs", "jsx", "ts", "tsx")) {
                for (m in Regex("(?:from\\s+|require\\(\\s*|import\\s+)[\"']([^\"'./][^\"']*)[\"']").findAll(c)) {
                    val spec = m.groupValues[1]
                    if (spec.contains("://") || spec.startsWith("node:")) continue
                    val pkg = if (spec.startsWith("@")) spec.split('/').take(2).joinToString("/") else spec.substringBefore('/')
                    if (pkg in NODE_BUILTIN || pkg in npmDeclared || pkg in local) continue
                    out.add("npm: $pkg")
                }
            } else if (ext == "py") {
                for (m in Regex("(?m)^\\s*(?:from|import)\\s+([A-Za-z_]\\w*)").findAll(c)) {
                    val mod = m.groupValues[1]
                    if (mod in PY_STDLIB || mod in local) continue
                    val pkg = PY_IMPORT_TO_PKG[mod] ?: mod
                    if (pipKey(pkg) in pipDeclared || pipKey(mod) in pipDeclared) continue
                    out.add("pip: $pkg" + (if (pkg != mod) "  (import $mod)" else ""))
                }
            }
        }
        return out.toList()
    }

    private fun cap(s: String, n: Int = CAP) = if (s.length <= n) s else s.take(n * 2 / 3) + "\n...[middle trimmed]...\n" + s.takeLast(n / 3)

    private fun safeRel(p: String): String? {
        val parts = p.replace('\\', '/').split('/').map { it.trim() }.filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty() || parts.any { it == ".." } || parts.size > 6 || parts.last().startsWith(".anjoo")) return null
        return parts.joinToString("/")
    }

    // ============================================================ network

    private class Res(val code: Int, val body: String)

    private fun get(url: String): Res {
        Cancel.check()
        val req = Request.Builder().url(url).header("Accept", "application/json").header("User-Agent", "AnjooAI-CodeStudio").build()
        return http.newCall(req).execute().use { Res(it.code, it.body?.string().orEmpty()) }
    }

    private fun post(url: String, body: JSONObject): Res {
        Cancel.check()
        val req = Request.Builder().url(url).header("User-Agent", "AnjooAI-CodeStudio").post(body.toString().toRequestBody(JSON)).build()
        return http.newCall(req).execute().use { Res(it.code, it.body?.string().orEmpty()) }
    }

    private fun jsonOrNull(r: Res): JSONObject? = try { JSONObject(r.body) } catch (_: Exception) { null }

    /** Latest (or the given exact) version of a package. null = no such package/version. Throws IOException when offline. */
    private fun fetchLatest(eco: String, name: String, version: String? = null): Latest? {
        if (eco == "npm") {
            val enc = name.replace("/", "%2F")
            val r = get("https://registry.npmjs.org/$enc/" + (version ?: "latest"))
            if (r.code == 404) return null
            if (r.code != 200) throw java.io.IOException("npm registry answered ${r.code}")
            val j = jsonOrNull(r) ?: return null
            val dep = j.optString("deprecated").ifBlank { null }
            val lic = j.opt("license")
            val license = if (lic is JSONObject) lic.optString("type") else (lic?.toString() ?: "")
            return Latest(j.optString("version"), j.optString("description").take(140), license.ifBlank { "unknown" }, dep, null)
        }
        val r = get("https://pypi.org/pypi/$name/" + (if (version != null) "$version/" else "") + "json")
        if (r.code == 404) return null
        if (r.code != 200) throw java.io.IOException("PyPI answered ${r.code}")
        val j = jsonOrNull(r) ?: return null
        val info = j.optJSONObject("info") ?: return null
        val urls = j.optJSONArray("urls")
        var pure: Boolean? = null
        if (urls != null && urls.length() > 0) {
            pure = false
            for (i in 0 until urls.length()) if (urls.optJSONObject(i)?.optString("filename").orEmpty().endsWith("none-any.whl")) pure = true
        }
        val yanked = if (info.optBoolean("yanked", false)) "yanked: " + info.optString("yanked_reason") else null
        val license = info.optString("license").lines().firstOrNull().orEmpty().take(60).ifBlank { "see PyPI" }
        return Latest(info.optString("version"), info.optString("summary").take(140), license, yanked, pure)
    }

    private fun lookupAll(eco: String, names: List<String>): Map<String, Latest?> {
        val pool = Executors.newFixedThreadPool(MAX_PARALLEL)
        try {
            val futures = names.map { n -> n to pool.submit(Callable { try { fetchLatest(eco, n) } catch (e: java.io.IOException) { null } }) }
            val out = LinkedHashMap<String, Latest?>()
            for ((n, f) in futures) out[n] = try { f.get(60, TimeUnit.SECONDS) } catch (e: Exception) { null }
            return out
        } finally { pool.shutdownNow() }
    }

    /** OSV.dev: vulnerability ids per dependency (index-aligned with [deps]). */
    private fun osvQuery(deps: List<Pair<Dep, String>>): List<List<String>> {
        val out = ArrayList<List<String>>()
        for (chunk in deps.chunked(100)) {
            val qs = JSONArray()
            for ((d, v) in chunk) qs.put(JSONObject().put("package", JSONObject().put("name", d.name).put("ecosystem", osvEco(d.eco))).put("version", v))
            val r = post("https://api.osv.dev/v1/querybatch", JSONObject().put("queries", qs))
            if (r.code != 200) throw java.io.IOException("OSV.dev answered ${r.code}")
            val results = jsonOrNull(r)?.optJSONArray("results") ?: JSONArray()
            for (i in 0 until chunk.size) {
                val vs = results.optJSONObject(i)?.optJSONArray("vulns")
                val ids = ArrayList<String>()
                if (vs != null) for (k in 0 until vs.length()) vs.optJSONObject(k)?.optString("id")?.takeIf { it.isNotEmpty() }?.let { ids.add(it) }
                out.add(ids)
            }
        }
        return out
    }

    // ============================================================ project access

    private fun manifests(dir: File): List<Manifest> {
        val out = ArrayList<Manifest>()
        dir.walkTopDown().onEnter { it == dir || it.name !in SKIP_DIRS }.maxDepth(4).forEach { f ->
            if (!f.isFile) return@forEach
            val rel = f.relativeTo(dir).path.replace('\\', '/')
            when (f.name) {
                "package.json" -> out.add(Manifest(rel, "npm"))
                "requirements.txt" -> out.add(Manifest(rel, "pip"))
            }
        }
        return out.sortedWith(compareBy({ it.path.count { c -> c == '/' } }, { it.path }))
    }

    private fun readDeps(dir: File, ms: List<Manifest>): List<Dep> {
        val out = ArrayList<Dep>()
        for (m in ms) {
            val text = try { File(dir, m.path).readText(Charsets.UTF_8) } catch (_: Exception) { continue }
            out.addAll(if (m.eco == "npm") parseNpm(text, m.path) else parsePip(text, m.path))
        }
        return out
    }

    private fun touch(ctx: Context, dir: File) {
        dir.setLastModified(System.currentTimeMillis())
        Coder.keepCopy(ctx, dir)
        try { Coder.onChanged?.invoke(dir) } catch (_: Exception) {}
    }

    private fun projectFiles(dir: File): Map<String, String> = try { Coder.readFiles(dir) } catch (_: Exception) { emptyMap() }

    // ============================================================ entry

    fun run(ctx: Context, a: JSONObject, find: () -> Pair<File?, String>): String {
        val action = a.optString("action", "list").trim().lowercase().replace('-', '_').replace(' ', '_')
        return try {
            if (action in setOf("info", "lookup", "latest", "show_package")) return info(a)
            val (dir, err) = find()
            if (dir == null) return err
            when (action) {
                "list", "show", "deps", "inventory" -> list(dir)
                "add", "install" -> add(ctx, dir, a)
                "remove", "uninstall" -> remove(ctx, dir, a)
                "outdated", "check_updates", "versions" -> outdated(dir)
                "update", "upgrade" -> update(ctx, dir, a)
                "audit", "vulnerabilities", "security", "cve" -> audit(dir)
                "vendor", "download", "cdn" -> vendor(ctx, dir, a)
                else -> "project_deps action chunein: list, info, add, remove, outdated, update, audit, vendor."
            }
        } catch (e: CancelledException) { throw e
        } catch (e: java.io.IOException) { "Dependencies nakam: network problem (" + (e.message ?: "io") + "). Check the internet and try again."
        } catch (e: IllegalStateException) { "Dependencies nakam: " + (e.message ?: "error")
        }
    }

    private fun names(a: JSONObject): List<String> =
        (a.optString("name").ifBlank { a.optString("packages") }).split(',', ' ', '\n').map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    private fun ecoFor(dir: File?, a: JSONObject): String {
        val given = normEco(a.optString("ecosystem").ifBlank { a.optString("manager").ifBlank { a.optString("eco") } })
        if (given.isNotEmpty()) return given
        if (dir != null) {
            val ecos = manifests(dir).map { it.eco }.distinct()
            if (ecos.size == 1) return ecos[0]
            if (ecos.isEmpty()) {
                val files = projectFiles(dir).keys
                val py = files.any { it.endsWith(".py") }
                val js = files.any { it.endsWith(".js") || it.endsWith(".ts") || it.endsWith(".mjs") }
                if (py && !js) return "pip"
                if (js && !py) return "npm"
            }
        }
        return ""
    }

    private const val NEED_ECO = "Give ecosystem=npm or ecosystem=pip (the project does not make it clear which one)."

    private fun list(dir: File): String {
        val ms = manifests(dir)
        val deps = readDeps(dir, ms)
        val sb = StringBuilder()
        if (ms.isEmpty()) sb.append("No package.json or requirements.txt in this project yet (project_deps action=add creates one).\n")
        for (m in ms) {
            val mine = deps.filter { it.manifest == m.path }
            sb.append(m.path).append(" (").append(m.eco).append("): ").append(mine.size).append(" packages\n")
            for (d in mine) sb.append("  ").append(d.name).append(' ').append(d.spec.ifEmpty { "(any version)" }).append(if (d.dev) "  [dev]" else "").append('\n')
        }
        val miss = undeclared(projectFiles(dir), deps)
        if (miss.isNotEmpty()) sb.append("\nUsed in code but not declared in a manifest:\n").append(miss.take(40).joinToString("\n") { "  $it" })
            .append("\n(add them with project_deps action=add; Node built-ins and the standard library are already left out)")
        val cdn = projectFiles(dir).filterKeys { it.endsWith(".html") }.values.flatMap { h ->
            Regex("(?:src|href)\\s*=\\s*[\"'](https?://[^\"']+)[\"']").findAll(h).map { it.groupValues[1].take(100) }.toList()
        }.distinct()
        if (cdn.isNotEmpty()) sb.append("\n\nExternal web files (CDN): ").append(cdn.size).append('\n').append(cdn.take(15).joinToString("\n") { "  $it" })
        return cap(sb.toString().trim())
    }

    private fun info(a: JSONObject): String {
        val eco = normEco(a.optString("ecosystem").ifBlank { a.optString("manager") })
        val ns = names(a)
        if (ns.isEmpty()) return "Give a package name."
        val e = if (eco.isEmpty()) "npm" else eco
        val sb = StringBuilder()
        for (n in ns.take(8)) {
            if (!validName(e, n)) { sb.append("$n: not a valid $e package name\n"); continue }
            val l = fetchLatest(e, n, a.optString("version").ifBlank { null })
            if (l == null) { sb.append("$n: not found on ").append(if (e == "npm") "npm" else "PyPI").append('\n'); continue }
            sb.append(n).append(' ').append(l.version).append("  license: ").append(l.license).append('\n')
            if (l.summary.isNotBlank()) sb.append("  ").append(l.summary).append('\n')
            if (l.deprecated != null) sb.append("  WARNING ").append(l.deprecated.take(200)).append('\n')
            if (l.pure != null) sb.append(if (l.pure) "  pure-Python wheel: installs in the phone's Python runtime (run_python)\n" else "  has compiled code only: it will NOT install in run_python unless Pyodide ships it (numpy, pandas, scipy, matplotlib, pillow, scikit-learn, pyyaml, lxml do)\n")
        }
        return sb.toString().trim()
    }

    private fun target(dir: File, eco: String, a: JSONObject): Pair<String, Boolean> {
        val given = a.optString("manifest").trim()
        if (given.isNotEmpty()) safeRel(given)?.let { return Pair(it, File(dir, it).exists()) }
        val m = manifests(dir).firstOrNull { it.eco == eco }
        if (m != null) return Pair(m.path, true)
        return Pair(if (eco == "npm") "package.json" else "requirements.txt", false)
    }

    private fun add(ctx: Context, dir: File, a: JSONObject): String {
        val eco = ecoFor(dir, a)
        if (eco.isEmpty()) return NEED_ECO
        val ns = names(a)
        if (ns.isEmpty()) return "Give name (one package) or packages (comma separated)."
        val wantVer = a.optString("version").trim()
        if (wantVer.isNotEmpty() && ns.size > 1) return "version works with one package at a time."
        val dev = a.optBoolean("dev", false)
        val (path, exists) = target(dir, eco, a)
        val f = File(dir, path)
        var text = if (exists) f.readText(Charsets.UTF_8) else ""
        if (eco == "npm" && text.isBlank()) text = JSONObject().put("name", Coder.name(dir).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "app" }).put("version", "1.0.0").put("private", true).toString(2)
        val sb = StringBuilder()
        val added = ArrayList<Pair<Dep, String>>()
        var changed = false
        for (n in ns) {
            if (!validName(eco, n)) { sb.append("- $n: not a valid $eco package name\n"); continue }
            val exact = if (eco == "npm") Regex("^\\d+(\\.\\d+){0,2}([-+][\\w.]+)?$").matches(wantVer) else Regex("^\\d[\\w.]*$").matches(wantVer)
            val l = fetchLatest(eco, n, if (exact) wantVer else null)
            if (l == null) { sb.append("- $n").append(if (exact) "@$wantVer" else "").append(": not found on the registry (check the spelling/version)\n"); continue }
            val spec = when {
                eco == "npm" && wantVer.isNotEmpty() -> wantVer
                eco == "npm" -> "^" + l.version
                wantVer.isNotEmpty() -> pipSpec(wantVer)
                else -> "==" + l.version
            }
            val updated = if (eco == "npm") setNpm(text, n, spec, dev) ?: return "$path is not valid JSON; fix it first (project_read / project_edit)."
                else setPip(text, n, spec)
            text = updated; changed = true
            sb.append("- $n $spec added to $path").append(if (dev) " (dev)" else "").append('\n')
            if (l.deprecated != null) sb.append("  WARNING deprecated/yanked: ").append(l.deprecated.take(160)).append('\n')
            if (eco == "pip" && l.pure == false) sb.append("  NOTE: compiled package; run_python only runs it when Pyodide ships it. The code is still fine for a real computer.\n")
            baseVersion(spec)?.let { added.add(Pair(Dep(eco, n, spec, dev, path), it)) }
        }
        if (!changed) return sb.toString().trim().ifEmpty { "Nothing added." }
        Coder.snapshot(ctx, dir)
        f.parentFile?.mkdirs()
        f.writeText(text, Charsets.UTF_8)
        touch(ctx, dir)
        if (added.isNotEmpty()) {
            try {
                val ids = osvQuery(added)
                for (i in added.indices) if (ids[i].isNotEmpty())
                    sb.append("  SECURITY ").append(added[i].first.name).append(' ').append(added[i].second).append(" has ").append(ids[i].size)
                        .append(" known vulnerabilities (").append(ids[i].take(3).joinToString(", ")).append("). Run project_deps action=audit for details and the fixed version.\n")
            } catch (_: java.io.IOException) { sb.append("  (security check skipped: OSV.dev not reachable)\n") }
        }
        sb.append(if (eco == "pip") "requirements.txt is installed automatically when the project runs (run_python / project_check).\n"
            else "For a web page (no npm on the phone) use project_deps action=vendor name=<package> to put the browser file into vendor/ and get the script tag.\n")
        sb.append("(undo: project_history action=undo)")
        return sb.toString().trim()
    }

    private fun remove(ctx: Context, dir: File, a: JSONObject): String {
        val ns = names(a)
        if (ns.isEmpty()) return "Give name (or packages)."
        val ms = manifests(dir).let { all -> val eco = normEco(a.optString("ecosystem")); if (eco.isEmpty()) all else all.filter { it.eco == eco } }
        if (ms.isEmpty()) return "No manifest found."
        Coder.snapshot(ctx, dir)
        val sb = StringBuilder()
        var any = false
        for (n in ns) {
            var hit = false
            for (m in ms) {
                val f = File(dir, m.path)
                val text = try { f.readText(Charsets.UTF_8) } catch (_: Exception) { continue }
                if (m.eco == "npm") {
                    val r = removeNpm(text, n) ?: continue
                    if (r.second) { f.writeText(r.first, Charsets.UTF_8); hit = true; sb.append("- $n removed from ${m.path}\n") }
                } else {
                    val r = removePip(text, n)
                    if (r.second) { f.writeText(r.first, Charsets.UTF_8); hit = true; sb.append("- $n removed from ${m.path}\n") }
                }
            }
            if (!hit) sb.append("- $n: not declared in any manifest\n") else any = true
        }
        if (any) touch(ctx, dir)
        return sb.toString().trim() + (if (any) "\n(undo: project_history action=undo; code that still imports it needs a manual fix)" else "")
    }

    private fun outdated(dir: File): String {
        val deps = readDeps(dir, manifests(dir)).filter { baseVersion(it.spec) != null }
        if (deps.isEmpty()) return "No versioned dependency in a manifest. Use project_deps action=list or add."
        val shown = deps.take(MAX_DEPS)
        val latest = HashMap<String, Latest?>()
        for (eco in listOf("npm", "pip")) latest.putAll(lookupAll(eco, shown.filter { it.eco == eco }.map { it.name }.distinct()).mapKeys { eco + ":" + it.key })
        val rows = ArrayList<String>()
        var old = 0; var major = 0; var unknown = 0
        for (d in shown) {
            val l = latest[d.eco + ":" + d.name]
            if (l == null) { unknown++; rows.add("? ${d.name} ${d.spec}: could not look up"); continue }
            val cur = baseVersion(d.spec) ?: continue
            val b = bump(cur, l.version)
            if (b == "none") continue
            old++; if (b == "major") major++
            rows.add((if (b == "major") "MAJOR " else if (b == "minor") "minor " else "patch ") + d.name + "  " + d.spec + " -> " + l.version + (if (l.deprecated != null) "  (deprecated)" else ""))
        }
        val head = "Checked ${shown.size} packages" + (if (deps.size > shown.size) " of ${deps.size}" else "") + ": $old outdated ($major major)" + (if (unknown > 0) ", $unknown not looked up" else "") + "."
        if (rows.isEmpty()) return "$head Everything is at the latest version."
        return cap(head + "\n" + rows.sortedBy { if (it.startsWith("MAJOR")) 0 else if (it.startsWith("minor")) 1 else 2 }.joinToString("\n") +
            "\nUpdate with project_deps action=update (name=a,b to pick; major=true to allow major jumps). Major versions can break code: test after updating.")
    }

    private fun update(ctx: Context, dir: File, a: JSONObject): String {
        val ms = manifests(dir)
        val picked = names(a).map { it.lowercase() }
        val allowMajor = a.optBoolean("major", false)
        val deps = readDeps(dir, ms).filter { (picked.isEmpty() || it.name.lowercase() in picked || pipKey(it.name) in picked.map { p -> pipKey(p) }) && baseVersion(it.spec) != null }
        if (deps.isEmpty()) return "No matching versioned dependency."
        val shown = deps.take(MAX_DEPS)
        val latest = HashMap<String, Latest?>()
        for (eco in listOf("npm", "pip")) latest.putAll(lookupAll(eco, shown.filter { it.eco == eco }.map { it.name }.distinct()).mapKeys { eco + ":" + it.key })
        val edits = LinkedHashMap<String, String>()
        val sb = StringBuilder()
        var n = 0
        for (d in shown) {
            val l = latest[d.eco + ":" + d.name] ?: continue
            val cur = baseVersion(d.spec) ?: continue
            val b = bump(cur, l.version)
            if (b == "none") continue
            val explicit = picked.isNotEmpty()
            if (b == "major" && !allowMajor && !explicit) { sb.append("- ${d.name} ${d.spec} -> ${l.version} skipped (major; ask with name=${d.name} or major=true)\n"); continue }
            val spec = newSpec(d.eco, d.spec, l.version)
            if (spec == null) { sb.append("- ${d.name} ${d.spec}: open range, change it by hand if you want a newer floor\n"); continue }
            var text = edits[d.manifest] ?: File(dir, d.manifest).readText(Charsets.UTF_8)
            text = if (d.eco == "npm") setNpm(text, d.name, spec, d.dev) ?: continue else setPip(text, d.name, spec)
            edits[d.manifest] = text
            n++
            sb.append("- ${d.name} ${d.spec} -> $spec" + (if (b == "major") "  (MAJOR: test it)" else "") + "\n")
        }
        if (edits.isEmpty()) return (sb.toString().trim()).ifEmpty { "Everything is already at the latest version." }
        Coder.snapshot(ctx, dir)
        for ((p, t) in edits) File(dir, p).writeText(t, Charsets.UTF_8)
        touch(ctx, dir)
        return cap("Updated $n packages:\n" + sb.toString().trim() + "\nRun project_check now to see if anything broke. (undo: project_history action=undo)")
    }

    /** Dependency CVE check for project_engineering action=audit: never throws on a network problem. */
    fun auditForReport(dir: File): String = try {
        audit(dir)
    } catch (e: java.io.IOException) {
        "AUDIT skipped: OSV.dev not reachable (" + (e.message ?: "network") + "). Dependency CVEs were NOT checked."
    }

    private fun audit(dir: File): String {
        val all = readDeps(dir, manifests(dir))
        val deps = all.mapNotNull { d -> baseVersion(d.spec)?.let { Pair(d, it) } }.take(300)
        if (deps.isEmpty()) return "No versioned dependency to check. Use project_deps action=list; a package without a version cannot be checked."
        val ids = osvQuery(deps)
        val distinct = LinkedHashSet<String>()
        for (l in ids) distinct.addAll(l)
        if (distinct.isEmpty()) return "AUDIT: no known vulnerabilities for ${deps.size} packages (OSV.dev).\nNote: the version written in the manifest is taken as the installed one; there is no lock file or sub-dependency scan."
        val detail = HashMap<String, JSONObject>()
        val pool = Executors.newFixedThreadPool(MAX_PARALLEL)
        try {
            val fs = distinct.take(30).map { id -> id to pool.submit(Callable { try { jsonOrNull(get("https://api.osv.dev/v1/vulns/$id")) } catch (_: java.io.IOException) { null } }) }
            for ((id, f) in fs) try { f.get(40, TimeUnit.SECONDS)?.let { detail[id] = it } } catch (_: Exception) {}
        } finally { pool.shutdownNow() }
        val order = mapOf("critical" to 0, "high" to 1, "moderate" to 2, "medium" to 2, "low" to 3, "unknown" to 4)
        var worst = 4
        val sb = StringBuilder()
        var vulnPkgs = 0
        for (i in deps.indices) {
            if (ids[i].isEmpty()) continue
            vulnPkgs++
            val (d, base) = deps[i]
            sb.append("\n").append(d.name).append(' ').append(base).append(" (").append(d.manifest).append("): ").append(ids[i].size).append(" known vulnerabilit").append(if (ids[i].size == 1) "y" else "ies").append('\n')
            var fix: String? = null
            for (id in ids[i].take(6)) {
                val j = detail[id]
                val sev = if (j != null) severityOf(j) else "unknown"
                worst = minOf(worst, order[sev] ?: 4)
                val cve = j?.optJSONArray("aliases")?.let { arr -> (0 until arr.length()).map { arr.optString(it) }.firstOrNull { it.startsWith("CVE-") } }
                sb.append("  - ").append(id).append(if (cve != null) " / $cve" else "").append(" [").append(sev).append("] ").append(j?.optString("summary").orEmpty().take(110)).append('\n')
                val fx = if (j != null) fixedVersion(j, d.eco, d.name, base) else null
                if (fx != null && (fix == null || compareVersions(fx, fix) > 0)) fix = fx
            }
            if (ids[i].size > 6) sb.append("  ... and ${ids[i].size - 6} more\n")
            sb.append("  Fix: ").append(if (fix != null) "upgrade to $fix or newer (project_deps action=update name=${d.name}${if (bump(base, fix) == "major") " , major change" else ""})" else "no fixed version listed; check the advisory or replace the package").append('\n')
        }
        val sev = listOf("critical", "high", "moderate", "low", "unknown")[minOf(worst, 4)]
        return cap("AUDIT: $vulnPkgs of ${deps.size} packages have known vulnerabilities (worst: $sev).$sb\nSource: OSV.dev. The manifest version is taken as the installed one; sub-dependencies are not scanned. Fix, then run project_check.")
    }

    private fun vendor(ctx: Context, dir: File, a: JSONObject): String {
        val n = names(a).firstOrNull() ?: return "Give name (an npm package, e.g. chart.js)."
        if (!validName("npm", n)) return "$n is not a valid npm package name."
        var version = a.optString("version").trim()
        val file = a.optString("file").trim().trimStart('/')
        if (file.isNotEmpty() && (file.contains("..") || !Regex("^[A-Za-z0-9._/@-]+$").matches(file))) return "file: use a path inside the package like dist/chart.umd.min.js"
        if (version.isEmpty()) version = fetchLatest("npm", n)?.version ?: return "$n not found on npm."
        if (!Regex("^\\d[\\w.+-]*$").matches(version)) return "version must be an exact version like 4.4.1 (leave it empty for the latest)."
        val url = "https://cdn.jsdelivr.net/npm/$n@$version" + (if (file.isNotEmpty()) "/$file" else "")
        Cancel.check()
        val req = Request.Builder().url(url).header("User-Agent", "AnjooAI-CodeStudio").build()
        val bytes = http.newCall(req).execute().use { r ->
            if (r.code == 404) return "jsDelivr has no browser file for $n@$version" + (if (file.isEmpty()) ". Pass file=dist/<name>.min.js (look in the package's dist folder)." else " at $file.")
            if (r.code != 200) return "jsDelivr answered ${r.code}."
            val len = r.body?.contentLength() ?: -1L
            if (len > MAX_VENDOR) return "The file is larger than 3 MB; use the CDN link in a script tag instead: $url"
            val b = r.body?.bytes() ?: ByteArray(0)
            if (b.size > MAX_VENDOR) return "The file is larger than 3 MB; use the CDN link in a script tag instead: $url"
            b
        }
        val css = file.endsWith(".css")
        val folder = safeRel(a.optString("folder").ifBlank { "vendor" }) ?: "vendor"
        val base = (n.replace("@", "").replace('/', '-')) + "-" + version + (if (css) ".css" else ".js")
        val rel = "$folder/$base"
        Coder.snapshot(ctx, dir)
        val out = File(dir, rel)
        out.parentFile?.mkdirs()
        out.writeBytes(bytes)
        touch(ctx, dir)
        val tag = if (css) "<link rel=\"stylesheet\" href=\"$rel\">" else "<script src=\"$rel\"></script>"
        return "Saved $rel (${bytes.size / 1024} KB, $n@$version from jsDelivr). Add to the HTML: $tag\nThe file works offline now. (undo: project_history action=undo)"
    }
}
