package com.anjoo.assistant

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Publishes a website project to GitHub Pages: creates (or reuses) a public repository named after the project, writes
 * every project file in ONE commit through the Git Data API, and turns Pages on. Publishing again updates the same repository
 * and the same address. Needs a GitHub token with the "repo" permission (classic) or Contents + Pages write (fine-grained).
 */
object GitHubPages {

    private const val API = "https://api.github.com"
    private const val TOKEN_KEY = "githubPagesToken"
    private val JSON = "application/json".toMediaType()
    private val SKIP = setOf("node_modules", ".git", "build", "dist", ".gradle", "__pycache__", ".idea", "__MACOSX", "venv", ".venv")

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).writeTimeout(60, TimeUnit.SECONDS).build()

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    fun token(ctx: Context): String = prefs(ctx).getString(TOKEN_KEY, "").orEmpty()
    fun hasToken(ctx: Context): Boolean = prefs(ctx).getString(TOKEN_KEY, "").orEmpty().isNotBlank()
    fun saveToken(ctx: Context, token: String) { prefs(ctx).edit().putString(TOKEN_KEY, token.trim()).apply() }

    private class Res(val code: Int, val body: String) {
        fun json(): JSONObject = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
    }

    private fun call(token: String, method: String, url: String, body: JSONObject?): Res {
        val rb = if (body == null) (if (method == "GET") null else "{}".toRequestBody(JSON)) else body.toString().toRequestBody(JSON)
        val req = Request.Builder().url(url).method(method, rb)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28").build()
        return http.newCall(req).execute().use { r -> Res(r.code, r.body?.string().orEmpty()) }
    }

    private fun fail(r: Res, what: String): Nothing {
        val msg = r.json().optString("message").ifBlank { r.body.take(140) }
        if (r.code == 401) throw IllegalStateException("The GitHub token is wrong or expired. Set a new token.")
        if (r.code == 403 || r.code == 404) throw IllegalStateException("GitHub did not allow $what (${r.code}): $msg. The token needs the 'repo' permission.")
        throw IllegalStateException("GitHub error ${r.code} ($what): $msg")
    }

    private fun repoName(dir: File): String {
        val slug = Coder.name(dir).lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "-").trim('-').take(40)
        return "anjoo-" + slug.ifEmpty { "site" }
    }

    /** Returns the live address. Run on a background thread. [say] gets short progress lines. */
    fun publish(ctx: Context, dir: File, say: (String) -> Unit): String {
        val token = prefs(ctx).getString(TOKEN_KEY, "").orEmpty()
        if (token.isBlank()) throw IllegalStateException("No GitHub token set.")
        if (PreviewServer.entry(dir) == null) throw IllegalStateException("The project has no index page.")
        val files = dir.walkTopDown().onEnter { it == dir || it.name !in SKIP }
            .filter { it.isFile && !DeployCore.isPrivate(it.relativeTo(dir).path.replace('\\', '/')) && it.length() <= 25L * 1024 * 1024 }.toList()
        if (files.isEmpty()) throw IllegalStateException("The project is empty.")
        if (files.sumOf { it.length() } > 80L * 1024 * 1024) throw IllegalStateException("The project is larger than 80 MB.")

        say("GitHub: account check...")
        val me = call(token, "GET", "$API/user", null)
        if (me.code != 200) fail(me, "login")
        val login = me.json().optString("login")
        if (login.isBlank()) throw IllegalStateException("GitHub username not found.")

        val key = "ghRepo_" + dir.name
        val repo = prefs(ctx).getString(key, "").orEmpty().ifBlank { repoName(dir) }
        say("GitHub: repository '$repo'...")
        var info = call(token, "GET", "$API/repos/$login/$repo", null)
        if (info.code == 404) {
            val mk = call(token, "POST", "$API/user/repos", JSONObject().put("name", repo)
                .put("description", "Website made with Anjoo AI").put("private", false).put("auto_init", true))
            if (mk.code !in 200..299) fail(mk, "repository banane")
            info = mk
            Thread.sleep(1500)
        } else if (info.code != 200) fail(info, "repository dekhne")
        prefs(ctx).edit().putString(key, repo).apply()
        val branch = info.json().optString("default_branch").ifBlank { "main" }

        say("GitHub: uploading ${files.size} file(s)...")
        val tree = JSONArray()
        for ((i, f) in files.withIndex()) {
            val rel = f.relativeTo(dir).path.replace('\\', '/')
            val blob = call(token, "POST", "$API/repos/$login/$repo/git/blobs",
                JSONObject().put("content", android.util.Base64.encodeToString(f.readBytes(), android.util.Base64.NO_WRAP)).put("encoding", "base64"))
            if (blob.code !in 200..299) fail(blob, "file upload ($rel)")
            tree.put(JSONObject().put("path", rel).put("mode", "100644").put("type", "blob").put("sha", blob.json().optString("sha")))
            if (i % 5 == 4) say("GitHub: ${i + 1}/${files.size} file(s)...")
        }
        // Keeps files that start with an underscore (for example _headers) and stops Jekyll from changing the site.
        val empty = call(token, "POST", "$API/repos/$login/$repo/git/blobs", JSONObject().put("content", "").put("encoding", "utf-8"))
        if (empty.code in 200..299 && files.none { it.name == ".nojekyll" })
            tree.put(JSONObject().put("path", ".nojekyll").put("mode", "100644").put("type", "blob").put("sha", empty.json().optString("sha")))

        val newTree = call(token, "POST", "$API/repos/$login/$repo/git/trees", JSONObject().put("tree", tree))
        if (newTree.code !in 200..299) fail(newTree, "tree banane")
        val ref = call(token, "GET", "$API/repos/$login/$repo/git/ref/heads/$branch", null)
        val parent = if (ref.code == 200) ref.json().optJSONObject("object")?.optString("sha").orEmpty() else ""
        val commitBody = JSONObject().put("message", "Update website from Anjoo AI").put("tree", newTree.json().optString("sha"))
            .put("parents", JSONArray().apply { if (parent.isNotBlank()) put(parent) })
        val commit = call(token, "POST", "$API/repos/$login/$repo/git/commits", commitBody)
        if (commit.code !in 200..299) fail(commit, "commit banane")
        val sha = commit.json().optString("sha")
        val move = if (parent.isNotBlank()) call(token, "PATCH", "$API/repos/$login/$repo/git/refs/heads/$branch", JSONObject().put("sha", sha).put("force", true))
        else call(token, "POST", "$API/repos/$login/$repo/git/refs", JSONObject().put("ref", "refs/heads/$branch").put("sha", sha))
        if (move.code !in 200..299) fail(move, "branch update")

        say("GitHub: turning on Pages...")
        val pages = call(token, "POST", "$API/repos/$login/$repo/pages", JSONObject().put("source", JSONObject().put("branch", branch).put("path", "/")))
        // 201 = turned on now, 409 = already on. Anything else is shown to the user.
        if (pages.code !in listOf(200, 201, 204, 409)) fail(pages, "Pages on karne")
        return "https://$login.github.io/$repo/"
    }
}
