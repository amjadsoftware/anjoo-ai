package com.anjoo.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Real linters and formatters for Code Studio projects. A phone has no node or python binary, so the tools run inside a
 * hidden WebView, loaded from jsDelivr like PyRun does with Pyodide:
 *
 *  JavaScript lint ... ESLint (eslint-linter-browserify) with a bug-finding rule set (no-undef, no-unused-vars, no-dupe-keys ...)
 *  Python lint ....... pyflakes (undefined names, unused imports/variables, syntax errors) through micropip
 *  format ............ Prettier (js, jsx, ts, tsx, json, css, scss, less, html, md) and black (py); .prettierrc is honoured
 *
 * Needs internet the first time (libraries are cached afterwards). When the tools cannot load, callers fall back to the
 * built-in checks and say so. Not covered: ESLint for TypeScript, ruff, ktlint, project-specific ESLint configs.
 */
object Linter {

    private const val PRETTIER = "https://cdn.jsdelivr.net/npm/prettier@3.3.3/"
    private const val ESLINT = "https://cdn.jsdelivr.net/npm/eslint-linter-browserify@9.12.0/linter.js"
    private const val PYODIDE = "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/"
    private const val MAX_FILES = 40
    private const val MAX_FILE_CHARS = 300_000
    private val SKIP = Regex("(^|/)(node_modules|vendor|dist|build|\\.git|__pycache__)/|\\.min\\.(js|css)$|\\.bundle\\.js$")

    class Issue(val path: String, val line: Int, val col: Int, val rule: String, val severity: String, val message: String)
    class Result(val ok: Boolean, val note: String, val issues: List<Issue>, val formatted: Map<String, String>, val errors: List<String>)

    /** "js" | "ts" | "css" | "html" | "json" | "md" | "py" for files the real tools handle, else null. */
    fun kind(path: String): String? {
        if (SKIP.containsMatchIn(path.replace('\\', '/'))) return null
        return when (path.substringAfterLast('.', "").lowercase()) {
            "js", "jsx", "mjs", "cjs" -> "js"
            "ts", "tsx" -> "ts"
            "css", "scss", "less" -> "css"
            "html", "htm" -> "html"
            "json" -> "json"
            "md", "markdown" -> "md"
            "py" -> "py"
            else -> null
        }
    }

    /** Files the tools will look at: supported kind, not minified/vendored, not huge, at most [MAX_FILES]. [only] limits to one path. */
    fun eligible(files: Map<String, String>, mode: String, only: String = ""): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for ((p, c) in files.toSortedMap()) {
            if (only.isNotBlank() && p != only) continue
            val k = kind(p) ?: continue
            if (mode == "lint" && k != "js" && k != "py") continue
            if (c.length > MAX_FILE_CHARS || c.isBlank()) continue
            if (p.substringAfterLast('/') == "package-lock.json") continue
            out[p] = c
            if (out.size >= MAX_FILES) break
        }
        return out
    }

    /** Prettier options from a .prettierrc / .prettierrc.json in the project root (JSON only); "{}" when absent or invalid. */
    fun prettierOptions(files: Map<String, String>): String {
        for (n in listOf(".prettierrc", ".prettierrc.json")) {
            val t = files[n] ?: continue
            try { return JSONObject(t).toString() } catch (_: Exception) {}
        }
        return "{}"
    }

    fun parseResult(json: String): Result {
        val o = try { JSONObject(json) } catch (_: Exception) { return Result(false, "The tools returned no readable result.", emptyList(), emptyMap(), emptyList()) }
        val issues = ArrayList<Issue>()
        val li = o.optJSONArray("lint") ?: JSONArray()
        for (i in 0 until li.length()) {
            val x = li.optJSONObject(i) ?: continue
            issues.add(Issue(x.optString("path"), x.optString("line", "0").toIntOrNull() ?: 0, x.optString("col", "0").toIntOrNull() ?: 0,
                x.optString("rule", ""), x.optString("sev", "warn"), x.optString("msg")))
        }
        val fm = LinkedHashMap<String, String>()
        o.optJSONObject("format")?.let { f -> for (k in f.keys()) fm[k] = f.optString(k) }
        val errs = ArrayList<String>()
        o.optJSONArray("errors")?.let { e -> for (i in 0 until e.length()) errs.add(e.optString(i)) }
        return Result(true, "", issues, fm, errs)
    }

    /** Readable lint report: errors first, at most [perFile] lines per file. */
    fun report(issues: List<Issue>, perFile: Int = 12): String {
        if (issues.isEmpty()) return ""
        val sb = StringBuilder()
        val errs = issues.count { it.severity == "error" }
        sb.append(errs).append(" error(s), ").append(issues.size - errs).append(" warning(s)\n")
        for ((p, list) in issues.groupBy { it.path }.toSortedMap()) {
            val sorted = list.sortedWith(compareBy({ if (it.severity == "error") 0 else 1 }, { it.line }))
            for (i in sorted.take(perFile)) sb.append(p).append(':').append(i.line).append(':').append(i.col).append("  ").append(i.severity).append("  ")
                .append(i.message.take(160)).append(if (i.rule.isNotBlank()) "  [" + i.rule + "]" else "").append('\n')
            if (sorted.size > perFile) sb.append(p).append(": ... and ").append(sorted.size - perFile).append(" more\n")
        }
        return sb.toString().trim()
    }

    // ============================================================ the page

    private const val PY_LINT = """
import json, io, re
from pyflakes import api, reporter
files = json.loads(FILES_JSON)
out = []
for path, code in files.items():
    o, e = io.StringIO(), io.StringIO()
    api.check(code, path, reporter.Reporter(o, e))
    for line in (o.getvalue() + e.getvalue()).splitlines():
        m = re.match(r'^(.*?):(\d+):(?:(\d+):?)? ?(.*)${'$'}', line)
        if m:
            msg = m.group(4)
            sev = 'error' if ('syntax' in msg.lower() or 'invalid' in msg.lower() or 'undefined name' in msg.lower()) else 'warn'
            out.append({'path': path, 'line': m.group(2), 'col': m.group(3) or '0', 'rule': 'pyflakes', 'sev': sev, 'msg': msg})
RESULT = json.dumps(out)
"""

    private const val PY_FORMAT = """
import json, black
files = json.loads(FILES_JSON)
res, errs = {}, []
mode = black.Mode(line_length=int(LINE_LENGTH))
for path, code in files.items():
    try:
        new = black.format_str(code, mode=mode)
        if new != code:
            res[path] = new
    except Exception as ex:
        errs.append(path + ': ' + str(ex).splitlines()[0][:160] if str(ex) else path + ': cannot format')
RESULT = json.dumps({'format': res, 'errors': errs})
"""

    private const val GLOBALS = "window document console navigator localStorage sessionStorage fetch setTimeout clearTimeout setInterval clearInterval " +
        "requestAnimationFrame cancelAnimationFrame alert confirm prompt location history Event CustomEvent URL URLSearchParams FormData Blob File FileReader " +
        "XMLHttpRequest WebSocket Image Audio Promise performance AbortController MutationObserver IntersectionObserver ResizeObserver HTMLElement Node " +
        "atob btoa crypto matchMedia getComputedStyle indexedDB Worker structuredClone queueMicrotask TextEncoder TextDecoder innerWidth innerHeight " +
        "scrollTo scrollBy DOMParser Notification screen Intl globalThis self top parent frames caches requestIdleCallback " +
        "require module exports process __dirname __filename Buffer global setImmediate clearImmediate " +
        "describe it test expect beforeEach afterEach beforeAll afterAll jest vi"

    private fun page(mode: String, langs: String): String = "<!doctype html><html><body><script>\n" +
        "var R={lint:[],format:{},errors:[]};\n" +
        "function load(src){return new Promise(function(res,rej){var s=document.createElement('script');s.src=src;s.onload=res;s.onerror=function(){rej(new Error('could not load '+src));};document.head.appendChild(s);});}\n" +
        "var MODE=" + JSONObject.quote(mode) + ", LANGS=" + JSONObject.quote(langs) + ", GL=" + JSONObject.quote(GLOBALS) + ";\n" +
        "var INPUT=JSON.parse(Bridge.input());\n" +
        "var PARSER={js:'babel',ts:'typescript',json:'json',html:'html',md:'markdown'};\n" +
        "function pparser(p){var e=p.split('.').pop().toLowerCase();if(e=='ts'||e=='tsx')return 'typescript';if(e=='css')return 'css';if(e=='scss')return 'scss';if(e=='less')return 'less';return PARSER[INPUT.kinds[p]];}\n" +
        "async function runJs(){\n" +
        " var files=INPUT.files,paths=Object.keys(files).filter(function(p){return INPUT.kinds[p]=='js';});\n" +
        " if(!paths.length)return;\n" +
        " await load('" + ESLINT + "');\n" +
        " var g={};GL.split(' ').forEach(function(n){g[n]='readonly';});\n" +
        " var rules={'no-undef':'warn','no-unused-vars':['warn',{args:'none'}],'no-dupe-keys':'error','no-dupe-args':'error','no-dupe-else-if':'error','no-duplicate-case':'error','no-unreachable':'error','no-redeclare':'error','no-const-assign':'error','no-func-assign':'error','no-class-assign':'error','no-self-assign':'warn','no-cond-assign':'error','no-constant-condition':['warn',{checkLoops:false}],'no-empty':['warn',{allowEmptyCatch:true}],'no-fallthrough':'warn','no-sparse-arrays':'warn','use-isnan':'error','valid-typeof':'error','no-unsafe-negation':'error','no-unsafe-finally':'error','no-this-before-super':'error','no-invalid-regexp':'error','no-loss-of-precision':'warn','no-compare-neg-zero':'error','getter-return':'error','no-setter-return':'error','no-async-promise-executor':'error','no-dupe-class-members':'error','no-import-assign':'error','no-prototype-builtins':'warn','require-yield':'warn','eqeqeq':['warn','smart']};\n" +
        " var linter=new eslint.Linter();\n" +
        " paths.forEach(function(p){\n" +
        "  var cfg=[{files:['**/*'],languageOptions:{ecmaVersion:'latest',sourceType:(p.endsWith('.cjs')?'commonjs':'module'),globals:g,parserOptions:{ecmaFeatures:{jsx:true}}},rules:rules}];\n" +
        "  var msgs;try{msgs=linter.verify(files[p],cfg,{filename:p});}catch(e){R.errors.push(p+': '+e.message);return;}\n" +
        "  msgs.forEach(function(m){var fatal=m.fatal||m.severity==2;R.lint.push({path:p,line:m.line||0,col:m.column||0,rule:m.ruleId||'',sev:fatal?'error':'warn',msg:m.message});});\n" +
        " });\n" +
        "}\n" +
        "async function runPrettier(){\n" +
        " var files=INPUT.files,paths=Object.keys(files).filter(function(p){return pparser(p);});\n" +
        " if(!paths.length)return;\n" +
        " await load('" + PRETTIER + "standalone.js');\n" +
        " var need={};paths.forEach(function(p){var k=pparser(p);if(k=='babel'||k=='json'){need.babel=1;need.estree=1;}else if(k=='typescript'){need.typescript=1;need.estree=1;}else if(k=='html'){need.html=1;need.babel=1;need.estree=1;need.postcss=1;}else if(k=='markdown'){need.markdown=1;}else{need.postcss=1;}});\n" +
        " for(var n in need){await load('" + PRETTIER + "plugins/'+n+'.js');}\n" +
        " var plugins=Object.keys(need).map(function(n){return prettierPlugins[n];});\n" +
        " var base=JSON.parse(INPUT.options||'{}');\n" +
        " for(var i=0;i<paths.length;i++){var p=paths[i];\n" +
        "  try{var o=Object.assign({},base,{parser:pparser(p),plugins:plugins});var out=await prettier.format(files[p],o);if(out!==files[p])R.format[p]=out;}\n" +
        "  catch(e){R.errors.push(p+': '+String(e.message||e).split('\\n')[0].slice(0,200));}\n" +
        " }\n" +
        "}\n" +
        "async function runPy(){\n" +
        " var files={};Object.keys(INPUT.files).forEach(function(p){if(INPUT.kinds[p]=='py')files[p]=INPUT.files[p];});\n" +
        " if(!Object.keys(files).length)return;\n" +
        " await load('" + PYODIDE + "pyodide.js');\n" +
        " var py=await loadPyodide({indexURL:'" + PYODIDE + "'});\n" +
        " await py.loadPackage('micropip');\n" +
        " py.globals.set('FILES_JSON',JSON.stringify(files));py.globals.set('LINE_LENGTH',INPUT.lineLength||88);\n" +
        " if(MODE=='lint'){await py.runPythonAsync('import micropip\\nawait micropip.install(\"pyflakes\")');await py.runPythonAsync(Bridge.pyLint());R.lint=R.lint.concat(JSON.parse(py.globals.get('RESULT')));}\n" +
        " else{await py.runPythonAsync('import micropip\\nawait micropip.install(\"black\")');await py.runPythonAsync(Bridge.pyFormat());var r=JSON.parse(py.globals.get('RESULT'));Object.assign(R.format,r.format);R.errors=R.errors.concat(r.errors);}\n" +
        "}\n" +
        "async function go(){\n" +
        " try{\n" +
        "  Bridge.loaded();\n" +
        "  var jobs=[];\n" +
        "  if(MODE=='lint'){ if(LANGS.indexOf('js')>=0){try{await runJs();}catch(e){R.errors.push('ESLint: '+(e.message||e));}} }\n" +
        "  else{ try{await runPrettier();}catch(e){R.errors.push('Prettier: '+(e.message||e));} }\n" +
        "  if(LANGS.indexOf('py')>=0){try{await runPy();}catch(e){R.errors.push((MODE=='lint'?'pyflakes: ':'black: ')+String((e&&e.message)||e).split('\\n')[0].slice(0,200));}}\n" +
        " }catch(e){R.errors.push(String((e&&e.message)||e));}\n" +
        " Bridge.done(JSON.stringify(R));\n" +
        "}\n" +
        "go();\n" +
        "</script></body></html>"

    class Bridge(val input: String, val loadedLatch: CountDownLatch, val doneLatch: CountDownLatch) {
        @Volatile var result = ""
        @Volatile var finished = false
        @Volatile var didLoad = false
        @JavascriptInterface fun input() = input
        @JavascriptInterface fun pyLint() = PY_LINT
        @JavascriptInterface fun pyFormat() = PY_FORMAT
        @JavascriptInterface fun loaded() { didLoad = true; loadedLatch.countDown() }
        @JavascriptInterface fun done(r: String) { result = r; finished = true; loadedLatch.countDown(); doneLatch.countDown() }
    }

    /** Blocking. Call from a background thread. [mode] is "lint" or "format". */
    fun run(ctx: Context, mode: String, files: Map<String, String>, only: String = "", waitMs: Long = 150_000): Result {
        val chosen = eligible(files, mode, only)
        if (chosen.isEmpty()) return Result(true, "No JavaScript or Python file to " + (if (mode == "lint") "lint" else "format") + ".", emptyList(), emptyMap(), emptyList())
        val kinds = JSONObject()
        val fobj = JSONObject()
        for ((p, c) in chosen) { kinds.put(p, kind(p)); fobj.put(p, c) }
        val langs = chosen.keys.mapNotNull { kind(it) }.toSet().joinToString(",")
        val input = JSONObject().put("files", fobj).put("kinds", kinds).put("options", prettierOptions(files)).put("lineLength", 88).toString()
        val loadedLatch = CountDownLatch(1)
        val doneLatch = CountDownLatch(1)
        val b = Bridge(input, loadedLatch, doneLatch)
        val main = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        val jsErr = StringBuilder()
        main.post {
            try {
                val w = WebView(ctx.applicationContext)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.addJavascriptInterface(b, "Bridge")
                w.webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(m: android.webkit.ConsoleMessage?): Boolean {
                        if (m != null && m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR && jsErr.length < 400) jsErr.append(m.message()).append('\n')
                        return true
                    }
                }
                w.loadDataWithBaseURL("https://lint.local/", page(mode, langs), "text/html", "UTF-8", null)
            } catch (e: Exception) { loadedLatch.countDown(); doneLatch.countDown() }
        }
        try { loadedLatch.await(20_000, TimeUnit.MILLISECONDS) } catch (_: Exception) {}
        if (b.didLoad && !b.finished) try { doneLatch.await(waitMs, TimeUnit.MILLISECONDS) } catch (_: Exception) {}
        main.post { try { wv?.stopLoading(); wv?.destroy() } catch (_: Exception) {} }
        if (!b.didLoad) return Result(false, "The lint/format engine could not start.", emptyList(), emptyMap(), emptyList())
        if (!b.finished) return Result(false, "The lint/format engine did not finish in time (first use downloads the tools; check the internet and try again).", emptyList(), emptyMap(), emptyList())
        return parseResult(b.result)
    }

    /** Lint report for the assistant, or "" when the engine is unavailable (the caller then says only built-in checks ran). */
    fun lintReport(ctx: Context, files: Map<String, String>): String {
        val r = run(ctx, "lint", files)
        if (!r.ok) return "Real linters (ESLint, pyflakes): not run. " + r.note
        val rep = report(r.issues)
        val errs = if (r.errors.isEmpty()) "" else "\nTool problems: " + r.errors.joinToString("; ").take(400)
        if (r.note.isNotEmpty()) return ""
        return if (rep.isEmpty()) "Real linters (ESLint for JavaScript, pyflakes for Python): no problems.$errs" else "Real linters (ESLint / pyflakes):\n$rep$errs"
    }

    /** Applies the real formatters. Returns the files changed and a summary; writing is left to the caller. */
    fun format(ctx: Context, files: Map<String, String>, only: String = ""): Result = run(ctx, "format", files, only)
}
