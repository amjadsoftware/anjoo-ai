package com.anjoo.assistant

import android.content.Context
import java.io.File

/**
 * Audit log of security and agent events that really happened on this phone (export passcode tries, money-safety
 * blocks, tools paused after repeated failures, admin changes). Append-only inside the app: there is no edit or
 * clear function. Keeps the newest [MAX] events. Never stores prompts, keys, passcodes or tool output.
 */
object AdminAudit {
    const val MAX = 500
    private const val FILE = "admin_audit.tsv"
    private const val DEDUPE_MS = 30_000L
    private const val WINDOW_MS = 10 * 60_000L

    class Entry(val at: Long, val category: String, val action: String, val detail: String)

    // ---- pure helpers (no Android; unit tested) ----

    private fun esc(s: String): String = s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "")

    private fun unesc(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) { 't' -> sb.append('\t'); 'n' -> sb.append('\n'); else -> sb.append(s[i + 1]) }
                i += 2
            } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    fun encode(e: Entry): String = e.at.toString() + "\t" + esc(e.category) + "\t" + esc(e.action) + "\t" + esc(e.detail)

    fun decode(line: String): Entry? {
        val p = line.split('\t')
        if (p.size < 4) return null
        val at = p[0].toLongOrNull() ?: return null
        return Entry(at, unesc(p[1]), unesc(p[2]), unesc(p[3]))
    }

    /** True when the same event was just logged (so a stuck loop does not flood the log). */
    fun isRepeat(last: Entry?, category: String, action: String, detail: String, now: Long): Boolean =
        last != null && last.category == category && last.action == action && last.detail == detail && now - last.at < DEDUPE_MS

    fun trim(lines: List<String>, max: Int = MAX): List<String> = if (lines.size <= max) lines else lines.subList(lines.size - max, lines.size)

    /** Unusual activity in the last 10 minutes, from the log itself. Empty when nothing stands out. */
    fun suspicious(entries: List<Entry>, now: Long): List<String> {
        val recent = entries.filter { now - it.at <= WINDOW_MS }
        val out = ArrayList<String>()
        val wrong = recent.count { it.action.startsWith("Wrong passcode") }
        if (wrong >= 3) out.add("$wrong wrong export passcodes in the last 10 minutes.")
        val money = recent.count { it.action.startsWith("Blocked: bank") }
        if (money >= 5) out.add("$money actions blocked by the bank, wallet and card safety rule in the last 10 minutes.")
        val paused = recent.count { it.action.startsWith("Tool paused") }
        if (paused >= 3) out.add("$paused tools were paused after repeated failures in the last 10 minutes.")
        return out
    }

    // ---- storage ----

    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, FILE)

    @Synchronized
    fun log(ctx: Context, category: String, action: String, detail: String = "") {
        try {
            val now = System.currentTimeMillis()
            val f = file(ctx)
            val lines = if (f.exists()) f.readLines() else emptyList()
            if (isRepeat(lines.lastOrNull()?.let { decode(it) }, category, action, detail.take(160), now)) return
            val all = lines + encode(Entry(now, category.take(20), action.take(90), detail.take(160)))
            f.writeText(trim(all).joinToString("\n") + "\n")
        } catch (_: Exception) { /* logging must never break the app */ }
    }

    /** Newest first. */
    @Synchronized
    fun entries(ctx: Context): List<Entry> = try {
        val f = file(ctx)
        if (f.exists()) f.readLines().mapNotNull { decode(it) }.reversed() else emptyList()
    } catch (_: Exception) { emptyList() }
}
