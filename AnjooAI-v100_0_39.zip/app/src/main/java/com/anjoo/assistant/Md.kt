package com.anjoo.assistant

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.URLSpan
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Turns an AI reply written in Markdown into clean native views (headings, lists, code blocks with Copy, links). */
object Md {

    private val INLINE = Regex("\\*\\*(.+?)\\*\\*|`([^`\\n]+)`|\\[([^\\]\\n]+)\\]\\((https?://[^)\\s]+)\\)|(?<![*\\w])\\*([^*\\n]+)\\*(?!\\w)|__(.+?)__|(?<![\\w(\\[\\]/\"=])(https?://[^\\s<>)\\]]+[^\\s<>)\\].,;:!?'\"])")

    /** Links are blue (like Claude), a lighter blue on dark themes. */
    fun linkColor(th: CyberTheme): Int = if (th.light) Color.parseColor("#1A73E8") else Color.parseColor("#6CA8FF")

    private class BlueLink(url: String) : URLSpan(url) {
        override fun updateDrawState(ds: android.text.TextPaint) { super.updateDrawState(ds); ds.isUnderlineText = false }
    }

    fun inline(src: String, th: CyberTheme): CharSequence {
        val sb = SpannableStringBuilder()
        var pos = 0
        for (m in INLINE.findAll(src)) {
            if (m.range.first > pos) sb.append(src.substring(pos, m.range.first))
            val start = sb.length
            val g = m.groupValues
            when {
                g[1].isNotEmpty() -> { sb.append(g[1]); sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                g[6].isNotEmpty() -> { sb.append(g[6]); sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                g[2].isNotEmpty() -> {
                    sb.append(g[2])
                    sb.setSpan(TypefaceSpan("monospace"), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(BackgroundColorSpan(Color.argb(48, 128, 128, 128)), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(RelativeSizeSpan(0.92f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                g[3].isNotEmpty() -> {
                    sb.append(g[3])
                    sb.setSpan(BlueLink(g[4]), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(ForegroundColorSpan(linkColor(th)), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                g[7].isNotEmpty() -> {
                    sb.append(g[7])
                    sb.setSpan(BlueLink(g[7]), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(ForegroundColorSpan(linkColor(th)), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                g[5].isNotEmpty() -> { sb.append(g[5]); sb.setSpan(StyleSpan(Typeface.ITALIC), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
            }
            pos = m.range.last + 1
        }
        if (pos < src.length) sb.append(src.substring(pos))
        return sb
    }

    private fun copy(ctx: Context, t: String) {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Anjoo", t))
        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
    }

    /** Set by the chat screen: called with the selected text when the user taps "Reply" in the selection bar. */
    var onReply: ((String) -> Unit)? = null

    private fun text(ctx: Context, th: CyberTheme, s: CharSequence, size: Float = 16f): TextView = TextView(ctx).apply {
        this.text = s
        textSize = size
        setTextColor(th.ink)
        // Keep chat answers crisp and consistent with a modern app UI. Android textSize is in sp.
        typeface = FontPref.body(ctx)
        includeFontPadding = false
        setLineSpacing(0f, 1.30f)
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        setTextIsSelectable(true)
        movementMethod = LinkMovementMethod.getInstance()
        setLinkTextColor(linkColor(th))
        customSelectionActionModeCallback = object : android.view.ActionMode.Callback {
            override fun onCreateActionMode(mode: android.view.ActionMode, menu: android.view.Menu): Boolean {
                if (onReply != null) menu.add(0, 7001, 0, "Reply").setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS)
                return true
            }
            override fun onPrepareActionMode(mode: android.view.ActionMode, menu: android.view.Menu) = false
            override fun onActionItemClicked(mode: android.view.ActionMode, item: android.view.MenuItem): Boolean {
                if (item.itemId != 7001) return false
                val tv = this@apply
                val a = tv.selectionStart.coerceAtLeast(0); val b = tv.selectionEnd.coerceAtLeast(0)
                val sel = tv.text.subSequence(minOf(a, b), maxOf(a, b)).toString().trim()
                mode.finish()
                if (sel.isNotEmpty()) onReply?.invoke(sel)
                return true
            }
            override fun onDestroyActionMode(mode: android.view.ActionMode) {}
        }
    }

    /** Builds the views for one reply. */
    fun render(ctx: Context, raw: String, th: CyberTheme): LinearLayout {
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        fun add(v: View, top: Int = 6) {
            root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
        }

        val lines = raw.replace("\r", "").split("\n")
        var i = 0
        val para = StringBuilder()
        fun flush() {
            if (para.isNotBlank()) {
                val body = text(ctx, th, inline(para.toString().trim(), th), 16f)
                body.setLineSpacing(0f, 1.32f)
                add(body, 8)
            }
            para.setLength(0)
        }
        while (i < lines.size) {
            val ln = lines[i]
            val t = ln.trim()
            if (t.startsWith("```")) {
                flush()
                val lang = t.removePrefix("```").trim()
                val code = StringBuilder()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) { code.append(lines[i]).append("\n"); i++ }
                val body = code.toString().trimEnd()
                val l = lang.lowercase()
                val previewable = l == "html" || l == "htm" || l == "svg"
                val prose = l in PROSE_LANGS
                val page = if (l == "svg") "<html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head><body style=\"margin:0;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#fff\">" + body + "</body></html>" else body
                val box = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    background = GradientDrawable().apply { setColor(0xFF1F1E1D.toInt()); cornerRadius = dp(12).toFloat(); setStroke(dp(1) / 2 + 1, Color.argb(60, 128, 128, 128)) }
                }
                val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(2), dp(4), 0) }
                var outViewForPython: TextView? = null
                fun act(label: String, f: () -> Unit) = TextView(ctx).apply {
                    this.text = label; textSize = 12f; setTextColor(th.accent)
                    setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { f() }
                }
                val hs = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
                val pane = CodePane(ctx, 12.5f)
                pane.set(body, l)
                pane.view.setPadding(0, dp(2), 0, dp(10))
                hs.addView(pane.view)
                val nLines = body.count { it == '\n' } + 1
                val holder = FrameLayout(ctx).apply { visibility = View.GONE }
                var wv: WebView? = null
                val tCode = act("Code") {}
                val tPrev = act("Preview") {}
                fun showCode() {
                    hs.visibility = View.VISIBLE; holder.visibility = View.GONE
                    tCode.setTypeface(null, Typeface.BOLD); tPrev.setTypeface(null, Typeface.NORMAL)
                }
                fun showPreview() {
                    if (wv == null) {
                        val w = WebView(ctx)
                        w.settings.javaScriptEnabled = true
                        w.settings.domStorageEnabled = true
                        w.setBackgroundColor(Color.WHITE)
                        w.setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
                        w.loadDataWithBaseURL("https://preview.local/", page, "text/html", "UTF-8", null)
                        holder.addView(w, FrameLayout.LayoutParams(-1, -1))
                        wv = w
                    }
                    hs.visibility = View.GONE; holder.visibility = View.VISIBLE
                    tPrev.setTypeface(null, Typeface.BOLD); tCode.setTypeface(null, Typeface.NORMAL)
                }
                if (previewable) {
                    tCode.setOnClickListener { showCode() }
                    tPrev.setOnClickListener { showPreview() }
                    head.addView(tCode); head.addView(tPrev)
                } else {
                    head.addView(TextView(ctx).apply {
                        this.text = (if (l == "prompt") "Prompt" else if (prose) "Text" else lang.ifEmpty { "code" }); textSize = 12f; setTextColor(0xFFA3A199.toInt())
                        setPadding(dp(10), dp(8), dp(8), dp(8))
                    })
                }
                head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
                if (previewable) head.addView(act("↗") {
                    try {
                        val f = java.io.File(java.io.File(ctx.filesDir, "studio").also { it.mkdirs() }, "snippet-" + (System.currentTimeMillis() / 1000) + ".html")
                        f.writeText(page, Charsets.UTF_8)
                        Studio.open(ctx, f)
                    } catch (e: Exception) {}
                }.apply { contentDescription = "Open preview in Code Studio" })
                if (l == "python" || l == "py") {
                    val out = TextView(ctx).apply {
                        textSize = 12f; setTextColor(th.ink); typeface = Typeface.MONOSPACE; setTextIsSelectable(true)
                        setPadding(dp(12), dp(6), dp(12), dp(10)); visibility = View.GONE
                    }
                    val runBtn = act("\u25B6 Run") {}
                    runBtn.setOnClickListener {
                        if (runBtn.tag == "busy") return@setOnClickListener
                        runBtn.tag = "busy"
                        out.visibility = View.VISIBLE
                        out.text = "Running Python... (the runtime is downloaded the first time; internet needed)"
                        Thread {
                            val dd = java.io.File(ctx.cacheDir, "pychat-" + System.currentTimeMillis())
                            val res = try {
                                dd.mkdirs()
                                java.io.File(dd, "main.py").writeText(body, Charsets.UTF_8)
                                PyRun.run(ctx, dd, "main.py", false, 70000, 40000)
                            } catch (e: Exception) { null } finally { try { dd.deleteRecursively() } catch (e: Exception) {} }
                            val sb = StringBuilder()
                            when {
                                res == null || !res.loaded -> sb.append("The runtime did not load. Check your internet.")
                                !res.finished -> sb.append("The program did not finish in time (endless loop or waiting for input?).")
                                else -> {
                                    if (res.out.isNotBlank()) sb.append(res.out.trim().take(4000))
                                    if (res.err.isNotBlank()) sb.append(if (sb.isEmpty()) "" else "\n\n").append("\u26A0\uFE0F ").append(res.err.trim().takeLast(2000))
                                    if (sb.isEmpty()) sb.append("\u2705 Ran successfully (nothing was printed).")
                                }
                            }
                            out.post { out.text = sb.toString(); runBtn.tag = null }
                        }.start()
                    }
                    head.addView(runBtn)
                    outViewForPython = out
                }
                head.addView(act(if (l == "prompt") "Copy prompt" else "Copy") { copy(ctx, body) })
                box.addView(head)
                val codeContent: View = if (prose) TextView(ctx).apply {
                    text = body; textSize = 14.5f; setTextColor(th.ink); setLineSpacing(0f, 1.3f)
                    textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                    setTextIsSelectable(true); setPadding(dp(12), dp(4), dp(12), dp(12))
                } else hs
                val codeScroll = ScrollView(ctx).apply {
                    isVerticalScrollBarEnabled = nLines > 14
                    addView(codeContent, FrameLayout.LayoutParams(-1, -2))
                }
                val codeParams = LinearLayout.LayoutParams(-1, if (nLines > 14) dp(240) else -2)
                box.addView(codeScroll, codeParams)
                if (nLines > 14) {
                    val expand = act("↕") {
                        val open = codeScroll.tag == "expanded"
                        codeScroll.tag = if (open) "compact" else "expanded"
                        codeParams.height = if (open) dp(240) else dp(440)
                        codeScroll.layoutParams = codeParams
                        codeScroll.isVerticalScrollBarEnabled = true
                        val expandView = head.findViewWithTag<TextView>("code_expand_action")
                        expandView?.text = if (open) "⌄" else "⌃"
                        expandView?.contentDescription = if (open) "Expand code" else "Collapse code"
                    }
                    expand.tag = "code_expand_action"
                    expand.contentDescription = "Expand or collapse code"
                    head.addView(expand)
                }
                head.addView(act("⛶") { showFullscreenCode(ctx, lang.ifBlank { "code" }, body, th) }.apply { contentDescription = "Open code full screen" })
                outViewForPython?.let { box.addView(it) }
                outViewForPython = null
                box.addView(holder, LinearLayout.LayoutParams(-1, dp(380)))
                if (previewable) showCode()
                add(box, 8)
                i++
                continue
            }
            val h = Regex("^(#{1,6})\\s+(.*)$").find(t)
            if (h != null) {
                flush()
                val lvl = h.groupValues[1].length
                val size = when (lvl) { 1 -> 25f; 2 -> 21f; 3 -> 18.5f; 4 -> 17f; else -> 16f }
                val tv = text(ctx, th, inline(h.groupValues[2], th), size)
                tv.typeface = Typeface.create(if (lvl <= 2) "sans-serif" else "sans-serif-medium", Typeface.BOLD)
                tv.setLineSpacing(0f, 1.12f)
                tv.setTextColor(if (lvl == 1) th.accent else th.ink)
                tv.setPadding(0, dp(1), 0, dp(2))
                add(tv, when (lvl) { 1 -> 18; 2 -> 15; 3 -> 12; else -> 9 })
                i++
                continue
            }
            val bullet = Regex("^([-*•+])\\s+(.*)$").find(t)
            val num = Regex("^(\\d{1,3})[.)]\\s+(.*)$").find(t)
            if (bullet != null || num != null) {
                flush()
                val indent = ln.length - ln.trimStart().length
                val marker = if (bullet != null) "•" else num!!.groupValues[1] + "."
                val body = if (bullet != null) bullet.groupValues[2] else num!!.groupValues[2]
                val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
                val mark = text(ctx, th, marker, 15f).apply {
                    setTextColor(th.accent)
                    typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
                    gravity = Gravity.TOP
                    setPadding(0, dp(1), 0, 0)
                }
                row.addView(mark, LinearLayout.LayoutParams(dp(24), -2))
                val itemText = text(ctx, th, inline(body, th), 16f).apply { setLineSpacing(0f, 1.28f) }
                row.addView(itemText, LinearLayout.LayoutParams(0, -2, 1f))
                root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6); marginStart = dp(4 + minOf(indent, 8) * 4) })
                i++
                continue
            }
            if (t.startsWith(">")) {
                flush()
                val q = text(ctx, th, inline(t.removePrefix(">").trim(), th), 15.5f).apply {
                    setTextColor(th.muted)
                    setLineSpacing(0f, 1.28f)
                    setPadding(dp(12), dp(6), dp(8), dp(6))
                }
                val wrap = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    background = GradientDrawable().apply { setColor(Color.argb(if (th.light) 10 else 20, Color.red(th.accent), Color.green(th.accent), Color.blue(th.accent))); cornerRadius = dp(8).toFloat() }
                }
                wrap.addView(View(ctx).apply { setBackgroundColor(th.accent) }, LinearLayout.LayoutParams(dp(3), -1))
                wrap.addView(q, LinearLayout.LayoutParams(0, -2, 1f))
                add(wrap, 8)
                i++
                continue
            }
            if (t.startsWith("|") && t.endsWith("|")) {
                flush()
                val rows = ArrayList<List<String>>()
                while (i < lines.size && lines[i].trim().startsWith("|")) {
                    val row = lines[i].trim()
                    if (!Regex("^\\|[\\s:|-]+\\|$").matches(row)) {
                        rows.add(row.removePrefix("|").removeSuffix("|").split("|").map { it.trim() })
                    }
                    i++
                }
                if (rows.isNotEmpty()) {
                    val count = rows.maxOf { it.size }
                    val widths = (0 until count).map { c ->
                        val chars = rows.maxOf { r -> r.getOrElse(c) { "" }.length }.coerceIn(8, 28)
                        dp((chars * 7.3f + 28f).toInt().coerceIn(88, 230))
                    }
                    val table = LinearLayout(ctx).apply {
                        orientation = LinearLayout.VERTICAL
                        background = GradientDrawable().apply { setColor(th.surface); cornerRadius = dp(9).toFloat(); setStroke(dp(1), Color.argb(55, Color.red(th.muted), Color.green(th.muted), Color.blue(th.muted)) ) }
                        clipToOutline = true
                    }
                    rows.forEachIndexed { ri, cells ->
                        val rowView = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
                        for (ci in 0 until count) {
                            val value = cells.getOrElse(ci) { "" }
                            val cell = TextView(ctx).apply {
                                text = inline(value, th)
                                textSize = if (ri == 0) 13.5f else 13.25f
                                setTextColor(if (ri == 0) th.accent else th.ink)
                                typeface = if (ri == 0) Typeface.create("sans-serif-medium", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
                                includeFontPadding = false
                                setLineSpacing(0f, 1.18f)
                                setPadding(dp(9), dp(9), dp(9), dp(9))
                                gravity = Gravity.CENTER_VERTICAL
                                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                                setTextIsSelectable(true)
                                if (ri == 0) setBackgroundColor(Color.argb(if (th.light) 18 else 28, Color.red(th.accent), Color.green(th.accent), Color.blue(th.accent)))
                            }
                            rowView.addView(cell, LinearLayout.LayoutParams(widths[ci], -2))
                        }
                        table.addView(rowView, LinearLayout.LayoutParams(-2, -2))
                        if (ri < rows.lastIndex) table.addView(View(ctx).apply {
                            setBackgroundColor(Color.argb(45, Color.red(th.muted), Color.green(th.muted), Color.blue(th.muted)))
                        }, LinearLayout.LayoutParams(-1, dp(1)))
                    }
                    val hs = HorizontalScrollView(ctx).apply {
                        isHorizontalScrollBarEnabled = false
                        addView(table)
                    }
                    add(hs, 8)
                }
                continue
            }
            if (Regex("^(-{3,}|\\*{3,}|_{3,})$").matches(t)) {
                flush()
                add(View(ctx).apply { setBackgroundColor(Color.argb(60, 128, 128, 128)) }.also {
                    it.layoutParams = LinearLayout.LayoutParams(-1, dp(1))
                }, 10)
                i++
                continue
            }
            if (t.isEmpty()) { flush(); i++; continue }
            if (para.isNotEmpty()) para.append("\n")
            para.append(ln.trimEnd())
            i++
        }
        flush()
        if (root.childCount == 0) add(text(ctx, th, raw))
        return root
    }

    private val PROSE_LANGS = setOf("prompt", "text", "txt", "md", "markdown")

    /** Full-screen, selectable code view with a real copy action. */
    private fun showFullscreenCode(ctx: Context, language: String, source: String, th: CyberTheme) {
        val dlg = Dialog(ctx)
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(0xFF171717.toInt()); setPadding(dp(14), dp(10), dp(14), dp(10)) }
        val header = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(ctx).apply { text = language.uppercase(); textSize = 13f; setTextColor(0xFFB9B4AC.toInt()); typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(TextView(ctx).apply { text = "Copy"; textSize = 13f; setTextColor(th.accent); setPadding(dp(12), dp(10), dp(12), dp(10)); setOnClickListener { copy(ctx, source) } })
        header.addView(TextView(ctx).apply { text = "Done"; textSize = 13f; setTextColor(th.accent); setPadding(dp(12), dp(10), dp(4), dp(10)); setOnClickListener { dlg.dismiss() } })
        root.addView(header)
        root.addView(View(ctx).apply { setBackgroundColor(Color.argb(55, 255, 255, 255)) }, LinearLayout.LayoutParams(-1, dp(1)))
        val code = TextView(ctx).apply {
            text = source; textSize = 13f; setTextColor(0xFFE6EDF3.toInt()); typeface = Typeface.MONOSPACE
            setTextIsSelectable(true); setPadding(dp(10), dp(12), dp(10), dp(20)); setHorizontallyScrolling(true)
        }
        val sc = ScrollView(ctx).apply { isFillViewport = false; addView(HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = true; addView(code) }) }
        root.addView(sc, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        dlg.setContentView(root)
        dlg.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dlg.show()
        dlg.window?.setLayout(-1, (ctx.resources.displayMetrics.heightPixels * 0.92f).toInt())
    }

    /** The fenced blocks of a reply as (language, text), in order. */
    fun blocks(raw: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val lines = raw.replace("\r", "").split("\n")
        var i = 0
        while (i < lines.size) {
            val t = lines[i].trim()
            if (t.startsWith("```")) {
                val lang = t.removePrefix("```").trim().lowercase()
                val sb = StringBuilder()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) { sb.append(lines[i]).append("\n"); i++ }
                out.add(Pair(lang, sb.toString().trimEnd()))
            }
            i++
        }
        return out
    }

    /** Plain text for copying/sharing/speaking: markdown marks removed. */
    fun plain(raw: String): String = raw.replace(Regex("```[a-zA-Z0-9+#-]*\\n?"), "")
        .replace(Regex("\\*\\*|__|`"), "").replace(Regex("(?m)^#{1,4}\\s+"), "").trim()
}
