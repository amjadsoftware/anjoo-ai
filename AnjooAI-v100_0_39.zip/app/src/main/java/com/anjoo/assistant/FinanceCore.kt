package com.anjoo.assistant

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import java.io.File
import java.util.Locale

/**
 * Finance logic. Pure Kotlin (no Android) so it can be unit tested.
 * Two kinds of money are kept apart on purpose:
 *  - ESTIMATE: tokens measured on this phone times the prices the owner typed in.
 *  - ACTUAL:   amounts the owner recorded from a real provider invoice or payment (FinanceStore).
 * Nothing is invented: with no price entered, the cost is "unknown", never 0.
 */
object FinanceCore {
    data class Expense(val at: Long, val provider: String, val amountUsd: Double, val note: String)
    data class CostRow(val company: String, val model: String, val calls: Long, val input: Long, val output: Long, val cost: Double?)
    enum class BudgetState { NONE, OK, NEAR, OVER }

    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "")
    private fun unesc(s: String): String {
        val sb = StringBuilder(); var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                when (s[i + 1]) { 't' -> sb.append('\t'); 'n' -> sb.append('\n'); '\\' -> sb.append('\\'); else -> sb.append(s[i + 1]) }
                i += 2
            } else { sb.append(c); i++ }
        }
        return sb.toString()
    }

    fun encode(e: Expense): String = e.at.toString() + "\t" + esc(e.provider) + "\t" + e.amountUsd.toString() + "\t" + esc(e.note)

    fun decode(line: String): Expense? {
        val p = line.split('\t')
        if (p.size < 4) return null
        val at = p[0].toLongOrNull() ?: return null
        val amount = p[2].toDoubleOrNull() ?: return null
        if (amount.isNaN() || amount.isInfinite() || amount < 0) return null
        return Expense(at, unesc(p[1]), amount, unesc(p[3]))
    }

    /** One row per "Company|model", biggest token use first. The cost is null when the owner entered no price for that model. */
    fun costRows(totals: Map<String, UsageBook.Row>, prices: Map<String, Pair<Double, Double>>): List<CostRow> =
        totals.entries.map { (k, r) ->
            val company = k.substringBefore('|'); val model = if (k.contains('|')) k.substringAfter('|') else k
            CostRow(company, model, r.calls, r.input, r.output, UsageBook.cost(prices, model, r.input, r.output))
        }.sortedByDescending { it.input + it.output }

    /** Sum of the rows that have a price, and whether every row had one. */
    fun sumKnown(rows: List<CostRow>): Pair<Double, Boolean> {
        var sum = 0.0; var all = true
        for (r in rows) { val c = r.cost; if (c == null) all = false else sum += c }
        return sum to all
    }

    /** Straight-line guess for the whole month from the days so far. Always shown as an estimate. */
    fun projection(spentSoFar: Double, dayOfMonth: Int, daysInMonth: Int): Double =
        if (dayOfMonth <= 0 || daysInMonth <= 0) spentSoFar else spentSoFar / dayOfMonth * daysInMonth

    fun budgetState(spent: Double, budget: Double): BudgetState = when {
        budget <= 0.0 -> BudgetState.NONE
        spent >= budget -> BudgetState.OVER
        spent >= budget * 0.8 -> BudgetState.NEAR
        else -> BudgetState.OK
    }

    /** Parses a typed money amount ("12.5", "$12.50", "1,200"). Returns null for anything that is not a non-negative number. */
    fun parseAmount(text: String): Double? {
        val t = text.trim().removePrefix("$").replace(",", "").trim()
        val v = t.toDoubleOrNull() ?: return null
        return if (v.isNaN() || v.isInfinite() || v < 0) null else v
    }

    fun money(v: Double): String = String.format(Locale.US, if (v != 0.0 && v < 0.01) "$%.4f" else "$%.2f", v)

    private fun csvCell(s: String): String {
        // A cell that starts with = + - @ could run as a formula in a spreadsheet: neutralise it.
        val safe = if (s.isNotEmpty() && s[0] in "=+@" || s.startsWith("-") && s.toDoubleOrNull() == null) "'$s" else s
        return if (safe.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + safe.replace("\"", "\"\"") + "\"" else safe
    }

    fun csv(header: List<String>, rows: List<List<String>>): String =
        (listOf(header) + rows).joinToString("\r\n") { r -> r.joinToString(",") { csvCell(it) } } + "\r\n"
}

/** Actual amounts recorded by the owner (a provider invoice, a top-up). Stored privately in the app; never leaves the phone unless exported. */
object FinanceStore {
    private const val FILE = "finance_records.tsv"
    private fun file(ctx: Context) = File(ctx.applicationContext.filesDir, FILE)

    @Synchronized fun all(ctx: Context): List<FinanceCore.Expense> = try {
        val f = file(ctx)
        if (!f.isFile) emptyList() else f.readLines().mapNotNull { FinanceCore.decode(it) }.sortedByDescending { it.at }
    } catch (_: Exception) { emptyList() }

    @Synchronized fun add(ctx: Context, e: FinanceCore.Expense): Boolean = try {
        file(ctx).appendText(FinanceCore.encode(e) + "\n")
        AdminAudit.log(ctx, "admin", "Payment recorded", e.provider.take(40))
        true
    } catch (_: Exception) { false }

    @Synchronized fun remove(ctx: Context, e: FinanceCore.Expense): Boolean = try {
        val keep = all(ctx).toMutableList()
        val gone = keep.remove(e)
        if (gone) {
            file(ctx).writeText(keep.sortedBy { it.at }.joinToString("") { FinanceCore.encode(it) + "\n" })
            AdminAudit.log(ctx, "admin", "Payment record deleted", e.provider.take(40))
        }
        gone
    } catch (_: Exception) { false }

    fun budgetUsd(ctx: Context): Double = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getString("finBudgetMonthUsd", "")?.toDoubleOrNull() ?: 0.0
    fun setBudgetUsd(ctx: Context, v: Double) {
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit().putString("finBudgetMonthUsd", v.coerceAtLeast(0.0).toString()).apply()
        AdminAudit.log(ctx, "admin", "Monthly budget changed", if (v > 0) FinanceCore.money(v) else "removed")
    }
}

/** Writes a text file (CSV) to the private share folder and opens the Android share sheet. */
object AdminExport {
    fun shareCsv(ctx: Context, filename: String, text: String, subject: String): String = try {
        val dir = File(ctx.filesDir, "artifacts/_share").also { it.mkdirs() }
        dir.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 24 * 3600 * 1000L) it.delete() }
        File(dir, filename).writeBytes(text.toByteArray(Charsets.UTF_8))
        val uri = Uri.parse("content://" + Artifacts.AUTH + "/" + Uri.encode(filename))
        val i = Intent(Intent.ACTION_SEND).setType("text/csv").putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_SUBJECT, subject)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri(filename, uri)
        ctx.startActivity(Intent.createChooser(i, subject).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        AdminAudit.log(ctx, "admin", "Report exported", filename)
        "Opened the share screen: $filename"
    } catch (e: Exception) { "The file could not be shared: " + (e.message ?: "unknown error") }
}
