package com.anjoo.assistant

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Bundle
import android.os.Process
import android.os.StatFs
import android.os.SystemClock
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * System Monitoring (local mode). Every value is read from this phone right now (battery, storage, memory, network, app
 * uptime, local databases) or from the app's own measured records (model health, tool runs, tasks).
 * Servers, a cloud database and job queues are not connected, so they are listed as such and no number is invented for them.
 * Problems found are written to the audit log (category "system"), at most once an hour per problem.
 */
class MonitorActivity : Activity() {
    override fun attachBaseContext(base: Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private lateinit var theme: CyberTheme
    private lateinit var content: LinearLayout
    private val good = Color.rgb(46, 125, 50)
    private val warn = Color.rgb(230, 126, 0)
    private val bad = Color.rgb(198, 40, 40)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun faint() = Color.argb(70, 128, 128, 128)
    private fun shape(fill: Int, stroke: Int = faint(), radius: Int = 14) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(radius).toFloat()
    }
    private fun label(text: String, size: Float = 14f, color: Int = theme.ink, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private fun card(title: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = shape(theme.surface); setPadding(dp(14), dp(12), dp(14), dp(12))
        addView(label(title, 13f, theme.muted, true))
    }
    private fun gap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    private fun LinearLayout.row(name: String, value: String, color: Int = theme.ink) {
        val r = LinearLayout(this@MonitorActivity)
        r.addView(label(name, 13f, theme.muted), LinearLayout.LayoutParams(0, -2, 1f))
        r.addView(label(value, 13f, color, true).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(0, -2, 1.3f))
        addView(r, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        theme = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        Style.bars(window, theme)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(theme.bg)
            setPadding(dp(14), dp(28), dp(14), dp(10))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("‹", 30f).apply { setPadding(dp(6), 0, dp(18), dp(4)); setOnClickListener { finish() } })
        header.addView(label("System Monitoring", 20f, theme.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("↻", 24f, theme.accent).apply { setPadding(dp(14), 0, dp(6), dp(2)); setOnClickListener { render() } })
        root.addView(header)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        setContentView(root)
        render()
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) render() }

    private fun dirSize(f: File): Long = try {
        if (f.isFile) f.length() else (f.listFiles() ?: emptyArray()).sumOf { dirSize(it) }
    } catch (_: Exception) { 0L }

    private fun render() {
        content.removeAllViews()
        val now = System.currentTimeMillis()

        // ---- real readings ----
        val battIntent: Intent? = try { registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) } catch (_: Exception) { null }
        val level = battIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val battPct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        val status = battIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val tempC = (battIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE) ?: Int.MIN_VALUE).let { if (it == Int.MIN_VALUE) null else it / 10.0 }

        var freeStorage = -1L; var totalStorage = -1L
        try { val sf = StatFs(filesDir.path); freeStorage = sf.availableBytes; totalStorage = sf.totalBytes } catch (_: Exception) { }
        val appData = dirSize(filesDir)

        val mem = ActivityManager.MemoryInfo()
        try { (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mem) } catch (_: Exception) { }
        val rt = Runtime.getRuntime()
        val heapUsed = rt.totalMemory() - rt.freeMemory(); val heapMax = rt.maxMemory()

        var online = false; var netName = "No connection"; var metered = false
        try {
            val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            if (caps != null) {
                online = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
                netName = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile data"
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                    else -> "Other"
                }
                metered = cm.isActiveNetworkMetered
            }
        } catch (_: Exception) { }

        val uptime = SystemClock.elapsedRealtime() - Process.getStartElapsedRealtime()

        // ---- alerts ----
        val alerts = MonitorCore.alerts(battPct, charging, freeStorage, totalStorage, mem.lowMemory, online, heapUsed, heapMax)
        val recent = AdminAudit.entries(this)
        for (a in alerts) if (recent.none { it.category == "system" && it.action == a.action && now - it.at < 3600_000L }) AdminAudit.log(this, "system", a.action, a.detail)

        val head = card("Status")
        if (alerts.isEmpty()) head.addView(label("No problems found on this phone right now.", 14f, good, true).apply { setPadding(0, dp(3), 0, 0) })
        else for (a in alerts) {
            head.addView(label(a.action, 14f, bad, true).apply { setPadding(0, dp(5), 0, 0) })
            head.addView(label(a.detail, 12.5f, theme.muted))
        }
        head.addView(label("Measured " + SimpleDateFormat("d MMM, HH:mm:ss", Locale.getDefault()).format(Date(now)) + ". Tap ↻ to measure again. Problems are written to Security & Audit (system), at most once an hour each.", 11.5f, theme.muted).apply { setPadding(0, dp(6), 0, 0) })
        content.addView(head, LinearLayout.LayoutParams(-1, -2))

        // ---- application ----
        val app = card("Application")
        app.row("Version", try { packageManager.getPackageInfo(packageName, 0).versionName ?: "?" } catch (_: Exception) { "?" })
        app.row("Running for", MonitorCore.duration(uptime))
        app.row("App memory", "${MonitorCore.bytes(heapUsed)} of ${MonitorCore.bytes(heapMax)} (${MonitorCore.pct(heapUsed, heapMax)}%)", if (heapMax > 0 && heapUsed * 100 / heapMax >= 85) bad else theme.ink)
        app.row("App data on disk", MonitorCore.bytes(appData))
        val all = Tasks.all(this)
        var doing = 0
        for (i in 0 until all.length()) if (all.optJSONObject(i)?.optString("status") == "doing") doing++
        app.row("Tasks running now", doing.toString())
        content.addView(app, gap())

        // ---- device ----
        val dev = card("This phone")
        dev.row("Battery", if (battPct < 0) "not available" else "$battPct%" + (if (charging) ", charging" else ""), if (battPct in 0..15 && !charging) bad else theme.ink)
        if (tempC != null) dev.row("Battery temperature", String.format(Locale.US, "%.1f °C", tempC), if (tempC >= 45.0) bad else theme.ink)
        dev.row("Free storage", if (totalStorage > 0) "${MonitorCore.bytes(freeStorage)} of ${MonitorCore.bytes(totalStorage)}" else "not available", if (totalStorage > 0 && (freeStorage * 100 / totalStorage < 10)) bad else theme.ink)
        dev.row("Free memory", if (mem.totalMem > 0) "${MonitorCore.bytes(mem.availMem)} of ${MonitorCore.bytes(mem.totalMem)}" else "not available", if (mem.lowMemory) bad else theme.ink)
        content.addView(dev, gap())

        // ---- network / API availability ----
        val net = card("Network and API availability")
        net.row("Connection", if (online) "$netName, online" else "offline or not verified", if (online) good else bad)
        if (online && metered) net.row("Data plan", "metered connection")
        val health = Router.healthRows()
        if (health.isEmpty()) net.addView(label("No AI model has been called yet, so there is no measured API availability.", 12.5f, theme.muted).apply { setPadding(0, dp(6), 0, 0) })
        for (h in health.take(8)) {
            val fp = MonitorCore.failPct(h.ok, h.fail)
            val c = when { h.resting -> bad; fp >= 30 -> bad; fp >= 10 -> warn; else -> good }
            net.row(h.name, "${h.ok + h.fail} calls · ${fp}% failed · avg ${h.avgMs} ms" + (if (h.resting) " · resting" else ""), c)
        }
        content.addView(net, gap())

        // ---- background work: tool runs ----
        val tools = ToolRunLog.entries(this)
        val tc = card("Tool execution (last ${tools.size} runs)")
        if (tools.isEmpty()) tc.addView(label("No tool has run yet.", 12.5f, theme.muted).apply { setPadding(0, dp(4), 0, 0) })
        else {
            val issues = tools.count { it.status == "ISSUE" }
            val timed = tools.filter { it.durationMs > 0 }
            tc.row("Finished without a problem", (tools.count { it.status == "DONE" }).toString(), good)
            tc.row("Problems", issues.toString(), if (issues > 0) warn else theme.ink)
            tc.row("Needed setup or permission", tools.count { it.status == "SETUP" }.toString())
            tc.row("Average run time", if (timed.isEmpty()) "not measured" else "${timed.sumOf { it.durationMs } / timed.size} ms")
            tc.row("Slowest run", timed.maxByOrNull { it.durationMs }?.let { "${it.name}, ${it.durationMs} ms" } ?: "not measured")
        }
        content.addView(tc, gap())

        // ---- local databases ----
        val dbs = card("Local databases")
        val names = try { databaseList().filter { !it.endsWith("-journal") && !it.endsWith("-wal") && !it.endsWith("-shm") } } catch (_: Exception) { emptyList() }
        if (names.isEmpty()) dbs.addView(label("No database file yet.", 12.5f, theme.muted).apply { setPadding(0, dp(4), 0, 0) })
        for (n in names) dbs.row(n, MonitorCore.bytes(try { getDatabasePath(n).length() } catch (_: Exception) { -1L }))
        content.addView(dbs, gap())

        // ---- honest list of what is not connected ----
        val nc = card("Not connected (no number is shown)")
        nc.addView(label("Cloud server health, cloud database health, job queues and server resource use need a backend (for example Supabase). It is not connected to this app, so these are not monitored and nothing here is simulated.", 12.5f, theme.muted).apply { setPadding(0, dp(4), 0, 0) })
        content.addView(nc, gap())
    }
}
