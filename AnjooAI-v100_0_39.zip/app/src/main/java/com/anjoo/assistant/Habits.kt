package com.anjoo.assistant

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * The routine and habit engine. It quietly remembers WHAT the user does and AT WHAT TIME of day
 * (weather, news, apps, prayer times, tasks, calendar...), and once a pattern is clear (3 different days)
 * it offers a helpful suggestion at the usual time, as a notification and on the home screen.
 * Everything stays on the phone. Limits: a few suggestions per day, none at night, and the user can say
 * "later" or "never" to any of them.
 */
object Habits {
    const val ACT_TICK = "com.anjoo.assistant.HABIT_TICK"
    const val ACT_LATER = "com.anjoo.assistant.HABIT_LATER"
    const val ACT_NEVER = "com.anjoo.assistant.HABIT_NEVER"
    private const val CH = "anjoo_habit"
    private const val DAY = 86400000L

    /** True while the app is on screen: then suggestions show inside the app, not as notifications. */
    @Volatile var appVisible = false

    class Sug(val key: String, val title: String, val prompt: String, val score: Double)

    private fun p(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    fun enabled(ctx: Context) = p(ctx).getBoolean("habits", true) && p(ctx).getBoolean("saveMemory", true)
    fun notifyOn(ctx: Context) = p(ctx).getBoolean("habitNotif", true)

    private fun obj(ctx: Context, k: String): JSONObject =
        try { JSONObject(p(ctx).getString(k, "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    private fun put(ctx: Context, k: String, o: JSONObject) { p(ctx).edit().putString(k, o.toString()).apply() }

    private fun epochDay(): Long {
        val n = System.currentTimeMillis()
        return (n + TimeZone.getDefault().getOffset(n)) / DAY
    }

    private fun zeros(n: Int): JSONArray { val a = JSONArray(); for (i in 0 until n) a.put(0); return a }
    private fun bump(a: JSONArray, i: Int) { a.put(i, a.optInt(i) + 1) }
    private fun tail(a: JSONArray, n: Int): JSONArray {
        val out = JSONArray()
        for (i in maxOf(0, a.length() - n) until a.length()) out.put(a.get(i))
        return out
    }

    private fun whenText(h: Int): String {
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "$h12 " + (if (h < 12) "AM" else "PM")
    }

    // ------------------------------------------------------------------ learning

    /** What to remember about a tool call: (habit key, short label, sentence that repeats it). */
    private fun describe(name: String, a: JSONObject): Triple<String, String, String>? {
        fun s(k: String) = a.optString(k, "").trim().replace(">", " ")
        return when (name) {
            "open_app" -> { val n = s("name"); if (n.isEmpty()) null else Triple("app:" + n.lowercase(Locale.ROOT), "opening " + n, "Open " + n) }
            "weather" -> Triple("weather", "checking the weather", "Tell me today's weather.")
            "news" -> Triple("news", "listening to the news", "Tell me today's latest news.")
            "today_events" -> Triple("events", "checking today's calendar events", "Tell me today's calendar events.")
            "list_tasks" -> Triple("tasks", "viewing the task board", "Show me my tasks.")
            "prayer_times" -> Triple("prayer", "checking prayer times", "Tell me today's prayer times.")
            "ledger_summary" -> Triple("ledger", "viewing the expense summary", "Tell me this month's accounts summary.")
            "play_music" -> { val q = s("query"); if (q.isEmpty()) null else Triple("music:" + q.lowercase(Locale.ROOT).take(30), "playing " + q.take(30), "Play music: " + q) }
            "navigate" -> { val q = s("place"); if (q.isEmpty()) null else Triple("nav:" + q.lowercase(Locale.ROOT).take(30), "directions to " + q.take(30), "Show directions to " + q + ".") }
            "call" -> {
                val t = s("to")
                if (t.isEmpty() || t.any { it.isDigit() }) null else Triple("call:" + t.lowercase(Locale.ROOT).take(30), "calling " + t.take(30), "Call " + t + ".")
            }
            else -> null
        }
    }

    /** Called after every successful tool run (from Actions). */
    @Synchronized
    fun record(ctx: Context, name: String, a: JSONObject) {
        if (!enabled(ctx)) return
        val d = describe(name, a) ?: return
        val now = System.currentTimeMillis()
        val ev = obj(ctx, "habit_events")
        val o = ev.optJSONObject(d.first)
            ?: JSONObject().put("n", 0).put("h", zeros(24)).put("w", zeros(7)).put("d", JSONArray())
        val c = Calendar.getInstance()
        val hour = c.get(Calendar.HOUR_OF_DAY)
        val wd = (c.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Monday = 0
        o.put("l", d.second).put("p", d.third).put("n", o.optInt("n") + 1).put("t", now)
        bump(o.getJSONArray("h"), hour)
        bump(o.getJSONArray("w"), wd)
        val day = epochDay()
        val ds = o.getJSONArray("d")
        if (ds.length() == 0 || ds.getLong(ds.length() - 1) != day) {
            ds.put(day)
            if (ds.length() > 30) o.put("d", tail(ds, 30))
        }
        ev.put(d.first, o)
        if (ev.length() > 60) {
            var oldest: String? = null
            var ot = Long.MAX_VALUE
            for (k in ev.keys()) { val t = ev.getJSONObject(k).optLong("t"); if (t < ot) { ot = t; oldest = k } }
            if (oldest != null) ev.remove(oldest)
        }
        put(ctx, "habit_events", ev)
        notePair(ctx, d.first, now, day)
    }

    /** Two different actions close together (weather, then news) are noted as a pair: a routine in the making. */
    private fun notePair(ctx: Context, key: String, now: Long, day: Long) {
        val rec = obj(ctx, "habit_recent")
        val last = rec.optString("k", "")
        val lt = rec.optLong("t", 0L)
        if (last.isNotEmpty() && last != key && now - lt in 1..(15 * 60 * 1000L)) {
            val pairs = obj(ctx, "habit_pairs")
            val pk = "$last>$key"
            val po = pairs.optJSONObject(pk) ?: JSONObject().put("n", 0).put("d", JSONArray())
            po.put("n", po.optInt("n") + 1)
            val ds = po.getJSONArray("d")
            if (ds.length() == 0 || ds.getLong(ds.length() - 1) != day) {
                ds.put(day)
                if (ds.length() > 30) po.put("d", tail(ds, 30))
            }
            pairs.put(pk, po)
            if (pairs.length() > 40) pairs.remove(pairs.keys().next())
            put(ctx, "habit_pairs", pairs)
        }
        put(ctx, "habit_recent", JSONObject().put("k", key).put("t", now))
    }

    // ------------------------------------------------------------------ reading the patterns

    private fun strong(o: JSONObject, today: Long): Boolean {
        if (o.optInt("n") < 3) return false
        val ds = o.getJSONArray("d")
        var c = 0
        for (i in 0 until ds.length()) if (ds.getLong(i) >= today - 21) c++
        return c >= 3
    }

    /** The hour of day this is usually done around, or null when there is no clear time. */
    private fun peakHour(o: JSONObject): Int? {
        val h = o.getJSONArray("h")
        var total = 0
        for (i in 0 until 24) total += h.optInt(i)
        if (total < 3) return null
        var best = -1
        var bestSum = 0
        for (i in 0 until 24) {
            val s = h.optInt((i + 23) % 24) + h.optInt(i) + h.optInt((i + 1) % 24)
            if (s > bestSum) { bestSum = s; best = i }
        }
        return if (best >= 0 && bestSum >= 3 && bestSum * 100 >= total * 55) best else null
    }

    private fun lastDay(o: JSONObject): Long {
        val ds = o.getJSONArray("d")
        return if (ds.length() == 0) 0L else ds.getLong(ds.length() - 1)
    }

    /** Something only done on weekdays is not suggested on a weekend, and the other way round. */
    private fun dayFits(o: JSONObject, cal: Calendar): Boolean {
        val w = o.getJSONArray("w")
        var wk = 0
        var we = 0
        for (i in 0 until 5) wk += w.optInt(i)
        for (i in 5 until 7) we += w.optInt(i)
        val total = wk + we
        if (total == 0) return true
        val weekendToday = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 >= 5
        if (!weekendToday && we * 100 >= total * 85) return false
        if (weekendToday && wk * 100 >= total * 85) return false
        return true
    }

    private fun morningHour(ev: JSONObject, today: Long): Int? {
        val sum = IntArray(24)
        val days = HashSet<Long>()
        for (k in listOf("weather", "news", "events", "tasks")) {
            val o = ev.optJSONObject(k) ?: continue
            val h = o.getJSONArray("h")
            for (i in 0 until 24) sum[i] += h.optInt(i)
            val ds = o.getJSONArray("d")
            for (i in 0 until ds.length()) if (ds.getLong(i) >= today - 21) days.add(ds.getLong(i))
        }
        var total = 0
        for (v in sum) total += v
        var best = 5
        var morning = 0
        for (i in 5..10) { morning += sum[i]; if (sum[i] > sum[best]) best = i }
        return if (days.size >= 3 && morning >= 3 && morning * 2 >= total) best else null
    }

    private fun parseDue(s: String): Long? {
        val t = s.trim()
        if (t.isEmpty()) return null
        if (t.equals("aaj", true) || t.equals("today", true)) return epochDay()
        for (f in listOf("yyyy-MM-dd", "dd/MM/yyyy", "dd-MM-yyyy")) {
            try {
                val df = SimpleDateFormat(f, Locale.US)
                df.isLenient = false
                val d = df.parse(t) ?: continue
                return (d.time + TimeZone.getDefault().getOffset(d.time)) / DAY
            } catch (e: Exception) {}
        }
        return null
    }

    private fun isDone(st: JSONObject, key: String) = st.optJSONObject("done")?.has(key) == true

    // ------------------------------------------------------------------ suggestions

    /**
     * What Anjoo could helpfully offer right now, best first. [forNotif] additionally hides anything
     * that was already pushed as a notification in the last 20 hours.
     */
    fun suggest(ctx: Context, forNotif: Boolean): List<Sug> {
        if (!enabled(ctx)) return emptyList()
        val out = ArrayList<Sug>()
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()
        val hourNow = cal.get(Calendar.HOUR_OF_DAY)
        val minutes = hourNow * 60 + cal.get(Calendar.MINUTE)
        val today = epochDay()
        val st = obj(ctx, "habit_state")
        val ev = obj(ctx, "habit_events")

        // 1) things the user usually does around this time of day
        for (k in ev.keys()) {
            val o = ev.getJSONObject(k)
            if (!strong(o, today)) continue
            val peak = peakHour(o) ?: continue
            if (lastDay(o) == today) continue
            if (!dayFits(o, cal)) continue
            val start = peak * 60
            if (minutes < start - 20 || minutes > start + 100) continue
            val lead = "Around " + whenText(peak) + ","
            out.add(Sug("h:$k", lead + " you often do this: " + o.optString("l") + ". Do it now?", o.optString("p"), 5.0 + minOf(o.optInt("n"), 30) / 30.0))
        }

        // 2) a daily briefing the user seems to want but has not set
        if ((p(ctx).getString("briefTime", "") ?: "").isEmpty() && !isDone(st, "s:brief")) {
            val m = morningHour(ev, today)
            if (m != null) {
                out.add(Sug("s:brief", "You check the weather or news in the morning. Set a daily briefing at " + whenText(m) + "?",
                    "Set my daily briefing every morning at " + "%02d:00".format(m) + ".", 6.0))
            }
        }

        // 3) prayer reminders for someone who keeps checking prayer times
        val pr = ev.optJSONObject("prayer")
        if (pr != null && pr.optInt("n") >= 2 && (p(ctx).getString("prayerCity", "") ?: "").isEmpty() && !isDone(st, "s:prayer")) {
            out.add(Sug("s:prayer", "You keep checking prayer times. Set a reminder for every prayer?",
                "Set prayer reminders for my city.", 5.5))
        }

        // 4) the next prayer is close
        try {
            val rem = Reminders.list(ctx)
            for (i in 0 until rem.length()) {
                val r = rem.getJSONObject(i)
                if (r.optString("kind") != "prayer") continue
                val at = r.optLong("at")
                val left = at - now
                if (left >= 5 * 60 * 1000L && left <= 30 * 60 * 1000L) {
                    val hm = SimpleDateFormat("h:mm", Locale.US).format(Date(at))
                    out.add(Sug("p:" + r.optInt("id"), r.optString("text") + " is at " + hm + " (in " + (left / 60000) + " minutes).",
                        "Tell me today's prayer times.", 7.0))
                }
            }
        } catch (e: Exception) {}

        // 5) tasks that are due, and an evening look at what is left
        try {
            val ts = Tasks.all(ctx)
            var open = 0
            for (i in 0 until ts.length()) {
                val t = ts.getJSONObject(i)
                if (t.optString("status") == "done") continue
                open++
                val due = parseDue(t.optString("due"))
                if (due != null && due <= today) {
                    out.add(Sug("t:" + t.optInt("id") + ":" + today,
                        "Task #" + t.optInt("id") + " \"" + t.optString("title").take(40) + "\" " + (if (due < today) "is overdue." else "is due today."),
                        "Show me my tasks.", 8.0))
                }
            }
            if (open > 0 && hourNow in 17..20) {
                out.add(Sug("t:eve:$today", "You still have " + open + " task(s) left today. Take a look?", "Show me my remaining tasks.", 4.0))
            }
        } catch (e: Exception) {}

        // 6) two things done together again and again: offer to save them as one routine
        val pairs = obj(ctx, "habit_pairs")
        for (pk in pairs.keys()) {
            val po = pairs.getJSONObject(pk)
            val ds = po.getJSONArray("d")
            var recent = 0
            for (i in 0 until ds.length()) if (ds.getLong(i) >= today - 21) recent++
            if (po.optInt("n") < 3 || recent < 3 || isDone(st, "r:$pk")) continue
            val ab = pk.split(">")
            if (ab.size != 2) continue
            val ea = ev.optJSONObject(ab[0]) ?: continue
            val eb = ev.optJSONObject(ab[1]) ?: continue
            out.add(Sug("r:$pk", "You often do \"" + eb.optString("l") + "\" after \"" + ea.optString("l") + "\". Make them one routine?",
                "Save a routine (ask me for the name) that first does: " + ea.optString("p") + " then: " + eb.optString("p"), 4.5))
        }

        val snooze = st.optJSONObject("snooze") ?: JSONObject()
        val shown = st.optJSONObject("shown") ?: JSONObject()
        return out.filter { s ->
            snooze.optLong(s.key, 0L) <= now && !(forNotif && now - shown.optLong(s.key, 0L) < 20 * 3600 * 1000L)
        }.sortedByDescending { it.score }
    }

    // ------------------------------------------------------------------ user feedback

    private fun stamp(st: JSONObject, group: String, key: String, v: Long) {
        val g = st.optJSONObject(group) ?: JSONObject()
        g.put(key, v)
        st.put(group, g)
    }

    /** The user followed a suggestion. One-time offers are never repeated; habits rest for half a day. */
    @Synchronized
    fun accept(ctx: Context, key: String) {
        val st = obj(ctx, "habit_state")
        if (key.startsWith("s:") || key.startsWith("r:")) stamp(st, "done", key, 1L)
        else stamp(st, "snooze", key, System.currentTimeMillis() + 12 * 3600 * 1000L)
        put(ctx, "habit_state", st)
    }

    @Synchronized
    fun snooze(ctx: Context, key: String, ms: Long) {
        val st = obj(ctx, "habit_state")
        stamp(st, "snooze", key, System.currentTimeMillis() + ms)
        put(ctx, "habit_state", st)
    }

    /** "Do not show again": rests for two weeks, and after the third time for good. */
    @Synchronized
    fun dismiss(ctx: Context, key: String) {
        val st = obj(ctx, "habit_state")
        val n = (st.optJSONObject("never")?.optInt(key, 0) ?: 0) + 1
        stamp(st, "never", key, n.toLong())
        stamp(st, "snooze", key, System.currentTimeMillis() + if (n >= 3) 3650L * DAY else 14L * DAY)
        put(ctx, "habit_state", st)
    }

    @Synchronized
    fun clear(ctx: Context) {
        p(ctx).edit().remove("habit_events").remove("habit_pairs").remove("habit_recent").remove("habit_state").apply()
    }

    // ------------------------------------------------------------------ for the AI and for the settings screen

    /** One line for the AI's instructions, so it can gently mention a routine in conversation. */
    fun promptLine(ctx: Context): String {
        if (!enabled(ctx)) return ""
        val today = epochDay()
        val ev = obj(ctx, "habit_events")
        val items = ArrayList<Pair<Int, String>>()
        for (k in ev.keys()) {
            val o = ev.getJSONObject(k)
            if (!strong(o, today)) continue
            val pk = peakHour(o) ?: continue
            items.add(Pair(o.optInt("n"), whenText(pk) + " " + o.optString("l")))
        }
        if (items.isEmpty()) return ""
        val top = items.sortedByDescending { it.first }.take(4).joinToString("; ") { it.second }
        return "USER HABITS (learned automatically, only a hint): " + top +
            ". At a suitable moment you may give a short friendly suggestion (for example reminding them of that task at that time), but never pushy or repeated.\n"
    }

    fun summaryText(ctx: Context): String {
        val today = epochDay()
        val ev = obj(ctx, "habit_events")
        if (ev.length() == 0) {
            return "Nothing learned yet. As you use Anjoo (weather, news, apps, prayers, tasks), " +
                "your habits will appear here. All of this stays only on this phone."
        }
        val rows = ArrayList<Pair<Int, String>>()
        for (k in ev.keys()) {
            val o = ev.getJSONObject(k)
            val pk = if (strong(o, today)) peakHour(o) else null
            rows.add(Pair(o.optInt("n"), "• " + o.optString("l") + " — " + o.optInt("n") + " times" + (if (pk != null) ", often " + whenText(pk) else "")))
        }
        val sb = StringBuilder()
        for (r in rows.sortedByDescending { it.first }.take(12)) sb.append(r.second).append('\n')
        sb.append("\nA suggestion appears when something was done at about the same time on 3 different days. All of this stays only on this phone.")
        return sb.toString()
    }

    // ------------------------------------------------------------------ delivery

    /** Checks every ~30 minutes (only while the phone is awake) whether a suggestion is worth a notification. */
    fun schedule(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val pi = PendingIntent.getBroadcast(
                ctx, 4242, Intent(ctx, HabitReceiver::class.java).setAction(ACT_TICK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            am.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + 10 * 60 * 1000L, 30 * 60 * 1000L, pi)
        } catch (e: Exception) {}
    }

    fun tick(ctx: Context) {
        if (!enabled(ctx) || !notifyOn(ctx) || appVisible) return
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (h < 7 || h >= 22) return // quiet hours
        val s = suggest(ctx, true).firstOrNull() ?: return
        synchronized(this) {
            val st = obj(ctx, "habit_state")
            val today = epochDay()
            if (st.optLong("day") != today) st.put("day", today).put("sent", 0)
            if (st.optInt("sent") >= p(ctx).getInt("habitMax", 3)) { put(ctx, "habit_state", st); return }
            stamp(st, "shown", s.key, System.currentTimeMillis())
            st.put("sent", st.optInt("sent") + 1)
            put(ctx, "habit_state", st)
        }
        post(ctx, s)
    }

    private fun post(ctx: Context, s: Sug) {
        try {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH, "Anjoo mashware", NotificationManager.IMPORTANCE_DEFAULT))
            val id = 7000 + (Math.abs(s.key.hashCode()) % 900)
            val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            val go = PendingIntent.getActivity(
                ctx, id,
                Intent(ctx, MainActivity::class.java)
                    .putExtra("habit_prompt", s.prompt).putExtra("habit_key", s.key)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                flags
            )
            fun act(action: String, code: Int) = PendingIntent.getBroadcast(
                ctx, id * 3 + code,
                Intent(ctx, HabitReceiver::class.java).setAction(action).putExtra("key", s.key).putExtra("nid", id), flags
            )
            val n = Notification.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("Anjoo suggests")
                .setContentText(s.title)
                .setStyle(Notification.BigTextStyle().bigText(s.title))
                .setContentIntent(go)
                .setAutoCancel(true)
                .addAction(Notification.Action.Builder(Icon.createWithResource(ctx, android.R.drawable.ic_menu_send), "Yes, do it", go).build())
                .addAction(Notification.Action.Builder(Icon.createWithResource(ctx, android.R.drawable.ic_menu_recent_history), "Later", act(ACT_LATER, 1)).build())
                .addAction(Notification.Action.Builder(Icon.createWithResource(ctx, android.R.drawable.ic_menu_close_clear_cancel), "Never again", act(ACT_NEVER, 2)).build())
                .build()
            nm.notify(id, n)
        } catch (e: Exception) {}
    }
}

class HabitReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val key = intent.getStringExtra("key") ?: ""
        when (intent.action) {
            Habits.ACT_TICK -> try { Habits.tick(ctx) } catch (e: Exception) {}
            Habits.ACT_LATER -> { Habits.snooze(ctx, key, 3 * 3600 * 1000L); close(ctx, intent) }
            Habits.ACT_NEVER -> { Habits.dismiss(ctx, key); close(ctx, intent) }
        }
    }

    private fun close(ctx: Context, intent: Intent) {
        try { ctx.getSystemService(NotificationManager::class.java).cancel(intent.getIntExtra("nid", 0)) } catch (e: Exception) {}
    }
}
