package com.anjoo.assistant

/**
 * Extra starter templates for project_template: FastAPI, React + Vite,
 * Flutter and Android (Jetpack Compose). Raw strings are used so the files
 * stay readable. No dollar signs are used inside the content on purpose.
 */
object StarterTemplates {

    /** Short names the model or the user may type -> real template key. */
    val ALIASES: Map<String, String> = mapOf(
        "react" to "react_vite", "vite" to "react_vite", "reactvite" to "react_vite",
        "vite_react" to "react_vite",
        "fast_api" to "fastapi", "api" to "fastapi",
        "android" to "android_compose", "compose" to "android_compose",
        "jetpack_compose" to "android_compose", "android_kotlin" to "android_compose"
    )

    val ALL: Map<String, List<Pair<String, String>>> = mapOf(
        "fastapi" to listOf(
            "main.py" to """
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app = FastAPI(title="My API")

ITEMS: dict[int, dict] = {}


class ItemIn(BaseModel):
    name: str
    price: float = 0.0


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/items", status_code=201)
def create_item(item: ItemIn):
    new_id = len(ITEMS) + 1
    ITEMS[new_id] = {"id": new_id, "name": item.name, "price": item.price}
    return ITEMS[new_id]


@app.get("/items/{item_id}")
def get_item(item_id: int):
    if item_id not in ITEMS:
        raise HTTPException(status_code=404, detail="item not found")
    return ITEMS[item_id]
""".trimStart(),
            "test_main.py" to """
from fastapi.testclient import TestClient

from main import app, ITEMS

client = TestClient(app)


def setup_function():
    ITEMS.clear()


def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


def test_create_and_get_item():
    r = client.post("/items", json={"name": "pen", "price": 2.5})
    assert r.status_code == 201
    item_id = r.json()["id"]
    r = client.get("/items/" + str(item_id))
    assert r.status_code == 200
    assert r.json()["name"] == "pen"


def test_missing_item_is_404():
    assert client.get("/items/99").status_code == 404
""".trimStart(),
            "requirements.txt" to "fastapi\nuvicorn[standard]\nhttpx\npytest\n",
            ".gitignore" to "__pycache__/\n*.pyc\n.venv/\n.env\n.pytest_cache/\n",
            "README.md" to """
# FastAPI project

Install: `pip install -r requirements.txt`

Run: `uvicorn main:app --reload` then open http://127.0.0.1:8000/docs

Test: `pytest`

Note: FastAPI needs a real Python (not Pyodide), so run and test it on a PC, server or CI.
""".trimStart()
        ),

        "react_vite" to listOf(
            "package.json" to """
{
  "name": "my-react-app",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "test": "vitest run"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.1",
    "vite": "^5.4.0",
    "vitest": "^2.0.5"
  }
}
""".trimStart(),
            "vite.config.js" to """
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  base: './'
})
""".trimStart(),
            "index.html" to """
<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>My React App</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.jsx"></script>
  </body>
</html>
""".trimStart(),
            "src/main.jsx" to """
import React from 'react'
import { createRoot } from 'react-dom/client'
import App from './App.jsx'
import './App.css'

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
""".trimStart(),
            "src/App.jsx" to """
import { useState } from 'react'
import { nextCount } from './counter.js'

export default function App() {
  const [count, setCount] = useState(0)
  return (
    <main>
      <h1>My React App</h1>
      <button onClick={() => setCount(nextCount(count))}>
        Clicked {count} times
      </button>
    </main>
  )
}
""".trimStart(),
            "src/counter.js" to "export function nextCount(n) {\n  return n + 1\n}\n",
            "src/counter.test.js" to """
import { describe, it, expect } from 'vitest'
import { nextCount } from './counter.js'

describe('nextCount', () => {
  it('adds one', () => {
    expect(nextCount(0)).toBe(1)
    expect(nextCount(41)).toBe(42)
  })
})
""".trimStart(),
            "src/App.css" to """
:root { --bg: #faf9f5; --ink: #1f1e1d; --accent: #c96442; }
* { box-sizing: border-box; }
body { margin: 0; font-family: system-ui, sans-serif; background: var(--bg); color: var(--ink); }
main { max-width: 640px; margin: 0 auto; padding: 24px 16px; }
button { background: var(--accent); color: #fff; border: 0; border-radius: 12px; padding: 10px 18px; font-size: 16px; }
""".trimStart(),
            ".gitignore" to "node_modules/\ndist/\n.env\n*.log\n.DS_Store\n",
            "README.md" to """
# React + Vite project

Install: `npm install`

Dev server: `npm run dev`

Test: `npm test`

Build: `npm run build` (output in `dist/`)
""".trimStart()
        ),

        "flutter" to listOf(
            "pubspec.yaml" to """
name: my_app
description: A new Flutter project.
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.3.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^4.0.0

flutter:
  uses-material-design: true
""".trimStart(),
            "analysis_options.yaml" to "include: package:flutter_lints/flutter.yaml\n",
            "lib/main.dart" to """
import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFC96442)),
        useMaterial3: true,
      ),
      home: const CounterPage(),
    );
  }
}

class CounterPage extends StatefulWidget {
  const CounterPage({super.key});

  @override
  State<CounterPage> createState() => _CounterPageState();
}

class _CounterPageState extends State<CounterPage> {
  int _count = 0;

  void _increment() => setState(() => _count++);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('My App')),
      body: Center(
        child: Text('Count: ' + _count.toString(),
            style: Theme.of(context).textTheme.headlineMedium),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _increment,
        tooltip: 'Add',
        child: const Icon(Icons.add),
      ),
    );
  }
}
""".trimStart(),
            "test/widget_test.dart" to """
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter/material.dart';
import 'package:my_app/main.dart';

void main() {
  testWidgets('counter increments', (WidgetTester tester) async {
    await tester.pumpWidget(const MyApp());
    expect(find.text('Count: 0'), findsOneWidget);

    await tester.tap(find.byIcon(Icons.add));
    await tester.pump();

    expect(find.text('Count: 1'), findsOneWidget);
  });
}
""".trimStart(),
            ".gitignore" to ".dart_tool/\n.packages\nbuild/\n.flutter-plugins\n.flutter-plugins-dependencies\n*.iml\n.idea/\n.DS_Store\n",
            "README.md" to """
# Flutter project

This starter has `lib/`, `test/` and `pubspec.yaml`. The platform folders
(android/, ios/ ...) are not included. Create them once on a machine with
Flutter installed:

    flutter create --project-name my_app .

Then:

- Run: `flutter run`
- Test: `flutter test`
- Analyze: `flutter analyze`
""".trimStart()
        ),

        "android_compose" to listOf(
            "settings.gradle.kts" to """
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "MyApp"
include(":app")
""".trimStart(),
            "build.gradle.kts" to """
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
""".trimStart(),
            "gradle.properties" to "org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8\nandroid.useAndroidX=true\nkotlin.code.style=official\nandroid.nonTransitiveRClass=true\n",
            "app/build.gradle.kts" to """
plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.myapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.myapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        compose = true
    }
    composeOptions {
        // 1.5.14 matches Kotlin 1.9.24
        kotlinCompilerExtensionVersion = "1.5.14"
    }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui-tooling-preview")
    debugImplementation("androidx.compose.ui:ui-tooling")

    testImplementation("junit:junit:4.13.2")
}
""".trimStart(),
            "app/src/main/AndroidManifest.xml" to """
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.MyApp">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
""".trimStart(),
            "app/src/main/java/com/example/myapp/MainActivity.kt" to """
package com.example.myapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    CounterScreen()
                }
            }
        }
    }
}

@Composable
fun CounterScreen() {
    var count by rememberSaveable { mutableIntStateOf(0) }
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Count: " + count)
        Button(onClick = { count = nextCount(count) }) {
            Text("Add")
        }
    }
}

fun nextCount(n: Int): Int = n + 1
""".trimStart(),
            "app/src/test/java/com/example/myapp/CounterTest.kt" to """
package com.example.myapp

import org.junit.Assert.assertEquals
import org.junit.Test

class CounterTest {
    @Test
    fun nextCount_addsOne() {
        assertEquals(1, nextCount(0))
        assertEquals(42, nextCount(41))
    }
}
""".trimStart(),
            "app/src/main/res/values/strings.xml" to "<resources>\n    <string name=\"app_name\">MyApp</string>\n</resources>\n",
            "app/src/main/res/values/themes.xml" to "<resources>\n    <style name=\"Theme.MyApp\" parent=\"android:Theme.Material.Light.NoActionBar\" />\n</resources>\n",
            ".gitignore" to "*.iml\n.gradle/\n/local.properties\n/.idea/\n.DS_Store\nbuild/\n/captures\n.externalNativeBuild/\n.cxx/\n*.jks\nkeystore.properties\n",
            "README.md" to """
# Android (Jetpack Compose) project

Kotlin + Compose + Material 3. Change the package `com.example.myapp`
(in app/build.gradle.kts, the manifest and the folders) before publishing.

The Gradle wrapper (gradlew, gradle/wrapper) is not included. Create it with
`gradle wrapper` or open the folder in Android Studio.

- Debug APK: `./gradlew assembleDebug`
- Unit tests: `./gradlew testDebugUnitTest`
""".trimStart()
        )
    )
}
