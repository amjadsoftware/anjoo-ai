package com.anjoo.assistant

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * project_deploy: publish a static Code Studio project to Netlify, Vercel, Cloudflare Pages or GitHub Pages, and keep
 * environment variables (secrets) on the host. Secret files (.env, keystores ...) are never uploaded. Secret VALUES are
 * never printed or returned to the AI: env_push reads them from the project's .env file on the phone and sends them
 * straight to the host over HTTPS.
 *
 * Actions: status, token_check, publish, deploys, env_list, env_set, env_push, env_delete.
 * Limits: static sites only (no build step on the phone); env vars only matter for sites that have serverless functions or
 * a build on the host; GitHub Actions secrets are not supported (they need libsodium).
 */
object Deploy {

    private const val NETLIFY = "https://api.netlify.com/api/v1"
    private const val VERCEL = "https://api.vercel.com"
    private const val CF = "https://api.cloudflare.com/client/v4"
    private val JSON = "application/json".toMediaType()

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).writeTimeout(120, TimeUnit.SECONDS).build()
    }

    // ============================================================ tokens (kept on the phone only)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    fun vercelToken(ctx: Context): String = prefs(ctx).getString("vercelToken", "").orEmpty()
    fun cfToken(ctx: Context): String = prefs(ctx).getString("cloudflareDeployToken", "").orEmpty()
    fun cfAccount(ctx: Context): String = prefs(ctx).getString("cloudflareAccountId", "").orEmpty()
    fun saveVercel(ctx: Context, t: String) { prefs(ctx).edit().putString("vercelToken", t.trim()).apply() }
    fun saveCloudflare(ctx: Context, token: String, account: String) {
        prefs(ctx).edit().putString("cloudflareDeployToken", token.trim()).putString("cloudflareAccountId", account.trim()).apply()
    }
    private fun has(ctx: Context, p: String): Boolean = when (p) {
        "netlify" -> SitePublisher.hasToken(ctx)
        "vercel" -> vercelToken(ctx).isNotBlank()
        "cloudflare" -> cfToken(ctx).isNotBlank() && cfAccount(ctx).isNotBlank()
        "github" -> GitHubPages.hasToken(ctx)
        else -> false
    }
    fun hasAnyToken(ctx: Context): Boolean = PROVIDERS.any { has(ctx, it) }

    private val PROVIDERS = listOf("netlify", "vercel", "cloudflare", "github")
    private fun title(p: String) = when (p) { "netlify" -> "Netlify"; "vercel" -> "Vercel"; "cloudflare" -> "Cloudflare Pages"; else -> "GitHub Pages" }
    private fun norm(raw: String): String = when (raw.trim().lowercase().replace('-', '_').replace(' ', '_')) {
        "netlify" -> "netlify"
        "vercel" -> "vercel"
        "cloudflare", "cloudflare_pages", "pages", "cf" -> "cloudflare"
        "github", "github_pages", "gh", "gh_pages" -> "github"
        else -> ""
    }
    private fun tokenHelp(p: String) = when (p) {
        "netlify" -> "Netlify token missing. Ask the user to open Settings > Deploy tokens and paste a Netlify personal access token. Never ask them to type it in chat."
        "vercel" -> "Vercel token missing. Ask the user to open Settings > Deploy tokens and paste a Vercel token (vercel.com/account/tokens). Never ask them to type it in chat."
        "cloudflare" -> "Cloudflare token or Account ID missing. Ask the user to open Settings > Deploy tokens and paste a Cloudflare API token (permission: Account > Cloudflare Pages > Edit) and the Account ID. Never ask them to type them in chat."
        else -> "No GitHub token. Ask the user to open Settings > GitHub token."
    }

    // ============================================================ http helpers

    private class Res(val code: Int, val body: String) {
        val ok get() = code in 200..299
        fun json(): JSONObject = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
        fun arr(): JSONArray = try { JSONArray(body) } catch (_: Exception) { JSONArray() }
    }

    private fun call(method: String, url: String, token: String, body: RequestBody? = null, headers: Map<String, String> = emptyMap()): Res {
        val rb = body ?: if (method == "GET" || method == "DELETE") null else "".toRequestBody(JSON)
        val b = Request.Builder().url(url).method(method, rb).header("Authorization", "Bearer $token")
        for ((k, v) in headers) b.header(k, v)
        return http.newCall(b.build()).execute().use { r -> Res(r.code, r.body?.string().orEmpty()) }
    }

    private fun jbody(o: Any): RequestBody = o.toString().toRequestBody(JSON)

    /** Short readable reason from any of the three APIs. Never contains a token. */
    private fun reason(r: Res): String {
        val j = r.json()
        val cf = j.optJSONArray("errors")?.optJSONObject(0)?.optString("message").orEmpty()
        val vc = j.optJSONObject("error")?.optString("message").orEmpty()
        val nl = j.optString("message")
        return (cf.ifBlank { vc }.ifBlank { nl }).ifBlank { r.body.take(160) }.take(200)
    }

    private fun ensure(p: String, r: Res, what: String): Res {
        if (r.ok) return r
        if (r.code == 401) throw IllegalStateException("${title(p)} token is wrong or expired. Set a new one in Settings > Deploy tokens.")
        if (r.code == 403) throw IllegalStateException("${title(p)} refused $what (403): ${reason(r)}. The token lacks permission.")
        throw IllegalStateException("${title(p)} error ${r.code} ($what): ${reason(r)}")
    }

    private fun cfOk(r: Res, what: String): JSONObject {
        ensure("cloudflare", r, what)
        val j = r.json()
        if (!j.optBoolean("success", true)) throw IllegalStateException("Cloudflare error ($what): ${reason(r)}")
        return j
    }

    // ============================================================ entry point

    fun run(ctx: Context, confirm: (String) -> Boolean, a: JSONObject, find: () -> Pair<File?, String>): String {
        val action = a.optString("action", "status").trim().lowercase().replace('-', '_').replace(' ', '_')
        return try {
            when (action) {
                "token_check", "test", "whoami" -> selfTest(ctx)
                "status", "providers" -> status(ctx, find().first)
                else -> {
                    val (dir, err) = find()
                    if (dir == null) return err
                    when (action) {
                        "publish", "deploy" -> publish(ctx, confirm, dir, a)
                        "deploys", "history", "list" -> deploys(ctx, dir, a)
                        "env_list", "env", "envs" -> envList(ctx, dir, a)
                        "env_set", "env_add" -> envSet(ctx, confirm, dir, a)
                        "env_push", "env_sync" -> envPush(ctx, confirm, dir, a)
                        "env_delete", "env_remove", "env_unset" -> envDelete(ctx, confirm, dir, a)
                        else -> "project_deploy action chunein: status, token_check, publish, deploys, env_list, env_set, env_push, env_delete."
                    }
                }
            }
        } catch (e: IllegalStateException) { "Deploy nakam: " + (e.message ?: "error")
        } catch (e: java.io.IOException) { "Deploy nakam: network problem (" + (e.message ?: "io") + "). Check the internet and try again."
        }
    }

    // ============================================================ status / test

    private fun urlKey(p: String, dir: File) = "deployUrl_${p}_${dir.name}"
    private fun projKey(p: String, dir: File) = "deployProj_${p}_${dir.name}"

    private fun linked(ctx: Context, dir: File?): List<String> {
        if (dir == null) return emptyList()
        return PROVIDERS.filter { prefs(ctx).getString(urlKey(it, dir), "").orEmpty().isNotBlank() }
    }

    private fun status(ctx: Context, dir: File?): String {
        val sb = StringBuilder("DEPLOY STATUS\n")
        for (p in PROVIDERS) {
            sb.append("• ").append(title(p)).append(": ").append(if (has(ctx, p)) "token saved" else "no token (Settings > Deploy tokens)")
            if (dir != null) prefs(ctx).getString(urlKey(p, dir), "").orEmpty().takeIf { it.isNotBlank() }?.let { sb.append(" · last published: ").append(it) }
            sb.append('\n')
        }
        sb.append("Publishing sends the project's files (never .env or key files) to a public address. Static sites only.")
        return sb.toString()
    }

    fun selfTest(ctx: Context): String {
        val sb = StringBuilder()
        fun line(p: String, f: () -> String) {
            if (!has(ctx, p)) { sb.append(title(p)).append(": no token\n"); return }
            sb.append(title(p)).append(": ").append(try { f() } catch (e: Exception) { "FAILED (" + (e.message ?: "error").take(120) + ")" }).append('\n')
        }
        line("netlify") { val r = ensure("netlify", call("GET", "$NETLIFY/user", netlifyToken(ctx)), "login"); "OK (" + r.json().optString("email").ifBlank { "account" } + ")" }
        line("vercel") { val r = ensure("vercel", call("GET", "$VERCEL/v2/user", vercelToken(ctx)), "login"); "OK (" + r.json().optJSONObject("user")?.optString("username").orEmpty() + ")" }
        line("cloudflare") {
            val j = cfOk(call("GET", "$CF/accounts/${cfAccount(ctx)}/pages/projects?per_page=1", cfToken(ctx)), "login")
            "OK (Pages access works, " + (j.optJSONArray("result")?.length() ?: 0) + " project(s) seen)"
        }
        line("github") { Git.selfTest(ctx) }
        return sb.toString().trim()
    }

    private fun netlifyToken(ctx: Context) = prefs(ctx).getString("netlifyToken", "").orEmpty()

    // ============================================================ publish

    private fun pickProvider(ctx: Context, dir: File, a: JSONObject): String {
        val given = a.optString("provider", "")
        if (given.isNotBlank()) return norm(given).ifEmpty { throw IllegalStateException("provider chunein: netlify, vercel, cloudflare, github.") }
        val l = linked(ctx, dir)
        if (l.size == 1) return l[0]
        val tokens = PROVIDERS.filter { has(ctx, it) }
        if (tokens.size == 1) return tokens[0]
        throw IllegalStateException(
            if (tokens.isEmpty()) "No deploy token saved. Ask the user to open Settings > Deploy tokens (Netlify, Vercel or Cloudflare) or Settings > GitHub token."
            else "More than one host is possible (" + tokens.joinToString(", ") + "). Ask the user which one, then call again with provider=."
        )
    }

    private fun publish(ctx: Context, confirm: (String) -> Boolean, dir: File, a: JSONObject): String {
        val p = pickProvider(ctx, dir, a)
        if (!has(ctx, p)) return tokenHelp(p)
        if (PreviewServer.entry(dir) == null) return "This project has no index page. Deploy supports static sites (index.html); add one first."
        val c = DeployCore.collect(dir)
        if (c.files.isEmpty()) return "The project has no publishable files."
        if (c.files.size > DeployCore.MAX_FILES) return "The project has ${c.files.size} files; the limit is ${DeployCore.MAX_FILES}."
        if (c.tooBig.isNotEmpty()) return "These files are over 25 MB and cannot be published: " + c.tooBig.take(5).joinToString(", ") + ". Remove or shrink them."
        val total = c.files.sumOf { it.length() }
        if (total > DeployCore.MAX_TOTAL) return "The files add up to ${DeployCore.kb(total)}; the limit is ${DeployCore.kb(DeployCore.MAX_TOTAL)}."

        // Anything that looks like a real key inside a PUBLIC site is a leak: stop unless the user said it is fine.
        if (!a.optBoolean("allow_secrets", false)) {
            val texts = HashMap<String, String>()
            for (f in c.files) if (f.length() <= 1_500_000) {
                val rel = f.relativeTo(dir).path.replace('\\', '/')
                val ext = rel.substringAfterLast('.', "").lowercase()
                if (ext in setOf("html", "htm", "js", "mjs", "css", "json", "txt", "md", "xml", "svg", "ts", "yml", "yaml", "toml")) texts[rel] = f.readText()
            }
            val hits = SecretScan.scanAll(texts).filter { it.sev != SecretScan.Sev.MEDIUM }
            if (hits.isNotEmpty())
                return "PUBLISH BLOCKED: this site would show " + hits.size + " secret(s) to everyone.\n" +
                    SecretScan.report(Coder.name(dir), texts, 10) +
                    "\nMove them to a server-side function or env var, revoke the leaked keys, then publish again. Only if the user says these are public keys, call again with allow_secrets=true."
        }

        val note = if (c.excluded.isEmpty()) "" else " Not uploaded (private): " + c.excluded.take(6).joinToString(", ") + "."
        if (!confirm(Confirm.msg("run", "Publish \"${Coder.name(dir)}\" on ${title(p)}?",
                "${c.files.size} file(s), ${DeployCore.kb(total)}. The site becomes public on the internet; publishing again updates the same address.$note")))
            return "The user declined."

        val url = when (p) {
            "netlify" -> SitePublisher.publish(ctx, dir)
            "github" -> GitHubPages.publish(ctx, dir) { }
            "vercel" -> publishVercel(ctx, dir, c.files, a)
            else -> publishCloudflare(ctx, dir, c.files, a)
        }
        prefs(ctx).edit().putString(urlKey(p, dir), url).apply()
        return "Published on ${title(p)}: $url\n${c.files.size} file(s), ${DeployCore.kb(total)}.$note" +
            (if (p == "github") " GitHub Pages can take a minute or two to show the first time." else "") +
            " Open the address to check it before telling the user it works."
    }

    // ---------------------------------------------------------------- Vercel

    private fun vercelName(ctx: Context, dir: File, a: JSONObject): String =
        a.optString("name", "").takeIf { it.isNotBlank() }?.let { DeployCore.slug(it, 60) }
            ?: prefs(ctx).getString(projKey("vercel", dir), "").orEmpty().ifBlank { DeployCore.slug("anjoo-" + Coder.name(dir), 60) }

    private fun publishVercel(ctx: Context, dir: File, files: List<File>, a: JSONObject): String {
        val token = vercelToken(ctx)
        val name = vercelName(ctx, dir, a)
        val list = JSONArray()
        for (f in files) {
            val bytes = f.readBytes()
            val sha = DeployCore.sha1Hex(bytes)
            ensure("vercel", call("POST", "$VERCEL/v2/files", token, bytes.toRequestBody("application/octet-stream".toMediaType()),
                mapOf("x-vercel-digest" to sha, "Content-Length" to bytes.size.toString())), "file upload (${f.name})")
            list.put(JSONObject().put("file", f.relativeTo(dir).path.replace('\\', '/')).put("sha", sha).put("size", bytes.size))
        }
        val body = JSONObject().put("name", name).put("files", list).put("target", "production")
            .put("projectSettings", JSONObject().put("framework", JSONObject.NULL))
        val d = ensure("vercel", call("POST", "$VERCEL/v13/deployments?forceNew=1&skipAutoDetectionConfirmation=1", token, jbody(body)), "deployment").json()
        prefs(ctx).edit().putString(projKey("vercel", dir), name).apply()
        val id = d.optString("id")
        var cur = d
        var tries = 0
        while (id.isNotBlank() && cur.optString("readyState") !in setOf("READY", "ERROR", "CANCELED") && tries++ < 12) {
            Thread.sleep(2500)
            val r = call("GET", "$VERCEL/v13/deployments/$id", token)
            if (r.ok) cur = r.json()
        }
        val state = cur.optString("readyState")
        if (state == "ERROR" || state == "CANCELED") throw IllegalStateException("Vercel deployment ended as $state: " + cur.optJSONObject("error")?.optString("message").orEmpty().ifBlank { "see the Vercel dashboard" })
        val alias = cur.optJSONArray("alias")?.optString(0).orEmpty()
        val dep = cur.optString("url").ifBlank { d.optString("url") }
        val live = if (alias.isNotBlank()) "https://$alias" else if (dep.isNotBlank()) "https://$dep" else throw IllegalStateException("Published, but the address was not returned. Check the Vercel dashboard.")
        return live + (if (state != "READY") " (state: $state, may need a few more seconds)" else "")
    }

    // ---------------------------------------------------------------- Cloudflare Pages

    private fun cfName(ctx: Context, dir: File, a: JSONObject): String =
        a.optString("name", "").takeIf { it.isNotBlank() }?.let { DeployCore.slug(it, 58) }
            ?: prefs(ctx).getString(projKey("cloudflare", dir), "").orEmpty().ifBlank { DeployCore.slug("anjoo-" + Coder.name(dir), 58) }

    private val CF_SPECIAL = setOf("_headers", "_redirects", "_routes.json", "_worker.js")

    private fun publishCloudflare(ctx: Context, dir: File, files: List<File>, a: JSONObject): String {
        val token = cfToken(ctx)
        val acc = cfAccount(ctx)
        val name = cfName(ctx, dir, a)
        val base = "$CF/accounts/$acc/pages/projects"
        var proj = call("GET", "$base/$name", token)
        if (proj.code == 404 || (proj.code == 200 && !proj.json().optBoolean("success", true))) {
            proj = call("POST", base, token, jbody(JSONObject().put("name", name).put("production_branch", "main")))
        }
        val subdomain = cfOk(proj, "project").optJSONObject("result")?.optString("subdomain").orEmpty().ifBlank { "$name.pages.dev" }
        prefs(ctx).edit().putString(projKey("cloudflare", dir), name).apply()

        val jwt = cfOk(call("GET", "$base/$name/upload-token", token), "upload token").optJSONObject("result")?.optString("jwt").orEmpty()
        if (jwt.isBlank()) throw IllegalStateException("Cloudflare gave no upload token.")

        val manifest = JSONObject()
        val byHash = LinkedHashMap<String, File>()
        val special = ArrayList<File>()
        for (f in files) {
            val rel = f.relativeTo(dir).path.replace('\\', '/')
            if (rel in CF_SPECIAL) { special.add(f); continue }
            val h = DeployCore.cfHash(f.readBytes(), rel)
            manifest.put("/$rel", h)
            byHash.putIfAbsent(h, f)
        }
        val allHashes = JSONArray(byHash.keys.toList())
        val missingArr = cfOk(call("POST", "$CF/pages/assets/check-missing", jwt, jbody(JSONObject().put("hashes", allHashes))), "hash check").optJSONArray("result") ?: JSONArray()
        val missing = (0 until missingArr.length()).map { missingArr.getString(it) }

        var batch = JSONArray()
        var size = 0L
        fun flush() {
            if (batch.length() == 0) return
            cfOk(call("POST", "$CF/pages/assets/upload", jwt, jbody(batch)), "file upload")
            batch = JSONArray(); size = 0
        }
        for (h in missing) {
            val f = byHash[h] ?: continue
            val bytes = f.readBytes()
            batch.put(JSONObject().put("key", h).put("value", DeployCore.base64(bytes))
                .put("metadata", JSONObject().put("contentType", DeployCore.contentType(f.name))).put("base64", true))
            size += bytes.size
            if (size > 8L * 1024 * 1024 || batch.length() >= 200) flush()
        }
        flush()
        cfOk(call("POST", "$CF/pages/assets/upsert-hashes", jwt, jbody(JSONObject().put("hashes", allHashes))), "hash save")

        val mp = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("manifest", manifest.toString())
            .addFormDataPart("branch", "main")
        for (f in special) mp.addFormDataPart(f.name, f.name, f.readBytes().toRequestBody("application/octet-stream".toMediaType()))
        val dep = cfOk(call("POST", "$base/$name/deployments", token, mp.build()), "deployment").optJSONObject("result")
        val depUrl = dep?.optString("url").orEmpty()
        return "https://$subdomain" + (if (depUrl.isNotBlank()) " (this deployment: $depUrl)" else "")
    }

    // ============================================================ deploy history

    private fun deploys(ctx: Context, dir: File, a: JSONObject): String {
        val p = pickProvider(ctx, dir, a)
        if (!has(ctx, p)) return tokenHelp(p)
        val sb = StringBuilder("RECENT DEPLOYS · ${title(p)}\n")
        when (p) {
            "netlify" -> {
                val id = SitePublisher.siteId(ctx, dir).ifBlank { return "This project was not published to Netlify from this phone yet." }
                val arr = ensure(p, call("GET", "$NETLIFY/sites/$id/deploys?per_page=6", netlifyToken(ctx)), "deploy list").arr()
                for (i in 0 until arr.length()) arr.getJSONObject(i).let { sb.append("• ").append(it.optString("created_at")).append(" · ").append(it.optString("state"))
                    .append(" · ").append(it.optString("deploy_ssl_url")).append(it.optString("error_message").let { e -> if (e.isBlank() || e == "null") "" else " · $e" }).append('\n') }
            }
            "vercel" -> {
                val name = vercelName(ctx, dir, a)
                val arr = ensure(p, call("GET", "$VERCEL/v6/deployments?app=$name&limit=6", vercelToken(ctx)), "deploy list").json().optJSONArray("deployments") ?: JSONArray()
                for (i in 0 until arr.length()) arr.getJSONObject(i).let { sb.append("• ").append(it.optString("state").ifBlank { it.optString("readyState") }).append(" · https://").append(it.optString("url")).append('\n') }
            }
            "cloudflare" -> {
                val name = cfName(ctx, dir, a)
                val arr = cfOk(call("GET", "$CF/accounts/${cfAccount(ctx)}/pages/projects/$name/deployments?per_page=6", cfToken(ctx)), "deploy list").optJSONArray("result") ?: JSONArray()
                for (i in 0 until arr.length()) arr.getJSONObject(i).let { sb.append("• ").append(it.optString("created_on")).append(" · ").append(it.optJSONObject("latest_stage")?.optString("status").orEmpty())
                    .append(" · ").append(it.optString("url")).append('\n') }
            }
            else -> return "GitHub Pages history is the repository's commit log: use project_git log."
        }
        if (sb.lines().size <= 2) sb.append("(none found)\n")
        return sb.toString().trim()
    }

    // ============================================================ environment variables

    private fun envProvider(ctx: Context, dir: File, a: JSONObject): String {
        val p = pickProvider(ctx, dir, a)
        if (p == "github") throw IllegalStateException("GitHub Pages is static: it has no environment variables (GitHub Actions secrets are not supported here). Use Netlify, Vercel or Cloudflare.")
        if (!has(ctx, p)) throw IllegalStateException(tokenHelp(p))
        return p
    }

    /** Which environments: production, preview or all. */
    private fun targets(a: JSONObject): List<String> = when (a.optString("target", "all").trim().lowercase()) {
        "production", "prod" -> listOf("production")
        "preview", "staging" -> listOf("preview")
        else -> listOf("production", "preview")
    }

    private val STATIC_NOTE = "\nNote: a purely static site cannot read these at runtime; they only reach serverless functions or builds on the host. Never put secrets in front-end JavaScript."

    private fun envList(ctx: Context, dir: File, a: JSONObject): String {
        val p = envProvider(ctx, dir, a)
        val sb = StringBuilder("ENV VARIABLES · ${title(p)} (names only, values are never shown)\n")
        when (p) {
            "netlify" -> {
                val (slug, id) = netlifySite(ctx, dir)
                val arr = ensure(p, call("GET", "$NETLIFY/accounts/$slug/env?site_id=$id", netlifyToken(ctx)), "env list").arr()
                for (i in 0 until arr.length()) arr.getJSONObject(i).let { sb.append("• ").append(it.optString("key")).append(if (it.optBoolean("is_secret")) " (secret)" else "").append('\n') }
            }
            "vercel" -> {
                val arr = ensure(p, call("GET", "$VERCEL/v9/projects/${vercelName(ctx, dir, a)}/env", vercelToken(ctx)), "env list").json().optJSONArray("envs") ?: JSONArray()
                for (i in 0 until arr.length()) arr.getJSONObject(i).let { sb.append("• ").append(it.optString("key")).append(" [").append(it.optJSONArray("target")?.join(",")?.replace("\"", "").orEmpty()).append("]\n") }
            }
            else -> {
                val pr = cfOk(call("GET", "$CF/accounts/${cfAccount(ctx)}/pages/projects/${cfName(ctx, dir, a)}", cfToken(ctx)), "project").optJSONObject("result")
                for (env in listOf("production", "preview")) {
                    val vars = pr?.optJSONObject("deployment_configs")?.optJSONObject(env)?.optJSONObject("env_vars") ?: continue
                    for (k in vars.keys()) sb.append("• ").append(k).append(" [").append(env).append("]\n")
                }
            }
        }
        if (sb.lines().size <= 2) sb.append("(none)\n")
        return sb.toString().trim()
    }

    private fun netlifySite(ctx: Context, dir: File): Pair<String, String> {
        val id = SitePublisher.siteId(ctx, dir).ifBlank { throw IllegalStateException("Publish this project to Netlify first so a site exists, then set variables.") }
        val site = ensure("netlify", call("GET", "$NETLIFY/sites/$id", netlifyToken(ctx)), "site lookup").json()
        val slug = site.optString("account_slug").ifBlank { throw IllegalStateException("Netlify account not found for this site.") }
        return slug to id
    }

    /** Sets or updates [vars] on the host. Returns one summary line per variable (names only). */
    private fun pushVars(ctx: Context, p: String, dir: File, a: JSONObject, vars: Map<String, String>): String {
        val tg = targets(a)
        val out = StringBuilder()
        when (p) {
            "netlify" -> {
                val (slug, id) = netlifySite(ctx, dir)
                val t = netlifyToken(ctx)
                fun body(k: String, v: String, secret: Boolean): JSONObject {
                    val o = JSONObject().put("key", k).put("scopes", JSONArray(listOf("builds", "functions", "runtime")))
                        .put("values", JSONArray().put(JSONObject().put("context", "all").put("value", v)))
                    if (secret) o.put("is_secret", true)
                    return o
                }
                for ((k, v) in vars) {
                    var secretStored = true
                    var r = call("POST", "$NETLIFY/accounts/$slug/env?site_id=$id", t, jbody(JSONArray().put(body(k, v, true))))
                    if (!r.ok) r = call("PUT", "$NETLIFY/accounts/$slug/env/$k?site_id=$id", t, jbody(body(k, v, true)))
                    if (!r.ok && r.code != 401 && r.code != 403) {
                        secretStored = false
                        r = call("POST", "$NETLIFY/accounts/$slug/env?site_id=$id", t, jbody(JSONArray().put(body(k, v, false))))
                        if (!r.ok) r = call("PUT", "$NETLIFY/accounts/$slug/env/$k?site_id=$id", t, jbody(body(k, v, false)))
                    }
                    ensure("netlify", r, "env $k")
                    out.append("• ").append(k).append(": saved").append(if (secretStored) " (secret)" else " (normal variable, Netlify refused the secret flag)").append('\n')
                }
            }
            "vercel" -> {
                val name = vercelName(ctx, dir, a)
                val vt = tg.map { if (it == "preview") "preview" else "production" } + (if (a.optString("target", "all").lowercase() in setOf("all", "")) listOf("development") else emptyList())
                for ((k, v) in vars) {
                    ensure("vercel", call("POST", "$VERCEL/v10/projects/$name/env?upsert=true", vercelToken(ctx),
                        jbody(JSONObject().put("key", k).put("value", v).put("type", "encrypted").put("target", JSONArray(vt)))), "env $k")
                    out.append("• ").append(k).append(": saved (encrypted) for ").append(vt.joinToString("/")).append('\n')
                }
            }
            else -> {
                val cfg = JSONObject()
                for (env in tg) {
                    val ev = JSONObject()
                    for ((k, v) in vars) ev.put(k, JSONObject().put("type", "secret_text").put("value", v))
                    cfg.put(env, JSONObject().put("env_vars", ev))
                }
                cfOk(call("PATCH", "$CF/accounts/${cfAccount(ctx)}/pages/projects/${cfName(ctx, dir, a)}", cfToken(ctx),
                    jbody(JSONObject().put("deployment_configs", cfg))), "env set")
                for (k in vars.keys) out.append("• ").append(k).append(": saved (secret) for ").append(tg.joinToString("/")).append('\n')
            }
        }
        return out.toString()
    }

    private fun envSet(ctx: Context, confirm: (String) -> Boolean, dir: File, a: JSONObject): String {
        val key = a.optString("key", "").trim()
        val value = a.optString("value", "")
        if (!DeployCore.ENV_KEY.matches(key)) return "Give key as a valid variable name (letters, digits, underscore; not starting with a digit)."
        if (value.isEmpty()) return "Give value. Better: ask the user to put it in the project's .env file and use env_push, so the value never passes through chat."
        val p = envProvider(ctx, dir, a)
        if (!confirm(Confirm.msg("run", "Set $key on ${title(p)}?", "The value is sent over HTTPS and stored on the host. It is not shown here."))) return "The user declined."
        return "ENV SET · ${title(p)}\n" + pushVars(ctx, p, dir, a, mapOf(key to value)) +
            "Tell the user: the value came through chat, so if it is a real secret, rotate it later and prefer .env + env_push." + STATIC_NOTE
    }

    private fun envPush(ctx: Context, confirm: (String) -> Boolean, dir: File, a: JSONObject): String {
        val file = a.optString("file", ".env").trim().ifBlank { ".env" }
        if (file.contains("..") || file.startsWith("/")) return "file must be a path inside the project (for example .env or .env.production)."
        val f = File(dir, file)
        if (!f.isFile) return "File '$file' not found in the project. Ask the user to create it with KEY=value lines (it is never published), or use env_set."
        var vars = DeployCore.parseEnv(f.readText())
        val only = a.optString("keys", "").split(',').map { it.trim() }.filter { it.isNotEmpty() }
        if (only.isNotEmpty()) vars = LinkedHashMap(vars.filterKeys { it in only })
        vars = LinkedHashMap(vars.filterValues { it.isNotEmpty() })
        if (vars.isEmpty()) return "No KEY=value lines with a value found in $file" + (if (only.isNotEmpty()) " for keys: ${only.joinToString(", ")}" else "") + "."
        if (vars.size > 50) return "${vars.size} variables is too many for one push; use keys= to pick up to 50."
        val p = envProvider(ctx, dir, a)
        if (!confirm(Confirm.msg("run", "Send ${vars.size} variable(s) from $file to ${title(p)}?", vars.keys.joinToString(", ") + "\nValues are sent over HTTPS and stored on the host. They are not shown here.")))
            return "The user declined."
        return "ENV PUSH · ${title(p)} · from $file (${vars.size} variable(s); values never shown)\n" + pushVars(ctx, p, dir, a, vars) + STATIC_NOTE
    }

    private fun envDelete(ctx: Context, confirm: (String) -> Boolean, dir: File, a: JSONObject): String {
        val key = a.optString("key", "").trim()
        if (!DeployCore.ENV_KEY.matches(key)) return "Give key (the variable name to remove)."
        val p = envProvider(ctx, dir, a)
        if (!confirm(Confirm.msg("delete", "Delete $key from ${title(p)}?", "This cannot be undone. Sites that use it may stop working."))) return "The user declined."
        when (p) {
            "netlify" -> { val (slug, id) = netlifySite(ctx, dir); ensure(p, call("DELETE", "$NETLIFY/accounts/$slug/env/$key?site_id=$id", netlifyToken(ctx)), "env delete") }
            "vercel" -> {
                val name = vercelName(ctx, dir, a)
                val envs = ensure(p, call("GET", "$VERCEL/v9/projects/$name/env", vercelToken(ctx)), "env list").json().optJSONArray("envs") ?: JSONArray()
                var n = 0
                for (i in 0 until envs.length()) envs.getJSONObject(i).let { if (it.optString("key") == key) { ensure(p, call("DELETE", "$VERCEL/v9/projects/$name/env/${it.optString("id")}", vercelToken(ctx)), "env delete"); n++ } }
                if (n == 0) return "$key was not found on Vercel."
            }
            else -> {
                val cfg = JSONObject()
                for (env in targets(a)) cfg.put(env, JSONObject().put("env_vars", JSONObject().put(key, JSONObject.NULL)))
                cfOk(call("PATCH", "$CF/accounts/${cfAccount(ctx)}/pages/projects/${cfName(ctx, dir, a)}", cfToken(ctx), jbody(JSONObject().put("deployment_configs", cfg))), "env delete")
            }
        }
        return "Deleted $key from ${title(p)}."
    }
}
