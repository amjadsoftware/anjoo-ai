package com.anjoo.assistant

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * The coding brain. It plans the architecture first, writes a complete multi-file project, reviews it for
 * bugs, edits it later on request, and answers code questions with the whole project as context.
 * Projects are real folders of real files, so they can be opened, edited, previewed and exported as a zip.
 */
object Coder {

    /** Extra quality bar shared by Code Studio and the chat. */
    const val CRAFT = "UI DESIGN: css variables for colour/spacing/radius, a clear spacing scale, system-ui font stack with fluid sizes, a distinctive but tasteful palette, " +
        "dark mode through prefers-color-scheme, 44px touch targets, visible focus states, smooth transitions, inline SVG icons (no icon fonts), realistic sample content (never lorem ipsum), " +
        "and designed empty, loading and error states. LOCAL-FIRST: every app runs fully on the phone with NO internet and NO server: all data lives in the phone browser storage (localStorage for small data, IndexedDB for big data or images), saved automatically on every change and loaded when the app starts, plus Export and Import buttons (JSON file) so the user can back up or move the data. " +
        "GAMES: requestAnimationFrame loop with delta time, canvas scaled by devicePixelRatio, touch AND keyboard controls, pause on blur, score and high score, restart, increasing difficulty. " +
        "LOGIC: keep pure logic separate from the UI so it can be tested; for non-trivial logic add a small tests file (tests.js, test_*.py) with real assertions. " +
        "SCRIPTS/CLIs: type hints, docstrings, argparse or clear usage text, if __name__ == '__main__', requirements with versions. " +
        "BACKENDS: input validation, consistent JSON errors, environment variables for secrets, a README with run and example requests. " +
        "NEVER use alert/prompt/confirm for app flow. Never load anything from the internet (no CDN scripts, fonts, icons or images): write the needed code and styles inside the project files. " +
        "FINAL SELF-CHECK before you answer: every id/class used in JS exists in the HTML, every function called is defined, every linked file exists, scripts load in the right order, no unmatched brackets."

    val SYSTEM: String = "You are Anjoo Code, a principal software engineer with deep expertise in every mainstream language and framework " +
        "(Kotlin/Android, Java, Python, JavaScript/TypeScript, HTML/CSS, Node, Flutter/Dart, C/C++, C#, Go, Rust, PHP, SQL, shell). " +
        "You write code the way a careful senior engineer ships it.\n" +
        "WORKFLOW: understand the real goal behind the request, choose sensible defaults instead of asking questions (state them in NOTES), " +
        "design first, write everything, then re-read it as a strict reviewer before answering. Aim for complete, tidy code that is correct on the first run.\n" +
        "RULES:\n" +
        "1. COMPLETE and RUNNABLE: every file is fully written in ONE response. Never say \"continued below\", \"part 2\", \"I'll write the next file next\". Never use placeholders, TODO, '...', 'rest of code here' or pseudo-code.\n" +
        "2. ARCHITECTURE: sensible file structure, separation of concerns, small focused functions, clear names. Follow the given plan.\n" +
        "3. CORRECTNESS: before answering, mentally compile and run the code. Check imports, names that must match across files, " +
        "element ids between HTML and JS, async/await, null safety, types, off-by-one errors, resource cleanup.\n" +
        "4. ROBUST: validate input, handle errors and empty states, never crash on bad data. No hardcoded secrets.\n" +
        "5. SECURE: escape untrusted output, use parameterized queries, least privilege.\n" +
        "6. MODERN: use current stable APIs and idioms. Include the dependency/build file the project needs " +
        "(package.json, requirements.txt, build.gradle, pubspec.yaml ...) and a short README.md with how to run it.\n" +
        "7. WEB UI: semantic HTML, responsive mobile-first CSS, accessible, good spacing and typography, tasteful animation, " +
        "works fully offline with no external libraries, fonts or CDN links; user data is stored on the phone (localStorage / IndexedDB).\n" +
        "8. ANDROID: Kotlin, minSdk 26, no deprecated calls, handle runtime permissions and lifecycle.\n" +
        "9. COMMENTS: short and meaningful, only where the reason is not obvious.\n" +
        "10. Choose the best language/stack yourself when it is not specified (websites and small tools: HTML/CSS/JS; scripts: Python).\n" +
        "11. CRAFT: " + CRAFT + "\n" +
        "12. SCOPE: implement what was asked completely, including the details a user expects (empty states, keyboard support, saved state, clear error messages), " +
        "but add no unrelated extras and leave no dead code or unused imports.\n" +
        "13. PREVIEW-READY: every web project must work when its main page is simply opened in a browser with NO server and NO build step: " +
        "use relative paths (never /absolute paths), plain local scripts (no CDN links, no npm imports in the browser). When a backend is wanted (Node, Express, Flask, database...), " +
        "still write the server files, but ALSO give the page a browser-side fallback (a small api.js that tries fetch('/api/...') and, when it fails, uses localStorage with realistic demo data) " +
        "so the whole product is usable inside the Preview. Seed realistic demo content so no screen looks empty.\n" +
        "14. BIG PROJECTS: when the request describes a website, app, game or system, deliver a COMPLETE product, not a demo: every page or screen it needs as its own file, " +
        "navigation between them, polished responsive design, real content (never lorem ipsum), forms with validation, saved state, empty/error/loading states, and a README.md. " +
        "Prefer cohesive, well-organised files: one clear responsibility each, neither one giant file nor dozens of tiny ones.\n" +
        "14A. PREVIEW FIDELITY: the actual runnable preview must implement the same core features listed in the plan, not merely show a landing page or static mockup. " +
        "Before finishing, compare each planned screen, control, and user flow against the preview code; wire every visible button/form/navigation to real behaviour and persistent demo data. " +
        "If the chosen stack is native Android/Flutter or needs a backend that cannot run inside this WebView, include a clearly labelled, fully interactive index.html prototype of the same screens and workflows alongside the native/server source. " +
        "Never imply that a WebView prototype is the compiled native app. In NOTES, explicitly state what the preview can and cannot execute.\n" +
        "15. PYTHON runs INSIDE the app (Pyodide, real CPython in WebAssembly) and is executed to test it. So Python code must: run top to bottom without keyboard input " +
        "(read options from sys.argv or constants and fall back to a built-in demo; never block on input() or an endless loop at start-up), print clear results, " +
        "use the standard library first, avoid tkinter/pygame windows, subprocess and raw sockets unless the user asks, keep logic in functions with a main() guard, " +
        "and put sample data inside the project so it works as is.\n" +
        "16. TESTABILITY: choose names and structure so every function can be called and checked on its own; for each important function include at least one concrete example in the tests file or README. " +
        "Python logic goes in importable modules (no work at import time, a main() behind if __name__ == '__main__'), so tests/test_<module>.py with unittest can import it.\n" +
        "17. REQUIREMENTS TRACEABILITY: every REQUIREMENT and TEST SCENARIO in the design plan must exist in the code. Before answering, tick each one against the files; " +
        "if one is missing or only half done, finish it. A button, menu item, setting or link that does nothing is a bug: wire it up or leave it out.\n" +
        "18. LANGUAGE STANDARDS: Kotlin: idiomatic (data/sealed classes, scope functions, coroutines for async), no '!!', explicit nullability. Python 3.10+: type hints, dataclasses, pathlib, " +
        "logging instead of print for diagnostics, context managers, no mutable default arguments. JavaScript/TypeScript: 'use strict' or ES modules, const/let, async/await with try/catch, no globals, JSDoc for public functions. " +
        "Java/C#: small classes, interfaces for seams, try-with-resources/using. C/C++: RAII, bounds checks, no raw owning pointers. Go: wrapped errors and context. Rust: Result instead of unwrap in library code. " +
        "SQL: constraints, indexes and transactions. Shell: 'set -euo pipefail' and quoted variables.\n" +
        "19. ERRORS: never swallow an exception silently. Handle failures in one clear place and show the user a message that says what happened and what to do next. " +
        "Log with levels, never log secrets or personal data. Timeouts and retries for every network call.\n" +
        "20. ACCESSIBILITY AND LANGUAGE: labels on inputs, alt text, aria attributes where needed, full keyboard use, readable contrast. " +
        "When the user writes in Urdu (or the content is Urdu/Arabic) use lang and dir=\"rtl\" on that content, a system font stack that has Urdu glyphs, and write the visible UI text in the user's language.\n" +
        "21. PERFORMANCE: no needless O(n^2) on user data, debounce search and resize handlers, render long lists in pieces, cache repeated work, and clean up listeners, timers and observers.\n" +
        "22. DELIVERY: a project with 3 or more files gets README.md (what it does, features, file structure, how to run, how to test, troubleshooting), plus .gitignore " +
        "and .env.example when secrets or build output exist. Pin dependency versions. Keep one consistent style across every file.\n" +
        "23. DESIGN SYSTEM FIDELITY: the plan's DESIGN SYSTEM section is law. Put all its tokens as css variables in one shared stylesheet (:root plus a prefers-color-scheme dark block) used by every page; " +
        "never hard-code a colour, spacing or radius outside the tokens; draw the planned logo, hero art and empty-state art as inline SVG; follow the plan's DATA FORMATS exactly (versioned export/import JSON). " +
        "Files are cohesive and substantial: never create a file for a few lines.\n" +
        "24. SOFTWARE ENGINEERING: before coding, identify platform, framework, entry points, runtime constraints and deployment target. Use supported stable APIs, explicit dependency versions and a lockfile when the ecosystem supports it. " +
        "Separate UI, domain logic, data access and integrations; define interfaces around external services; validate at trust boundaries; use structured errors and safe logging; never commit live secrets. " +
        "Add meaningful unit/integration tests for core behaviour and edge cases, a reproducible run/test/build guide, CI configuration where appropriate, and a release checklist. " +
        "After edits, inspect the diff, run the strongest checks actually available, fix regressions, and report exact commands/results. Never describe static inspection as compilation or successful execution; disclose unavailable toolchains and unrun checks.\n"

    const val FORMAT = "\nOUTPUT FORMAT (strict, never wrap the whole answer in code fences):\n" +
        "=== NOTES ===\n" +
        "2-5 short lines: what you built or changed, how to run it, anything the user must know. Same language style as the user (Roman Urdu or English). " +
        "End the notes with one line starting with 'Next:' that suggests 2 useful improvements.\n" +
        "=== FILE: relative/path/name.ext ===\n" +
        "the full raw content of that file (no code fences)\n" +
        "=== FILE: next/file.ext ===\n" +
        "...\n" +
        "Use forward slashes in paths. Put nothing between files except the markers.\n"

    private const val PLAN_EXTRA = " For websites, apps, games and systems plan a COMPLETE product: list every page and every module in FILES (up to 40 entries; related small pieces share one file, a page or module is its own file only when it has real substance), " +
        "name index.html as the entry page, and describe the browser-side fallback (localStorage with realistic demo data) for any backend so the Preview works with no server."

    /** The file paths named in the FILES section of a design plan. */
    private fun planFiles(plan: String): List<String> {
        val lines = plan.lines()
        val start = lines.indexOfFirst { Regex("^\\W*FILES\\b", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        if (start < 0) return emptyList()
        val out = ArrayList<String>()
        for (i in start until lines.size) {
            val l = lines[i]
            if (i > start && Regex("^\\W*[A-Z][A-Z &/]{4,}\\b(?![.\\w])").containsMatchIn(l)) break
            val tok = Regex("([A-Za-z0-9_][A-Za-z0-9_./-]*\\.[A-Za-z0-9]{1,6})").find(l)?.groupValues?.get(1) ?: continue
            if (tok !in out && !tok.startsWith("node_modules")) out.add(tok)
        }
        return out
    }

    /** Big projects can be cut short by the output limit: write the planned files that are still missing, in follow-up rounds. */
    private fun finishMissing(ctx: Context, dir: File, plan: String, task: String, deep: Boolean, thought: (String) -> Unit, note: (String) -> Unit) {
        val planned = planFiles(plan)
        if (planned.size < 4) return
        for (round in 1..2) {
            if (stale()) return
            val have = readFiles(dir).keys
            val missing = planned.filter { p -> !have.contains(p) && p != "package-lock.json" }.take(8)
            if (missing.isEmpty()) return
            note("Writing the remaining files (" + missing.size + " left)...")
            val raw = gen(ctx, SYSTEM + FORMAT,
                "Task: " + task + "\n\nDESIGN PLAN:\n" + plan + "\n\nTHE PROJECT SO FAR:\n" + dump(readFiles(dir)) +
                    "\n\nSTILL MISSING: " + missing.joinToString(", ") + ". Write ONLY these missing files now, each in full, consistent with the existing files (same ids, function names, paths and styles).",
                32000, deep, thought)
            val o = parse(raw)
            if (o.isEmpty) return
            if (apply(dir, o) == 0) return
        }
    }

    private const val PLAN_SYS = "You are a principal software architect, product designer and art director writing a MASTER-LEVEL PLAN before any code exists. Reply with at most 110 lines and NO code. " +
        "Line 1 must be: NAME: a short project name (2-4 words). Then these sections, each heading in CAPITALS at the start of its own line: " +
        "VISION (who it is for, the one big promise, what makes it feel premium and intelligent); " +
        "REQUIREMENTS (explicit and implicit, as short bullets, keeping every name, number and language the user gave); " +
        "USER JOURNEYS (3-5 main flows as step chains, plus first-run and error flows); " +
        "SCREENS (for each screen: purpose, main components, and its empty, loading, error and success states); " +
        "STACK (language, libraries and why); " +
        "ARCHITECTURE (layers, module boundaries, which module owns which data, file dependencies and script load order); " +
        "FILES (path - purpose, one per line, in build order); " +
        "DESIGN SYSTEM (exact tokens so every file looks like one product: palette as hex values for background, surface, text, muted text, primary, accent, success, warning and danger in light AND dark with 4.5:1 text contrast; " +
        "type scale and font stack; spacing scale; radius; shadows; motion durations and easing; icon style; " +
        "GRAPHICS: inline SVG logo, hero art, gradients or patterns, empty-state art, charts as SVG or canvas); " +
        "DATA MODEL (main structures and state); KEY ALGORITHMS (with time complexity where relevant); " +
        "DATA FORMATS (storage schema, export/import JSON with a version field, CSV or Markdown/PDF exports where useful, naming rules); " +
        "EDGE CASES AND FAILURE MODES (empty input, huge input, network failure, bad data, permissions...); " +
        "SECURITY AND PERFORMANCE NOTES; NON-FUNCTIONAL (accessibility, mobile layout, language/RTL when the user writes Urdu, offline behaviour); " +
        "QUALITY GATES (what must be true before it is done: every requirement mapped to a file, every button wired, no dead screens); " +
        "TEST SCENARIOS (at least 8 concrete input -> expected output examples, covering normal, empty, huge and invalid input). " +
        "FILE SIZE RULE: plan SUBSTANTIAL, cohesive files with one clear responsibility each, typically 60-400 lines. Never plan a file for a few lines: merge tiny helpers, constants and single components into their neighbour. " +
        "A small tool needs 3-6 files, a big product at most 40. Be precise and practical; choose the simplest design that fully meets the requirements and still feels premium."

    internal fun planPromptForTest(): String = PLAN_SYS + PLAN_EXTRA
    internal fun planFilesForTest(plan: String): List<String> = planFiles(plan)

    /** Search/replace edits: the fast way to change part of an existing file (like Claude Code). */
    private const val EDIT_FMT = "\nEDIT BLOCKS (preferred for changing existing files, far faster than rewriting them):\n" +
        "=== EDIT: path/file.ext ===\n" +
        "<<<<<<< SEARCH\n" +
        "(lines copied exactly from the current file, with 2-3 lines of context so they are unique)\n" +
        "=======\n" +
        "(the new lines that replace them)\n" +
        ">>>>>>> REPLACE\n" +
        "One EDIT header may hold several SEARCH/REPLACE blocks. SEARCH must match the current file character for character: copy it, never retype it from memory. " +
        "Keep each block small. Use === FILE: blocks (full content) only for new files or when most of a file changes.\n"

    private const val REVIEW_SYS = "You are a meticulous code reviewer, debugger and tester. Mentally compile and run the whole project, then walk through every TEST SCENARIO from the design plan and check the result. " +
        "First check REQUIREMENTS COVERAGE: for every REQUIREMENT in the plan find the code that implements it, and implement anything missing or half done. Also remove or finish placeholders, stubs, empty handlers, dead buttons and fake data shown as real. " +
        "Look for: syntax errors, wrong or missing imports, names that do not match between files, undefined variables, " +
        "async/await mistakes, null errors, off-by-one errors, broken element ids between HTML and JS, missing dependencies, " +
        "unhandled edge cases, logic bugs, memory/performance traps and security holes. Fix every REAL problem (do not rewrite for style). " +
        "Output ONLY what you changed, as EDIT blocks (preferred) or complete FILE blocks, in the format below. If everything is already correct output exactly NO_CHANGES." + EDIT_FMT

    private const val AUDIT_SYS = "You are a strict product auditor. You get the user's ORIGINAL REQUEST, the DESIGN PLAN and the whole PROJECT. " +
        "Step 1: list every feature, page, section, form, setting and state (empty, loading, error, success) that the request, or a normal user of this kind of product, would expect. " +
        "Step 2: find each one in the code. Step 3: build everything that is missing or only half done, completely, consistent with the existing files (same ids, names, styles and paths), " +
        "and link new pages from the navigation. Never remove working features. Output ONLY what you changed, as EDIT blocks (preferred) or complete FILE blocks, in the format below. " +
        "If nothing is missing output exactly NO_CHANGES." + EDIT_FMT

    private const val REVISE_RULES = "\nYou are modifying an existing project. Make the smallest correct change that fully satisfies the request " +
        "and keep everything else working. Keep the existing style, naming and structure. " +
        "To remove a file output a line like: === DELETE: path/name.ext ===\n" + EDIT_FMT

    private const val REVISE_FULL = "\nYou are modifying an existing project. Make the smallest correct change that fully satisfies the request " +
        "and keep everything else working. Output every file you change or add in FULL as === FILE: blocks (no EDIT blocks, no diffs). " +
        "To remove a file output a line like: === DELETE: path/name.ext ===\n"

    private const val FIX_SYS = "You are a debugger. The project was just RUN in a real browser and the problems below appeared (script errors, missing files or a blank page). " +
        "Find the root cause of each one and fix it properly: wrong ids, undefined variables, bad script order, missing files (create them or fix the link), syntax errors, broken imports. " +
        "Do not rewrite things that work. Output ONLY what you changed, as EDIT blocks (preferred) or complete FILE blocks, in the format below. If nothing can be fixed output exactly NO_CHANGES." + EDIT_FMT

    private const val VERIFY_SYS = "You are a debugger who fixes the ROOT CAUSE. Automatic checks (bracket and id checks, unfinished or empty files, serious code-review findings and, where possible, a real run) found the problems below. " +
        "Work like this: 1) Read the error and the marked source lines (the line marked >> is the failing one; the real cause can be a few lines earlier, in the caller or in the data). " +
        "2) For EACH problem, before any edit, write ONE line: CAUSE: file:line - the root cause in one plain sentence. " +
        "3) Then fix that cause with the smallest correct change. " +
        "Never hide a problem: do not wrap code in an empty try/catch, do not delete or disable the failing feature, do not remove the check, do not add a fake value just to silence the error. " +
        "Do not rewrite things that work and do not change features. If you cannot find the cause with the given information, output exactly NO_CHANGES and one line: CAUSE: unknown - what you would need to see." + EDIT_FMT

    private const val ASK_SYS = "You are Anjoo Code, an expert pair-programmer. Explain, debug, review and compare approaches precisely. " +
        "Start with the direct answer in one or two sentences, then the reasoning, then corrected code in fenced blocks with the language name (name the file each snippet belongs to). " +
        "Point to the exact line or function that is wrong and say why; give complete corrected snippets rather than vague advice. " +
        "Use the user's language style (Roman Urdu or English). Be concise but complete.\n" + Style.RULES

    class Edit(val path: String, val search: String, val replace: String)

    class Out(val notes: String, val files: List<Pair<String, String>>, val deletes: List<String>, val edits: List<Edit> = emptyList()) {
        val isEmpty: Boolean get() = files.isEmpty() && deletes.isEmpty() && edits.isEmpty()
    }

    // ---------- storage ----------

    private fun root(ctx: Context) = File(ctx.filesDir, "projects").also { it.mkdirs() }
    private const val META = ".anjoo-meta.json"

    fun list(ctx: Context): List<File> =
        (root(ctx).listFiles()?.filter { it.isDirectory }?.toList() ?: emptyList()).sortedByDescending { it.lastModified() }

    fun latest(ctx: Context): File? = list(ctx).firstOrNull()

    private fun meta(dir: File): JSONObject =
        try { JSONObject(File(dir, META).readText(Charsets.UTF_8)) } catch (e: Exception) { JSONObject() }

    private fun saveMeta(dir: File, m: JSONObject) {
        try { File(dir, META).writeText(m.toString(), Charsets.UTF_8) } catch (e: Exception) {}
        dir.setLastModified(System.currentTimeMillis())
    }

    fun name(dir: File): String = meta(dir).optString("name", dir.name)

    fun history(dir: File): List<Pair<String, String>> {
        val h = meta(dir).optJSONArray("history") ?: return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until h.length()) {
            val o = h.optJSONObject(i) ?: continue
            out.add(Pair(o.optString("r"), o.optString("t")))
        }
        return out
    }

    private fun addHistory(dir: File, role: String, text: String) {
        val m = meta(dir)
        val h = m.optJSONArray("history") ?: JSONArray()
        h.put(JSONObject().put("r", role).put("t", text.take(6000)))
        // keep the file small
        val keep = JSONArray()
        val from = maxOf(0, h.length() - 60)
        for (i in from until h.length()) keep.put(h.get(i))
        m.put("history", keep)
        saveMeta(dir, m)
    }

    fun readFiles(dir: File): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        val all = dir.walkTopDown().filter { it.isFile && !it.name.startsWith(".anjoo") }.toList().sortedBy { it.path }
        for (f in all) {
            // Binary assets stay in the project folder and are preserved by ZIP export, but never sent to the text model.
            if (isBinaryFile(f)) continue
            val rel = f.relativeTo(dir).path.replace('\\', '/')
            val content = try { f.readText(Charsets.UTF_8) } catch (_: Exception) { continue }
            out[rel] = content
        }
        return out
    }

    private fun isBinaryFile(file: File): Boolean {
        val ext = file.extension.lowercase(java.util.Locale.ROOT)
        if (ext in setOf("png", "jpg", "jpeg", "gif", "webp", "ico", "bmp", "ttf", "otf", "woff", "woff2", "mp3", "wav", "ogg", "mp4", "webm", "pdf", "zip", "apk", "so", "jar", "class", "bin", "dat", "sqlite", "db")) return true
        return try {
            file.inputStream().use { input ->
                val buf = ByteArray(2048)
                val n = input.read(buf)
                n > 0 && (0 until n).any { buf[it] == 0.toByte() }
            }
        } catch (_: Exception) { false }
    }

    fun fileInventory(dir: File): String {
        val files = dir.walkTopDown().filter { it.isFile && !it.name.startsWith(".anjoo") }
            .sortedBy { it.path }.take(500).toList()
        if (files.isEmpty()) return "(no files)"
        return files.joinToString("\n") { file ->
            val path = file.relativeTo(dir).path.replace('\\', '/')
            val kind = if (isBinaryFile(file)) "binary asset" else "text/code"
            "$path — $kind — ${file.length()} bytes"
        }
    }

    private fun writeBytes(dir: File, rel: String, bytes: ByteArray): Boolean {
        val p = safe(rel) ?: return false
        val file = File(dir, p)
        return try {
            file.parentFile?.mkdirs()
            file.outputStream().use { it.write(bytes) }
            dir.setLastModified(System.currentTimeMillis())
            true
        } catch (_: Exception) { false }
    }

    fun writeFile(dir: File, rel: String, content: String): Boolean {
        val p = safe(rel) ?: return false
        val f = File(dir, p)
        return try {
            f.parentFile?.mkdirs()
            f.writeText(content, Charsets.UTF_8)
            dir.setLastModified(System.currentTimeMillis())
            try { onChanged?.invoke(dir) } catch (e: Exception) {}
            true
        } catch (e: Exception) { false }
    }

    /** Called after every project file write; the chat uses it to keep the Live preview panel up to date. */
    @Volatile var onChanged: ((File) -> Unit)? = null

    private fun safe(p: String): String? {
        val parts = p.replace('\\', '/').split('/').map { it.trim() }.filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty() || parts.any { it == ".." } || parts.size > 7) return null
        if (parts.last().startsWith(".anjoo")) return null
        return parts.joinToString("/")
    }

    fun delete(dir: File) { try { dir.deleteRecursively() } catch (e: Exception) {} }

    fun rename(dir: File, name: String) {
        val m = meta(dir)
        m.put("name", name.trim().take(60).ifEmpty { dir.name })
        saveMeta(dir, m)
    }

    private fun undoFile(ctx: Context, dir: File) = File(File(ctx.filesDir, "undo").also { it.mkdirs() }, dir.name + ".json")

    /**
     * Diff review: puts ONE file back to how it was before the last change (a new file is removed, a deleted file comes back).
     * The other files of the change stay. Needs the snapshot of that change.
     */
    fun revertFile(ctx: Context, dir: File, path: String): Boolean {
        val f = undoFile(ctx, dir)
        if (!f.exists()) return false
        val p = safe(path) ?: return false
        return try {
            val old = JSONObject(f.readText(Charsets.UTF_8))
            if (old.has(p)) writeFile(dir, p, old.getString(p))
            else { val t = File(dir, p); !t.exists() || t.delete() }
        } catch (e: Exception) { false }
    }

    private fun redoFile(ctx: Context, dir: File) = File(File(ctx.filesDir, "undo").also { it.mkdirs() }, dir.name + ".redo.json")

    fun canRedo(ctx: Context, dir: File) = redoFile(ctx, dir).exists()

    /** Undo that keeps the state it replaced, so a wrong tap can be brought back with [redo]. */
    fun undoWithRedo(ctx: Context, dir: File): Boolean {
        val now = JSONObject()
        for ((k, v) in readFiles(dir)) now.put(k, v)
        if (!undo(ctx, dir)) return false
        try { redoFile(ctx, dir).writeText(now.toString(), Charsets.UTF_8) } catch (e: Exception) {}
        return true
    }

    /** Brings back the state that the last [undoWithRedo] replaced; Undo works again afterwards. */
    fun redo(ctx: Context, dir: File): Boolean {
        val f = redoFile(ctx, dir)
        if (!f.exists()) return false
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            snapshot(ctx, dir)   // so Undo is possible again (this also clears the redo file)
            for (k in readFiles(dir).keys) File(dir, k).delete()
            for (k in o.keys()) writeFile(dir, k, o.getString(k))
            f.delete()
            true
        } catch (e: Exception) { false }
    }

    /** Saves the project's files so the next edit can be undone. */
    fun snapshot(ctx: Context, dir: File) {
        try { redoFile(ctx, dir).delete() } catch (e: Exception) {}
        try {
            val o = JSONObject()
            for ((k, v) in readFiles(dir)) o.put(k, v)
            undoFile(ctx, dir).writeText(o.toString(), Charsets.UTF_8)
        } catch (e: Exception) {}
    }

    fun canUndo(ctx: Context, dir: File) = undoFile(ctx, dir).exists()

    /** A short list of what the last edit changed, like a mini diff. */
    fun changes(ctx: Context, dir: File): String {
        val f = undoFile(ctx, dir)
        if (!f.exists()) return ""
        return try {
            val old = JSONObject(f.readText(Charsets.UTF_8))
            val now = readFiles(dir)
            val sb = StringBuilder()
            for ((p, c) in now) {
                if (!old.has(p)) { sb.append("➕ ").append(p).append("  (new, ").append(c.split("\n").size).append(" lines)\n"); continue }
                val o = old.getString(p)
                if (o == c) continue
                val cnt = HashMap<String, Int>()
                for (l in o.split("\n")) cnt[l] = (cnt[l] ?: 0) + 1
                var add = 0
                for (l in c.split("\n")) { val n = cnt[l] ?: 0; if (n > 0) cnt[l] = n - 1 else add++ }
                val del = cnt.values.sum()
                sb.append("✏️ ").append(p).append("  +").append(add).append("  -").append(del).append("\n")
            }
            for (k in old.keys()) if (!now.containsKey(k)) sb.append("🗑 ").append(k).append("  (deleted)\n")
            if (sb.isEmpty()) "" else "Changed files:\n" + sb.toString().trim()
        } catch (e: Exception) { "" }
    }

    /** One changed file of the last edit, with a ready-to-show diff (lines start with "+ ", "- " or "  "). */
    class Change(val path: String, val status: String, val add: Int, val del: Int, val diff: List<String>)

    /** Line diff with 2 lines of context per hunk. Uses LCS for normal files and a cheap fallback for huge ones. */
    internal fun lineDiff(o: List<String>, n: List<String>): List<String> {
        val ops = ArrayList<String>()
        if (o.size.toLong() * n.size <= 4_000_000L) {
            val w = n.size + 1
            val t = IntArray((o.size + 1) * w)
            for (i in o.size - 1 downTo 0) for (j in n.size - 1 downTo 0)
                t[i * w + j] = if (o[i] == n[j]) t[(i + 1) * w + j + 1] + 1 else maxOf(t[(i + 1) * w + j], t[i * w + j + 1])
            var i = 0; var j = 0
            while (i < o.size && j < n.size) {
                if (o[i] == n[j]) { ops.add("  " + o[i]); i++; j++ }
                else if (t[(i + 1) * w + j] >= t[i * w + j + 1]) { ops.add("- " + o[i]); i++ }
                else { ops.add("+ " + n[j]); j++ }
            }
            while (i < o.size) { ops.add("- " + o[i]); i++ }
            while (j < n.size) { ops.add("+ " + n[j]); j++ }
        } else {
            val on = o.toHashSet(); val nn = n.toHashSet()
            for (l in o) if (l !in nn) ops.add("- " + l)
            for (l in n) if (l !in on) ops.add("+ " + l)
            return ops
        }
        val keep = BooleanArray(ops.size)
        for (k in ops.indices) if (!ops[k].startsWith("  ")) for (m in maxOf(0, k - 2)..minOf(ops.size - 1, k + 2)) keep[m] = true
        val out = ArrayList<String>()
        var gap = false
        for (k in ops.indices) {
            if (keep[k]) { if (gap && out.isNotEmpty()) out.add("  ..."); gap = false; out.add(ops[k]) } else gap = true
        }
        return out
    }

    /** Every file the last edit created, changed or deleted, with +/- counts and a diff. Empty if nothing changed. */
    fun diffs(ctx: Context, dir: File): List<Change> {
        val f = undoFile(ctx, dir)
        if (!f.exists()) return emptyList()
        return try {
            val old = JSONObject(f.readText(Charsets.UTF_8))
            val now = readFiles(dir)
            val out = ArrayList<Change>()
            for ((p, c) in now) {
                val nl = c.split("\n")
                if (!old.has(p)) { out.add(Change(p, "new", nl.size, 0, nl.take(60).map { "+ " + it })); continue }
                val oc = old.getString(p)
                if (oc == c) continue
                val d = lineDiff(oc.split("\n"), nl)
                out.add(Change(p, "edit", d.count { it.startsWith("+ ") }, d.count { it.startsWith("- ") }, d.take(400)))
            }
            for (k in old.keys()) if (!now.containsKey(k)) out.add(Change(k, "deleted", 0, old.getString(k).split("\n").size, emptyList()))
            out
        } catch (e: Exception) { emptyList() }
    }

    /** Puts the project back to how it was before the last edit. */
    fun undo(ctx: Context, dir: File): Boolean {
        val f = undoFile(ctx, dir)
        if (!f.exists()) return false
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            for (k in readFiles(dir).keys) File(dir, k).delete()
            for (k in o.keys()) writeFile(dir, k, o.getString(k))
            f.delete()
            true
        } catch (e: Exception) { false }
    }

    private fun newDir(ctx: Context, name: String): File {
        val slug = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(24).ifEmpty { "project" }
        val d = File(root(ctx), slug + "-" + (System.currentTimeMillis() / 1000))
        d.mkdirs()
        return d
    }

    fun zip(dir: File): ByteArray {
        val bo = ByteArrayOutputStream()
        val skip = setOf("node_modules", ".git", "build", "dist", ".gradle", "__pycache__", ".idea", "__MACOSX", "venv", ".venv")
        ZipOutputStream(bo).use { z ->
            val files = dir.walkTopDown().onEnter { folder -> folder == dir || folder.name !in skip }
                .filter { it.isFile && !it.name.startsWith(".anjoo") }.sortedBy { it.path }
            for (file in files) {
                val rel = file.relativeTo(dir).path.replace('\\', '/')
                z.putNextEntry(ZipEntry(rel))
                file.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        return bo.toByteArray()
    }

    private val ZIP_SKIP = setOf("node_modules", ".git", "build", "dist", ".gradle", "__pycache__", ".idea", "__MACOSX", "venv", ".venv")

    private fun readZipEntryLimited(input: java.io.InputStream, maxBytes: Int): ByteArray? {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            if (out.size() + n > maxBytes) return null
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    /** Imports text plus binary assets into a project; bounds expansion and rejects unsafe paths to resist ZIP bombs/path traversal. */
    fun importZip(ctx: Context, bytes: ByteArray, zipName: String): File? {
        if (bytes.size > 25 * 1024 * 1024) return null
        val entries = ArrayList<Pair<String, ByteArray>>()
        var expanded = 0L
        try {
            java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(bytes)).use { z ->
                while (entries.size < 400) {
                    val e = z.nextEntry ?: break
                    if (e.isDirectory) continue
                    val n = e.name.replace('\\', '/')
                    val parts = n.split('/').filter { it.isNotEmpty() }
                    if (parts.isEmpty() || parts.any { it == "." || it == ".." || it.startsWith(".anjoo") } || parts.any { it in ZIP_SKIP }) continue
                    val data = readZipEntryLimited(z, 8 * 1024 * 1024) ?: continue
                    expanded += data.size
                    if (expanded > 40L * 1024 * 1024) return null
                    val safePath = safe(n) ?: continue
                    entries.add(Pair(safePath, data))
                }
            }
        } catch (_: Exception) { return null }
        if (entries.isEmpty()) return null
        val tops = entries.map { it.first.substringBefore('/', "") }.toSet()
        val strip = tops.size == 1 && tops.first().isNotEmpty() && entries.all { it.first.contains('/') }
        val base = zipName.substringBeforeLast('.').ifBlank { "project" }.take(40)
        val d = newDir(ctx, base)
        var written = 0
        for ((p, data) in entries) {
            val rel = if (strip) p.substringAfter('/') else p
            if (writeBytes(d, rel, data)) written++
        }
        if (written == 0) { d.deleteRecursively(); return null }
        saveMeta(d, JSONObject().put("name", base).put("created", System.currentTimeMillis()).put("importedFiles", written))
        return d
    }

    /** Text of an attached file for the coder: plain text/code as is, or all text files of a ZIP joined. Null when unreadable. */
    fun attachmentText(name: String, bytes: ByteArray): String? {
        if (bytes.size > 3 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()) {
            val sb = StringBuilder()
            var count = 0
            try {
                java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(bytes)).use { z ->
                    while (sb.length < 120000) {
                        val e = z.nextEntry ?: break
                        if (e.isDirectory) continue
                        val n = e.name.replace('\\', '/')
                        if (ZIP_SKIP.any { n.contains(it) }) continue
                        val data = z.readBytes()
                        if (data.size > 300000 || data.take(2000).any { it.toInt() == 0 }) continue
                        sb.append("=== ").append(n).append(" ===\n").append(String(data, Charsets.UTF_8)).append("\n\n")
                        count++
                    }
                }
            } catch (e: Exception) { return null }
            if (count == 0) return null
            return ("ZIP " + name + " (" + count + " files)\n\n" + sb).take(130000)
        }
        if (bytes.take(2000).any { it.toInt() == 0 }) return null
        return String(bytes, Charsets.UTF_8).take(120000)
    }

    fun projectDir(ctx: Context, name: String): File = File(root(ctx), name)

    /** Makes a one-file Code Studio project from code the user attached, so it can be edited like any project. */
    fun fileProject(ctx: Context, fileName: String, content: String): File {
        val nm = fileName.substringBeforeLast('.').take(40).ifBlank { "My code" }
        val dir = newDir(ctx, nm)
        saveMeta(dir, JSONObject().put("name", nm).put("language", "auto").put("created", System.currentTimeMillis()))
        writeFile(dir, fileName, content)
        addHistory(dir, "u", "Attached " + fileName)
        keepCopy(ctx, dir)
        return dir
    }

    private fun keepRoot(ctx: Context) = File(ctx.filesDir, "chatkeep").also { it.mkdirs() }

    /** A second copy of a chat's project, so the files in the chat survive even if the project is deleted in Code Studio. */
    fun keepCopy(ctx: Context, dir: File) {
        try { dir.copyRecursively(File(keepRoot(ctx), dir.name), overwrite = true) } catch (e: Exception) {}
    }

    /** The project folder for a chat card; brings it back from the kept copy when it was deleted. */
    fun ensureProject(ctx: Context, name: String): File? {
        val d = projectDir(ctx, name)
        if (d.exists()) return d
        val k = File(keepRoot(ctx), name)
        if (!k.exists()) return null
        return try { k.copyRecursively(d, overwrite = true); d } catch (e: Exception) { null }
    }

    private val SKIP_LANGS = setOf("", "text", "txt", "output", "console", "bash", "sh", "shell", "zsh", "diff", "log", "markdown", "md")

    private fun snippetName(l: String): String = when (l) {
        "html", "htm" -> "index.html"
        "svg" -> "image.svg"
        "css" -> "style.css"
        "js", "javascript" -> "script.js"
        "ts", "typescript" -> "index.ts"
        "py", "python" -> "main.py"
        "kotlin", "kt" -> "Main.kt"
        "java" -> "Main.java"
        "c" -> "main.c"
        "cpp", "c++" -> "main.cpp"
        "go" -> "main.go"
        "rust", "rs" -> "main.rs"
        "php" -> "index.php"
        "json" -> "data.json"
        "sql" -> "query.sql"
        "dart" -> "main.dart"
        else -> ""
    }

    /**
     * Turns the code blocks of a chat reply into project files inside Code Studio.
     * A file name is taken from the line just before a block (FILE: x), from a first-line comment, or from the language.
     * Returns the folder and its file count, or null when there is nothing worth keeping.
     * When [existing] already holds a file with the same name, that project is updated instead of a new one.
     */
    fun saveFromChat(ctx: Context, reply: String, title: String, existing: File?, force: Boolean = false): Pair<File, Int>? {
        val fence = Regex("```([A-Za-z0-9+#._-]*)[ \\t]*\\r?\\n([\\s\\S]*?)```")
        val tokRe = Regex("([A-Za-z0-9_][A-Za-z0-9_./-]*\\.[A-Za-z0-9]{1,6})")
        val commentRe = Regex("^(?://|#|--|<!--|/\\*)\\s*(?:file(?:name)?\\s*[:=]\\s*)?([A-Za-z0-9_][A-Za-z0-9_./-]*\\.[A-Za-z0-9]{1,6})\\s*(?:-->|\\*/)?\\s*$", RegexOption.IGNORE_CASE)
        val names = ArrayList<String>()
        val codes = ArrayList<String>()
        var labelled = false
        var lineCount = 0
        var firstLang = ""
        for (m in fence.findAll(reply)) {
            val lang = m.groupValues[1].lowercase()
            val code = m.groupValues[2].trimEnd()
            if (code.isBlank()) continue
            val before = reply.substring(maxOf(0, m.range.first - 160), m.range.first).trimEnd().lines().lastOrNull() ?: ""
            var name: String? = null
            var isLabel = false
            val tok = tokRe.find(before)?.groupValues?.get(1)
            if (tok != null && before.length < 90 &&
                (before.contains("file", true) || before.trim().trim('*', '_', '`', ':', ' ', '#', '>', '-') == tok)) { name = tok; isLabel = true }
            if (name == null) {
                val c = commentRe.find(code.lines().first().trim())?.groupValues?.get(1)
                if (c != null) { name = c; isLabel = true }
            }
            if (name == null) {
                if (lang in SKIP_LANGS) continue
                name = snippetName(lang)
                if (name.isEmpty()) continue
            }
            name = name.trimStart('/', '.')
            if (name.isEmpty()) continue
            val at = names.indexOf(name)
            if (at >= 0) {
                if (isLabel) { codes[at] = code; continue }
                var n = 2
                val dot = name.lastIndexOf('.')
                val stem = if (dot > 0) name.substring(0, dot) else name
                val ext = if (dot > 0) name.substring(dot) else ""
                while (names.contains(stem + n + ext)) n++
                name = stem + n + ext
            }
            if (isLabel) labelled = true
            if (firstLang.isEmpty()) firstLang = lang
            names.add(name); codes.add(code)
            lineCount += code.count { it == '\n' } + 1
        }
        if (names.isEmpty() || (!force && !labelled && lineCount < 12)) return null
        val reuse = existing != null && existing.exists() && names.any { readFiles(existing).containsKey(it) }
        val dir: File
        if (reuse) {
            dir = existing!!
            snapshot(ctx, dir)
        } else {
            val nm = title.replace(Regex("\\s+"), " ").trim().take(40).ifBlank { "Chat project" }
            dir = newDir(ctx, nm)
            saveMeta(dir, JSONObject().put("name", nm).put("language", firstLang.ifEmpty { "auto" }).put("created", System.currentTimeMillis()))
            addHistory(dir, "u", title.take(300))
            addHistory(dir, "a", "Saved from the Anjoo chat.")
        }
        for (i in names.indices) writeFile(dir, names[i], codes[i] + "\n")
        keepCopy(ctx, dir)
        return Pair(dir, readFiles(dir).size)
    }

    /** Saves one code block from the chat as its own small project, so it can be edited and exported. */
    fun snippetProject(ctx: Context, lang: String, code: String): File {
        val l = lang.lowercase()
        val file = when (l) {
            "html", "htm" -> "index.html"
            "svg" -> "image.svg"
            "css" -> "style.css"
            "js", "javascript" -> "script.js"
            "ts", "typescript" -> "index.ts"
            "py", "python" -> "main.py"
            "kotlin", "kt" -> "Main.kt"
            "java" -> "Main.java"
            "c" -> "main.c"
            "cpp", "c++" -> "main.cpp"
            "go" -> "main.go"
            "rust", "rs" -> "main.rs"
            "php" -> "index.php"
            "sh", "bash", "shell" -> "script.sh"
            "json" -> "data.json"
            "sql" -> "query.sql"
            "dart" -> "main.dart"
            else -> "snippet.txt"
        }
        val dir = newDir(ctx, "snippet " + l)
        writeFile(dir, file, code + "\n")
        saveMeta(dir, JSONObject().put("name", "Snippet (" + l.ifEmpty { "code" } + ")").put("language", l).put("created", System.currentTimeMillis()))
        return dir
    }

    /** Shows a finished project: a website opens in the full-screen preview, anything else stays in the chat. */
    fun show(ctx: Context, dir: File) {
        if (PreviewServer.entry(dir) != null) {
            ctx.startActivity(
                Intent(ctx, ProjectPreviewActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("project", dir.absolutePath)
            )
        } else {
            open(ctx, dir)
        }
    }

    /** There is no separate editor screen any more: websites open in the preview, everything else lives in the chat. */
    fun open(ctx: Context, dir: File?, preview: Boolean = false) {
        if (dir != null && PreviewServer.entry(dir) != null) { show(ctx, dir); return }
        android.widget.Toast.makeText(ctx, "The project is in the chat: write there what to change.", android.widget.Toast.LENGTH_SHORT).show()
    }

    // ---------- parsing ----------

    private fun cleanFile(b: String): String {
        var t = b.trim('\n', '\r')
        var fenced = false
        if (t.trimStart().startsWith("```")) { t = t.trimStart().substringAfter("\n", ""); fenced = true }
        if (fenced) {
            val e = t.trimEnd()
            if (e.endsWith("```")) t = e.removeSuffix("```")
        }
        return t.trimEnd() + "\n"
    }

    fun parse(raw: String): Out {
        val re = Regex("(?m)^=== (FILE|DELETE|EDIT): (.+?) ===[ \\t]*$")
        val ms = re.findAll(raw).toList()
        var notes = raw
        val files = ArrayList<Pair<String, String>>()
        val dels = ArrayList<String>()
        val edits = ArrayList<Edit>()
        if (ms.isNotEmpty()) {
            notes = raw.substring(0, ms[0].range.first)
            for (i in ms.indices) {
                val m = ms[i]
                val end = if (i + 1 < ms.size) ms[i + 1].range.first else raw.length
                val body = raw.substring(m.range.last + 1, end)
                val path = m.groupValues[2].trim()
                when (m.groupValues[1]) {
                    "DELETE" -> dels.add(path)
                    "EDIT" -> edits.addAll(parseEdits(path, body))
                    else -> files.add(Pair(path, cleanFile(body)))
                }
            }
        }
        notes = notes.replace(Regex("(?m)^=== NOTES ===[ \\t]*$"), "").trim()
        return Out(notes, files, dels, edits)
    }

    private val EDIT_RE = Regex("<<<<<<< SEARCH\\r?\\n([\\s\\S]*?)\\r?\\n=======\\r?\\n([\\s\\S]*?)\\r?\\n?>>>>>>> REPLACE")

    private fun parseEdits(path: String, body: String): List<Edit> =
        EDIT_RE.findAll(body).map { Edit(path, it.groupValues[1], it.groupValues[2]) }.toList()

    /** Replaces the first match of [search]; falls back to a match that ignores indentation and trailing spaces. */
    private fun replaceOnce(text: String, search: String, repl: String): String? {
        if (search.isEmpty()) return null
        val k = text.indexOf(search)
        if (k >= 0) return text.substring(0, k) + repl + text.substring(k + search.length)
        val tl = text.split("\n")
        val sl = search.trim('\n', '\r').split("\n").map { it.trim() }
        if (sl.all { it.isEmpty() }) return null
        var at = -1
        for (i in 0..(tl.size - sl.size)) {
            var ok = true
            for (j in sl.indices) if (tl[i + j].trim() != sl[j]) { ok = false; break }
            if (ok) { at = i; break }
        }
        if (at < 0) return null
        val out = ArrayList<String>()
        out.addAll(tl.subList(0, at))
        if (repl.isNotEmpty()) {
            // the model's indentation may differ from the file's: shift the replacement to the file's indentation
            val sInd = search.trim('\n', '\r').split("\n").first().takeWhile { it == ' ' || it == '\t' }
            val fInd = tl[at].takeWhile { it == ' ' || it == '\t' }
            for (ln in repl.trim('\n', '\r').split("\n"))
                out.add(if (sInd != fInd && ln.startsWith(sInd)) fInd + ln.substring(sInd.length) else ln)
        }
        out.addAll(tl.subList(at + sl.size, tl.size))
        return out.joinToString("\n")
    }

    /** Applies search/replace edits. Returns the paths where at least one edit did not match. */
    private fun applyEdits(dir: File, edits: List<Edit>, touched: MutableSet<String>): List<String> {
        val failed = LinkedHashSet<String>()
        val byFile = LinkedHashMap<String, MutableList<Edit>>()
        for (e in edits) {
            val p = safe(e.path) ?: continue
            byFile.getOrPut(p) { ArrayList() }.add(e)
        }
        for ((p, list) in byFile) {
            val f = File(dir, p)
            val first = try { if (f.isFile) f.readText(Charsets.UTF_8) else null } catch (ex: Exception) { null }
            if (first == null) { failed.add(p); continue }
            var text: String = first
            var changed = false
            for (e in list) {
                val r = replaceOnce(text, e.search, e.replace)
                if (r == null) failed.add(p) else { text = r; changed = true }
            }
            if (changed && writeFile(dir, p, text)) touched.add(p)
        }
        return failed.toList()
    }

    private fun apply(dir: File, o: Out, failed: MutableList<String>? = null): Int {
        val touched = LinkedHashSet<String>()
        for ((p, c) in o.files) if (writeFile(dir, p, c)) { val sp = safe(p); if (sp != null) touched.add(sp) }
        val bad = applyEdits(dir, o.edits, touched)
        if (failed != null) failed.addAll(bad)
        for (p in o.deletes) {
            val sp = safe(p) ?: continue
            try { File(dir, sp).delete() } catch (e: Exception) {}
            touched.add(sp)
        }
        return touched.size
    }

    private fun dump(files: Map<String, String>, cap: Int = 110000): String {
        val sb = StringBuilder()
        for ((p, c) in files) {
            if (sb.length + c.length > cap) { sb.append("=== FILE: ").append(p).append(" === (skipped, too large)\n"); continue }
            sb.append("=== FILE: ").append(p).append(" ===\n").append(c).append("\n")
        }
        return sb.toString()
    }

    // ---------- model calls ----------

    /** Live view of the current model call: (thought summary so far, answer so far). Set by the screen showing progress. */
    @Volatile var live: ((String, String) -> Unit)? = null

    /** Stop support: every run remembers the id it started with; [stop] makes older runs quit at their next model call. */
    @Volatile private var runId = 0
    private val tid = ThreadLocal<Int>()
    fun stop() { runId++ }
    private fun enter() { tid.set(runId) }
    private fun stale(): Boolean { val me: Int? = tid.get(); return me != null && me != runId }

    fun deepDefault(ctx: Context): Boolean = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean("codeThink", true)

    private fun gen(
        ctx: Context, system: String, user: String, max: Int,
        deep: Boolean = false, thought: (String) -> Unit = {}
    ): String {
        if (stale()) throw java.util.concurrent.CancellationException("Stopped")
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        Providers.load(p)
        val key = p.getString("key", "") ?: ""
        if (key.isEmpty()) throw IllegalStateException("Add an API key in Settings first.")
        val own = if (Providers.active.id == "gemini") (p.getString("codeModel", "") ?: "") else ""
        val model = own.ifBlank { p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash" }
        val limit = if (deep) minOf(60000, max + 16000) else max
        val f0 = live
        val me: Int? = tid.get()
        val lv: ((String, String) -> Unit)? = if (f0 == null) null else fun(a: String, b: String) { if (me == null || me == runId) f0(a, b) }
        Router.taskOverride.set(Task.CODE)
        val r = try { Gemini.plainFull(key, model, system, JSONArray().put(JSONObject().put("text", user)), limit, 0.3, deep, lv) } finally { Router.taskOverride.remove() }
        if (stale()) throw java.util.concurrent.CancellationException("Stopped")
        if (r.thoughts.isNotBlank()) thought(r.thoughts)
        return r.text
    }

    private fun defaultName(language: String): String = when (language.lowercase()) {
        "python", "py" -> "main.py"
        "kotlin" -> "Main.kt"
        "java" -> "Main.java"
        "javascript", "js", "node" -> "index.js"
        "typescript", "ts" -> "index.ts"
        "c++", "cpp" -> "main.cpp"
        "c" -> "main.c"
        "go" -> "main.go"
        "rust" -> "main.rs"
        "php" -> "index.php"
        else -> "index.html"
    }

    // ---------- documents (ChatGPT-style) ----------

    private val DOC_WORDS = Regex("(?i)\\b(document|documents|report|resume|cv|proposal|letter|essay|assignment|article|brochure|invoice|contract|agreement|policy|notes|handbook|guide|manual|whitepaper|case study|lesson plan|meeting minutes|cover letter|application|dastavez|rapat)\\b")
    private val CODE_WORDS = Regex("(?i)\\b(website|web site|webpage|web app|app|game|html|css|javascript|python|kotlin|api|script|code|program|login|landing|dashboard|bot|backend|frontend|component|calculator|todo|tool)\\b")

    /** True when the request is for a written document (report, resume, letter...) rather than software. */
    fun isDocument(task: String): Boolean = DOC_WORDS.containsMatchIn(task) && !CODE_WORDS.containsMatchIn(task)

    private const val DOC_PLAN_SYS = "You are a senior editor planning a professional document before writing it. Reply with at most 40 lines and NO full prose. " +
        "Line 1 must be: NAME: a short document title (2-5 words). Then: TYPE (report, resume, letter, proposal...); AUDIENCE AND TONE; " +
        "REQUIREMENTS (every explicit and implicit requirement from the user's request, as short bullets, including names, numbers, dates, language and length they gave); " +
        "STRUCTURE (numbered list of every section with one line saying what it contains; add a title block, a short summary up front and a conclusion or next steps when the type calls for them); " +
        "TABLES AND LISTS (where a table or checklist makes the content clearer). Use the same language as the user (Roman Urdu, Urdu or English). Never invent facts the user did not give: use a clear [placeholder] instead."

    private const val DOC_SYS = "You are Anjoo Docs, a professional writer and document designer who produces documents the way ChatGPT does: complete, well structured and ready to use. " +
        "Follow the DOCUMENT PLAN exactly and satisfy every requirement in it. Write real, specific, useful text for every section (no filler, no lorem ipsum, no 'add content here'). " +
        "Never invent personal data, statistics or quotes: leave a clear [placeholder] where the user must fill something in.\n" +
        "Produce exactly TWO files:\n" +
        "1. index.html: ONE self-contained styled document page (inline CSS, no external files, no scripts needed). Use a clean A4-style page: centred column max-width 800px, white page on a soft background, " +
        "system-ui font stack, a title block, a table of contents with working #anchor links when there are 4 or more sections, h1/h2/h3 hierarchy, readable line-height, styled tables, lists and callout boxes, " +
        "page numbers are not needed. Add @media print rules (A4, 18mm margins, no background, avoid page breaks inside tables and headings) so Print > Save as PDF looks perfect. " +
        "Add <meta name=viewport> so it also reads well on a phone. If the text is Urdu or Arabic script use dir=rtl lang=ur and a suitable font stack (Noto Nastaliq Urdu, Jameel Noori Nastaleeq, serif); otherwise dir=ltr.\n" +
        "2. document.md: the same content as clean Markdown, so it can be edited or pasted anywhere.\n" +
        "Both files must contain identical content and structure.\n"

    /** Plans and writes a finished document (styled HTML page + Markdown copy). */
    private fun buildDocument(
        ctx: Context, task: String, deep: Boolean, thought: (String) -> Unit, note: (String) -> Unit
    ): Pair<File, String> {
        note(if (deep) "Deep analysis of your requirements..." else "Planning the document structure...")
        val plan = gen(ctx, DOC_PLAN_SYS, "Request: " + task, 3500, deep, thought)
        val name = Regex("(?m)^NAME:\\s*(.+)$").find(plan)?.groupValues?.get(1)?.trim()?.take(40)?.ifBlank { null } ?: task.take(30)
        thought("📐 Document plan\n" + plan)
        note("Writing the document...")
        val dir = newDir(ctx, name)
        saveMeta(dir, JSONObject().put("name", name).put("language", "document").put("created", System.currentTimeMillis()))
        addHistory(dir, "u", task)
        val raw = gen(ctx, DOC_SYS + FORMAT, "Request: " + task + "\n\nDOCUMENT PLAN (follow it and satisfy every requirement):\n" + plan, 32000, deep, thought)
        val out = parse(raw)
        var files = out.files
        if (files.isEmpty()) {
            val body = cleanFile(raw)
            if (body.isBlank()) throw IllegalStateException("The document could not be created, please try again.")
            files = listOf(Pair("index.html", body))
        }
        for ((p, c) in files) writeFile(dir, p, c)
        if (!readFiles(dir).containsKey("index.html")) {
            val first = readFiles(dir).entries.firstOrNull { it.key.endsWith(".html", true) }
            if (first != null) writeFile(dir, "index.html", first.value)
        }
        note("Checking the structure...")
        val have = readFiles(dir).keys
        var notes = out.notes.ifBlank { "Document is ready: " + have.size + " file(s)." }
        notes += "\n(View it in Preview; for PDF use Print > Save as PDF from Preview, for Word copy document.md or the HTML.)"
        addHistory(dir, "a", notes)
        return Pair(dir, notes)
    }

    /** Analyses, plans, writes and reviews (two rounds) a brand-new project. Returns the folder and a short note. */
    /** When true (set by the Website Builder), files are written one page at a time instead of one huge reply. */
    @Volatile var pageByPage = false

    /** Called as soon as a new project folder exists, so callers can save progress before the long build starts. */
    @Volatile var onDirCreated: ((File) -> Unit)? = null

    /** Files that are missing content, empty or cut off (used to resume an interrupted build). */
    internal fun brokenFiles(dir: File): List<String> =
        readFiles(dir).keys.filter { brokenReason(dir, it) != null }

    fun build(
        ctx: Context, task: String, language: String, review: Boolean,
        deep: Boolean = false, thought: (String) -> Unit = {}, note: (String) -> Unit
    ): Pair<File, String> {
        enter()
        if (isDocument(task)) return buildDocument(ctx, task, deep, thought, note)
        val lang = language.ifBlank { "auto" }
        note("🔎 Analyst Agent: reading and understanding the request...")
        note("🏗 Architect Agent: planning the architecture...")
        val plan = gen(ctx, PLAN_SYS + PLAN_EXTRA, "Language/stack: " + lang + "\nTask: " + task, 9000, deep, thought)
        val name = Regex("(?m)^NAME:\\s*(.+)$").find(plan)?.groupValues?.get(1)?.trim()?.take(40)?.ifBlank { null } ?: task.take(30)
        thought("📐 Design plan\n" + plan)
        note("⌘ Builder Agent: writing the code...")
        val planned = planFiles(plan)
        val dir = newDir(ctx, name)
        saveMeta(dir, JSONObject().put("name", name).put("language", lang).put("created", System.currentTimeMillis())
            .put("plan", plan.take(20000)).put("task", task.take(6000)).put("state", "building"))
        try { onDirCreated?.invoke(dir) } catch (_: Exception) { }
        addHistory(dir, "u", task)
        var batchNotes = ""
        // Try one-shot first (all files in one call). Fall back to batches only when the output is incomplete.
        // Page-by-page mode (websites with 2+ planned files) skips the one huge reply: shared files first, then one page per call.
        val usePages = pageByPage && planned.size >= 2
        var oneShotRaw = ""
        if (!usePages) {
            note("⌘ Builder Agent: writing all files...")
            oneShotRaw = gen(ctx, SYSTEM + FORMAT,
                "Language/stack: " + lang + "\nTask: " + task +
                "\n\nDESIGN PLAN (follow it and satisfy its test scenarios):\n" + plan +
                "\n\nWRITE ALL FILES NOW in this single response, each one COMPLETE from its first line to its last. Do NOT split across multiple replies.",
                32000, deep, thought)
            val oneShotOut = parse(oneShotRaw)
            if (!oneShotOut.isEmpty) {
                apply(dir, oneShotOut)
                batchNotes = oneShotOut.notes
            }
        } else note("⌘ Builder Agent: building page by page (" + planned.size + " files)...")
        // Fill any missing/broken files via batches
        val missing = planned.filter { p -> val f = java.io.File(dir, p); !f.isFile || f.length() < 20L }
        if (missing.isNotEmpty()) {
            note("🧩 Completer Agent: completing " + missing.size + " remaining file(s)...")
            val patchNotes = try {
                writeInBatches(ctx, dir, task, lang, plan, missing, deep, thought, note)
            } catch (e: java.util.concurrent.CancellationException) {
                throw e
            } catch (e: Exception) { "" }
            if (batchNotes.isBlank() && patchNotes.isNotBlank()) batchNotes = patchNotes
        }
        if (readFiles(dir).isEmpty()) {
            val body = cleanFile(oneShotRaw)
            if (body.isBlank()) throw IllegalStateException("The code could not be created, please try again.")
            writeFile(dir, defaultName(lang), body)
        }
        try { finishMissing(ctx, dir, plan, task, deep, thought, note) } catch (e: Exception) {}
        var notes = batchNotes.ifBlank { "Project is ready: " + readFiles(dir).size + " file(s)." }
        if (review && !stale()) {
            var fixed = 0
            note("🛡 Syntax Guard Agent: checking brackets, ids and leftover placeholders...")
            try {
                if (deep || planned.size >= 3) {
                    note("📋 Auditor Agent: checking that nothing from your request is missing...")
                    fixed += auditPass(ctx, dir, task, plan, deep, thought)
                }
            } catch (e: Exception) {}
            try {
                // Cheap local checks first: the model review runs when Deep think is on or the checks found something.
                if (deep || lint(readFiles(dir)).isNotBlank() || Engineering.findings(readFiles(dir)).any { it.level.rank >= Engineering.Level.REVIEW.rank }) {
                    note("🔍 Reviewer Agent: reviewing and testing (round 1)...")
                    val n1 = reviewPass(ctx, dir, plan, deep, thought)
                    fixed += n1
                    if (n1 > 0) {
                        note("🔍 Reviewer Agent: verifying the fixes (round 2)...")
                        fixed += reviewPass(ctx, dir, plan, deep, thought)
                    }
                }
            } catch (e: Exception) {}
            if (deep && !stale()) {
                try {
                    if (readFiles(dir).keys.any { k -> k.endsWith(".html", true) || k.endsWith(".css", true) }) {
                        note("🎨 UI Agent: polishing layout, spacing and states...")
                        fixed += agentPass(ctx, dir, UI_SYS, plan, deep, thought)
                    }
                } catch (e: Exception) {}
            }
            if (deep && !stale()) {
                try {
                    note("🔒 Security Agent: checking safety and robustness...")
                    fixed += agentPass(ctx, dir, SEC_SYS, plan, deep, thought)
                } catch (e: Exception) {}
            }
            var verdictLine = ""
            try { val v = verifyAndFix(ctx, dir, deep, thought, note); fixed += v.fixed; verdictLine = v.line } catch (e: CancelledException) { throw e } catch (e: Exception) {}
            var qualityLine = ""
            if (!stale()) {
                try { val q = qualityPass(ctx, dir, plan, deep, thought, note); fixed += q.first; qualityLine = q.second } catch (e: CancelledException) { throw e } catch (e: Exception) {}
            }
            if (fixed > 0) notes += "\n(Review and run check: " + fixed + " file fix(es) applied.)"
            if (verdictLine.isNotBlank()) notes += "\n" + verdictLine
            if (qualityLine.isNotBlank()) notes += "\n" + qualityLine
            if (deep) notes += "\n(Code team: Analyst, Architect, Builder, Completer, Syntax Guard, Auditor, Reviewer, UI, Security, Tester, Docs.)"
        }
        setState(dir, "done")
        addHistory(dir, "a", notes)
        return Pair(dir, notes)
    }

    /** Build order: setup files, styles, data, logic, inner pages, the entry page, then docs. */
    internal fun orderRank(path: String): Int {
        val n = path.lowercase()
        val ext = n.substringAfterLast('.', "")
        val base = n.substringAfterLast('/')
        return when {
            base == "package.json" || base == "requirements.txt" || base == "pubspec.yaml" || base.endsWith(".gradle") || base.endsWith(".gradle.kts") -> 0
            ext == "css" || ext == "scss" -> 1
            ext == "json" || ext == "csv" || ext == "sql" -> 2
            ext in setOf("js", "mjs", "ts", "py", "kt", "java", "go", "rs", "cs", "dart", "php", "c", "cpp", "h") -> 3
            base == "index.html" -> 5
            ext == "html" -> 4
            ext == "md" -> 7
            else -> 6
        }
    }

    /** Why a written file is not usable (missing, empty or cut off), or null when it looks complete. */
    private fun brokenReason(dir: File, path: String): String? {
        val rel = safe(path) ?: return null
        val f = File(dir, rel)
        if (!f.isFile) return "it was not written"
        val c = try { f.readText(Charsets.UTF_8) } catch (e: Exception) { return null }
        if (c.isBlank()) return "it is empty"
        val ext = rel.lowercase().substringAfterLast('.', "")
        if (ext == "html" && c.contains("<html", true) && !c.contains("</html>", true)) return "it is cut off (no closing </html>)"
        if (ext in BRACKET_EXT) {
            val bc = bracketCheck(c, ext == "py", ext == "css" || ext == "scss")
            if (bc != null) return "it is cut off or unbalanced: " + bc
        }
        return null
    }

    /** Writes every planned file, three at a time, each call seeing the files already written. Returns the notes. */
    private fun writeInBatches(
        ctx: Context, dir: File, task: String, lang: String, plan: String, planned: List<String>,
        deep: Boolean, thought: (String) -> Unit, note: (String) -> Unit
    ): String {
        val order = planned.sortedBy { orderRank(it) }
        var notes = ""
        var done = 0
        // Page-by-page: shared files (css/js/data) together first, then every HTML page on its own.
        val chunks: List<List<String>> = if (pageByPage) {
            val pages = order.filter { it.lowercase().endsWith(".html") }
            val shared = order.filter { !it.lowercase().endsWith(".html") }
            shared.chunked(4) + pages.map { listOf(it) }
        } else order.chunked(6)
        for ((i, batch) in chunks.withIndex()) {
            if (stale()) throw java.util.concurrent.CancellationException("Stopped")
            note("Writing files " + (done + 1) + "–" + minOf(done + batch.size, order.size) + " of " + order.size + ":  " + batch.joinToString("  ·  ") { it.substringAfterLast('/') })
            val have = readFiles(dir)
            val raw = gen(
                ctx, SYSTEM + FORMAT,
                "Language/stack: " + lang + "\nTask: " + task + "\n\nDESIGN PLAN (follow it exactly and satisfy its test scenarios):\n" + plan +
                    (if (have.isEmpty()) "" else "\n\nFILES ALREADY WRITTEN (reuse their ids, function names, classes and paths exactly):\n" + dump(have, 60000)) +
                    "\n\nWrite ONLY these files now, each one COMPLETE from its first line to its last: " + batch.joinToString(", ") +
                    ". Do not write any other file." +
                    (if (pageByPage) " This is one part of a multi-page website: reuse the exact navbar, footer, CSS classes, design tokens and script functions of the files already written, link only to files in the plan, and never leave content hidden by default." else "") +
                    (if (i == 0) " Begin with the NOTES section." else " Skip the NOTES section."),
                32000, deep, thought
            )
            val o = parse(raw)
            if (i == 0 && o.notes.isNotBlank()) notes = o.notes
            if (!o.isEmpty) apply(dir, o)
            for (p in batch) {
                try { rewriteIfBroken(ctx, dir, task, lang, plan, p, deep, thought) }
                catch (e: java.util.concurrent.CancellationException) { throw e }
                catch (e: Exception) { }
            }
            done += batch.size
        }
        return notes
    }

    /** Writes one file again, alone, when it is missing or was cut short. */
    private fun rewriteIfBroken(ctx: Context, dir: File, task: String, lang: String, plan: String, path: String, deep: Boolean, thought: (String) -> Unit) {
        val why = brokenReason(dir, path) ?: return
        if (stale()) return
        val others = readFiles(dir).filterKeys { it != path }
        val raw = gen(
            ctx, SYSTEM + FORMAT,
            "Language/stack: " + lang + "\nTask: " + task + "\n\nDESIGN PLAN:\n" + plan +
                "\n\nFILES ALREADY WRITTEN:\n" + dump(others, 60000) +
                "\n\nWrite the file " + path + " again, COMPLETE from its first line to its last, because " + why + ". Output only that file.",
            32000, deep, thought
        )
        val o = parse(raw)
        if (!o.isEmpty) apply(dir, o)
    }

    /** Compares the finished project with the ORIGINAL request and builds whatever is still missing. */
    /** One extra specialist pass: the agent reads the whole project and returns only the edits it makes. */
    private fun agentPass(ctx: Context, dir: File, sys: String, plan: String, deep: Boolean, thought: (String) -> Unit): Int {
        val raw = gen(ctx, sys + FORMAT, "DESIGN PLAN:\n" + plan + "\n\nPROJECT:\n" + dump(readFiles(dir)), 32000, deep, thought)
        val o = parse(raw)
        if (o.isEmpty) return 0
        return apply(dir, o)
    }

    private const val UI_SYS = "You are the UI AGENT, a senior product designer and front-end engineer. Read the whole project and improve ONLY the look and feel and the usability: clear visual hierarchy, a consistent spacing scale and colour variables, readable type, large touch targets (44px or more), pressed and focus states, responsive mobile-first layout, dark mode, designed empty, loading and error states, smooth but light transitions. " +
        "Keep every feature, id, class and function name that the JavaScript uses. Never add external libraries, fonts or links. Output ONLY what you changed, as EDIT blocks (preferred) or complete FILE blocks, in the format below. If the UI is already excellent output exactly NO_CHANGES." + EDIT_FMT

    private const val SEC_SYS = "You are the SECURITY AGENT, an application security engineer. Read the whole project and fix only REAL problems: untrusted text put into the page without escaping, unsafe eval or innerHTML, missing input validation, secrets or keys written in code, string-built SQL, unsafe file paths, missing error handling that can crash on bad data, and data that can be lost when storage fails. " +
        "Do not rewrite for style and do not remove features. Output ONLY what you changed, as EDIT blocks (preferred) or complete FILE blocks, in the format below. If nothing real is wrong output exactly NO_CHANGES." + EDIT_FMT

    private const val DOCS_SYS = "You are the DOCS AGENT. Read the whole project and write one short, accurate README.md: what the project is, how to run it step by step, the file structure with one line per file, the main features, where the data is stored, and a short 'Limits' list. " +
        "Write ONLY what the code really does: never invent a feature, command, setting or file; if something is unclear leave it out. Do not change any other file. " +
        "Output the README.md as a complete FILE block in the format below." + EDIT_FMT

    private const val TEST_SYS = "You are the TEST AGENT. Write ONE test file for the JavaScript modules below that export functions (module.exports / export). " +
        "Use describe / it / expect and CommonJS require with the correct relative path, put the file in tests/ and name it <module>.test.js. " +
        "Test only functions that really exist, with their exact names and argument order. For each important pure function write a normal case, an edge case (empty, zero, negative, invalid input) and every branch you see: 4 to 10 tests in all. " +
        "Work out every expected value by hand from the code; if you are not sure of a value, skip that test. No network, no timers, no DOM, no randomness. Do not change any source file. " +
        "Output only the test file as a complete FILE block in the format below. If nothing in the project can be unit tested, output exactly NO_CHANGES." + EDIT_FMT

    internal val EXPORT_RE = Regex("(?m)\\bmodule\\.exports\\b|^\\s*export\\s+(default|function|const|class|\\{)")

    /**
     * Quality standard for every new project: a README that matches the code, and unit tests for the modules that can be tested.
     * Tests are written but NOT run here (running them sends code to the online sandbox, which asks the user first).
     * Returns lines for the reply and how many files were added.
     */
    internal fun qualityPass(ctx: Context, dir: File, plan: String, deep: Boolean, thought: (String) -> Unit, note: (String) -> Unit): Pair<Int, String> {
        var added = 0
        val sb = StringBuilder()
        if (stale()) return Pair(0, "")
        val files = readFiles(dir)
        val hasCode = files.keys.any { CodeNav.family(it).isNotEmpty() }
        if (files.keys.none { it.equals("README.md", true) } && (files.size >= 2 || hasCode)) {
            note("📝 Docs Agent: writing the README...")
            try { added += agentPass(ctx, dir, DOCS_SYS, plan, deep, thought) } catch (e: CancelledException) { throw e } catch (e: Exception) {}
        }
        if (stale()) return Pair(added, sb.toString())
        val now = readFiles(dir)
        val testable = now.filter { (k, v) -> k.matches(Regex(".*\\.(m?js|cjs)$")) && !RunTests.isJsTest(k) && !k.contains("node_modules/") && EXPORT_RE.containsMatchIn(v) }
        if (testable.isNotEmpty() && RunTests.jsTestFiles(now.keys).isEmpty()) {
            note("🧪 Test Agent: writing unit tests...")
            try {
                val raw = gen(ctx, TEST_SYS + FORMAT, "DESIGN PLAN:\n" + plan + "\n\nMODULES TO TEST:\n" + dump(testable) + "\n\nWHOLE PROJECT (for context):\n" + dump(pickFiles(now, "tests " + testable.keys.joinToString(" "))), 32000, deep, thought)
                val o = parse(raw)
                // only test files are accepted from this agent; it can never change the source
                val onlyTests = Out(o.notes, o.files.filter { RunTests.isJsTest(it.first) }, emptyList(), emptyList())
                if (!onlyTests.isEmpty) {
                    added += apply(dir, onlyTests)
                    val names = RunTests.jsTestFiles(readFiles(dir).keys)
                    if (names.isNotEmpty()) sb.append("🧪 Tests written: ").append(names.joinToString(", ")).append(" (not run yet: use the project menu, Run tests).")
                }
            } catch (e: CancelledException) { throw e } catch (e: Exception) {}
        }
        if (!stale()) {
            try {
                val py = pythonTestPass(ctx, dir, plan, deep, thought, note)
                added += py.first
                if (py.second.isNotBlank()) { if (sb.isNotEmpty()) sb.append('\n'); sb.append(py.second) }
            } catch (e: CancelledException) { throw e } catch (e: Exception) {}
        }
        if (!stale()) {
            try {
                val ct = compiledTestPass(ctx, dir, plan, deep, thought, note)
                added += ct.first
                if (ct.second.isNotBlank()) { if (sb.isNotEmpty()) sb.append('\n'); sb.append(ct.second) }
            } catch (e: CancelledException) { throw e } catch (e: Exception) {}
        }
        return Pair(added, sb.toString())
    }

    private const val PY_TEST_SYS = "You are the TEST AGENT. Write unit tests for the Python modules below with the standard library unittest (import unittest, class ...(unittest.TestCase), self.assertEqual and friends). " +
        "Put ONE file in tests/ named test_<module>.py (or one file test_<project>.py for several small modules). Import the code from the project root by its plain module name (from calc import add, or from app.utils import slugify); " +
        "no relative imports, no sys.path changes, no pytest, no mock of the code under test. Test only functions and classes that really exist, with their exact names, argument order and return types. " +
        "For each important function write a normal case, an edge case (empty, zero, negative, None, invalid input; use assertRaises where the code raises) and every branch you can see: 4 to 12 tests in all. " +
        "Work out every expected value by hand from the code; if you are not sure of a value, skip that test. No network, files outside a temp dir, sleeping, input(), randomness or the clock. " +
        "End the file with if __name__ == '__main__': unittest.main(). Do not change any source file. " +
        "Output only the test file as a complete FILE block in the format below. If nothing in the project can be unit tested, output exactly NO_CHANGES." + EDIT_FMT

    private const val TESTFIX_SYS = "You are a debugger. Unit tests were just RUN and the failures below appeared. The tests were written by a model that worked out every expected value by hand, so the TEST can be wrong as well as the code. " +
        "For EACH failure decide which side is wrong, using the DESIGN PLAN requirements and what the code is evidently meant to do. " +
        "If the code has a real bug: write one line CAUSE: file:line - root cause, then fix the code with the smallest correct change. " +
        "If the test expectation is wrong: write one line TEST_WRONG: test name - why, then correct that one expected value, or delete that single test when it cannot be corrected. " +
        "Never weaken a correct test, never add skip or expectedFailure, never catch AssertionError, and never make the code special-case the test input. Do not touch tests that pass. " +
        "Output ONLY what you changed, as EDIT blocks (preferred) or complete FILE blocks, in the format below. If you cannot tell which side is wrong, output exactly NO_CHANGES." + EDIT_FMT

    /**
     * Python projects: the Test Agent writes tests/test_*.py, they are RUN on the phone (Pyodide, nothing leaves the phone),
     * and one fix round decides for each failure whether the code or the test is wrong. Returns files changed and one honest line.
     */
    internal fun pythonTestPass(ctx: Context, dir: File, plan: String, deep: Boolean, thought: (String) -> Unit, note: (String) -> Unit): Pair<Int, String> {
        val now = readFiles(dir)
        val mods = PyTests.testable(now)
        if (mods.isEmpty() || PyTests.testFiles(now.keys).isNotEmpty() || PyRun.needsSyntaxOnly(dir)) return Pair(0, "")
        note("🧪 Test Agent: writing Python unit tests...")
        val raw = gen(ctx, PY_TEST_SYS + FORMAT, "DESIGN PLAN:\n" + plan + "\n\nMODULES TO TEST:\n" + dump(mods) +
            "\n\nWHOLE PROJECT (for context):\n" + dump(pickFiles(now, "tests " + mods.keys.joinToString(" "))), 32000, deep, thought)
        val o = parse(raw)
        // only test files are accepted from this agent; it can never change the source
        val onlyTests = Out(o.notes, o.files.filter { PyTests.isTest(it.first) }, emptyList(), emptyList())
        if (onlyTests.isEmpty) return Pair(0, "")
        var changed = apply(dir, onlyTests)
        if (stale()) return Pair(changed, "")
        note("🧪 Running the tests on the phone...")
        var out = PyTests.run(ctx, dir)
        var fixed = 0
        if (out.bad && !stale()) {
            note("🧪 Tests failed: checking whether the code or the test is wrong...")
            val failing = PyTests.failureText(out)
            thought("🧪 Test run\n" + failing)
            val raw2 = try {
                val all = readFiles(dir)
                gen(ctx, TESTFIX_SYS + FORMAT, "DESIGN PLAN:\n" + plan + "\n\nFAILING TESTS:\n" + failing + "\n\nPROJECT:\n" + dump(pickFiles(all, failing)), 32000, deep, thought)
            } catch (e: CancelledException) { throw e } catch (e: Exception) { "" }
            val o2 = parse(raw2)
            if (!o2.isEmpty) {
                fixed = apply(dir, o2)
                if (fixed > 0 && !stale()) { note("🧪 Running the tests again..."); out = PyTests.run(ctx, dir) }
            }
        }
        changed += fixed
        return Pair(changed, PyTests.line(out, fixed))
    }

    /**
     * Kotlin / Java / Go projects: the Test Agent writes tests/SelfTest.* (a small program that prints PASS/FAIL), it is run on the online runner
     * (only after the user agreed), and one fix round decides whether the code or the test is wrong. Returns files changed and one honest line.
     */
    internal fun compiledTestPass(ctx: Context, dir: File, plan: String, deep: Boolean, thought: (String) -> Unit, note: (String) -> Unit): Pair<Int, String> {
        val confirm = runConfirm ?: return Pair(0, "")
        if (compileDeclined || stale()) return Pair(0, "")
        val now = readFiles(dir)
        if (needsExternalLibs(now) || Runner.entry(dir) != null || PyRun.entry(dir) != null) return Pair(0, "")
        val entry = RunCode.entryOf(now.keys) ?: return Pair(0, "")
        val lang = RunCode.normLang(entry.substringAfterLast('/'))
        if (lang !in SelfTests.LANGS || SelfTests.files(now.keys).isNotEmpty()) return Pair(0, "")
        val mods = SelfTests.modules(now, entry, lang)
        if (mods.isEmpty()) return Pair(0, "")
        note("🧪 Test Agent: writing a " + lang + " self-test program...")
        val raw = gen(ctx, SelfTests.systemPrompt(lang) + FORMAT, "DESIGN PLAN:\n" + plan + "\n\nMODULES TO TEST (entry file " + entry + " is not part of the test run):\n" + dump(mods) +
            "\n\nWHOLE PROJECT (for context):\n" + dump(pickFiles(now, "tests " + mods.keys.joinToString(" "))), 32000, deep, thought)
        val o = parse(raw)
        // only the self-test file is accepted from this agent; it can never change the source
        val onlyTests = Out(o.notes, o.files.filter { SelfTests.isSelfTest(it.first) }, emptyList(), emptyList())
        if (onlyTests.isEmpty) return Pair(0, "")
        var changed = apply(dir, onlyTests)
        fun runIt(): PyTests.Outcome {
            val all = readFiles(dir)
            val tf = SelfTests.fileFor(lang, all.keys) ?: return PyTests.Outcome(false, 0, 0, 0, 0, "no self-test file")
            return SelfTests.run(ctx, confirm, all, entry, lang, tf)
        }
        if (stale()) return Pair(changed, "")
        note("🧪 Running the self-test on the online runner...")
        var out = runIt()
        if (out.text.contains("declined")) { compileDeclined = true; return Pair(changed, "🧪 Self-test written (tests/) but not run: you did not allow the online run.") }
        var fixed = 0
        if (out.bad && !stale()) {
            note("🧪 Self-test failed: checking whether the code or the test is wrong...")
            val failing = PyTests.failureText(out)
            thought("🧪 Self-test run\n" + failing)
            val raw2 = try {
                val all = readFiles(dir)
                gen(ctx, TESTFIX_SYS + FORMAT, "DESIGN PLAN:\n" + plan + "\n\nFAILING TESTS (a compile error here can be in the test file or in the code):\n" + failing + "\n\nPROJECT:\n" + dump(pickFiles(all, failing)), 32000, deep, thought)
            } catch (e: CancelledException) { throw e } catch (e: Exception) { "" }
            val o2 = parse(raw2)
            if (!o2.isEmpty) {
                fixed = apply(dir, o2)
                if (fixed > 0 && !stale()) { note("🧪 Running the self-test again..."); out = runIt() }
            }
        }
        changed += fixed
        return Pair(changed, PyTests.line(out, fixed, "self-test program, " + lang + ", online runner"))
    }

    private fun auditPass(ctx: Context, dir: File, task: String, plan: String, deep: Boolean, thought: (String) -> Unit): Int {
        val raw = gen(
            ctx, AUDIT_SYS + FORMAT,
            "ORIGINAL REQUEST:\n" + task + "\n\nDESIGN PLAN:\n" + plan + "\n\nPROJECT:\n" + dump(readFiles(dir)),
            32000, deep, thought
        )
        val o = parse(raw)
        if (o.isEmpty) return 0
        return apply(dir, o)
    }

    private fun reviewPass(ctx: Context, dir: File, plan: String, deep: Boolean, thought: (String) -> Unit): Int {
        val files = readFiles(dir)
        val basicLint = lint(files).ifBlank { "no structural lint findings" }
        val engineeringFindings = Engineering.findings(files).joinToString("\n") { f ->
            "[${f.level.name}] ${f.code} — ${f.path}:${f.line} — ${f.title}. ${f.detail} Fix: ${f.recommendation}"
        }.ifBlank { "no security heuristic findings" }
        val raw = gen(
            ctx, REVIEW_SYS + FORMAT,
            "DESIGN PLAN AND TEST SCENARIOS:\n" + plan + "\n\nAUTOMATIC STRUCTURAL LINT:\n" + basicLint +
                "\n\nAUTOMATIC ENGINEERING / SECURITY HEURISTICS (confirm each; some are intentionally conservative):\n" + engineeringFindings +
                "\n\nREVIEW THIS PROJECT:\n" + dump(files), 32000, deep, thought
        )
        val o = parse(raw)
        if (o.isEmpty) return 0
        return apply(dir, o)
    }

    /** Runs a web project in a hidden browser and lets the model fix what broke. Returns the number of files changed. */
    /** Result of the last check: how many files were fixed and one honest line for the reply. */
    internal class Verdict(val fixed: Int, val line: String)

    /** All cheap checks plus a real run (when the project can run). Empty text = nothing found. */
    private fun problems(ctx: Context, dir: File): String {
        val sb = StringBuilder()
        val files = readFiles(dir)
        val l = try { lint(files) } catch (e: Exception) { "" }
        if (l.isNotBlank()) sb.append(l.trim()).append('\n')
        val bf = try { brokenFiles(dir) } catch (e: Exception) { emptyList() }
        if (bf.isNotEmpty()) sb.append("Empty or unfinished files: ").append(bf.joinToString(", ")).append('\n')
        val eng = try { Engineering.findings(files).filter { it.level.rank >= Engineering.Level.HIGH.rank } } catch (e: Exception) { emptyList() }
        for (f in eng.take(8)) sb.append(f.path).append(':').append(f.line).append(' ').append(f.title).append(" - ").append(f.recommendation).append('\n')
        if (Runner.entry(dir) != null || PyRun.entry(dir) != null) {
            val r = try { Runner.check(ctx, dir) } catch (e: Exception) { "" }
            if (r.isNotBlank()) sb.append(r.trim())
        } else {
            val c = try { compileProblems(ctx, dir) } catch (e: CancelledException) { throw e } catch (e: Exception) { "" }
            if (c.isNotBlank()) sb.append(c.trim())
        }
        return sb.toString().trim()
    }

    /**
     * Permission to send the project to the online runner for a real compile. Set by the chat around a build or change;
     * null (website builder, background jobs) means no compile check is attempted, so nothing is ever sent without a question.
     */
    @Volatile var runConfirm: ((String) -> Boolean)? = null
    @Volatile private var compileRan = false
    @Volatile private var compileDeclined = false

    fun <T> withRunConfirm(confirm: (String) -> Boolean, block: () -> T): T {
        runConfirm = confirm; compileDeclined = false
        try { return block() } finally { runConfirm = null }
    }

    private val COMPILED = setOf("kotlin", "java", "c", "cpp", "csharp", "go", "rust", "swift")

    /** True when the project needs libraries or a build tool the online sandbox does not have (Android, Gradle, Maven, Cargo/Go modules with dependencies). */
    internal fun needsExternalLibs(files: Map<String, String>): Boolean {
        for ((k, v) in files) {
            val n = k.substringAfterLast('/')
            if (n == "AndroidManifest.xml" || n == "pom.xml" || n.startsWith("build.gradle") || n.endsWith(".csproj") || n == "Package.swift") return true
            if (n == "Cargo.toml" && Regex("(?m)^\\[(dev-|build-)?dependencies\\]\\s*\\n\\s*\\S").containsMatchIn(v)) return true
            if (n == "go.mod" && Regex("(?m)^\\s*require\\b").containsMatchIn(v)) return true
        }
        return false
    }

    private val LIB_ERR = Regex("(?i)cannot find package|no required module|unresolved reference: *(android|androidx)|package [\\w.]+ does not exist|can't find crate|unresolved import|could not find or load main class|No such file or directory|fatal error: [\\w./]+: No such|does not exist in the namespace|could not be found \\(are you missing")

    /** Turns the online runner's report into a problem text, or "" when it compiled/ran, or could not be judged (no network, missing library, time limit). */
    internal fun compileVerdict(lang: String, report: String): String {
        if (report.contains("The user declined") || report.contains("Could not reach") || report.contains("was not run") || report.contains("No server language")) return ""
        val compileFail = report.contains("Compilation Error", true) || report.contains("did not compile")
        val crashed = report.contains("crashed at runtime") || Regex("(?m)^RUN .*: (Runtime Error|Exit code)", RegexOption.IGNORE_CASE).containsMatchIn(report) || report.contains("the program ended with an error")
        if (!compileFail && !crashed) return ""
        val detail = report.substringAfter("COMPILER OUTPUT:", report.substringAfter("ERROR OUTPUT:", report)).substringBefore("\n\nResult:").trim()
        if (LIB_ERR.containsMatchIn(detail)) return ""   // needs a library or file the sandbox does not have: cannot be judged here
        if (crashed && !compileFail && Regex("(?i)\\b(EOFError|NoSuchElementException|InputMismatch|scanner|stdin|readLine)\\b").containsMatchIn(detail)) return ""   // wanted keyboard input
        return "- " + lang + (if (compileFail) " compile failed:\n" else " run crashed:\n") + detail.take(1800)
    }

    /** Real compile (and one run) of a non-web, non-Python project on the online runner, after the user agreed. "" when fine or not possible. */
    private fun compileProblems(ctx: Context, dir: File): String {
        val confirm = runConfirm ?: return ""
        if (compileDeclined || stale()) return ""
        val files = readFiles(dir)
        if (needsExternalLibs(files)) return ""
        val entry = RunCode.entryOf(files.keys) ?: return ""
        val lang = RunCode.normLang(entry.substringAfterLast('/'))
        if (lang !in COMPILED) return ""
        val src = files.filterKeys { RunCode.normLang(it.substringAfterLast('/')) == lang && !it.contains("..") && !SelfTests.inTestsDir(it) }
        if (src.isEmpty() || src.size > 80 || src.values.sumOf { it.length } > 600000) return ""
        val report = try {
            if (src.size >= 2) {
                if (RunCode.plan(lang, entry, src) == null) return ""
                RunCode.runMulti(ctx, confirm, lang, entry, src, "")
            } else RunCode.runSource(ctx, confirm, lang, src.getValue(entry), "")
        } catch (e: CancelledException) { throw e } catch (e: Exception) { return "" }
        if (report.contains("The user declined")) { compileDeclined = true; return "" }
        if (!report.startsWith("RUN ")) return ""
        compileRan = true
        return compileVerdict(lang, report)
    }

    /** The failing lines with their surroundings, when the error text points to files of this project. */
    internal fun whereItHappens(files: Map<String, String>, errs: String): String {
        val t = try { Debug.diagnose(files, errs, 6, 5) } catch (e: Exception) { return "" }
        if (t.startsWith("Give output=") || t.contains("No file:line in this output")) return ""
        return t.substringBefore("\n\nFix the source").trim()
    }

    private val CAUSE_RE = Regex("(?m)^\\s*CAUSE:\\s*(.+)$")

    /**
     * Check, fix (up to 3 rounds), then check AGAIN and say plainly what is left.
     * The words only claim what was really checked: static checks and a run, never a full compile.
     */
    internal fun verifyAndFix(ctx: Context, dir: File, deep: Boolean, thought: (String) -> Unit, note: (String) -> Unit): Verdict {
        if (stale()) return Verdict(0, "")
        note("🧪 Tester Agent: checking the result...")
        compileRan = false
        var fixed = 0
        var rounds = 0
        var errs = problems(ctx, dir)
        val causes = ArrayList<String>()
        while (errs.isNotBlank() && rounds < 3 && !stale()) {
            rounds++
            note("🧪 Tester Agent: found problems, fixing (round " + rounds + " of 3)...")
            thought("🧪 Check (round " + rounds + ")\n" + errs)
            val raw = try {
                val all = readFiles(dir)
                val where = whereItHappens(all, errs)
                gen(ctx, VERIFY_SYS + FORMAT,
                    "PROBLEMS FOUND BY THE CHECKS:\n" + errs +
                        (if (where.isNotBlank()) "\n\nWHERE IT HAPPENS (>> marks the failing line):\n" + where else "") +
                        "\n\nPROJECT:\n" + dump(pickFiles(all, errs)), 32000, deep, thought)
            } catch (e: CancelledException) { throw e } catch (e: Exception) { break }
            val o = parse(raw)
            for (m in CAUSE_RE.findAll(o.notes)) { val c = m.groupValues[1].trim().take(160); if (c.isNotBlank() && c !in causes && causes.size < 3) causes.add(c) }
            if (o.isEmpty) break
            val n = apply(dir, o)
            if (n == 0) break
            fixed += n
            errs = problems(ctx, dir)
        }
        val ran = Runner.entry(dir) != null || PyRun.entry(dir) != null
        val what = if (ran) "code checks and a test run" else if (compileRan) "code checks and a real compile + run of the source files on the online runner" else "code checks"
        val tail = if (compileRan) "Standard library only: this is not a full Gradle/Maven/Cargo build." else "This is not a full compile."
        val line = if (errs.isBlank()) {
            (if (fixed > 0) "✅ Checked again after fixing " + fixed + " file(s): no problems found (" + what + "). " + tail
             else "✅ Checked: no problems found (" + what + "). " + tail)
        } else {
            "⚠ Still open after " + rounds + " fix round(s): " + errs.lines().filter { it.isNotBlank() }.take(3).joinToString("; ") { it.take(120) }
        }
        val why = if (causes.isEmpty()) "" else "🔎 Cause: " + causes.joinToString(" | ") + "\n"
        return Verdict(fixed, why + line)
    }

    private fun runAndFix(ctx: Context, dir: File, deep: Boolean, thought: (String) -> Unit, note: (String) -> Unit): Int {
        if ((Runner.entry(dir) == null && PyRun.entry(dir) == null) || stale()) return 0
        var fixed = 0
        for (round in 1..2) {
            note("🧪 Tester Agent: running it to look for errors...")
            val errs = try { Runner.check(ctx, dir) } catch (e: Exception) { "" }
            if (errs.isBlank()) break
            thought("🧪 Run check (round " + round + ")\n" + errs)
            note("🧪 Tester Agent: found errors while running, fixing (round " + round + ")...")
            val raw = gen(ctx, FIX_SYS + FORMAT, "PROBLEMS SEEN WHEN RUNNING:\n" + errs + "\n\nPROJECT:\n" + dump(readFiles(dir)), 32000, deep, thought)
            val o = parse(raw)
            if (o.isEmpty) break
            fixed += apply(dir, o)
        }
        return fixed
    }

    /** Signs that the model stopped writing before the job was done. */
    private val PLACEHOLDER_RE = Regex(
        "(//|#|/\\*|<!--)\\s*(TODO|FIXME|TBD)\\b|\\bTODO\\(|rest of (the )?(code|file|implementation)|your code here|implement (me|this) (here|later)|" +
            "NotImplementedError|NotImplementedException|(?i:lorem ipsum)"
    )

    private val ID_RE = Regex("\\bid\\s*=\\s*[\"']([^\"']+)[\"']")
    private val GET_ID_RE = Regex("getElementById\\(\\s*[\"']([^\"']+)[\"']\\s*\\)")
    private val QS_ID_RE = Regex("querySelector(?:All)?\\(\\s*[\"']#([A-Za-z_][\\w-]*)[\"']\\s*\\)")
    private val INLINE_JS_RE = Regex("<script(?![^>]*\\bsrc\\s*=)[^>]*>([\\s\\S]*?)</script>", RegexOption.IGNORE_CASE)
    private val BRACKET_EXT = setOf(
        "js", "mjs", "jsx", "ts", "tsx", "java", "kt", "kts", "c", "cpp", "h", "cs", "go", "rs", "php", "dart", "swift", "css", "scss", "py"
    )

    /**
     * Finds an unmatched or mismatched ( [ { while skipping strings and comments.
     * Returns a short description of the first problem, or null when the brackets are balanced.
     * It is a hint for the reviewer (regex literals can fool it), not a verdict.
     */
    private fun bracketCheck(src: String, py: Boolean, css: Boolean): String? {
        val st = ArrayList<Pair<Char, Int>>()
        val n = src.length
        var i = 0
        var line = 1
        while (i < n) {
            val c = src[i]
            if (c == '\n') { line++; i++; continue }
            if (py && c == '#') { while (i < n && src[i] != '\n') i++; continue }
            if (!py && !css && c == '/' && i + 1 < n && src[i + 1] == '/') { while (i < n && src[i] != '\n') i++; continue }
            if (!py && c == '/' && i + 1 < n && src[i + 1] == '*') {
                val e = src.indexOf("*/", i + 2)
                val stop = if (e < 0) n else e + 2
                for (k in i until stop) if (src[k] == '\n') line++
                i = stop
                continue
            }
            if (c == '"' || c == '\'' || (c == '`' && !py)) {
                if (c != '`' && i + 2 < n && src[i + 1] == c && src[i + 2] == c) {
                    val e = src.indexOf("" + c + c + c, i + 3)
                    val stop = if (e < 0) n else e + 3
                    for (k in i until stop) if (src[k] == '\n') line++
                    i = stop
                    continue
                }
                var e = i + 1
                while (e < n) {
                    val d = src[e]
                    if (d == '\\') { e += 2; continue }
                    if (d == c) { e++; break }
                    if (d == '\n') { if (c != '`') break else line++ }
                    e++
                }
                i = minOf(e, n)
                continue
            }
            when (c) {
                '(', '[', '{' -> st.add(Pair(c, line))
                ')', ']', '}' -> {
                    if (st.isEmpty()) return "unexpected '" + c + "' at line " + line
                    val top = st.removeAt(st.size - 1)
                    val want = when (top.first) { '(' -> ')'; '[' -> ']'; else -> '}' }
                    if (c != want) return "'" + c + "' at line " + line + " does not match '" + top.first + "' opened at line " + top.second
                }
            }
            i++
        }
        if (st.isNotEmpty()) {
            val top = st[st.size - 1]
            return "'" + top.first + "' opened at line " + top.second + " is never closed"
        }
        return null
    }

    private fun idRefs(js: String, where: String, ids: Set<String>, out: StringBuilder) {
        val missing = LinkedHashSet<String>()
        for (m in GET_ID_RE.findAll(js)) if (m.groupValues[1] !in ids) missing.add(m.groupValues[1])
        for (m in QS_ID_RE.findAll(js)) if (m.groupValues[1] !in ids) missing.add(m.groupValues[1])
        for (id in missing.take(8))
            out.append("- ").append(where).append(" looks up #").append(id).append(" but no HTML element has that id (ignore if it is created dynamically)\n")
    }

    /** Cheap automatic checks (missing files, broken JSON, unbalanced brackets, ids that do not exist) handed to the reviewer as facts. */
    internal fun lint(files: Map<String, String>): String {
        val out = StringBuilder()
        val htmlIds = HashSet<String>()
        var hasHtml = false
        for ((p, c) in files) {
            if (!p.lowercase().endsWith(".html")) continue
            hasHtml = true
            val seen = HashSet<String>()
            for (m in ID_RE.findAll(c)) {
                val id = m.groupValues[1]
                htmlIds.add(id)
                if (!seen.add(id)) out.append("- ").append(p).append(": id \"").append(id).append("\" is used more than once\n")
            }
        }
        for ((p, c) in files) {
            val low = p.lowercase()
            val ext = low.substringAfterLast('.', "")
            if (ext == "html") {
                val base = p.substringBeforeLast('/', "")
                for (m in Regex("(?:src|href)\\s*=\\s*[\"']([^\"'#?]+)[\"']").findAll(c)) {
                    val ref = m.groupValues[1]
                    if (ref.startsWith("http") || ref.startsWith("//") || ref.startsWith("data:") ||
                        ref.startsWith("mailto:") || ref.startsWith("tel:") || ref.startsWith("javascript:")) continue
                    val path = if (base.isEmpty() || ref.startsWith("/")) ref.trimStart('/') else base + "/" + ref
                    if (!files.containsKey(path)) out.append("- ").append(p).append(" refers to a file that does not exist: ").append(ref).append("\n")
                }
                val opens = Regex("<script", RegexOption.IGNORE_CASE).findAll(c).count()
                val closes = Regex("</script>", RegexOption.IGNORE_CASE).findAll(c).count()
                if (opens > closes) out.append("- ").append(p).append(": a <script> tag is not closed\n")
                for (m in INLINE_JS_RE.findAll(c)) {
                    val js = m.groupValues[1]
                    val bc = bracketCheck(js, false, false)
                    if (bc != null) out.append("- ").append(p).append(" (inline script): ").append(bc).append("\n")
                    idRefs(js, p + " (inline script)", htmlIds, out)
                }
            }
            if (ext in BRACKET_EXT || ext == "html") {
                val ph = PLACEHOLDER_RE.find(c)
                if (ph != null) out.append("- ").append(p).append(": unfinished code (placeholder or stub: \"").append(ph.value.trim().take(40)).append("\")\n")
            }
            if (ext == "html" && c.contains("<html", true) && !c.contains("</html>", true))
                out.append("- ").append(p).append(" looks cut off: there is no closing </html>\n")
            if (ext == "json") {
                try { JSONObject(c) } catch (e: Exception) {
                    try { JSONArray(c) } catch (e2: Exception) { out.append("- ").append(p).append(" is not valid JSON\n") }
                }
            }
            if (ext in BRACKET_EXT) {
                val bc = bracketCheck(c, ext == "py", ext == "css" || ext == "scss")
                if (bc != null) out.append("- ").append(p).append(": ").append(bc).append("\n")
            }
            if (hasHtml && (ext == "js" || ext == "mjs" || ext == "jsx")) idRefs(c, p, htmlIds, out)
            if (ext == "py" && Regex("(?m)^\\t").containsMatchIn(c) && Regex("(?m)^ +\\S").containsMatchIn(c))
                out.append("- ").append(p).append(" mixes tab and space indentation\n")
        }
        if (files.size >= 3 && files.keys.none { it.substringAfterLast('/').lowercase().startsWith("readme") })
            out.append("- the project has no README.md (what it does, how to run it, how to test it)\n")
        return out.toString()
    }

    /** Changes an existing project according to the instruction. Returns a short note. */
    /** When set (by the Website Builder), a change request that names pages is shown only those pages plus shared css/js. */
    @Volatile var focusChange = false

    /** Files worth showing for a small change: pages named in the request, plus the shared stylesheet/script/data files. */
    internal fun relevantFiles(files: Map<String, String>, instruction: String): Map<String, String> {
        val ins = instruction.lowercase()
        val named = files.keys.filter { k ->
            val low = k.lowercase()
            low.endsWith(".html") && (ins.contains(low.substringAfterLast('/')) || ins.contains(low.substringAfterLast('/').removeSuffix(".html")) && low.substringAfterLast('/').removeSuffix(".html").length >= 3)
        }
        if (named.isEmpty()) return files
        val shared = files.keys.filter { k -> !k.lowercase().endsWith(".html") && !k.lowercase().endsWith(".md") }
        val keep = (named + shared).toSet()
        return files.filterKeys { it in keep }
    }

    private val GLOBAL_RE = Regex("(?i)\\b(whole|entire|all files|every file|everywhere|across the (whole )?project|poora|pura|saari|sari|har file|rename)\\b")

    /**
     * Big project: show only the files this request is about, not whatever fits first.
     * Order of importance: files named in the request, files whose content matches the request words (CodeNav.locate),
     * then files that use names defined in the best matches. Small projects and "whole project" requests get everything.
     */
    internal fun pickFiles(files: Map<String, String>, instruction: String, budget: Int = 60000): Map<String, String> {
        if (files.size <= 3 || files.values.sumOf { it.length } <= budget || GLOBAL_RE.containsMatchIn(instruction)) return files
        val score = HashMap<String, Double>()
        val ins = instruction.lowercase()
        for (k in files.keys) {
            val low = k.lowercase()
            val base = low.substringAfterLast('/')
            if (ins.contains(low) || (base.length >= 4 && ins.contains(base))) score[k] = (score[k] ?: 0.0) + 1000.0
        }
        try { for (h in CodeNav.locate(files, instruction, 14)) score[h.path] = (score[h.path] ?: 0.0) + h.score } catch (e: Exception) {}
        val best = score.entries.sortedByDescending { it.value }.take(3).map { it.key }
        val names = HashSet<String>()
        for (b in best) try { for (d in CodeNav.definitions(b, files[b] ?: "")) if (d.name.length >= 4) names.add(d.name) } catch (e: Exception) {}
        if (names.isNotEmpty()) for ((k, t) in files) {
            if (k in best) continue
            var uses = 0
            for (n in names) if (t.contains(n)) { uses++; if (uses >= 3) break }
            if (uses > 0) score[k] = (score[k] ?: 0.0) + uses * 0.5
        }
        if (score.isEmpty()) return files
        val chosen = LinkedHashSet<String>()
        var used = 0
        for (e in score.entries.sortedByDescending { it.value }) {
            val len = files[e.key]?.length ?: continue
            if (chosen.isNotEmpty() && used + len > budget) continue
            chosen.add(e.key); used += len
            if (chosen.size >= 12) break
        }
        return files.filterKeys { it in chosen }
    }

    /** One line per file that is NOT shown: its path and the main names defined in it. */
    internal fun omittedOutline(all: Map<String, String>, shown: Map<String, String>): String {
        val sb = StringBuilder()
        var n = 0
        for ((k, t) in all) {
            if (k in shown) continue
            if (++n > 60) { sb.append("... and more files\n"); break }
            val defs = try { CodeNav.definitions(k, t).map { it.name }.distinct().take(6) } catch (e: Exception) { emptyList() }
            sb.append(k).append(" (").append(t.length).append(" chars)")
            if (defs.isNotEmpty()) sb.append(" - ").append(defs.joinToString(", "))
            sb.append('\n')
        }
        return sb.toString()
    }

    private val NEED_RE = Regex("(?m)^\\s*NEED_FILES:\\s*(.+)$")

    fun revise(
        ctx: Context, dir: File, instruction: String,
        deep: Boolean = false, thought: (String) -> Unit = {}, note: (String) -> Unit
    ): String {
        enter()
        note("Reading the project...")
        val hist = history(dir).takeLast(6).joinToString("\n") { (if (it.first == "u") "USER: " else "ASSISTANT: ") + it.second.take(500) }
        note(if (deep) "Thinking through the change..." else "Updating the code...")
        val allFiles = readFiles(dir)
        var shown = if (focusChange) relevantFiles(allFiles, instruction) else pickFiles(allFiles, instruction)
        if (shown.size < allFiles.size && !focusChange) note("Reading the " + shown.size + " file(s) that matter (of " + allFiles.size + ")...")
        fun askModel(show: Map<String, String>, allowNeed: Boolean): String {
            val outline = if (allowNeed && !focusChange) omittedOutline(allFiles, show) else ""
            return gen(
                ctx, SYSTEM + REVISE_RULES + FORMAT,
                "PROJECT FILE INVENTORY (includes binary assets; preserve assets unless explicitly asked to remove them):\n" + fileInventory(dir) +
                    "\nCURRENT TEXT/CODE FILES:\n" + dump(show) +
                    (if (outline.isNotBlank()) "\nOTHER FILES (not shown, to save space; path and main names):\n" + outline +
                        "If you must read or change one of them, reply with ONLY one line: NEED_FILES: path1, path2 (max 4). Otherwise do not mention this.\n" else "") +
                    "\nRECENT CHAT:\n" + hist + "\n\nUSER REQUEST: " + instruction, 32000, deep, thought
            )
        }
        var raw = askModel(shown, true)
        val need = NEED_RE.find(raw)
        if (need != null && parse(raw).isEmpty && shown.size < allFiles.size) {
            val want = need.groupValues[1].split(',', ';').map { it.trim().trim('`', '"', '\'') }.filter { it in allFiles }.take(4)
            if (want.isNotEmpty()) {
                note("Reading " + want.joinToString(", ") + " too...")
                shown = shown + allFiles.filterKeys { it in want }
                raw = askModel(shown, false)
            }
        }
        val o = parse(raw)
        addHistory(dir, "u", instruction)
        if (o.isEmpty) {
            val msg = o.notes.ifBlank { "Nothing changed. Please write the request a bit more clearly." }
            addHistory(dir, "a", msg)
            return msg
        }
        val failed = ArrayList<String>()
        val changedFiles = apply(dir, o, failed)
        if (failed.isNotEmpty()) {
            note("A few edits did not match, redoing those files in full...")
            try {
                val raw2 = gen(
                    ctx, SYSTEM + REVISE_FULL + FORMAT,
                    "CURRENT PROJECT:\n" + dump(readFiles(dir)) + "\n\nUSER REQUEST: " + instruction +
                        "\n\nEdits for these files could not be applied: " + failed.distinct().joinToString(", ") +
                        ". Finish the unfinished part of the request for them and output each of those files in FULL as === FILE: blocks.",
                    32000, deep, thought
                )
                apply(dir, parse(raw2))
            } catch (e: Exception) {}
        }
        var msg = o.notes.ifBlank { "Updated: " + changedFiles + " file(s)." }
        if (deep && !stale()) {
            try {
                note("Re-checking the change...")
                val n = reviewPass(ctx, dir, "Check that the user's request is fully satisfied: " + instruction, deep, thought)
                if (n > 0) msg += "\n(Review: " + n + " file fix(es) applied.)"
            } catch (e: Exception) {}
        }
        try {
            val v = verifyAndFix(ctx, dir, deep, thought, note)
            if (v.fixed > 0) msg += "\n(Check: " + v.fixed + " file fix(es) applied.)"
            if (v.line.isNotBlank()) msg += "\n" + v.line
        } catch (e: CancelledException) { throw e } catch (e: Exception) {}
        addHistory(dir, "a", msg)
        return msg
    }

    /** Answers a coding question; the project (if any) is given as context. */
    fun ask(ctx: Context, dir: File?, question: String, deep: Boolean = false, thought: (String) -> Unit = {}): String {
        enter()
        val sb = StringBuilder()
        if (dir != null) {
            sb.append("PROJECT FILE INVENTORY (binary assets are preserved; do not claim to read their contents):\n")
                .append(fileInventory(dir)).append("\nPROJECT TEXT/CODE FILES:\n").append(dump(readFiles(dir), 90000)).append("\n")
            val hist = history(dir).takeLast(6).joinToString("\n") { (if (it.first == "u") "USER: " else "ASSISTANT: ") + it.second.take(500) }
            if (hist.isNotBlank()) sb.append("RECENT CHAT:\n").append(hist).append("\n\n")
        }
        sb.append("QUESTION: ").append(question)
        val ans = gen(ctx, ASK_SYS, sb.toString(), 8000, deep, thought)
        if (dir != null) { addHistory(dir, "u", question); addHistory(dir, "a", ans) }
        return ans.ifBlank { "No answer received, please ask again." }
    }

    // ---------- entry points for the voice assistant ----------

    // ---------- resume of an interrupted build ----------

    private fun setState(dir: File, state: String) {
        try { val m = meta(dir); m.put("state", state); saveMeta(dir, m) } catch (e: Exception) {}
    }

    /** Planned files that are missing, plus files that exist but are empty or cut off. */
    private fun stillMissing(dir: File, plan: String): List<String> =
        (planFiles(plan).filter { p -> p != "package-lock.json" && File(dir, p).let { !it.isFile || it.length() < 20L } } + brokenFiles(dir)).distinct()

    /** The newest project whose build was interrupted (network lost, app closed, Stop) and still lacks files; null otherwise. */
    fun unfinished(ctx: Context): File? {
        val d = latest(ctx) ?: return null
        val m = meta(d)
        if (m.optString("state") != "building" || m.optString("plan").isBlank()) return null
        if (stillMissing(d, m.optString("plan")).isEmpty()) { setState(d, "done"); return null }
        return d
    }

    private val CONTINUE_RE = Regex("(?i)^\\s*(please\\s+)?(continue|resume|carry on|go on|finish( it)?|complete( it)?|aage|agay|jari rakho|jaari rakho|dobara|phir se|pura karo|poora karo|mukammal karo)\\b")

    /** True when the message only asks to carry on with the unfinished work. */
    internal fun isContinue(text: String): Boolean = text.length <= 60 && CONTINUE_RE.containsMatchIn(text)

    /**
     * Finishes an interrupted build from the saved plan: files that are already complete stay untouched, only the missing or
     * cut-off files are written, then the same check-and-fix and quality steps run.
     */
    fun resumeBuild(ctx: Context, dir: File, deep: Boolean = false, thought: (String) -> Unit = {}, note: (String) -> Unit): String {
        enter()
        val m = meta(dir)
        val plan = m.optString("plan"); val task = m.optString("task"); val lang = m.optString("language", "auto")
        if (plan.isBlank()) return "There is nothing saved to resume for '" + name(dir) + "'."
        val missing = stillMissing(dir, plan)
        note("Resuming '" + name(dir) + "': " + (planFiles(plan).size - missing.size).coerceAtLeast(0) + " file(s) are already done and stay as they are...")
        if (missing.isNotEmpty()) {
            note("🧩 Completer Agent: writing " + missing.size + " remaining file(s)...")
            writeInBatches(ctx, dir, task, lang, plan, missing, deep, thought, note)
        }
        try { finishMissing(ctx, dir, plan, task, deep, thought, note) } catch (e: CancelledException) { throw e } catch (e: Exception) {}
        val left = stillMissing(dir, plan)
        var notes = "Build resumed: " + readFiles(dir).size + " file(s) now."
        if (left.isEmpty() && !stale()) {
            try { val v = verifyAndFix(ctx, dir, deep, thought, note); if (v.line.isNotBlank()) notes += "\n" + v.line } catch (e: CancelledException) { throw e } catch (e: Exception) {}
            try { val q = qualityPass(ctx, dir, plan, deep, thought, note); if (q.second.isNotBlank()) notes += "\n" + q.second } catch (e: CancelledException) { throw e } catch (e: Exception) {}
            setState(dir, "done")
        } else if (left.isNotEmpty()) {
            notes += "\nStill missing: " + left.take(8).joinToString(", ") + ". Say 'continue' again."
        }
        addHistory(dir, "a", notes)
        return notes
    }

    fun buildAndOpen(ctx: Context, task: String, language: String, review: Boolean): String {
        if (isContinue(task)) unfinished(ctx)?.let { return resumeAndOpen(ctx, it) }
        return try {
            // Product builds always receive an implementation audit; otherwise notes can claim features
            // that were never wired into the runnable preview. The caller flag remains accepted for API compatibility.
            val (dir, notes) = build(ctx, task, language, true, deepDefault(ctx)) {}
            if (ctx !is MainActivity) show(ctx, dir)
            "Project '" + name(dir) + "' created (" + readFiles(dir).size + " files). " +
                (if (ctx is MainActivity) "The chat will show the project card, inline preview and ZIP download. " else "Opened on screen. ") + notes.take(300)
        } catch (e: Exception) {
            val u = try { unfinished(ctx) } catch (x: Exception) { null }
            "Could not create the code: " + (e.message ?: e.javaClass.simpleName) +
                (if (u != null) ". The project '" + name(u) + "' was started and its progress is saved (" + readFiles(u).size + " file(s) so far). Tell the user to say 'continue': it finishes from the same point." else "")
        }
    }

    private fun resumeAndOpen(ctx: Context, dir: File): String = try {
        val notes = resumeBuild(ctx, dir, deepDefault(ctx)) {}
        if (ctx !is MainActivity) show(ctx, dir)
        "Project '" + name(dir) + "' resumed (" + readFiles(dir).size + " files). " +
            (if (ctx is MainActivity) "The chat will show the project card, inline preview and ZIP download. " else "Opened on screen. ") + notes.take(300)
    } catch (e: Exception) {
        "Could not resume: " + (e.message ?: e.javaClass.simpleName) + ". The saved progress is kept; say 'continue' again."
    }

    fun editLatest(ctx: Context, instruction: String): String {
        val dir = latest(ctx) ?: return "There is no project yet. Create one with write_code first."
        if (isContinue(instruction)) unfinished(ctx)?.let { return resumeAndOpen(ctx, it) }
        return try {
            val msg = revise(ctx, dir, instruction, deepDefault(ctx)) {}
            if (ctx !is MainActivity) show(ctx, dir)
            "Project '" + name(dir) + "' was updated. " +
                (if (ctx is MainActivity) "The chat will show the updated project card. " else "Opened on screen. ") + msg.take(300)
        } catch (e: Exception) {
            "Could not apply the change: " + (e.message ?: e.javaClass.simpleName)
        }
    }
}
