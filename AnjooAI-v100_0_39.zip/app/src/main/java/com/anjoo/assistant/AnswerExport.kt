package com.anjoo.assistant

import java.util.Locale

/** Helpers for the "Download as PDF / Word / Excel" card under an answer. Pure text logic, no Android needed. */
object AnswerExport {
    private val SEP = Regex("^\\s*\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?\\s*$")

    private fun isRow(l: String) = l.count { it == '|' } >= 2

    private fun cells(l: String): List<String> =
        l.trim().removePrefix("|").removeSuffix("|").split("|").map { it.trim().replace("**", "").replace("`", "") }

    /** Every Markdown table in the answer, each as a list of rows (header first). */
    fun tables(md: String): List<List<List<String>>> {
        val out = ArrayList<List<List<String>>>()
        var cur = ArrayList<List<String>>()
        fun flush() { if (cur.size >= 2) out.add(cur); cur = ArrayList() }
        for (line in md.replace("\r", "").lines()) {
            if (isRow(line)) { if (!SEP.matches(line)) cur.add(cells(line)) } else flush()
        }
        flush()
        return out
    }

    fun hasTable(md: String) = tables(md).isNotEmpty()

    private fun csv(rows: List<List<String>>) = rows.joinToString("\n") { r -> r.joinToString(",") { "\"" + it.replace("\"", "\"\"") + "\"" } }

    /** Text for the Excel writer: one sheet per table, or a single "Answer" sheet with one line per row. */
    fun sheets(md: String): String {
        val ts = tables(md)
        if (ts.isEmpty()) {
            val lines = md.replace("\r", "").lines().map { it.trim() }.filter { it.isNotEmpty() }.map { it.removePrefix("#").trim().replace("**", "") }
            return csv(listOf(listOf("Answer")) + lines.map { listOf(it) })
        }
        return ts.withIndex().joinToString("\n") { (i, t) -> "== Sheet: Table ${i + 1} ==\n" + csv(t) }
    }

    /** Worth offering a file when the answer is long, structured or has a table. */
    fun worthIt(md: String): Boolean {
        val t = md.trim()
        if (t.isEmpty()) return false
        if (hasTable(t)) return true
        val headings = t.lines().count { it.trimStart().startsWith("#") }
        return t.length >= 700 || (headings >= 2 && t.length >= 300)
    }

    /** A title from the first heading or first line. */
    fun title(md: String): String {
        val first = md.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() && !it.startsWith("```") && !it.startsWith("|") } ?: "Anjoo answer"
        return first.trimStart('#', ' ', '*').replace("**", "").take(60).ifBlank { "Anjoo answer" }
    }

    fun fileName(title: String, fmt: String): String {
        val base = title.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "_").trim('_').take(40).ifEmpty { "anjoo_answer" }
        return base + "." + fmt.lowercase(Locale.ROOT).removePrefix(".")
    }
}
