package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Reminders, briefing, prayer times, money diary, currency, news, translator mode, message replies. */
object MoreTools {

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 20000
        c.setRequestProperty("User-Agent", "Mozilla/5.0 AnjooAI")
        return c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    fun run(ctx: Context, confirm: (String) -> Boolean, name: String, a: JSONObject, progress: (String, String) -> Unit = { _, _ -> }): String? = when (name) {
        "set_reminder" -> setReminder(ctx, a)
        "list_reminders" -> listReminders(ctx)
        "cancel_reminder" -> cancelReminder(ctx, a.getString("text"))
        "set_daily_briefing" -> setBriefing(ctx, a)
        "convert_currency" -> currency(a.getDouble("amount"), a.getString("from"), a.getString("to"))
        "news" -> news(a.optString("topic", ""))
        "prayer_times" -> prayerTimes(a.getString("city"), a.optString("country", ""))
        "set_prayer_reminders" -> setPrayer(ctx, a)
        "ledger_add" -> ledgerAdd(ctx, a)
        "ledger_summary" -> ledgerSummary(ctx, a.optString("period", "month"), a.optString("person", ""))
        "set_translator" -> setTranslator(ctx, a)
        "read_notifications" -> NotifState.recent(a.optInt("count", 5))
        "reply_message" -> replyMessage(confirm, a.getString("text"))
        "set_auto_reply" -> setAutoReply(ctx, a)
        "create_page" -> if (Artifacts.isBillRequest(a.optString("description"))) Artifacts.billInstead(ctx, a.optString("description")) else Studio.page(ctx, a.getString("description"))
        "write_code" -> if (Artifacts.isBillRequest(a.optString("task"))) Artifacts.billInstead(ctx, a.optString("task")) else Studio.code(ctx, a.getString("task"), a.optString("language", "auto"))
        "edit_code" -> Coder.editLatest(ctx, a.getString("instruction"))
        "generate_image" -> ImageGen.tool(ctx, a)
        "browser_open" -> Browser.open(ctx, a.getString("url"))
        "browser_read" -> Browser.read(ctx)
        "browser_click" -> Browser.click(ctx, a.getString("target"))
        "browser_type" -> Browser.type(ctx, a.getString("target"), a.getString("text"), a.optBoolean("submit", false))
        "browser_scroll" -> Browser.scroll(ctx, a.optString("direction", "down"))
        "browser_back" -> Browser.back(ctx)
        "browser_close" -> Browser.close(ctx)
        "add_note" -> { val n = Notes.add(ctx, a.optString("title", ""), a.getString("text")); "Note saved (on the phone, safe offline too): " + n.title }
        "list_notes" -> Notes.summary(ctx, a.optString("query", ""))
        "read_note" -> Notes.byNumber(ctx, a.getInt("number"))?.let { (if (it.title.isNotEmpty()) it.title + "\n\n" else "") + it.body } ?: "No note with this number. Check with list_notes."
        "delete_note" -> Notes.byNumber(ctx, a.getInt("number"))?.let {
            if (!confirm(Confirm.msg("delete", "Delete note " + a.getInt("number") + (if (it.title.isNotEmpty()) " (" + it.title.take(40) + ")" else "") + "?", "This cannot be undone."))) "The user declined."
            else { Notes.delete(ctx, it.id); "Note " + a.getInt("number") + " deleted." }
        } ?: "No note with this number."
        "add_task" -> Tasks.toolAdd(ctx, a)
        "move_task" -> Tasks.toolMove(ctx, a)
        "list_tasks" -> Tasks.summary(ctx, a.optString("status", ""))
        "delete_task" -> if (!confirm(Confirm.msg("delete", "Delete task \"" + a.getString("task").take(60) + "\"?", "This cannot be undone."))) "The user declined." else Tasks.toolDelete(ctx, a.getString("task"))
        "schedule_agent" -> AgentJobs.schedule(ctx, a)
        "delegate_task" -> AgentJobs.delegate(ctx, a.optString("role", "researcher"), a.getString("task"))
        "delegate_team" -> AgentJobs.team(ctx, a, progress)
        "agent_execute" -> AgentOrchestrator.execute(ctx, a.getString("goal"), progress = progress)
        "retry_task" -> AgentJobs.retry(ctx, a, progress)
        "make_prompt" -> PromptMaker.make(ctx, a.getString("idea"), a.optString("target", ""))
        "run_python" -> PyRun.runCode(ctx, a.getString("code"))
        "run_code" -> RunCode.run(ctx, confirm, a)
        "run_shell" -> Shell.run(ctx, a, confirm)
        "project_tree", "project_read", "project_write", "project_edit", "project_search", "project_replace", "project_manage", "project_check", "project_history", "project_template", "project_studio", "project_engineering", "project_git", "project_deps", "project_code", "project_debug", "project_deploy" ->
            if (name == "project_studio" && a.optString("action") == "build" && Artifacts.isBillRequest(a.optString("message") + " " + a.optString("task") + " " + a.optString("requirements"))) Artifacts.billInstead(ctx, a.optString("message").ifEmpty { a.optString("task") })
            else CodeTools.run(ctx, confirm, name, a)
        "website_builder" -> WebsiteBuilder.run(ctx, confirm, a)
        "search_web" -> Web.search(ctx, a)
        "create_artifact", "update_artifact", "read_artifact", "list_artifacts", "open_artifact", "export_artifact", "share_artifact", "stop_sharing", "delete_artifact" -> Artifacts.tool(ctx, confirm, name, a)
        "fetch_page" -> Web.fetch(ctx, a)
        "save_routine" -> saveRoutine(ctx, a.getString("name"), a.getString("steps"))
        "delete_routine" -> if (!confirm(Confirm.msg("delete", "Delete routine \"" + a.getString("name").take(60) + "\"?", "This cannot be undone."))) "The user declined." else deleteRoutine(ctx, a.getString("name"))
        "search_chats" -> ChatStore.search(ctx, a.getString("query"))
        "pick_folder", "storage_setup", "save_file", "edit_file", "list_files", "find_files", "grep_files", "read_file", "delete_file", "save_image", "export_project", "backup_to_folder" -> FileAccess.tool(ctx, confirm, name, a)
        else -> null
    }

    private fun routines(ctx: Context): JSONObject =
        try { JSONObject(prefs(ctx).getString("routines", "{}")) } catch (e: Exception) { JSONObject() }

    private fun saveRoutine(ctx: Context, name: String, steps: String): String {
        val r = routines(ctx)
        r.put(name.trim(), steps.trim())
        prefs(ctx).edit().putString("routines", r.toString()).apply()
        return "Learned: when you say '" + name + "' I will do this: " + steps
    }

    private fun deleteRoutine(ctx: Context, name: String): String {
        val r = routines(ctx)
        val k = r.keys().asSequence().firstOrNull { it.equals(name.trim(), true) } ?: return "No routine with this name."
        r.remove(k)
        prefs(ctx).edit().putString("routines", r.toString()).apply()
        return "Routine '$k' deleted."
    }

    // ---------- reminders ----------

    private fun setReminder(ctx: Context, a: JSONObject): String {
        val text = a.getString("text")
        val now = System.currentTimeMillis()
        val at: Long = when {
            a.optInt("minutes", 0) > 0 -> now + a.getInt("minutes") * 60_000L
            a.optString("datetime", "").isNotBlank() -> try {
                SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ENGLISH).parse(a.getString("datetime"))!!.time
            } catch (e: Exception) {
                return "Could not understand the time. Give it in this format: 2026-10-16 18:30"
            }
            else -> return "After how long or at what time should I remind you?"
        }
        if (at < now) return "This time has already passed."
        Reminders.add(ctx, at, text, "reminder")
        return "Okay, " + SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH).format(Date(at)) + " I will remind you: " + text
    }

    private fun listReminders(ctx: Context): String {
        val a = Reminders.list(ctx)
        if (a.length() == 0) return "No reminders are set."
        val f = SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH)
        val sb = StringBuilder()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val k = o.optString("kind")
            if (k == "prayer_refresh") continue
            sb.append(f.format(Date(o.getLong("at")))).append(" - ")
                .append(if (k == "brief") "morning briefing" else if (k.startsWith("agent")) "🤖 " + o.optString("text").split("|", limit = 3).last() else o.optString("text")).append("\n")
        }
        return sb.toString().ifBlank { "No reminders are set." }
    }

    private fun cancelReminder(ctx: Context, word: String): String {
        val w = word.lowercase(Locale.ROOT)
        val n = Reminders.removeWhere(ctx) {
            val k = it.optString("kind")
            k != "prayer_refresh" && k != "prayer" && it.optString("text").lowercase(Locale.ROOT).contains(w)
        }
        return if (n > 0) "Deleted $n reminder(s)." else "No reminder with this name found."
    }

    private fun setBriefing(ctx: Context, a: JSONObject): String {
        Reminders.removeKind(ctx, "brief")
        if (!a.optBoolean("on", true)) {
            prefs(ctx).edit().remove("briefTime").apply()
            return "Turned off the morning briefing."
        }
        val h = a.getInt("hour")
        val m = a.optInt("minute", 0)
        prefs(ctx).edit().putString("briefTime", "%02d:%02d".format(h, m)).apply()
        Reminders.scheduleBrief(ctx)
        return "Roz subah %02d:%02d par briefing sunaunga.".format(h, m)
    }

    // ---------- money, news ----------

    private fun currency(amount: Double, from: String, to: String): String {
        val f = from.trim().uppercase(Locale.ROOT)
        val t = to.trim().uppercase(Locale.ROOT)
        val r = JSONObject(get("https://open.er-api.com/v6/latest/$f")).optJSONObject("rates")
            ?: return "Rate not found."
        if (!r.has(t)) return "Currency '$t' not found."
        val rate = r.getDouble(t)
        return "%.2f %s = %.2f %s (1 %s = %.4f %s)".format(amount, f, amount * rate, t, f, rate, t)
    }

    private fun clean(s: String) = s.replace("<![CDATA[", "").replace("]]>", "")
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">")

    private fun news(topic: String): String {
        val base = if (topic.isBlank()) "https://news.google.com/rss?hl=en-PK&gl=PK&ceid=PK:en"
        else "https://news.google.com/rss/search?q=" + enc(topic) + "&hl=en-PK&gl=PK&ceid=PK:en"
        val xml = get(base)
        val titles = Regex("<item>\\s*<title>(.*?)</title>", RegexOption.DOT_MATCHES_ALL).findAll(xml)
            .map { clean(it.groupValues[1]).trim() }.take(6).toList()
        return if (titles.isEmpty()) "No news found." else titles.joinToString("\n")
    }

    // ---------- prayer ----------

    private val NAMES = listOf("Fajr", "Dhuhr", "Asr", "Maghrib", "Isha")

    private fun timings(city: String, country: String): JSONObject {
        val m = when {
            country.contains("saudi", true) -> 4
            country.contains("pakistan", true) -> 1
            else -> 3
        }
        val j = JSONObject(get("https://api.aladhan.com/v1/timingsByCity?city=" + enc(city) + "&country=" + enc(country) + "&method=" + m))
        return j.getJSONObject("data").getJSONObject("timings")
    }

    private fun prayerTimes(city: String, country: String): String {
        if (country.isBlank()) return "Please also tell me the country name."
        val t = timings(city, country)
        return city + ": " + NAMES.joinToString(", ") { it + " " + t.getString(it).take(5) }
    }

    private fun setPrayer(ctx: Context, a: JSONObject): String {
        if (!a.optBoolean("on", true)) {
            prefs(ctx).edit().remove("prayerCity").remove("prayerCountry").apply()
            Reminders.removeKind(ctx, "prayer"); Reminders.removeKind(ctx, "prayer_refresh")
            return "Turned off the prayer-time reminders."
        }
        val city = a.getString("city")
        val country = a.optString("country", "")
        if (country.isBlank()) return "Please also tell me the country name."
        prefs(ctx).edit().putString("prayerCity", city).putString("prayerCountry", country).apply()
        val r = refreshPrayers(ctx)
        Reminders.scheduleRefresh(ctx)
        return "Prayer-time reminders on. $r"
    }

    /** Fetches today's prayer times and sets an alarm for each one still to come. */
    fun refreshPrayers(ctx: Context): String {
        val city = prefs(ctx).getString("prayerCity", "") ?: ""
        val country = prefs(ctx).getString("prayerCountry", "") ?: ""
        if (city.isEmpty()) return ""
        return try {
            val t = timings(city, country)
            Reminders.removeKind(ctx, "prayer")
            val now = System.currentTimeMillis()
            val left = ArrayList<String>()
            for (n in NAMES) {
                val hm = t.getString(n).take(5)
                val c = Calendar.getInstance()
                c.set(Calendar.HOUR_OF_DAY, hm.substringBefore(":").toInt())
                c.set(Calendar.MINUTE, hm.substringAfter(":").toInt())
                c.set(Calendar.SECOND, 0)
                if (c.timeInMillis > now) { Reminders.add(ctx, c.timeInMillis, n, "prayer"); left.add("$n $hm") }
            }
            if (left.isEmpty()) "All of today's prayers have already passed." else "Baqi aaj: " + left.joinToString(", ")
        } catch (e: Exception) {
            "Could not get prayer times right now."
        }
    }

    // ---------- money diary ----------

    private fun ledgerAdd(ctx: Context, a: JSONObject): String {
        val arr = try { JSONArray(prefs(ctx).getString("ledger", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(
            JSONObject().put("t", System.currentTimeMillis()).put("kind", a.getString("kind"))
                .put("amt", a.getDouble("amount")).put("cur", a.optString("currency", "").uppercase(Locale.ROOT))
                .put("note", a.optString("note", "")).put("person", a.optString("person", ""))
        )
        while (arr.length() > 1500) arr.remove(0)
        prefs(ctx).edit().putString("ledger", arr.toString()).apply()
        return "Written in the diary: " + a.getString("kind") + " " + a.getDouble("amount") + " " + a.optString("currency", "") +
            (if (a.optString("person", "").isNotBlank()) " (" + a.getString("person") + ")" else "")
    }

    private fun ledgerSummary(ctx: Context, period: String, person: String): String {
        val arr = try { JSONArray(prefs(ctx).getString("ledger", "[]")) } catch (e: Exception) { JSONArray() }
        if (arr.length() == 0) return "The diary is empty."
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0)
        val from: Long = when (period) {
            "today" -> c.timeInMillis
            "week" -> c.timeInMillis - 6 * 86400000L
            "all" -> 0L
            else -> { c.set(Calendar.DAY_OF_MONTH, 1); c.timeInMillis }
        }
        val totals = LinkedHashMap<String, Double>()
        val owe = LinkedHashMap<String, Double>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("t") < from) continue
            val p = o.optString("person")
            if (person.isNotBlank() && !p.contains(person, true)) continue
            val k = o.getString("kind")
            val cur = o.optString("cur")
            val amt = o.getDouble("amt")
            val key = "$k ($cur)"
            totals[key] = (totals[key] ?: 0.0) + amt
            if (p.isNotBlank()) {
                val sign = when (k) { "udhaar_diya", "wapsi_di" -> 1.0; "udhaar_liya", "wapsi_mili" -> -1.0; else -> 0.0 }
                // udhaar_diya: they owe me (+). wapsi_mili: they paid back (-). udhaar_liya: I owe (-). wapsi_di: I paid back (+).
                val s = when (k) { "udhaar_diya" -> 1.0; "wapsi_mili" -> -1.0; "udhaar_liya" -> -1.0; "wapsi_di" -> 1.0; else -> 0.0 }
                if (sign != 0.0) owe["$p ($cur)"] = (owe["$p ($cur)"] ?: 0.0) + s * amt
            }
        }
        val sb = StringBuilder()
        for ((k, v) in totals) sb.append(k).append(": ").append(v).append("\n")
        for ((k, v) in owe) sb.append("Balance ").append(k).append(": ")
            .append(if (v > 0) "to receive $v" else if (v < 0) "to pay ${-v}" else "settled").append("\n")
        return sb.toString().ifBlank { "No entries in this period." }
    }

    // ---------- modes ----------

    private fun setTranslator(ctx: Context, a: JSONObject): String {
        val on = a.optBoolean("on", true)
        val lang = a.optString("language", "")
        prefs(ctx).edit().putString("translator", if (on) lang else "").apply()
        return if (on) "Translator mode on: I will now translate everything into $lang." else "Translator mode off."
    }

    private fun setAutoReply(ctx: Context, a: JSONObject): String {
        val on = a.optBoolean("on", true)
        val text = a.optString("text", "I am busy right now, I will reply shortly.")
        prefs(ctx).edit().putString("autoreply", if (on) text else "").apply()
        return if (on) "Auto-reply on: \"$text\" (Notification access is required)." else "Auto-reply off."
    }

    private fun replyMessage(confirm: (String) -> Boolean, text: String): String {
        val last = NotifState.lastReply ?: return "No recent message to reply to (turn on Notification access)."
        if (!confirm(Confirm.msg("reply", "Reply to " + last.who + " on " + last.app + "?", text))) return "The user declined; the reply was not sent."
        return if (NotifState.send(last, text)) "Reply sent." else "The reply could not be sent."
    }
}
