package com.anjoo.assistant

import java.io.File
import java.security.MessageDigest
import java.util.Locale

/**
 * Pure (no Android) helpers for project_deploy. Everything here is unit tested on the JVM:
 *  - BLAKE3 (Cloudflare Pages identifies every uploaded file by a BLAKE3 hash; no BLAKE3 library is needed on the phone)
 *  - which project files may be published (secret files such as .env are NEVER uploaded)
 *  - .env parsing, remote project names, content types
 */
object DeployCore {

    // ============================================================ BLAKE3 (spec: github.com/BLAKE3-team/BLAKE3-specs)

    private val IV = intArrayOf(
        0x6A09E667, 0xBB67AE85.toInt(), 0x3C6EF372, 0xA54FF53A.toInt(),
        0x510E527F, 0x9B05688C.toInt(), 0x1F83D9AB, 0x5BE0CD19
    )
    private val PERM = intArrayOf(2, 6, 3, 10, 7, 0, 4, 13, 1, 11, 12, 5, 9, 14, 15, 8)
    private const val CHUNK_START = 1
    private const val CHUNK_END = 2
    private const val PARENT = 4
    private const val ROOT = 8
    private const val CHUNK_LEN = 1024

    private fun rotr(x: Int, n: Int) = (x ushr n) or (x shl (32 - n))

    private fun g(s: IntArray, a: Int, b: Int, c: Int, d: Int, mx: Int, my: Int) {
        s[a] = s[a] + s[b] + mx
        s[d] = rotr(s[d] xor s[a], 16)
        s[c] = s[c] + s[d]
        s[b] = rotr(s[b] xor s[c], 12)
        s[a] = s[a] + s[b] + my
        s[d] = rotr(s[d] xor s[a], 8)
        s[c] = s[c] + s[d]
        s[b] = rotr(s[b] xor s[c], 7)
    }

    private fun round(s: IntArray, m: IntArray) {
        g(s, 0, 4, 8, 12, m[0], m[1]); g(s, 1, 5, 9, 13, m[2], m[3])
        g(s, 2, 6, 10, 14, m[4], m[5]); g(s, 3, 7, 11, 15, m[6], m[7])
        g(s, 0, 5, 10, 15, m[8], m[9]); g(s, 1, 6, 11, 12, m[10], m[11])
        g(s, 2, 7, 8, 13, m[12], m[13]); g(s, 3, 4, 9, 14, m[14], m[15])
    }

    /** One compression. Returns the 8-word chaining value (first half of the output). */
    private fun compress(cv: IntArray, block: IntArray, counter: Long, blockLen: Int, flags: Int): IntArray {
        val s = IntArray(16)
        for (i in 0 until 8) s[i] = cv[i]
        for (i in 0 until 4) s[8 + i] = IV[i]
        s[12] = counter.toInt()
        s[13] = (counter ushr 32).toInt()
        s[14] = blockLen
        s[15] = flags
        var m = block.copyOf()
        for (r in 0 until 7) {
            round(s, m)
            if (r < 6) { val p = IntArray(16); for (i in 0 until 16) p[i] = m[PERM[i]]; m = p }
        }
        val out = IntArray(8)
        for (i in 0 until 8) out[i] = s[i] xor s[i + 8]
        return out
    }

    private fun words(data: ByteArray, off: Int, len: Int): IntArray {
        val w = IntArray(16)
        for (i in 0 until len) w[i shr 2] = w[i shr 2] or ((data[off + i].toInt() and 0xFF) shl (8 * (i and 3)))
        return w
    }

    /** Chaining value of one chunk (up to 1024 bytes). */
    private fun chunkCv(data: ByteArray, off: Int, len: Int, counter: Long, root: Boolean): IntArray {
        var cv = IV.copyOf()
        val blocks = if (len == 0) 1 else (len + 63) / 64
        for (b in 0 until blocks) {
            val bOff = off + b * 64
            val bLen = if (len == 0) 0 else minOf(64, len - b * 64)
            var flags = 0
            if (b == 0) flags = flags or CHUNK_START
            if (b == blocks - 1) { flags = flags or CHUNK_END; if (root) flags = flags or ROOT }
            cv = compress(cv, words(data, bOff, bLen), counter, bLen, flags)
        }
        return cv
    }

    private fun node(data: ByteArray, off: Int, len: Int, firstChunk: Long, root: Boolean): IntArray {
        if (len <= CHUNK_LEN) return chunkCv(data, off, len, firstChunk, root)
        // The left subtree takes the largest power-of-two number of whole chunks that still leaves something for the right.
        val chunks = (len + CHUNK_LEN - 1) / CHUNK_LEN
        var leftChunks = 1
        while (leftChunks * 2 < chunks) leftChunks *= 2
        val leftLen = leftChunks * CHUNK_LEN
        val left = node(data, off, leftLen, firstChunk, false)
        val right = node(data, off + leftLen, len - leftLen, firstChunk + leftChunks, false)
        val block = IntArray(16)
        for (i in 0 until 8) { block[i] = left[i]; block[8 + i] = right[i] }
        return compress(IV, block, 0, 64, PARENT or (if (root) ROOT else 0))
    }

    /** First 32 bytes of the BLAKE3 hash of [data], as 64 lower-case hex characters. */
    fun blake3Hex(data: ByteArray): String {
        val cv = node(data, 0, data.size, 0, true)
        val sb = StringBuilder(64)
        for (w in cv) for (i in 0 until 4) sb.append(String.format(Locale.ROOT, "%02x", (w ushr (8 * i)) and 0xFF))
        return sb.toString()
    }

    private const val B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

    /** Standard Base64 without line breaks (java.util.Base64 needs API 26, android.util.Base64 is not on the JVM). */
    fun base64(bytes: ByteArray): String {
        val sb = StringBuilder((bytes.size + 2) / 3 * 4)
        var i = 0
        while (i < bytes.size) {
            val b0 = bytes[i].toInt() and 0xFF
            val b1 = if (i + 1 < bytes.size) bytes[i + 1].toInt() and 0xFF else 0
            val b2 = if (i + 2 < bytes.size) bytes[i + 2].toInt() and 0xFF else 0
            sb.append(B64[b0 shr 2]).append(B64[((b0 and 3) shl 4) or (b1 shr 4)])
            sb.append(if (i + 1 < bytes.size) B64[((b1 and 15) shl 2) or (b2 shr 6)] else '=')
            sb.append(if (i + 2 < bytes.size) B64[b2 and 63] else '=')
            i += 3
        }
        return sb.toString()
    }

    /** Cloudflare Pages file key: first 32 hex chars of BLAKE3(base64(content) + extension without the dot). Same as wrangler. */
    fun cfHash(content: ByteArray, path: String): String {
        val ext = path.substringAfterLast('/').substringAfterLast('.', "")
        return blake3Hex((base64(content) + ext).toByteArray(Charsets.UTF_8)).take(32)
    }

    fun sha1Hex(bytes: ByteArray): String {
        val d = MessageDigest.getInstance("SHA-1").digest(bytes)
        val sb = StringBuilder(40)
        for (b in d) sb.append(String.format(Locale.ROOT, "%02x", b.toInt() and 0xFF))
        return sb.toString()
    }

    // ============================================================ which files are published

    private val SKIP_DIRS = setOf("node_modules", ".git", "build", "dist", ".gradle", "__pycache__", ".idea", "__MACOSX", "venv", ".venv")
    const val MAX_FILE = 25L * 1024 * 1024
    const val MAX_TOTAL = 50L * 1024 * 1024
    const val MAX_FILES = 2000

    class Collected(val files: List<File>, val excluded: List<String>, val tooBig: List<String>)

    /** Relative path of a file that must never leave the phone (secrets, keystores, git state, the app's own bookkeeping). */
    fun isPrivate(rel: String): Boolean {
        val name = rel.substringAfterLast('/')
        return name.startsWith(".anjoo") || name.startsWith(".env") || SecretScan.isSecretFileName(rel)
    }

    fun collect(dir: File): Collected {
        val ok = ArrayList<File>()
        val excluded = ArrayList<String>()
        val big = ArrayList<String>()
        val all = dir.walkTopDown().onEnter { it == dir || it.name !in SKIP_DIRS }.filter { it.isFile }.sortedBy { it.path }
        for (f in all) {
            val rel = f.relativeTo(dir).path.replace('\\', '/')
            when {
                isPrivate(rel) -> if (!rel.substringAfterLast('/').startsWith(".anjoo")) excluded.add(rel)
                f.length() > MAX_FILE -> big.add(rel)
                else -> ok.add(f)
            }
        }
        return Collected(ok, excluded, big)
    }

    // ============================================================ names, env files, content types

    /** A safe remote project name: a-z, 0-9 and single hyphens, 1..[max] chars, never starting or ending with a hyphen. */
    fun slug(name: String, max: Int = 40): String {
        val s = name.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "-").trim('-').take(max).trim('-')
        return s.ifEmpty { "site" }
    }

    val ENV_KEY = Regex("^[A-Za-z_][A-Za-z0-9_]*$")

    /** KEY=VALUE lines of a .env file: comments, `export`, quotes and inline comments handled. Later lines win. */
    fun parseEnv(text: String): LinkedHashMap<String, String> {
        val out = LinkedHashMap<String, String>()
        for (raw in text.lineSequence()) {
            var line = raw.trim().removePrefix("﻿")
            if (line.isEmpty() || line.startsWith("#")) continue
            if (line.startsWith("export ")) line = line.substring(7).trim()
            val eq = line.indexOf('=')
            if (eq <= 0) continue
            val key = line.substring(0, eq).trim()
            if (!ENV_KEY.matches(key)) continue
            var v = line.substring(eq + 1).trim()
            if (v.length >= 2 && v.startsWith("\"") && v.indexOf('"', 1) > 0) {
                val end = v.lastIndexOf('"')
                v = v.substring(1, end).replace("\\n", "\n").replace("\\\"", "\"")
            } else if (v.length >= 2 && v.startsWith("'") && v.indexOf('\'', 1) > 0) {
                v = v.substring(1, v.lastIndexOf('\''))
            } else {
                val hash = v.indexOf(" #")
                if (hash >= 0) v = v.substring(0, hash).trim()
            }
            out[key] = v
        }
        return out
    }

    private val TYPES = mapOf(
        "html" to "text/html", "htm" to "text/html", "css" to "text/css", "js" to "application/javascript", "mjs" to "application/javascript",
        "json" to "application/json", "map" to "application/json", "txt" to "text/plain", "xml" to "application/xml", "svg" to "image/svg+xml",
        "png" to "image/png", "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "gif" to "image/gif", "webp" to "image/webp", "ico" to "image/x-icon",
        "avif" to "image/avif", "woff" to "font/woff", "woff2" to "font/woff2", "ttf" to "font/ttf", "otf" to "font/otf", "pdf" to "application/pdf",
        "mp4" to "video/mp4", "webm" to "video/webm", "mp3" to "audio/mpeg", "wav" to "audio/wav", "wasm" to "application/wasm", "webmanifest" to "application/manifest+json"
    )

    fun contentType(path: String): String = TYPES[path.substringAfterLast('.', "").lowercase(Locale.ROOT)] ?: "application/octet-stream"

    fun kb(bytes: Long): String = if (bytes >= 1024 * 1024) String.format(Locale.ROOT, "%.1f MB", bytes / 1048576.0) else (bytes / 1024 + 1).toString() + " KB"
}
