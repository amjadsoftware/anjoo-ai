package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.regex.Pattern

/**
 * The Code Studio toolbox: the same moves a careful engineer makes in a terminal, on a Code Studio project.
 * Explore (tree, search), read with line numbers, make exact edits, check/run/test, and keep history
 * (undo, diff, named checkpoints). Every tool works on one project; a blank `project` means the newest one.
 */
object CodeTools {

    val NAMES = setOf(
        "project_tree", "project_read", "project_write", "project_edit", "project_search",
        "project_replace", "project_manage", "project_check", "project_history", "project_template", "project_studio", "project_engineering", "project_git", "project_deps", "project_code", "project_debug", "project_deploy"
    )

    private const val CAP = 14000
    private const val NO_PROJECT = "No Code Studio project found. Create one with project_template or write_code."

    fun run(ctx: Context, confirm: (String) -> Boolean, name: String, a: JSONObject): String? {
        if (name !in NAMES) return null
        return try {
            when (name) {
                "project_template" -> template(ctx, a)
                "project_manage" -> manage(ctx, confirm, a)
                "project_studio" -> studio(ctx, confirm, a)
                "project_git" -> Git.run(ctx, confirm, a) { find(ctx, a) }
                "project_deps" -> Deps.run(ctx, a) { find(ctx, a) }
                "project_code" -> CodeNav.run(ctx, a) { find(ctx, a) }
                "project_debug" -> Debug.run(ctx, a) { find(ctx, a) }
                "project_deploy" -> Deploy.run(ctx, confirm, a) { find(ctx, a) }
                else -> {
                    val (dir, err) = find(ctx, a)
                    if (dir == null) return err
                    when (name) {
                        "project_tree" -> tree(dir)
                        "project_read" -> read(dir, a)
                        "project_write" -> write(ctx, dir, a)
                        "project_edit" -> edit(ctx, dir, a)
                        "project_search" -> search(dir, a)
                        "project_replace" -> replace(ctx, dir, a)
                        "project_check" -> check(ctx, confirm, dir, a)
                        "project_engineering" -> engineering(dir, a)
                        else -> history(ctx, dir, a)
                    }
                }
            }
        } catch (e: Exception) {
            "Tool nakam: " + (e.message ?: e.javaClass.simpleName)
        }
    }


    // ------------------------------------------------------------------ chat-first Code Studio controls

    /**
     * Exposes the remaining Code Studio quick actions to the main chat, where a project card
     * is also rendered after a project_* tool call. No extra editor screen is required for the
     * usual preview/run/export/history workflow.
     */
    private fun studio(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val action = a.optString("action", "preview").trim().lowercase().replace(' ', '_').replace('-', '_')
        if (action in setOf("deep_think", "think", "thinking")) {
            val prefs = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
            val current = prefs.getBoolean("codeThink", true)
            val requested = a.optString("value", "toggle").trim().lowercase()
            val next = when (requested) {
                "on", "true", "yes", "enable", "enabled" -> true
                "off", "false", "no", "disable", "disabled" -> false
                "status", "check" -> current
                else -> !current
            }
            if (requested !in setOf("status", "check") && next != current) prefs.edit().putBoolean("codeThink", next).apply()
            return "Code Studio Deep Think: " + (if (next) "ON" else "OFF") +
                if (requested in setOf("status", "check")) " (status only; unchanged)." else "."
        }
        if (action in setOf("list", "list_projects", "projects"))
            return manage(ctx, confirm, JSONObject(a.toString()).put("action", "list_projects"))

        // The Code Studio prompt enhancer is also available from the main chat, even before a project exists.
        if (action in setOf("enhance_prompt", "improve_prompt", "polish_prompt")) {
            val request = a.optString("message", a.optString("instruction", a.optString("value", ""))).trim()
            if (request.isBlank()) return "Give a message or instruction to improve the prompt."
            val all = Coder.list(ctx)
            val hint = a.optString("project", "").trim()
            val project = if (hint.isBlank()) all.firstOrNull() else (
                all.firstOrNull { it.name.equals(hint, true) }
                    ?: all.firstOrNull { Coder.name(it).equals(hint, true) || Coder.name(it).contains(hint, true) }
                )
            val info = project?.let { d ->
                "Project: " + Coder.name(d) + "\nFiles: " + Coder.readFiles(d).keys.take(100).joinToString(", ")
            } ?: ""
            return PromptMaker.improve(ctx, request, info).ifBlank {
                "Could not improve the prompt. Check the API key and network, then try again."
            }
        }

        // New-project Build mode mirrors Code Studio's Build tab but keeps the result in this chat.
        if (action in setOf("build", "build_project", "new_project")) {
            val task = a.optString("message", a.optString("instruction", a.optString("value", ""))).trim()
            if (task.isBlank()) return "Give the requirements in the message to create a new project."
            val language = a.optString("language", "auto").ifBlank { "auto" }
            val (built, notes) = Coder.withRunConfirm(confirm) { Coder.build(ctx, task, language, true, Coder.deepDefault(ctx), {}, {}) }
            return "PROJECT_BUILT: '" + Coder.name(built) + "' is ready (" + Coder.readFiles(built).size + " files). The chat will show the project card, file list, preview and ZIP download.\n" + notes
        }

        val (dir, err) = find(ctx, a)
        if (dir == null) return err

        val message = a.optString("message", a.optString("instruction", a.optString("value", ""))).trim()
        if (action in setOf("ask", "explain", "ask_about_project")) {
            if (message.isBlank()) return "Give your question about the project in the message."
            return Coder.ask(ctx, dir, message, Coder.deepDefault(ctx))
        }
        if (action in setOf("edit", "revise", "apply_change")) {
            if (message.isBlank()) return "Write what to change in the project in the message."
            val result = Coder.withRunConfirm(confirm) { Coder.revise(ctx, dir, message, Coder.deepDefault(ctx), {}, {}) }
            return "PROJECT_EDITED: '" + Coder.name(dir) + "'\n" + result
        }
        val preset = when (action) {
            "find_bugs", "review_bugs" -> "Review the whole project for bugs, edge cases and crashes. Fix every real problem you find and list what you fixed."
            "optimize", "performance" -> "Optimize performance and clean the code without changing behaviour. Explain what improved."
            "add_tests", "tests" -> "Add automated tests (or a test page / test script for web projects) covering the main features and edge cases."
            "better_ui", "polish_ui" -> "Make the interface look more polished and professional: spacing, typography, colors, animations and mobile friendliness. Keep all features."
            "security", "security_review" -> "Do a security review (input validation, XSS, secrets, unsafe storage) and fix the issues you find."
            "cleanup", "clean_up", "refactor" -> "Refactor for readability: clear names, small functions, helpful comments. Keep behaviour identical."
            "responsive", "mobile_friendly" -> "Make it fully responsive and touch friendly for phones, tablets and desktop."
            "engineering_review", "quality_gate" -> "Perform a full software-engineering quality review: inspect architecture, correctness, security, dependencies, tests, maintainability and release readiness. Fix only verified issues, preserve behaviour, then run all supported checks. Clearly separate static checks from tests that actually ran."
            else -> ""
        }
        if (preset.isNotBlank()) return "PROJECT_EDITED: '" + Coder.name(dir) + "'\n" + Coder.revise(ctx, dir, preset, Coder.deepDefault(ctx), {}, {})

        return when (action) {
            "preview", "show_preview", "preview_in_chat" -> {
                val entry = PreviewServer.entry(dir)
                    ?: return "This project has no HTML/HTM entry page; the inline browser preview is only for web projects."
                val pages = PreviewServer.pages(dir)
                if (ctx is MainActivity) {
                    "PREVIEW_READY: '" + Coder.name(dir) + "' in-chat preview is ready. Entry: " + entry +
                        "; pages: " + pages.size + ". The project card in this chat reply will have Preview, Full screen, Download ZIP and Code Studio actions."
                } else {
                    Coder.show(ctx, dir)
                    "Preview opened: '" + Coder.name(dir) + "' (" + pages.size + " HTML page(s))."
                }
            }
            "run_python", "python" -> {
                val entry = PyRun.entry(dir) ?: return "This project has no Python (.py) entry to run."
                val syntaxOnly = PyRun.needsSyntaxOnly(dir)
                val r = PyRun.run(ctx, dir, entry, syntaxOnly)
                if (!r.loaded) return "The Python runtime did not load; internet is needed the first time."
                if (!r.finished) return "Python did not finish in time (60-second limit). The program may be waiting for input or stuck in an endless loop."
                buildString {
                    append("PYTHON RUN: ").append(entry).append('\n')
                    if (syntaxOnly) append("NOTE: some of the project's libraries are unsupported in this runtime; only a syntax check was done.\n")
                    if (r.out.isNotBlank()) append("STDOUT:\n").append(r.out.trim().take(9000)).append('\n')
                    if (r.err.isNotBlank()) append("STDERR:\n").append(r.err.trim().takeLast(5000)).append('\n')
                    if (r.out.isBlank() && r.err.isBlank()) append("The program ran; no output was produced.")
                }.trim()
            }
            "run", "run_project", "test", "test_project", "coverage", "lint", "check", "fix_preview_errors", "debug_preview" -> {
                val checkAction = when (action) {
                    "test", "test_project" -> "test"
                    "coverage" -> "coverage"
                    "lint", "check" -> "lint"
                    else -> "run"
                }
                val result = check(ctx, confirm, dir, JSONObject().put("action", checkAction)
                    .put("path", a.optString("path", "")).put("coverage", a.optBoolean("coverage", true)))
                if (action in setOf("fix_preview_errors", "debug_preview"))
                    "Preview/runtime diagnostics for '" + Coder.name(dir) + "':\n" + result +
                        "\nIf errors are reported, fix the actual files and run this check again; report only verified results."
                else result
            }
            "undo" -> history(ctx, dir, JSONObject().put("action", "undo"))
            "diff" -> history(ctx, dir, JSONObject().put("action", "diff"))
            "history", "log" -> history(ctx, dir, JSONObject().put("action", "log"))
            "checkpoint", "save_checkpoint" -> history(ctx, dir, JSONObject().put("action", "checkpoint").put("message", a.optString("message", "Saved from chat")))
            "restore" -> history(ctx, dir, JSONObject().put("action", "restore").put("id", a.optInt("id", -1)))
            "compare_checkpoint" -> history(ctx, dir, JSONObject().put("action", "compare").put("id", a.optInt("id", -1)))
            "stats", "deps", "format" -> manage(ctx, confirm, JSONObject(a.toString()).put("action", action))
            "export_zip", "download_zip" -> FileAccess.tool(ctx, confirm, "export_project",
                JSONObject().put("project", Coder.name(dir)).put("as_zip", true).put("folder", a.optString("folder", "")))
                ?: "ZIP export tool unavailable."
            "export_html", "single_html", "save_html" -> {
                val html = PreviewServer.inline(dir)
                    ?: return "Single-file HTML export needs the web project's HTML entry page."
                val slug = Coder.name(dir).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "website" }
                FileAccess.tool(ctx, confirm, "save_file", JSONObject()
                    .put("filename", "$slug.html").put("content", html).put("folder", a.optString("folder", "")))
                    ?: "HTML save tool unavailable."
            }
            "open_studio", "open_editor" -> {
                "There is no separate editor screen: all work on project '" + Coder.name(dir) + "' happens in this chat (project_read / project_write / project_edit / project_studio)."
            }
            "rename" -> manage(ctx, confirm, JSONObject(a.toString()).put("action", "rename_project"))
            "delete" -> manage(ctx, confirm, JSONObject(a.toString()).put("action", "delete_project"))
            else -> "project_studio action chunein: build, ask, edit, enhance_prompt, find_bugs, optimize, add_tests, better_ui, security_review, cleanup, responsive, engineering_review, preview, run_python, run, test, coverage, lint, fix_preview_errors, undo, diff, history, checkpoint, restore, compare_checkpoint, stats, deps, format, export_zip, export_html, deep_think, open_studio, rename, delete, list_projects."
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun find(ctx: Context, a: JSONObject): Pair<File?, String> {
        val all = Coder.list(ctx)
        val n = a.optString("project", "").trim()
        if (n.isEmpty()) return all.firstOrNull()?.let { Pair(it, "") } ?: Pair(null, NO_PROJECT)
        val hit = all.firstOrNull { it.name == n }
            ?: all.firstOrNull { Coder.name(it).equals(n, true) }
            ?: all.firstOrNull { Coder.name(it).contains(n, true) || it.name.contains(n, true) }
        return if (hit != null) Pair(hit, "") else Pair(null, "No project with this name found: $n. Projects: " + all.take(15).joinToString(", ") { Coder.name(it) })
    }

    private fun cleanPath(p: String): String? {
        val parts = p.replace('\\', '/').split('/').map { it.trim() }.filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty() || parts.any { it == ".." } || parts.size > 12) return null
        if (parts.last().startsWith(".anjoo")) return null
        return parts.joinToString("/")
    }

    private val SKIP_DIRS = setOf("node_modules", ".git", "__pycache__", "build", ".gradle")

    private fun listFiles(dir: File): List<File> =
        dir.walkTopDown().onEnter { it == dir || it.name !in SKIP_DIRS }
            .filter { it.isFile && !it.name.startsWith(".anjoo") }.take(3000).sortedBy { it.path }.toList()

    private fun rel(dir: File, f: File) = f.relativeTo(dir).path.replace('\\', '/')

    private fun isBinary(f: File): Boolean = try {
        f.inputStream().use { s -> val b = ByteArray(2000); val n = s.read(b); (0 until maxOf(n, 0)).any { b[it].toInt() == 0 } }
    } catch (e: Exception) { false }

    private fun readText(f: File): String? = if (isBinary(f)) null else try { f.readText(Charsets.UTF_8) } catch (e: Exception) { null }

    /** Static engineering reports; action=audit adds the live dependency CVE check (OSV.dev) to the security review. */
    private fun engineering(dir: File, a: JSONObject): String {
        val action = a.optString("action", "quality_gate").trim().lowercase().replace('-', '_').replace(' ', '_')
        val files = textFiles(dir)
        if (action in setOf("audit", "security_audit", "full_security", "cve")) {
            if (files.isEmpty()) return "Project '" + Coder.name(dir) + "' has no readable text source file."
            val secrets = SecretScan.report(Coder.name(dir), files, 40)
            val security = Engineering.report(Coder.name(dir), files, "security")
            return cap(security + "\n\n" + secrets + "\n\n" + Deps.auditForReport(dir), 24000)
        }
        return Engineering.report(Coder.name(dir), files, action)
    }

    private fun textFiles(dir: File): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (f in listFiles(dir)) { if (f.length() > 1_500_000) continue; readText(f)?.let { out[rel(dir, f)] = it } }
        return out
    }

    /** One undo point per burst of edits: the first change after 90 quiet seconds saves the project. */
    private fun snap(ctx: Context, dir: File) {
        val f = File(File(ctx.filesDir, "undo"), dir.name + ".json")
        if (!f.exists() || System.currentTimeMillis() - f.lastModified() > 90_000) Coder.snapshot(ctx, dir)
    }

    private fun done(ctx: Context, dir: File) { dir.setLastModified(System.currentTimeMillis()); Coder.keepCopy(ctx, dir) }

    private fun cap(s: String, n: Int = CAP) = if (s.length <= n) s else s.take(n * 2 / 3) + "\n...[middle part trimmed]...\n" + s.takeLast(n / 3)

    private fun lines(s: String): Int = if (s.isEmpty()) 0 else s.count { it == '\n' } + 1

    private fun sizeText(n: Long) = if (n < 1024) "$n B" else String.format(java.util.Locale.US, "%.1f KB", n / 1024.0)

    private fun globRegex(g: String): Regex {
        val sb = StringBuilder()
        var i = 0
        while (i < g.length) {
            val c = g[i]
            when {
                c == '*' && i + 1 < g.length && g[i + 1] == '*' -> { sb.append(".*"); i++; if (i + 1 < g.length && g[i + 1] == '/') i++ }
                c == '*' -> sb.append("[^/]*")
                c == '?' -> sb.append("[^/]")
                c == '{' -> sb.append("(")
                c == '}' -> sb.append(")")
                c == ',' -> sb.append("|")
                "\\.[]()+^$|".indexOf(c) >= 0 -> sb.append('\\').append(c)
                else -> sb.append(c)
            }
            i++
        }
        return Regex(sb.toString(), RegexOption.IGNORE_CASE)
    }

    private fun globOk(path: String, g: String): Boolean {
        if (g.isBlank()) return true
        val r = globRegex(g.trim())
        return if (g.contains('/')) r.matches(path) else r.matches(path.substringAfterLast('/'))
    }

    private fun regexOf(p: String, ignoreCase: Boolean, literal: Boolean = false): Regex {
        val opts = if (ignoreCase) setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE) else setOf(RegexOption.MULTILINE)
        return if (literal) Regex(Regex.escape(p), opts) else try { Regex(p, opts) } catch (e: Exception) { Regex(Regex.escape(p), opts) }
    }

    /** Problems the quick checker sees in one file (empty when clean). */
    /**
     * Safety check after every write or edit (like re-reading the file after changing it):
     * warns when the file became empty, shrank a lot, or has unbalanced brackets. The warning goes into the tool
     * result so the AI sees it and must fix it or undo (project_history) before saying the work is done.
     */
    private fun sanity(path: String, before: String?, after: String): String {
        val w = ArrayList<String>()
        if (after.isBlank()) w.add("file became EMPTY")
        else if (before != null && before.length > 300 && after.length < before.length * 0.4)
            w.add("file became very short (" + before.length + " to " + after.length + " chars); was the rest deleted by mistake?")
        val ext = path.substringAfterLast('.', "").lowercase()
        if (ext in setOf("kt", "kts", "java", "js", "mjs", "jsx", "ts", "tsx", "css", "scss", "json", "c", "cpp", "cs", "go", "rs", "php", "dart", "swift")) {
            var br = 0; var pa = 0; var sq = 0
            for (ch in after) when (ch) { '{' -> br++; '}' -> br--; '(' -> pa++; ')' -> pa--; '[' -> sq++; ']' -> sq-- }
            val bBefore = if (before == null) 0 else before.count { it == '{' } - before.count { it == '}' }
            val pBefore = if (before == null) 0 else before.count { it == '(' } - before.count { it == ')' }
            // Only warn when the edit itself made the brackets uneven (an already uneven file is not blamed on this edit).
            if (br != 0 && br != bBefore) w.add("{ } not balanced (difference " + br + ")")
            if (pa != 0 && pa != pBefore) w.add("( ) not balanced (difference " + pa + ")")
            if (sq != 0 && before != null && sq != before.count { it == '[' } - before.count { it == ']' }) w.add("[ ] not balanced (difference " + sq + ")")
        }
        return if (w.isEmpty()) "" else "\nWARNING (check after the change): " + w.joinToString("; ") + ". First re-read the file with project_read and fix it, or restore the previous version with project_history. Do not say 'done' until it is fixed."
    }

    private fun quick(dir: File, path: String): String {
        val all = textFiles(dir)
        val l = Coder.lint(all).lines().filter { it.contains(path) }
        return if (l.isEmpty()) "" else "\nCHECK:\n" + l.joinToString("\n")
    }

    // ------------------------------------------------------------------ project_tree

    private fun tree(dir: File): String {
        val fs = listFiles(dir)
        if (fs.isEmpty()) return "Project '" + Coder.name(dir) + "' is empty."
        var total = 0
        val sb = StringBuilder()
        val shown = HashSet<String>()
        for (f in fs) {
            val p = rel(dir, f)
            val parts = p.split('/')
            for (i in 0 until parts.size - 1) {
                val d = parts.take(i + 1).joinToString("/")
                if (shown.add(d)) sb.append("  ".repeat(i)).append(parts[i]).append("/\n")
            }
            val t = if (f.length() > 1_500_000) null else readText(f)
            val ln = if (t == null) 0 else lines(t)
            total += ln
            sb.append("  ".repeat(parts.size - 1)).append(parts.last()).append("  (")
                .append(if (t == null) "binary, " + sizeText(f.length()) else "$ln lines, " + sizeText(f.length())).append(")\n")
        }
        return "PROJECT: " + Coder.name(dir) + "  [folder: " + dir.name + "]  " + fs.size + " files, ~" + total + " lines\n" + cap(sb.toString())
    }

    // ------------------------------------------------------------------ project_read

    private fun read(dir: File, a: JSONObject): String {
        val p = cleanPath(a.optString("path")) ?: return "give a path (e.g. src/app.js)."
        val f = File(dir, p)
        if (!f.isFile) {
            val near = listFiles(dir).map { rel(dir, it) }.filter { it.substringAfterLast('/').equals(p.substringAfterLast('/'), true) }.take(5)
            return "File not found: $p." + (if (near.isNotEmpty()) " Milti julti: " + near.joinToString(", ") else " Check with project_tree.")
        }
        val t = readText(f) ?: return "$p is a binary file (" + sizeText(f.length()) + "), cannot be read as text."
        val all = t.split("\n")
        val off = a.optInt("offset", 1).coerceAtLeast(1)
        val lim = a.optInt("limit", 400).coerceIn(1, 1500)
        if (off > all.size) return "$p has only " + all.size + " lines."
        val end = minOf(all.size, off - 1 + lim)
        val sb = StringBuilder()
        for (i in off - 1 until end) sb.append(String.format(java.util.Locale.US, "%5d\t", i + 1)).append(all[i].take(600)).append('\n')
        val more = if (end < all.size) "\n[...and " + (all.size - end) + " lines remain: offset=" + (end + 1) + " to continue]" else ""
        return "FILE: $p  (" + all.size + " lines)\n" + cap(sb.toString(), 24000) + more
    }

    // ------------------------------------------------------------------ project_write

    private fun write(ctx: Context, dir: File, a: JSONObject): String {
        val p = cleanPath(a.optString("path")) ?: return "invalid path (e.g. src/app.js)."
        if (!a.has("content")) return "content do."
        val c = a.getString("content")
        val existed = File(dir, p).isFile
        val beforeW = if (existed) readText(File(dir, p)) else null
        snap(ctx, dir)
        if (!Coder.writeFile(dir, p, c)) return "Could not write file: $p"
        done(ctx, dir)
        return (if (existed) "Overwrote " else "Created ") + p + " (" + lines(c) + " lines)" + quick(dir, p) + sanity(p, beforeW, c)
    }

    // ------------------------------------------------------------------ project_edit

    private class Ed(val old: String, val new: String, val all: Boolean)

    private fun edit(ctx: Context, dir: File, a: JSONObject): String {
        val p = cleanPath(a.optString("path")) ?: return "path do."
        val eds = ArrayList<Ed>()
        val arr = a.optJSONArray("edits")
        if (arr != null) for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            eds.add(Ed(o.optString("old_text"), o.optString("new_text"), o.optBoolean("replace_all", false)))
        }
        if (a.has("old_text") || a.has("new_text")) eds.add(Ed(a.optString("old_text"), a.optString("new_text"), a.optBoolean("replace_all", false)))
        if (eds.isEmpty()) return "Give old_text and new_text (or a list of edits)."
        val f = File(dir, p)
        if (!f.isFile) {
            val e0 = eds.first()
            if (e0.old.isEmpty()) {
                snap(ctx, dir)
                if (!Coder.writeFile(dir, p, e0.new)) return "File was not created: $p"
                done(ctx, dir)
                return "Created $p (" + lines(e0.new) + " lines)" + quick(dir, p)
            }
            return "File not found: $p. Check the path with project_tree first."
        }
        var text = readText(f) ?: return "$p is binary."
        val before = text
        var changed = 0
        for ((i, e) in eds.withIndex()) {
            val tag = if (eds.size > 1) "Edit " + (i + 1) + ": " else ""
            if (e.old.isEmpty()) return tag + "old_text is empty."
            if (e.old == e.new) return tag + "old_text and new_text are the same."
            var n = 0; var at = 0
            while (true) { val k = text.indexOf(e.old, at); if (k < 0) break; n++; at = k + maxOf(1, e.old.length) }
            if (n == 0) {
                // forgive trailing-space / line-ending differences when the match is then unique
                val norm = { s: String -> s.replace("\r\n", "\n").split("\n").joinToString("\n") { it.trimEnd() } }
                val nt = norm(text); val no = norm(e.old)
                val k = nt.indexOf(no)
                if (no.isNotEmpty() && k >= 0 && nt.indexOf(no, k + 1) < 0) {
                    text = nt.replaceFirst(no, e.new.replace("\r\n", "\n")); changed++; continue
                }
                val first = e.old.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: ""
                val ln = if (first.isEmpty()) -1 else text.lines().indexOfFirst { it.contains(first) } + 1
                return tag + "old_text not found in the file (nothing changed)." + (if (ln > 0) " The first line is probably near line $ln: read it with project_read and copy it EXACTLY." else " Read the real text with project_read.")
            }
            if (n > 1 && !e.all) return tag + "old_text " + n + " places (nothing changed). Include a few surrounding lines, or pass replace_all=true."
            text = if (e.all) text.replace(e.old, e.new) else text.replaceFirst(e.old, e.new)
            changed += if (e.all) n else 1
        }
        if (text == before) return "No difference."
        snap(ctx, dir)
        f.writeText(text, Charsets.UTF_8)
        done(ctx, dir)
        val d = Coder.lineDiff(before.split("\n"), text.split("\n"))
        val shown = d.filter { it.startsWith("+ ") || it.startsWith("- ") }.take(30)
        return "Edited $p: $changed replacement(s), +" + d.count { it.startsWith("+ ") } + " -" + d.count { it.startsWith("- ") } + "\n" + shown.joinToString("\n") { it.take(200) } + quick(dir, p) + sanity(p, before, text)
    }

    // ------------------------------------------------------------------ project_search

    private val SYMBOLS = mapOf(
        "py" to Regex("^\\s*(?:async\\s+)?(?:def|class)\\s+\\w+.*"),
        "js" to Regex("^\\s*(?:export\\s+)?(?:default\\s+)?(?:async\\s+)?(?:function\\*?|class)\\s+\\w+.*|^\\s*(?:export\\s+)?(?:const|let|var)\\s+\\w+\\s*=\\s*(?:async\\s*)?(?:\\([^)]*\\)|\\w+)\\s*=>.*"),
        "kt" to Regex("^\\s*(?:(?:public|private|protected|internal|open|abstract|override|suspend|data|sealed|inline|const)\\s+)*(?:fun|class|interface|object)\\s+.*"),
        "java" to Regex("^\\s*(?:public|private|protected)\\s+[\\w<>\\[\\], .?]+\\s+\\w+\\s*\\(.*|^\\s*(?:public\\s+)?(?:abstract\\s+)?(?:class|interface|enum)\\s+\\w+.*"),
        "go" to Regex("^(?:func|type)\\s+.*"),
        "rs" to Regex("^\\s*(?:pub\\s+)?(?:fn|struct|enum|trait|impl)\\s+.*"),
        "php" to Regex("^\\s*(?:public|private|protected|static|abstract)?\\s*(?:function|class)\\s+\\w+.*"),
        "css" to Regex("^[^\\s@/*][^{]*\\{\\s*$|^@media.*\\{\\s*$"),
        "html" to Regex(".*\\bid\\s*=\\s*[\"'][^\"']+[\"'].*")
    )

    private fun symbolRegex(ext: String): Regex? = when (ext) {
        "py" -> SYMBOLS["py"]
        "js", "mjs", "jsx", "ts", "tsx" -> SYMBOLS["js"]
        "kt", "kts" -> SYMBOLS["kt"]
        "java", "cs", "dart", "swift" -> SYMBOLS["java"]
        "go" -> SYMBOLS["go"]
        "rs" -> SYMBOLS["rs"]
        "php" -> SYMBOLS["php"]
        "css", "scss" -> SYMBOLS["css"]
        "html", "htm" -> SYMBOLS["html"]
        else -> null
    }

    private fun search(dir: File, a: JSONObject): String {
        val mode = a.optString("mode", "grep").lowercase()
        val g = a.optString("glob", "")
        val max = a.optInt("max", 60).coerceIn(1, 300)
        if (mode == "glob") {
            val pat = a.optString("pattern", g).ifBlank { "**" }
            val hits = listFiles(dir).map { rel(dir, it) }.filter { globOk(it, pat) }
            return if (hits.isEmpty()) "No file matched: $pat" else hits.size.toString() + " files:\n" + cap(hits.take(max * 3).joinToString("\n"))
        }
        val files = textFiles(dir).filter { globOk(it.key, g) }
        val out = StringBuilder()
        var count = 0
        if (mode == "symbols") {
            val q = a.optString("pattern", "").trim()
            for ((p, c) in files) {
                val r = symbolRegex(p.substringAfterLast('.', "").lowercase()) ?: continue
                for ((i, l) in c.split("\n").withIndex()) {
                    if (!r.matches(l)) continue
                    if (q.isNotEmpty() && !l.contains(q, true)) continue
                    if (count++ < max) out.append(p).append(':').append(i + 1).append(": ").append(l.trim().take(140)).append('\n')
                }
            }
            return if (count == 0) "No function/class found." else "$count symbols:\n" + cap(out.toString())
        }
        val pattern = if (mode == "todos") "\\b(TODO|FIXME|HACK|XXX)\\b" else a.optString("pattern")
        if (pattern.isBlank()) return "pattern do."
        val re = regexOf(pattern, a.optBoolean("ignore_case", true))
        val ctxN = a.optInt("context", 0).coerceIn(0, 5)
        val filesOnly = a.optBoolean("files_only", false)
        for ((p, c) in files) {
            val ls = c.split("\n")
            var fileHit = false
            var lastShown = -1
            for (i in ls.indices) {
                if (!re.containsMatchIn(ls[i])) continue
                count++
                fileHit = true
                if (filesOnly) break
                if (count > max) continue
                val from = maxOf(maxOf(0, i - ctxN), lastShown + 1)
                if (ctxN > 0 && from > lastShown + 1 && lastShown >= 0) out.append("--\n")
                for (j in from..minOf(ls.size - 1, i + ctxN)) {
                    out.append(p).append(if (j == i) ':' else '-').append(j + 1).append(if (j == i) ": " else "- ").append(ls[j].take(220)).append('\n')
                    lastShown = j
                }
            }
            if (filesOnly && fileHit) out.append(p).append('\n')
        }
        if (count == 0) return "No match: $pattern"
        return (if (filesOnly) "" else "$count match(es)" + (if (count > max) " (first $max shown)" else "") + ":\n") + cap(out.toString())
    }

    // ------------------------------------------------------------------ project_replace

    private fun replace(ctx: Context, dir: File, a: JSONObject): String {
        val pat = a.optString("pattern")
        if (pat.isEmpty()) return "pattern do."
        val repl = a.optString("replacement", "")
        val literal = a.optBoolean("literal", false)
        val dry = a.optBoolean("dry_run", false)
        val re = try {
            Pattern.compile(if (literal) Pattern.quote(pat) else pat, (if (a.optBoolean("ignore_case", false)) Pattern.CASE_INSENSITIVE else 0) or Pattern.MULTILINE)
        } catch (e: Exception) { return "Invalid regex: " + (e.message ?: "").take(120) }
        val rp = if (literal) java.util.regex.Matcher.quoteReplacement(repl) else repl
        val g = a.optString("glob", "")
        val changes = LinkedHashMap<String, Pair<String, Int>>()
        for ((p, c) in textFiles(dir)) {
            if (!globOk(p, g)) continue
            val m = re.matcher(c)
            var n = 0
            while (m.find()) { n++; if (m.end() == m.start() && m.end() >= c.length) break }
            if (n == 0) continue
            val nc = try { re.matcher(c).replaceAll(rp) } catch (e: Exception) { return "Invalid replacement: " + (e.message ?: "").take(120) }
            if (nc != c) changes[p] = Pair(nc, n)
        }
        if (changes.isEmpty()) return "Nothing matched, nothing changed."
        val summary = changes.entries.joinToString("\n") { it.key + ": " + it.value.second + " jagah" }
        if (dry) return "DRY RUN (nothing changed): " + changes.size + " files:\n" + cap(summary)
        snap(ctx, dir)
        for ((p, v) in changes) File(dir, p).writeText(v.first, Charsets.UTF_8)
        done(ctx, dir)
        return "Replaced in " + changes.size + " files:\n" + cap(summary) + "\n(undo: project_history action=undo)"
    }

    // ------------------------------------------------------------------ project_manage

    private fun manage(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val act = a.optString("action", "list_projects").lowercase()
        if (act == "list_projects") {
            val all = Coder.list(ctx)
            if (all.isEmpty()) return NO_PROJECT
            return all.take(40).joinToString("\n") { d ->
                val fs = listFiles(d)
                "- " + Coder.name(d) + "  [folder: " + d.name + "]  " + fs.size + " files"
            }
        }
        val (dir, err) = find(ctx, a)
        if (dir == null) return err
        when (act) {
            "stats" -> {
                val byExt = java.util.TreeMap<String, IntArray>()
                var todo = 0
                for ((p, c) in textFiles(dir)) {
                    val e = p.substringAfterLast('.', "none").lowercase()
                    val x = byExt.getOrPut(e) { IntArray(2) }
                    x[0]++; x[1] += lines(c)
                    todo += Regex("\\b(TODO|FIXME)\\b").findAll(c).count()
                }
                val rows = byExt.entries.sortedByDescending { it.value[1] }.joinToString("\n") { "." + it.key + ": " + it.value[0] + " files, " + it.value[1] + " lines" }
                return "STATS " + Coder.name(dir) + ":\n" + rows + "\nTODO/FIXME: $todo\nCheckpoints: " + checkpoints(ctx, dir).size
            }
            "deps" -> return Deps.run(ctx, JSONObject().put("action", "list")) { Pair(dir, "") }
            "format" -> {
                val p = a.optString("path", "")
                val only = if (p.isBlank()) "" else (cleanPath(p) ?: return "path galat hai.")
                snap(ctx, dir)
                val all = textFiles(dir)
                val real = if (a.optBoolean("simple", false)) null else Linter.format(ctx, all, only)
                val realOk = real != null && real.ok
                val errPaths = (real?.errors ?: emptyList()).map { it.substringBefore(": ") }.toSet()
                val handled = if (realOk) Linter.eligible(all, "format", only).keys - errPaths else emptySet()
                var nReal = 0
                var nBasic = 0
                if (realOk) for ((rp, t) in real!!.formatted) { File(dir, rp).writeText(t, Charsets.UTF_8); nReal++ }
                for ((rp, c) in all) {
                    if (only.isNotBlank() && rp != only) continue
                    if (rp in handled) continue
                    var t = c.replace("\r\n", "\n").split("\n").joinToString("\n") { it.trimEnd() }.trimEnd('\n') + "\n"
                    if (rp.endsWith(".json")) t = try { (if (t.trimStart().startsWith("[")) JSONArray(t).toString(2) else JSONObject(t).toString(2)) + "\n" } catch (e: Exception) { t }
                    if (t != c) { File(dir, rp).writeText(t, Charsets.UTF_8); nBasic++ }
                }
                done(ctx, dir)
                val sb = StringBuilder()
                sb.append("Formatted: ").append(nReal).append(" file(s) with Prettier (js, ts, css, html, json, md) / black (py)")
                if (nBasic > 0) sb.append(", ").append(nBasic).append(" with basic cleanup (trailing spaces, final newline, JSON pretty)")
                sb.append(".")
                if (real != null && !realOk) sb.append("\nReal formatters did not run: ").append(real.note).append(" Only basic cleanup was done.")
                if (real != null && real.errors.isNotEmpty()) sb.append("\nCould not format (probably a syntax error, fix it first): ").append(real.errors.joinToString("; ").take(500))
                sb.append("\n(undo: project_history action=undo)")
                return sb.toString()
            }
            "new_file", "touch" -> {
                val p = cleanPath(a.optString("path")) ?: return "path do."
                if (File(dir, p).exists()) return "$p already exists."
                snap(ctx, dir); Coder.writeFile(dir, p, ""); done(ctx, dir); return "Created empty $p"
            }
            "move_file", "rename_file" -> {
                val from = cleanPath(a.optString("path")) ?: return "path do."
                val to = cleanPath(a.optString("to")) ?: return "give a 'to' (new path)."
                val src = File(dir, from)
                if (!src.exists()) return "Not found: $from"
                val dst = File(dir, to)
                if (dst.exists()) return "$to already exists."
                snap(ctx, dir)
                dst.parentFile?.mkdirs()
                if (!src.renameTo(dst)) { src.copyRecursively(dst, false); src.deleteRecursively() }
                done(ctx, dir)
                return "Moved $from -> $to (check imports/links yourself: project_search + project_check)."
            }
            "delete_file" -> {
                val p = cleanPath(a.optString("path")) ?: return "path do."
                val f = File(dir, p)
                if (!f.exists()) return "Not found: $p"
                if (!confirm(Confirm.msg("delete", "Delete " + p + " from project " + Coder.name(dir) + "?", "Undo: project_history action=undo"))) return "The user declined."
                snap(ctx, dir)
                f.deleteRecursively()
                done(ctx, dir)
                return "Deleted $p"
            }
            "rename_project" -> {
                val to = a.optString("to").trim()
                if (to.isEmpty()) return "give a 'to' (new name)."
                Coder.rename(dir, to); return "The project is now named: " + to
            }
            "delete_project" -> {
                if (!confirm(Confirm.msg("delete", "Delete the whole project " + Coder.name(dir) + "?", listFiles(dir).size.toString() + " files. This cannot be undone."))) return "The user declined."
                Coder.delete(dir); return "Project deleted."
            }
            else -> return "action: list_projects, stats, deps, format, new_file, move_file, delete_file, rename_project ya delete_project."
        }
    }

    // ------------------------------------------------------------------ project_check

    private fun check(ctx: Context, confirm: (String) -> Boolean, dir: File, a: JSONObject): String {
        val act = a.optString("action", "lint").lowercase()
        val files = textFiles(dir)
        when (act) {
            "lint" -> {
                val l = Coder.lint(files).trim()
                val base = if (l.isEmpty()) "Built-in lint clean: no problems found (brackets, JSON, HTML ids/links, stubs)." else "Built-in lint found this:\n" + cap(l)
                val real = if (a.optBoolean("simple", false)) "" else Linter.lintReport(ctx, files)
                return if (real.isEmpty()) base else base + "\n\n" + cap(real, 6000)
            }
            "run" -> {
                if (Runner.entry(dir) == null && PyRun.entry(dir) == null) return RunCode.hint(dir, files) ?: "No runnable entry found (needs index.html, main.py or a main file such as main.kt, Main.java, main.go, main.rs). Run project_check action=lint."
                val r = Runner.check(ctx, dir)
                return if (r.isBlank()) "Project ran clean: no errors (or it could not be tested because of an external package)." else "Chalane par masle:\n" + cap(r)
            }
            "test", "coverage" -> {
                val hasPy = PyTests.testFiles(files.keys).isNotEmpty()
                val hasJs = RunTests.jsTestFiles(files.keys).isNotEmpty()
                if (act == "coverage" && !hasJs) return "Coverage needs JavaScript tests (tests/name.test.js). " + RunTests.noTests(files.keys)
                val py = if (hasPy && act == "test") pythonTests(ctx, dir) else ""
                val js = if (hasJs || !hasPy) RunTests.run(ctx, confirm, files, a) else ""
                return listOf(py, js).filter { it.isNotEmpty() }.joinToString("\n\n")
            }
            else -> return "action: lint, run, test ya coverage."
        }
    }

    /** Python unittest run on Pyodide. Every test file is loaded by its path, so tests/ folders without __init__.py are found too. */
    private fun pythonTests(ctx: Context, dir: File): String = cap(PyTests.report(PyTests.run(ctx, dir)), 9000)

    // ------------------------------------------------------------------ project_history

    private fun cpRoot(ctx: Context, dir: File) = File(File(ctx.filesDir, "checkpoints"), dir.name).also { it.mkdirs() }

    private class Cp(val id: Int, val msg: String, val time: Long, val files: JSONObject)

    private fun checkpoints(ctx: Context, dir: File): List<Cp> =
        (cpRoot(ctx, dir).listFiles()?.filter { it.name.endsWith(".json") } ?: emptyList()).mapNotNull { f ->
            try {
                val o = JSONObject(f.readText(Charsets.UTF_8))
                Cp(o.getInt("id"), o.optString("msg"), o.optLong("t"), o.getJSONObject("files"))
            } catch (e: Exception) { null }
        }.sortedBy { it.id }

    private fun diffMaps(old: Map<String, String>, now: Map<String, String>): String {
        val sb = StringBuilder()
        for ((p, c) in now) {
            val o = old[p]
            if (o == null) { sb.append("+++ ").append(p).append("  (new, ").append(lines(c)).append(" lines)\n"); continue }
            if (o == c) continue
            val d = Coder.lineDiff(o.split("\n"), c.split("\n"))
            sb.append("~~~ ").append(p).append("  +").append(d.count { it.startsWith("+ ") }).append(" -").append(d.count { it.startsWith("- ") }).append('\n')
            for (l in d.filter { it.startsWith("+ ") || it.startsWith("- ") }.take(40)) sb.append("    ").append(l.take(180)).append('\n')
        }
        for (p in old.keys) if (!now.containsKey(p)) sb.append("--- ").append(p).append("  (deleted)\n")
        return sb.toString().trim()
    }

    private fun history(ctx: Context, dir: File, a: JSONObject): String {
        val act = a.optString("action", "diff").lowercase()
        when (act) {
            "diff" -> {
                val ch = Coder.diffs(ctx, dir)
                if (ch.isEmpty()) return "No changes since the last snapshot."
                val sb = StringBuilder()
                for (c in ch) {
                    sb.append(if (c.status == "new") "+++ " else if (c.status == "deleted") "--- " else "~~~ ").append(c.path).append("  +").append(c.add).append(" -").append(c.del).append('\n')
                    for (l in c.diff.filter { it.startsWith("+ ") || it.startsWith("- ") }.take(40)) sb.append("    ").append(l.take(180)).append('\n')
                }
                return cap(sb.toString())
            }
            "undo" -> return if (Coder.undo(ctx, dir)) { done(ctx, dir); "Reverted the last change." } else "No snapshot to revert to."
            "checkpoint", "commit" -> {
                val files = textFiles(dir)
                val list = checkpoints(ctx, dir)
                val id = (list.maxOfOrNull { it.id } ?: 0) + 1
                val o = JSONObject()
                for ((k, v) in files) o.put(k, v)
                val msg = a.optString("message", a.optString("name", "")).trim().ifEmpty { "checkpoint $id" }.take(100)
                File(cpRoot(ctx, dir), "$id.json").writeText(JSONObject().put("id", id).put("msg", msg).put("t", System.currentTimeMillis()).put("files", o).toString(), Charsets.UTF_8)
                // keep the newest 30
                list.sortedBy { it.id }.dropLast(29).forEach { File(cpRoot(ctx, dir), it.id.toString() + ".json").delete() }
                return "Checkpoint #$id saved: " + msg + " (" + files.size + " files)"
            }
            "log" -> {
                val l = checkpoints(ctx, dir)
                if (l.isEmpty()) return "No checkpoint. Create one with action=checkpoint."
                val f = java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.ENGLISH)
                return l.reversed().joinToString("\n") { "#" + it.id + "  " + f.format(java.util.Date(it.time)) + "  " + it.msg + "  (" + it.files.length() + " files)" }
            }
            "compare", "restore" -> {
                val id = a.optInt("id", -1)
                val cp = checkpoints(ctx, dir).let { l -> if (id >= 0) l.firstOrNull { it.id == id } else l.lastOrNull() } ?: return "No such checkpoint. See action=log."
                val old = LinkedHashMap<String, String>()
                for (k in cp.files.keys()) old[k] = cp.files.getString(k)
                if (act == "compare") {
                    val d = diffMaps(old, textFiles(dir))
                    return "Checkpoint #" + cp.id + " (" + cp.msg + ") until now:\n" + (if (d.isEmpty()) "no difference." else cap(d))
                }
                Coder.snapshot(ctx, dir)
                val now = textFiles(dir)
                for (p in now.keys) if (!old.containsKey(p)) File(dir, p).delete()
                for ((p, c) in old) Coder.writeFile(dir, p, c)
                done(ctx, dir)
                return "Project checkpoint #" + cp.id + " (" + cp.msg + ") restored. (The earlier state can be recovered with undo.)"
            }
            else -> return "action: diff, undo, checkpoint, log, compare ya restore."
        }
    }

    // ------------------------------------------------------------------ project_template

    private val TEMPLATES: Map<String, List<Pair<String, String>>> = mapOf(
        "web" to listOf(
            "index.html" to "<!doctype html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  <title>My App</title>\n  <link rel=\"stylesheet\" href=\"style.css\">\n</head>\n<body>\n  <main id=\"app\">\n    <h1>My App</h1>\n    <button id=\"btn\">Click me</button>\n    <p id=\"out\"></p>\n  </main>\n  <script src=\"script.js\"></script>\n</body>\n</html>\n",
            "style.css" to ":root { --bg: #faf9f5; --ink: #1f1e1d; --accent: #c96442; }\n* { box-sizing: border-box; }\nbody { margin: 0; font-family: system-ui, sans-serif; background: var(--bg); color: var(--ink); }\nmain { max-width: 640px; margin: 0 auto; padding: 24px 16px; }\nbutton { background: var(--accent); color: #fff; border: 0; border-radius: 12px; padding: 10px 18px; font-size: 16px; }\n",
            "script.js" to "const btn = document.getElementById('btn');\nconst out = document.getElementById('out');\nlet n = 0;\nbtn.addEventListener('click', () => {\n  n += 1;\n  out.textContent = 'Clicked ' + n + ' times';\n});\n"
        ),
        "python" to listOf(
            "main.py" to "def greet(name):\n    return 'Hello, ' + name + '!'\n\n\ndef main():\n    print(greet('world'))\n\n\nif __name__ == '__main__':\n    main()\n",
            "test_main.py" to "import unittest\nfrom main import greet\n\n\nclass GreetTest(unittest.TestCase):\n    def test_greet(self):\n        self.assertEqual(greet('Ali'), 'Hello, Ali!')\n\n\nif __name__ == '__main__':\n    unittest.main()\n",
            "requirements.txt" to "",
            "README.md" to "# Python project\n\nRun: `python main.py`\n\nTest: `python -m unittest`\n"
        ),
        "node" to listOf(
            "package.json" to "{\n  \"name\": \"my-app\",\n  \"version\": \"1.0.0\",\n  \"main\": \"index.js\",\n  \"scripts\": {\n    \"start\": \"node index.js\",\n    \"test\": \"node test.js\"\n  }\n}\n",
            "index.js" to "function add(a, b) {\n  return a + b;\n}\n\nmodule.exports = { add };\n\nif (require.main === module) {\n  console.log('2 + 3 =', add(2, 3));\n}\n",
            "test.js" to "const assert = require('assert');\nconst { add } = require('./index');\n\nassert.strictEqual(add(2, 3), 5);\nconsole.log('all tests passed');\n",
            "README.md" to "# Node project\n\nRun: `npm start`\n\nTest: `npm test`\n"
        ),
        "pwa" to listOf(
            "index.html" to "<!doctype html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  <meta name=\"theme-color\" content=\"#c96442\">\n  <link rel=\"manifest\" href=\"manifest.json\">\n  <title>My PWA</title>\n</head>\n<body>\n  <h1>My PWA</h1>\n  <script>\n    if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');\n  </script>\n</body>\n</html>\n",
            "manifest.json" to "{\n  \"name\": \"My PWA\",\n  \"short_name\": \"PWA\",\n  \"start_url\": \"index.html\",\n  \"display\": \"standalone\",\n  \"background_color\": \"#faf9f5\",\n  \"theme_color\": \"#c96442\",\n  \"icons\": []\n}\n",
            "sw.js" to "const CACHE = 'v1';\nconst FILES = ['index.html', 'manifest.json'];\nself.addEventListener('install', e => e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES))));\nself.addEventListener('fetch', e => e.respondWith(caches.match(e.request).then(r => r || fetch(e.request))));\n"
        ),
        "readme" to listOf("README.md" to "# Project name\n\nWhat it does in one line.\n\n## Run\n\n```\n...\n```\n\n## Test\n\n```\n...\n```\n\n## Structure\n\n- `file` - what it is for\n"),
        "gitignore" to listOf(".gitignore" to "node_modules/\n__pycache__/\n*.pyc\n.env\n.DS_Store\nbuild/\ndist/\n*.log\n"),
        "dockerfile" to listOf("Dockerfile" to "FROM python:3.12-slim\nWORKDIR /app\nCOPY requirements.txt .\nRUN pip install --no-cache-dir -r requirements.txt\nCOPY . .\nCMD [\"python\", \"main.py\"]\n"),
        "github_actions" to listOf(".github/workflows/ci.yml" to "name: CI\non: [push, pull_request]\njobs:\n  test:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-python@v5\n        with:\n          python-version: '3.12'\n      - run: python -m unittest\n")
    )

    private fun template(ctx: Context, a: JSONObject): String {
        val t0 = a.optString("template", "").trim().lowercase().replace('-', '_').replace(' ', '_')
        val t = StarterTemplates.ALIASES[t0] ?: t0
        val tpl = TEMPLATES[t] ?: StarterTemplates.ALL[t]
            ?: return "template chuno: " + (TEMPLATES.keys + StarterTemplates.ALL.keys).joinToString(", ")
        val overwrite = a.optBoolean("overwrite", false)
        val n = a.optString("project", "").trim()
        val existing = if (n.isEmpty()) null else find(ctx, a).first
        val dir: File
        val added = ArrayList<String>()
        if (existing != null) {
            dir = existing
            snap(ctx, dir)
        } else {
            val first = tpl.first()
            dir = Coder.fileProject(ctx, first.first.substringAfterLast('/'), "")
            if (n.isNotEmpty()) Coder.rename(dir, n)
            File(dir, first.first.substringAfterLast('/')).delete()
        }
        for ((p, c) in tpl) {
            if (File(dir, p).exists() && !overwrite) continue
            if (Coder.writeFile(dir, p, c)) added.add(p)
        }
        done(ctx, dir)
        return "Template '$t' project '" + Coder.name(dir) + "': added: " + (if (added.isEmpty()) "nothing new (files already existed, pass overwrite=true)" else added.joinToString(", "))
    }
}
