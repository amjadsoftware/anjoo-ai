package com.anjoo.assistant

import java.util.Locale
import kotlin.math.ln

/**
 * Secret scanner for Code Studio projects (project_engineering action=secrets, and part of security / audit).
 *
 * What it does (all offline, on the project's working files):
 *  - provider-specific key formats (AWS, GitHub, Google, OpenAI/Anthropic, Slack, Stripe, Telegram, SendGrid, npm ...)
 *  - private-key blocks, passwords inside URLs, JWTs
 *  - generic "name = value" assignments (api_key, secret, password, token ...) judged by value entropy, so
 *    placeholders, env lookups and plain words are not reported
 *  - config files too (.env, .properties, .yml, .toml, .ini ...), not only source code
 *  - secret-type file names (.env, *.jks, id_rsa ...)
 *
 * It never returns or prints a secret value: a hit carries only a masked form.
 * Put `secret-scan:ignore` in a comment on a line to silence a known false positive.
 * Limits: working tree only (not git history), heuristic (can miss or over-report).
 */
object SecretScan {
    enum class Sev(val rank: Int) { CRITICAL(3), HIGH(2), MEDIUM(1) }

    data class Hit(val sev: Sev, val kind: String, val path: String, val line: Int, val masked: String)

    private class Rule(val kind: String, val sev: Sev, val re: Regex, val reveal: Boolean = true, val ok: (String) -> Boolean = { true })

    private val rules = listOf(
        Rule("private key", Sev.CRITICAL, Regex("""-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP |ENCRYPTED )?PRIVATE KEY(?: BLOCK)?-----"""), reveal = false),
        Rule("AWS access key", Sev.CRITICAL, Regex("""\b(?:AKIA|ASIA)[0-9A-Z]{16}\b""")),
        Rule("GitHub token", Sev.CRITICAL, Regex("""\bgh[pousr]_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{40,}""")),
        Rule("Google API key", Sev.HIGH, Regex("""\bAIza[0-9A-Za-z_-]{35}""")),
        Rule("AI provider key", Sev.CRITICAL, Regex("""\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{32,}""")) { v -> v.any { it.isDigit() } },
        Rule("Slack token", Sev.CRITICAL, Regex("""\bxox[baprs]-[A-Za-z0-9-]{10,}""")),
        Rule("Slack webhook", Sev.HIGH, Regex("""https://hooks\.slack\.com/services/T[A-Za-z0-9]+/B[A-Za-z0-9]+/[A-Za-z0-9]{20,}"""), reveal = false),
        Rule("Stripe live key", Sev.CRITICAL, Regex("""\b[sr]k_live_[A-Za-z0-9]{20,}""")),
        Rule("SendGrid key", Sev.CRITICAL, Regex("""\bSG\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{30,}""")),
        Rule("Twilio API key", Sev.HIGH, Regex("""\bSK[0-9a-fA-F]{32}\b""")),
        Rule("Telegram bot token", Sev.CRITICAL, Regex("""\b[0-9]{8,10}:AA[A-Za-z0-9_-]{33}\b"""), reveal = false),
        Rule("npm token", Sev.CRITICAL, Regex("""\bnpm_[A-Za-z0-9]{36}\b""")),
        Rule("Hugging Face token", Sev.HIGH, Regex("""\bhf_[A-Za-z0-9]{34,}\b""")),
        Rule("Mailgun key", Sev.HIGH, Regex("""\bkey-[0-9a-f]{32}\b""")),
        Rule("JWT", Sev.MEDIUM, Regex("""\beyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"""), reveal = false)
    )

    private const val NAME_WORDS = """(?:secret|passw(?:or)?d|pwd|token|api[_-]?key|apikey|access[_-]?key|auth[_-]?key|credential|private[_-]?key)"""
    private val quotedAssign = Regex("""(?i)([A-Za-z0-9_.\-]*$NAME_WORDS[A-Za-z0-9_.\-]*)["']?\s*[:=]\s*["']([^"'\s]{12,})["']""")
    private val bareAssign = Regex("""(?i)^\s*([A-Za-z0-9_.\-]*$NAME_WORDS[A-Za-z0-9_.\-]*)\s*[:=]\s*([^\s"'#]{12,})\s*(?:#.*)?$""")
    private val urlPassword = Regex("""[A-Za-z][A-Za-z0-9+.\-]*://[^\s/:@"']+:([^\s/@"']{3,})@[^\s/"']+""")

    private val placeholder = Regex(
        """(?i)(your[_ -]?|change[_ -]?me|replace[_ -]?me|example|sample|placeholder|dummy|fake|test[_ -]?key|x{4,}|\*{3,}|\.{4,}|<[^>]+>|\$\{|\{\{|%\(|todo|redacted|insert[_ -]?|enter[_ -]?)"""
    )
    private val dottedIdentifier = Regex("""^[A-Za-z_][A-Za-z0-9_]*(?:\.[A-Za-z_][A-Za-z0-9_]*)+$""")
    private val lettersOnly = Regex("""^[A-Za-z]+$""")

    private val secretFileName = Regex("""(?i)(^|/)(\.env(\.[^/]*)?|keys\.properties|signing\.properties|local\.properties|[^/]*\.(jks|keystore|p12|pfx|pem)|id_rsa|id_ed25519)$""")
    private val safeName = Regex("""(?i)(example|sample|template|\.dist$)""")
    private val skipFile = Regex("""(?i)(^|/)(package-lock\.json|npm-shrinkwrap\.json|yarn\.lock|pnpm-lock\.yaml|poetry\.lock|cargo\.lock|go\.sum|composer\.lock|pubspec\.lock|gradle\.lockfile)$|\.min\.(js|css)$|\.map$""")
    private val skipDir = Regex("""(^|/)(node_modules|vendor|\.git|build|dist|\.gradle)/""")
    private val configExt = setOf("env", "properties", "ini", "cfg", "conf", "yml", "yaml", "toml")

    private const val IGNORE_MARK = "secret-scan:ignore"
    private const val MAX_LINE = 4000
    private const val MAX_FILE = 1_500_000

    fun entropy(s: String): Double {
        if (s.isEmpty()) return 0.0
        val counts = HashMap<Char, Int>()
        for (c in s) counts[c] = (counts[c] ?: 0) + 1
        var h = 0.0
        for (n in counts.values) {
            val p = n.toDouble() / s.length
            h -= p * (ln(p) / ln(2.0))
        }
        return h
    }

    /** True when [value] looks like a real credential rather than a placeholder, a lookup or a plain word. */
    internal fun looksReal(value: String): Boolean {
        if (value.length < 12) return false
        if (placeholder.containsMatchIn(value)) return false
        val first = value[0]
        if (first == '$' || first == '@' || first == '%' || first == '{' || first == '<' || first == '(' || first == '[' || first == '/' || first == '.') return false
        if (value.startsWith("http://") || value.startsWith("https://")) return false
        if (value.contains('(') || value.contains(')') || value.contains("::")) return false
        if (dottedIdentifier.matches(value) && value.none { it.isDigit() }) return false
        if (lettersOnly.matches(value)) return false
        if (value.toSet().size < 6) return false
        return entropy(value) >= 3.0
    }

    private fun mask(value: String, reveal: Boolean): String =
        if (reveal && value.length >= 8) value.take(4) + "… (" + value.length + " chars, value redacted)"
        else "(" + value.length + " chars, value redacted)"

    fun isSecretFileName(path: String): Boolean =
        secretFileName.containsMatchIn(path) && !safeName.containsMatchIn(path.substringAfterLast('/'))

    private fun skipped(path: String): Boolean {
        val p = path.replace('\\', '/')
        return skipDir.containsMatchIn(p) || skipFile.containsMatchIn(p) || safeName.containsMatchIn(p.substringAfterLast('/'))
    }

    /** Hits in one file. Binary files: pass null text to check the file name only. */
    fun scan(path: String, text: String?): List<Hit> {
        val p = path.replace('\\', '/')
        if (skipped(p)) return emptyList()
        val out = ArrayList<Hit>()
        if (isSecretFileName(p)) out.add(Hit(Sev.HIGH, "secret-type file", p, 1, "(file name matches a secret file type)"))
        if (text == null || text.length > MAX_FILE) return out

        val name = p.substringAfterLast('/').lowercase(Locale.ROOT)
        val ext = name.substringAfterLast('.', "")
        val config = ext in configExt || name.startsWith(".env")
        val seen = HashSet<String>()

        for ((index, raw) in text.lineSequence().withIndex()) {
            if (raw.length > MAX_LINE || raw.isBlank() || raw.contains(IGNORE_MARK)) continue
            val number = index + 1
            var providerHit = false

            for (r in rules) {
                for (m in r.re.findAll(raw)) {
                    if (!r.ok(m.value)) continue
                    providerHit = true
                    if (seen.add(r.kind + ":" + number)) out.add(Hit(r.sev, r.kind, p, number, mask(m.value, r.reveal)))
                }
            }
            for (m in urlPassword.findAll(raw)) {
                val pw = m.groupValues[1]
                if (placeholder.containsMatchIn(pw) || pw.equals("password", true) || pw.equals("pass", true)) continue
                providerHit = true
                if (seen.add("url:$number")) out.add(Hit(Sev.HIGH, "password inside URL", p, number, mask(pw, false)))
            }
            if (providerHit) continue

            val m = quotedAssign.find(raw) ?: if (config) bareAssign.find(raw) else null
            if (m != null) {
                val value = m.groupValues[2]
                if (looksReal(value) && seen.add("generic:$number")) {
                    out.add(Hit(Sev.HIGH, "key/password assigned in code", p, number, mask(value, false)))
                }
            }
        }
        return out
    }

    fun scanAll(files: Map<String, String>): List<Hit> {
        val all = ArrayList<Hit>()
        for ((path, text) in files.toSortedMap()) all.addAll(scan(path, text))
        return all.sortedWith(compareByDescending<Hit> { it.sev.rank }.thenBy { it.path }.thenBy { it.line })
    }

    private fun fixFor(h: Hit): String = when (h.kind) {
        "secret-type file" -> "Keep it out of the project and out of git (.gitignore); share a sanitized .example file instead."
        "private key" -> "Remove the key from the project, revoke/replace it, and load it from a secure store."
        else -> "Move it to an environment variable or secret store, then revoke and re-issue it if it was ever committed, pushed or shared."
    }

    fun report(project: String, files: Map<String, String>, limit: Int = 60): String {
        val hits = scanAll(files)
        val c = hits.count { it.sev == Sev.CRITICAL }
        val h = hits.count { it.sev == Sev.HIGH }
        val m = hits.count { it.sev == Sev.MEDIUM }
        return buildString {
            append("SECRET SCAN: ").append(project).append('\n')
            append("Files scanned: ").append(files.size).append(" · Hits: ").append(hits.size)
                .append(" (CRITICAL ").append(c).append(", HIGH ").append(h).append(", MEDIUM ").append(m).append(")\n")
            if (hits.isEmpty()) {
                append("\nNo secrets found by the enabled patterns and entropy checks.\n")
            } else {
                append('\n')
                for (x in hits.take(limit)) {
                    append('[').append(x.sev.name).append("] ").append(x.kind).append('\n')
                    append("  ").append(x.path).append(':').append(x.line).append("  ").append(x.masked).append('\n')
                    append("  Fix: ").append(fixFor(x)).append("\n\n")
                }
                if (hits.size > limit) append("... ").append(hits.size - limit).append(" more hits not shown.\n")
                append("A secret that was ever committed, pushed or shared must be treated as leaked: deleting it from the file is not enough, revoke and re-issue it.\n")
            }
            append("\nLimits: working files only (git history is not scanned); pattern and entropy heuristics can miss secrets or flag harmless values (silence one with a comment containing secret-scan:ignore). Secret values are never printed.")
        }.trim()
    }
}
