package com.anjoo.assistant

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * In-memory book of token usage: day -> "Company|model" -> [input tokens, output tokens, calls].
 * Pure Kotlin (no Android), so it can be unit tested. Prices are only what the user typed in: nothing is guessed.
 */
class UsageBook {
    class Row(var input: Long = 0, var output: Long = 0, var calls: Long = 0)

    private val days = LinkedHashMap<String, LinkedHashMap<String, Row>>()

    @Synchronized fun record(day: String, key: String, input: Int, output: Int) {
        val row = days.getOrPut(day) { LinkedHashMap() }.getOrPut(key) { Row() }
        row.input += input.coerceAtLeast(0); row.output += output.coerceAtLeast(0); row.calls += 1
        // Keep about two months of days.
        while (days.size > 62) days.remove(days.keys.minOrNull() ?: break)
    }

    /** Totals per "Company|model" for every day that starts with [dayPrefix] (a whole day "2026-11-01" or a month "2026-11"). */
    @Synchronized fun totals(dayPrefix: String): Map<String, Row> {
        val out = LinkedHashMap<String, Row>()
        for ((d, rows) in days) if (d.startsWith(dayPrefix)) for ((k, r) in rows) {
            val t = out.getOrPut(k) { Row() }
            t.input += r.input; t.output += r.output; t.calls += r.calls
        }
        return out
    }

    @Synchronized fun tokensOn(day: String): Long = totals(day).values.sumOf { it.input + it.output }

    @Synchronized fun toJson(): String {
        val o = JSONObject()
        for ((d, rows) in days) {
            val dj = JSONObject()
            for ((k, r) in rows) dj.put(k, org.json.JSONArray().put(r.input).put(r.output).put(r.calls))
            o.put(d, dj)
        }
        return o.toString()
    }

    @Synchronized fun load(json: String) {
        days.clear()
        try {
            val o = JSONObject(json)
            for (d in o.keys().asSequence().sorted()) {
                val dj = o.getJSONObject(d)
                val m = LinkedHashMap<String, Row>()
                for (k in dj.keys()) { val a = dj.getJSONArray(k); m[k] = Row(a.optLong(0), a.optLong(1), a.optLong(2)) }
                days[d] = m
            }
        } catch (_: Exception) { }
    }

    companion object {
        /** Price per one million tokens, typed in by the user. Returns null when no price is known for this model. */
        fun cost(prices: Map<String, Pair<Double, Double>>, model: String, input: Long, output: Long): Double? {
            val m = model.lowercase(Locale.ROOT)
            val hit = prices.entries.filter { m.contains(it.key.lowercase(Locale.ROOT)) }.maxByOrNull { it.key.length } ?: return null
            return input / 1_000_000.0 * hit.value.first + output / 1_000_000.0 * hit.value.second
        }

        /** Lines "model-part,inputPerMillion,outputPerMillion". Bad lines are ignored. */
        fun parsePrices(text: String): Map<String, Pair<Double, Double>> {
            val out = LinkedHashMap<String, Pair<Double, Double>>()
            for (line in text.lines()) {
                val p = line.split(',').map { it.trim() }
                if (p.size < 3 || p[0].isEmpty()) continue
                val a = p[1].toDoubleOrNull() ?: continue
                val b = p[2].toDoubleOrNull() ?: continue
                if (a >= 0 && b >= 0) out[p[0]] = a to b
            }
            return out
        }
    }
}

/** App-wide token ledger: every provider call reports its token counts here (when the provider returns them). */
object TokenLedger {
    private val book = UsageBook()
    @Volatile private var app: Context? = null
    @Volatile private var loaded = false
    @Volatile private var alertedDay = ""
    private val dayFmt get() = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    private fun file(ctx: Context) = File(ctx.filesDir, "token_usage.json")

    /** Call once with any context (the chat screen and the background job do). */
    fun bind(ctx: Context) {
        val a = ctx.applicationContext
        app = a
        if (!loaded) synchronized(this) {
            if (!loaded) { try { if (file(a).isFile) book.load(file(a).readText()) } catch (_: Exception) { }; loaded = true }
        }
    }

    fun record(company: String, model: String, input: Int, output: Int) {
        if (input <= 0 && output <= 0) return
        val a = app
        val day = dayFmt.format(Date())
        book.record(day, "$company|$model", input, output)
        if (a != null) {
            try { file(a).writeText(book.toJson()) } catch (_: Exception) { }
            checkBudget(a, day)
        }
    }

    /** Reads usage from a Gemini reply (usageMetadata); thinking tokens count as output. */
    fun recordGemini(model: String, reply: JSONObject) {
        val u = reply.optJSONObject("usageMetadata") ?: return
        record("Google", model, u.optInt("promptTokenCount"), u.optInt("candidatesTokenCount") + u.optInt("thoughtsTokenCount"))
        recordCached(u.optInt("cachedContentTokenCount"))
    }

    /** Input tokens the company served from its prompt cache (billed cheaper). Kept per day, only for the report. */
    fun recordCached(tokens: Int) {
        val a = app ?: return
        if (tokens <= 0) return
        val k = "tokCached_" + dayFmt.format(Date())
        val p = prefs(a)
        p.edit().putLong(k, p.getLong(k, 0L) + tokens).apply()
    }

    /** Reads usage from an OpenAI-style (prompt_tokens) or Anthropic-style (input_tokens) reply. */
    fun recordOpenAiOrAnthropic(company: String, model: String, reply: JSONObject) {
        val u = reply.optJSONObject("usage") ?: return
        val cacheRead = u.optInt("cache_read_input_tokens", u.optJSONObject("prompt_tokens_details")?.optInt("cached_tokens") ?: 0)
        val cacheWrite = u.optInt("cache_creation_input_tokens", 0)
        val baseIn = u.optInt("prompt_tokens", u.optInt("input_tokens"))
        // Anthropic reports the cached part separately from input_tokens; OpenAI's prompt_tokens already includes it.
        val input = if (u.has("input_tokens") && !u.has("prompt_tokens")) baseIn + cacheRead + cacheWrite else baseIn
        record(company, model, input, u.optInt("completion_tokens", u.optInt("output_tokens")))
        recordCached(cacheRead)
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    fun dailyBudget(ctx: Context): Long = prefs(ctx).getLong("tokBudgetDay", 0L)
    fun setDailyBudget(ctx: Context, tokens: Long) { prefs(ctx).edit().putLong("tokBudgetDay", tokens.coerceAtLeast(0)).apply() }
    fun prices(ctx: Context): Map<String, Pair<Double, Double>> = UsageBook.parsePrices(prefs(ctx).getString("tokPrices", "").orEmpty())
    fun pricesText(ctx: Context): String = prefs(ctx).getString("tokPrices", "").orEmpty()
    fun setPricesText(ctx: Context, text: String) { prefs(ctx).edit().putString("tokPrices", text).apply() }

    /** A soft alert (a notification) once per day when the daily budget is passed. Requests are never blocked. */
    private fun checkBudget(ctx: Context, day: String) {
        val budget = dailyBudget(ctx)
        if (budget <= 0 || alertedDay == day) return
        val used = book.tokensOn(day)
        if (used >= budget) {
            alertedDay = day
            try { AlertService.post(ctx, "Today's token limit has been passed", "$used tokens used today (your limit is $budget). Nothing stopped; this is just a reminder.") } catch (_: Exception) { }
        }
    }

    /** Read-only totals per "Company|model" for a day ("2026-11-07") or a month ("2026-11"). Used by the Operations dashboard. */
    fun totalsFor(ctx: Context, dayPrefix: String): Map<String, UsageBook.Row> { bind(ctx); return book.totals(dayPrefix) }

    /** The last [n] days, oldest first: Triple(day, tokens, calls). Days with no record are 0. */
    fun recentDays(ctx: Context, n: Int): List<Triple<String, Long, Long>> {
        bind(ctx)
        val out = ArrayList<Triple<String, Long, Long>>()
        for (i in (n - 1) downTo 0) {
            val cal = java.util.Calendar.getInstance()
            cal.add(java.util.Calendar.DAY_OF_YEAR, -i)
            val day = dayFmt.format(cal.time)
            out.add(Triple(day, book.tokensOn(day), book.totals(day).values.sumOf { it.calls }))
        }
        return out
    }

    fun cachedTokensOn(ctx: Context, day: String): Long = prefs(ctx).getLong("tokCached_" + day, 0L)

    private fun fmt(n: Long): String = when {
        n >= 1_000_000 -> String.format(Locale.US, "%.2fM", n / 1_000_000.0)
        n >= 1_000 -> String.format(Locale.US, "%.1fk", n / 1_000.0)
        else -> n.toString()
    }

    private fun section(ctx: Context, title: String, prefix: String, prices: Map<String, Pair<Double, Double>>): String {
        val rows = book.totals(prefix).entries.sortedByDescending { it.value.input + it.value.output }
        if (rows.isEmpty()) return "$title: no records yet.\n"
        val sb = StringBuilder(title).append(":\n")
        var total = 0L; var cost = 0.0; var allKnown = true
        for ((k, r) in rows) {
            val model = k.substringAfter('|'); val company = k.substringBefore('|')
            total += r.input + r.output
            val c = UsageBook.cost(prices, model, r.input, r.output)
            if (c == null) allKnown = false else cost += c
            sb.append("• ").append(company).append(" · ").append(model).append(": ").append(r.calls).append(" call, ")
                .append(fmt(r.input)).append(" in / ").append(fmt(r.output)).append(" out")
                .append(if (c != null) String.format(Locale.US, " ≈ $%.4f", c) else "").append('\n')
        }
        sb.append("Total: ").append(fmt(total)).append(" token")
        sb.append(if (prices.isEmpty()) ", cost: unknown (no price entered)" else if (allKnown) String.format(Locale.US, ", cost ≈ $%.4f", cost) else String.format(Locale.US, ", cost ≥ $%.4f (some models have no price entered)", cost))
        return sb.append('\n').toString()
    }

    /** Text report for the settings dialog. */
    fun report(ctx: Context): String {
        bind(ctx)
        val now = Date()
        val day = dayFmt.format(now)
        val month = day.substring(0, 7)
        val prices = prices(ctx)
        val budget = dailyBudget(ctx)
        val sb = StringBuilder()
        sb.append(section(ctx, "Today", day, prices)).append('\n').append(section(ctx, "This month", month, prices))
        sb.append("\nCached input today: ").append(fmt(prefs(ctx).getLong("tokCached_" + day, 0L))).append(" tokens (served from the company's prompt cache, billed cheaper)")
        sb.append("\nDaily token limit: ").append(if (budget > 0) fmt(budget) + " (" + fmt(book.tokensOn(day)) + " used today)" else "not set")
        sb.append("\n\nNote: only the tokens the company reports in its reply are counted. Some replies (such as live voice) are not included. Prices are only the ones you entered; the app assumes no price itself.")
        return sb.toString()
    }
}
