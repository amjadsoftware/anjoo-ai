package com.anjoo.assistant

import android.content.Context
import java.io.File
import java.util.Locale

/** Pure helpers for the Memory overview (no Android), so they can be unit tested on the JVM. */
object MemoryOverviewLogic {
    fun size(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
    }

    fun percent(part: Int, total: Int): Int = if (total <= 0) 0 else (part.toLong() * 100 / total).toInt().coerceIn(0, 100)

    /** "3 facts · 2 preferences · 1 task" from the stored kinds (fact, pref, task, person). Empty kinds are left out. */
    fun kindSummary(items: List<MemItem>): String {
        val names = listOf("fact" to ("fact" to "facts"), "pref" to ("preference" to "preferences"), "task" to ("task" to "tasks"), "person" to ("person" to "people"))
        val parts = ArrayList<String>()
        for ((kind, label) in names) {
            val n = items.count { it.kind == kind }
            if (n > 0) parts.add("$n " + (if (n == 1) label.first else label.second))
        }
        val known = names.map { it.first }.toSet()
        val other = items.count { it.kind !in known }
        if (other > 0) parts.add("$other other")
        return parts.joinToString(" · ")
    }
}

/**
 * The Memory overview: one card per memory layer with real counts read from the app's own stores, plus the size of
 * the files they use. Nothing here is estimated. Each card may name one real action that opens where it is managed.
 */
object MemoryOverview {
    class Layer(val icon: String, val title: String, val lines: List<String>, val actionLabel: String? = null, val action: String? = null)

    private fun fileSize(f: File): Long = if (f.exists()) f.length() else 0L

    fun build(ctx: Context): List<Layer> {
        val out = ArrayList<Layer>()
        val prefs = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

        // Short-term: the chats saved on this phone
        val chats = ChatStore.all(ctx)
        var messages = 0
        var grouped = 0
        for (i in 0 until chats.length()) {
            val c = chats.optJSONObject(i) ?: continue
            messages += c.optJSONArray("lines")?.length() ?: 0
            if (c.optString("project").isNotBlank()) grouped++
        }
        out.add(Layer("💬", "Short-term: chats",
            listOf("${chats.length()} chats and $messages messages are saved on this phone.",
                "The open chat is what the AI sees as conversation context. Delete a chat from the chat list.")))

        // Long-term memory
        val mem = LongMemory.all(ctx)
        val memLines = ArrayList<String>()
        memLines.add(if (mem.isEmpty()) "No memories saved yet." else mem.size.toString() + " memories: " + MemoryOverviewLogic.kindSummary(mem) + ".")
        if (mem.any { it.pinned }) memLines.add(mem.count { it.pinned }.toString() + " pinned.")
        memLines.add("Save Memory: " + (if (LongMemory.enabled(ctx)) "on" else "off") + "  ·  Auto Memory: " + (if (LongMemory.auto(ctx)) "on" else "off"))
        memLines.add("Open a memory to correct, pin or delete it.")
        out.add(Layer("🧠", "Long-term memory", memLines, "Open memories", "memories"))

        // Project memory
        val projects = Projects.list(ctx)
        out.add(Layer("📁", "Project memory",
            listOf(if (projects.isEmpty()) "No projects yet." else projects.size.toString() + " projects, " + projects.count { it.instructions.isNotBlank() } + " with instructions.",
                "$grouped chats are grouped in projects. Edit or delete a project from the chat list; deleting a project keeps its chats.")))

        // Task memory
        val tasks = Tasks.all(ctx)
        var todo = 0; var doing = 0; var done = 0
        for (i in 0 until tasks.length()) when (tasks.optJSONObject(i)?.optString("status")) { "doing" -> doing++; "done" -> done++; else -> todo++ }
        out.add(Layer("✅", "Task memory",
            listOf(if (tasks.length() == 0) "No tasks on the board." else "${tasks.length()} tasks: $todo to do, $doing doing, $done done."),
            "Open Task Board", "tasks"))

        // Knowledge base and its search index
        val ks = KnowledgeBase.stats(ctx)
        val docs = ks.optInt("documents")
        val kLines = ArrayList<String>()
        kLines.add(if (docs == 0) "No documents yet." else "$docs documents, ${ks.optInt("chunks")} searchable parts, ${MemoryOverviewLogic.size(ks.optLong("characters"))} of text" + (if (ks.optInt("pinned") > 0) ", ${ks.optInt("pinned")} pinned." else "."))
        val total = ks.optInt("semantic_total_chunks"); val indexed = ks.optInt("semantic_indexed_chunks")
        kLines.add(if (ks.optBoolean("semantic_enabled")) "AI search index: $indexed of $total parts (${MemoryOverviewLogic.percent(indexed, total)}%)." else "AI semantic search is off, so keyword search is used.")
        kLines.add("Use Knowledge in AI answers: " + (if (prefs.getBoolean("knowledgeContext", false)) "on" else "off"))
        out.add(Layer("📚", "Knowledge base and documents", kLines, "Open knowledge", "knowledge"))

        // Storage actually used by these layers
        val mem1 = fileSize(File(ctx.filesDir, "long_memory.json"))
        val chats1 = fileSize(File(ctx.filesDir, "chats.json"))
        val db = fileSize(ctx.getDatabasePath("anjoo_local.db"))
        out.add(Layer("💾", "Storage on this phone",
            listOf("Chats: " + MemoryOverviewLogic.size(chats1),
                "Long-term memory: " + MemoryOverviewLogic.size(mem1),
                "Knowledge database: " + MemoryOverviewLogic.size(db),
                "Total: " + MemoryOverviewLogic.size(mem1 + chats1 + db) + ". Tasks and projects are small settings entries and are not counted.")))
        return out
    }
}
