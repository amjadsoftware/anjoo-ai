package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Finance & Billing (local mode). Two kinds of money, never mixed:
 *  - Estimates: tokens measured on this phone times the prices you typed in.
 *  - Actual: payments or invoices you recorded yourself from a real provider.
 * Online payments and revenue need a payment provider and a backend, which are not connected, so they are not shown as numbers.
 */
class FinanceActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private lateinit var theme: CyberTheme
    private lateinit var content: LinearLayout
    private val good = Color.rgb(46, 125, 50)
    private val warn = Color.rgb(230, 126, 0)
    private val bad = Color.rgb(198, 40, 40)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun faint() = Color.argb(70, 128, 128, 128)
    private fun shape(fill: Int, stroke: Int = faint(), radius: Int = 14) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(radius).toFloat()
    }
    private fun label(text: String, size: Float = 14f, color: Int = theme.ink, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(theme.surface); setPadding(dp(14), dp(12), dp(14), dp(12)) }
    private fun gap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    private fun fmt(n: Long): String = when {
        n >= 1_000_000 -> String.format(Locale.US, "%.2fM", n / 1_000_000.0)
        n >= 1_000 -> String.format(Locale.US, "%.1fk", n / 1_000.0)
        else -> n.toString()
    }
    private fun button(text: String, onClick: () -> Unit) = label(text, 13f, theme.accent, true).apply {
        background = shape(Color.TRANSPARENT, theme.accent, 16); setPadding(dp(12), dp(7), dp(12), dp(7)); setOnClickListener { onClick() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        theme = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        Style.bars(window, theme)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(theme.bg)
            setPadding(dp(14), dp(28), dp(14), dp(10))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("‹", 30f).apply { setPadding(dp(6), 0, dp(18), dp(4)); setOnClickListener { finish() } })
        header.addView(label("Finance & Billing", 20f, theme.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("↻", 24f, theme.accent).apply { setPadding(dp(14), 0, dp(6), dp(2)); setOnClickListener { render() } })
        root.addView(header)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        setContentView(root)
        render()
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) render() }

    private fun input(title: String, hint: String, initial: String, numeric: Boolean, onOk: (String) -> Unit) {
        val et = EditText(this).apply {
            setText(initial); this.hint = hint; setSingleLine(!hint.contains("lines"))
            if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(dp(20), dp(12), dp(20), dp(12))
        }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("Save") { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun render() {
        content.removeAllViews()
        val now = Date()
        val day = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(now)
        val month = day.substring(0, 7)
        val cal = Calendar.getInstance()
        val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
        val daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val prices = TokenLedger.prices(this)
        val monthRows = FinanceCore.costRows(TokenLedger.totalsFor(this, month), prices)
        val todayRows = FinanceCore.costRows(TokenLedger.totalsFor(this, day), prices)
        val (monthCost, monthAllKnown) = FinanceCore.sumKnown(monthRows)
        val (todayCost, todayAllKnown) = FinanceCore.sumKnown(todayRows)
        val budget = FinanceStore.budgetUsd(this)

        // Banner: what is real and what is not.
        val banner = card()
        banner.addView(label("Estimates and actual payments are kept apart", 14.5f, theme.ink, true))
        banner.addView(label("Estimate = tokens measured on this phone × the prices you entered. Actual = payments you record from a real provider invoice. Online payments, subscriptions and revenue need a payment provider and a backend; they are not connected, so no number is shown for them.", 12.5f, theme.muted).apply { setPadding(0, dp(4), 0, 0) })
        content.addView(banner, LinearLayout.LayoutParams(-1, -2))

        // This month (estimate) + budget
        val m = card()
        m.addView(label("This month · estimate", 13f, theme.muted, true))
        val tokens = monthRows.sumOf { it.input + it.output }
        val calls = monthRows.sumOf { it.calls }
        val costText = when {
            monthRows.isEmpty() -> "No usage yet"
            prices.isEmpty() -> "Cost unknown"
            monthAllKnown -> "≈ " + FinanceCore.money(monthCost)
            else -> "≥ " + FinanceCore.money(monthCost)
        }
        m.addView(label(costText, 24f, theme.ink, true).apply { setPadding(0, dp(2), 0, 0) })
        m.addView(label("${fmt(tokens)} tokens in $calls AI requests." + (if (prices.isEmpty()) " Enter prices to see a cost." else if (!monthAllKnown && monthRows.isNotEmpty()) " Some models have no price entered, so the real cost is higher." else ""), 12.5f, theme.muted).apply { setPadding(0, dp(2), 0, 0) })
        if (prices.isNotEmpty() && monthRows.isNotEmpty()) {
            val proj = FinanceCore.projection(monthCost, dayOfMonth, daysInMonth)
            m.addView(label("Projection for the whole month (straight line from $dayOfMonth of $daysInMonth days): ≈ ${FinanceCore.money(proj)}", 12.5f, theme.muted).apply { setPadding(0, dp(4), 0, 0) })
        }
        val state = FinanceCore.budgetState(monthCost, budget)
        if (state == FinanceCore.BudgetState.NONE) {
            m.addView(label("No monthly budget set.", 12.5f, theme.muted).apply { setPadding(0, dp(6), 0, 0) })
        } else {
            val frac = (monthCost / budget).coerceIn(0.0, 1.0).toFloat()
            val color = when (state) { FinanceCore.BudgetState.OVER -> bad; FinanceCore.BudgetState.NEAR -> warn; else -> good }
            m.addView(bar(frac, color), LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(8) })
            val msg = when (state) {
                FinanceCore.BudgetState.OVER -> "Over the monthly budget of ${FinanceCore.money(budget)}."
                FinanceCore.BudgetState.NEAR -> "Close to the monthly budget of ${FinanceCore.money(budget)} (80% or more)."
                else -> "Within the monthly budget of ${FinanceCore.money(budget)}."
            }
            m.addView(label(msg + " Requests are never blocked; this is only a warning.", 12.5f, color, true).apply { setPadding(0, dp(4), 0, 0) })
        }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button(if (budget > 0) "Change budget" else "Set budget") {
            input("Monthly budget (USD)", "0 removes the budget", if (budget > 0) budget.toString() else "", true) { t ->
                val v = if (t.isBlank()) 0.0 else FinanceCore.parseAmount(t)
                if (v == null) Toast.makeText(this, "That is not a valid amount.", Toast.LENGTH_SHORT).show()
                else { FinanceStore.setBudgetUsd(this, v); render() }
            }
        })
        actions.addView(button("Edit prices") {
            input("Prices per 1M tokens", "one per line: model,input,output\ne.g. gpt-4o,2.5,10 (more lines)", TokenLedger.pricesText(this), false) { t ->
                TokenLedger.setPricesText(this, t); AdminAudit.log(this, "admin", "Token prices changed", "${UsageBook.parsePrices(t).size} price lines"); render()
            }
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        m.addView(actions, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
        content.addView(m, gap())

        // Today (estimate)
        val t = card()
        t.addView(label("Today · estimate", 13f, theme.muted, true))
        val todayTokens = todayRows.sumOf { it.input + it.output }
        t.addView(label(
            if (todayRows.isEmpty()) "No AI requests today." else
                "${fmt(todayTokens)} tokens, ${todayRows.sumOf { it.calls }} requests" + (if (prices.isEmpty()) ", cost unknown." else (if (todayAllKnown) ", ≈ " else ", ≥ ") + FinanceCore.money(todayCost) + "."),
            13.5f, theme.ink).apply { setPadding(0, dp(3), 0, 0) })
        val dailyLimit = TokenLedger.dailyBudget(this)
        t.addView(label("Daily token limit: " + (if (dailyLimit > 0) "${fmt(dailyLimit)} (${fmt(todayTokens)} used)" else "not set") + ". Change it in Settings.", 12f, theme.muted).apply { setPadding(0, dp(3), 0, 0) })
        content.addView(t, gap())

        // By model this month
        val byModel = card()
        byModel.addView(label("Expenditure by model · this month · estimate", 13f, theme.muted, true))
        if (monthRows.isEmpty()) byModel.addView(label("No records yet.", 12.5f, theme.muted).apply { setPadding(0, dp(4), 0, 0) })
        for (r in monthRows) {
            byModel.addView(label(r.company + " · " + r.model, 13.5f, theme.ink, true).apply { setPadding(0, dp(8), 0, 0) })
            byModel.addView(label("${r.calls} requests · ${fmt(r.input)} in / ${fmt(r.output)} out · " + (r.cost?.let { "≈ " + FinanceCore.money(it) } ?: "no price entered"), 12f, theme.muted))
        }
        content.addView(byModel, gap())

        // Last 14 days: real tokens per day
        val days = TokenLedger.recentDays(this, 14)
        val maxTok = days.maxOfOrNull { it.second } ?: 0L
        val chart = card()
        chart.addView(label("Tokens per day · last 14 days", 13f, theme.muted, true))
        if (maxTok == 0L) chart.addView(label("No token records in the last 14 days.", 12.5f, theme.muted).apply { setPadding(0, dp(4), 0, 0) })
        else for ((d, tok, _) in days) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(label(d.substring(5), 11.5f, theme.muted), LinearLayout.LayoutParams(dp(44), -2))
            row.addView(bar(tok.toFloat() / maxTok, theme.accent), LinearLayout.LayoutParams(0, dp(8), 1f))
            row.addView(label(fmt(tok), 11.5f, theme.muted).apply { gravity = Gravity.END }, LinearLayout.LayoutParams(dp(52), -2))
            chart.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        }
        content.addView(chart, gap())

        // Actual payments recorded by the owner
        val records = FinanceStore.all(this)
        val monthStart = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val monthActual = records.filter { it.at >= monthStart }.sumOf { it.amountUsd }
        val actual = card()
        actual.addView(label("Actual payments · recorded by you", 13f, theme.muted, true))
        actual.addView(label(if (records.isEmpty()) "None recorded" else "This month: " + FinanceCore.money(monthActual) + " · all time: " + FinanceCore.money(records.sumOf { it.amountUsd }), 14f, theme.ink, true).apply { setPadding(0, dp(3), 0, 0) })
        actual.addView(label("These are amounts you typed from a provider's invoice or receipt. The app cannot see your provider account.", 12f, theme.muted).apply { setPadding(0, dp(3), 0, 0) })
        val df = SimpleDateFormat("d MMM yyyy", Locale.getDefault())
        for (e in records.take(30)) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            val txt = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            txt.addView(label(e.provider + " · " + FinanceCore.money(e.amountUsd), 13f, theme.ink, true))
            txt.addView(label(df.format(Date(e.at)) + (if (e.note.isNotBlank()) " · " + e.note else ""), 11.5f, theme.muted))
            row.addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(label("Delete", 12f, bad, true).apply {
                setPadding(dp(8), dp(6), dp(4), dp(6))
                setOnClickListener {
                    AlertDialog.Builder(this@FinanceActivity).setTitle("Delete this record?").setMessage(e.provider + " · " + FinanceCore.money(e.amountUsd))
                        .setPositiveButton("Delete") { _, _ -> FinanceStore.remove(this@FinanceActivity, e); render() }
                        .setNegativeButton("Cancel", null).show()
                }
            })
            actual.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
        actual.addView(button("Record a payment") {
            input("Provider (for example OpenAI)", "Provider name", "", false) { prov ->
                if (prov.isBlank()) { Toast.makeText(this, "Enter a provider name.", Toast.LENGTH_SHORT).show(); return@input }
                input("Amount paid (USD)", "e.g. 20", "", true) { amt ->
                    val v = FinanceCore.parseAmount(amt)
                    if (v == null || v <= 0.0) Toast.makeText(this, "That is not a valid amount.", Toast.LENGTH_SHORT).show()
                    else input("Note (optional)", "e.g. invoice number or month", "", false) { note ->
                        if (FinanceStore.add(this, FinanceCore.Expense(System.currentTimeMillis(), prov.trim().take(60), v, note.trim().take(120)))) render()
                        else Toast.makeText(this, "The record could not be saved.", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        content.addView(actual, gap())

        // Export
        val ex = card()
        ex.addView(label("Export", 13f, theme.muted, true))
        ex.addView(label("A CSV file with the estimate rows (per model, this month) and your recorded payments, labelled so they cannot be confused.", 12f, theme.muted).apply { setPadding(0, dp(3), 0, 0) })
        ex.addView(button("Export CSV") {
            val rows = ArrayList<List<String>>()
            for (r in monthRows) rows.add(listOf("ESTIMATE", month, r.company, r.model, r.calls.toString(), r.input.toString(), r.output.toString(), r.cost?.let { String.format(Locale.US, "%.6f", it) } ?: "no price"))
            for (e in records) rows.add(listOf("ACTUAL (recorded by owner)", SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(e.at)), e.provider, e.note, "", "", "", String.format(Locale.US, "%.2f", e.amountUsd)))
            val csv = FinanceCore.csv(listOf("type", "date_or_month", "provider", "model_or_note", "requests", "input_tokens", "output_tokens", "usd"), rows)
            val name = "Anjoo_Finance_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".csv"
            Toast.makeText(this, AdminExport.shareCsv(this, name, csv, "Anjoo AI finance report"), Toast.LENGTH_LONG).show()
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        content.addView(ex, gap())
    }

    /** A horizontal bar filled to [fraction] (0..1) with real data. */
    private fun bar(fraction: Float, color: Int): View {
        val f = fraction.coerceIn(0f, 1f)
        val track = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; weightSum = 1f; background = shape(Color.argb(40, 128, 128, 128), Color.TRANSPARENT, 4) }
        if (f > 0f) track.addView(View(this).apply { background = shape(color, Color.TRANSPARENT, 4) }, LinearLayout.LayoutParams(0, -1, f))
        return track
    }
}
