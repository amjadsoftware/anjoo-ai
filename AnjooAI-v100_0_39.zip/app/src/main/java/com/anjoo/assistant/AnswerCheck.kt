package com.anjoo.assistant

/**
 * Final-answer check: before an answer is shown, it is compared with the tools that really ran in this request.
 * If the answer says something only a tool could make true ("tests passed", "built successfully", "published",
 * "message sent", "PDF created") and no matching tool result exists, a short warning is added under the answer.
 * It never rewrites the answer and never blocks it. Detection is deliberately narrow (English and Roman Urdu)
 * so that ordinary explanations ("make sure the tests pass") are not flagged.
 * Pure Kotlin, so it can be unit tested.
 */
internal object AnswerCheck {
    /** One tool call of this request: its name, its "action" argument, whether it succeeded and (a part of) its result. */
    class Ran(val name: String, val action: String, val ok: Boolean, val result: String)

    enum class Kind(val warning: String) {
        TESTS("I said tests passed, but no test run in this request confirms it."),
        BUILD("I said it was built or compiled, but no build or run in this request confirms it."),
        PUBLISH("I said it was published or deployed, but no publish or deploy step in this request confirms it."),
        SENT("I said a message was sent, but no send action in this request confirms it."),
        DOCUMENT("I said a document or file was created, but no file tool in this request confirms it.")
    }

    private val MARK = "⚠️ Check before relying on this:"

    private val skip = Regex("(?i)\\b(not|no|never|nahi|nahin|nhi|should|would|could|can|will|shall|if|when|once|until|ensure|before|after|want|need|try|agar|jab|let me|going to|make sure)\\b|n't|'ll")
    private val fence = Regex("(?s)```.*?```")
    private val splitter = Regex("[.!?\\n]+")

    private val files = "pdf|docx|word document|word file|excel|xlsx|spreadsheet|powerpoint|pptx|presentation"
    private val claimRx: List<Pair<Kind, Regex>> = listOf(
        Kind.TESTS to Regex("\\btests?\\b.{0,25}\\b(passed|pass|passing|succeeded|paas)\\b"),
        Kind.BUILD to Regex("\\b(build|compil\\w*)\\b.{0,25}\\b(succeeded|successful|successfully|passed|completed|ho gaya|ho gayi)\\b|\\bcompiled (successfully|without errors|fine)\\b"),
        Kind.PUBLISH to Regex("\\b(published|deployed|went live|is now live|is live|publish ho gaya|deploy ho gaya|live ho gaya)\\b"),
        Kind.SENT to Regex("\\b(sent|bhej di|bhej diya)\\b.{0,25}\\b(message|sms|email|mail|whatsapp|text)\\b|\\b(message|sms|email|mail|whatsapp)\\b.{0,25}\\b(sent|bhej di|bhej diya)\\b"),
        Kind.DOCUMENT to Regex("\\b($files)\\b.{0,40}\\b(created|generated|saved|exported|bana di|bana diya|ban gaya|ban gayi)\\b|\\b(created|generated|saved|exported|made|bana di|bana diya)\\b.{0,40}\\b($files)\\b")
    )

    private val passRx = Regex("(?i)\\bpass(ed)?\\b")
    private val testActions = setOf("test", "coverage")
    private val runActions = setOf("run", "test", "coverage")
    private val runTools = setOf("run_code", "run_python", "run_shell")
    private val sendTools = setOf("send_sms", "send_email", "whatsapp_message", "reply_message", "send_in_app", "share_text")
    private val docTools = setOf("make_document", "convert_document", "edit_document", "merge_documents", "export_artifact", "create_artifact", "save_file", "export_project")

    private fun norm(a: String) = a.lowercase().replace('-', '_').replace(' ', '_')

    /** True when a tool that really ran backs this kind of claim. */
    private fun supported(kind: Kind, ran: List<Ran>): Boolean {
        val ok = ran.filter { it.ok }
        return when (kind) {
            Kind.TESTS -> ok.any { (it.name == "project_check" && norm(it.action) in testActions || it.name in runTools) && passRx.containsMatchIn(it.result) }
            Kind.BUILD -> ok.any { it.name in runTools || (it.name == "project_check" && norm(it.action) in runActions) }
            Kind.PUBLISH -> ok.any { it.name == "project_deploy" || norm(it.action).let { a -> a.contains("publish") || a.contains("deploy") } }
            Kind.SENT -> ok.any { it.name in sendTools }
            Kind.DOCUMENT -> ok.any { it.name in docTools }
        }
    }

    /** The kinds of claims in [answer] that no tool in [ran] supports. Code blocks, negations and conditions are ignored. */
    fun findings(answer: String, ran: List<Ran>): List<Kind> {
        val text = fence.replace(answer, " ").lowercase()
        val found = LinkedHashSet<Kind>()
        for (sentence in text.split(splitter)) {
            if (sentence.length < 8 || skip.containsMatchIn(sentence)) continue
            for ((kind, rx) in claimRx) if (kind !in found && rx.containsMatchIn(sentence) && !supported(kind, ran)) found.add(kind)
        }
        return found.toList()
    }

    /** Returns [answer] with a short warning added when it claims something no tool confirms; otherwise unchanged. */
    fun annotate(answer: String, ran: List<Ran>): String {
        if (answer.isBlank() || answer.contains(MARK)) return answer
        val f = findings(answer, ran)
        if (f.isEmpty()) return answer
        return answer.trimEnd() + "\n\n" + MARK + "\n" + f.joinToString("\n") { "• " + it.warning }
    }
}
