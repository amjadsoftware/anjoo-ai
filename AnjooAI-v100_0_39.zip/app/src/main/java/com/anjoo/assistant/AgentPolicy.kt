package com.anjoo.assistant

/**
 * One place for the limits agents really run under, plus the one new enforced rule of v100.0.34:
 * a tool that keeps failing is blocked for a while instead of being tried again and again.
 * The screen "Agent runs > Limits & permissions" is generated from these constants, so it cannot drift from the code.
 */
internal object AgentPolicy {
    /** The same tool failing this many times in a row ... */
    const val FAILURE_CAP = 4
    /** ... within this time stays blocked until this much time passes after its last failure. */
    const val FAILURE_WINDOW_MS = 5 * 60_000L
    /** delegate_team never runs more specialists than this. */
    const val TEAM_MAX = 3
    /** Answer size cap of one specialist (delegate_task / delegate_team), in tokens. */
    const val SUBAGENT_MAX_TOKENS = 4096

    /** A tool result that clearly reports a failure (not a cancelled, set-up or blocked-by-policy message). Conservative on purpose. */
    fun looksFailed(result: String, thrown: Boolean): Boolean {
        if (thrown) return true
        val t = result.trim().lowercase()
        return listOf("error", "failed", "nakam", "could not", "unable to", "cannot ", "no such tool").any { t.startsWith(it) }
    }

    /** Counts consecutive failures per tool name. Pure Kotlin so it can be unit tested. */
    class FailureTracker(private val cap: Int = FAILURE_CAP, private val windowMs: Long = FAILURE_WINDOW_MS) {
        private class S(var count: Int = 0, var lastAt: Long = 0L)
        private val map = HashMap<String, S>()

        /** Returns the STOP message when [name] must not be called now, else null. */
        @Synchronized fun blockedMessage(name: String, now: Long): String? {
            val s = map[name] ?: return null
            if (now - s.lastAt > windowMs) { map.remove(name); return null }
            if (s.count < cap) return null
            return "STOP: the tool '$name' failed ${s.count} times in a row in the last ${windowMs / 60_000} minutes, so it is paused. " +
                "Do not call it again now. Tell the user plainly what is failing, or reach the goal with a different tool."
        }

        /** Call after every run of [name]. A success clears its count. */
        @Synchronized fun record(name: String, failed: Boolean, now: Long) {
            if (!failed) { map.remove(name); return }
            val s = map.getOrPut(name) { S() }
            if (now - s.lastAt > windowMs) s.count = 0
            s.count++
            s.lastAt = now
        }
    }

    /** What the Limits screen shows: section title to lines. Every number comes from a constant used by the code. */
    fun sections(): List<Pair<String, List<String>>> {
        val out = ArrayList<Pair<String, List<String>>>()
        out.add("Enforced by the app for every agent that uses tools" to listOf(
            "Tool rounds: at most ${ToolLoopBudget.MAX_STEPS} per request. After that the task is reported as not fully verified.",
            "Repeats: the same tool with the same arguments is stopped on its 3rd run within 90 seconds.",
            "Retries: a tool that fails ${FAILURE_CAP} times in a row is paused until ${FAILURE_WINDOW_MS / 60_000} minutes after its last failure. A success clears the count.",
            "Money safety: bank, wallet and card screens and details are blocked.",
            "Confirmation: calls, SMS and other sensitive actions ask first. In background runs they are refused, because nobody can answer.",
            "Models: if a model or key fails, the next one is tried, up to ${Router.MAX_TRIES} candidates per request, with resting time after repeated failures."
        ))
        out.add("Autonomous runs (Agent runs)" to listOf(
            "Plan first: 3 to 7 steps and acceptance checks (a prompt rule; the model decides the exact steps).",
            "Pause and cancel apply at the next safe checkpoint between model and tool actions.",
            "A run is marked Done only if the final report says DONE, at least one tool result came back, and the completion check passes. Otherwise it is Blocked or Needs attention.",
            "Background runs can use the same tools but cannot send calls, SMS or replies."
        ))
        out.add("Specialist team (delegate_team / delegate_task)" to listOf(
            "At most $TEAM_MAX specialists, one after the other, one pass each.",
            "No phone tools. Each specialist only writes an answer, up to $SUBAGENT_MAX_TOKENS tokens.",
            "Researcher and analyst may use Google Search grounding.",
            "A failed specialist is reported as \"Sub-agent failed\". It is not retried automatically."
        ))
        val agents = ArrayList<String>()
        for ((task, a) in AgentRoster.entries()) agents.add(a.icon + " " + a.name + " handles " + task.label + ".")
        agents.add("These are role rules inside the prompt. Tool access is the same for all of them; it is not restricted per agent.")
        out.add("Agents by kind of work" to agents)
        return out
    }
}
