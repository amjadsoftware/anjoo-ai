package com.anjoo.assistant

import android.app.Notification
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** The latest chat messages seen in the notification bar, and a way to answer them. */
object NotifState {
    class Item(val app: String, val who: String, val text: String, val at: Long, val action: Notification.Action?)

    private val items = ArrayList<Item>()
    @Volatile var lastReply: Item? = null

    @Synchronized
    fun add(i: Item) {
        items.add(i)
        while (items.size > 25) items.removeAt(0)
        if (i.action != null) lastReply = i
    }

    @Synchronized
    fun recent(n: Int): String {
        if (items.isEmpty()) return "No new message (or Notification access is not on)."
        val fmt = SimpleDateFormat("HH:mm", Locale.ENGLISH)
        return items.takeLast(n.coerceIn(1, 10)).joinToString("\n") {
            fmt.format(Date(it.at)) + " " + it.app + " - " + it.who + ": " + it.text
        }
    }

    /** One line for the system prompt, only while the last message is still fresh. */
    fun contextLine(): String {
        val l = lastReply ?: return ""
        if (System.currentTimeMillis() - l.at > 15 * 60 * 1000) return ""
        return "Last received message: " + l.app + " par " + l.who + " wrote: \"" + l.text.take(200) +
            "\". If the user asks, you can send a reply with the reply_message tool."
    }

    fun send(item: Item, text: String): Boolean {
        val a = item.action ?: return false
        val inputs = a.remoteInputs ?: return false
        if (inputs.isEmpty()) return false
        return try {
            val b = Bundle()
            b.putCharSequence(inputs[0].resultKey, text)
            val intent = Intent()
            RemoteInput.addResultsToIntent(inputs, intent, b)
            a.actionIntent.send(null, 0, intent)
            true
        } catch (e: Exception) { false }
    }
}

class AnjooNotif : NotificationListenerService() {

    private val known = mapOf(
        "com.whatsapp" to "WhatsApp",
        "com.whatsapp.w4b" to "WhatsApp Business",
        "org.telegram.messenger" to "Telegram",
        "com.google.android.apps.messaging" to "SMS",
        "com.android.mms" to "SMS",
        "com.samsung.android.messaging" to "SMS"
    )
    private val autoSent = HashMap<String, Long>()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        try {
            val app = known[sbn.packageName] ?: return
            val n = sbn.notification
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return
            val ex = n.extras
            val who = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: return
            val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: return
            if (text.isBlank()) return
            val group = ex.getBoolean("android.isGroupConversation", false)
            val action = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
            val item = NotifState.Item(app, who, text, System.currentTimeMillis(), action)
            NotifState.add(item)

            val prefs = getSharedPreferences("anjoo", Context.MODE_PRIVATE)
            val auto = prefs.getString("autoreply", "") ?: ""
            if (auto.isNotEmpty() && action != null && !group) {
                val now = System.currentTimeMillis()
                if (now - (autoSent[who] ?: 0L) > 30 * 60 * 1000L && NotifState.send(item, auto)) {
                    autoSent[who] = now
                    Buddy.post(3, "[AUTO] Reply sent to $who")
                    return
                }
            }
            if (prefs.getBoolean("notifread", true) && VoiceService.running) {
                VoiceService.announce("Message from " + who + " on " + app + ": " + text.take(250) + ". Shall I reply?")
            }
        } catch (e: Exception) {}
    }
}
