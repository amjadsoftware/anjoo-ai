package com.anjoo.assistant

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Operations dashboard: one screen of REAL numbers measured on this phone.
 * Sources: TokenLedger (provider-reported tokens), Router (success/failure/latency per model),
 * ToolRunLog (last tool runs) and the Task Board. Nothing here is estimated or invented:
 * where a number is not recorded, the screen says so. Cost uses only prices the user entered.
 */
class OpsDashboardActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private val bg = Color.rgb(247, 246, 243)
    private val surface = Color.WHITE
    private val ink = Color.rgb(32, 37, 43)
    private val muted = Color.rgb(105, 112, 120)
    private val accent = Color.rgb(37, 111, 194)
    private val line = Color.rgb(225, 228, 232)
    private val good = Color.rgb(46, 125, 50)
    private val bad = Color.rgb(198, 40, 40)
    private val warn = Color.rgb(230, 126, 0)
    private lateinit var content: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, radius: Int, stroke: Int = Color.TRANSPARENT) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.toFloat(); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(22), dp(16), dp(12))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        top.addView(TextView(this).apply {
            text = "‹"; textSize = 32f; setTextColor(ink); gravity = Gravity.CENTER
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(46), dp(48)))
        top.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@OpsDashboardActivity).apply { text = "Operations"; textSize = 24f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD })
            addView(TextView(this@OpsDashboardActivity).apply { text = "Measured on this phone. Nothing is estimated."; textSize = 12.5f; setTextColor(muted) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = "↻"; textSize = 25f; setTextColor(accent); gravity = Gravity.CENTER
            setOnClickListener { render() }
        }, LinearLayout.LayoutParams(dp(42), dp(46)))
        root.addView(top)

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { addView(content); isVerticalScrollBarEnabled = false }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) })
        setContentView(root)
        render()
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) render() }

    private fun fmt(n: Long): String = when {
        n >= 1_000_000 -> String.format(Locale.US, "%.2fM", n / 1_000_000.0)
        n >= 1_000 -> String.format(Locale.US, "%.1fk", n / 1_000.0)
        else -> n.toString()
    }

    private fun card(title: String, body: LinearLayout.() -> Unit) {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(surface, dp(14), line)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        c.addView(TextView(this).apply { text = title; textSize = 15f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD })
        c.body()
        content.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
    }

    private fun LinearLayout.text(s: String, color: Int = muted, size: Float = 13f, bold: Boolean = false) {
        addView(TextView(this@OpsDashboardActivity).apply {
            text = s; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, 0)
        })
    }

    private fun LinearLayout.stats(vararg pairs: Pair<String, String>) {
        val row = LinearLayout(this@OpsDashboardActivity).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(2)) }
        for ((label, value) in pairs) {
            row.addView(LinearLayout(this@OpsDashboardActivity).apply {
                orientation = LinearLayout.VERTICAL
                addView(TextView(this@OpsDashboardActivity).apply { text = value; textSize = 20f; setTextColor(ink); typeface = Typeface.DEFAULT_BOLD })
                addView(TextView(this@OpsDashboardActivity).apply { text = label; textSize = 11.5f; setTextColor(muted) })
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        addView(row)
    }

    private fun LinearLayout.bar(label: String, fraction: Float, right: String, color: Int) {
        val f = fraction.coerceIn(0f, 1f)
        val row = LinearLayout(this@OpsDashboardActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(3), 0, dp(3)) }
        row.addView(TextView(this@OpsDashboardActivity).apply { text = label; textSize = 11.5f; setTextColor(muted) }, LinearLayout.LayoutParams(dp(44), -2))
        val track = LinearLayout(this@OpsDashboardActivity).apply { orientation = LinearLayout.HORIZONTAL; background = rounded(Color.rgb(238, 240, 243), dp(4)) }
        if (f > 0f) track.addView(View(this@OpsDashboardActivity).apply { background = rounded(color, dp(4)) }, LinearLayout.LayoutParams(0, dp(10), f))
        if (f < 1f) track.addView(View(this@OpsDashboardActivity), LinearLayout.LayoutParams(0, dp(10), 1f - f))
        row.addView(track, LinearLayout.LayoutParams(0, dp(10), 1f))
        row.addView(TextView(this@OpsDashboardActivity).apply { text = right; textSize = 11.5f; setTextColor(ink); gravity = Gravity.END }, LinearLayout.LayoutParams(dp(62), -2))
        addView(row)
    }

    private fun render() {
        content.removeAllViews()
        TokenLedger.bind(this)
        val dayFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val today = dayFmt.format(Date())
        val prices = TokenLedger.prices(this)

        // 1. Usage today and this month (provider-reported tokens only)
        fun usage(prefix: String): Triple<Long, Long, Double?> {
            val rows = TokenLedger.totalsFor(this, prefix)
            var calls = 0L; var tokens = 0L; var cost = 0.0; var known = prices.isNotEmpty()
            for ((k, r) in rows) {
                calls += r.calls; tokens += r.input + r.output
                val c = UsageBook.cost(prices, k.substringAfter('|'), r.input, r.output)
                if (c == null) known = false else cost += c
            }
            return Triple(calls, tokens, if (known && rows.isNotEmpty()) cost else null)
        }
        val (tc, tt, tcost) = usage(today)
        val (mc, mt, mcost) = usage(today.substring(0, 7))
        card("AI usage") {
            stats("Requests today" to tc.toString(), "Tokens today" to fmt(tt), "Cost today" to (tcost?.let { String.format(Locale.US, "$%.4f", it) } ?: "n/a"))
            stats("Requests this month" to mc.toString(), "Tokens this month" to fmt(mt), "Cost this month" to (mcost?.let { String.format(Locale.US, "$%.4f", it) } ?: "n/a"))
            val budget = TokenLedger.dailyBudget(this@OpsDashboardActivity)
            text(if (budget > 0) "Daily token limit: ${fmt(budget)} (${fmt(tt)} used today). It only reminds you; nothing is blocked." else "Daily token limit: not set.")
            text(if (prices.isEmpty()) "Cost shows n/a until you enter model prices (Settings > token usage)." else "Cost uses only the prices you entered; n/a means a used model has no price.")
            text("Only tokens the provider reports are counted. Live voice replies are not included.", muted, 11.5f)
        }

        // 2. Seven-day trend
        val days = TokenLedger.recentDays(this, 7)
        card("Last 7 days (tokens)") {
            val max = (days.maxOfOrNull { it.second } ?: 0L)
            if (max == 0L) text("No token records in the last 7 days.")
            else for ((d, tokens, calls) in days) bar(d.substring(5), tokens.toFloat() / max.toFloat(), fmt(tokens) + " · " + calls, accent)
        }

        // 3. Models (measured success, failure, latency)
        val rows = Router.healthRows()
        card("Models (measured)") {
            if (rows.isEmpty()) text("No model has been used yet, so there are no numbers to show.")
            else {
                val ok = rows.sumOf { it.ok }; val fail = rows.sumOf { it.fail }
                stats("Replies OK" to ok.toString(), "Failures" to fail.toString(), "Success rate" to (if (ok + fail > 0) (ok * 100 / (ok + fail)).toString() + "%" else "-"))
                for (r in rows.take(12)) {
                    val attempts = r.ok + r.fail
                    val rate = if (attempts > 0) r.ok * 100 / attempts else 0
                    val color = when { r.consecFail >= 3 || r.resting -> bad; rate < 80 -> warn; else -> good }
                    text(r.name, ink, 13f, true)
                    var s = "${r.ok} ok / ${r.fail} fail ($rate%)"
                    if (r.ok > 0) s += " · avg " + String.format(Locale.US, "%.1f", r.avgMs / 1000.0) + "s"
                    if (r.resting) s += " · resting now"
                    else if (r.consecFail > 0) s += " · ${r.consecFail} failures in a row"
                    text(s, color, 12f)
                    if (r.fail > 0 && r.lastFailureAt > 0) text("Last failure: " + SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date(r.lastFailureAt)) + " · " + Router.failureText(r.lastCode), muted, 11.5f)
                }
                if (rows.size > 12) text("… and ${rows.size - 12} more models")
            }
        }

        // 4. Tools (last runs kept by ToolRunLog)
        val tools = ToolRunLog.entries(this)
        card("Tool runs (last ${tools.size})") {
            if (tools.isEmpty()) text("No tool has run yet.")
            else {
                val by = tools.groupingBy { it.status }.eachCount()
                stats("Done" to (by["DONE"] ?: 0).toString(), "Issues" to (by["ISSUE"] ?: 0).toString(), "Needs setup" to (by["SETUP"] ?: 0).toString())
                val timed = tools.filter { it.durationMs > 0 }
                if (timed.isNotEmpty()) text("Average run time: " + timed.map { it.durationMs }.average().toLong() + " ms")
                val issues = tools.filter { it.status == "ISSUE" }.groupingBy { it.name }.eachCount().entries.sortedByDescending { it.value }.take(5)
                if (issues.isNotEmpty()) text("Most frequent issues: " + issues.joinToString(", ") { it.key + " ×" + it.value }, warn)
                text("Only the most recent ${tools.size} runs are kept. Arguments and outputs are never stored.", muted, 11.5f)
            }
        }

        // 5. Task board
        val all = Tasks.all(this)
        card("Task board") {
            var todo = 0; var doing = 0; var done = 0
            for (i in 0 until all.length()) when (all.optJSONObject(i)?.optString("status")) { "doing" -> doing++; "done" -> done++; else -> todo++ }
            if (all.length() == 0) text("No tasks on the board.")
            else {
                stats("To do" to todo.toString(), "Doing" to doing.toString(), "Done" to done.toString())
                text("Completion: " + (done * 100 / all.length()) + "% of ${all.length()} tasks")
            }
        }

        // 6. Alerts (only real conditions)
        card("Needs attention") {
            val alerts = ArrayList<String>()
            for (r in rows) if (r.consecFail >= 3) alerts.add(r.name + ": " + r.consecFail + " failures in a row (" + Router.failureText(r.lastCode) + ")")
            val budget = TokenLedger.dailyBudget(this@OpsDashboardActivity)
            if (budget > 0 && tt >= budget) alerts.add("Today's token limit is passed (${fmt(tt)} of ${fmt(budget)}).")
            val ti = tools.count { it.status == "ISSUE" }
            if (tools.size >= 10 && ti * 100 / tools.size >= 30) alerts.add("$ti of the last ${tools.size} tool runs had issues.")
            if (alerts.isEmpty()) text("Nothing needs attention right now.", good)
            else for (a in alerts) text("• $a", bad)
        }
    }
}
