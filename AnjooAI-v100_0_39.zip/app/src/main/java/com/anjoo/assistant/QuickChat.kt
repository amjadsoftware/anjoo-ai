package com.anjoo.assistant

import org.json.JSONArray
import java.util.Locale

/**
 * Words like "ok", "haan", "yes", "ji" are deliberately NOT here: they may confirm a phone action the AI just asked about.
 * Fast path for plain small talk ("Hi", "salam", "shukriya"). These do not need the 40k-character rulebook or the
 * 60k-character tool list, so they are sent with a short prompt, no tools and no thinking: the first words arrive in
 * about a second instead of many seconds. Anything that looks like a command or a question still takes the full path.
 */
object QuickChat {
    private val WORDS = setOf(
        "hi", "hii", "hiii", "hello", "hey", "heyy", "yo", "salam", "salaam", "slam", "aoa", "assalam", "assalamualaikum", "assalamu", "alaikum", "alaykum", "walaikum", "walaikumassalam", "aslam", "o", "u", "a",
        "kaise", "kesay", "kese", "ho", "hain", "hai", "ap", "aap", "tum", "kya", "haal", "hal", "chal", "raha", "rahi", "or", "aur", "sunao", "bhai", "yaar", "dost", "anjoo", "anju",
        "thanks", "thank", "you", "shukriya", "shukria", "mehrbani", "good", "morning", "night", "evening", "afternoon", "bye", "khuda", "hafiz", "allah", "nice", "great", "wow", "cool", "zabardast", "shabash", "lol", "hmm", "hm", "hahaha", "haha"
    )
    private val URDU = Regex("^[\\s\\u0600-\\u06FF]{1,40}$")
    private val URDU_WORDS = setOf("سلام", "السلام", "علیکم", "ہیلو", "شکریہ", "ہے", "کیسے", "ہو", "آپ", "کیا", "حال", "خدا", "حافظ")

    fun isSmallTalk(text: String): Boolean {
        val t = text.trim().lowercase(Locale.ROOT)
        if (t.isEmpty() || t.length > 40) return false
        val words = t.replace(Regex("[^\\p{L}\\p{N}\\s]"), " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.isEmpty() || words.size > 6) return false
        if (URDU.matches(t)) return words.all { it in URDU_WORDS }
        return words.all { it in WORDS }
    }

    /** True when one of the last [n] history entries holds a tool call or result: such a chat keeps the full path (some AI companies need the tool list then). */
    fun recentTools(history: JSONArray, n: Int = 10): Boolean {
        for (i in maxOf(0, history.length() - n) until history.length()) {
            val ps = history.getJSONObject(i).optJSONArray("parts") ?: continue
            for (j in 0 until ps.length()) { val p = ps.optJSONObject(j) ?: continue; if (p.has("functionCall") || p.has("functionResponse")) return true }
        }
        return false
    }

    const val BASE = "You are Anjoo AI, a friendly voice and chat assistant on the user's phone. This message is plain small talk: " +
        "reply warmly in one or two short sentences, in the same language and script the user wrote (Urdu, Roman Urdu or English). " +
        "Do not use headings or lists. Do not run tools."

    /** Messages that need the heavy tools (projects, files, documents, code, browser, agents) keep the full tool list. */
    private val HEAVY = Regex("(project|website|web site|webpage|landing|app bana|apk|\\bcode|coding|script|program|github|\\bgit\\b|deploy|folder|directory|\\bfile|pdf|docx|\\bword\\b|excel|xlsx|pptx|slides|presentation|csv|backup|export|import|browser|agent|artifact|dashboard|database|\\bsql|\\bapi\\b|json|html|css|kotlin|python|java|compile|debug|install|download|upload|studio|workspace|schedule|routine|translator|auto.?reply|knowledge|http|www\\.|document|report|resume|\\bcv\\b|\\bdoc\\b)")

    /** Everyday chat, questions and phone commands: a smaller tool list is enough (about a third of the size), so the reply starts sooner. */
    fun isLean(text: String): Boolean {
        val t = text.lowercase(Locale.ROOT)
        return t.length in 1..1500 && !HEAVY.containsMatchIn(t)
    }

    val LEAN_TOOLS: Set<String> = setOf(
        "open_app", "find_contact", "call", "send_sms", "whatsapp_message", "set_alarm", "set_timer", "set_reminder", "list_reminders", "cancel_reminder",
        "web_search", "search_web", "fetch_page", "open_url", "navigate", "flashlight", "volume", "media", "battery", "open_settings", "add_calendar_event", "today_events", "search_calendar",
        "copy_text", "paste_text", "type_text", "send_in_app", "tap_text", "press_key", "tap_image", "look_at_screen", "list_screen", "tap_xy", "swipe", "wait", "read_screen",
        "weather", "play_music", "share_text", "read_sms", "my_location", "read_call_log", "set_daily_briefing", "convert_currency", "news", "prayer_times", "set_prayer_reminders",
        "ledger_add", "ledger_summary", "read_notifications", "reply_message", "send_email", "add_note", "list_notes", "read_note", "delete_note", "add_task", "move_task", "list_tasks", "delete_task",
        "run_python", "generate_image", "search_chats", "current_time", "device_info", "list_tools", "app_map", "ask_model", "remember", "forget", "memory_search", "memory_update",
        "memory_pin", "memory_delete", "list_memory", "memory_done", "knowledge_search"
    )
}
