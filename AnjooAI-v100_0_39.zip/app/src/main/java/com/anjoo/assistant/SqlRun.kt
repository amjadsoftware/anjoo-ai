package com.anjoo.assistant

import android.content.Context
import android.database.Cursor
import android.database.DatabaseUtils
import android.database.sqlite.SQLiteDatabase
import android.os.CancellationSignal
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Local SQL runner for run_code language=sql. It uses the phone's own SQLite, so it works offline and the SQL
 * never leaves the phone. Features: many statements in one script (strings, comments and triggers are split
 * correctly), result tables, rows changed, error with statement number and line, whole run in one transaction
 * (rolled back on error), setup files (schema.sql, seed.sql) run first, a database file inside the project
 * (db=name.db) that is kept between runs, and the shell shortcuts .tables and .schema.
 */
object SqlRun {
    private const val MAX_ROWS = 50
    private const val MAX_LISTED = 40
    private const val CAP = 6000
    private const val TIMEOUT_MS = 20_000L

    data class Stmt(val sql: String, val line: Int)
    private class Job(val stmt: Stmt, val src: String, val show: Boolean)

    // ------------------------------------------------------------------ pure helpers (unit tested)

    /** Splits a script into statements. Semicolons inside quotes, comments and trigger bodies do not split. */
    fun split(script: String): List<Stmt> {
        val out = ArrayList<Stmt>()
        val cur = StringBuilder()
        var line = 1
        var startLine = 1
        val head = ArrayList<String>()
        var inTrigger = false
        var inBody = false
        var bodyEnded = false
        var caseDepth = 0
        var i = 0
        val n = script.length

        fun put(ch: Char) {
            if (cur.isEmpty() && ch.isWhitespace()) return
            if (cur.isEmpty()) startLine = line
            cur.append(ch)
        }
        fun flush() {
            val t = cur.toString().trim()
            if (t.isNotEmpty()) out.add(Stmt(t, startLine))
            cur.setLength(0)
            head.clear()
            inTrigger = false; inBody = false; bodyEnded = false; caseDepth = 0
        }

        while (i < n) {
            val c = script[i]
            if (c == '\n') { line++; put(c); i++; continue }
            if (c == '-' && i + 1 < n && script[i + 1] == '-') {
                while (i < n && script[i] != '\n') i++
                continue
            }
            if (c == '/' && i + 1 < n && script[i + 1] == '*') {
                i += 2
                while (i < n && !(script[i] == '*' && i + 1 < n && script[i + 1] == '/')) { if (script[i] == '\n') line++; i++ }
                i = minOf(n, i + 2)
                put(' ')
                continue
            }
            if (c == '\'' || c == '"' || c == '`' || c == '[') {
                val close = if (c == '[') ']' else c
                put(c); i++
                while (i < n) {
                    val d = script[i]
                    if (d == '\n') line++
                    cur.append(d)
                    i++
                    if (d == close) {
                        if (close != ']' && i < n && script[i] == close) { cur.append(script[i]); i++; continue }
                        break
                    }
                }
                continue
            }
            if (c.isLetterOrDigit() || c == '_') {
                val s = i
                while (i < n && (script[i].isLetterOrDigit() || script[i] == '_')) i++
                val w = script.substring(s, i)
                val up = w.uppercase()
                if (cur.isEmpty()) startLine = line
                cur.append(w)
                if (head.size < 3) head.add(up)
                if (!inTrigger && head.size >= 2 && head[0] == "CREATE" &&
                    (head[1] == "TRIGGER" || (head.size >= 3 && (head[1] == "TEMP" || head[1] == "TEMPORARY") && head[2] == "TRIGGER"))) inTrigger = true
                if (inTrigger) {
                    if (up == "BEGIN") inBody = true
                    else if (inBody && up == "CASE") caseDepth++
                    else if (inBody && up == "END") { if (caseDepth > 0) caseDepth-- else bodyEnded = true }
                }
                continue
            }
            if (c == ';') {
                if (inTrigger && inBody && !bodyEnded) { put(c) } else flush()
                i++
                continue
            }
            put(c); i++
        }
        flush()
        return out
    }

    fun firstWord(sql: String): String = Regex("^\\s*([A-Za-z]+)").find(sql)?.groupValues?.get(1)?.uppercase() ?: ""

    /** True when the statement gives rows back (needs a query, not execSQL). */
    fun isQuery(sql: String): Boolean {
        if (firstWord(sql) in setOf("SELECT", "WITH", "PRAGMA", "VALUES", "EXPLAIN")) return true
        return Regex("\\bRETURNING\\b", RegexOption.IGNORE_CASE).containsMatchIn(sql)
    }

    /** Statements that manage the transaction themselves (or cannot run inside one): the run is then not wrapped. */
    fun controlsTransaction(sql: String): Boolean =
        firstWord(sql) in setOf("BEGIN", "COMMIT", "END", "ROLLBACK", "SAVEPOINT", "RELEASE", "PRAGMA", "VACUUM", "ATTACH", "DETACH")

    /** The sqlite3 shell shortcuts .tables and .schema [table] as SQL, or null when [code] is not one of them. */
    fun dotToSql(code: String): String? {
        val t = code.trim()
        if (t.contains('\n') || !t.startsWith(".")) return null
        val parts = t.split(Regex("\\s+"))
        return when (parts[0].lowercase()) {
            ".tables" -> "SELECT name AS table_name, type FROM sqlite_master WHERE type IN ('table','view') AND name NOT LIKE 'sqlite_%' ORDER BY name"
            ".schema" ->
                if (parts.size > 1) "SELECT sql FROM sqlite_master WHERE sql IS NOT NULL AND tbl_name = '" + parts[1].replace("'", "''") + "' ORDER BY type DESC, name"
                else "SELECT sql FROM sqlite_master WHERE sql IS NOT NULL AND name NOT LIKE 'sqlite_%' ORDER BY type DESC, name"
            else -> null
        }
    }

    private fun cell(s: String): String {
        val one = s.replace("\r", " ").replace("\n", "\\n")
        return if (one.length > 60) one.take(57) + "..." else one
    }

    /** A small text table: header line, then rows, columns joined with " | ". */
    fun formatTable(cols: List<String>, rows: List<List<String>>, total: Int): String {
        val sb = StringBuilder()
        sb.append(cols.joinToString(" | ") { cell(it) }).append("\n")
        for (r in rows) sb.append(r.joinToString(" | ") { cell(it) }).append("\n")
        if (total > rows.size) sb.append("... ").append(total - rows.size).append(" more rows not shown\n")
        return sb.toString().trimEnd()
    }

    fun label(sql: String): String {
        val one = sql.replace(Regex("\\s+"), " ").trim()
        return if (one.length > 70) one.take(67) + "..." else one
    }

    /** A database file name inside the project dir, or null when it escapes the project or has a wrong extension. */
    fun resolveDb(dir: File, name: String): File? {
        val n = name.replace('\\', '/').trim().trim('/')
        if (n.isEmpty() || n.split('/').any { it == ".." || it.isEmpty() }) return null
        if (n.substringAfterLast('.', "").lowercase() !in setOf("db", "sqlite", "sqlite3")) return null
        val f = File(dir, n)
        return try {
            if (f.canonicalPath.startsWith(dir.canonicalPath + File.separator)) f else null
        } catch (e: Exception) { null }
    }

    // ------------------------------------------------------------------ the run

    /** Entry from run_code: [code] is the main script; optional db (file in the project) and setup (project .sql files, comma separated). */
    fun runFromTool(ctx: Context, a: JSONObject, code: String): String {
        Cancel.check()
        val proj = a.optString("project", "").trim()
        val dir: File? = if (proj.isEmpty()) null else (Coder.ensureProject(ctx, proj)
            ?: return "No Code Studio project named '$proj'. Check with project_manage action=list_projects.")
        val dbName = a.optString("db", "").trim()
        val setupRaw = if (a.isNull("setup")) "" else {
            val so = a.opt("setup")
            if (so is JSONArray) (0 until so.length()).joinToString(",") { so.optString(it) } else so.toString()
        }
        if ((dbName.isNotEmpty() || setupRaw.isNotBlank()) && dir == null) return "db and setup work inside a Code Studio project: pass project as well."
        var dbFile: File? = null
        if (dbName.isNotEmpty()) {
            dbFile = resolveDb(dir!!, dbName) ?: return "db must be a file name inside the project that ends in .db, .sqlite or .sqlite3 (no .. and no absolute path)."
        }
        val setup = ArrayList<Pair<String, String>>()
        if (setupRaw.isNotBlank()) {
            val files = Coder.readFiles(dir!!)
            for (p in setupRaw.split(',', ';', '\n').map { it.trim() }.filter { it.isNotEmpty() }) {
                val txt = files[p] ?: return "Setup file not found in the project: $p"
                setup.add(p to txt)
            }
        }
        if (dbFile != null) dbFile.parentFile?.mkdirs()
        return runLocal(code, setup, dbFile, dbName)
    }

    fun runLocal(code: String, setup: List<Pair<String, String>>, dbFile: File?, dbLabel: String): String {
        if (code.length > 200_000) return "The SQL is longer than 200,000 characters; run a smaller script."
        val main = dotToSql(code) ?: code
        val jobs = ArrayList<Job>()
        var setupCount = 0
        for ((p, txt) in setup) for (s in split(txt)) { jobs.add(Job(s, p, false)); setupCount++ }
        for (s in split(main)) jobs.add(Job(s, "", true))
        if (jobs.none { it.show }) return "RUN sql: there is no SQL statement to run (the script is empty or only comments)."
        val note = if (setupCount > 0) "setup: " + setupCount + " statement" + (if (setupCount == 1) "" else "s") + " from " + setup.joinToString(", ") { it.first } else ""
        val sig = CancellationSignal()
        val box = arrayOfNulls<String>(1)
        val t = Thread {
            box[0] = try { execute(jobs, dbFile, dbLabel, note, sig) }
            catch (e: Throwable) { "RUN sql: ERROR " + (e.message ?: e.javaClass.simpleName) }
        }
        t.isDaemon = true
        t.start()
        t.join(TIMEOUT_MS)
        if (t.isAlive) {
            try { sig.cancel() } catch (e: Exception) { }
            return "RUN sql: time limit exceeded (more than " + (TIMEOUT_MS / 1000) + " s). The query was cancelled. Look for an endless recursive CTE or a very large join. Do not claim the SQL worked."
        }
        return box[0] ?: "RUN sql: no result."
    }

    private fun cellText(c: Cursor, i: Int): String = when (c.getType(i)) {
        Cursor.FIELD_TYPE_NULL -> "NULL"
        Cursor.FIELD_TYPE_BLOB -> "<blob " + (c.getBlob(i)?.size ?: 0) + " bytes>"
        else -> c.getString(i) ?: "NULL"
    }

    private fun effect(db: SQLiteDatabase, sql: String): String {
        if (firstWord(sql) in setOf("INSERT", "UPDATE", "DELETE", "REPLACE")) {
            val n = DatabaseUtils.longForQuery(db, "SELECT changes()", null)
            return n.toString() + " row" + (if (n == 1L) "" else "s") + " changed"
        }
        return "OK"
    }

    private fun execute(jobs: List<Job>, dbFile: File?, dbLabel: String, note: String, sig: CancellationSignal): String {
        val t0 = System.currentTimeMillis()
        val db: SQLiteDatabase = try {
            if (dbFile != null) SQLiteDatabase.openOrCreateDatabase(dbFile, null) else SQLiteDatabase.create(null)
        } catch (e: Exception) {
            return "RUN sql: could not open the database (" + (e.message ?: e.javaClass.simpleName) + ")."
        }
        val lines = ArrayList<String>()
        var hidden = 0
        var listed = 0
        var ran = 0
        var mainNo = 0
        var failed = false
        var version = "?"
        val wrapped = jobs.none { controlsTransaction(it.stmt.sql) }
        try {
            db.setForeignKeyConstraintsEnabled(true)
            version = try { DatabaseUtils.stringForQuery(db, "SELECT sqlite_version()", null) } catch (e: Exception) { "?" }
            if (wrapped) db.beginTransaction()
            try {
                for (j in jobs) {
                    val sql = j.stmt.sql
                    if (j.show) mainNo++
                    val head = "[" + mainNo + "] " + label(sql) + " ->"
                    try {
                        if (isQuery(sql)) {
                            val c = db.rawQuery(sql, null, sig)
                            try {
                                val cols = c.columnNames.toList()
                                val total = c.count
                                val rows = ArrayList<List<String>>()
                                while (rows.size < MAX_ROWS && c.moveToNext()) rows.add(cols.indices.map { cellText(c, it) })
                                ran++
                                if (j.show) {
                                    val text = if (cols.isEmpty()) head + " OK"
                                    else head + " " + total + " row" + (if (total == 1) "" else "s") + "\n" + formatTable(cols, rows, total)
                                    if (listed < MAX_LISTED) { lines.add(text); listed++ } else hidden++
                                }
                            } finally { c.close() }
                        } else {
                            db.execSQL(sql)
                            ran++
                            if (j.show) {
                                if (listed < MAX_LISTED) { lines.add(head + " " + effect(db, sql)); listed++ } else hidden++
                            }
                        }
                    } catch (e: Exception) {
                        val msg = (e.message ?: e.javaClass.simpleName).replace(Regex("\\s+"), " ").take(300)
                        val loc = if (j.show) "[" + mainNo + "] ERROR (line " + j.stmt.line + ")" else "[setup] ERROR (" + j.src + ", line " + j.stmt.line + ")"
                        lines.add(loc + ": " + msg + "\n    " + label(sql))
                        failed = true
                        break
                    }
                }
                if (wrapped && !failed) db.setTransactionSuccessful()
            } finally {
                if (wrapped) { try { db.endTransaction() } catch (e: Exception) { } }
            }
        } catch (e: Exception) {
            lines.add("ERROR: " + (e.message ?: e.javaClass.simpleName))
            failed = true
        } finally {
            try { db.close() } catch (e: Exception) { }
        }
        val ms = System.currentTimeMillis() - t0
        val sb = StringBuilder()
        sb.append("RUN sql (SQLite ").append(version).append(", ").append(if (dbFile != null) "file $dbLabel" else "in memory").append("): ")
            .append(if (failed) "ERROR" else "OK").append(" · ").append(ran).append(if (ran == 1) " statement ran" else " statements ran")
            .append(" · ").append(ms).append(" ms\n")
        if (note.isNotEmpty()) sb.append(note).append("\n")
        sb.append("\n").append(lines.joinToString("\n"))
        if (hidden > 0) sb.append("\n(+").append(hidden).append(" more statements ran OK, not listed)")
        if (failed) {
            sb.append("\n\nResult: the SQL failed at the statement above.")
            if (wrapped) sb.append(if (dbFile != null) " Nothing was saved (rolled back)." else "")
            else sb.append(" The script manages its own transaction, so earlier statements may already be applied.")
            sb.append(" Fix it and run again.")
        } else {
            sb.append("\n\nResult: the script ran and finished.")
            sb.append(if (dbFile != null) " Saved to $dbLabel." else " (In-memory database: it is gone now. Pass project + db=name.db to keep data between runs.)")
        }
        val text = sb.toString().trim()
        return if (text.length > CAP) text.take(CAP) + "\n... (output cut at $CAP characters)" else text
    }
}
