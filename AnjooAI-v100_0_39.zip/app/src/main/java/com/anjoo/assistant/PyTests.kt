package com.anjoo.assistant

import android.content.Context
import java.io.File

/**
 * Python unit tests (unittest) for a Code Studio project. They run INSIDE the app (Pyodide, offline after the first
 * download), so a test result is a real result and nothing leaves the phone.
 *
 * The old runner used unittest discovery, which in Python 3.11+ skips a tests/ folder that has no __init__.py,
 * so tests in tests/test_x.py were silently never found. This runner loads every test file by its path instead.
 */
object PyTests {

    private val NAME = Regex("(^|/)(test_[^/]*|[^/]*_test)\\.py$")

    /** True for test_x.py, x_test.py and any .py file inside a tests/ folder (except __init__ and conftest). */
    fun isTest(path: String): Boolean {
        if (!path.endsWith(".py")) return false
        val n = path.substringAfterLast('/')
        if (n == "__init__.py" || n == "conftest.py") return false
        if (NAME.containsMatchIn(path)) return true
        return path.startsWith("tests/") || path.contains("/tests/")
    }

    fun testFiles(paths: Collection<String>): List<String> = paths.filter { isTest(it) }.sorted()

    /** A project file with top level functions or classes can be unit tested. */
    private val DEF = Regex("(?m)^(def|class)\\s+\\w+")

    /** Source modules a Test Agent can write tests for (never test files, setup.py or files that need a window or a server). */
    fun testable(files: Map<String, String>): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for ((k, v) in files) {
            if (!k.endsWith(".py") || isTest(k)) continue
            val n = k.substringAfterLast('/')
            if (n == "setup.py" || n == "__init__.py" || n == "conftest.py") continue
            if (k.contains("venv/") || k.contains("site-packages/")) continue
            if (DEF.containsMatchIn(v)) out[k] = v
        }
        return out
    }

    internal const val RUNNER_NAME = "_anjoo_run_tests.py"
    internal const val LIST_NAME = "_anjoo_tests.txt"

    /** The Python that loads each listed test file by path and runs them all; the last line is machine readable. */
    internal val RUNNER = """
import sys, os, unittest, importlib.util
root = os.getcwd()
sys.path.insert(0, root)
paths = [l.strip() for l in open(os.path.join(root, '_anjoo_tests.txt'), encoding='utf-8').read().splitlines() if l.strip()]
suite = unittest.TestSuite()
loader = unittest.TestLoader()
load_errors = 0
for rel in paths:
    full = os.path.join(root, rel)
    d = os.path.dirname(full)
    if d not in sys.path:
        sys.path.insert(0, d)
    name = rel[:-3].replace('/', '.')
    try:
        spec = importlib.util.spec_from_file_location(name, full)
        mod = importlib.util.module_from_spec(spec)
        sys.modules[name] = mod
        spec.loader.exec_module(mod)
        suite.addTests(loader.loadTestsFromModule(mod))
    except BaseException as e:
        load_errors += 1
        print("LOAD ERROR in %s: %s: %s" % (rel, type(e).__name__, e))
res = unittest.TextTestRunner(verbosity=2, stream=sys.stdout).run(suite)
print("ANJOO_RESULT ran=%d failures=%d errors=%d load_errors=%d" % (res.testsRun, len(res.failures), len(res.errors), load_errors))
""".trimStart()

    /** What happened. [ran] is false when the tests could not be run at all (runtime missing, timeout, nothing to run). */
    class Outcome(val ran: Boolean, val tests: Int, val failures: Int, val errors: Int, val loadErrors: Int, val text: String) {
        val ok: Boolean get() = ran && tests > 0 && failures == 0 && errors == 0 && loadErrors == 0
        val bad: Boolean get() = ran && (failures > 0 || errors > 0 || loadErrors > 0)
    }

    private val RESULT = Regex("ANJOO_RESULT ran=(\\d+) failures=(\\d+) errors=(\\d+) load_errors=(\\d+)")

    /** Reads the runner's output. A missing result line means the run did not get to the end. */
    fun parse(out: String): Outcome {
        val m = RESULT.find(out) ?: return Outcome(false, 0, 0, 0, 0, out.trim())
        val g = m.groupValues
        val body = out.substringBefore("ANJOO_RESULT").trim()
        return Outcome(true, g[1].toInt(), g[2].toInt(), g[3].toInt(), g[4].toInt(), body)
    }

    /** Only the part of the output a person (or the fixing model) needs: the failures, not every passing line. */
    fun failureText(o: Outcome, max: Int = 3500): String {
        val lines = o.text.lines()
        val keep = ArrayList<String>()
        var on = false
        for (l in lines) {
            if (l.startsWith("LOAD ERROR")) { keep.add(l); continue }
            if (l.startsWith("=====") || l.startsWith("ERROR:") || l.startsWith("FAIL:")) on = true
            if (on) keep.add(l)
        }
        val t = (if (keep.isEmpty()) o.text else keep.joinToString("\n")).trim()
        return if (t.length > max) t.take(max) + "\n... (cut)" else t
    }

    /** One honest line for the reply. */
    fun line(o: Outcome, fixed: Int = 0, label: String = "Python unittest, run on the phone"): String {
        if (!o.ran) return "🧪 Tests written but NOT run (the runner did not load, was declined or did not finish). Use the project menu, Run tests."
        if (o.tests == 0 && o.loadErrors == 0) return "🧪 Tests written, but no test was found to run."
        if (o.ok) return "✅ Tests: all " + o.tests + " passed" + (if (fixed > 0) " after fixing " + fixed + " file(s)" else "") + " (" + label + ")."
        val first = failureText(o, 600).lines().filter { it.isNotBlank() }.take(2).joinToString(" | ") { it.take(120) }
        return "⚠ Tests: " + o.failures + " failed, " + o.errors + " error(s)" + (if (o.loadErrors > 0) ", " + o.loadErrors + " test file(s) could not load" else "") +
            " of " + o.tests + " run" + (if (fixed > 0) " (still open after fixing " + fixed + " file(s))" else "") + ". " + first
    }

    /** Runs every test file of [dir] on a temporary copy, so the project never gets runner files. Blocking: call from a background thread. */
    fun run(ctx: Context, dir: File, only: String = ""): Outcome {
        val files = Coder.readFiles(dir)
        var tests = testFiles(files.keys)
        if (only.isNotBlank()) tests = tests.filter { it == only || it.endsWith("/$only") }
        if (tests.isEmpty()) return Outcome(false, 0, 0, 0, 0, "No Python test file found (test_*.py or a file in tests/).")
        val tmp = File(ctx.cacheDir, "pytests-" + System.currentTimeMillis())
        return try {
            for ((p, c) in files) {
                if (p.contains("..")) continue
                val f = File(tmp, p)
                f.parentFile?.mkdirs()
                f.writeText(c, Charsets.UTF_8)
            }
            File(tmp, RUNNER_NAME).writeText(RUNNER, Charsets.UTF_8)
            File(tmp, LIST_NAME).writeText(tests.joinToString("\n"), Charsets.UTF_8)
            val r = PyRun.run(ctx, tmp, RUNNER_NAME, false, 70000, 60000)
            if (!r.loaded) return Outcome(false, 0, 0, 0, 0, "The Python runtime did not load (internet is needed the first time).")
            if (!r.finished) return Outcome(false, 0, 0, 0, 0, "The tests did not finish within 60 seconds (an endless loop or very heavy code).")
            val o = parse(r.out + "\n" + r.err)
            if (o.ran) o else Outcome(false, 0, 0, 0, 0, (r.out + "\n" + r.err).trim().takeLast(1500))
        } catch (e: Exception) {
            Outcome(false, 0, 0, 0, 0, "Python tests could not run: " + (e.message ?: e.javaClass.simpleName))
        } finally { try { tmp.deleteRecursively() } catch (e: Exception) {} }
    }

    /** Text for the chat tool project_check action=test. */
    fun report(o: Outcome): String = when {
        !o.ran -> o.text
        o.ok -> "TEST RESULT: PASS - all " + o.tests + " Python tests passed (run on the phone).\n\n" + o.text.lines().takeLast(14).joinToString("\n")
        else -> "TEST RESULT: FAIL - " + o.failures + " failed, " + o.errors + " error(s), " + o.loadErrors + " file(s) not loadable, of " + o.tests + " tests.\n\n" + failureText(o, 6000) +
            "\n\nDecide for each failure whether the CODE or the TEST EXPECTATION is wrong, fix that one, and run the tests again. Never weaken a correct test just to make it pass."
    }
}
