package com.anjoo.assistant

import android.content.Context
import android.graphics.Typeface

/** User-chosen font for chat text: Sans (default), Serif, Rounded or Mono. Saved in the app settings. */
object FontPref {
    const val KEY = "font_idx"
    val labels = arrayOf("Sans (default)", "Serif", "Rounded", "Mono")
    private val families = arrayOf("sans-serif", "serif", "casual", "monospace")
    const val DEFAULT_IDX = 0

    fun index(ctx: Context): Int = try {
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getInt(KEY, DEFAULT_IDX).coerceIn(0, families.size - 1)
    } catch (e: Exception) { DEFAULT_IDX }

    fun label(ctx: Context): String = labels[index(ctx)]

    fun set(ctx: Context, idx: Int) {
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit().putInt(KEY, idx.coerceIn(0, families.size - 1)).apply()
    }

    fun family(idx: Int): String = families[idx.coerceIn(0, families.size - 1)]

    /** Typeface for normal chat text in the chosen font. */
    fun body(ctx: Context): Typeface = Typeface.create(family(index(ctx)), Typeface.NORMAL)
}
