package com.anjoo.assistant

import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Container for the keys shipped inside a private build (assets/keys.sealed), so they are NOT readable as plain text
 * when someone unzips the APK or runs "strings" on it. Format: "ANJ1" + 16-byte nonce + ciphertext + 32-byte HMAC.
 * Cipher: XOR with a SHA-256 counter keystream; integrity: HMAC-SHA256. Standard library only, so tools/seal_keys.py
 * (which makes the file) matches it exactly.
 *
 * Honest limit: the unlock key is inside the app, so this only stops casual extraction. Someone who reverse-engineers
 * the APK can still recover the keys. The only real protection is keeping the keys on a server.
 */
internal object SealedKeys {
    private val MAGIC = byteArrayOf('A'.code.toByte(), 'N'.code.toByte(), 'J'.code.toByte(), '1'.code.toByte())

    private fun secret(): ByteArray {
        val parts = listOf("anjoo", "ai", "sealed", "keys", "v1", "7f3c", "d41e", "9b20")
        return MessageDigest.getInstance("SHA-256").digest(parts.joinToString("|").toByteArray(Charsets.UTF_8))
    }

    private fun stream(key: ByteArray, nonce: ByteArray, len: Int): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        val out = ByteArray(len)
        var pos = 0
        var i = 0
        while (pos < len) {
            md.update(key); md.update(nonce)
            md.update(byteArrayOf((i ushr 24).toByte(), (i ushr 16).toByte(), (i ushr 8).toByte(), i.toByte()))
            val block = md.digest()
            val n = minOf(block.size, len - pos)
            System.arraycopy(block, 0, out, pos, n)
            pos += n; i++
        }
        return out
    }

    private fun mac(key: ByteArray, data: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(data)
    }

    /** Decrypts a sealed file; null when it is damaged, changed, or not a sealed file. */
    fun open(blob: ByteArray): String? {
        if (blob.size < 4 + 16 + 32) return null
        for (i in 0 until 4) if (blob[i] != MAGIC[i]) return null
        val key = secret()
        val nonce = blob.copyOfRange(4, 20)
        val ct = blob.copyOfRange(20, blob.size - 32)
        val tag = blob.copyOfRange(blob.size - 32, blob.size)
        if (!MessageDigest.isEqual(tag, mac(key, nonce + ct))) return null
        val ks = stream(key, nonce, ct.size)
        val plain = ByteArray(ct.size) { (ct[it].toInt() xor ks[it].toInt()).toByte() }
        return String(plain, Charsets.UTF_8)
    }

    /** Used by tests (tools/seal_keys.py does the same in Python). */
    fun seal(text: String, nonce: ByteArray): ByteArray {
        val key = secret()
        val plain = text.toByteArray(Charsets.UTF_8)
        val ks = stream(key, nonce, plain.size)
        val ct = ByteArray(plain.size) { (plain[it].toInt() xor ks[it].toInt()).toByte() }
        return MAGIC + nonce + ct + mac(key, nonce + ct)
    }
}
