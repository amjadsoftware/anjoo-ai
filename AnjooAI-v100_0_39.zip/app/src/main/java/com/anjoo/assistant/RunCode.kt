package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64

/**
 * run_code: compiles and runs source code in many languages (Kotlin, Java, C, C++, Go, Rust, PHP, Ruby, Node.js,
 * TypeScript, C#, Swift, Bash, Dart, SQL ...) on an online sandbox that speaks the Judge0 API, and returns the real
 * output or the real compiler error. The code leaves the phone, so the user is asked once per app run.
 * Default server: https://ce.judge0.com (public, rate limited). Settings > "Code runner" (keys "judge0_url", "judge0_key")
 * can point to the user's own Judge0 server and has a Test button. When the main server is busy, down or refuses, the run
 * falls back to Wandbox (wandbox.org) for the languages it has (everything except Kotlin, Dart, R). Python without extra packages and web pages still run on the phone (run_python, project_check).
 * SQL is the exception: it runs on the phone's own SQLite (see SqlRun), offline, with optional db file and setup files.
 * MULTI-FILE: a project with several source files of one language (Main.kt + Util.kt, main.go + util.go, main.c + util.c ...)
 * is sent as a whole: Judge0 "Multi-file program" (a zip with generated compile/run scripts); on failure Wandbox gets the
 * files too for C, C++, Python, JavaScript, Ruby, PHP, Rust, Lua, Perl. The sandbox has no internet, so no npm/pip/Gradle/Cargo
 * packages: standard library only (Rust: rustc, not cargo). Also accepted: files={"path":"content",...} without a project.
 */
object RunCode {
    private const val DEFAULT_URL = "https://ce.judge0.com"
    private const val CAP = 6000
    @Volatile private var approved = false
    @Volatile private var cachedLangs: JSONArray? = null

    // our language key -> prefix of the Judge0 language name (lower case)
    private val NAME_PREFIX = linkedMapOf(
        "python" to "python (3", "javascript" to "javascript (node", "typescript" to "typescript", "java" to "java (",
        "kotlin" to "kotlin", "c" to "c (gcc", "cpp" to "c++ (gcc", "csharp" to "c# (", "go" to "go (", "rust" to "rust",
        "php" to "php", "ruby" to "ruby", "swift" to "swift", "bash" to "bash", "dart" to "dart", "sql" to "sql (sqlite",
        "r" to "r (", "lua" to "lua", "perl" to "perl", "scala" to "scala", "haskell" to "haskell"
    )
    // used only when the server's language list cannot be read (Judge0 CE ids)
    private val FALLBACK_ID = mapOf(
        "python" to 71, "javascript" to 63, "typescript" to 74, "java" to 62, "kotlin" to 78, "c" to 50, "cpp" to 54,
        "csharp" to 51, "go" to 60, "rust" to 73, "php" to 68, "ruby" to 72, "swift" to 83, "bash" to 46, "sql" to 82,
        "r" to 80, "lua" to 64, "perl" to 85, "scala" to 81, "haskell" to 61
    )
    private val ALIAS = mapOf(
        "py" to "python", "python3" to "python", "js" to "javascript", "node" to "javascript", "nodejs" to "javascript", "mjs" to "javascript",
        "ts" to "typescript", "kt" to "kotlin", "kts" to "kotlin", "c++" to "cpp", "cc" to "cpp", "cxx" to "cpp", "h" to "c", "cs" to "csharp", "c#" to "csharp",
        "golang" to "go", "rs" to "rust", "rb" to "ruby", "sh" to "bash", "shell" to "bash", "zsh" to "bash", "pl" to "perl", "hs" to "haskell", "sqlite" to "sql"
    )

    /** "Kotlin", "c++", "main.rs" -> our key ("kotlin", "cpp", "rust"), or "" when unknown. */
    fun normLang(raw: String): String {
        var s = raw.trim().lowercase()
        if (s.contains('.') && !s.startsWith(".") && s.length > 2 && s != "c++" && s != "c#") s = s.substringAfterLast('.')
        s = s.trimStart('.')
        val k = ALIAS[s] ?: s
        return if (NAME_PREFIX.containsKey(k)) k else ""
    }

    /** The Judge0 language id for [key] from the server's /languages list (newest version wins), or the built-in id. */
    fun pickId(list: JSONArray?, key: String): Int {
        val prefix = NAME_PREFIX[key] ?: return -1
        var best = -1
        if (list != null) for (i in 0 until list.length()) {
            val o = list.optJSONObject(i) ?: continue
            if (o.optString("name").lowercase().startsWith(prefix)) best = maxOf(best, o.optInt("id", -1))
        }
        return if (best > 0) best else (FALLBACK_ID[key] ?: -1)
    }

    private fun b64(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(Charsets.UTF_8))
    private fun unb64(s: String?): String =
        if (s.isNullOrEmpty() || s == "null") "" else try { String(Base64.getMimeDecoder().decode(s), Charsets.UTF_8) } catch (e: Exception) { s }

    /** Turns a Judge0 answer (base64 fields) into a short report for the AI. */
    fun format(lang: String, r: JSONObject): String {
        val status = r.optJSONObject("status")
        val id = status?.optInt("id", 0) ?: 0
        val desc = status?.optString("description", "") ?: ""
        val out = unb64(r.optString("stdout", "")).trimEnd()
        val err = unb64(r.optString("stderr", "")).trimEnd()
        val compile = unb64(r.optString("compile_output", "")).trimEnd()
        val msg = unb64(r.optString("message", "")).trimEnd()
        val sb = StringBuilder()
        sb.append("RUN ").append(lang).append(": ").append(desc.ifEmpty { "finished" })
        val time = r.optString("time", "")
        if (time.isNotEmpty() && time != "null") sb.append(" · ").append(time).append("s")
        val mem = r.optInt("memory", 0)
        if (mem > 0) sb.append(" · ").append(mem / 1024).append(" MB")
        sb.append("\n")
        if (compile.isNotEmpty()) sb.append("\nCOMPILER OUTPUT:\n").append(compile).append("\n")
        if (out.isNotEmpty()) sb.append("\nOUTPUT:\n").append(out).append("\n")
        if (err.isNotEmpty()) sb.append("\nERROR OUTPUT:\n").append(err).append("\n")
        if (msg.isNotEmpty()) sb.append("\nNOTE: ").append(msg).append("\n")
        if (out.isEmpty() && err.isEmpty() && compile.isEmpty()) sb.append("(no output)\n")
        when (id) {
            3 -> sb.append("\nResult: the program ran and finished.")
            5 -> sb.append("\nResult: time limit exceeded (infinite loop or too slow).")
            6 -> sb.append("\nResult: it did not compile. Fix the compiler errors above and run again.")
            in 7..12 -> sb.append("\nResult: the program crashed at runtime. Fix the error above and run again.")
        }
        val text = sb.toString().trim()
        return if (text.length > CAP) text.take(CAP) + "\n... (output cut at $CAP characters)" else text
    }

    private fun base(ctx: Context): String {
        val u = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getString("judge0_url", "") ?: ""
        return (if (u.startsWith("https://")) u else DEFAULT_URL).trimEnd('/')
    }

    private fun call(ctx: Context, method: String, path: String, body: String?): Pair<Int, String> {
        val prefs = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val conn = URL(base(ctx) + path).openConnection() as HttpURLConnection
        Cancel.track(conn)
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 45000
        conn.setRequestProperty("Accept", "application/json")
        val key = prefs.getString("judge0_key", "") ?: ""
        if (key.isNotBlank()) conn.setRequestProperty("X-Auth-Token", key.trim())
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        return code to text
    }

    private fun languages(ctx: Context): JSONArray? {
        cachedLangs?.let { return it }
        return try {
            val (c, t) = call(ctx, "GET", "/languages", null)
            if (c in 200..299) JSONArray(t).also { cachedLangs = it } else null
        } catch (e: Exception) { null }
    }

    /** The source to run: given code, or one file of a Code Studio project. Returns (language key, code) or an error string. */
    private fun source(ctx: Context, a: JSONObject): Pair<Pair<String, String>?, String> {
        var code = a.optString("code", "")
        var lang = normLang(a.optString("language", ""))
        val proj = a.optString("project", "").trim()
        val path = a.optString("path", "").trim()
        if (code.isBlank() && proj.isNotEmpty()) {
            val dir = Coder.ensureProject(ctx, proj) ?: return null to "No Code Studio project named '$proj'. Check with project_manage action=list_projects."
            val files = Coder.readFiles(dir)
            val p = if (path.isNotEmpty()) path else (entryOf(files.keys) ?: (if (lang == "sql") sqlEntry(files.keys) else null)
                ?: return null to "No entry file found. Give path, for example src/main.rs.")
            code = files[p] ?: return null to "File not found in the project: $p"
            if (lang.isEmpty()) lang = normLang(p.substringAfterLast('/'))
        }
        if (code.isBlank()) return null to "Give code, or project and path of a file to run."
        if (lang.isEmpty()) return null to "Unknown language. Use one of: " + NAME_PREFIX.keys.joinToString(", ") + "."
        return (lang to code) to ""
    }

    private val ENTRY_NAMES = listOf("main.kt", "Main.kt", "Main.java", "main.java", "main.go", "main.rs", "src/main.rs", "main.c", "main.cpp", "Program.cs", "main.cs",
        "index.js", "main.js", "app.js", "main.ts", "index.ts", "main.php", "index.php", "main.rb", "main.swift", "main.dart", "main.sh", "main.lua", "main.pl")

    /** For SQL projects: query.sql if there is one, else the first .sql file that is not a schema or seed file, else any .sql file. */
    fun sqlEntry(paths: Collection<String>): String? {
        val sql = paths.filter { it.lowercase().endsWith(".sql") }.sorted()
        return sql.firstOrNull { it.substringAfterLast('/').lowercase() == "query.sql" }
            ?: sql.firstOrNull { val n = it.substringAfterLast('/').lowercase(); !n.contains("schema") && !n.contains("seed") && !n.contains("migrat") }
            ?: sql.firstOrNull()
    }

    /** The most likely file to start a project from, or null. */
    fun entryOf(paths: Collection<String>): String? =
        ENTRY_NAMES.firstOrNull { it in paths } ?: ENTRY_NAMES.firstNotNullOfOrNull { n -> paths.firstOrNull { it.endsWith("/$n") } }

    fun run(ctx: Context, confirm: (String) -> Boolean, a: JSONObject, test: Boolean = false): String {
        val multi = multiSet(ctx, a)
        if (multi != null) {
            if (multi.error != null) return multi.error
            return runMulti(ctx, confirm, multi.lang, multi.entry, multi.files, a.optString("stdin", ""), test)
        }
        val (src, err) = source(ctx, a)
        if (src == null) return err
        val (lang, code) = src
        if (lang == "sql") return SqlRun.runFromTool(ctx, a, code)   // local SQLite: offline, nothing leaves the phone
        return runSource(ctx, confirm, lang, code, a.optString("stdin", ""), test)
    }

    /** Runs [code] as one file of language [lang] (our key, e.g. "javascript"): asks the user once, tries Judge0, then Wandbox. */
    fun runSource(ctx: Context, confirm: (String) -> Boolean, lang: String, code: String, stdin: String, test: Boolean = false): String {
        if (lang == "sql") return SqlRun.runLocal(code, emptyList(), null, "")
        if (code.length > 100_000) return "The source is longer than 100,000 characters; run a smaller file."
        approval(ctx, confirm, lang, 1, test)?.let { return it }
        val main = try { runJudge0(ctx, lang, code, stdin) } catch (e: CancelledException) { throw e } catch (e: Exception) { null to ("Could not reach the online runner (" + (e.message ?: e.javaClass.simpleName) + ").") }
        if (main.first != null) return main.first!! + "\n(server: " + base(ctx).removePrefix("https://") + ")"
        // Main server busy, down or refusing: try the backup server for the languages it has.
        val backup = runWandbox(lang, code, stdin)
        if (backup != null) return backup
        return main.second + " The code was not run, so do not claim it passed."
    }

    /** Returns (report, "") when the run happened, or (null, reason) when the server could not run it. */
    private fun runJudge0(ctx: Context, lang: String, code: String, stdin: String): Pair<String?, String> {
        val id = pickId(languages(ctx), lang)
        if (id < 0) return null to "No server language for $lang."
        val body = JSONObject().put("language_id", id).put("source_code", b64(code))
        if (stdin.isNotEmpty()) body.put("stdin", b64(stdin))
        val (c, t) = call(ctx, "POST", SUBMIT, body.toString())
        return judgeAnswer(lang, c, t)
    }

    private const val SUBMIT = "/submissions?base64_encoded=true&wait=true&fields=stdout,stderr,compile_output,message,status,time,memory"

    private fun judgeAnswer(lang: String, c: Int, t: String): Pair<String?, String> = when {
        c in 200..299 -> format(lang, JSONObject(t)) to ""
        c == 429 -> null to "The online runner is busy (too many runs)."
        c == 401 || c == 403 -> null to "The online runner refused the request ($c); it may need a key (Settings > Code runner)."
        else -> null to ("The online runner failed ($c). " + t.take(160))
    }

    /** Asks the user once per app run. Returns the "declined" text, or null when the run may go ahead. */
    private fun approval(ctx: Context, confirm: (String) -> Boolean, lang: String, nFiles: Int, test: Boolean): String? {
        if (approved || test) return null
        val what = if (nFiles > 1) "this $lang project ($nFiles files)" else "this $lang code"
        if (!confirm(Confirm.msg("run", "Run $what online?", "The code is sent to " + base(ctx).removePrefix("https://") + " (and to wandbox.org if that server is busy) to be compiled and run, and the output comes back. Do not run code that holds passwords or keys."))) return "The user declined to run the code online."
        approved = true
        return null
    }

    // ------------------------------------------------------------------ several files in one run

    class MultiSet(val lang: String, val entry: String, val files: Map<String, String>, val error: String?)
    class Plan(val compile: String?, val run: String)

    private const val MAX_MULTI_FILES = 80
    private const val MAX_MULTI_CHARS = 600_000
    private val MULTI_SKIP = Regex("(^|/)(node_modules|vendor|dist|build|target|out|tests|\\.git|\\.gradle|\\.idea|__pycache__)/")
    private val WB_MULTI = setOf("c", "cpp", "python", "javascript", "ruby", "php", "rust", "lua", "perl")

    /** Single-quotes [s] for a shell script. */
    fun shq(s: String): String = "'" + s.replace("'", "'\\''") + "'"

    private fun pkgOf(code: String?): String =
        if (code == null) "" else Regex("(?m)^\\s*package\\s+([\\w.]+)").find(code)?.groupValues?.get(1)?.let { "$it." } ?: ""

    /** The compile and run shell commands for a [lang] project whose entry file is [entry], or null when the language has no multi-file recipe. */
    fun plan(lang: String, entry: String, files: Map<String, String>): Plan? {
        val e = shq(entry)
        fun list(vararg ext: String) = files.keys.filter { p -> ext.any { p.endsWith(".$it") } }.sorted().joinToString(" ") { shq(it) }
        val base = entry.substringAfterLast('/').substringBeforeLast('.')
        return when (lang) {
            "python" -> Plan(null, "python3 $e")
            "javascript" -> Plan(null, "node $e")
            "ruby", "php", "lua", "perl" -> Plan(null, "$lang $e")
            "bash" -> Plan(null, "bash $e")
            "c" -> Plan("gcc -O2 -I. -o app ${list("c")} -lm", "./app")
            "cpp" -> Plan("g++ -std=c++17 -O2 -I. -o app ${list("cpp", "cc", "cxx")}", "./app")
            "java" -> Plan("javac -d out ${list("java")}", "java -cp out " + pkgOf(files[entry]) + base)
            "kotlin" -> Plan("kotlinc ${list("kt")} -include-runtime -d app.jar", "java -cp app.jar " + pkgOf(files[entry]) + base.replaceFirstChar { it.uppercase() } + "Kt")
            "go" -> {
                val dir = entry.substringBeforeLast('/', "")
                Plan("export GOCACHE=\"\$PWD/.gocache\" GOPATH=\"\$PWD/.gopath\"\n[ -f go.mod ] || go mod init app >/dev/null 2>&1\ngo build -o app " + (if (dir.isEmpty()) "." else shq("./$dir")), "./app")
            }
            "rust" -> Plan("rustc --edition 2021 -O -o app $e", "./app")
            "csharp" -> Plan("mcs -out:app.exe ${list("cs")}", "mono app.exe")
            "typescript" -> Plan("tsc --target es2020 --module commonjs --outDir out --rootDir . ${list("ts")}", "node " + shq("out/" + entry.removeSuffix(".ts") + ".js"))
            "swift" -> Plan("swiftc -o app ${list("swift")}", "./app")
            else -> null
        }
    }

    /** True when a project has more than one source file of [lang]. */
    private fun sameLangCount(files: Map<String, String>, lang: String) = files.keys.count { normLang(it) == lang }

    /**
     * Decides whether this call is a multi-file run: files={...} was given, or project=... has several files of the entry's language
     * (single=true forces the old one-file run, multi=true forces a whole-project run). Null means "run one file as before".
     */
    fun multiSet(ctx: Context, a: JSONObject): MultiSet? {
        if (a.optBoolean("single", false)) return null
        val path = a.optString("path", "").trim()
        var lang = normLang(a.optString("language", ""))
        val explicit = a.optBoolean("multi", false)
        val given = a.optJSONObject("files") ?: a.optString("files", "").trim().takeIf { it.startsWith("{") }?.let { try { JSONObject(it) } catch (_: Exception) { null } }
        val files = LinkedHashMap<String, String>()
        if (given != null) {
            for (k in given.keys()) files[k.trim().trimStart('/')] = given.optString(k, "")
        } else {
            val proj = a.optString("project", "").trim()
            if (proj.isEmpty() || a.optString("code", "").isNotBlank()) return null
            val dir = Coder.ensureProject(ctx, proj) ?: return null
            for ((p, c) in Coder.readFiles(dir)) if (!MULTI_SKIP.containsMatchIn(p)) files[p] = c
        }
        val entry = if (path.isNotEmpty()) path.trimStart('/') else (entryOf(files.keys) ?: "")
        if (entry.isEmpty() || !files.containsKey(entry)) {
            return if (given != null || explicit) MultiSet("", "", files, "Multi-file run needs the entry file: give path=, for example src/main.rs (files in the set: " + files.keys.take(20).joinToString(", ") + ").") else null
        }
        if (lang.isEmpty()) lang = normLang(entry)
        if (lang.isEmpty() || lang == "sql") return null
        if (given == null && !explicit && sameLangCount(files, lang) < 2) return null
        if (files.keys.any { it.contains("..") }) return MultiSet(lang, entry, files, "A file path with '..' is not allowed.")
        if (files.size > MAX_MULTI_FILES || files.values.sumOf { it.length } > MAX_MULTI_CHARS)
            return MultiSet(lang, entry, files, "The project is too big for one online run (more than $MAX_MULTI_FILES files or $MAX_MULTI_CHARS characters). Run a smaller set with files={path: content} or run one file with single=true.")
        if (plan(lang, entry, files) == null) {
            return if (given != null || explicit) MultiSet(lang, entry, files, "Whole-project runs are not supported for $lang yet. Run one file with single=true.") else null
        }
        return MultiSet(lang, entry, files, null)
    }

    fun zipBytes(files: Map<String, String>): ByteArray {
        val bo = java.io.ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(bo).use { z ->
            for ((p, c) in files) { z.putNextEntry(java.util.zip.ZipEntry(p)); z.write(c.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        }
        return bo.toByteArray()
    }

    private const val SCRIPT_HEAD = "export PATH=\"\$(ls -d /usr/local/*/bin 2>/dev/null | tr '\\n' ':')\$PATH\"\nexport HOME=\"\$PWD\"\n"

    /** The zip Judge0's "Multi-file program" language wants: the project files plus a `compile` (optional) and a `run` script. */
    fun judgeZip(plan: Plan, files: Map<String, String>): ByteArray {
        val all = LinkedHashMap(files)
        if (plan.compile != null) all["compile"] = SCRIPT_HEAD + plan.compile + "\n"
        all["run"] = SCRIPT_HEAD + plan.run + "\n"
        return zipBytes(all)
    }

    private fun multiId(list: JSONArray?): Int {
        if (list != null) for (i in 0 until list.length()) {
            val o = list.optJSONObject(i) ?: continue
            if (o.optString("name").lowercase().startsWith("multi-file")) return o.optInt("id", 89)
        }
        return 89
    }

    /** Runs a whole project ([files], starting at [entry]) in [lang]: Judge0 multi-file first, then Wandbox for the languages it can take. */
    fun runMulti(ctx: Context, confirm: (String) -> Boolean, lang: String, entry: String, files: Map<String, String>, stdin: String, test: Boolean = false): String {
        val plan = plan(lang, entry, files) ?: return "Whole-project runs are not supported for $lang. Run one file with single=true."
        approval(ctx, confirm, lang, files.size, test)?.let { return it }
        val main = try {
            val body = JSONObject().put("language_id", multiId(languages(ctx)))
                .put("additional_files", Base64.getEncoder().encodeToString(judgeZip(plan, files)))
            if (stdin.isNotEmpty()) body.put("stdin", b64(stdin))
            val (c, t) = call(ctx, "POST", SUBMIT, body.toString())
            judgeAnswer("$lang project (${files.size} files, entry $entry)", c, t)
        } catch (e: CancelledException) { throw e } catch (e: Exception) { null to ("Could not reach the online runner (" + (e.message ?: e.javaClass.simpleName) + ").") }
        if (main.first != null) return main.first!! + "\n(server: " + base(ctx).removePrefix("https://") + ", multi-file)"
        val backup = runWandboxMulti(lang, entry, files, stdin)
        if (backup != null) return backup
        return main.second + " The project was not run, so do not claim it passed."
    }

    // ------------------------------------------------------------------ backup server: Wandbox

    private const val WANDBOX = "https://wandbox.org"
    @Volatile private var cachedWandbox: JSONArray? = null
    private val WB_LANG = mapOf(
        "python" to "python", "javascript" to "javascript", "typescript" to "typescript", "java" to "java", "c" to "c", "cpp" to "c++",
        "csharp" to "c#", "go" to "go", "rust" to "rust", "php" to "php", "ruby" to "ruby", "swift" to "swift", "bash" to "bash script",
        "lua" to "lua", "perl" to "perl", "scala" to "scala", "haskell" to "haskell", "sql" to "sql"
    )
    private val WB_PREFER = mapOf("c" to "gcc", "cpp" to "gcc", "python" to "cpython", "javascript" to "nodejs")

    private fun versionKey(name: String): List<Int> = Regex("\\d+").findAll(name).map { it.value.toIntOrNull() ?: 0 }.toList()

    private fun cmpVersion(a: List<Int>, b: List<Int>): Int {
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }; val y = b.getOrElse(i) { 0 }
            if (x != y) return x.compareTo(y)
        }
        return 0
    }

    /** The newest stable Wandbox compiler name for [key] (not "head"/trunk builds), or null when Wandbox has none. */
    fun pickWandbox(list: JSONArray?, key: String): String? {
        val lang = WB_LANG[key] ?: return null
        if (list == null) return null
        val prefer = WB_PREFER[key]
        val all = ArrayList<String>()
        for (i in 0 until list.length()) {
            val o = list.optJSONObject(i) ?: continue
            if (o.optString("language").lowercase() == lang) all.add(o.optString("name"))
        }
        var pool = all.filter { it.isNotEmpty() && !it.contains("head") }
        if (pool.isEmpty()) pool = all.filter { it.isNotEmpty() }
        if (prefer != null) pool.filter { it.startsWith(prefer) }.takeIf { it.isNotEmpty() }?.let { pool = it }
        var best: String? = null
        for (n in pool) if (best == null || cmpVersion(versionKey(n), versionKey(best)) >= 0) best = n
        return best
    }

    /** Wandbox answer -> the same kind of report as [format]. */
    fun formatWandbox(lang: String, r: JSONObject): String {
        val out = r.optString("program_output", "").trimEnd()
        val err = r.optString("program_error", "").trimEnd()
        val compile = r.optString("compiler_error", "").trimEnd()
        val status = r.optString("status", "")
        val signal = r.optString("signal", "")
        val sb = StringBuilder("RUN ").append(lang).append(": ")
        val compileFailed = compile.isNotEmpty() && out.isEmpty() && status != "0" && status.isNotEmpty()
        sb.append(if (compileFailed) "Compilation Error" else if (status == "0" || status.isEmpty()) "Finished" else "Exit code $status").append("\n")
        if (compile.isNotEmpty()) sb.append("\nCOMPILER OUTPUT:\n").append(compile).append("\n")
        if (out.isNotEmpty()) sb.append("\nOUTPUT:\n").append(out).append("\n")
        if (err.isNotEmpty()) sb.append("\nERROR OUTPUT:\n").append(err).append("\n")
        if (signal.isNotEmpty()) sb.append("\nSIGNAL: ").append(signal).append("\n")
        if (out.isEmpty() && err.isEmpty() && compile.isEmpty()) sb.append("(no output)\n")
        if (compileFailed) sb.append("\nResult: it did not compile. Fix the compiler errors above and run again.")
        else if (status != "0" && status.isNotEmpty()) sb.append("\nResult: the program ended with an error. Fix it and run again.")
        else sb.append("\nResult: the program ran and finished.")
        val text = sb.toString().trim()
        return if (text.length > CAP) text.take(CAP) + "\n... (output cut at $CAP characters)" else text
    }

    private fun wandboxCall(method: String, path: String, body: String?): Pair<Int, String> {
        val conn = URL(WANDBOX + path).openConnection() as HttpURLConnection
        Cancel.track(conn)
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 45000
        conn.setRequestProperty("Accept", "application/json")
        if (body != null) {
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        return code to text
    }

    /** Backup run on Wandbox. Returns the report, or null when Wandbox cannot run this language or fails. */
    private fun runWandbox(lang: String, code: String, stdin: String): String? {
        if (!WB_LANG.containsKey(lang)) return null
        return try {
            var list = cachedWandbox
            if (list == null) {
                val (c, t) = wandboxCall("GET", "/api/list.json", null)
                if (c !in 200..299) return null
                list = JSONArray(t); cachedWandbox = list
            }
            val compiler = pickWandbox(list, lang) ?: return null
            val body = JSONObject().put("compiler", compiler).put("code", code).put("save", false)
            if (stdin.isNotEmpty()) body.put("stdin", stdin)
            val (c, t) = wandboxCall("POST", "/api/compile.json", body.toString())
            if (c in 200..299) formatWandbox(lang, JSONObject(t)) + "\n(server: wandbox.org, $compiler)" else null
        } catch (e: CancelledException) { throw e
        } catch (e: Exception) { null }
    }

    /** Backup run of a whole project on Wandbox (entry file as the main code, the others as extra files). Null when it cannot. */
    private fun runWandboxMulti(lang: String, entry: String, files: Map<String, String>, stdin: String): String? {
        if (lang !in WB_MULTI) return null
        return try {
            var list = cachedWandbox
            if (list == null) {
                val (c, t) = wandboxCall("GET", "/api/list.json", null)
                if (c !in 200..299) return null
                list = JSONArray(t); cachedWandbox = list
            }
            val compiler = pickWandbox(list, lang) ?: return null
            val body = JSONObject().put("compiler", compiler).put("code", files[entry] ?: return null).put("save", false)
            val others = JSONArray()
            for ((p, c) in files) if (p != entry) others.put(JSONObject().put("file", p).put("code", c))
            body.put("codes", others)
            if (lang == "c" || lang == "cpp") {
                val ext = if (lang == "c") listOf(".c") else listOf(".cpp", ".cc", ".cxx")
                body.put("compiler-option-raw", (listOf("-I.") + files.keys.filter { it != entry && ext.any { x -> it.endsWith(x) } }).joinToString("\n"))
            }
            if (stdin.isNotEmpty()) body.put("stdin", stdin)
            val (c, t) = wandboxCall("POST", "/api/compile.json", body.toString())
            if (c in 200..299) formatWandbox("$lang project (${files.size} files)", JSONObject(t)) + "\n(server: wandbox.org, $compiler, multi-file)" else null
        } catch (e: CancelledException) { throw e
        } catch (e: Exception) { null }
    }

    /** Settings > Code runner > Test: runs a tiny program through the normal path so the user sees at once whether it works. */
    fun selfTest(ctx: Context): String {
        val r = run(ctx, { true }, JSONObject().put("language", "python").put("code", "print('anjoo run_code ok')"), true)
        return if (r.contains("anjoo run_code ok")) "Chal raha hai.\n\n" + r else "Test fail hua.\n\n" + r
    }

    /** Message for project_check action=run when the project is not a web page or Python: tells the AI how to run it. */
    fun hint(dir: File, files: Map<String, String>): String? {
        val e = entryOf(files.keys) ?: return null
        val lang = normLang(e.substringAfterLast('/'))
        return "This project is $lang (entry $e). Run it with the run_code tool: language=$lang, project=" + dir.name + ", path=$e. If the project has several files of this language they are all sent together (single=true runs just that one file)."
    }
}
