package com.anjoo.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Runs Python projects inside the app, with no server and nothing to install: it uses Pyodide
 * (real CPython compiled to WebAssembly) in a hidden WebView. The first run downloads the
 * runtime (about 10 MB, internet needed); later runs use the cache.
 *
 * Works for scripts, algorithms, data/text processing, games' logic, and the Python standard library
 * (numpy, pandas, matplotlib-free maths etc. load on demand when Pyodide has them).
 * Not possible here: tkinter / pygame windows, Flask or Django servers, raw sockets, subprocess.
 * For those projects only a syntax check is done.
 */
object PyRun {

    private const val BASE = "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/"

    class Result(val loaded: Boolean, val finished: Boolean, val out: String, val err: String, val syntaxOnly: Boolean)

    private val UNSUPPORTED = Regex(
        "^\\s*(?:import|from)\\s+(?:tkinter|pygame|kivy|flask|django|fastapi|uvicorn|selenium|socket|subprocess|telebot|discord|pyautogui|cv2|torch|tensorflow|PyQt\\d?|PySide\\d?|curses|serial|bluetooth)\\b",
        RegexOption.MULTILINE
    )

    private fun pyFiles(dir: File): Map<String, String> =
        Coder.readFiles(dir).filterKeys { it.endsWith(".py") }

    /** The file to run: main.py, app.py ... else a root file with `if __name__ == "__main__"`, else the first root .py file. */
    fun entry(dir: File): String? {
        val py = pyFiles(dir)
        if (py.isEmpty()) return null
        for (n in listOf("main.py", "app.py", "run.py", "__main__.py", "index.py", "script.py"))
            if (py.containsKey(n)) return n
        val root = py.filterKeys { !it.contains('/') }
        root.entries.firstOrNull { it.value.contains("__main__") }?.let { return it.key }
        return root.keys.firstOrNull() ?: py.keys.first()
    }

    fun needsSyntaxOnly(dir: File): Boolean = pyFiles(dir).values.any { UNSUPPORTED.containsMatchIn(it) }

    private const val SETUP = """
import json, os, sys
root = '/proj'
for p, c in json.loads(FILES_JSON).items():
    fp = os.path.join(root, p)
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    with open(fp, 'w', encoding='utf-8') as f:
        f.write(c)
os.chdir(root)
sys.path.insert(0, root)
"""

    private const val RUN = """
import os, sys, runpy, traceback
def clean(tb):
    out = []
    skip = False
    for l in tb.splitlines():
        if l.startswith('  File "'):
            skip = ('<frozen' in l) or ('/lib/python' in l)
            if skip:
                continue
        elif skip and l.startswith('    '):
            continue
        else:
            skip = False
        out.append(l)
    return "\n".join(out)
if SYNTAX_ONLY:
    bad = []
    for dp, dn, fn in os.walk('/proj'):
        for n in fn:
            if n.endswith('.py'):
                p = os.path.join(dp, n)
                try:
                    compile(open(p, encoding='utf-8').read(), p, 'exec')
                except SyntaxError as e:
                    bad.append("%s:%s: SyntaxError: %s" % (os.path.relpath(p, '/proj'), e.lineno, e.msg))
    if bad:
        print("\n".join(bad), file=sys.stderr)
else:
    try:
        runpy.run_path(ENTRY, run_name='__main__')
    except SystemExit as e:
        if e.code not in (None, 0):
            print("[exit code %s]" % (e.code,), file=sys.stderr)
    except BaseException:
        print(clean(traceback.format_exc()), file=sys.stderr)
"""

    private fun page(): String = "<!doctype html><html><body><script src=\"" + BASE + "pyodide.js\"></script><script>\n" +
        "var OUT='',ERR='';\n" +
        "async function go(){\n" +
        " try{\n" +
        "  var py=await loadPyodide({indexURL:\"" + BASE + "\"});\n" +
        "  Bridge.loaded();\n" +
        "  py.setStdout({batched:function(s){OUT+=s+\"\\n\";}});\n" +
        "  py.setStderr({batched:function(s){ERR+=s+\"\\n\";}});\n" +
        "  py.setStdin({stdin:function(){return null;}});\n" +
        "  py.globals.set('FILES_JSON',Bridge.files());\n" +
        "  py.globals.set('ENTRY',Bridge.entry());\n" +
        "  py.globals.set('SYNTAX_ONLY',Bridge.syntaxOnly());\n" +
        "  await py.runPythonAsync(Bridge.pySetup());\n" +
        "  if(!Bridge.syntaxOnly()){try{await py.loadPackagesFromImports(Bridge.imports());}catch(e){ERR+='[package load] '+e+\"\\n\";}}\n" +
        "  if(!Bridge.syntaxOnly()&&Bridge.reqs()!='[]'){try{await py.loadPackage('micropip');py.globals.set('REQS_JSON',Bridge.reqs());await py.runPythonAsync('import micropip, json\\nawait micropip.install(json.loads(REQS_JSON), keep_going=True)');}catch(e){ERR+='[pip install] '+e+\"\\n\";}}\n" +
        "  await py.runPythonAsync(Bridge.pyRun());\n" +
        " }catch(e){ERR+=String((e&&e.message)||e)+\"\\n\";}\n" +
        " Bridge.done(OUT,ERR);\n" +
        "}\n" +
        "go();\n" +
        "</script></body></html>"

    class Bridge(
        val files: String, val entry: String, val syntax: Boolean, val imports: String, val reqs: String,
        val loadedLatch: CountDownLatch, val doneLatch: CountDownLatch
    ) {
        @Volatile var out = ""
        @Volatile var err = ""
        @Volatile var finished = false
        @Volatile var didLoad = false
        @JavascriptInterface fun files() = files
        @JavascriptInterface fun entry() = entry
        @JavascriptInterface fun syntaxOnly() = syntax
        @JavascriptInterface fun imports() = imports
        @JavascriptInterface fun reqs() = reqs
        @JavascriptInterface fun pySetup() = SETUP
        @JavascriptInterface fun pyRun() = RUN
        @JavascriptInterface fun loaded() { didLoad = true; loadedLatch.countDown() }
        @JavascriptInterface fun done(o: String, e: String) { out = o; err = e; finished = true; loadedLatch.countDown(); doneLatch.countDown() }
    }

    /** Blocking. Call from a background thread. */
    fun run(ctx: Context, dir: File, entry: String, syntaxOnly: Boolean, loadWaitMs: Long = 60000, runWaitMs: Long = 60000): Result {
        val files = JSONObject()
        for ((k, v) in pyFiles(dir)) files.put(k, v)
        // every other text file too (data files, json, csv), so open("data.json") works
        for ((k, v) in Coder.readFiles(dir)) if (!files.has(k) && v.length < 400000) files.put(k, v)
        val imports = pyFiles(dir).values.joinToString("\n")
        val loadedLatch = CountDownLatch(1)
        val doneLatch = CountDownLatch(1)
        val reqs = JSONArray(Deps.pipRequirements(Coder.readFiles(dir))).toString()
        val b = Bridge(files.toString(), entry, syntaxOnly, imports, reqs, loadedLatch, doneLatch)
        val main = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        val jsErr = StringBuilder()
        main.post {
            try {
                val w = WebView(ctx.applicationContext)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.addJavascriptInterface(b, "Bridge")
                w.webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(m: android.webkit.ConsoleMessage?): Boolean {
                        if (m != null && m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR && jsErr.length < 600)
                            jsErr.append(m.message()).append("\n")
                        return true
                    }
                }
                w.loadDataWithBaseURL("https://py.local/", page(), "text/html", "UTF-8", null)
            } catch (e: Exception) { loadedLatch.countDown(); doneLatch.countDown() }
        }
        try { loadedLatch.await(loadWaitMs, TimeUnit.MILLISECONDS) } catch (e: Exception) {}
        if (b.didLoad && !b.finished) try { doneLatch.await(runWaitMs, TimeUnit.MILLISECONDS) } catch (e: Exception) {}
        main.post { try { wv?.stopLoading(); wv?.destroy() } catch (e: Exception) {} }
        val err = if (b.finished) b.err else (b.err + jsErr.toString())
        return Result(b.didLoad, b.finished, b.out, err, syntaxOnly)
    }


    /** Runs a snippet and returns its output as text for the assistant (tool run_python). */
    fun runCode(ctx: Context, code: String): String {
        if (Sandbox.on(ctx) && Sandbox.touchesPhone(code)) return Sandbox.DENY_CODE
        val d = File(ctx.cacheDir, "pyrun-" + System.currentTimeMillis())
        return try {
            d.mkdirs()
            File(d, "main.py").writeText(code, Charsets.UTF_8)
            val r = run(ctx, d, "main.py", false, 70000, 40000)
            when {
                !r.loaded -> "The Python runtime did not load (internet is needed the first time). Try again, or work it out yourself and say it was not run."
                !r.finished -> "The code did not finish in 40 seconds (maybe very heavy or an endless loop). Make it smaller and run again."
                else -> {
                    val sb = StringBuilder()
                    if (r.out.isNotBlank()) sb.append("OUTPUT:\n").append(r.out.trim().take(4000))
                    if (r.err.isNotBlank()) sb.append(if (sb.isEmpty()) "" else "\n\n").append("ERROR:\n").append(r.err.trim().takeLast(1500))
                    if (sb.isEmpty()) "The code ran but printed nothing. Show the result with print()." else sb.toString()
                }
            }
        } catch (e: Exception) { "Python could not run: " + (e.message ?: "") } finally { try { d.deleteRecursively() } catch (e: Exception) {} }
    }

    /** For the coder's self-fix loop: a plain list of problems, or "" when it ran fine or cannot be tested. */
    fun check(ctx: Context, dir: File): String {
        val e = entry(dir) ?: return ""
        val syntax = needsSyntaxOnly(dir)
        val r = run(ctx, dir, e, syntax, 45000, 20000)
        if (!r.loaded || !r.finished) return ""
        val err = r.err.trim()
        if (err.isEmpty()) return ""
        if (err.contains("EOFError")) return ""   // the script wanted keyboard input: not a bug
        val missing = Regex("No module named '([^'.]+)").find(err)?.groupValues?.get(1)
        if (missing != null) {
            val local = pyFiles(dir).keys.map { it.substringBefore('/').removeSuffix(".py") }
            if (missing !in local) return ""        // a package Pyodide does not have: cannot be tested here
        }
        if (!(err.contains("Traceback") || err.contains("SyntaxError") || Regex("(?m)^\\w*(Error|Exception)\\b").containsMatchIn(err))) return ""
        return "- Python " + (if (syntax) "syntax check" else "run of $e") + " failed:\n" + err.takeLast(1800)
    }
}
