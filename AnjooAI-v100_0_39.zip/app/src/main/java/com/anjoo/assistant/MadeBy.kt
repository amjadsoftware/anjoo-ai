package com.anjoo.assistant

/**
 * The "Made by" line under an answer. The saved text (Router.footer) is long:
 * "🤖 Made by: Google Gemini · gemini-3.6-flash + Mistral · mistral-code-latest +2  ·  phone actions  ·  121 more models ready".
 * The chat shows only the company names; tapping it opens the model details.
 */
object MadeBy {
    private const val PREFIX = "🤖 Made by:"
    private const val SEP = "  ·  "

    private class Parsed(val models: List<Pair<String, String>>, val extra: String, val task: String, val rest: String)

    private fun parse(by: String): Parsed {
        val body = by.trim().removePrefix(PREFIX).trim()
        val parts = body.split(SEP)
        var shown = parts.firstOrNull().orEmpty().trim()
        var extra = ""
        val m = Regex("\\s\\+(\\d+)$").find(shown)
        if (m != null) { extra = m.groupValues[1]; shown = shown.substring(0, m.range.first).trim() }
        val models = shown.split(" + ").map { it.trim() }.filter { it.isNotEmpty() }.map {
            if (it.contains(" · ")) it.substringBefore(" · ").trim() to it.substringAfter(" · ").trim() else it to ""
        }
        return Parsed(models, extra, parts.getOrNull(1)?.trim().orEmpty(), parts.drop(2).joinToString(SEP).trim())
    }

    /** "🤖 Made by: Google Gemini + Mistral +2" (company names only). */
    fun short(by: String): String {
        if (by.isBlank()) return ""
        val p = parse(by)
        if (p.models.isEmpty()) return by
        val names = p.models.map { it.first }.distinct().joinToString(" + ")
        return "$PREFIX $names" + (if (p.extra.isNotEmpty()) " +${p.extra}" else "")
    }

    /** Lines for the details sheet: one per company with its model, then the kind of work. */
    fun details(by: String): String {
        val p = parse(by)
        if (p.models.isEmpty()) return by
        val sb = StringBuilder()
        for ((c, m) in p.models) sb.append(c).append(if (m.isNotEmpty()) "\n   model: $m" else "").append("\n\n")
        if (p.extra.isNotEmpty()) sb.append("+${p.extra} aur model bhi use hue\n\n")
        if (p.task.isNotEmpty()) sb.append("Kaam: ").append(p.task).append("\n")
        if (p.rest.isNotEmpty()) sb.append(p.rest).append("\n")
        return sb.toString().trim()
    }
}
