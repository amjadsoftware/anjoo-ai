package com.anjoo.assistant

/**
 * Stops a model that has fallen into a repetition loop (the same sentence or the same few sentences again and again,
 * for example "11. Enterprise-Level ... 12. Enterprise-Level ... 13. ..."). Three identical repeats in a row are a loop.
 * Numbering and bullet marks are ignored, so "11. X" and "12. X" count as the same line. Sentences shorter than
 * [MIN_LEN] characters and everything inside ``` code blocks are ignored, so normal answers are never cut.
 * Pure Kotlin, so it can be unit tested.
 */
internal object RepetitionGuard {
    const val NOTE = "⚠️ The model started repeating itself, so I stopped it here. Ask me to continue, or try another model."
    private const val MIN_LEN = 25
    private const val MAX_PERIOD = 4          // a loop may repeat a block of up to 4 sentences
    private const val CHECK_EVERY = 400       // while streaming, look again only after this many new characters

    /** Thrown inside a stream reader to stop reading once a loop is found. */
    class Stop : RuntimeException("Repeating answer stopped")

    private class Seg(val start: Int, val key: String)

    private val listMark = Regex("^\\s*(?:\\d{1,3}[.)]|[-*•#>]+)\\s*")
    private val junk = Regex("[*_`]+")
    private val spaces = Regex("\\s+")
    private val sentenceBreak = Regex("(?<=[.!?])\\s+")

    private fun key(s: String): String = junk.replace(listMark.replace(s, ""), "").lowercase().replace(spaces, " ").trim()

    private fun segments(text: String): List<Seg> {
        val out = ArrayList<Seg>()
        var inFence = false
        var pos = 0
        for (line in text.split('\n')) {
            val lineStart = pos
            pos += line.length + 1
            if (line.trimStart().startsWith("```")) { inFence = !inFence; continue }
            if (inFence || line.isBlank()) continue
            var from = 0
            fun add(to: Int) {
                val k = key(line.substring(from, to))
                if (k.length >= MIN_LEN) out.add(Seg(lineStart + from, k))
            }
            for (m in sentenceBreak.findAll(line)) { add(m.range.first); from = m.range.last + 1 }
            add(line.length)
        }
        return out
    }

    /** Index in [text] where the second copy of a looping block starts, or -1 when there is no loop. */
    fun loopStart(text: String): Int {
        val s = segments(text)
        val n = s.size
        for (i in 0 until n) for (p in 1..MAX_PERIOD) {
            if (i + 3 * p > n) break
            var same = true
            for (k in 0 until p) if (s[i + k].key != s[i + p + k].key || s[i + k].key != s[i + 2 * p + k].key) { same = false; break }
            if (same) return s[i + p].start
        }
        return -1
    }

    /** Cuts a looping answer back to its first copy and adds [NOTE]. Text without a loop is returned unchanged. */
    fun fix(text: String): String {
        val at = loopStart(text)
        if (at < 0) return text
        return text.substring(0, at).trimEnd() + "\n\n" + NOTE
    }

    /** Used by a stream reader: says true when the text so far contains a loop (looks again only after enough new text). */
    class Watch {
        private var checked = 0
        fun tripped(text: String): Boolean {
            if (text.length - checked < CHECK_EVERY) return false
            checked = text.length
            return loopStart(text) >= 0
        }
    }
}
