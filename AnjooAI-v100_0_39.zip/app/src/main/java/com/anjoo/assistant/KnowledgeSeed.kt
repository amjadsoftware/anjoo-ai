package com.anjoo.assistant

import android.content.Context

/**
 * Loads the built-in reference pack (the assets/kb_pack folder (text files)) into the local Knowledge Base once,
 * so common how-to knowledge is searchable offline. The user can pin, edit or delete these notes.
 * Bump VERSION when new files are added to the pack.
 */
object KnowledgeSeed {
    private const val VERSION = 2

    fun apply(ctx: Context) {
        val app = ctx.applicationContext
        val p = app.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        if (p.getInt("kbSeedVersion", 0) >= VERSION) return
        Thread {
            try {
                val names = app.assets.list("kb_pack")?.filter { it.endsWith(".txt") }?.sorted() ?: emptyList()
                var ok = 0
                for (n in names) {
                    try {
                        val text = app.assets.open("kb_pack/$n").bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val title = text.lineSequence().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
                        KnowledgeBase.addText(app, title, "Anjoo built-in pack", "text/plain", text)
                        ok++
                    } catch (e: Exception) {
                        android.util.Log.w("Anjoo", "kb seed skip $n", e)
                    }
                }
                if (ok > 0 && ok == names.size) p.edit().putInt("kbSeedVersion", VERSION).apply()
            } catch (e: Exception) {
                android.util.Log.w("Anjoo", "kb seed failed", e)
            }
        }.start()
    }
}
