package com.anjoo.assistant

import android.content.Context
import org.json.JSONObject
import java.io.File
import kotlin.math.ln

/**
 * project_code: understand and change code across the whole project, without a language server.
 *
 *  symbols ....... every definition (function, class, method, variable) with file:line; optional path / kind filter
 *  definition .... where a name is defined, with a few lines of context
 *  references .... every use of a name; uses inside comments and strings are listed separately
 *  rename ........ rename an identifier everywhere it is used as code (comments/strings untouched unless asked); dry_run=true previews
 *  apply_patch ... apply a unified diff (several files, new files, deletions); all hunks or nothing
 *  locate ........ find code by meaning words ("where is login handled") with a ranked, offline text search
 *
 * It is NAME based, not type based: a method called `get` on two classes counts as one name, so scope with path= and check
 * with references/dry_run first. Comments and strings are skipped with a small scanner (// /* */ # """ ' " `), JavaScript
 * regex literals and template-string `${...}` code are not understood.
 */
object CodeNav {

    private const val CAP = 9000
    private val SKIP = Regex("(^|/)(node_modules|vendor|dist|build|\\.git|__pycache__|\\.gradle)/|\\.min\\.(js|css)$|\\.bundle\\.js$")
    private const val MAX_FILE = 600_000

    class Def(val name: String, val kind: String, val path: String, val line: Int)
    class Ref(val path: String, val line: Int, val inCode: Boolean, val text: String)

    // ============================================================ scanner (pure)

    /** "c" (// and /* */ comments), "hash" (# comments, triple quotes), or "" (not code: no masking). */
    fun family(path: String): String = when (path.substringAfterLast('.', "").lowercase()) {
        "js", "jsx", "mjs", "cjs", "ts", "tsx", "java", "kt", "kts", "cs", "go", "rs", "c", "h", "cpp", "hpp", "cc", "swift", "dart", "php", "scala",
        "css", "scss", "less", "html", "htm", "vue", "svelte" -> "c"
        "py", "rb", "sh", "bash", "yml", "yaml", "r", "pl" -> "hash"
        else -> ""
    }

    /**
     * Same-length copy of [text] where comments and string literals are blanked (newlines kept), so a search on it
     * only sees code. Single-line strings end at the line end, which limits the damage of anything the scanner misreads.
     */
    fun mask(text: String, fam: String, path: String = ""): String {
        if (fam.isEmpty()) return text
        val ext = path.substringAfterLast('.', "").lowercase()
        val rust = ext == "rs"
        val out = text.toCharArray()
        fun blank(from: Int, to: Int) { for (k in from until minOf(to, out.size)) if (out[k] != '\n') out[k] = ' ' }
        var i = 0
        val n = text.length
        while (i < n) {
            val c = text[i]
            if (fam == "c" && c == '/' && i + 1 < n && text[i + 1] == '/') {
                val e = text.indexOf('\n', i).let { if (it < 0) n else it }; blank(i, e); i = e; continue
            }
            if (fam == "c" && c == '/' && i + 1 < n && text[i + 1] == '*') {
                val e = text.indexOf("*/", i + 2).let { if (it < 0) n else it + 2 }; blank(i, e); i = e; continue
            }
            if (fam == "c" && (ext == "html" || ext == "htm" || ext == "vue" || ext == "svelte") && text.startsWith("<!--", i)) {
                val e = text.indexOf("-->", i + 4).let { if (it < 0) n else it + 3 }; blank(i, e); i = e; continue
            }
            if (fam == "hash" && c == '#') {
                val e = text.indexOf('\n', i).let { if (it < 0) n else it }; blank(i, e); i = e; continue
            }
            if ((c == '"' && text.startsWith("\"\"\"", i)) || (c == '\'' && fam == "hash" && text.startsWith("'''", i))) {
                val q = text.substring(i, i + 3)
                val e = text.indexOf(q, i + 3).let { if (it < 0) n else it + 3 }; blank(i, e); i = e; continue
            }
            if (c == '\'' && rust) {
                // Rust: 'a lifetime vs 'x' char literal
                if (i + 2 < n && text[i + 2] == '\'') { blank(i, i + 3); i += 3; continue }
                if (i + 3 < n && text[i + 1] == '\\' && text[i + 3] == '\'') { blank(i, i + 4); i += 4; continue }
                i++; continue
            }
            if (c == '"' || c == '\'' || (c == '`' && fam == "c")) {
                var j = i + 1
                val multi = c == '`'
                while (j < n) {
                    val d = text[j]
                    if (d == '\\') { j += 2; continue }
                    if (d == c) { j++; break }
                    if (d == '\n' && !multi) break
                    j++
                }
                val e = minOf(j, n); blank(i, e); i = e; continue
            }
            i++
        }
        return String(out)
    }

    private val KEYWORDS = setOf("if", "for", "while", "switch", "catch", "function", "return", "else", "do", "try", "new", "typeof", "await", "super", "this", "when", "with", "elif", "sizeof")

    private fun lineOf(starts: IntArray, pos: Int): Int {
        var lo = 0; var hi = starts.size - 1
        while (lo < hi) { val mid = (lo + hi + 1) / 2; if (starts[mid] <= pos) lo = mid else hi = mid - 1 }
        return lo + 1
    }

    private fun lineStarts(text: String): IntArray {
        val l = ArrayList<Int>(); l.add(0)
        for (i in text.indices) if (text[i] == '\n') l.add(i + 1)
        return l.toIntArray()
    }

    private val PY_DEF = Regex("(?m)^[ \\t]*(?:async[ \\t]+)?(def|class)[ \\t]+([A-Za-z_]\\w*)")
    private val PY_VAR = Regex("(?m)^([A-Za-z_]\\w*)[ \\t]*(?::[^=\\n]+)?=(?!=)")
    private val JS_DEF = Regex("(?m)^[ \\t]*(?:export[ \\t]+)?(?:default[ \\t]+)?(?:declare[ \\t]+)?(?:abstract[ \\t]+)?(?:async[ \\t]+)?(function\\*?|class|interface|type|enum)[ \\t]+([A-Za-z_$][\\w$]*)")
    private val JS_VAR = Regex("(?m)^[ \\t]*(?:export[ \\t]+)?(?:const|let|var)[ \\t]+([A-Za-z_$][\\w$]*)")
    private val JS_METHOD = Regex("(?m)^[ \\t]{2,}(?:(?:static|async|get|set|public|private|protected|readonly)[ \\t]+)*([A-Za-z_$][\\w$]*)[ \\t]*\\([^)\\n]*\\)[ \\t]*(?::[^{\\n]+)?\\{")
    private val KT_DEF = Regex("(?m)^[ \\t]*(?:(?:public|private|protected|internal|open|abstract|override|data|sealed|inline|suspend|operator|const|lateinit|companion|enum|annotation)[ \\t]+)*(fun|class|object|interface|val|var|typealias)[ \\t]+(?:<[^>\\n]*>[ \\t]*)?(?:[\\w.]+\\.)?([A-Za-z_]\\w*)")
    private val JAVA_TYPE = Regex("(?m)^[ \\t]*(?:(?:public|private|protected|static|final|abstract|sealed|internal|partial)[ \\t]+)*(class|interface|enum|record|struct)[ \\t]+(\\w+)")
    private val JAVA_METHOD = Regex("(?m)^[ \\t]*(?:(?:public|private|protected|static|final|abstract|override|async|internal|virtual|synchronized)[ \\t]+)+[\\w<>\\[\\],.?]+(?:[ \\t]+[\\w<>\\[\\],.?]+)*[ \\t]+(\\w+)[ \\t]*\\(")
    private val GO_DEF = Regex("(?m)^(func)[ \\t]+(?:\\([^)]*\\)[ \\t]*)?(\\w+)|^(type|var|const)[ \\t]+(\\w+)")
    private val RS_DEF = Regex("(?m)^[ \\t]*(?:pub(?:\\([^)]*\\))?[ \\t]+)?(?:async[ \\t]+)?(?:unsafe[ \\t]+)?(fn|struct|enum|trait|mod|const|static|type)[ \\t]+(\\w+)")
    private val PHP_DEF = Regex("(?m)^[ \\t]*(?:(?:public|private|protected|static|abstract|final)[ \\t]+)*(function|class|interface|trait)[ \\t]+(\\w+)")

    fun definitions(path: String, text: String): List<Def> {
        val fam = family(path)
        if (fam.isEmpty()) return emptyList()
        val m = mask(text, fam, path)
        val starts = lineStarts(m)
        val out = ArrayList<Def>()
        fun add(name: String, kind: String, pos: Int) { if (name !in KEYWORDS) out.add(Def(name, kind, path, lineOf(starts, pos))) }
        when (path.substringAfterLast('.', "").lowercase()) {
            "py" -> {
                for (x in PY_DEF.findAll(m)) add(x.groupValues[2], if (x.groupValues[1] == "def") "function" else "class", x.groups[2]!!.range.first)
                for (x in PY_VAR.findAll(m)) add(x.groupValues[1], "variable", x.range.first)
            }
            "js", "jsx", "mjs", "cjs", "ts", "tsx", "vue", "svelte", "html", "htm" -> {
                for (x in JS_DEF.findAll(m)) add(x.groupValues[2], x.groupValues[1].trimEnd('*').let { if (it == "function") "function" else it }, x.groups[2]!!.range.first)
                for (x in JS_VAR.findAll(m)) add(x.groupValues[1], "variable", x.groups[1]!!.range.first)
                for (x in JS_METHOD.findAll(m)) add(x.groupValues[1], "method", x.groups[1]!!.range.first)
            }
            "kt", "kts" -> for (x in KT_DEF.findAll(m)) add(x.groupValues[2], x.groupValues[1].let { if (it == "fun") "function" else it }, x.groups[2]!!.range.first)
            "java", "cs", "dart", "swift", "scala", "c", "h", "cpp", "hpp", "cc" -> {
                for (x in JAVA_TYPE.findAll(m)) add(x.groupValues[2], x.groupValues[1], x.groups[2]!!.range.first)
                for (x in JAVA_METHOD.findAll(m)) add(x.groupValues[1], "method", x.groups[1]!!.range.first)
            }
            "go" -> for (x in GO_DEF.findAll(m)) {
                if (x.groupValues[2].isNotEmpty()) add(x.groupValues[2], "function", x.groups[2]!!.range.first)
                else add(x.groupValues[4], x.groupValues[3], x.groups[4]!!.range.first)
            }
            "rs" -> for (x in RS_DEF.findAll(m)) add(x.groupValues[2], x.groupValues[1], x.groups[2]!!.range.first)
            "php" -> for (x in PHP_DEF.findAll(m)) add(x.groupValues[2], x.groupValues[1], x.groups[2]!!.range.first)
        }
        return out.distinctBy { it.name + ":" + it.line }.sortedBy { it.line }
    }

    fun isIdent(s: String) = Regex("^[A-Za-z_$][\\w$]*$").matches(s)

    private fun wordRegex(name: String) = Regex("(?<![\\w$])" + Regex.escape(name) + "(?![\\w$])")

    /** Uses of [name] in the files. inCode=false means the hit sits inside a comment or string. */
    fun references(files: Map<String, String>, name: String, only: String = ""): List<Ref> {
        val re = wordRegex(name)
        val out = ArrayList<Ref>()
        for ((p, t) in files) {
            if (only.isNotBlank() && p != only && !p.startsWith(only.trimEnd('/') + "/")) continue
            if (!t.contains(name)) continue
            val fam = family(p)
            val m = mask(t, fam, p)
            val starts = lineStarts(t)
            val lines = t.split("\n")
            for (x in re.findAll(t)) {
                val code = fam.isEmpty() || m.startsWith(name, x.range.first)
                val ln = lineOf(starts, x.range.first)
                out.add(Ref(p, ln, code, lines[ln - 1].trim().take(140)))
            }
        }
        return out
    }

    class Renamed(val files: Map<String, String>, val code: Int, val skipped: Int, val perFile: Map<String, Int>)

    /** Rename [from] to [to] in code (and in comments/strings when [inText]); returns the changed files. */
    fun rename(files: Map<String, String>, from: String, to: String, only: String = "", inText: Boolean = false): Renamed {
        val re = wordRegex(from)
        val changed = LinkedHashMap<String, String>()
        val per = LinkedHashMap<String, Int>()
        var code = 0; var skipped = 0
        for ((p, t) in files) {
            if (only.isNotBlank() && p != only && !p.startsWith(only.trimEnd('/') + "/")) continue
            if (!t.contains(from)) continue
            val fam = family(p)
            val m = mask(t, fam, p)
            val sb = StringBuilder()
            var last = 0
            var n = 0
            for (x in re.findAll(t)) {
                val isCode = fam.isEmpty() || m.startsWith(from, x.range.first)
                if (isCode || inText) {
                    sb.append(t, last, x.range.first).append(to); last = x.range.last + 1; n++
                    if (isCode) code++
                } else skipped++
            }
            if (n > 0) { sb.append(t, last, t.length); changed[p] = sb.toString(); per[p] = n }
        }
        return Renamed(changed, code, skipped.coerceAtLeast(0), per)
    }

    // ============================================================ patch (pure)

    class Hunk(val hint: Int, val ops: List<Pair<Char, String>>) {
        val old: List<String> get() = ops.filter { it.first != '+' }.map { it.second }
    }
    class FilePatch(val oldPath: String?, val newPath: String?, val hunks: List<Hunk>)
    class PatchResult(val files: Map<String, String>, val deleted: Set<String>, val error: String?, val summary: List<String>)

    private fun cleanDiffPath(raw: String): String? {
        val p = raw.trim().substringBefore('\t').trim().trim('"')
        if (p == "/dev/null") return null
        return p
    }

    fun parsePatch(text: String): List<FilePatch> {
        val lines = text.replace("\r\n", "\n").split("\n")
        val out = ArrayList<FilePatch>()
        var i = 0
        while (i < lines.size) {
            if (lines[i].startsWith("--- ") && i + 1 < lines.size && lines[i + 1].startsWith("+++ ")) {
                val op = cleanDiffPath(lines[i].substring(4)); val np = cleanDiffPath(lines[i + 1].substring(4))
                i += 2
                val hunks = ArrayList<Hunk>()
                while (i < lines.size && !lines[i].startsWith("--- ")) {
                    val h = Regex("^@@ -(\\d+)(?:,\\d+)? \\+\\d+(?:,\\d+)? @@").find(lines[i])
                    if (h == null) { i++; continue }
                    val hint = h.groupValues[1].toInt()
                    i++
                    val ops = ArrayList<Pair<Char, String>>()
                    while (i < lines.size && !lines[i].startsWith("@@") && !(lines[i].startsWith("--- ") && i + 1 < lines.size && lines[i + 1].startsWith("+++ "))) {
                        val l = lines[i]
                        when {
                            l.startsWith("\\") -> {}
                            l.startsWith("+") -> ops.add(Pair('+', l.substring(1)))
                            l.startsWith("-") -> ops.add(Pair('-', l.substring(1)))
                            l.startsWith(" ") -> ops.add(Pair(' ', l.substring(1)))
                            l.isEmpty() -> { if (i + 1 < lines.size || ops.isNotEmpty()) ops.add(Pair(' ', "")) }
                            else -> {}
                        }
                        i++
                    }
                    // trailing blank context from the final newline of the diff text is not part of the hunk
                    while (i >= lines.size && ops.isNotEmpty() && ops.last().first == ' ' && ops.last().second.isEmpty()) ops.removeAt(ops.size - 1)
                    hunks.add(Hunk(hint, ops))
                }
                out.add(FilePatch(op, np, hunks))
            } else i++
        }
        return out
    }

    private fun sameLine(a: String, b: String) = a.trimEnd() == b.trimEnd()

    private fun findBlock(lines: List<String>, block: List<String>, from: Int, hint: Int): Int {
        if (block.isEmpty()) return minOf(maxOf(hint, 0), lines.size)
        var best = -1
        for (s in from..(lines.size - block.size)) {
            var ok = true
            for (k in block.indices) if (!sameLine(lines[s + k], block[k])) { ok = false; break }
            if (ok && (best < 0 || Math.abs(s - hint) < Math.abs(best - hint))) best = s
        }
        return best
    }

    /** Applies the patches to [files] in memory; the first problem aborts everything (error set, nothing changes). */
    fun applyPatch(files: Map<String, String>, patches: List<FilePatch>): PatchResult {
        if (patches.isEmpty()) return PatchResult(emptyMap(), emptySet(), "No file section (--- a/path, +++ b/path, @@ hunks) found in the patch.", emptyList())
        val work = LinkedHashMap<String, String>()
        val deleted = LinkedHashSet<String>()
        val summary = ArrayList<String>()
        fun resolve(p: String?): String? {
            if (p == null) return null
            val n = p.replace('\\', '/').removePrefix("./")
            if (files.containsKey(n) || work.containsKey(n)) return n
            val stripped = n.substringAfter('/', n)
            if ((n.startsWith("a/") || n.startsWith("b/")) && (files.containsKey(stripped) || work.containsKey(stripped))) return stripped
            return if (n.startsWith("a/") || n.startsWith("b/")) stripped else n
        }
        for (fp in patches) {
            val target = resolve(fp.newPath ?: fp.oldPath) ?: return PatchResult(emptyMap(), emptySet(), "A file section has no path.", emptyList())
            if (target.contains("..") || target.startsWith("/")) return PatchResult(emptyMap(), emptySet(), "Unsafe path in patch: $target", emptyList())
            if (fp.newPath == null) { // deletion
                if (!files.containsKey(target) && !work.containsKey(target)) return PatchResult(emptyMap(), emptySet(), "Cannot delete $target: it does not exist.", emptyList())
                work.remove(target); deleted.add(target); summary.add("deleted $target"); continue
            }
            val creating = fp.oldPath == null
            val src = work[target] ?: files[target]
            if (src == null && !creating) return PatchResult(emptyMap(), emptySet(), "Cannot patch $target: it does not exist (use --- /dev/null to create).", emptyList())
            val text = (src ?: "").replace("\r\n", "\n")
            val endsNl = text.endsWith("\n") || creating || text.isEmpty()
            val lines = ArrayList<String>(if (text.isEmpty()) emptyList() else text.removeSuffix("\n").split("\n"))
            var shift = 0
            var from = 0
            for ((hi, h) in fp.hunks.withIndex()) {
                val at = findBlock(lines, h.old, from, if (h.old.isEmpty()) h.hint + shift else h.hint - 1 + shift)
                if (at < 0) {
                    val first = h.old.firstOrNull { it.isNotBlank() }?.trim()?.take(80) ?: ""
                    return PatchResult(emptyMap(), emptySet(), "Hunk ${hi + 1} of $target does not match the file (looked for: \"$first\"). Re-read the file with project_read and make the patch from its current text. Nothing was changed.", emptyList())
                }
                val oldLen = h.old.size
                val result = ArrayList<String>()
                var pos = at
                for ((kind, txt) in h.ops) when (kind) {
                    '+' -> result.add(txt)
                    '-' -> pos++
                    else -> { result.add(lines[pos]); pos++ }   // context keeps the file's own text
                }
                for (k in 0 until oldLen) lines.removeAt(at)
                lines.addAll(at, result)
                shift += result.size - oldLen
                from = at + result.size
            }
            work[target] = lines.joinToString("\n") + (if (endsNl && lines.isNotEmpty()) "\n" else "")
            deleted.remove(target)
            summary.add((if (creating) "created " else "patched ") + target + " (" + fp.hunks.size + " hunk" + (if (fp.hunks.size == 1) "" else "s") + ")")
        }
        return PatchResult(work, deleted, null, summary)
    }

    // ============================================================ locate (pure)

    class Hit(val path: String, val from: Int, val to: Int, val score: Double, val preview: String)

    private val STOP = setOf("the", "a", "an", "of", "to", "in", "is", "are", "where", "how", "what", "does", "do", "and", "or", "for", "with", "this", "that", "it", "on", "my", "i", "code", "function", "file")

    fun words(s: String): List<String> =
        Regex("[A-Z]+(?![a-z])|[A-Za-z][a-z0-9]*|\\d+").findAll(s).map { it.value.lowercase() }.filter { it.length > 1 && it !in STOP }.toList()

    fun locate(files: Map<String, String>, query: String, top: Int = 8): List<Hit> {
        val q = words(query).distinct()
        if (q.isEmpty()) return emptyList()
        class Chunk(val path: String, val from: Int, val lines: List<String>, val tf: Map<String, Int>)
        val chunks = ArrayList<Chunk>()
        for ((p, t) in files) {
            if (family(p).isEmpty() && !p.endsWith(".md") && !p.endsWith(".txt") && !p.endsWith(".json")) continue
            val ls = t.split("\n")
            var s = 0
            while (s < ls.size) {
                val part = ls.subList(s, minOf(ls.size, s + 30))
                val tf = HashMap<String, Int>()
                for (w in words(part.joinToString("\n"))) tf[w] = (tf[w] ?: 0) + 1
                for (w in words(p)) tf[w] = (tf[w] ?: 0) + 2
                chunks.add(Chunk(p, s + 1, part, tf))
                if (s + 30 >= ls.size) break
                s += 15
            }
        }
        if (chunks.isEmpty()) return emptyList()
        val df = HashMap<String, Int>()
        for (c in chunks) for (w in q) if (c.tf.containsKey(w)) df[w] = (df[w] ?: 0) + 1
        val scored = ArrayList<Hit>()
        for (c in chunks) {
            var score = 0.0
            var matched = 0
            for (w in q) {
                val f = c.tf[w] ?: continue
                matched++
                score += (1 + ln(f.toDouble())) * ln(1.0 + chunks.size.toDouble() / (df[w] ?: 1))
            }
            if (matched == 0) continue
            score *= (1.0 + matched.toDouble() / q.size)
            val pv = c.lines.firstOrNull { l -> q.any { w -> l.lowercase().contains(w) } }?.trim()?.take(120) ?: ""
            scored.add(Hit(c.path, c.from, c.from + c.lines.size - 1, score, pv))
        }
        val picked = ArrayList<Hit>()
        for (h in scored.sortedByDescending { it.score }) {
            if (picked.any { it.path == h.path && h.from < it.to && it.from < h.to }) continue
            picked.add(h)
            if (picked.size >= top) break
        }
        return picked
    }

    // ============================================================ tool entry

    private fun cap(s: String, n: Int = CAP) = if (s.length <= n) s else s.take(n * 2 / 3) + "\n...[middle trimmed]...\n" + s.takeLast(n / 3)

    private fun codeFiles(dir: File): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for ((p, c) in Coder.readFiles(dir).toSortedMap()) {
            if (SKIP.containsMatchIn(p) || p.startsWith(".anjoo") || c.length > MAX_FILE) continue
            out[p] = c
        }
        return out
    }

    private fun touch(ctx: Context, dir: File) {
        dir.setLastModified(System.currentTimeMillis())
        Coder.keepCopy(ctx, dir)
        try { Coder.onChanged?.invoke(dir) } catch (_: Exception) {}
    }

    private fun scope(a: JSONObject): String = a.optString("path", "").trim().replace('\\', '/').trim('/')

    fun run(ctx: Context, a: JSONObject, find: () -> Pair<File?, String>): String {
        val action = a.optString("action", "symbols").trim().lowercase().replace('-', '_').replace(' ', '_')
        val (dir, err) = find()
        if (dir == null) return err
        val files = codeFiles(dir)
        return try {
            when (action) {
                "symbols", "outline", "list_symbols" -> symbols(files, a)
                "definition", "define", "go_to_definition", "def" -> definition(files, a)
                "references", "refs", "find_references", "usages" -> refs(files, a)
                "rename", "rename_symbol" -> rename(ctx, dir, files, a)
                "apply_patch", "patch", "diff_apply" -> patch(ctx, dir, files, a)
                "locate", "find_code", "semantic_search", "where" -> locate(files, a)
                else -> "project_code action chunein: symbols, definition, references, rename, apply_patch, locate."
            }
        } catch (e: CancelledException) { throw e }
    }

    private fun symbols(files: Map<String, String>, a: JSONObject): String {
        val sc = scope(a)
        val kind = a.optString("kind", "").lowercase()
        val sb = StringBuilder()
        var total = 0
        for ((p, t) in files) {
            if (sc.isNotEmpty() && p != sc && !p.startsWith("$sc/")) continue
            val defs = definitions(p, t).filter { kind.isEmpty() || it.kind == kind }
            if (defs.isEmpty()) continue
            total += defs.size
            sb.append(p).append('\n')
            for (d in defs.take(80)) sb.append("  ").append(d.line).append("  ").append(d.kind).append(' ').append(d.name).append('\n')
            if (defs.size > 80) sb.append("  ... ").append(defs.size - 80).append(" more\n")
        }
        return if (total == 0) "No definitions found" + (if (sc.isNotEmpty()) " in $sc" else "") + ". (Supported: py, js/ts, kt, java/cs/dart/swift/c/cpp, go, rs, php.)" else cap("$total definitions\n" + sb.toString().trim())
    }

    private fun nameOf(a: JSONObject): String = a.optString("name", a.optString("symbol", a.optString("query", ""))).trim()

    private fun definition(files: Map<String, String>, a: JSONObject): String {
        val n = nameOf(a)
        if (n.isEmpty() || !isIdent(n)) return "Give name= (a function, class or variable name)."
        val hits = ArrayList<Def>()
        for ((p, t) in files) if (t.contains(n)) hits.addAll(definitions(p, t).filter { it.name == n })
        if (hits.isEmpty()) return "No definition of '$n' found by pattern. It may be imported from a library, defined dynamically or in an unsupported language. Try project_code action=references name=$n or project_search."
        val sb = StringBuilder()
        for (d in hits.take(8)) {
            val ls = files[d.path]!!.split("\n")
            sb.append(d.path).append(':').append(d.line).append("  ").append(d.kind).append(' ').append(n).append('\n')
            for (k in (d.line - 1) until minOf(ls.size, d.line + 7)) sb.append(String.format(java.util.Locale.US, "%5d\t", k + 1)).append(ls[k].take(200)).append('\n')
            sb.append('\n')
        }
        if (hits.size > 8) sb.append("... and ").append(hits.size - 8).append(" more definitions with this name (name based: check which one you need)\n")
        return cap(sb.toString().trim())
    }

    private fun refs(files: Map<String, String>, a: JSONObject): String {
        val n = nameOf(a)
        if (n.isEmpty() || !isIdent(n)) return "Give name= (an identifier)."
        val r = references(files, n, scope(a))
        if (r.isEmpty()) return "'$n' is not used anywhere" + (if (scope(a).isNotEmpty()) " in " + scope(a) else "") + "."
        val defLines = HashSet<String>()
        for ((p, t) in files) definitions(p, t).filter { it.name == n }.forEach { defLines.add(p + ":" + it.line) }
        val code = r.filter { it.inCode }
        val other = r.size - code.size
        val sb = StringBuilder("'$n': ${code.size} use(s) in code" + (if (other > 0) ", $other in comments/strings" else "") + ", " + code.map { it.path }.distinct().size + " file(s)\n")
        for ((p, list) in code.groupBy { it.path }) {
            sb.append(p).append('\n')
            for (x in list.take(25)) sb.append("  ").append(x.line).append(if (defLines.contains(p + ":" + x.line)) "  [definition]  " else "  ").append(x.text).append('\n')
            if (list.size > 25) sb.append("  ... ").append(list.size - 25).append(" more\n")
        }
        if (other > 0) sb.append("In comments/strings (not renamed by default): ").append(r.filter { !it.inCode }.take(6).joinToString("; ") { it.path + ":" + it.line }).append('\n')
        sb.append("(name based: an identically named member of another class counts too)")
        return cap(sb.toString().trim())
    }

    private fun rename(ctx: Context, dir: File, files: Map<String, String>, a: JSONObject): String {
        val from = nameOf(a)
        val to = a.optString("to", a.optString("new_name", "")).trim()
        if (!isIdent(from) || !isIdent(to)) return "Give name= (old) and to= (new): both must be plain identifiers."
        if (from == to) return "The new name is the same."
        val sc = scope(a)
        val dry = a.optBoolean("dry_run", false)
        val clash = files.entries.filter { (sc.isEmpty() || it.key == sc || it.key.startsWith("$sc/")) }.flatMap { (p, t) -> definitions(p, t).filter { it.name == to }.map { p + ":" + it.line } }
        if (clash.isNotEmpty() && !a.optBoolean("force", false))
            return "'$to' is already defined at " + clash.take(4).joinToString(", ") + ". Renaming would merge two things. Pick another name, or pass force=true if that is intended."
        val r = rename(files, from, to, sc, a.optBoolean("include_comments", false))
        if (r.files.isEmpty()) return "'$from' is not used" + (if (sc.isNotEmpty()) " in $sc" else "") + ", nothing to rename."
        val sb = StringBuilder(if (dry) "DRY RUN: would rename" else "Renamed").append(" '$from' -> '$to': ").append(r.perFile.values.sum()).append(" place(s) in ").append(r.files.size).append(" file(s)\n")
        for ((p, n) in r.perFile) sb.append("  ").append(p).append("  ").append(n).append('\n')
        if (r.skipped > 0) sb.append(r.skipped).append(" mention(s) in comments/strings left as they are (include_comments=true renames them too).\n")
        if (!dry) {
            Coder.snapshot(ctx, dir)
            for ((p, t) in r.files) File(dir, p).writeText(t, Charsets.UTF_8)
            touch(ctx, dir)
            sb.append("Names inside string keys (JSON keys, HTML ids/classes, reflection) are NOT code and were not changed: run project_check and project_code action=references name=$from to see what remains. (undo: project_history action=undo)")
        }
        return cap(sb.toString().trim())
    }

    private fun patch(ctx: Context, dir: File, files: Map<String, String>, a: JSONObject): String {
        val text = a.optString("patch", a.optString("diff", a.optString("content", "")))
        if (text.isBlank()) return "Give patch= (a unified diff: --- a/path, +++ b/path, @@ hunks)."
        val r = applyPatch(files, parsePatch(text))
        if (r.error != null) return "Patch NOT applied. " + r.error
        if (a.optBoolean("dry_run", false)) return "DRY RUN: the patch applies cleanly: " + r.summary.joinToString("; ")
        Coder.snapshot(ctx, dir)
        for ((p, t) in r.files) { File(dir, p).parentFile?.mkdirs(); File(dir, p).writeText(t, Charsets.UTF_8) }
        for (p in r.deleted) File(dir, p).delete()
        touch(ctx, dir)
        return "Patch applied: " + r.summary.joinToString("; ") + ". Run project_check next. (undo: project_history action=undo)"
    }

    private fun locate(files: Map<String, String>, a: JSONObject): String {
        val q = a.optString("query", a.optString("name", "")).trim()
        if (q.isEmpty()) return "Give query= (words about what you look for, e.g. \"login token refresh\")."
        val hits = locate(files, q)
        if (hits.isEmpty()) return "Nothing matches those words. Try other words (names of things, not sentences) or project_search with a pattern."
        return cap("Best matches for \"$q\" (ranked text search, no AI):\n" + hits.joinToString("\n") { it.path + ":" + it.from + "-" + it.to + "  " + it.preview } +
            "\nOpen the best one with project_read path=... offset=...")
    }
}
