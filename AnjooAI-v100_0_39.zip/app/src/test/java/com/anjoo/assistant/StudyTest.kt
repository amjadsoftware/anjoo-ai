package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StudyTest {
    @Test fun promptNamesTheRealToolsAndRequiresApproval() {
        val p = Study.promptBlock()
        assertTrue(p.contains("search_web"))
        assertTrue(p.contains("fetch_page"))
        assertTrue(p.contains("knowledge_add"))
        assertTrue(p.contains("poochho"))
    }

    @Test fun onlyHttpSourcesCountAsWebLearned() {
        assertTrue(Study.isWebSource("https://developer.android.com/x"))
        assertTrue(Study.isWebSource("  HTTP://example.com"))
        assertFalse(Study.isWebSource("AI-added note"))
        assertFalse(Study.isWebSource("Anjoo built-in pack"))
    }

    @Test fun noteIsShortAndKeepsItsSource() {
        val long = "a".repeat(Study.MAX_NOTE_CHARS + 500)
        val n = Study.note(long, "https://example.com/doc")
        assertTrue(n.contains("Source: https://example.com/doc"))
        assertTrue(n.length <= Study.MAX_NOTE_CHARS + 60)
        assertEquals("text\n\nSource: https://a.b", Study.note("text", "https://a.b"))
        assertEquals("see https://a.b", Study.note("see https://a.b", "https://a.b"))
    }

    @Test fun previewIsBounded() {
        val p = Study.preview("T", "https://a.b", "x".repeat(2000))
        assertTrue(p.length < 800)
        assertTrue(p.endsWith("..."))
    }

    @Test fun scheduledStudyNeverSavesByItself() {
        val j = Study.jobPrompt("Android baseline profiles")
        assertTrue(j.contains("search_web") && j.contains("fetch_page"))
        assertTrue(j.contains("Do NOT call knowledge_add"))
        assertTrue(Study.jobPrompt("x".repeat(900)).length < 900)
        assertTrue(Study.promptBlock().contains("schedule_agent"))
    }
}
