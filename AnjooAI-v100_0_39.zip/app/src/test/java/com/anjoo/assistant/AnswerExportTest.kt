package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AnswerExportTest {
    private val md = "# Sales\n\n| Item | Qty |\n|---|---|\n| Pen | 3 |\n| Book | 5 |\n"
    @Test fun findsTable() {
        val t = AnswerExport.tables(md)
        assertEquals(1, t.size)
        assertEquals(listOf("Item", "Qty"), t[0][0])
        assertEquals(3, t[0].size)
    }
    @Test fun sheetsHaveCsv() { assertTrue(AnswerExport.sheets(md).contains("\"Pen\",\"3\"")) }
    @Test fun shortPlainAnswerHasNoCard() { assertFalse(AnswerExport.worthIt("Haan, theek hai.")) }
    @Test fun tableAnswerHasCard() { assertTrue(AnswerExport.worthIt(md)) }
    @Test fun titleAndFileName() {
        assertEquals("Sales", AnswerExport.title(md))
        assertEquals("sales.pdf", AnswerExport.fileName("Sales", "pdf"))
    }
}
