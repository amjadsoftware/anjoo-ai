package com.anjoo.assistant

import org.junit.Assert.assertTrue
import org.junit.Test

class AppMapTest {
    @Test fun lookupFindsHologramAndOrb() {
        val r = AppMap.lookup("hologram")
        assertTrue(r.contains("Hologram image"))
        assertTrue(r.contains("default Off"))
    }

    @Test fun emptyQueryReturnsEverything() {
        val r = AppMap.lookup("")
        assertTrue(r.contains("Main chat screen"))
        assertTrue(r.contains("Backup and restore"))
    }

    @Test fun unknownQueryIsHonest() = assertTrue(AppMap.lookup("zzzqqq").contains("Nothing matching"))

    @Test fun promptBlockMentionsToolAndQualityBar() {
        assertTrue(AppMap.promptBlock().contains("app_map"))
        assertTrue(Style.INTELLIGENCE.contains("run_python"))
    }

    @Test fun memoryAndApkBuilderScreensAreKnown() {
        val m = AppMap.lookup("memory")
        assertTrue(m.contains("Manage Memory & Knowledge"))
        assertTrue(m.contains("Build AI Index"))
        val a = AppMap.lookup("apk")
        assertTrue(a.contains("Connect GitHub"))
        assertTrue(a.contains("Build type"))
    }

    @Test fun settingsDisplayAgentAndFixAreKnown() {
        assertTrue(AppMap.lookup("text size").contains("whole app"))
        assertTrue(AppMap.lookup("language").contains("Anjoo language"))
        assertTrue(AppMap.lookup("agent system").contains("Open Task Board"))
        assertTrue(AppMap.lookup("fix the problem").contains("Open Settings"))
        assertTrue(AppMap.lookup("privacy lock").contains("encrypted"))
        assertTrue(AppMap.lookup("chatgpt").contains("Ask another AI model"))
    }
}
