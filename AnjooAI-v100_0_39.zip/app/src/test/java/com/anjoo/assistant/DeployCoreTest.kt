package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class DeployCoreTest {
    private fun data(n: Int) = ByteArray(n) { (it % 251).toByte() }

    // Vectors generated with the official libblake3 (input byte i = i % 251).
    @Test fun blake3MatchesOfficialLibrary() {
        assertEquals("af1349b9f5f9a1a6a0404dea36dcc9499bcb25c9adc112b7cc9a93cae41f3262", DeployCore.blake3Hex(ByteArray(0)))
        assertEquals("2d3adedff11b61f14c886e35afa036736dcd87a74d27b5c1510225d0f592e213", DeployCore.blake3Hex(data(1)))
        assertEquals("e9bc37a594daad83be9470df7f7b3798297c3d834ce80ba85d6e207627b7db7b", DeployCore.blake3Hex(data(63)))
        assertEquals("ac69f8086484814f8b5062bcaa846bde9011e3f931eaa83275c85c4d7f435f10", DeployCore.blake3Hex(data(300001)))
    }

    @Test fun cloudflareHashUsesBase64PlusExtension() {
        assertEquals("17453d0cfb9bacc76d9f30d3cb9ca048", DeployCore.cfHash("<h1>hi</h1>\n".toByteArray(), "index.html"))
        assertEquals("c89c27f28e24f706b72c408fe1d6537a", DeployCore.cfHash("x".toByteArray(), "LICENSE"))
    }

    @Test fun base64MatchesJava() {
        for (n in listOf(0, 1, 2, 3, 4, 5, 100, 1000)) {
            val d = ByteArray(n) { (it * 7).toByte() }
            assertEquals(java.util.Base64.getEncoder().encodeToString(d), DeployCore.base64(d))
        }
    }

    @Test fun envFilesParse() {
        val e = DeployCore.parseEnv("# c\nA=1\nexport B=\"two words\"\nC='x y'\nD=val # note\nE=\nbad key=1\n1X=2\nA=3\n")
        assertEquals("3", e["A"]); assertEquals("two words", e["B"]); assertEquals("x y", e["C"]); assertEquals("val", e["D"]); assertEquals("", e["E"])
        assertFalse(e.containsKey("bad key")); assertFalse(e.containsKey("1X"))
    }

    @Test fun secretFilesAreNeverPublished() {
        for (p in listOf(".env", "sub/.env.local", ".env.example", "release.jks", "key.pem", ".anjoo-git.json")) assertTrue(p, DeployCore.isPrivate(p))
        assertFalse(DeployCore.isPrivate("index.html")); assertFalse(DeployCore.isPrivate("js/environment.js"))
        val d = java.nio.file.Files.createTempDirectory("dc").toFile()
        try {
            File(d, "index.html").writeText("<html>"); File(d, ".env").writeText("K=v"); File(d, "node_modules").mkdirs(); File(d, "node_modules/x.js").writeText("1")
            val c = DeployCore.collect(d)
            assertEquals(listOf("index.html"), c.files.map { it.name }); assertEquals(listOf(".env"), c.excluded)
        } finally { d.deleteRecursively() }
    }

    @Test fun remoteNamesAreSafe() {
        assertEquals("meri-dukaan-2024", DeployCore.slug("Meri Dukaan 2024!!")); assertEquals("site", DeployCore.slug("###"))
        assertEquals(40, DeployCore.slug("a".repeat(80)).length)
    }
}
