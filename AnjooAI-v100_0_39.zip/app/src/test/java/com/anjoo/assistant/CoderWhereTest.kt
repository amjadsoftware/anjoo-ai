package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** The auto-fix step shows the model the exact failing lines, not only the error text. */
class CoderWhereTest {
    @Test fun pythonTracebackPointsAtTheFailingLine() {
        val files = mapOf("app.py" to "a = 1\nb = 2\nprint(undefined)\nc = 3\n")
        val err = "Traceback (most recent call last):\n  File \"app.py\", line 3, in <module>\nNameError: name 'undefined' is not defined"
        val t = Coder.whereItHappens(files, err)
        assertTrue(t.contains("app.py:3"))
        assertTrue(t.contains(">>"))
        assertTrue(t.contains("print(undefined)"))
    }

    @Test fun textWithoutProjectLocationsGivesNothing() {
        assertEquals("", Coder.whereItHappens(mapOf("app.py" to "a = 1\n"), "something went wrong"))
    }
}
