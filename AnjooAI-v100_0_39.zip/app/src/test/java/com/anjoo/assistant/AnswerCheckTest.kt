package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AnswerCheckTest {
    private fun ran(name: String, action: String = "", ok: Boolean = true, result: String = "") = AnswerCheck.Ran(name, action, ok, result)
    private val none = emptyList<AnswerCheck.Ran>()

    @Test fun testsPassedWithoutATestRunIsFlagged() {
        assertEquals(listOf(AnswerCheck.Kind.TESTS), AnswerCheck.findings("All tests passed.", none))
    }

    @Test fun testsPassedWithARealPassingRunIsNotFlagged() {
        val r = listOf(ran("project_check", "test", true, "RESULT: PASS 12 tests"))
        assertTrue(AnswerCheck.findings("All tests passed.", r).isEmpty())
    }

    @Test fun testsPassedAfterAFailingRunIsFlagged() {
        val r = listOf(ran("project_check", "test", true, "RESULT: FAIL 2 failed"))
        assertEquals(listOf(AnswerCheck.Kind.TESTS), AnswerCheck.findings("All tests passed.", r))
    }

    @Test fun adviceAndNegationsAreNotFlagged() {
        assertTrue(AnswerCheck.findings("Make sure the tests pass before you ship.", none).isEmpty())
        assertTrue(AnswerCheck.findings("I haven't published it yet.", none).isEmpty())
        assertTrue(AnswerCheck.findings("The email was not sent.", none).isEmpty())
    }

    @Test fun codeBlocksAreIgnored() {
        assertTrue(AnswerCheck.findings("Here is the script:\n```\nprint('tests passed')\n```", none).isEmpty())
    }

    @Test fun publishedClaimNeedsADeployStep() {
        assertEquals(listOf(AnswerCheck.Kind.PUBLISH), AnswerCheck.findings("The site is live at example.com.", none))
        assertTrue(AnswerCheck.findings("The site is live at example.com.", listOf(ran("project_deploy"))).isEmpty())
    }

    @Test fun sentClaimNeedsASuccessfulSendTool() {
        assertEquals(listOf(AnswerCheck.Kind.SENT), AnswerCheck.findings("I sent the email.", none))
        assertEquals(listOf(AnswerCheck.Kind.SENT), AnswerCheck.findings("I sent the email.", listOf(ran("send_email", ok = false))))
        assertTrue(AnswerCheck.findings("I sent the email.", listOf(ran("send_email"))).isEmpty())
    }

    @Test fun romanUrduDocumentClaimIsChecked() {
        assertEquals(listOf(AnswerCheck.Kind.DOCUMENT), AnswerCheck.findings("Maine PDF bana di hai", none))
        assertTrue(AnswerCheck.findings("Maine PDF bana di hai", listOf(ran("make_document"))).isEmpty())
    }

    @Test fun annotateAddsOneWarningAndIsIdempotent() {
        val once = AnswerCheck.annotate("All tests passed.", none)
        assertTrue(once.contains("no test run in this request confirms it"))
        assertEquals(once, AnswerCheck.annotate(once, none))
        assertEquals("Hello there, how can I help?", AnswerCheck.annotate("Hello there, how can I help?", none))
    }
}
