package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RepetitionGuardTest {
    private val item = "Enterprise-Level School Management ERP: Poori school management ERP system banani, jaise students, teachers, classes, attendance, exams, results, fees, aur library management."

    private fun loopedAnswer(): String {
        val sb = StringBuilder("Yeh rahi 15 ideas:\n1. Smart Attendance App: Face scan se hazri lagane wali mobile app banani hai.\n2. Fee Reminder Bot: Parents ko WhatsApp par fees yaad dilane wala bot.\n")
        for (n in 3..15) sb.append("**$n.** **Enterprise-Level School Management ERP:** ${item.substringAfter(": ")}\n".replace("**$n.** **Enterprise-Level School Management ERP:**", "$n. Enterprise-Level School Management ERP:"))
        return sb.toString()
    }

    @Test fun numberedLoopIsCutToTheFirstCopy() {
        val fixed = RepetitionGuard.fix(loopedAnswer())
        assertEquals(1, Regex("Enterprise-Level School Management ERP").findAll(fixed).count())
        assertTrue(fixed.contains("Smart Attendance App"))
        assertTrue(fixed.endsWith(RepetitionGuard.NOTE))
    }

    @Test fun fixIsIdempotent() {
        val once = RepetitionGuard.fix(loopedAnswer())
        assertEquals(once, RepetitionGuard.fix(once))
    }

    @Test fun normalAnswerIsUnchanged() {
        val t = "First point is about planning the whole project carefully.\nSecond point is about building the first small version.\nThird point is about testing it with real users."
        assertEquals(t, RepetitionGuard.fix(t))
    }

    @Test fun shortRepeatsAndCodeBlocksAreIgnored() {
        val short = "ok\nok\nok\nok\nok"
        assertEquals(short, RepetitionGuard.fix(short))
        val code = "```\nconsole.log('the same long line of code here');\nconsole.log('the same long line of code here');\nconsole.log('the same long line of code here');\n```"
        assertEquals(code, RepetitionGuard.fix(code))
    }

    @Test fun twoSentenceLoopIsFound() {
        val a = "The first sentence in the loop is quite long indeed."
        val b = "The second sentence in the loop is also long enough."
        val t = "Intro line that is not part of any loop at all.\n$a $b $a $b $a $b $a $b"
        val at = RepetitionGuard.loopStart(t)
        assertTrue(at > 0)
        assertEquals(1, Regex("first sentence").findAll(RepetitionGuard.fix(t)).count())
    }

    @Test fun watchChecksOnlyAfterEnoughNewText() {
        val w = RepetitionGuard.Watch()
        assertFalse(w.tripped("short"))
        assertTrue(w.tripped(loopedAnswer() + "x".repeat(500)))
    }
}
