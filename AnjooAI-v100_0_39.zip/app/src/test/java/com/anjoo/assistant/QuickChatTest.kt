package com.anjoo.assistant

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class QuickChatTest {
    @Test fun greetingsAreQuick() {
        for (s in listOf("Hi", "hello", "Salam", "Assalam o alaikum", "kya haal hai", "shukriya", "thanks", "سلام", "کیا حال ہے")) assertTrue(s, QuickChat.isSmallTalk(s))
    }
    @Test fun commandsAndQuestionsAreNot() {
        for (s in listOf("ok", "haan", "yes", "ji", "call ali", "open whatsapp", "hi call ali", "weather kaisa hai", "ok send message to ahmed", "hi can you write code", "", "a".repeat(50))) assertFalse(s, QuickChat.isSmallTalk(s))
    }
    @Test fun toolHistoryDetected() {
        val h = JSONArray().put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("functionCall", JSONObject().put("name", "call")))))
        assertTrue(QuickChat.recentTools(h))
        assertFalse(QuickChat.recentTools(JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", "hi"))))))
    }
}
