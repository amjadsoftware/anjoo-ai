package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FinanceCoreTest {
    private val prices = mapOf("gpt-4o" to (2.5 to 10.0))

    @Test fun expenseKeepsTabsNewlinesAndBackslashes() {
        val e = FinanceCore.Expense(123L, "Open\tAI", 20.5, "inv\n#1 \\ ok")
        assertEquals(e, FinanceCore.decode(FinanceCore.encode(e)))
    }

    @Test fun badRecordsAreIgnored() {
        assertNull(FinanceCore.decode("nonsense"))
        assertNull(FinanceCore.decode("1\tA\tabc\tn"))
        assertNull(FinanceCore.decode("1\tA\t-5\tn"))
        assertNull(FinanceCore.decode("1\tA\tNaN\tn"))
    }

    @Test fun costIsUnknownWithoutAPriceNeverZero() {
        val book = UsageBook()
        book.record("2026-11-07", "OpenAI|gpt-4o", 1_000_000, 500_000)
        book.record("2026-11-07", "Google|gemini-x", 1000, 1000)
        val rows = FinanceCore.costRows(book.totals("2026-11"), prices)
        assertEquals("gpt-4o", rows[0].model)
        assertEquals(7.5, rows[0].cost!!, 1e-9)
        assertNull(rows[1].cost)
        val (sum, allKnown) = FinanceCore.sumKnown(rows)
        assertEquals(7.5, sum, 1e-9)
        assertFalse(allKnown)
    }

    @Test fun projectionAndBudget() {
        assertEquals(30.0, FinanceCore.projection(10.0, 10, 30), 1e-9)
        assertEquals(5.0, FinanceCore.projection(5.0, 0, 30), 1e-9)
        assertEquals(FinanceCore.BudgetState.NONE, FinanceCore.budgetState(50.0, 0.0))
        assertEquals(FinanceCore.BudgetState.OK, FinanceCore.budgetState(79.0, 100.0))
        assertEquals(FinanceCore.BudgetState.NEAR, FinanceCore.budgetState(80.0, 100.0))
        assertEquals(FinanceCore.BudgetState.OVER, FinanceCore.budgetState(100.0, 100.0))
    }

    @Test fun amountParsing() {
        assertEquals(1200.0, FinanceCore.parseAmount("$1,200")!!, 1e-9)
        assertEquals(12.5, FinanceCore.parseAmount(" 12.5 ")!!, 1e-9)
        assertNull(FinanceCore.parseAmount("-3"))
        assertNull(FinanceCore.parseAmount("abc"))
        assertNull(FinanceCore.parseAmount("NaN"))
    }

    @Test fun csvQuotesAndNeutralisesFormulas() {
        val csv = FinanceCore.csv(listOf("a", "b"), listOf(listOf("x,y", "say \"hi\""), listOf("=1+1", "-5")))
        val lines = csv.trimEnd().split("\r\n")
        assertEquals("a,b", lines[0])
        assertEquals("\"x,y\",\"say \"\"hi\"\"\"", lines[1])
        assertEquals("'=1+1,-5", lines[2])
        assertTrue(csv.endsWith("\r\n"))
    }

    @Test fun moneyFormat() {
        assertEquals("$1.50", FinanceCore.money(1.5))
        assertEquals("$0.0012", FinanceCore.money(0.0012))
        assertEquals("$0.00", FinanceCore.money(0.0))
    }
}
