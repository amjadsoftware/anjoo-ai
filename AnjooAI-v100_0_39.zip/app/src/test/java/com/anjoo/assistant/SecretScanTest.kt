package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SecretScanTest {
    private fun kinds(path: String, text: String) = SecretScan.scan(path, text).map { it.kind }

    @Test fun providerKeysAreFoundInSourceAndConfig() {
        assertTrue("AWS access key" in kinds("src/a.kt", "val k = \"AKIAABCDEFGHIJKLMNOP\""))
        assertTrue("GitHub token" in kinds("notes.txt", "token ghp_" + "a1".repeat(18)))
        assertTrue("Stripe live key" in kinds("pay.js", "const k = 'sk_live_" + "Ab3".repeat(10) + "'"))
        assertTrue("Telegram bot token" in kinds("bot.py", "TOKEN = '123456789:AA" + "Bc1".repeat(11) + "'"))
        assertTrue("private key" in kinds("deploy/key.txt", "-----BEGIN RSA PRIVATE KEY-----\nMIIE..."))
    }

    @Test fun envFilesAreScannedByContentNotJustByName() {
        val hits = SecretScan.scan(".env", "DB_PASSWORD=Zq8v!Lx2mP9rTt4Wn\nDEBUG=true\n")
        assertTrue(hits.any { it.kind == "key/password assigned in code" && it.line == 1 })
        assertTrue(hits.any { it.kind == "secret-type file" })
    }

    @Test fun passwordInsideUrlIsFlaggedButPlaceholderIsNot() {
        assertTrue("password inside URL" in kinds("cfg.js", "const u = 'postgres://app:Zq8vLx2mP9@db.internal/main';"))
        assertTrue(kinds("cfg.js", "const u = 'postgres://user:password@localhost/main';").isEmpty())
    }

    @Test fun placeholdersLookupsAndPlainWordsAreNotReported() {
        assertTrue(kinds("a.js", "const apiKey = process.env.API_KEY_VALUE;").isEmpty())
        assertTrue(kinds("a.kt", "val token = BuildConfig.GEMINI_API_KEY").isEmpty())
        assertTrue(kinds("a.py", "password = \"your_password_here\"").isEmpty())
        assertTrue(kinds("a.py", "api_key = \"changeme-changeme\"").isEmpty())
        assertTrue(kinds("a.js", "const authorizationHeader = \"authorizationHeader\";").isEmpty())
        assertTrue(kinds(".env.example", "API_KEY=Zq8v!Lx2mP9rTt4Wn").isEmpty())
        assertTrue(kinds("package-lock.json", "\"token\": \"Zq8v!Lx2mP9rTt4Wn\"").isEmpty())
    }

    @Test fun ignoreCommentSilencesOneLine() {
        assertTrue(kinds("a.js", "const k = 'AKIAABCDEFGHIJKLMNOP'; // secret-scan:ignore").isEmpty())
    }

    @Test fun reportNeverContainsTheSecret() {
        val secret = "Zq8v!Lx2mP9rTt4WnKd7"
        val aws = "AKIAABCDEFGHIJKLMNOP"
        val files = mapOf("config.properties" to "db.password=$secret\n", "src/App.kt" to "val k = \"$aws\"")
        val report = SecretScan.report("Demo", files)
        assertFalse(report.contains(secret))
        assertFalse(report.contains(aws))
        assertTrue(report.contains("value redacted"))
        assertTrue(report.contains("CRITICAL 1"))
    }

    @Test fun engineeringQualityGateBlocksOnConfigFileSecret() {
        val files = mapOf("settings.yml" to "client_secret: Zq8v!Lx2mP9rTt4WnKd7\n")
        assertTrue(Engineering.findings(files).any { it.code == "POSSIBLE_HARDCODED_SECRET" })
        assertTrue(Engineering.report("Demo", files, "secrets").startsWith("SECRET SCAN"))
    }

    @Test fun entropySeparatesRandomFromWords() {
        assertTrue(SecretScan.entropy("Zq8v!Lx2mP9rTt4Wn") > 3.5)
        assertEquals(0.0, SecretScan.entropy("aaaaaaaa"), 0.0001)
    }
}
