package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CodeNavTest {

    @Test fun masksCommentsAndStrings() {
        val js = "let a = 1; // count a\nlet s = \"a b\"; /* a */ let t = `a\na`; a++;"
        val m = CodeNav.mask(js, "c", "x.js")
        assertEquals(js.length, m.length)
        assertEquals(2, Regex("\\ba\\b").findAll(m).count())   // 'let a' and 'a++'
        val py = "x = 1  # x here\nd = '''x\nx'''\ny = \"x\" + str(x)\n"
        val pm = CodeNav.mask(py, "hash", "x.py")
        assertEquals(2, Regex("\\bx\\b").findAll(pm).count())   // 'x = 1' and 'str(x)'
                assertTrue(CodeNav.mask("fn f<'a>(x: &'a str) -> char { 'z' }", "c", "x.rs").contains("&'a str"))
        assertFalse(CodeNav.mask("fn f() -> char { 'z' }", "c", "x.rs").contains("'z'"))
    }

    @Test fun findsDefinitions() {
        val py = CodeNav.definitions("a.py", "import os\nLIMIT = 3\nclass Foo:\n    def bar(self): pass\n# def hidden(): pass\nasync def run(): pass\n")
        assertEquals(listOf("LIMIT:variable", "Foo:class", "bar:function", "run:function"), py.map { it.name + ":" + it.kind })
        assertEquals(3, py.first { it.name == "Foo" }.line)
        val js = CodeNav.definitions("a.js", "export function load() {}\nconst x = () => 1;\nclass Box {\n  async open(a, b) {\n  }\n  if (x) {\n  }\n}\n")
        assertEquals(listOf("load", "x", "Box", "open"), js.map { it.name })
        val kt = CodeNav.definitions("A.kt", "class A {\n    private fun go(x: Int) = x\n    val n = 1\n}\nobject Main\n")
        assertEquals(listOf("A", "go", "n", "Main"), kt.map { it.name })
        val go = CodeNav.definitions("a.go", "func (s *S) Run() {}\nfunc main() {}\ntype T struct{}\n")
        assertEquals(listOf("Run", "main", "T"), go.map { it.name })
    }

    @Test fun referencesSplitCodeAndText() {
        val files = mapOf("a.js" to "function total(x) { return x }\n// total is here\nconst s = 'total';\ntotal(1);\n", "b.js" to "total(2); subtotal(3); total_x = 1;\n")
        val r = CodeNav.references(files, "total")
        assertEquals(5, r.size)
        assertEquals(3, r.count { it.inCode })
        assertEquals(listOf(1, 4, 1), r.filter { it.inCode }.map { it.line })
        assertEquals(1, CodeNav.references(files, "total", "b.js").size)
    }

    @Test fun renamesOnlyCode() {
        val files = mapOf("a.js" to "function total(x) { return x }\n// total is here\nconst s = 'total';\ntotal(1);\n", "b.js" to "total(2); subtotal(3);\n", "c.txt" to "total")
        val r = CodeNav.rename(files, "total", "sum")
        assertEquals("function sum(x) { return x }\n// total is here\nconst s = 'total';\nsum(1);\n", r.files["a.js"])
        assertEquals("sum(2); subtotal(3);\n", r.files["b.js"])
        assertEquals(1, r.files.filter { it.key == "c.txt" }.size)
        assertEquals(4, r.code)
        assertEquals(2, r.skipped)
        val all = CodeNav.rename(files, "total", "sum", "", true)
        assertTrue(all.files["a.js"]!!.contains("// sum is here") && all.files["a.js"]!!.contains("'sum'"))
        assertEquals(1, CodeNav.rename(files, "total", "sum", "b.js").files.size)
        assertTrue(CodeNav.isIdent("a_b1") && CodeNav.isIdent("\$x") && !CodeNav.isIdent("1a") && !CodeNav.isIdent("a b"))
    }

    private val file = "line1\nline2\nline3\nline4\nline5\n"

    @Test fun appliesPatch() {
        val patch = "--- a/f.txt\n+++ b/f.txt\n@@ -2,3 +2,3 @@\n line2\n-line3\n+LINE3\n line4\n"
        val r = CodeNav.applyPatch(mapOf("f.txt" to file), CodeNav.parsePatch(patch))
        assertNull(r.error)
        assertEquals("line1\nline2\nLINE3\nline4\nline5\n", r.files["f.txt"])
    }

    @Test fun patchToleratesWrongLineNumbersAndTrailingSpaces() {
        val patch = "--- a/f.txt\n+++ b/f.txt\n@@ -40,2 +40,3 @@\n line4  \n+inserted\n line5\n"
        val r = CodeNav.applyPatch(mapOf("f.txt" to file), CodeNav.parsePatch(patch))
        assertNull(r.error)
        assertEquals("line1\nline2\nline3\nline4\ninserted\nline5\n", r.files["f.txt"])
    }

    @Test fun patchIsAllOrNothing() {
        val patch = "--- a/f.txt\n+++ b/f.txt\n@@ -1,1 +1,1 @@\n-line1\n+ONE\n--- a/g.txt\n+++ b/g.txt\n@@ -1,1 +1,1 @@\n-missing\n+x\n"
        val r = CodeNav.applyPatch(mapOf("f.txt" to file, "g.txt" to "other\n"), CodeNav.parsePatch(patch))
        assertTrue(r.error!!.contains("g.txt"))
        assertTrue(r.files.isEmpty())
    }

    @Test fun patchCreatesAndDeletes() {
        val patch = "--- /dev/null\n+++ b/new/n.txt\n@@ -0,0 +1,2 @@\n+hello\n+world\n--- a/old.txt\n+++ /dev/null\n@@ -1,1 +0,0 @@\n-bye\n"
        val r = CodeNav.applyPatch(mapOf("old.txt" to "bye\n"), CodeNav.parsePatch(patch))
        assertNull(r.error)
        assertEquals("hello\nworld\n", r.files["new/n.txt"])
        assertEquals(setOf("old.txt"), r.deleted)
        assertTrue(CodeNav.applyPatch(emptyMap(), CodeNav.parsePatch("nothing")).error != null)
    }

    @Test fun patchAppendsAtEnd() {
        val patch = "--- a/f.txt\n+++ b/f.txt\n@@ -5,0 +6,1 @@\n+line6\n"
        val r = CodeNav.applyPatch(mapOf("f.txt" to file), CodeNav.parsePatch(patch))
        assertNull(r.error)
        assertEquals(file + "line6\n", r.files["f.txt"])
    }

    @Test fun locatesByWords() {
        val files = mapOf(
            "auth.js" to "function refreshToken(user) {\n  // refresh the login token\n  return fetch('/token')\n}\n",
            "ui.js" to "function drawButton() {\n  document.body.append('x')\n}\n",
            "README.md" to "A small app")
        val hits = CodeNav.locate(files, "where is the login token refreshed")
        assertEquals("auth.js", hits.first().path)
        assertEquals(listOf("get", "user", "name"), CodeNav.words("getUserName"))
        assertTrue(CodeNav.locate(files, "zzzz qqqq").isEmpty())
    }
}
