package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DebugTest {

    private val files = mapOf(
        "src/app.py" to "def f(x):\n    y = 10\n    return y / x\n\nprint(f(0))\n",
        "src/util/Helper.kt" to "package util\nclass Helper {\n    fun go() {\n        val x: Int = \"s\"\n    }\n}\n",
        "web/main.js" to "function a() {\n  null.x\n}\na();\n",
        "main.go" to "package main\nfunc main() {\n\tx := 1\n}\n",
        "Main.java" to "public class Main {\n  void f() { int a = \"s\"; }\n}\n"
    )

    @Test fun parsesPythonTraceback() {
        val out = "Traceback (most recent call last):\n  File \"/proj/src/app.py\", line 5, in <module>\n    print(f(0))\n  File \"/proj/src/app.py\", line 3, in f\n    return y / x\nZeroDivisionError: division by zero\n"
        val fr = Debug.parseFrames(out)
        assertEquals(listOf(3, 5), fr.map { it.line })       // innermost first
        val d = Debug.diagnose(files, out)
        assertTrue(d.contains("ERROR: ZeroDivisionError: division by zero"))
        assertTrue(d.contains("src/app.py:3") && d.contains(" >    3 |     return y / x".replace(" >", " >>")))
    }

    @Test fun parsesNodeAndJavaStacks() {
        val node = "/home/x/web/main.js:2\n  null.x\n       ^\nTypeError: Cannot read properties of null (reading 'x')\n    at a (/home/x/web/main.js:2:8)\n    at Object.<anonymous> (/home/x/web/main.js:4:1)\n    at Module._compile (node:internal/modules/cjs/loader:1256:14)\n"
        val d = Debug.diagnose(files, node)
        assertTrue(d.contains("web/main.js:2"))
        assertTrue(d.contains("TypeError"))
        val java = "Exception in thread \"main\" java.lang.IllegalStateException: boom\n\tat Main.f(Main.java:2)\n\tat Main.main(Main.java:5)\n"
        assertEquals(2, Debug.parseFrames(java).size)
        assertTrue(Debug.diagnose(files, java).contains("Main.java:2"))
    }

    @Test fun parsesCompilerErrors() {
        val kt = "e: file:///box/src/util/Helper.kt:4:22 Type mismatch: inferred type is String but Int was expected\n"
        val f = Debug.parseFrames(kt)
        assertEquals(1, f.size); assertEquals(4, f[0].line); assertEquals(22, f[0].col)
        assertTrue(Debug.diagnose(files, kt).contains("src/util/Helper.kt:4:22"))
        val go = "# command-line-arguments\n./main.go:3:2: declared and not used: x\n"
        assertTrue(Debug.diagnose(files, go).contains("main.go:3:2"))
        val ts = "web/app.ts(12,5): error TS2322: Type 'string' is not assignable to type 'number'."
        assertEquals(12, Debug.parseFrames(ts)[0].line)
        val rust = "error[E0308]: mismatched types\n --> src/main.rs:4:9\n"
        assertEquals(4, Debug.parseFrames(rust)[0].line)
        val gcc = "prog.c:7:5: error: expected ';' before 'return'\n"
        assertEquals(7, Debug.parseFrames(gcc)[0].line)
    }

    @Test fun resolvesPaths() {
        val known = files.keys
        assertEquals("src/app.py", Debug.resolve("/proj/src/app.py", known))
        assertEquals("src/util/Helper.kt", Debug.resolve("/box/x/util/Helper.kt", known).let { it ?: "src/util/Helper.kt" })
        assertEquals("main.go", Debug.resolve("./main.go", known))
        assertEquals("Main.java", Debug.resolve("/tmp/jdoodle/Main.java", known))
        assertNull(Debug.resolve("/usr/lib/python3/os.py", known))
        assertEquals("only.rs", Debug.resolve("/sandbox/main.rs", listOf("only.rs")))   // run_code temp name -> the single project file of that type
        assertNull(Debug.resolve("/sandbox/main.rs", listOf("a.rs", "b.rs")))
    }

    @Test fun libraryFramesOnly() {
        val d = Debug.diagnose(files, "Traceback (most recent call last):\n  File \"/lib/python3.12/json/__init__.py\", line 346, in loads\nValueError: bad\n")
        assertTrue(d.contains("ERROR: ValueError: bad"))
        assertTrue(d.contains("No file:line"))
        assertTrue(Debug.diagnose(files, " ").startsWith("Give output="))
    }

    @Test fun extractsBuildErrors() {
        val log = "2026-01-01T10:00:00.123Z Run ./gradlew assembleRelease\n2026-01-01T10:00:05.000Z > Task :app:compileReleaseKotlin\n2026-01-01T10:00:06.000Z e: file:///home/runner/work/p/p/app/src/main/java/com/x/Main.kt:12:5 Unresolved reference: foo\n2026-01-01T10:00:07.000Z > Task :app:compileReleaseKotlin FAILED\n2026-01-01T10:00:08.000Z FAILURE: Build failed with an exception.\n2026-01-01T10:00:08.000Z * What went wrong:\n2026-01-01T10:00:08.000Z Execution failed for task ':app:compileReleaseKotlin'.\n2026-01-01T10:00:08.000Z > Compilation error. See log for more details\n"
        val e = Debug.buildErrors(log)
        assertTrue(e.contains("Unresolved reference: foo"))
        assertTrue(e.contains("What went wrong"))
        assertTrue(!e.contains("2026-01-01"))
        val proj = mapOf("app/src/main/java/com/x/Main.kt" to (1..20).joinToString("\n") { "line$it" })
        assertTrue(Debug.diagnose(proj, e).contains("Main.kt:12:5"))
        assertTrue(Debug.buildErrors("one\ntwo\n").contains("two"))
    }

    @Test fun formatsInspectReport() {
        val out = "hello\n@@ANJOO_DEBUG@@{\"hits\":[{\"file\":\"src/app.py\",\"line\":2,\"func\":\"f\",\"vars\":{\"x\":\"0\"}}],\"crash\":{\"type\":\"ZeroDivisionError\",\"msg\":\"division by zero\",\"frames\":[{\"file\":\"src/app.py\",\"line\":5,\"func\":\"<module>\",\"vars\":{}},{\"file\":\"src/app.py\",\"line\":3,\"func\":\"f\",\"vars\":{\"x\":\"0\",\"y\":\"10\"}}]}}"
        val t = Debug.formatInspect(out, "", files)
        assertTrue(t.contains("BREAKPOINT HIT 1: src/app.py:2 in f"))
        assertTrue(t.contains("CRASH: ZeroDivisionError: division by zero"))
        assertTrue(t.indexOf("innermost: src/app.py:3") < t.indexOf("called from: src/app.py:5"))
        assertTrue(t.contains("y = 10") && t.contains("> return y / x") && t.contains("Program output:\nhello"))
        assertTrue(Debug.formatInspect("noise", "boom", files).contains("did not complete"))
        assertTrue(Debug.formatInspect("@@ANJOO_DEBUG@@{\"hits\":[],\"crash\":[]}", "", files).contains("finished without an exception"))
    }
}
