package com.anjoo.assistant

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The build runner: which workflow a project gets and how the GitHub run list is read. */
class GitCiTest {
    @Test fun ownWorkflowIsRespected() {
        assertTrue(Git.hasWorkflow(listOf(".github/workflows/ci.yml", "main.go")))
        assertTrue(Git.hasWorkflow(listOf(".github/workflows/build.yaml")))
        assertFalse(Git.hasWorkflow(listOf("main.go", "README.md")))
    }

    @Test fun androidGradleProjectBuildsDebugAndUnitTests() {
        val w = Git.ciWorkflow(mapOf("gradlew" to "", "app/build.gradle.kts" to "plugins { id(\"com.android.application\") }"))
        assertNotNull(w)
        assertTrue(w!!.first.contains("Android"))
        assertTrue(w.second.contains("assembleDebug testDebugUnitTest"))
        assertTrue(w.second.contains("chmod +x ./gradlew"))
        assertTrue(w.second.contains("setup-java"))
    }

    @Test fun otherStacksGetTheirOwnBuild() {
        assertTrue(Git.ciWorkflow(mapOf("go.mod" to "module x"))!!.second.contains("go test ./..."))
        assertTrue(Git.ciWorkflow(mapOf("Cargo.toml" to "[package]"))!!.second.contains("cargo test"))
        assertTrue(Git.ciWorkflow(mapOf("pom.xml" to "<project/>"))!!.second.contains("mvn -B verify"))
        assertTrue(Git.ciWorkflow(mapOf("package.json" to "{}"))!!.second.contains("npm test --if-present"))
        val py = Git.ciWorkflow(mapOf("main.py" to "print(1)", "tests/test_a.py" to "x", "requirements.txt" to "requests==2.0"))!!
        assertTrue(py.second.contains("pytest -q"))
        assertTrue(py.second.contains("pip install -r requirements.txt"))
        assertTrue(Git.ciWorkflow(mapOf("main.py" to "print(1)"))!!.second.contains("compileall"))
    }

    @Test fun unknownProjectGetsNoWorkflow() {
        assertNull(Git.ciWorkflow(mapOf("index.html" to "<html>", "style.css" to "a{}")))
    }

    @Test fun everyWorkflowIsValidLookingYaml() {
        val sample = listOf(mapOf("gradlew" to ""), mapOf("go.mod" to "x"), mapOf("Cargo.toml" to "x"), mapOf("pom.xml" to "x"), mapOf("package.json" to "{}"), mapOf("a.py" to "x"), mapOf("A.csproj" to "x"))
        for (f in sample) {
            val y = Git.ciWorkflow(f)!!.second
            assertTrue(y.startsWith("name: Anjoo CI\non:\n"))
            assertTrue(y.contains("actions/checkout@v4"))
            assertFalse(y.contains("\t"))
            assertTrue(y.endsWith("\n"))
        }
    }

    private fun run(status: String, conclusion: String) = JSONObject().put("status", status).put("conclusion", conclusion).put("name", "Anjoo CI")

    @Test fun runsAreSummarised() {
        val passed = Git.ciState(JSONArray().put(run("completed", "success")))
        assertEquals(0, passed.running); assertEquals(1, passed.passed); assertTrue(passed.failed.isEmpty())
        val failing = Git.ciState(JSONArray().put(run("completed", "failure")).put(run("completed", "success")))
        assertEquals(1, failing.failed.size); assertEquals(1, failing.passed)
        val going = Git.ciState(JSONArray().put(run("in_progress", "")).put(run("completed", "success")))
        assertEquals(1, going.running)
        assertEquals(0, Git.ciState(JSONArray()).total)
        assertEquals(1, Git.ciState(JSONArray().put(run("completed", "cancelled"))).failed.size)
    }
}
