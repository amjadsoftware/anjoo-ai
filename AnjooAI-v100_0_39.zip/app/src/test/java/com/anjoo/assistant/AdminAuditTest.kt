package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AdminAuditTest {
    private val t0 = 10_000_000L
    private fun e(at: Long, cat: String, action: String, detail: String = "") = AdminAudit.Entry(at, cat, action, detail)

    @Test fun encodeDecodeKeepsTabsNewlinesAndBackslashes() {
        val src = e(t0, "security", "Wrong\tpasscode", "line one\nline two with \\ backslash")
        val back = AdminAudit.decode(AdminAudit.encode(src))!!
        assertEquals(src.at, back.at)
        assertEquals(src.category, back.category)
        assertEquals(src.action, back.action)
        assertEquals(src.detail, back.detail)
    }

    @Test fun brokenLinesAreIgnored() {
        assertNull(AdminAudit.decode("not a log line"))
        assertNull(AdminAudit.decode("abc\tsecurity\taction\tdetail"))
    }

    @Test fun trimKeepsTheNewest() {
        val lines = (1..10).map { it.toString() }
        assertEquals(listOf("8", "9", "10"), AdminAudit.trim(lines, 3))
        assertEquals(lines, AdminAudit.trim(lines, 20))
    }

    @Test fun repeatsWithin30SecondsAreSkipped() {
        val last = e(t0, "agent", "Tool paused after repeated failures", "read_file")
        assertTrue(AdminAudit.isRepeat(last, "agent", "Tool paused after repeated failures", "read_file", t0 + 29_000))
        assertFalse(AdminAudit.isRepeat(last, "agent", "Tool paused after repeated failures", "read_file", t0 + 31_000))
        assertFalse(AdminAudit.isRepeat(last, "agent", "Tool paused after repeated failures", "open_app", t0 + 1_000))
        assertFalse(AdminAudit.isRepeat(null, "agent", "x", "y", t0))
    }

    @Test fun threeWrongPasscodesInTenMinutesIsFlagged() {
        val list = listOf(e(t0, "security", "Wrong passcode", "Attempt 1"), e(t0 + 1000, "security", "Wrong passcode", "Attempt 2"), e(t0 + 2000, "security", "Wrong passcode", "Attempt 3"))
        assertEquals(1, AdminAudit.suspicious(list, t0 + 60_000).size)
        assertTrue(AdminAudit.suspicious(list.take(2), t0 + 60_000).isEmpty())
    }

    @Test fun oldEventsDoNotCount() {
        val list = (0..4).map { e(t0 + it, "security", "Blocked: bank, wallet or card safety", "tap_text") }
        assertEquals(1, AdminAudit.suspicious(list, t0 + 60_000).size)
        assertTrue(AdminAudit.suspicious(list, t0 + 11 * 60_000).isEmpty())
    }

    @Test fun repeatedToolPausesAreFlagged() {
        val list = (0..2).map { e(t0 + it, "agent", "Tool paused after repeated failures", "tool$it") }
        assertEquals(1, AdminAudit.suspicious(list, t0 + 1000).size)
    }
}
