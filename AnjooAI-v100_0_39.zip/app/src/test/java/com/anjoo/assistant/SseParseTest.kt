package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.BufferedReader
import java.io.StringReader

class SseParseTest {
    private fun rd(s: String) = BufferedReader(StringReader(s.trimIndent()))

    @Test fun openAiTextToolCallAndUsage() {
        var last = ""
        val r = SseParse.openAi(rd("""
            data: {"choices":[{"delta":{"content":"Sal"}}]}

            data: {"choices":[{"delta":{"content":"am"}}]}

            data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"name":"weather","arguments":"{\"city\":"}}]}}]}

            data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"\"Riyadh\"}"}}]},"finish_reason":"tool_calls"}],"usage":{"prompt_tokens":5,"completion_tokens":2}}

            data: [DONE]
        """), { last = it }, null)
        assertEquals("Salam", last)
        val ch = r.getJSONArray("choices").getJSONObject(0)
        val msg = ch.getJSONObject("message")
        assertEquals("Salam", msg.getString("content"))
        val fn = msg.getJSONArray("tool_calls").getJSONObject(0).getJSONObject("function")
        assertEquals("weather", fn.getString("name"))
        assertEquals("{\"city\":\"Riyadh\"}", fn.getString("arguments"))
        assertEquals(5, r.getJSONObject("usage").getInt("prompt_tokens"))
    }

    @Test fun anthropicTextAndToolUse() {
        var last = ""
        val r = SseParse.anthropic(rd("""
            event: message_start
            data: {"type":"message_start","message":{"usage":{"input_tokens":10}}}

            event: content_block_start
            data: {"type":"content_block_start","index":0,"content_block":{"type":"text","text":""}}

            event: content_block_delta
            data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"Hello "}}

            event: content_block_delta
            data: {"type":"content_block_delta","index":0,"delta":{"type":"text_delta","text":"world"}}

            event: content_block_start
            data: {"type":"content_block_start","index":1,"content_block":{"type":"tool_use","id":"x","name":"battery"}}

            event: content_block_delta
            data: {"type":"content_block_delta","index":1,"delta":{"type":"input_json_delta","partial_json":"{\"a\":1}"}}

            event: message_delta
            data: {"type":"message_delta","delta":{"stop_reason":"tool_use"},"usage":{"output_tokens":7}}
        """), { last = it }, null)
        assertEquals("Hello world", last)
        val c = r.getJSONArray("content")
        assertEquals("Hello world", c.getJSONObject(0).getString("text"))
        assertEquals("battery", c.getJSONObject(1).getString("name"))
        assertEquals(1, c.getJSONObject(1).getJSONObject("input").getInt("a"))
        assertEquals("tool_use", r.getString("stop_reason"))
        assertEquals(7, r.getJSONObject("usage").getInt("output_tokens"))
    }

    @Test fun serverThatIgnoresStreamingStillWorks() {
        val r = SseParse.openAi(rd("""{"choices":[{"message":{"content":"plain"}}]}"""), { }, null)
        assertEquals("plain", r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content"))
    }

    @Test fun leanPathOnlyForEverydayRequests() {
        assertTrue(QuickChat.isLean("mausam kaisa hai aaj"))
        assertTrue(QuickChat.isLean("ammi ko call karo"))
        assertFalse(QuickChat.isLean("ek website bana do"))
        assertFalse(QuickChat.isLean("python mein sort kaise karte hain"))
        assertFalse(QuickChat.isLean("pdf bana do"))
    }
}
