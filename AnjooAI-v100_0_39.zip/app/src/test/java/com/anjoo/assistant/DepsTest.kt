package com.anjoo.assistant

import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DepsTest {

    @Test fun parsesPackageJson() {
        val d = Deps.parseNpm("""{"dependencies":{"react":"^18.2.0","axios":"1.6.0"},"devDependencies":{"vite":"~5.0.1"}}""")
        assertEquals(listOf("axios", "react", "vite"), d.map { it.name })
        assertTrue(d.first { it.name == "vite" }.dev)
        assertEquals("^18.2.0", d.first { it.name == "react" }.spec)
        assertTrue(Deps.parseNpm("not json").isEmpty())
    }

    @Test fun parsesRequirementsLines() {
        val d = Deps.parsePip("# comment\nrequests==2.31.0\nnumpy>=1.26,<2  # pin\n-r other.txt\nflask[async]~=3.0 ; python_version>'3.8'\ngit+https://x/y.git\nrich\n")
        assertEquals(listOf("requests", "numpy", "flask", "rich"), d.map { it.name })
        assertEquals("==2.31.0", d[0].spec)
        assertEquals(">=1.26,<2", d[1].spec)
        assertEquals("~=3.0", d[2].spec)
        assertEquals("", d[3].spec)
    }

    @Test fun baseVersionAndCompare() {
        assertEquals("18.2.0", Deps.baseVersion("^18.2.0"))
        assertEquals("2.31.0", Deps.baseVersion("==2.31.0"))
        assertEquals("1.26", Deps.baseVersion(">=1.26,<2"))
        assertNull(Deps.baseVersion("*"))
        assertNull(Deps.baseVersion("latest"))
        assertNull(Deps.baseVersion("git+https://github.com/a/b"))
        assertTrue(Deps.compareVersions("1.10.0", "1.9.9") > 0)
        assertEquals(0, Deps.compareVersions("1.0", "1.0.0"))
        assertTrue(Deps.compareVersions("2.0.0", "10.0.0") < 0)
    }

    @Test fun bumpKinds() {
        assertEquals("major", Deps.bump("17.0.2", "18.3.1"))
        assertEquals("minor", Deps.bump("18.2.0", "18.3.1"))
        assertEquals("patch", Deps.bump("18.3.0", "18.3.1"))
        assertEquals("none", Deps.bump("18.3.1", "18.3.1"))
        assertEquals("none", Deps.bump("19.0.0", "18.3.1"))
        assertEquals("major", Deps.bump("0.3.1", "0.4.0"))
    }

    @Test fun newSpecKeepsStyle() {
        assertEquals("^5.1.0", Deps.newSpec("npm", "^4.2.0", "5.1.0"))
        assertEquals("~5.1.0", Deps.newSpec("npm", "~4.2.0", "5.1.0"))
        assertEquals("5.1.0", Deps.newSpec("npm", "4.2.0", "5.1.0"))
        assertNull(Deps.newSpec("npm", "*", "5.1.0"))
        assertEquals("==2.32.3", Deps.newSpec("pip", "==2.31.0", "2.32.3"))
        assertEquals(">=2.32.3", Deps.newSpec("pip", ">=2.0", "2.32.3"))
        assertNull(Deps.newSpec("pip", ">=2.0,<3", "2.32.3"))
        assertEquals("==1.2", Deps.pipSpec("1.2"))
        assertEquals(">=1.2", Deps.pipSpec(">=1.2"))
    }

    @Test fun npmEditing() {
        val t = Deps.setNpm("""{"name":"x","dependencies":{"zod":"^3.0.0"}}""", "axios", "^1.6.0", false)!!
        val deps = JSONObject(t).getJSONObject("dependencies")
        assertEquals("^1.6.0", deps.getString("axios"))
        assertEquals("^3.0.0", deps.getString("zod"))
        val dev = JSONObject(Deps.setNpm(t, "axios", "^1.7.0", true)!!)
        assertFalse(dev.getJSONObject("dependencies").has("axios"))
        assertEquals("^1.7.0", dev.getJSONObject("devDependencies").getString("axios"))
        assertNull(Deps.setNpm("{broken", "a", "1", false))
        val r = Deps.removeNpm(t, "zod")!!
        assertTrue(r.second)
        assertFalse(JSONObject(r.first).getJSONObject("dependencies").has("zod"))
        assertFalse(Deps.removeNpm(t, "nothing")!!.second)
    }

    @Test fun pipEditing() {
        val base = "# libs\nRequests==2.0.0\nflask>=3\n"
        val replaced = Deps.setPip(base, "requests", "==2.32.3")
        assertTrue(replaced.contains("requests==2.32.3"))
        assertFalse(replaced.contains("Requests==2.0.0"))
        assertTrue(replaced.contains("# libs") && replaced.contains("flask>=3"))
        assertTrue(Deps.setPip("", "rich", "==13.0").trim() == "rich==13.0")
        assertTrue(Deps.setPip(base, "rich", "==13.0").endsWith("rich==13.0\n"))
        val r = Deps.removePip(base, "REQUESTS")
        assertTrue(r.second)
        assertFalse(r.first.contains("equests"))
        assertEquals(listOf("requests==2.0.0"), Deps.pipRequirements(mapOf("requirements.txt" to "# x\nrequests==2.0.0\n-r y.txt\nrequests==2.0.0")))
        assertTrue(Deps.pipRequirements(mapOf("main.py" to "print(1)")).isEmpty())
    }

    @Test fun validatesNames() {
        assertTrue(Deps.validName("npm", "chart.js"))
        assertTrue(Deps.validName("npm", "@types/node"))
        assertFalse(Deps.validName("npm", "Bad Name"))
        assertFalse(Deps.validName("npm", "../x"))
        assertTrue(Deps.validName("pip", "scikit-learn"))
        assertFalse(Deps.validName("pip", "a b"))
        assertEquals("python-dateutil", Deps.pipKey("Python_Dateutil"))
    }

    @Test fun findsFixedVersion() {
        val v = JSONObject("""{"affected":[{"package":{"name":"lodash","ecosystem":"npm"},"ranges":[{"type":"SEMVER","events":[{"introduced":"0"},{"fixed":"4.17.12"}]},{"type":"SEMVER","events":[{"introduced":"5.0.0"},{"fixed":"5.1.0"}]}]},{"package":{"name":"other","ecosystem":"npm"},"ranges":[{"events":[{"fixed":"9.9.9"}]}]}],"database_specific":{"severity":"HIGH"}}""")
        assertEquals("4.17.12", Deps.fixedVersion(v, "npm", "lodash", "4.17.5"))
        assertEquals("5.1.0", Deps.fixedVersion(v, "npm", "lodash", "4.17.20"))
        assertNull(Deps.fixedVersion(v, "pip", "lodash", "1.0"))
        assertEquals("high", Deps.severityOf(v))
        assertEquals("unknown", Deps.severityOf(JSONObject("{}")))
    }

    @Test fun findsUndeclaredImports() {
        val files = mapOf(
            "app.js" to "import React from 'react';\nconst fs = require('fs');\nconst x = require('./local');\nimport z from '@scope/pkg/sub';\nimport y from 'https://cdn/x.js';",
            "main.py" to "import os\nimport requests\nfrom PIL import Image\nimport helpers\nimport yaml\n",
            "helpers.py" to "import json\n"
        )
        val declared = listOf(Deps.Dep("npm", "react", "^18", false, "package.json"), Deps.Dep("pip", "pyyaml", "==6", false, "requirements.txt"))
        val out = Deps.undeclared(files, declared)
        assertEquals(listOf("npm: @scope/pkg", "pip: pillow  (import PIL)", "pip: requests"), out)
    }
}
