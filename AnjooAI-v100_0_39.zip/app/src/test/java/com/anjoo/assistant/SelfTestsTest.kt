package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Kotlin / Java / Go self-test programs: which files, what gets compiled together, how the report is read. */
class SelfTestsTest {
    @Test fun selfTestFilesAreRecognised() {
        assertTrue(SelfTests.isSelfTest("tests/SelfTest.kt"))
        assertTrue(SelfTests.isSelfTest("tests/SelfTest.java"))
        assertTrue(SelfTests.isSelfTest("tests/selftest.go"))
        assertFalse(SelfTests.isSelfTest("src/Main.kt"))
        assertEquals("tests/SelfTest.kt", SelfTests.fileFor("kotlin", listOf("tests/selftest.go", "tests/SelfTest.kt")))
    }

    @Test fun onlyNonEntryFilesWithFunctionsAreTestable() {
        val files = mapOf(
            "main.go" to "package main\nfunc main() {}\n",
            "util.go" to "package main\nfunc Add(a, b int) int { return a + b }\n",
            "data.go" to "package main\nvar X = 1\n",
            "README.md" to "func nothing"
        )
        assertEquals(listOf("util.go"), SelfTests.modules(files, "main.go", "go").keys.toList())
    }

    @Test fun runSetLeavesOutTheEntryAndMovesTheTestNextToTheModules() {
        val files = mapOf(
            "src/Main.kt" to "fun main() {}",
            "src/Util.kt" to "fun add(a: Int, b: Int) = a + b",
            "tests/SelfTest.kt" to "fun main() {}"
        )
        val (entry, set) = SelfTests.runSet(files, "src/Main.kt", "kotlin", "tests/SelfTest.kt")
        assertEquals("src/SelfTest.kt", entry)
        assertEquals(setOf("src/Util.kt", "src/SelfTest.kt"), set.keys)
    }

    @Test fun reportIsReadHonestly() {
        val pass = SelfTests.outcome("go", "RUN go: Accepted\n\nOUTPUT:\nPASS a\nSELFTEST passed=3 failed=0\n\nResult: the program ran and finished.")
        assertTrue(pass.ok); assertEquals(3, pass.tests)
        val fail = SelfTests.outcome("go", "RUN go: Runtime Error (NZEC)\n\nOUTPUT:\nFAIL add: expected 4 got 3\nSELFTEST passed=1 failed=1\n\nResult: the program crashed at runtime.")
        assertTrue(fail.bad); assertEquals(1, fail.failures)
        assertTrue(PyTests.failureText(fail).contains("expected 4 got 3"))
        val compile = SelfTests.outcome("kotlin", "RUN kotlin: Compilation Error\n\nCOMPILER OUTPUT:\nSelfTest.kt:5:3: error: unresolved reference: addd\n\nResult: it did not compile.")
        assertTrue(compile.bad)
        assertTrue(compile.text.contains("addd"))
    }

    @Test fun noRunnerMeansNoResult() {
        assertFalse(SelfTests.outcome("java", "The user declined to run the code online.").ran)
        assertFalse(SelfTests.outcome("java", "Could not reach the online runner (x).").ran)
    }

    @Test fun promptNamesTheRightFileAndSummaryLine() {
        assertTrue(SelfTests.systemPrompt("java").contains("tests/SelfTest.java"))
        assertTrue(SelfTests.systemPrompt("go").contains("os.Exit(1)"))
        assertTrue(SelfTests.systemPrompt("kotlin").contains("SELFTEST passed=<N> failed=<M>"))
    }
}
