package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SealedKeysTest {
    @Test fun roundTrip() {
        val blob = SealedKeys.seal("groq=abc\ngemini=xyz\n", ByteArray(16) { it.toByte() })
        assertEquals("groq=abc\ngemini=xyz\n", SealedKeys.open(blob))
    }
    @Test fun tamperedOrForeignFileIsRejected() {
        val blob = SealedKeys.seal("groq=abc", ByteArray(16))
        blob[22] = (blob[22].toInt() xor 1).toByte()
        assertNull(SealedKeys.open(blob))
        assertNull(SealedKeys.open("not a sealed file at all, just text.......................".toByteArray()))
    }
}
