package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LinterTest {

    @Test fun kindsOfFiles() {
        assertEquals("js", Linter.kind("src/app.js"))
        assertEquals("js", Linter.kind("a.mjs"))
        assertEquals("ts", Linter.kind("a.tsx"))
        assertEquals("py", Linter.kind("main.py"))
        assertEquals("css", Linter.kind("style.scss"))
        assertNull(Linter.kind("vendor/chart-4.js"))
        assertNull(Linter.kind("node_modules/x/index.js"))
        assertNull(Linter.kind("lib.min.js"))
        assertNull(Linter.kind("notes.txt"))
    }

    @Test fun eligibleFilesPerMode() {
        val files = mapOf("a.js" to "let x = 1", "b.py" to "x = 1", "c.css" to "a{}", "big.js" to "x".repeat(400_000), "empty.js" to " ", "package-lock.json" to "{}", "d.json" to "{}")
        assertEquals(listOf("a.js", "b.py"), Linter.eligible(files, "lint").keys.toList())
        assertEquals(listOf("a.js", "b.py", "c.css", "d.json"), Linter.eligible(files, "format").keys.toList())
        assertEquals(listOf("b.py"), Linter.eligible(files, "format", "b.py").keys.toList())
    }

    @Test fun readsPrettierRc() {
        assertEquals("{}", Linter.prettierOptions(mapOf("a.js" to "x")))
        assertEquals("{}", Linter.prettierOptions(mapOf(".prettierrc" to "not json")))
        assertTrue(Linter.prettierOptions(mapOf(".prettierrc" to "{\"semi\": false}")).contains("\"semi\":false"))
    }

    @Test fun parsesEngineResult() {
        val r = Linter.parseResult("""{"lint":[{"path":"a.js","line":3,"col":5,"rule":"no-undef","sev":"warn","msg":"'x' is not defined."},{"path":"a.js","line":1,"col":1,"rule":"","sev":"error","msg":"Parsing error"}],"format":{"b.py":"x = 1\n"},"errors":["c.css: bad"]}""")
        assertTrue(r.ok)
        assertEquals(2, r.issues.size)
        assertEquals(3, r.issues[0].line)
        assertEquals("x = 1\n", r.formatted["b.py"])
        assertEquals(listOf("c.css: bad"), r.errors)
        assertFalse(Linter.parseResult("nonsense").ok)
    }

    @Test fun reportPutsErrorsFirstAndCaps() {
        val issues = listOf(Linter.Issue("a.js", 9, 1, "no-unused-vars", "warn", "'y' is defined but never used."),
            Linter.Issue("a.js", 20, 2, "", "error", "Parsing error: Unexpected token"))
        val t = Linter.report(issues)
        assertTrue(t.startsWith("1 error(s), 1 warning(s)"))
        assertTrue(t.indexOf("a.js:20:2") < t.indexOf("a.js:9:1"))
        val many = (1..30).map { Linter.Issue("b.js", it, 1, "r", "warn", "m") }
        assertTrue(Linter.report(many, 5).contains("and 25 more"))
        assertEquals("", Linter.report(emptyList()))
    }
}
