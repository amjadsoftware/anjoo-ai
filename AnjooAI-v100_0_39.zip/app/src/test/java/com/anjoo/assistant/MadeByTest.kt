package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MadeByTest {
    private val by = "🤖 Made by: Google Gemini · gemini-3.6-flash + Mistral · mistral-code-latest +2  ·  phone actions  ·  121 more models ready"
    @Test fun shortShowsOnlyCompanies() { assertEquals("🤖 Made by: Google Gemini + Mistral +2", MadeBy.short(by)) }
    @Test fun detailsListModels() {
        val d = MadeBy.details(by)
        assertTrue(d.contains("gemini-3.6-flash")); assertTrue(d.contains("mistral-code-latest"))
        assertTrue(d.contains("phone actions")); assertTrue(d.contains("121 more models ready"))
    }
    @Test fun singleModel() { assertEquals("🤖 Made by: Groq", MadeBy.short("🤖 Made by: Groq · llama-3.3  ·  chat")) }
    @Test fun emptyStaysEmpty() { assertEquals("", MadeBy.short("")) }
}
