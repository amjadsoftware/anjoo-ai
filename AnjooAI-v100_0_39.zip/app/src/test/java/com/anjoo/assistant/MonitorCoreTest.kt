package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MonitorCoreTest {
    private val gb = 1024L * 1024 * 1024
    private fun alerts(batt: Int = 80, charging: Boolean = false, free: Long = 50 * gb, total: Long = 100 * gb, lowMem: Boolean = false, online: Boolean = true, heapUsed: Long = 10, heapMax: Long = 100) =
        MonitorCore.alerts(batt, charging, free, total, lowMem, online, heapUsed, heapMax).map { it.action }

    @Test fun healthyPhoneHasNoAlerts() = assertTrue(alerts().isEmpty())

    @Test fun batteryAlertOnlyWhenNotCharging() {
        assertEquals(listOf("Battery low"), alerts(batt = 10))
        assertTrue(alerts(batt = 10, charging = true).isEmpty())
        assertTrue(alerts(batt = -1).isEmpty())
    }

    @Test fun storageAlertByPercentOrAbsoluteSize() {
        assertEquals(listOf("Storage low"), alerts(free = 5 * gb))
        assertEquals(listOf("Storage low"), alerts(free = 300L * 1024 * 1024, total = 1000 * gb))
        assertTrue(alerts(free = -1, total = -1).isEmpty())
    }

    @Test fun memoryAndNetworkAlerts() {
        assertEquals(listOf("Device memory low"), alerts(lowMem = true))
        assertEquals(listOf("No network"), alerts(online = false))
        assertEquals(listOf("App memory high"), alerts(heapUsed = 90))
    }

    @Test fun formatting() {
        assertEquals("n/a", MonitorCore.bytes(-1))
        assertEquals("512 B", MonitorCore.bytes(512))
        assertEquals("2.0 MB", MonitorCore.bytes(2L * 1024 * 1024))
        assertEquals("1d 2h", MonitorCore.duration(26 * 3600_000L))
        assertEquals("5m", MonitorCore.duration(5 * 60_000L))
        assertEquals(25, MonitorCore.failPct(3, 1))
        assertEquals(0, MonitorCore.failPct(0, 0))
        assertEquals(100, MonitorCore.pct(500, 100))
    }
}
