package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class RunTestsTest {
    private val files = linkedMapOf(
        "src/math.js" to "function add(a, b) { return a + b; }\nmodule.exports = { add };\n",
        "src/greet.mjs" to "import { add } from './math.js';\nexport function greet(n) { return 'Hi ' + n + add(0, 0); }\n",
        "src/unused.js" to "module.exports = 1;\n",
        "data/cfg.json" to "{\"a\":1}",
        "tests/math.test.js" to "const { add } = require('../src/math');\nit('adds', () => expect(add(1, 2)).toBe(3));\n",
        "tests/greet.spec.mjs" to "import { greet } from '../src/greet.mjs';\nconst cfg = require('../data/cfg');\nit('g', () => {});\n"
    )

    @Test fun findsJsTestFiles() {
        assertTrue(RunTests.isJsTest("tests/math.test.js")); assertTrue(RunTests.isJsTest("a/b.spec.mjs"))
        assertTrue(RunTests.isJsTest("test/helper.js")); assertTrue(RunTests.isJsTest("src/__tests__/x.js")); assertTrue(RunTests.isJsTest("test.js"))
        assertFalse(RunTests.isJsTest("src/math.js")); assertFalse(RunTests.isJsTest("node_modules/x/test/a.js")); assertFalse(RunTests.isJsTest("tests/readme.md"))
        assertEquals(listOf("tests/greet.spec.mjs", "tests/math.test.js"), RunTests.jsTestFiles(files.keys))
    }

    @Test fun readsRelativeImportsOnly() {
        val s = "const a = require('./a');\nimport b from \"../b\";\nimport './c';\nimport {x} from 'lodash';\nconst fs = require('fs');"
        assertEquals(listOf("./a", "../b", "./c"), RunTests.specs(s))
    }

    @Test fun normalizesAndResolvesPaths() {
        assertEquals("a/c/d", RunTests.normalize("a/b/../c/./d")); assertNull(RunTests.normalize("../x"))
        val known = files.keys
        assertEquals("src/math.js", RunTests.resolve("tests/math.test.js", "../src/math", known))
        assertEquals("src/math.js", RunTests.resolve("src/greet.mjs", "./math.js", known))
        assertEquals("data/cfg.json", RunTests.resolve("tests/greet.spec.mjs", "../data/cfg", known))
        assertNull(RunTests.resolve("tests/math.test.js", "../src/missing", known))
        assertEquals("src/math.js", RunTests.resolve("top.js", "./src/math", known))
    }

    @Test fun packsOnlyWhatTestsImport() {
        val tests = RunTests.jsTestFiles(files.keys)
        val r = RunTests.reachable(files, tests)
        assertTrue("src/math.js" in r); assertTrue("src/greet.mjs" in r); assertTrue("data/cfg.json" in r); assertFalse("src/unused.js" in r)
        assertEquals(listOf("src/unused.js"), RunTests.untested(files, tests))
    }

    @Test fun bundleHasHarnessFilesAndRunCall() {
        val b = RunTests.bundle("/*HARNESS*/", files, RunTests.jsTestFiles(files.keys), true)
        assertTrue(b.startsWith("/*HARNESS*/"))
        assertTrue(Regex("__anjooReg\\(\"src\\\\?/math\\.js\", \"function add").containsMatchIn(b))
        assertTrue(Regex("__anjooReg\\(\"tests\\\\?/math\\.test\\.js\", .*, true\\);").containsMatchIn(b))
        assertTrue(Regex("__anjooReg\\(\"src\\\\?/math\\.js\", .*, false\\);").containsMatchIn(b))
        assertFalse(b.contains("src/unused.js"))
        assertTrue(b.trimEnd().endsWith("], true);"))
        assertTrue(RunTests.bundle("", files, listOf("tests/math.test.js"), false).trimEnd().endsWith(", false);"))
    }

    @Test fun passReportTellsToProveWithResultLine() {
        val t = RunTests.summarize("RESULT: PASS ran=3 passed=3 failed=0 skipped=0 errors=0\nsrc/a.js  80% (4/5) not run: 3", listOf("src/unused.js"))
        assertTrue(t.contains("All 3 tests passed")); assertTrue(t.contains("not run")); assertTrue(t.contains("src/unused.js"))
    }

    @Test fun failReportStartsTheFixLoop() {
        val t = RunTests.summarize("RESULT: FAIL ran=4 passed=3 failed=1 skipped=0 errors=0\nFAILED TESTS:\n  FAIL tests/a.test.js > x", emptyList())
        assertTrue(t.contains("FIX LOOP")); assertTrue(t.contains("1 test(s) failed")); assertTrue(t.contains("project_check action=test again"))
    }

    @Test fun noResultLineMeansTestsDidNotRun() {
        assertTrue(RunTests.summarize("RUN javascript: Time Limit Exceeded", emptyList()).contains("endless loop"))
        assertTrue(RunTests.summarize("The user declined to run the code online.", emptyList()).contains("NOT run"))
        assertTrue(RunTests.summarize("The online runner is busy. The code was not run, so do not claim it passed.", emptyList()).contains("NOT run"))
        assertTrue(RunTests.summarize("RUN javascript: Runtime Error\nSyntaxError", emptyList()).contains("did not run properly"))
        assertTrue(RunTests.summarize("RESULT: NONE ran=0 passed=0 failed=0 skipped=0 errors=0", emptyList()).contains("no describe/it tests"))
    }

    @Test fun missingTestsMessagesSayWhatToDo() {
        assertTrue(RunTests.noTests(listOf("a.test.ts")).contains("TypeScript"))
        assertTrue(RunTests.noTests(listOf("src/test/kotlin/AppTest.kt")).contains("JUnit"))
        assertTrue(RunTests.noTests(listOf("main.go", "util_test.go")).contains("main()"))
        assertTrue(RunTests.noTests(listOf("index.js")).contains("tests/name.test.js"))
    }

    @Test fun harnessFileIsPresentAndOldNodeSafe() {
        val f = File("src/main/assets/js_test_harness.js")
        assertTrue("harness missing at " + f.absolutePath, f.exists())
        val s = f.readText()
        assertTrue(s.contains("function __anjooReg(")); assertTrue(s.contains("function __anjooRun(") || s.contains("async function __anjooRun("))
        assertTrue(s.contains("RESULT: "))
        val code = s.lines().filter { !it.trim().startsWith("*") && !it.trim().startsWith("/*") && !it.trim().startsWith("//") }.joinToString("\n")
        assertFalse("optional chaining breaks Node 12", Regex("\\w\\?\\.\\w").containsMatchIn(code))
        assertFalse("?? breaks Node 12", code.contains(" ?? "))
        assertFalse(code.contains("replaceAll("))
    }
}
