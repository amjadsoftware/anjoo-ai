package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SqlRunTest {
    private fun texts(s: String) = SqlRun.split(s).map { it.sql }

    @Test fun splitsStatementsAndKeepsLineNumbers() {
        val r = SqlRun.split("CREATE TABLE a(x); INSERT INTO a VALUES (1);\nSELECT * FROM a;")
        assertEquals(listOf("CREATE TABLE a(x)", "INSERT INTO a VALUES (1)", "SELECT * FROM a"), r.map { it.sql })
        assertEquals(listOf(1, 1, 2), r.map { it.line })
    }

    @Test fun semicolonsInStringsAndCommentsDoNotSplit() {
        val r = texts("INSERT INTO t VALUES ('a;b', \"c;d\"); -- ; comment\nSELECT 1 /* ; */;")
        assertEquals(2, r.size)
        assertTrue(r[0].contains("'a;b'") && r[0].contains("\"c;d\""))
        assertEquals("SELECT 1", r[1])
    }

    @Test fun doubledQuoteInsideStringIsKept() {
        val r = texts("INSERT INTO t VALUES ('it''s; ok'); SELECT 2;")
        assertEquals(2, r.size)
        assertTrue(r[0].contains("it''s; ok"))
    }

    @Test fun triggerBodyIsOneStatement() {
        val r = texts("CREATE TRIGGER trg AFTER INSERT ON t BEGIN UPDATE t SET n = n + 1; INSERT INTO log VALUES (CASE WHEN 1 THEN 2 END); END; SELECT 1;")
        assertEquals(2, r.size)
        assertTrue(r[0].startsWith("CREATE TRIGGER") && r[0].endsWith("END"))
        assertEquals("SELECT 1", r[1])
    }

    @Test fun beginTransactionIsNotATrigger() {
        assertEquals(listOf("BEGIN", "INSERT INTO t VALUES (1)", "COMMIT"), texts("BEGIN; INSERT INTO t VALUES (1); COMMIT;"))
    }

    @Test fun emptyAndCommentOnlyScriptsGiveNothing() {
        assertTrue(SqlRun.split("").isEmpty())
        assertTrue(SqlRun.split("-- only a comment\n/* and another */").isEmpty())
    }

    @Test fun detectsStatementsThatReturnRows() {
        assertTrue(SqlRun.isQuery("select 1"))
        assertTrue(SqlRun.isQuery("  WITH x AS (SELECT 1) SELECT * FROM x"))
        assertTrue(SqlRun.isQuery("PRAGMA table_info(t)"))
        assertTrue(SqlRun.isQuery("INSERT INTO t VALUES (1) RETURNING id"))
        assertFalse(SqlRun.isQuery("INSERT INTO t VALUES (1)"))
        assertFalse(SqlRun.isQuery("CREATE TABLE t(returning_x INT)"))
    }

    @Test fun transactionControlIsRecognised() {
        assertTrue(SqlRun.controlsTransaction("BEGIN"))
        assertTrue(SqlRun.controlsTransaction("pragma journal_mode=wal"))
        assertFalse(SqlRun.controlsTransaction("SELECT 1"))
    }

    @Test fun dotCommandsBecomeSql() {
        assertTrue(SqlRun.dotToSql(".tables")!!.contains("sqlite_master"))
        assertTrue(SqlRun.dotToSql(".schema users")!!.contains("tbl_name = 'users'"))
        assertTrue(SqlRun.dotToSql(".schema o'brien")!!.contains("o''brien"))
        assertNull(SqlRun.dotToSql("SELECT 1"))
        assertNull(SqlRun.dotToSql(".tables\nSELECT 1"))
    }

    @Test fun tableTextIsCompact() {
        val t = SqlRun.formatTable(listOf("id", "name"), listOf(listOf("1", "Ali"), listOf("2", "a\nb")), 5)
        assertEquals("id | name\n1 | Ali\n2 | a\\nb\n... 3 more rows not shown", t)
        val long = SqlRun.formatTable(listOf("x"), listOf(listOf("y".repeat(100))), 1)
        assertTrue(long.lines()[1].length <= 60)
    }

    @Test fun databaseFileMustStayInsideTheProject() {
        val dir = File(System.getProperty("java.io.tmpdir"), "sqlrun-test-" + System.nanoTime()).apply { mkdirs() }
        try {
            assertNotNull(SqlRun.resolveDb(dir, "data.db"))
            assertNotNull(SqlRun.resolveDb(dir, "db/app.sqlite3"))
            assertNull(SqlRun.resolveDb(dir, "../x.db"))
            assertNull(SqlRun.resolveDb(dir, "a/../../x.db"))
            assertNull(SqlRun.resolveDb(dir, "notes.txt"))
            assertNull(SqlRun.resolveDb(dir, ""))
        } finally { dir.deleteRecursively() }
    }

    @Test fun sqlProjectsPickTheQueryFile() {
        assertEquals("query.sql", RunCode.sqlEntry(listOf("schema.sql", "query.sql", "seed.sql")))
        assertEquals("report.sql", RunCode.sqlEntry(listOf("schema.sql", "report.sql", "seed.sql")))
        assertEquals("schema.sql", RunCode.sqlEntry(listOf("schema.sql")))
        assertNull(RunCode.sqlEntry(listOf("main.py")))
    }
}
