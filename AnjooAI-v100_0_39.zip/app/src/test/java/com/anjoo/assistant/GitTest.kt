package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class GitTest {

    @Test fun blobIdsMatchRealGit() {
        // values printed by `git hash-object`
        assertEquals("ce013625030ba8dba906f756967f9e9ca394464a", Git.blobSha("hello\n".toByteArray()))
        assertEquals("e69de29bb2d1d6434b8b29ae775ad8c2e48c5391", Git.blobSha(ByteArray(0)))
    }

    @Test fun parsesRepositoryNames() {
        assertEquals(Pair("foo", "bar"), Git.parseRepo("foo/bar"))
        assertEquals(Pair("foo", "bar"), Git.parseRepo("https://github.com/foo/bar.git"))
        assertEquals(Pair("foo", "bar"), Git.parseRepo("git@github.com:foo/bar.git"))
        assertEquals(Pair("foo", "bar"), Git.parseRepo("https://github.com/foo/bar/tree/main"))
        assertNull(Git.parseRepo("bar"))
        assertNull(Git.parseRepo("foo/ba r"))
    }

    @Test fun statusFindsAddedModifiedDeleted() {
        val s = Git.status(mapOf("a" to "1", "b" to "1", "c" to "1"), mapOf("a" to "1", "b" to "2", "d" to "9"))
        assertEquals(listOf("d"), s.added)
        assertEquals(listOf("b"), s.modified)
        assertEquals(listOf("c"), s.deleted)
        assertFalse(s.clean)
        assertTrue(Git.status(mapOf("a" to "1"), mapOf("a" to "1")).clean)
    }

    @Test fun pullKeepsLocalEditsTakesRemoteEditsAndFlagsConflicts() {
        val base = mapOf("a" to "1", "b" to "1", "c" to "1")
        val local = mapOf("a" to "2", "b" to "1", "c" to "1", "d" to "9")
        val remote = mapOf("a" to "3", "b" to "2", "e" to "5")
        val p = Git.planPull(base, local, remote)
        assertEquals(listOf("b", "e"), p.take)
        assertEquals(listOf("c"), p.remove)
        assertEquals(listOf("a"), p.conflicts)
    }

    @Test fun samePullChangeOnBothSidesIsNotAConflict() {
        val p = Git.planPull(mapOf("a" to "1"), mapOf("a" to "2"), mapOf("a" to "2"))
        assertTrue(p.take.isEmpty() && p.remove.isEmpty() && p.conflicts.isEmpty())
    }

    @Test fun gitignoreRules() {
        val ig = Git.Ignore(listOf("# comment", "node_modules/", "*.log", "/secret.txt", "build/**/out", "!keep.log"))
        assertTrue(ig.matches("node_modules/x/y.js"))
        assertTrue(ig.matches("app/node_modules/x.js"))
        assertTrue(ig.matches("a/b.log"))
        assertTrue(ig.matches("secret.txt"))
        assertFalse(ig.matches("x/secret.txt"))
        assertTrue(ig.matches("build/out"))
        assertTrue(ig.matches("build/a/b/out"))
        assertFalse(ig.matches("src/main.kt"))
    }

    @Test fun conflictMarkersRoundTrip() {
        val t = Git.conflictText("mine\n", "theirs\n")
        assertTrue(t.startsWith(Git.MARK_LOCAL))
        assertTrue(Git.hasConflictMarkers(t))
        assertFalse(Git.hasConflictMarkers("plain text\n"))
    }

    @Test fun secretsAreFoundWithoutRevealingThem() {
        assertTrue(Git.secretHits(".env", "A=1").isNotEmpty())
        assertTrue(Git.secretHits("app/signing.properties", null).isNotEmpty())
        assertTrue(Git.secretHits(".env.example", "A=1").isEmpty())
        assertTrue(Git.secretHits("keys.properties.example", "k=v").isEmpty())
        val aws = Git.secretHits("src/a.kt", "val k = \"AKIAABCDEFGHIJKLMNOP\"")
        assertEquals(listOf("AWS access key"), aws)
        val gh = Git.secretHits("notes.txt", "token ghp_" + "a".repeat(36))
        assertEquals(listOf("GitHub token"), gh)
        assertTrue(Git.secretHits("src/Main.kt", "fun main() { println(\"hi\") }").isEmpty())
    }

    @Test fun unifiedDiffShowsTheChange() {
        val d = Git.unifiedDiff("f.txt", "a\nb\nc\n", "a\nB\nc\n")
        assertTrue(d.startsWith("--- a/f.txt\n+++ b/f.txt\n"))
        assertTrue(d.contains("@@ -1,4 +1,4 @@"))
        assertTrue(d.contains("\n-b\n"))
        assertTrue(d.contains("\n+B\n"))
        assertEquals("", Git.unifiedDiff("f.txt", "same\n", "same\n"))
    }

    @Test fun unifiedDiffHandlesNewAndEmptyFiles() {
        val added = Git.unifiedDiff("n.txt", "", "x\ny\n")
        assertTrue(added.contains("+x") && added.contains("+y"))
        val removed = Git.unifiedDiff("n.txt", "x\ny\n", "")
        assertTrue(removed.contains("-x") && removed.contains("-y"))
    }

    @Test fun scanRespectsGitignoreButKeepsTrackedFiles() {
        val dir = java.nio.file.Files.createTempDirectory("gittest").toFile()
        try {
            File(dir, "a.txt").writeText("a")
            File(dir, ".gitignore").writeText("*.log\n")
            File(dir, "b.log").writeText("b")
            File(dir, "node_modules").mkdirs(); File(dir, "node_modules/x.js").writeText("x")
            File(dir, ".anjoo-git.json").writeText("{}")
            File(dir, "sub").mkdirs(); File(dir, "sub/c.txt").writeText("c")
            assertEquals(setOf(".gitignore", "a.txt", "sub/c.txt"), Git.scan(dir, emptyMap()).keys)
            val withTracked = Git.scan(dir, mapOf("b.log" to "old"))
            assertEquals(setOf(".gitignore", "a.txt", "b.log", "sub/c.txt"), withTracked.keys)
            assertEquals(Git.blobSha("a".toByteArray()), withTracked["a.txt"])
        } finally { dir.deleteRecursively() }
    }
}
