package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Test

class FontPrefTest {
    @Test fun labelsMatchFamilies() { assertEquals(FontPref.labels.size, 4) }
    @Test fun defaultIsSans() { assertEquals("sans-serif", FontPref.family(FontPref.DEFAULT_IDX)) }
    @Test fun outOfRangeIsClamped() { assertEquals("monospace", FontPref.family(99)) }
}
