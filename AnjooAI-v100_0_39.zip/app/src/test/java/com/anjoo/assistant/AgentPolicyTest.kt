package com.anjoo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentPolicyTest {
    private val t0 = 1_000_000L

    @Test fun toolIsNotBlockedBeforeTheCap() {
        val f = AgentPolicy.FailureTracker(cap = 4, windowMs = 300_000)
        repeat(3) { f.record("read_file", true, t0 + it) }
        assertNull(f.blockedMessage("read_file", t0 + 10))
    }

    @Test fun toolIsBlockedAfterTheCapAndOtherToolsAreNot() {
        val f = AgentPolicy.FailureTracker(cap = 4, windowMs = 300_000)
        repeat(4) { f.record("read_file", true, t0 + it) }
        val msg = f.blockedMessage("read_file", t0 + 10)
        assertNotNull(msg)
        assertTrue(msg!!.startsWith("STOP:"))
        assertNull(f.blockedMessage("open_app", t0 + 10))
    }

    @Test fun aSuccessClearsTheCount() {
        val f = AgentPolicy.FailureTracker(cap = 4, windowMs = 300_000)
        repeat(3) { f.record("read_file", true, t0 + it) }
        f.record("read_file", false, t0 + 5)
        f.record("read_file", true, t0 + 6)
        assertNull(f.blockedMessage("read_file", t0 + 7))
    }

    @Test fun blockEndsAfterTheWindowAndCountingRestarts() {
        val f = AgentPolicy.FailureTracker(cap = 4, windowMs = 300_000)
        repeat(4) { f.record("read_file", true, t0) }
        assertNotNull(f.blockedMessage("read_file", t0 + 299_000))
        assertNull(f.blockedMessage("read_file", t0 + 301_000))
        f.record("read_file", true, t0 + 400_000)
        assertNull(f.blockedMessage("read_file", t0 + 400_001))
    }

    @Test fun failureDetectionIsConservative() {
        assertTrue(AgentPolicy.looksFailed("anything", true))
        assertTrue(AgentPolicy.looksFailed("Error: file missing", false))
        assertTrue(AgentPolicy.looksFailed("Could not open the file", false))
        assertFalse(AgentPolicy.looksFailed("The file contains the word error in line 3", false))
        assertFalse(AgentPolicy.looksFailed("STOP: this same action has already run 3 times", false))
        assertFalse(AgentPolicy.looksFailed("Done: saved notes.txt", false))
    }
}
