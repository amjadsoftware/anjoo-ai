package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The real compile check only judges what the online sandbox can really judge. */
class CoderCompileTest {
    @Test fun androidAndBuildToolProjectsAreSkipped() {
        assertTrue(Coder.needsExternalLibs(mapOf("app/src/main/AndroidManifest.xml" to "<manifest/>")))
        assertTrue(Coder.needsExternalLibs(mapOf("build.gradle.kts" to "plugins {}")))
        assertTrue(Coder.needsExternalLibs(mapOf("pom.xml" to "<project/>")))
        assertTrue(Coder.needsExternalLibs(mapOf("go.mod" to "module x\n\nrequire github.com/a/b v1.0.0\n")))
        assertTrue(Coder.needsExternalLibs(mapOf("Cargo.toml" to "[package]\nname=\"x\"\n\n[dependencies]\nserde = \"1\"\n")))
        assertFalse(Coder.needsExternalLibs(mapOf("go.mod" to "module x\n\ngo 1.22\n", "main.go" to "package main")))
        assertFalse(Coder.needsExternalLibs(mapOf("Cargo.toml" to "[package]\nname=\"x\"\n", "main.rs" to "fn main(){}")))
    }

    @Test fun compileErrorBecomesAProblem() {
        val r = "RUN kotlin: Compilation Error · 1.2s\n\nCOMPILER OUTPUT:\nMain.kt:3:5: error: unresolved reference: foo\n\nResult: it did not compile. Fix the compiler errors above and run again."
        val p = Coder.compileVerdict("kotlin", r)
        assertTrue(p.startsWith("- kotlin compile failed"))
        assertTrue(p.contains("Main.kt:3:5"))
    }

    @Test fun cleanRunIsNotAProblem() {
        assertEquals("", Coder.compileVerdict("go", "RUN go: Accepted\n\nOUTPUT:\nhi\n\nResult: the program ran and finished."))
    }

    @Test fun missingLibraryIsNotBlamedOnTheCode() {
        val r = "RUN go: Compilation Error\n\nCOMPILER OUTPUT:\nmain.go:4:2: cannot find package \"github.com/x/y\"\n\nResult: it did not compile."
        assertEquals("", Coder.compileVerdict("go", r))
    }

    @Test fun runtimeCrashIsAProblemButWaitingForInputIsNot() {
        val crash = "RUN java: Runtime Error (NZEC)\n\nERROR OUTPUT:\nException in thread \"main\" java.lang.ArithmeticException: / by zero\n\nResult: the program crashed at runtime. Fix the error above and run again."
        assertTrue(Coder.compileVerdict("java", crash).startsWith("- java run crashed"))
        val input = "RUN java: Runtime Error (NZEC)\n\nERROR OUTPUT:\nException in thread \"main\" java.util.NoSuchElementException\n\nResult: the program crashed at runtime."
        assertEquals("", Coder.compileVerdict("java", input))
    }

    @Test fun noNetworkOrDeclinedMeansNoVerdict() {
        assertEquals("", Coder.compileVerdict("rust", "The user declined to run the code online."))
        assertEquals("", Coder.compileVerdict("rust", "Could not reach the online runner (timeout)."))
    }
}
