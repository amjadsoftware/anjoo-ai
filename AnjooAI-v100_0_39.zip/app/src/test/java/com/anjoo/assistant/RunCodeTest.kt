package com.anjoo.assistant

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Base64

class RunCodeTest {
    private fun b(s: String) = Base64.getEncoder().encodeToString(s.toByteArray())
    private fun lang(id: Int, name: String) = JSONObject().put("id", id).put("name", name)

    @Test fun languageNamesAndFilesMapToKeys() {
        assertEquals("kotlin", RunCode.normLang("Kotlin")); assertEquals("cpp", RunCode.normLang("c++"))
        assertEquals("rust", RunCode.normLang("main.rs")); assertEquals("javascript", RunCode.normLang("node"))
        assertEquals("csharp", RunCode.normLang("C#")); assertEquals("python", RunCode.normLang(".py")); assertEquals("", RunCode.normLang("cobol"))
    }
    @Test fun newestServerVersionWins() {
        val l = JSONArray().put(lang(62, "Java (OpenJDK 13.0.1)")).put(lang(91, "Java (JDK 17.0.6)")).put(lang(71, "Python (3.8.1)")).put(lang(70, "Python (2.7.17)"))
        assertEquals(91, RunCode.pickId(l, "java")); assertEquals(71, RunCode.pickId(l, "python"))
    }
    @Test fun fallsBackToBuiltInIds() { assertEquals(78, RunCode.pickId(null, "kotlin")); assertEquals(-1, RunCode.pickId(null, "cobol")) }
    @Test fun formatsCompileError() {
        val r = JSONObject().put("status", JSONObject().put("id", 6).put("description", "Compilation Error")).put("compile_output", b("main.kt:1:1: error: boom"))
        val t = RunCode.format("kotlin", r)
        assertTrue(t.contains("Compilation Error")); assertTrue(t.contains("error: boom")); assertTrue(t.contains("did not compile"))
    }
    @Test fun formatsOutput() {
        val r = JSONObject().put("status", JSONObject().put("id", 3).put("description", "Accepted")).put("stdout", b("hello\n")).put("time", "0.01")
        val t = RunCode.format("go", r)
        assertTrue(t.contains("OUTPUT:\nhello")); assertTrue(t.contains("0.01s"))
    }
    @Test fun findsEntryFile() {
        assertEquals("src/main.rs", RunCode.entryOf(listOf("Cargo.toml", "src/main.rs")))
        assertEquals("Main.java", RunCode.entryOf(listOf("Main.java", "Util.java")))
        assertEquals(null, RunCode.entryOf(listOf("notes.txt")))
    }

    private fun wb(lang: String, name: String) = JSONObject().put("language", lang).put("name", name)

    @Test fun wandboxPicksNewestStableGcc() {
        val l = JSONArray().put(wb("C++", "gcc-head")).put(wb("C++", "clang-18.1.0")).put(wb("C++", "gcc-9.5.0")).put(wb("C++", "gcc-13.2.0")).put(wb("C++", "gcc-10.5.0"))
        assertEquals("gcc-13.2.0", RunCode.pickWandbox(l, "cpp"))
    }
    @Test fun wandboxPrefersCpythonAndKnowsMissingLanguages() {
        val l = JSONArray().put(wb("Python", "pypy-7.3.17-v3.10")).put(wb("Python", "cpython-3.12.7")).put(wb("Python", "cpython-3.9.20"))
        assertEquals("cpython-3.12.7", RunCode.pickWandbox(l, "python"))
        assertEquals(null, RunCode.pickWandbox(l, "kotlin"))
        assertEquals(null, RunCode.pickWandbox(null, "python"))
    }
    @Test fun wandboxJavaVersionsCompareNumerically() {
        val l = JSONArray().put(wb("Java", "openjdk-jdk-9+181")).put(wb("Java", "openjdk-jdk-22+36")).put(wb("Java", "openjdk-jdk-17+35"))
        assertEquals("openjdk-jdk-22+36", RunCode.pickWandbox(l, "java"))
    }
    @Test fun wandboxFormats() {
        val ok = RunCode.formatWandbox("go", JSONObject().put("status", "0").put("program_output", "hi\n"))
        assertTrue(ok.contains("OUTPUT:\nhi")); assertTrue(ok.contains("ran and finished"))
        val bad = RunCode.formatWandbox("c", JSONObject().put("status", "1").put("compiler_error", "prog.c:1: error"))
        assertTrue(bad.contains("Compilation Error")); assertTrue(bad.contains("did not compile"))
    }

    @Test fun multiFilePlansCompileEveryFileOfTheLanguage() {
        val kt = mapOf("Main.kt" to "fun main() {}", "Util.kt" to "fun u() {}", "notes.txt" to "x")
        val k = RunCode.plan("kotlin", "Main.kt", kt)!!
        assertTrue(k.compile!!.contains("'Main.kt'") && k.compile!!.contains("'Util.kt'") && !k.compile!!.contains("notes.txt"))
        assertEquals("java -cp app.jar MainKt", k.run)
        val j = RunCode.plan("java", "src/app/Main.java", mapOf("src/app/Main.java" to "package app;\nclass Main {}", "src/app/U.java" to "package app;"))!!
        assertEquals("java -cp out app.Main", j.run)
        val g = RunCode.plan("go", "cmd/main.go", mapOf("cmd/main.go" to "package main"))!!
        assertTrue(g.compile!!.contains("go build -o app './cmd'"))
        val c = RunCode.plan("c", "main.c", mapOf("main.c" to "", "util.c" to "", "util.h" to ""))!!
        assertTrue(c.compile!!.contains("'main.c' 'util.c'") && !c.compile!!.contains("util.h"))
        assertEquals(null, RunCode.plan("python", "a.py", mapOf("a.py" to ""))!!.compile)
        assertEquals(null, RunCode.plan("cobol", "a.cob", emptyMap()))
    }
    @Test fun quotingSurvivesApostrophes() { assertEquals("'it'\\''s.c'", RunCode.shq("it's.c")) }
    @Test fun judgeZipHoldsProjectAndScripts() {
        val files = mapOf("main.c" to "int main(){}", "util.c" to "")
        val bytes = RunCode.judgeZip(RunCode.plan("c", "main.c", files)!!, files)
        val z = java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(bytes))
        val names = ArrayList<String>(); val text = HashMap<String, String>()
        while (true) { val e = z.nextEntry ?: break; names.add(e.name); text[e.name] = z.readBytes().toString(Charsets.UTF_8) }
        assertEquals(listOf("main.c", "util.c", "compile", "run"), names)
        assertTrue(text["compile"]!!.contains("gcc") && text["run"]!!.contains("./app"))
        val interp = RunCode.judgeZip(RunCode.plan("python", "a.py", mapOf("a.py" to ""))!!, mapOf("a.py" to ""))
        val n2 = ArrayList<String>(); val z2 = java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(interp))
        while (true) { val e = z2.nextEntry ?: break; n2.add(e.name) }
        assertEquals(listOf("a.py", "run"), n2)
    }
}
