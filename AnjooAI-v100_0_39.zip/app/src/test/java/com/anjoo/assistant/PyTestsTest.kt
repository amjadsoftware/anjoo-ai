package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Python unit tests: which files count as tests, what can be tested, and how the run result is read. */
class PyTestsTest {
    @Test fun testFilesAreRecognised() {
        assertTrue(PyTests.isTest("tests/test_calc.py"))
        assertTrue(PyTests.isTest("test_calc.py"))
        assertTrue(PyTests.isTest("calc_test.py"))
        assertTrue(PyTests.isTest("pkg/tests/helpers.py"))
        assertFalse(PyTests.isTest("calc.py"))
        assertFalse(PyTests.isTest("tests/__init__.py"))
        assertFalse(PyTests.isTest("tests/conftest.py"))
        assertFalse(PyTests.isTest("tests/test_calc.js"))
    }

    @Test fun onlyRealModulesAreTestable() {
        val files = mapOf(
            "calc.py" to "def add(a, b):\n    return a + b\n",
            "tests/test_calc.py" to "def test_x():\n    pass\n",
            "setup.py" to "def main():\n    pass\n",
            "notes.py" to "print('hi')\n"
        )
        assertEquals(listOf("calc.py"), PyTests.testable(files).keys.toList())
    }

    @Test fun runnerLoadsTestsByPathNotByDiscovery() {
        assertTrue(PyTests.RUNNER.contains("spec_from_file_location"))
        assertFalse(PyTests.RUNNER.contains("discover("))
        assertTrue(PyTests.RUNNER.contains("ANJOO_RESULT"))
        assertTrue(PyTests.RUNNER.contains(PyTests.LIST_NAME))
    }

    @Test fun passingRunIsReadAndReported() {
        val o = PyTests.parse("test_a ... ok\n\nRan 3 tests in 0.01s\n\nOK\nANJOO_RESULT ran=3 failures=0 errors=0 load_errors=0")
        assertTrue(o.ok)
        assertEquals(3, o.tests)
        assertTrue(PyTests.line(o).startsWith("✅ Tests: all 3 passed"))
        assertTrue(PyTests.line(o, 2).contains("after fixing 2 file(s)"))
    }

    @Test fun failingRunIsNeverReportedAsPassed() {
        val out = "LOAD ERROR in tests/test_b.py: ModuleNotFoundError: x\n======\nFAIL: test_w (tests.test_calc.T.test_w)\nAssertionError: 3 != 4\nANJOO_RESULT ran=4 failures=1 errors=0 load_errors=1"
        val o = PyTests.parse(out)
        assertTrue(o.bad)
        assertFalse(o.ok)
        val l = PyTests.line(o)
        assertTrue(l.startsWith("⚠ Tests: 1 failed"))
        assertTrue(l.contains("could not load"))
        assertTrue(PyTests.failureText(o).contains("AssertionError: 3 != 4"))
        assertTrue(PyTests.report(o).startsWith("TEST RESULT: FAIL"))
    }

    @Test fun aRunThatDidNotFinishIsNotAResult() {
        val o = PyTests.parse("Traceback (most recent call last): boom")
        assertFalse(o.ran)
        assertFalse(o.ok)
        assertFalse(o.bad)
        assertTrue(PyTests.line(o).contains("NOT run"))
    }

    @Test fun zeroTestsIsNotSuccess() {
        val o = PyTests.parse("Ran 0 tests\nANJOO_RESULT ran=0 failures=0 errors=0 load_errors=0")
        assertFalse(o.ok)
        assertTrue(PyTests.line(o).contains("no test was found"))
    }
}
