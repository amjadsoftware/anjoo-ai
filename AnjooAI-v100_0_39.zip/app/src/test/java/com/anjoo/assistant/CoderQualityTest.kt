package com.anjoo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Unit tests are only written for modules that export functions (a browser-only script cannot be unit tested). */
class CoderQualityTest {
    @Test fun commonJsAndEsModulesCountAsTestable() {
        assertTrue(Coder.EXPORT_RE.containsMatchIn("function add(a,b){return a+b}\nmodule.exports = { add }"))
        assertTrue(Coder.EXPORT_RE.containsMatchIn("export function add(a, b) { return a + b }"))
        assertTrue(Coder.EXPORT_RE.containsMatchIn("const x = 1\nexport default x"))
    }

    @Test fun plainBrowserScriptIsNotTestable() {
        assertFalse(Coder.EXPORT_RE.containsMatchIn("document.getElementById('a').onclick = function(){ alert(1) }"))
    }

    @Test fun testFilesAreRecognised() {
        assertTrue(RunTests.isJsTest("tests/cart.test.js"))
        assertFalse(RunTests.isJsTest("js/cart.js"))
    }
}
