package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** A big project shows the model only the files the request is about. */
class CoderPickTest {
    private fun big(): Map<String, String> {
        val filler = "val x = 1\n".repeat(2500)   // about 25,000 chars per file
        return linkedMapOf(
            "src/cart.js" to "function addToCart(item) { return item }\n" + filler,
            "src/payment.js" to "function chargeCard(total) { return total }\n" + filler,
            "src/login.js" to "function loginUser(name) { return name }\n" + filler,
            "src/profile.js" to "function showProfile(id) { return id }\n" + filler
        )
    }

    @Test fun fileNamedInTheRequestIsShownAndOthersAreLeftOut() {
        val files = big()
        val shown = Coder.pickFiles(files, "fix the bug in payment.js when total is zero")
        assertTrue(shown.containsKey("src/payment.js"))
        assertTrue(shown.size < files.size)
    }

    @Test fun wholeProjectRequestsGetEverything() {
        val files = big()
        assertEquals(files.size, Coder.pickFiles(files, "rename the variable total everywhere").size)
    }

    @Test fun smallProjectsGetEverything() {
        val files = mapOf("a.js" to "let a = 1", "b.js" to "let b = 2", "c.js" to "let c = 3", "d.js" to "let d = 4")
        assertEquals(4, Coder.pickFiles(files, "change a").size)
    }

    @Test fun outlineListsOnlyTheFilesThatAreNotShown() {
        val files = big()
        val shown = Coder.pickFiles(files, "fix the bug in payment.js")
        val outline = Coder.omittedOutline(files, shown)
        assertFalse(outline.contains("src/payment.js"))
        assertTrue(outline.contains("src/"))
    }
}
