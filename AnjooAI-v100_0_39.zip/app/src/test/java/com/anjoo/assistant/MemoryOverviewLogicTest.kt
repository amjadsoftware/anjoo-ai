package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Test

class MemoryOverviewLogicTest {
    private fun item(id: Long, kind: String) = MemItem(id, kind, "text $id", 1L, 1L)

    @Test fun sizesAreReadable() {
        assertEquals("0 B", MemoryOverviewLogic.size(0))
        assertEquals("1023 B", MemoryOverviewLogic.size(1023))
        assertEquals("1.5 KB", MemoryOverviewLogic.size(1536))
        assertEquals("3.0 MB", MemoryOverviewLogic.size(3L * 1024 * 1024))
    }

    @Test fun percentIsSafe() {
        assertEquals(0, MemoryOverviewLogic.percent(0, 0))
        assertEquals(33, MemoryOverviewLogic.percent(1, 3))
        assertEquals(100, MemoryOverviewLogic.percent(5, 3))
    }

    @Test fun kindSummaryCountsEachKind() {
        val items = listOf(item(1, "fact"), item(2, "fact"), item(3, "pref"), item(4, "person"), item(5, "person"), item(6, "weird"))
        assertEquals("2 facts · 1 preference · 2 people · 1 other", MemoryOverviewLogic.kindSummary(items))
        assertEquals("", MemoryOverviewLogic.kindSummary(emptyList()))
        assertEquals("1 task", MemoryOverviewLogic.kindSummary(listOf(item(1, "task"))))
    }
}
