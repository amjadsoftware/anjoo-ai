package com.anjoo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** "continue" after an interrupted build finishes the saved project instead of starting a new one. */
class CoderResumeTest {
    @Test fun shortContinueWordsAreRecognised() {
        for (t in listOf("continue", "Continue please", "please continue", "resume", "finish it", "aage karo", "dobara karo", "pura karo", "poora karo"))
            assertTrue(t, Coder.isContinue(t))
    }

    @Test fun realRequestsAreNotTreatedAsContinue() {
        assertFalse(Coder.isContinue("make a todo app with dark mode"))
        assertFalse(Coder.isContinue("add a login page"))
        assertFalse(Coder.isContinue("continue the story about a clockmaker and write three pages about his life in detail"))
    }
}
