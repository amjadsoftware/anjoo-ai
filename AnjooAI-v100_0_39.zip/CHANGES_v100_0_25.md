# v100.0.25 - Recurring study (daily), safe by design

- Study mode can now be repeated: "roz subah 8 baje <topic> par seekho" uses schedule_agent (daily_time, minutes or datetime).
- Scheduled study only researches and sends a short sourced note; it never calls knowledge_add because nobody is there to approve. The user says "save kar do" later and the normal Confirm card appears.
- Weekly schedules are NOT supported by schedule_agent; Anjoo is told to say so and offer daily or one-time.
- New: Study.jobPrompt(topic) (topic capped at 200 chars). AppMap "Study mode" entry updated. Test: StudyTest.scheduledStudyNeverSavesByItself.
- Version 100.0.25 / fallback code 100025. Not built with Gradle here (no Android SDK); check build and tests in CI.
