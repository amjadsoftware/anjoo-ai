package com.anjoo.assistant

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Opening scene: a night sky with twinkling stars and a soft aurora, a glowing orb that rises over layered hills,
 * a shooting star and drifting fireflies. The Anjoo spark appears inside the orb, then the app opens.
 */
class SplashActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var opened = false
    private var anim: ValueAnimator? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private class Scene(ctx: Context) : View(ctx) {
        var t = 0f // seconds
        private val d = resources.displayMetrics.density
        private val rnd = Random(7)
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private val logo = ctx.resources.getDrawable(R.drawable.ic_launcher_foreground, null)

        private val sx = FloatArray(90) { rnd.nextFloat() }
        private val sy = FloatArray(90) { rnd.nextFloat() * 0.62f }
        private val sr = FloatArray(90) { 0.6f + rnd.nextFloat() * 1.5f }
        private val sp = FloatArray(90) { rnd.nextFloat() * 6.28f }
        private val fx = FloatArray(34) { rnd.nextFloat() }
        private val fy = FloatArray(34) { rnd.nextFloat() }
        private val fs = FloatArray(34) { 0.04f + rnd.nextFloat() * 0.08f }
        private val fp = FloatArray(34) { rnd.nextFloat() * 6.28f }
        private val fc = IntArray(34) { if (it % 3 == 0) Color.rgb(255, 150, 220) else if (it % 3 == 1) Color.rgb(120, 255, 235) else Color.rgb(255, 225, 140) }

        private fun ease(x: Float): Float { val k = x.coerceIn(0f, 1f); return 1f - (1f - k) * (1f - k) * (1f - k) }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            if (w == 0f) return
            val horizon = h * 0.72f

            // sky
            p.shader = LinearGradient(0f, 0f, 0f, h,
                intArrayOf(Color.rgb(6, 5, 24), Color.rgb(24, 15, 70), Color.rgb(16, 70, 96), Color.rgb(8, 30, 48)),
                floatArrayOf(0f, 0.45f, 0.75f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
            p.shader = null

            // stars
            for (i in sx.indices) {
                val a = (0.35f + 0.65f * (0.5f + 0.5f * sin(t * 2.2f + sp[i]))) * ease(t / 0.8f)
                p.color = Color.argb((a * 255).toInt(), 255, 255, 255)
                c.drawCircle(sx[i] * w, sy[i] * h, sr[i] * d * 0.8f, p)
            }

            // aurora ribbons
            val aurA = ease((t - 0.3f) / 1.2f)
            for (b in 0 until 3) {
                val base = h * (0.22f + 0.07f * b)
                val col = when (b) { 0 -> Color.rgb(60, 255, 200); 1 -> Color.rgb(140, 110, 255); else -> Color.rgb(255, 120, 210) }
                path.reset()
                val steps = 28
                for (i in 0..steps) {
                    val x = w * i / steps
                    val y = base + 26f * d * sin(i * 0.38f + t * (0.9f + b * 0.25f) + b) + 12f * d * sin(i * 0.9f - t * 0.7f)
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                for (i in steps downTo 0) {
                    val x = w * i / steps
                    val y = base + 90f * d + 20f * d * sin(i * 0.3f + t * 0.6f + b)
                    path.lineTo(x, y)
                }
                path.close()
                p.shader = LinearGradient(0f, base - 30f * d, 0f, base + 100f * d,
                    intArrayOf(Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                        Color.argb((70 * aurA).toInt(), Color.red(col), Color.green(col), Color.blue(col)),
                        Color.argb(0, Color.red(col), Color.green(col), Color.blue(col))),
                    floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP)
                c.drawPath(path, p)
            }
            p.shader = null

            // rising orb
            val rise = ease((t - 0.2f) / 1.6f)
            val ox = w / 2f
            val oy = horizon - rise * (horizon - h * 0.36f) + 10f * d * sin(t * 1.4f) * rise
            val orbR = 64f * d
            val pulse = 1f + 0.05f * sin(t * 3f)
            // far glow
            p.shader = RadialGradient(ox, oy, orbR * 4.2f * pulse,
                intArrayOf(Color.argb(150, 110, 240, 225), Color.argb(55, 150, 120, 255), Color.argb(0, 40, 60, 160)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(ox, oy, orbR * 4.2f * pulse, p)
            p.shader = null
            // rotating rays
            c.save()
            c.rotate(t * 14f, ox, oy)
            p.strokeCap = Paint.Cap.ROUND
            for (i in 0 until 16) {
                val ang = i * (2 * PI / 16).toFloat()
                val r1 = orbR * 1.25f
                val r2 = orbR * (if (i % 2 == 0) 2.3f else 1.8f) * (0.9f + 0.1f * sin(t * 2f + i))
                p.color = Color.argb((90 * rise).toInt(), 190, 255, 245)
                p.strokeWidth = (if (i % 2 == 0) 2.4f else 1.4f) * d
                c.drawLine(ox + cos(ang) * r1, oy + sin(ang) * r1, ox + cos(ang) * r2, oy + sin(ang) * r2, p)
            }
            c.restore()
            // orb body
            p.shader = RadialGradient(ox - orbR * 0.3f, oy - orbR * 0.35f, orbR * 1.5f,
                intArrayOf(Color.rgb(255, 255, 255), Color.rgb(150, 245, 235), Color.rgb(50, 120, 190)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(ox, oy, orbR, p)
            p.shader = null

            // logo inside the orb
            val la = ease((t - 1.5f) / 0.7f)
            if (la > 0f) {
                val s = (orbR * 2.15f * (0.7f + 0.3f * la)).toInt()
                logo.alpha = (255 * la).toInt()
                logo.setBounds((ox - s / 2).toInt(), (oy - s / 2).toInt(), (ox + s / 2).toInt(), (oy + s / 2).toInt())
                logo.draw(c)
            }

            // orbiting sparks
            val orb2 = ease((t - 1.0f) / 0.8f)
            for (i in 0 until 3) {
                val ang = t * (1.2f + i * 0.35f) + i * 2.1f
                val rx = orbR * (1.7f + i * 0.35f); val ry = rx * 0.38f
                val px = ox + cos(ang) * rx
                val py = oy + sin(ang) * ry
                p.shader = RadialGradient(px, py, 9f * d, intArrayOf(Color.argb((255 * orb2).toInt(), 255, 240, 190), Color.argb(0, 255, 200, 120)), null, Shader.TileMode.CLAMP)
                c.drawCircle(px, py, 9f * d, p)
                p.shader = null
            }

            // shooting star
            val cyc = (t % 2.2f) / 2.2f
            if (t > 0.9f && cyc < 0.28f) {
                val k = cyc / 0.28f
                val x0 = w * 0.9f - k * w * 0.7f
                val y0 = h * 0.06f + k * h * 0.28f
                p.shader = LinearGradient(x0, y0, x0 + 90f * d, y0 - 56f * d,
                    Color.argb((255 * (1f - k)).toInt(), 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP)
                p.strokeWidth = 2.2f * d
                c.drawLine(x0, y0, x0 + 90f * d, y0 - 56f * d, p)
                p.shader = null
            }

            // hills (far, near) with slow drift
            drawHills(c, w, h, horizon - 6f * d, 0.045f, Color.rgb(20, 14, 62), 30f * d, 0.8f)
            drawHills(c, w, h, horizon + 26f * d, 0.07f, Color.rgb(9, 7, 32), 40f * d, 1.7f)

            // fireflies
            val fa = ease((t - 0.6f) / 1f)
            for (i in fx.indices) {
                val y = ((fy[i] - t * fs[i]) % 1f + 1f) % 1f
                val x = fx[i] + 0.03f * sin(t * 0.8f + fp[i])
                val a = fa * (0.35f + 0.65f * (0.5f + 0.5f * sin(t * 3f + fp[i])))
                val fyy = h * (0.45f + 0.5f * y)
                p.color = Color.argb((a * 200).toInt(), Color.red(fc[i]), Color.green(fc[i]), Color.blue(fc[i]))
                c.drawCircle(x * w, fyy, (1.4f + 1.4f * (i % 3)) * d * 0.7f, p)
            }
        }

        private fun drawHills(c: Canvas, w: Float, h: Float, y: Float, speed: Float, col: Int, amp: Float, seed: Float) {
            path.reset()
            path.moveTo(0f, h)
            val steps = 30
            for (i in 0..steps) {
                val x = w * i / steps
                val yy = y - amp * (0.55f + 0.45f * sin(i * 0.33f + seed + t * speed)) - amp * 0.35f * sin(i * 0.9f + seed * 2f)
                path.lineTo(x, yy)
            }
            path.lineTo(w, h)
            path.close()
            p.color = col
            c.drawPath(path, p)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val base = Color.parseColor("#07061A")
        window.setBackgroundDrawable(ColorDrawable(base))
        try { window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = base } catch (e: Exception) {}

        val root = FrameLayout(this)
        val scene = Scene(this)
        root.addView(scene, FrameLayout.LayoutParams(-1, -1))

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; alpha = 0f; translationY = dp(24).toFloat() }
        texts.addView(TextView(this).apply {
            text = "Anjoo AI"; textSize = 36f; setTextColor(Color.WHITE); letterSpacing = 0.07f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setShadowLayer(dp(14).toFloat(), 0f, 0f, Color.parseColor("#6638E8D0"))
        })
        texts.addView(TextView(this).apply {
            text = "Talk. Chat. Create. Code."; textSize = 14f; setTextColor(Color.parseColor("#A9E8DE")); letterSpacing = 0.1f
            setPadding(0, dp(8), 0, 0)
        })
        root.addView(texts, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).apply { bottomMargin = dp(120) })

        setContentView(root)
        texts.animate().alpha(1f).translationY(0f).setDuration(700).setStartDelay(1700).start()

        val started = System.nanoTime()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 60000
            interpolator = LinearInterpolator()
            addUpdateListener { scene.t = (System.nanoTime() - started) / 1e9f; scene.invalidate() }
            start()
        }
        ui.postDelayed({ openApp() }, 3600)
        root.setOnClickListener { openApp() }
    }

    private fun openApp() {
        if (opened) return
        opened = true
        val i = Intent(this, MainActivity::class.java)
        intent?.extras?.let { i.putExtras(it) }
        startActivity(i)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        anim?.cancel()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
