package com.anjoo.assistant

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * The coding brain. It plans the architecture first, writes a complete multi-file project, reviews it for
 * bugs, edits it later on request, and answers code questions with the whole project as context.
 * Projects are real folders of real files, so they can be opened, edited, previewed and exported as a zip.
 */
object Coder {

    /** Extra quality bar shared by Code Studio and the chat. */
    const val CRAFT = "UI DESIGN: css variables for colour/spacing/radius, a clear spacing scale, system-ui font stack with fluid sizes, a distinctive but tasteful palette, " +
        "dark mode through prefers-color-scheme, 44px touch targets, visible focus states, smooth transitions, inline SVG icons (no icon fonts), realistic sample content (never lorem ipsum), " +
        "and designed empty, loading and error states. Persist user data with localStorage when it helps. " +
        "GAMES: requestAnimationFrame loop with delta time, canvas scaled by devicePixelRatio, touch AND keyboard controls, pause on blur, score and high score, restart, increasing difficulty. " +
        "LOGIC: keep pure logic separate from the UI so it can be tested; for non-trivial logic add a small tests file (tests.js, test_*.py) with real assertions. " +
        "SCRIPTS/CLIs: type hints, docstrings, argparse or clear usage text, if __name__ == '__main__', requirements with versions. " +
        "BACKENDS: input validation, consistent JSON errors, environment variables for secrets, a README with run and example requests. " +
        "NEVER use alert/prompt/confirm for app flow. Never load code from random CDNs (cdnjs/jsdelivr with pinned versions only). " +
        "FINAL SELF-CHECK before you answer: every id/class used in JS exists in the HTML, every function called is defined, every linked file exists, scripts load in the right order, no unmatched brackets."

    val SYSTEM: String = "You are Anjoo Code, a principal software engineer with deep expertise in every mainstream language and framework " +
        "(Kotlin/Android, Java, Python, JavaScript/TypeScript, HTML/CSS, Node, Flutter/Dart, C/C++, C#, Go, Rust, PHP, SQL, shell). " +
        "You write code the way a careful senior engineer ships it.\n" +
        "WORKFLOW: understand the real goal behind the request, choose sensible defaults instead of asking questions (state them in NOTES), " +
        "design first, write everything, then re-read it as a strict reviewer before answering. Aim for complete, tidy code that is correct on the first run.\n" +
        "RULES:\n" +
        "1. COMPLETE and RUNNABLE: every file is fully written. Never use placeholders, TODO, '...', 'rest of code here' or pseudo-code.\n" +
        "2. ARCHITECTURE: sensible file structure, separation of concerns, small focused functions, clear names. Follow the given plan.\n" +
        "3. CORRECTNESS: before answering, mentally compile and run the code. Check imports, names that must match across files, " +
        "element ids between HTML and JS, async/await, null safety, types, off-by-one errors, resource cleanup.\n" +
        "4. ROBUST: validate input, handle errors and empty states, never crash on bad data. No hardcoded secrets.\n" +
        "5. SECURE: escape untrusted output, use parameterized queries, least privilege.\n" +
        "6. MODERN: use current stable APIs and idioms. Include the dependency/build file the project needs " +
        "(package.json, requirements.txt, build.gradle, pubspec.yaml ...) and a short README.md with how to run it.\n" +
        "7. WEB UI: semantic HTML, responsive mobile-first CSS, accessible, good spacing and typography, tasteful animation, " +
        "works offline without external libraries unless truly needed (cdnjs only).\n" +
        "8. ANDROID: Kotlin, minSdk 26, no deprecated calls, handle runtime permissions and lifecycle.\n" +
        "9. COMMENTS: short and meaningful, only where the reason is not obvious.\n" +
        "10. Choose the best language/stack yourself when it is not specified (websites and small tools: HTML/CSS/JS; scripts: Python).\n" +
        "11. CRAFT: " + CRAFT + "\n" +
        "12. SCOPE: implement what was asked completely, including the details a user expects (empty states, keyboard support, saved state, clear error messages), " +
        "but add no unrelated extras and leave no dead code or unused imports.\n" +
        "13. PREVIEW-READY: every web project must work when its main page is simply opened in a browser with NO server and NO build step: " +
        "use relative paths (never /absolute paths), plain scripts or cdnjs builds (no npm imports in the browser). When a backend is wanted (Node, Express, Flask, database...), " +
        "still write the server files, but ALSO give the page a browser-side fallback (a small api.js that tries fetch('/api/...') and, when it fails, uses localStorage with realistic demo data) " +
        "so the whole product is usable inside the Preview. Seed realistic demo content so no screen looks empty.\n" +
        "14. BIG PROJECTS: when the request describes a website, app, game or system, deliver a COMPLETE product, not a demo: every page or screen it needs as its own file, " +
        "navigation between them, polished responsive design, real content (never lorem ipsum), forms with validation, saved state, empty/error/loading states, and a README.md. " +
        "Prefer many well-organised files over one giant file.\n" +
        "15. PYTHON runs INSIDE the app (Pyodide, real CPython in WebAssembly) and is executed to test it. So Python code must: run top to bottom without keyboard input " +
        "(read options from sys.argv or constants and fall back to a built-in demo; never block on input() or an endless loop at start-up), print clear results, " +
        "use the standard library first, avoid tkinter/pygame windows, subprocess and raw sockets unless the user asks, keep logic in functions with a main() guard, " +
        "and put sample data inside the project so it works as is.\n" +
        "16. TESTABILITY: choose names and structure so every function can be called and checked on its own; for each important function include at least one concrete example in the tests file or README.\n"

    const val FORMAT = "\nOUTPUT FORMAT (strict, never wrap the whole answer in code fences):\n" +
        "=== NOTES ===\n" +
        "2-5 short lines: what you built or changed, how to run it, anything the user must know. Same language style as the user (Roman Urdu or English). " +
        "End the notes with one line starting with 'Next:' that suggests 2 useful improvements.\n" +
        "=== FILE: relative/path/name.ext ===\n" +
        "the full raw content of that file (no code fences)\n" +
        "=== FILE: next/file.ext ===\n" +
        "...\n" +
        "Use forward slashes in paths. Put nothing between files except the markers.\n"

    private const val PLAN_EXTRA = " For websites, apps, games and systems plan a COMPLETE product: list EVERY page, screen and module as its own file in FILES (under 25 entries), " +
        "name index.html as the entry page, and describe the browser-side fallback (localStorage with realistic demo data) for any backend so the Preview works with no server."

    /** The file paths named in the FILES section of a design plan. */
    private fun planFiles(plan: String): List<String> {
        val lines = plan.lines()
        val start = lines.indexOfFirst { Regex("^\\W*FILES\\b", RegexOption.IGNORE_CASE).containsMatchIn(it) }
        if (start < 0) return emptyList()
        val out = ArrayList<String>()
        for (i in start until lines.size) {
            val l = lines[i]
            if (i > start && Regex("^\\W*[A-Z][A-Z &/]{4,}\\b").containsMatchIn(l)) break
            val tok = Regex("([A-Za-z0-9_][A-Za-z0-9_./-]*\\.[A-Za-z0-9]{1,6})").find(l)?.groupValues?.get(1) ?: continue
            if (tok !in out && !tok.startsWith("node_modules")) out.add(tok)
        }
        return out
    }

    /** Big projects can be cut short by the output limit: write the planned files that are still missing, in follow-up rounds. */
    private fun finishMissing(ctx: Context, dir: File, plan: String, task: String, deep: Boolean, thought: (String) -> Unit, note: (String) -> Unit) {
        val planned = planFiles(plan)
        if (planned.size < 4) return
        for (round in 1..2) {
            if (stale()) return
            val have = readFiles(dir).keys
            val missing = planned.filter { p -> !have.contains(p) && p != "package-lock.json" }.take(8)
            if (missing.isEmpty()) return
            note("Writing the remaining files (" + missing.size + " left)...")
            val raw = gen(ctx, SYSTEM + FORMAT,
                "Task: " + task + "\n\nDESIGN PLAN:\n" + plan + "\n\nTHE PROJECT SO FAR:\n" + dump(readFiles(dir)) +
                    "\n\nSTILL MISSING: " + missing.joinToString(", ") + ". Write ONLY these missing files now, each in full, consistent with the existing files (same ids, function names, paths and styles).",
                32000, deep, thought)
            val o = parse(raw)
            if (o.isEmpty) return
            if (apply(dir, o) == 0) return
        }
    }

    private const val PLAN_SYS = "You are a principal software architect doing a DEEP ANALYSIS before any code is written. Reply with at most 45 lines and NO code. " +
        "Line 1 must be: NAME: a short project name (2-4 words). Then these sections: " +
        "REQUIREMENTS (explicit and implicit, as short bullets); STACK (language, libraries and why); " +
        "FILES (path - purpose, one per line); DATA MODEL (main structures and state); " +
        "KEY ALGORITHMS (with time complexity where relevant); EDGE CASES AND FAILURE MODES (empty input, huge input, network failure, bad data, permissions...); " +
        "SECURITY AND PERFORMANCE NOTES; TEST SCENARIOS (at least 6 concrete input -> expected output examples). " +
        "Be precise and practical. Prefer the simplest design that fully meets the requirements."

    /** Search/replace edits: the fast way to change part of an existing file (like Claude Code). */
    private const val EDIT_FMT = "\nEDIT BLOCKS (preferred for changing existing files, far faster than rewriting them):\n" +
        "=== EDIT: path/file.ext ===\n" +
        "<<<<<<< SEARCH\n" +
        "(lines copied exactly from the current file, with 2-3 lines of context so they are unique)\n" +
        "=======\n" +
        "(the new lines that replace them)\n" +
        ">>>>>>> REPLACE\n" +
        "One EDIT header may hold several SEARCH/REPLACE blocks. SEARCH must match the current file character for character: copy it, never retype it from memory. " +
        "Keep each block small. Use === FILE: blocks (full content) only for new files or when most of a file changes.\n"

    private const val REVIEW_SYS = "You are a meticulous code reviewer, debugger and tester. Mentally compile and run the whole project, then walk through every TEST SCENARIO from the design plan and check the result. " +
        "Look for: syntax errors, wrong or missing imports, names that do not match between files, undefined variables, " +
        "async/await mistakes, null errors, off-by-one errors, broken element ids between HTML and JS, missing dependencies, " +
        "unhandled edge cases, logic bugs, memory/performance traps and security holes. Fix every REAL problem (do not rewrite for style). " +
        "Output ONLY what you changed, as EDIT blocks (preferred) or complete FILE blocks, in the format below. If everything is already correct output exactly NO_CHANGES." + EDIT_FMT

    private const val REVISE_RULES = "\nYou are modifying an existing project. Make the smallest correct change that fully satisfies the request " +
        "and keep everything else working. Keep the existing style, naming and structure. " +
        "To remove a file output a line like: === DELETE: path/name.ext ===\n" + EDIT_FMT

    private const val REVISE_FULL = "\nYou are modifying an existing project. Make the smallest correct change that fully satisfies the request " +
        "and keep everything else working. Output every file you change or add in FULL as === FILE: blocks (no EDIT blocks, no diffs). " +
        "To remove a file output a line like: === DELETE: path/name.ext ===\n"

    private const val FIX_SYS = "You are a debugger. The project was just RUN in a real browser and the problems below appeared (script errors, missing files or a blank page). " +
        "Find the root cause of each one and fix it properly: wrong ids, undefined variables, bad script order, missing files (create them or fix the link), syntax errors, broken imports. " +
        "Do not rewrite things that work. Output ONLY what you changed, as EDIT blocks (preferred) or complete FILE blocks, in the format below. If nothing can be fixed output exactly NO_CHANGES." + EDIT_FMT

    private const val ASK_SYS = "You are Anjoo Code, an expert pair-programmer. Explain, debug, review and compare approaches precisely. " +
        "Start with the direct answer in one or two sentences, then the reasoning, then corrected code in fenced blocks with the language name (name the file each snippet belongs to). " +
        "Point to the exact line or function that is wrong and say why; give complete corrected snippets rather than vague advice. " +
        "Use the user's language style (Roman Urdu or English). Be concise but complete.\n" + Style.RULES

    class Edit(val path: String, val search: String, val replace: String)

    class Out(val notes: String, val files: List<Pair<String, String>>, val deletes: List<String>, val edits: List<Edit> = emptyList()) {
        val isEmpty: Boolean get() = files.isEmpty() && deletes.isEmpty() && edits.isEmpty()
    }

    // ---------- storage ----------

    private fun root(ctx: Context) = File(ctx.filesDir, "projects").also { it.mkdirs() }
    private const val META = ".anjoo-meta.json"

    fun list(ctx: Context): List<File> =
        (root(ctx).listFiles()?.filter { it.isDirectory }?.toList() ?: emptyList()).sortedByDescending { it.lastModified() }

    fun latest(ctx: Context): File? = list(ctx).firstOrNull()

    private fun meta(dir: File): JSONObject =
        try { JSONObject(File(dir, META).readText(Charsets.UTF_8)) } catch (e: Exception) { JSONObject() }

    private fun saveMeta(dir: File, m: JSONObject) {
        try { File(dir, META).writeText(m.toString(), Charsets.UTF_8) } catch (e: Exception) {}
        dir.setLastModified(System.currentTimeMillis())
    }

    fun name(dir: File): String = meta(dir).optString("name", dir.name)

    fun history(dir: File): List<Pair<String, String>> {
        val h = meta(dir).optJSONArray("history") ?: return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until h.length()) {
            val o = h.optJSONObject(i) ?: continue
            out.add(Pair(o.optString("r"), o.optString("t")))
        }
        return out
    }

    private fun addHistory(dir: File, role: String, text: String) {
        val m = meta(dir)
        val h = m.optJSONArray("history") ?: JSONArray()
        h.put(JSONObject().put("r", role).put("t", text.take(6000)))
        // keep the file small
        val keep = JSONArray()
        val from = maxOf(0, h.length() - 60)
        for (i in from until h.length()) keep.put(h.get(i))
        m.put("history", keep)
        saveMeta(dir, m)
    }

    fun readFiles(dir: File): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        val all = dir.walkTopDown().filter { it.isFile && !it.name.startsWith(".anjoo") }.toList().sortedBy { it.path }
        for (f in all) {
            val rel = f.relativeTo(dir).path.replace('\\', '/')
            out[rel] = try { f.readText(Charsets.UTF_8) } catch (e: Exception) { "" }
        }
        return out
    }

    fun writeFile(dir: File, rel: String, content: String): Boolean {
        val p = safe(rel) ?: return false
        val f = File(dir, p)
        return try {
            f.parentFile?.mkdirs()
            f.writeText(content, Charsets.UTF_8)
            dir.setLastModified(System.currentTimeMillis())
            true
        } catch (e: Exception) { false }
    }

    private fun safe(p: String): String? {
        val parts = p.replace('\\', '/').split('/').map { it.trim() }.filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty() || parts.any { it == ".." } || parts.size > 7) return null
        if (parts.last().startsWith(".anjoo")) return null
        return parts.joinToString("/")
    }

    fun delete(dir: File) { try { dir.deleteRecursively() } catch (e: Exception) {} }

    fun rename(dir: File, name: String) {
        val m = meta(dir)
        m.put("name", name.trim().take(60).ifEmpty { dir.name })
        saveMeta(dir, m)
    }

    private fun undoFile(ctx: Context, dir: File) = File(File(ctx.filesDir, "undo").also { it.mkdirs() }, dir.name + ".json")

    /** Saves the project's files so the next edit can be undone. */
    fun snapshot(ctx: Context, dir: File) {
        try {
            val o = JSONObject()
            for ((k, v) in readFiles(dir)) o.put(k, v)
            undoFile(ctx, dir).writeText(o.toString(), Charsets.UTF_8)
        } catch (e: Exception) {}
    }

    fun canUndo(ctx: Context, dir: File) = undoFile(ctx, dir).exists()

    /** A short list of what the last edit changed, like a mini diff. */
    fun changes(ctx: Context, dir: File): String {
        val f = undoFile(ctx, dir)
        if (!f.exists()) return ""
        return try {
            val old = JSONObject(f.readText(Charsets.UTF_8))
            val now = readFiles(dir)
            val sb = StringBuilder()
            for ((p, c) in now) {
                if (!old.has(p)) { sb.append("➕ ").append(p).append("  (new, ").append(c.split("\n").size).append(" lines)\n"); continue }
                val o = old.getString(p)
                if (o == c) continue
                val cnt = HashMap<String, Int>()
                for (l in o.split("\n")) cnt[l] = (cnt[l] ?: 0) + 1
                var add = 0
                for (l in c.split("\n")) { val n = cnt[l] ?: 0; if (n > 0) cnt[l] = n - 1 else add++ }
                val del = cnt.values.sum()
                sb.append("✏️ ").append(p).append("  +").append(add).append("  -").append(del).append("\n")
            }
            for (k in old.keys()) if (!now.containsKey(k)) sb.append("🗑 ").append(k).append("  (deleted)\n")
            if (sb.isEmpty()) "" else "Changed files:\n" + sb.toString().trim()
        } catch (e: Exception) { "" }
    }

    /** One changed file of the last edit, with a ready-to-show diff (lines start with "+ ", "- " or "  "). */
    class Change(val path: String, val status: String, val add: Int, val del: Int, val diff: List<String>)

    /** Line diff with 2 lines of context per hunk. Uses LCS for normal files and a cheap fallback for huge ones. */
    private fun lineDiff(o: List<String>, n: List<String>): List<String> {
        val ops = ArrayList<String>()
        if (o.size.toLong() * n.size <= 4_000_000L) {
            val w = n.size + 1
            val t = IntArray((o.size + 1) * w)
            for (i in o.size - 1 downTo 0) for (j in n.size - 1 downTo 0)
                t[i * w + j] = if (o[i] == n[j]) t[(i + 1) * w + j + 1] + 1 else maxOf(t[(i + 1) * w + j], t[i * w + j + 1])
            var i = 0; var j = 0
            while (i < o.size && j < n.size) {
                if (o[i] == n[j]) { ops.add("  " + o[i]); i++; j++ }
                else if (t[(i + 1) * w + j] >= t[i * w + j + 1]) { ops.add("- " + o[i]); i++ }
                else { ops.add("+ " + n[j]); j++ }
            }
            while (i < o.size) { ops.add("- " + o[i]); i++ }
            while (j < n.size) { ops.add("+ " + n[j]); j++ }
        } else {
            val on = o.toHashSet(); val nn = n.toHashSet()
            for (l in o) if (l !in nn) ops.add("- " + l)
            for (l in n) if (l !in on) ops.add("+ " + l)
            return ops
        }
        val keep = BooleanArray(ops.size)
        for (k in ops.indices) if (!ops[k].startsWith("  ")) for (m in maxOf(0, k - 2)..minOf(ops.size - 1, k + 2)) keep[m] = true
        val out = ArrayList<String>()
        var gap = false
        for (k in ops.indices) {
            if (keep[k]) { if (gap && out.isNotEmpty()) out.add("  ..."); gap = false; out.add(ops[k]) } else gap = true
        }
        return out
    }

    /** Every file the last edit created, changed or deleted, with +/- counts and a diff. Empty if nothing changed. */
    fun diffs(ctx: Context, dir: File): List<Change> {
        val f = undoFile(ctx, dir)
        if (!f.exists()) return emptyList()
        return try {
            val old = JSONObject(f.readText(Charsets.UTF_8))
            val now = readFiles(dir)
            val out = ArrayList<Change>()
            for ((p, c) in now) {
                val nl = c.split("\n")
                if (!old.has(p)) { out.add(Change(p, "new", nl.size, 0, nl.take(60).map { "+ " + it })); continue }
                val oc = old.getString(p)
                if (oc == c) continue
                val d = lineDiff(oc.split("\n"), nl)
                out.add(Change(p, "edit", d.count { it.startsWith("+ ") }, d.count { it.startsWith("- ") }, d.take(400)))
            }
            for (k in old.keys()) if (!now.containsKey(k)) out.add(Change(k, "deleted", 0, old.getString(k).split("\n").size, emptyList()))
            out
        } catch (e: Exception) { emptyList() }
    }

    /** Puts the project back to how it was before the last edit. */
    fun undo(ctx: Context, dir: File): Boolean {
        val f = undoFile(ctx, dir)
        if (!f.exists()) return false
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            for (k in readFiles(dir).keys) File(dir, k).delete()
            for (k in o.keys()) writeFile(dir, k, o.getString(k))
            f.delete()
            true
        } catch (e: Exception) { false }
    }

    private fun newDir(ctx: Context, name: String): File {
        val slug = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(24).ifEmpty { "project" }
        val d = File(root(ctx), slug + "-" + (System.currentTimeMillis() / 1000))
        d.mkdirs()
        return d
    }

    fun zip(dir: File): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            for ((rel, c) in readFiles(dir)) {
                z.putNextEntry(ZipEntry(rel))
                z.write(c.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
        return bo.toByteArray()
    }

    private val ZIP_SKIP = listOf("node_modules/", ".git/", "build/", "dist/", ".gradle/", "__pycache__/", ".idea/", "__MACOSX/", "venv/", ".venv/")

    /** Opens a ZIP as a new project (text and code files only; binaries, node_modules, .git are left out). */
    fun importZip(ctx: Context, bytes: ByteArray, zipName: String): File? {
        val entries = ArrayList<Pair<String, ByteArray>>()
        try {
            java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(bytes)).use { z ->
                while (entries.size < 400) {
                    val e = z.nextEntry ?: break
                    if (e.isDirectory) continue
                    val n = e.name.replace('\\', '/')
                    if (ZIP_SKIP.any { n.contains(it) } || n.substringAfterLast('/').startsWith(".anjoo")) continue
                    val data = z.readBytes()
                    if (data.size > 400000 || data.take(2000).any { it.toInt() == 0 }) continue
                    entries.add(Pair(n, data))
                }
            }
        } catch (e: Exception) { return null }
        if (entries.isEmpty()) return null
        val tops = entries.map { it.first.substringBefore('/', "") }.toSet()
        val strip = tops.size == 1 && tops.first().isNotEmpty() && entries.all { it.first.contains('/') }
        val base = zipName.substringBeforeLast('.').ifBlank { "project" }.take(40)
        val d = newDir(ctx, base)
        var n = 0
        for ((p, data) in entries) {
            val rel = if (strip) p.substringAfter('/') else p
            if (writeFile(d, rel, String(data, Charsets.UTF_8))) n++
        }
        if (n == 0) { d.deleteRecursively(); return null }
        saveMeta(d, JSONObject().put("name", base).put("created", System.currentTimeMillis()))
        return d
    }

    /** Text of an attached file for the coder: plain text/code as is, or all text files of a ZIP joined. Null when unreadable. */
    fun attachmentText(name: String, bytes: ByteArray): String? {
        if (bytes.size > 3 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()) {
            val sb = StringBuilder()
            var count = 0
            try {
                java.util.zip.ZipInputStream(java.io.ByteArrayInputStream(bytes)).use { z ->
                    while (sb.length < 120000) {
                        val e = z.nextEntry ?: break
                        if (e.isDirectory) continue
                        val n = e.name.replace('\\', '/')
                        if (ZIP_SKIP.any { n.contains(it) }) continue
                        val data = z.readBytes()
                        if (data.size > 300000 || data.take(2000).any { it.toInt() == 0 }) continue
                        sb.append("=== ").append(n).append(" ===\n").append(String(data, Charsets.UTF_8)).append("\n\n")
                        count++
                    }
                }
            } catch (e: Exception) { return null }
            if (count == 0) return null
            return ("ZIP " + name + " (" + count + " files)\n\n" + sb).take(130000)
        }
        if (bytes.take(2000).any { it.toInt() == 0 }) return null
        return String(bytes, Charsets.UTF_8).take(120000)
    }

    fun projectDir(ctx: Context, name: String): File = File(root(ctx), name)

    /** Makes a one-file Code Studio project from code the user attached, so it can be edited like any project. */
    fun fileProject(ctx: Context, fileName: String, content: String): File {
        val nm = fileName.substringBeforeLast('.').take(40).ifBlank { "My code" }
        val dir = newDir(ctx, nm)
        saveMeta(dir, JSONObject().put("name", nm).put("language", "auto").put("created", System.currentTimeMillis()))
        writeFile(dir, fileName, content)
        addHistory(dir, "u", "Attached " + fileName)
        keepCopy(ctx, dir)
        return dir
    }

    private fun keepRoot(ctx: Context) = File(ctx.filesDir, "chatkeep").also { it.mkdirs() }

    /** A second copy of a chat's project, so the files in the chat survive even if the project is deleted in Code Studio. */
    fun keepCopy(ctx: Context, dir: File) {
        try { dir.copyRecursively(File(keepRoot(ctx), dir.name), overwrite = true) } catch (e: Exception) {}
    }

    /** The project folder for a chat card; brings it back from the kept copy when it was deleted. */
    fun ensureProject(ctx: Context, name: String): File? {
        val d = projectDir(ctx, name)
        if (d.exists()) return d
        val k = File(keepRoot(ctx), name)
        if (!k.exists()) return null
        return try { k.copyRecursively(d, overwrite = true); d } catch (e: Exception) { null }
    }

    private val SKIP_LANGS = setOf("", "text", "txt", "output", "console", "bash", "sh", "shell", "zsh", "diff", "log", "markdown", "md")

    private fun snippetName(l: String): String = when (l) {
        "html", "htm" -> "index.html"
        "svg" -> "image.svg"
        "css" -> "style.css"
        "js", "javascript" -> "script.js"
        "ts", "typescript" -> "index.ts"
        "py", "python" -> "main.py"
        "kotlin", "kt" -> "Main.kt"
        "java" -> "Main.java"
        "c" -> "main.c"
        "cpp", "c++" -> "main.cpp"
        "go" -> "main.go"
        "rust", "rs" -> "main.rs"
        "php" -> "index.php"
        "json" -> "data.json"
        "sql" -> "query.sql"
        "dart" -> "main.dart"
        else -> ""
    }

    /**
     * Turns the code blocks of a chat reply into project files inside Code Studio.
     * A file name is taken from the line just before a block (FILE: x), from a first-line comment, or from the language.
     * Returns the folder and its file count, or null when there is nothing worth keeping.
     * When [existing] already holds a file with the same name, that project is updated instead of a new one.
     */
    fun saveFromChat(ctx: Context, reply: String, title: String, existing: File?, force: Boolean = false): Pair<File, Int>? {
        val fence = Regex("```([A-Za-z0-9+#._-]*)[ \\t]*\\r?\\n([\\s\\S]*?)```")
        val tokRe = Regex("([A-Za-z0-9_][A-Za-z0-9_./-]*\\.[A-Za-z0-9]{1,6})")
        val commentRe = Regex("^(?://|#|--|<!--|/\\*)\\s*(?:file(?:name)?\\s*[:=]\\s*)?([A-Za-z0-9_][A-Za-z0-9_./-]*\\.[A-Za-z0-9]{1,6})\\s*(?:-->|\\*/)?\\s*$", RegexOption.IGNORE_CASE)
        val names = ArrayList<String>()
        val codes = ArrayList<String>()
        var labelled = false
        var lineCount = 0
        var firstLang = ""
        for (m in fence.findAll(reply)) {
            val lang = m.groupValues[1].lowercase()
            val code = m.groupValues[2].trimEnd()
            if (code.isBlank()) continue
            val before = reply.substring(maxOf(0, m.range.first - 160), m.range.first).trimEnd().lines().lastOrNull() ?: ""
            var name: String? = null
            var isLabel = false
            val tok = tokRe.find(before)?.groupValues?.get(1)
            if (tok != null && before.length < 90 &&
                (before.contains("file", true) || before.trim().trim('*', '_', '`', ':', ' ', '#', '>', '-') == tok)) { name = tok; isLabel = true }
            if (name == null) {
                val c = commentRe.find(code.lines().first().trim())?.groupValues?.get(1)
                if (c != null) { name = c; isLabel = true }
            }
            if (name == null) {
                if (lang in SKIP_LANGS) continue
                name = snippetName(lang)
                if (name.isEmpty()) continue
            }
            name = name.trimStart('/', '.')
            if (name.isEmpty()) continue
            val at = names.indexOf(name)
            if (at >= 0) {
                if (isLabel) { codes[at] = code; continue }
                var n = 2
                val dot = name.lastIndexOf('.')
                val stem = if (dot > 0) name.substring(0, dot) else name
                val ext = if (dot > 0) name.substring(dot) else ""
                while (names.contains(stem + n + ext)) n++
                name = stem + n + ext
            }
            if (isLabel) labelled = true
            if (firstLang.isEmpty()) firstLang = lang
            names.add(name); codes.add(code)
            lineCount += code.count { it == '\n' } + 1
        }
        if (names.isEmpty() || (!force && !labelled && lineCount < 12)) return null
        val reuse = existing != null && existing.exists() && names.any { readFiles(existing).containsKey(it) }
        val dir: File
        if (reuse) {
            dir = existing!!
            snapshot(ctx, dir)
        } else {
            val nm = title.replace(Regex("\\s+"), " ").trim().take(40).ifBlank { "Chat project" }
            dir = newDir(ctx, nm)
            saveMeta(dir, JSONObject().put("name", nm).put("language", firstLang.ifEmpty { "auto" }).put("created", System.currentTimeMillis()))
            addHistory(dir, "u", title.take(300))
            addHistory(dir, "a", "Saved from the Anjoo chat.")
        }
        for (i in names.indices) writeFile(dir, names[i], codes[i] + "\n")
        keepCopy(ctx, dir)
        return Pair(dir, readFiles(dir).size)
    }

    /** Saves one code block from the chat as its own small project, so it can be edited and exported. */
    fun snippetProject(ctx: Context, lang: String, code: String): File {
        val l = lang.lowercase()
        val file = when (l) {
            "html", "htm" -> "index.html"
            "svg" -> "image.svg"
            "css" -> "style.css"
            "js", "javascript" -> "script.js"
            "ts", "typescript" -> "index.ts"
            "py", "python" -> "main.py"
            "kotlin", "kt" -> "Main.kt"
            "java" -> "Main.java"
            "c" -> "main.c"
            "cpp", "c++" -> "main.cpp"
            "go" -> "main.go"
            "rust", "rs" -> "main.rs"
            "php" -> "index.php"
            "sh", "bash", "shell" -> "script.sh"
            "json" -> "data.json"
            "sql" -> "query.sql"
            "dart" -> "main.dart"
            else -> "snippet.txt"
        }
        val dir = newDir(ctx, "snippet " + l)
        writeFile(dir, file, code + "\n")
        saveMeta(dir, JSONObject().put("name", "Snippet (" + l.ifEmpty { "code" } + ")").put("language", l).put("created", System.currentTimeMillis()))
        return dir
    }

    fun open(ctx: Context, dir: File?, preview: Boolean = false) {
        val i = Intent(ctx, CodeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (dir != null) i.putExtra("project", dir.absolutePath)
        if (preview) i.putExtra("preview", true)
        ctx.startActivity(i)
    }

    // ---------- parsing ----------

    private fun cleanFile(b: String): String {
        var t = b.trim('\n', '\r')
        var fenced = false
        if (t.trimStart().startsWith("```")) { t = t.trimStart().substringAfter("\n", ""); fenced = true }
        if (fenced) {
            val e = t.trimEnd()
            if (e.endsWith("```")) t = e.removeSuffix("```")
        }
        return t.trimEnd() + "\n"
    }

    fun parse(raw: String): Out {
        val re = Regex("(?m)^=== (FILE|DELETE|EDIT): (.+?) ===[ \\t]*$")
        val ms = re.findAll(raw).toList()
        var notes = raw
        val files = ArrayList<Pair<String, String>>()
        val dels = ArrayList<String>()
        val edits = ArrayList<Edit>()
        if (ms.isNotEmpty()) {
            notes = raw.substring(0, ms[0].range.first)
            for (i in ms.indices) {
                val m = ms[i]
                val end = if (i + 1 < ms.size) ms[i + 1].range.first else raw.length
                val body = raw.substring(m.range.last + 1, end)
                val path = m.groupValues[2].trim()
                when (m.groupValues[1]) {
                    "DELETE" -> dels.add(path)
                    "EDIT" -> edits.addAll(parseEdits(path, body))
                    else -> files.add(Pair(path, cleanFile(body)))
                }
            }
        }
        notes = notes.replace(Regex("(?m)^=== NOTES ===[ \\t]*$"), "").trim()
        return Out(notes, files, dels, edits)
    }

    private val EDIT_RE = Regex("<<<<<<< SEARCH\\r?\\n([\\s\\S]*?)\\r?\\n=======\\r?\\n([\\s\\S]*?)\\r?\\n?>>>>>>> REPLACE")

    private fun parseEdits(path: String, body: String): List<Edit> =
        EDIT_RE.findAll(body).map { Edit(path, it.groupValues[1], it.groupValues[2]) }.toList()

    /** Replaces the first match of [search]; falls back to a match that ignores indentation and trailing spaces. */
    private fun replaceOnce(text: String, search: String, repl: String): String? {
        if (search.isEmpty()) return null
        val k = text.indexOf(search)
        if (k >= 0) return text.substring(0, k) + repl + text.substring(k + search.length)
        val tl = text.split("\n")
        val sl = search.trim('\n', '\r').split("\n").map { it.trim() }
        if (sl.all { it.isEmpty() }) return null
        var at = -1
        for (i in 0..(tl.size - sl.size)) {
            var ok = true
            for (j in sl.indices) if (tl[i + j].trim() != sl[j]) { ok = false; break }
            if (ok) { at = i; break }
        }
        if (at < 0) return null
        val out = ArrayList<String>()
        out.addAll(tl.subList(0, at))
        if (repl.isNotEmpty()) {
            // the model's indentation may differ from the file's: shift the replacement to the file's indentation
            val sInd = search.trim('\n', '\r').split("\n").first().takeWhile { it == ' ' || it == '\t' }
            val fInd = tl[at].takeWhile { it == ' ' || it == '\t' }
            for (ln in repl.trim('\n', '\r').split("\n"))
                out.add(if (sInd != fInd && ln.startsWith(sInd)) fInd + ln.substring(sInd.length) else ln)
        }
        out.addAll(tl.subList(at + sl.size, tl.size))
        return out.joinToString("\n")
    }

    /** Applies search/replace edits. Returns the paths where at least one edit did not match. */
    private fun applyEdits(dir: File, edits: List<Edit>, touched: MutableSet<String>): List<String> {
        val failed = LinkedHashSet<String>()
        val byFile = LinkedHashMap<String, MutableList<Edit>>()
        for (e in edits) {
            val p = safe(e.path) ?: continue
            byFile.getOrPut(p) { ArrayList() }.add(e)
        }
        for ((p, list) in byFile) {
            val f = File(dir, p)
            val first = try { if (f.isFile) f.readText(Charsets.UTF_8) else null } catch (ex: Exception) { null }
            if (first == null) { failed.add(p); continue }
            var text: String = first
            var changed = false
            for (e in list) {
                val r = replaceOnce(text, e.search, e.replace)
                if (r == null) failed.add(p) else { text = r; changed = true }
            }
            if (changed && writeFile(dir, p, text)) touched.add(p)
        }
        return failed.toList()
    }

    private fun apply(dir: File, o: Out, failed: MutableList<String>? = null): Int {
        val touched = LinkedHashSet<String>()
        for ((p, c) in o.files) if (writeFile(dir, p, c)) { val sp = safe(p); if (sp != null) touched.add(sp) }
        val bad = applyEdits(dir, o.edits, touched)
        if (failed != null) failed.addAll(bad)
        for (p in o.deletes) {
            val sp = safe(p) ?: continue
            try { File(dir, sp).delete() } catch (e: Exception) {}
            touched.add(sp)
        }
        return touched.size
    }

    private fun dump(files: Map<String, String>, cap: Int = 110000): String {
        val sb = StringBuilder()
        for ((p, c) in files) {
            if (sb.length + c.length > cap) { sb.append("=== FILE: ").append(p).append(" === (skipped, too large)\n"); continue }
            sb.append("=== FILE: ").append(p).append(" ===\n").append(c).append("\n")
        }
        return sb.toString()
    }

    // ---------- model calls ----------

    /** Live view of the current model call: (thought summary so far, answer so far). Set by the screen showing progress. */
    @Volatile var live: ((String, String) -> Unit)? = null

    /** Stop support: every run remembers the id it started with; [stop] makes older runs quit at their next model call. */
    @Volatile private var runId = 0
    private val tid = ThreadLocal<Int>()
    fun stop() { runId++ }
    private fun enter() { tid.set(runId) }
    private fun stale(): Boolean { val me: Int? = tid.get(); return me != null && me != runId }

    fun deepDefault(ctx: Context): Boolean = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean("codeThink", true)

    private fun gen(
        ctx: Context, system: String, user: String, max: Int,
        deep: Boolean = false, thought: (String) -> Unit = {}
    ): String {
        if (stale()) throw java.util.concurrent.CancellationException("Stopped")
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        Providers.load(p)
        val key = p.getString("key", "") ?: ""
        if (key.isEmpty()) throw IllegalStateException("Pehle Settings mein API key dalein.")
        val own = if (Providers.active.id == "gemini") (p.getString("codeModel", "") ?: "") else ""
        val model = own.ifBlank { p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash" }
        val limit = if (deep) minOf(60000, max + 16000) else max
        val f0 = live
        val me: Int? = tid.get()
        val lv: ((String, String) -> Unit)? = if (f0 == null) null else fun(a: String, b: String) { if (me == null || me == runId) f0(a, b) }
        Router.taskOverride.set(Task.CODE)
        val r = try { Gemini.plainFull(key, model, system, JSONArray().put(JSONObject().put("text", user)), limit, 0.3, deep, lv) } finally { Router.taskOverride.remove() }
        if (stale()) throw java.util.concurrent.CancellationException("Stopped")
        if (r.thoughts.isNotBlank()) thought(r.thoughts)
        return r.text
    }

    private fun defaultName(language: String): String = when (language.lowercase()) {
        "python", "py" -> "main.py"
        "kotlin" -> "Main.kt"
        "java" -> "Main.java"
        "javascript", "js", "node" -> "index.js"
        "typescript", "ts" -> "index.ts"
        "c++", "cpp" -> "main.cpp"
        "c" -> "main.c"
        "go" -> "main.go"
        "rust" -> "main.rs"
        "php" -> "index.php"
        else -> "index.html"
    }

    /** Analyses, plans, writes and reviews (two rounds) a brand-new project. Returns the folder and a short note. */
    fun build(
        ctx: Context, task: String, language: String, review: Boolean,
        deep: Boolean = false, thought: (String) -> Unit = {}, note: (String) -> Unit
    ): Pair<File, String> {
        enter()
        val lang = language.ifBlank { "auto" }
        note(if (deep) "Deep analysis of the request..." else "Planning the architecture...")
        val plan = gen(ctx, PLAN_SYS + PLAN_EXTRA, "Language/stack: " + lang + "\nTask: " + task, 6000, deep, thought)
        val name = Regex("(?m)^NAME:\\s*(.+)$").find(plan)?.groupValues?.get(1)?.trim()?.take(40)?.ifBlank { null } ?: task.take(30)
        thought("📐 Design plan\n" + plan)
        note("Writing the code...")
        val raw = gen(ctx, SYSTEM + FORMAT, "Language/stack: " + lang + "\nTask: " + task + "\n\nDESIGN PLAN (follow it and satisfy its test scenarios):\n" + plan, 32000, deep, thought)
        val out = parse(raw)
        var files = out.files
        if (files.isEmpty()) {
            val body = cleanFile(raw)
            if (body.isBlank()) throw IllegalStateException("Code nahi bana, dobara koshish karein.")
            files = listOf(Pair(defaultName(lang), body))
        }
        val dir = newDir(ctx, name)
        for ((p, c) in files) writeFile(dir, p, c)
        saveMeta(dir, JSONObject().put("name", name).put("language", lang).put("created", System.currentTimeMillis()))
        addHistory(dir, "u", task)
        try { finishMissing(ctx, dir, plan, task, deep, thought, note) } catch (e: Exception) {}
        var notes = out.notes.ifBlank { "Project tayyar hai: " + files.size + " file(s)." }
        if (review && !stale()) {
            var fixed = 0
            try {
                // Cheap local checks first: the model review runs when Deep think is on or the checks found something.
                if (deep || lint(readFiles(dir)).isNotBlank()) {
                    note("Reviewing and testing (round 1)...")
                    val n1 = reviewPass(ctx, dir, plan, deep, thought)
                    fixed += n1
                    if (n1 > 0) {
                        note("Verifying the fixes (round 2)...")
                        fixed += reviewPass(ctx, dir, plan, deep, thought)
                    }
                }
            } catch (e: Exception) {}
            try { fixed += runAndFix(ctx, dir, deep, thought, note) } catch (e: Exception) {}
            if (fixed > 0) notes += "\n(Review and run check: " + fixed + " file fix(es) applied.)"
        }
        addHistory(dir, "a", notes)
        return Pair(dir, notes)
    }

    private fun reviewPass(ctx: Context, dir: File, plan: String, deep: Boolean, thought: (String) -> Unit): Int {
        val files = readFiles(dir)
        val found = lint(files).ifBlank { "nothing found" }
        val raw = gen(
            ctx, REVIEW_SYS + FORMAT,
            "DESIGN PLAN AND TEST SCENARIOS:\n" + plan + "\n\nAUTOMATIC CHECK RESULTS (a tool found these; confirm each and fix real ones, ignore false alarms):\n" +
                found + "\n\nREVIEW THIS PROJECT:\n" + dump(files), 32000, deep, thought
        )
        val o = parse(raw)
        if (o.isEmpty) return 0
        return apply(dir, o)
    }

    /** Runs a web project in a hidden browser and lets the model fix what broke. Returns the number of files changed. */
    private fun runAndFix(ctx: Context, dir: File, deep: Boolean, thought: (String) -> Unit, note: (String) -> Unit): Int {
        if ((Runner.entry(dir) == null && PyRun.entry(dir) == null) || stale()) return 0
        var fixed = 0
        for (round in 1..2) {
            note("Running it to look for errors...")
            val errs = try { Runner.check(ctx, dir) } catch (e: Exception) { "" }
            if (errs.isBlank()) break
            thought("🧪 Run check (round " + round + ")\n" + errs)
            note("Found errors while running, fixing (round " + round + ")...")
            val raw = gen(ctx, FIX_SYS + FORMAT, "PROBLEMS SEEN WHEN RUNNING:\n" + errs + "\n\nPROJECT:\n" + dump(readFiles(dir)), 32000, deep, thought)
            val o = parse(raw)
            if (o.isEmpty) break
            fixed += apply(dir, o)
        }
        return fixed
    }

    private val ID_RE = Regex("\\bid\\s*=\\s*[\"']([^\"']+)[\"']")
    private val GET_ID_RE = Regex("getElementById\\(\\s*[\"']([^\"']+)[\"']\\s*\\)")
    private val QS_ID_RE = Regex("querySelector(?:All)?\\(\\s*[\"']#([A-Za-z_][\\w-]*)[\"']\\s*\\)")
    private val INLINE_JS_RE = Regex("<script(?![^>]*\\bsrc\\s*=)[^>]*>([\\s\\S]*?)</script>", RegexOption.IGNORE_CASE)
    private val BRACKET_EXT = setOf(
        "js", "mjs", "jsx", "ts", "tsx", "java", "kt", "kts", "c", "cpp", "h", "cs", "go", "rs", "php", "dart", "swift", "css", "scss", "py"
    )

    /**
     * Finds an unmatched or mismatched ( [ { while skipping strings and comments.
     * Returns a short description of the first problem, or null when the brackets are balanced.
     * It is a hint for the reviewer (regex literals can fool it), not a verdict.
     */
    private fun bracketCheck(src: String, py: Boolean, css: Boolean): String? {
        val st = ArrayList<Pair<Char, Int>>()
        val n = src.length
        var i = 0
        var line = 1
        while (i < n) {
            val c = src[i]
            if (c == '\n') { line++; i++; continue }
            if (py && c == '#') { while (i < n && src[i] != '\n') i++; continue }
            if (!py && !css && c == '/' && i + 1 < n && src[i + 1] == '/') { while (i < n && src[i] != '\n') i++; continue }
            if (!py && c == '/' && i + 1 < n && src[i + 1] == '*') {
                val e = src.indexOf("*/", i + 2)
                val stop = if (e < 0) n else e + 2
                for (k in i until stop) if (src[k] == '\n') line++
                i = stop
                continue
            }
            if (c == '"' || c == '\'' || (c == '`' && !py)) {
                if (c != '`' && i + 2 < n && src[i + 1] == c && src[i + 2] == c) {
                    val e = src.indexOf("" + c + c + c, i + 3)
                    val stop = if (e < 0) n else e + 3
                    for (k in i until stop) if (src[k] == '\n') line++
                    i = stop
                    continue
                }
                var e = i + 1
                while (e < n) {
                    val d = src[e]
                    if (d == '\\') { e += 2; continue }
                    if (d == c) { e++; break }
                    if (d == '\n') { if (c != '`') break else line++ }
                    e++
                }
                i = minOf(e, n)
                continue
            }
            when (c) {
                '(', '[', '{' -> st.add(Pair(c, line))
                ')', ']', '}' -> {
                    if (st.isEmpty()) return "unexpected '" + c + "' at line " + line
                    val top = st.removeAt(st.size - 1)
                    val want = when (top.first) { '(' -> ')'; '[' -> ']'; else -> '}' }
                    if (c != want) return "'" + c + "' at line " + line + " does not match '" + top.first + "' opened at line " + top.second
                }
            }
            i++
        }
        if (st.isNotEmpty()) {
            val top = st[st.size - 1]
            return "'" + top.first + "' opened at line " + top.second + " is never closed"
        }
        return null
    }

    private fun idRefs(js: String, where: String, ids: Set<String>, out: StringBuilder) {
        val missing = LinkedHashSet<String>()
        for (m in GET_ID_RE.findAll(js)) if (m.groupValues[1] !in ids) missing.add(m.groupValues[1])
        for (m in QS_ID_RE.findAll(js)) if (m.groupValues[1] !in ids) missing.add(m.groupValues[1])
        for (id in missing.take(8))
            out.append("- ").append(where).append(" looks up #").append(id).append(" but no HTML element has that id (ignore if it is created dynamically)\n")
    }

    /** Cheap automatic checks (missing files, broken JSON, unbalanced brackets, ids that do not exist) handed to the reviewer as facts. */
    private fun lint(files: Map<String, String>): String {
        val out = StringBuilder()
        val htmlIds = HashSet<String>()
        var hasHtml = false
        for ((p, c) in files) {
            if (!p.lowercase().endsWith(".html")) continue
            hasHtml = true
            val seen = HashSet<String>()
            for (m in ID_RE.findAll(c)) {
                val id = m.groupValues[1]
                htmlIds.add(id)
                if (!seen.add(id)) out.append("- ").append(p).append(": id \"").append(id).append("\" is used more than once\n")
            }
        }
        for ((p, c) in files) {
            val low = p.lowercase()
            val ext = low.substringAfterLast('.', "")
            if (ext == "html") {
                val base = p.substringBeforeLast('/', "")
                for (m in Regex("(?:src|href)\\s*=\\s*[\"']([^\"'#?]+)[\"']").findAll(c)) {
                    val ref = m.groupValues[1]
                    if (ref.startsWith("http") || ref.startsWith("//") || ref.startsWith("data:") ||
                        ref.startsWith("mailto:") || ref.startsWith("tel:") || ref.startsWith("javascript:")) continue
                    val path = if (base.isEmpty() || ref.startsWith("/")) ref.trimStart('/') else base + "/" + ref
                    if (!files.containsKey(path)) out.append("- ").append(p).append(" refers to a file that does not exist: ").append(ref).append("\n")
                }
                val opens = Regex("<script", RegexOption.IGNORE_CASE).findAll(c).count()
                val closes = Regex("</script>", RegexOption.IGNORE_CASE).findAll(c).count()
                if (opens > closes) out.append("- ").append(p).append(": a <script> tag is not closed\n")
                for (m in INLINE_JS_RE.findAll(c)) {
                    val js = m.groupValues[1]
                    val bc = bracketCheck(js, false, false)
                    if (bc != null) out.append("- ").append(p).append(" (inline script): ").append(bc).append("\n")
                    idRefs(js, p + " (inline script)", htmlIds, out)
                }
            }
            if (ext == "json") {
                try { JSONObject(c) } catch (e: Exception) {
                    try { JSONArray(c) } catch (e2: Exception) { out.append("- ").append(p).append(" is not valid JSON\n") }
                }
            }
            if (ext in BRACKET_EXT) {
                val bc = bracketCheck(c, ext == "py", ext == "css" || ext == "scss")
                if (bc != null) out.append("- ").append(p).append(": ").append(bc).append("\n")
            }
            if (hasHtml && (ext == "js" || ext == "mjs" || ext == "jsx")) idRefs(c, p, htmlIds, out)
            if (ext == "py" && Regex("(?m)^\\t").containsMatchIn(c) && Regex("(?m)^ +\\S").containsMatchIn(c))
                out.append("- ").append(p).append(" mixes tab and space indentation\n")
        }
        return out.toString()
    }

    /** Changes an existing project according to the instruction. Returns a short note. */
    fun revise(
        ctx: Context, dir: File, instruction: String,
        deep: Boolean = false, thought: (String) -> Unit = {}, note: (String) -> Unit
    ): String {
        enter()
        note("Reading the project...")
        val hist = history(dir).takeLast(6).joinToString("\n") { (if (it.first == "u") "USER: " else "ASSISTANT: ") + it.second.take(500) }
        note(if (deep) "Thinking through the change..." else "Updating the code...")
        val raw = gen(
            ctx, SYSTEM + REVISE_RULES + FORMAT,
            "CURRENT PROJECT:\n" + dump(readFiles(dir)) + "\nRECENT CHAT:\n" + hist + "\n\nUSER REQUEST: " + instruction, 32000, deep, thought
        )
        val o = parse(raw)
        addHistory(dir, "u", instruction)
        if (o.isEmpty) {
            val msg = o.notes.ifBlank { "Koi badlav nahi hua. Request thori aur saaf likhein." }
            addHistory(dir, "a", msg)
            return msg
        }
        val failed = ArrayList<String>()
        val changedFiles = apply(dir, o, failed)
        if (failed.isNotEmpty()) {
            note("A few edits did not match, redoing those files in full...")
            try {
                val raw2 = gen(
                    ctx, SYSTEM + REVISE_FULL + FORMAT,
                    "CURRENT PROJECT:\n" + dump(readFiles(dir)) + "\n\nUSER REQUEST: " + instruction +
                        "\n\nEdits for these files could not be applied: " + failed.distinct().joinToString(", ") +
                        ". Finish the unfinished part of the request for them and output each of those files in FULL as === FILE: blocks.",
                    32000, deep, thought
                )
                apply(dir, parse(raw2))
            } catch (e: Exception) {}
        }
        var msg = o.notes.ifBlank { "Update ho gaya: " + changedFiles + " file(s)." }
        if (deep && !stale()) {
            try {
                note("Re-checking the change...")
                val n = reviewPass(ctx, dir, "Check that the user's request is fully satisfied: " + instruction, deep, thought)
                if (n > 0) msg += "\n(Review: " + n + " file fix(es) applied.)"
            } catch (e: Exception) {}
        }
        try {
            val n = runAndFix(ctx, dir, deep, thought, note)
            if (n > 0) msg += "\n(Run check: " + n + " file fix(es) applied.)"
        } catch (e: Exception) {}
        addHistory(dir, "a", msg)
        return msg
    }

    /** Answers a coding question; the project (if any) is given as context. */
    fun ask(ctx: Context, dir: File?, question: String, deep: Boolean = false, thought: (String) -> Unit = {}): String {
        enter()
        val sb = StringBuilder()
        if (dir != null) {
            sb.append("PROJECT FILES:\n").append(dump(readFiles(dir), 90000)).append("\n")
            val hist = history(dir).takeLast(6).joinToString("\n") { (if (it.first == "u") "USER: " else "ASSISTANT: ") + it.second.take(500) }
            if (hist.isNotBlank()) sb.append("RECENT CHAT:\n").append(hist).append("\n\n")
        }
        sb.append("QUESTION: ").append(question)
        val ans = gen(ctx, ASK_SYS, sb.toString(), 8000, deep, thought)
        if (dir != null) { addHistory(dir, "u", question); addHistory(dir, "a", ans) }
        return ans.ifBlank { "Jawab nahi mila, dobara poochein." }
    }

    // ---------- entry points for the voice assistant ----------

    fun buildAndOpen(ctx: Context, task: String, language: String, review: Boolean): String {
        return try {
            val (dir, notes) = build(ctx, task, language, review, deepDefault(ctx)) {}
            open(ctx, dir)
            "Project '" + name(dir) + "' ban gaya (" + readFiles(dir).size + " files) aur Code Studio mein khol diya. " + notes.take(300)
        } catch (e: Exception) {
            "Code nahi ban saka: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    fun editLatest(ctx: Context, instruction: String): String {
        val dir = latest(ctx) ?: return "Abhi koi project nahi hai. Pehle write_code se banayein."
        return try {
            val msg = revise(ctx, dir, instruction, deepDefault(ctx)) {}
            open(ctx, dir)
            "Project '" + name(dir) + "' update ho gaya. " + msg.take(300)
        } catch (e: Exception) {
            "Badlav nahi ho saka: " + (e.message ?: e.javaClass.simpleName)
        }
    }
}
