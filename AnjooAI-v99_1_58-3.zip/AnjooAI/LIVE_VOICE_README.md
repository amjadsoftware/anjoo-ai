# Anjoo 77.3 — Live Voice

## Naya kya hai

Live mode mic se audio ko chhote chunks mein Gemini Live API tak bhejta hai; alag speech-to-text, agent aur text-to-speech requests ki lambi chain ki jagah jawab audio stream hota hai. Baat karte hue AI ke bolne ke darmiyan user bole to server interruption signal bhejta hai aur app queued audio rok kar sunna jaari rakhti hai. Existing Anjoo phone actions Live model ke function calls se chalte hain. Call/SMS jaisi sensitive actions par pehle purani spoken confirmation zaroor hoti hai.

## Chalanay se pehle

- Gemini API key app mein configured honi chahiye, aur us key ko Live API model `gemini-3.8-live` ka access milna chahiye.
- Internet aur microphone permission lazmi hain. Live audio Google Gemini API ko stream hoti hai; is mode ko use karne par audio remote service tak jati hai.
- App ko foreground voice service ke taur par chalayein. Android battery restrictions ya mic policy ke mutabiq background behavior device-wise farq kar sakta hai.
- Voice settings mein `Gemini Live` select karein. Purani `Google speech` aur `Always-on Gemini STT` choices bhi maujood hain.

## Agar connect na ho

Live connection/model/API-key/audio setup fail ho to app visible error ke saath Google speech mode par fallback karke engine preference update karti hai. API key/model access aur internet check karein; baad mein settings se Gemini Live dobara select kar sakte hain. Continuous Live streaming API usage/quota use kar sakti hai.

## Test checklist

1. Service start karke pehle chhota sawal poochein; status `Live sun raha hoon` aana chahiye.
2. Assistant ke jawab ke beech mein apna jumla bol kar dekhein—purana jawab rukna aur naya input sunna chahiye.
3. Ek normal phone action test karein. Call ya SMS ke liye “haan” ke baghair action nahi chalna chahiye.
4. Screen-reading action test ke liye accessibility/screen permission ki existing settings zaroori ho sakti hain.
5. Agar echo aaye to speaker volume kam karke ya headset ke saath test karein; device ke echo-cancellation hardware ka asar mukhtalif ho sakta hai.

Is source archive mein Android SDK/Gradle ke baghair APK build nahi ki gayi. Installable APK banane ke liye Android Studio/SDK ke saath project build karna hoga.
