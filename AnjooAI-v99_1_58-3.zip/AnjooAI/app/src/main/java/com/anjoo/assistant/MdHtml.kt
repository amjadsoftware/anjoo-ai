package com.anjoo.assistant

/**
 * Turns Markdown into clean, styled HTML for documents and reports (headings, lists, task lists, tables, quotes,
 * code blocks, links, images, bold/italic/strike). Raw HTML in the text is escaped, and javascript: links are removed.
 * The page it produces looks good on a phone, follows light/dark mode, and prints cleanly (Save as PDF).
 */
object MdHtml {

    fun esc(s: String): String = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun safeUrl(u: String): String =
        if (Regex("^\\s*(javascript|vbscript|data:text)", RegexOption.IGNORE_CASE).containsMatchIn(u)) "#" else u.replace("\"", "%22")

    private fun inline(raw: String): String {
        val codes = ArrayList<String>()
        var s = Regex("`([^`]+)`").replace(raw) { m ->
            codes.add("<code>" + esc(m.groupValues[1]) + "</code>")
            "\u0000" + (codes.size - 1) + "\u0000"
        }
        s = esc(s)
        s = Regex("!\\[([^\\]]*)\\]\\(([^)\\s]+)\\)").replace(s) { m ->
            "<img alt=\"" + m.groupValues[1] + "\" src=\"" + safeUrl(m.groupValues[2]) + "\">"
        }
        s = Regex("\\[([^\\]]+)\\]\\(([^)\\s]+)\\)").replace(s) { m ->
            "<a href=\"" + safeUrl(m.groupValues[2]) + "\">" + m.groupValues[1] + "</a>"
        }
        s = Regex("\\*\\*(.+?)\\*\\*").replace(s, "<strong>\$1</strong>")
        s = Regex("(?<![A-Za-z0-9])__(.+?)__(?![A-Za-z0-9])").replace(s, "<strong>\$1</strong>")
        s = Regex("\\*(?!\\s)(.+?)(?<!\\s)\\*").replace(s, "<em>\$1</em>")
        s = Regex("(?<![A-Za-z0-9])_(?!\\s)(.+?)(?<!\\s)_(?![A-Za-z0-9])").replace(s, "<em>\$1</em>")
        s = Regex("~~(.+?)~~").replace(s, "<del>\$1</del>")
        s = Regex("(?<![\"'>=/])\\bhttps?://[^\\s<]+").replace(s) { m ->
            var u = m.value
            var tail = ""
            while (u.isNotEmpty() && u.last() in ".,;:!?)") { tail = u.last() + tail; u = u.dropLast(1) }
            "<a href=\"" + safeUrl(u) + "\">" + u + "</a>" + tail
        }
        s = Regex("\u0000(\\d+)\u0000").replace(s) { m -> codes.getOrElse(m.groupValues[1].toInt()) { "" } }
        return s
    }

    private class Li(val indent: Int, val ordered: Boolean, val text: String)

    private val LI = Regex("^(\\s*)([-*+]|\\d+[.)])\\s+(.*)$")
    private val HR = Regex("^\\s{0,3}([-*_])(\\s*\\1){2,}\\s*$")
    private val TABLE_SEP = Regex("^\\s*\\|?\\s*:?-+:?\\s*(\\|\\s*:?-+:?\\s*)*\\|?\\s*$")

    private fun isSep(l: String): Boolean = l.contains("|") && TABLE_SEP.matches(l)

    private fun indentOf(ws: String) = ws.replace("\t", "    ").length

    private fun task(t: String): String {
        val m = Regex("^\\[( |x|X)\\]\\s+(.*)$").find(t) ?: return inline(t)
        val on = m.groupValues[1] != " "
        return "<input type=\"checkbox\" disabled" + (if (on) " checked" else "") + "> " + inline(m.groupValues[2])
    }

    private fun renderItems(items: List<Li>, pos: IntArray, indent: Int): String {
        val ordered = items[pos[0]].ordered
        val sb = StringBuilder(if (ordered) "<ol>" else "<ul>")
        while (pos[0] < items.size && items[pos[0]].indent >= indent) {
            val cur = items[pos[0]]
            if (cur.indent > indent) { sb.append(renderItems(items, pos, cur.indent)); continue }
            pos[0]++
            sb.append("<li>").append(task(cur.text))
            if (pos[0] < items.size && items[pos[0]].indent > indent) sb.append(renderItems(items, pos, items[pos[0]].indent))
            sb.append("</li>")
        }
        sb.append(if (ordered) "</ol>" else "</ul>")
        return sb.toString()
    }

    private fun cells(line: String): List<String> {
        var t = line.trim()
        if (t.startsWith("|")) t = t.substring(1)
        if (t.endsWith("|")) t = t.dropLast(1)
        return t.split("|").map { it.trim() }
    }

    private fun startsBlock(l: String): Boolean =
        l.isBlank() || l.trimStart().startsWith("```") || Regex("^\\s{0,3}#{1,6}\\s").containsMatchIn(l) ||
            LI.containsMatchIn(l) || l.trimStart().startsWith(">") || HR.containsMatchIn(l)

    /** Markdown body to HTML (no page around it). */
    fun render(md: String): String {
        val lines = md.replace("\r\n", "\n").replace("\r", "\n").split("\n")
        val out = StringBuilder()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            if (line.isBlank()) { i++; continue }

            val fence = Regex("^\\s*```\\s*([\\w+#.-]*)").find(line)
            if (fence != null) {
                val lang = fence.groupValues[1]
                val buf = StringBuilder()
                i++
                while (i < lines.size && !lines[i].trimStart().startsWith("```")) { buf.append(lines[i]).append('\n'); i++ }
                i++
                out.append("<pre><code").append(if (lang.isNotEmpty()) " class=\"language-" + esc(lang) + "\"" else "").append(">")
                    .append(esc(buf.toString().trimEnd('\n'))).append("</code></pre>\n")
                continue
            }
            val h = Regex("^\\s{0,3}(#{1,6})\\s+(.*?)\\s*#*\\s*$").find(line)
            if (h != null) {
                val n = h.groupValues[1].length
                out.append("<h").append(n).append(">").append(inline(h.groupValues[2])).append("</h").append(n).append(">\n")
                i++; continue
            }
            if (HR.containsMatchIn(line)) { out.append("<hr>\n"); i++; continue }
            if (line.trimStart().startsWith(">")) {
                val buf = ArrayList<String>()
                while (i < lines.size && lines[i].trimStart().startsWith(">")) { buf.add(lines[i].trimStart().removePrefix(">").removePrefix(" ")); i++ }
                out.append("<blockquote>").append(render(buf.joinToString("\n"))).append("</blockquote>\n")
                continue
            }
            if (line.contains("|") && i + 1 < lines.size && isSep(lines[i + 1])) {
                val head = cells(line)
                val aligns = cells(lines[i + 1]).map { c ->
                    val l = c.startsWith(":"); val r = c.endsWith(":")
                    if (l && r) "center" else if (r) "right" else if (l) "left" else ""
                }
                i += 2
                val sb = StringBuilder("<div class=\"tw\"><table><thead><tr>")
                for ((k, c) in head.withIndex()) {
                    sb.append("<th").append(if (aligns.getOrElse(k) { "" }.isNotEmpty()) " style=\"text-align:" + aligns[k] + "\"" else "").append(">").append(inline(c)).append("</th>")
                }
                sb.append("</tr></thead><tbody>")
                while (i < lines.size && lines[i].contains("|") && lines[i].isNotBlank()) {
                    val row = cells(lines[i])
                    sb.append("<tr>")
                    for (k in head.indices) {
                        sb.append("<td").append(if (aligns.getOrElse(k) { "" }.isNotEmpty()) " style=\"text-align:" + aligns[k] + "\"" else "").append(">")
                            .append(inline(row.getOrElse(k) { "" })).append("</td>")
                    }
                    sb.append("</tr>")
                    i++
                }
                sb.append("</tbody></table></div>\n")
                out.append(sb)
                continue
            }
            if (LI.containsMatchIn(line)) {
                val items = ArrayList<Li>()
                while (i < lines.size) {
                    val m = LI.find(lines[i])
                    if (m != null) { items.add(Li(indentOf(m.groupValues[1]), m.groupValues[2][0].isDigit(), m.groupValues[3])); i++ }
                    else if (lines[i].isNotBlank() && lines[i].startsWith(" ") && items.isNotEmpty()) {
                        val last = items.removeAt(items.size - 1)
                        items.add(Li(last.indent, last.ordered, last.text + " " + lines[i].trim())); i++
                    } else break
                }
                val pos = intArrayOf(0)
                while (pos[0] < items.size) out.append(renderItems(items, pos, items[pos[0]].indent)).append('\n')
                continue
            }
            val buf = ArrayList<String>()
            while (i < lines.size && !startsBlock(lines[i]) && !(lines[i].contains("|") && i + 1 < lines.size && isSep(lines[i + 1]))) { buf.add(lines[i]); i++ }
            if (buf.isEmpty()) { buf.add(line); i++ }
            val text = buf.joinToString("\n") { it.trimEnd().let { t -> if (it.endsWith("  ")) "$t\u0001" else t } }
            out.append("<p>").append(inline(text.replace("\u0001\n", "\u0001")).replace("\u0001", "<br>").replace("\n", " ")).append("</p>\n")
        }
        return out.toString()
    }

    private const val CSS = """
:root{color-scheme:light dark;--bg:#ffffff;--ink:#1d2430;--muted:#5d6b7c;--line:#dfe5ec;--soft:#f4f6f9;--accent:#0b6bcb}
@media (prefers-color-scheme: dark){:root{--bg:#0f141a;--ink:#e6ebf1;--muted:#9aa7b6;--line:#2a3441;--soft:#171e27;--accent:#6db3ff}}
*{box-sizing:border-box}
html{-webkit-text-size-adjust:100%}
body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.65 -apple-system,"Segoe UI",Roboto,"Noto Sans","Noto Nastaliq Urdu",Arial,sans-serif}
main{max-width:780px;margin:0 auto;padding:24px 18px 64px}
h1,h2,h3,h4,h5,h6{line-height:1.25;margin:1.6em 0 .5em;font-weight:700}
h1{font-size:1.9em;margin-top:.4em;padding-bottom:.3em;border-bottom:1px solid var(--line)}
h2{font-size:1.45em;padding-bottom:.2em;border-bottom:1px solid var(--line)}
h3{font-size:1.2em}
p{margin:.8em 0}
a{color:var(--accent)}
ul,ol{padding-left:1.4em}li{margin:.25em 0}
li>input[type=checkbox]{margin-right:.4em}
blockquote{margin:1em 0;padding:.2em 1em;border-left:4px solid var(--accent);background:var(--soft);color:var(--muted);border-radius:0 8px 8px 0}
code{font:.9em ui-monospace,Menlo,Consolas,monospace;background:var(--soft);padding:.12em .35em;border-radius:5px}
pre{background:var(--soft);border:1px solid var(--line);border-radius:10px;padding:12px 14px;overflow:auto}
pre code{background:none;padding:0}
hr{border:0;border-top:1px solid var(--line);margin:1.8em 0}
img{max-width:100%;height:auto;border-radius:8px}
.tw{overflow-x:auto;margin:1em 0}
table{border-collapse:collapse;width:100%;font-size:.95em}
th,td{border:1px solid var(--line);padding:8px 10px;text-align:left;vertical-align:top}
th{background:var(--soft)}
@media print{:root{--bg:#fff;--ink:#000;--muted:#333;--line:#bbb;--soft:#f3f3f3;--accent:#000}main{max-width:none;padding:0}pre,table,blockquote,img{break-inside:avoid}h1,h2,h3{break-after:avoid}a{text-decoration:none}}
"""

    /** A complete standalone HTML page around the rendered document. */
    fun page(title: String, bodyHtml: String): String =
        "<!doctype html>\n<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">" +
            "<title>" + esc(title) + "</title><style>" + CSS + "</style></head><body><main>\n" + bodyHtml + "\n</main></body></html>"

    /** The same document as a Word-friendly .doc file (HTML that Microsoft Word / Google Docs / LibreOffice open). */
    fun wordDoc(title: String, bodyHtml: String): String =
        "<html xmlns:o=\"urn:schemas-microsoft-com:office:office\" xmlns:w=\"urn:schemas-microsoft-com:office:word\" xmlns=\"http://www.w3.org/TR/REC-html40\">" +
            "<head><meta charset=\"utf-8\"><title>" + esc(title) + "</title><style>" +
            "body{font-family:Calibri,Arial,sans-serif;font-size:11pt;line-height:1.45}h1{font-size:20pt}h2{font-size:15pt}h3{font-size:12.5pt}" +
            "table{border-collapse:collapse}th,td{border:1px solid #999;padding:4pt 6pt}th{background:#eeeeee}" +
            "pre,code{font-family:Consolas,monospace;font-size:10pt}pre{background:#f3f3f3;padding:6pt}blockquote{border-left:3pt solid #888;margin-left:0;padding-left:10pt;color:#444}" +
            "</style></head><body>\n" + bodyHtml + "\n</body></html>"
}
