package com.anjoo.assistant

import android.net.Uri
import android.util.Base64
import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream

/**
 * Serves a project's files to the preview browser as https://app.local/ so big websites behave like they do on a real server:
 * pages in sub-folders, absolute paths (/app.js), single-page apps and common folders (public, dist, client...) all work.
 */
object PreviewServer {

    fun mime(n: String): String = when (n.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "css" -> "text/css"
        "js", "mjs" -> "application/javascript"
        "json", "map" -> "application/json"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        "ico" -> "image/x-icon"
        "woff" -> "font/woff"
        "woff2" -> "font/woff2"
        "ttf" -> "font/ttf"
        "otf" -> "font/otf"
        "mp3" -> "audio/mpeg"
        "wav" -> "audio/wav"
        "ogg" -> "audio/ogg"
        "mp4" -> "video/mp4"
        "webm" -> "video/webm"
        "pdf" -> "application/pdf"
        "xml" -> "text/xml"
        "wasm" -> "application/wasm"
        else -> "text/plain"
    }

    /**
     * Every project gets its OWN web address (https://p1a2b3c.app.local/). A browser keeps localStorage and IndexedDB per
     * address, so each app has its own private data on the phone, apps never mix their data, and the data is still there
     * the next time the app is opened.
     */
    fun origin(dir: File): String = "https://p" + Integer.toHexString(dir.name.hashCode()) + ".app.local/"

    /** All pages of the project, main page first (shallowest folder, index.html before others). */
    fun pages(dir: File): List<String> {
        val out = ArrayList<String>()
        try {
            dir.walkTopDown().onEnter { it == dir || (it.name != "node_modules" && !it.name.startsWith(".")) }.forEach { f ->
                if (f.isFile && (f.extension.equals("html", true) || f.extension.equals("htm", true)))
                    out.add(f.relativeTo(dir).path.replace('\\', '/'))
            }
        } catch (e: Exception) {}
        return out.sortedWith(compareBy({ it.count { c -> c == '/' } }, { if (it.substringAfterLast('/') == "index.html") 0 else 1 }, { it }))
    }

    fun entry(dir: File): String? = pages(dir).firstOrNull()

    private fun inside(base: File, f: File) = try { f.canonicalPath.startsWith(base.canonicalPath) } catch (e: Exception) { false }

    private fun resp(f: File): WebResourceResponse {
        val m = mime(f.name)
        val enc = if (m.startsWith("text/") || m.contains("javascript") || m.contains("json") || m.contains("xml")) "UTF-8" else null
        return WebResourceResponse(m, enc, 200, "OK",
            mapOf("Access-Control-Allow-Origin" to "*", "Cache-Control" to "no-cache"), FileInputStream(f))
    }

    private val FOLDERS = listOf("public", "static", "dist", "build", "client", "src", "assets", "www", "web")

    /** Returns the response for one request to app.local, or null for other hosts. [onMissing] hears about files that do not exist. */
    fun serve(base: File, u: Uri, onMissing: (String) -> Unit = {}): WebResourceResponse? {
        val host = u.host ?: return null
        if (host != "app.local" && !host.endsWith(".app.local")) return null
        val entry = entry(base)
        var rel = Uri.decode((u.path ?: "").trimStart('/'))
        if (rel.isEmpty() && entry != null) rel = entry
        val root = if (entry != null && entry.contains('/')) File(base, entry.substringBeforeLast('/')) else base
        val cands = ArrayList<File>()
        cands.add(File(root, rel)); cands.add(File(base, rel))
        for (fo in FOLDERS) cands.add(File(base, "$fo/$rel"))
        val hit = cands.firstOrNull { it.isFile && inside(base, it) }
        if (hit != null) return try { resp(hit) } catch (e: Exception) { null }
        // single-page apps: a path without a file extension gets the main page
        if (entry != null && !rel.substringAfterLast('/').contains('.')) {
            val main = File(base, entry)
            if (main.isFile) return try { resp(main) } catch (e: Exception) { null }
        }
        onMissing(rel)
        return WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
    }

    /** The whole website as ONE html file (css, scripts and small images inside) that opens in any browser. */
    fun inline(dir: File): String? {
        val entry = entry(dir) ?: return null
        val root = if (entry.contains('/')) File(dir, entry.substringBeforeLast('/')) else dir
        var html = File(dir, entry).readText(Charsets.UTF_8)
        fun find(ref: String): File? {
            if (ref.startsWith("http") || ref.startsWith("//") || ref.startsWith("data:")) return null
            val r = ref.substringBefore('?').substringBefore('#').trimStart('/')
            if (r.isEmpty()) return null
            return listOf(File(root, r), File(dir, r)).firstOrNull { it.isFile && inside(dir, it) }
        }
        html = Regex("<link\\b[^>]*rel\\s*=\\s*[\"']stylesheet[\"'][^>]*>", RegexOption.IGNORE_CASE).replace(html) { m ->
            val href = Regex("href\\s*=\\s*[\"']([^\"']+)[\"']", RegexOption.IGNORE_CASE).find(m.value)?.groupValues?.get(1)
            val f = href?.let { find(it) }
            if (f != null) "<style>\n" + f.readText(Charsets.UTF_8) + "\n</style>" else m.value
        }
        html = Regex("<script\\b([^>]*?)\\bsrc\\s*=\\s*[\"']([^\"']+)[\"']([^>]*)>\\s*</script>", RegexOption.IGNORE_CASE).replace(html) { m ->
            val f = find(m.groupValues[2])
            if (f != null) {
                val attrs = (m.groupValues[1] + " " + m.groupValues[3]).trim()
                "<script" + (if (attrs.isEmpty()) "" else " $attrs") + ">\n" + f.readText(Charsets.UTF_8).replace("</script", "<\\/script") + "\n</script>"
            } else m.value
        }
        html = Regex("(<img\\b[^>]*\\bsrc\\s*=\\s*[\"'])([^\"']+)([\"'])", RegexOption.IGNORE_CASE).replace(html) { m ->
            val f = find(m.groupValues[2])
            if (f != null && f.length() <= 400_000)
                m.groupValues[1] + "data:" + mime(f.name) + ";base64," + Base64.encodeToString(f.readBytes(), Base64.NO_WRAP) + m.groupValues[3]
            else m.value
        }
        return html
    }
}
