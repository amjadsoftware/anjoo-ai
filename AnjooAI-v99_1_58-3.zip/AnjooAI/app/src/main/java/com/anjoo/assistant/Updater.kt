package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.widget.LinearLayout
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * In-app updater. GitHub Actions publishes every build as a GitHub Release ("build-<versionCode>" with AnjooAI.apk).
 * The app asks the Releases API for the latest one, and if its versionCode is higher it offers the update,
 * downloads the APK and hands it to Android's installer. Same package + same keystore = installs over the old app,
 * no uninstall needed. After the install, UpdatedReceiver opens the app again.
 */
object Updater {
    private const val ACTION_RESULT = "com.anjoo.assistant.UPDATE_RESULT"
    private val ui = Handler(Looper.getMainLooper())
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    private var checkedThisRun = false

    class Info(val code: Long, val name: String, val notes: String, val url: String)

    /** "99_1_50", "v99.1.50" or "AnjooAI-v99_1_50_x" -> 99001050, so versions compare as numbers. */
    private fun ver(s: String): Long? {
        val m = Regex("""(\d+)[._](\d+)[._](\d+)""").find(s) ?: return null
        val (a, b, c) = m.destructured
        return a.toLong() * 1_000_000 + b.toLong() * 1_000 + c.toLong()
    }

    /** Version of the installed app (from its versionName, e.g. 99.1.50). */
    fun currentCode(ctx: Context): Long = ver(BuildConfig.VERSION_NAME) ?: 0L

    /** Returns the latest release, or null if there is none / no internet / repo unknown. */
    private fun fetchLatest(): Info? {
        val repo = BuildConfig.UPDATE_REPO
        if (repo.isBlank()) return null
        val req = Request.Builder().url("https://api.github.com/repos/$repo/releases/latest")
            .header("Accept", "application/vnd.github+json").build()
        http.newCall(req).execute().use { r ->
            if (!r.isSuccessful) return null
            val j = JSONObject(r.body?.string() ?: return null)
            val name = j.optString("name")
            val code = ver(j.optString("tag_name")) ?: ver(name) ?: return null
            val assets = j.optJSONArray("assets") ?: return null
            var url = ""; var fallback = ""
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                val n = a.optString("name")
                if (!n.endsWith(".apk")) continue
                if (fallback.isEmpty()) fallback = a.optString("browser_download_url")
                if (!n.contains("debug", true)) { url = a.optString("browser_download_url"); break }
            }
            if (url.isEmpty()) url = fallback
            if (url.isEmpty()) return null
            return Info(code, name, j.optString("body").trim(), url)
        }
    }

    /** Silent check on app start (once per process). Shows the update screen only if something new exists. */
    fun checkOnLaunch(act: Activity) {
        if (checkedThisRun) return
        checkedThisRun = true
        Thread {
            val info = try { fetchLatest() } catch (e: Exception) { null }
            if (info != null && info.code > currentCode(act)) ui.post { offer(act, info) }
        }.start()
    }

    /** Manual "Update your app" button. */
    fun checkNow(act: Activity) {
        Toast.makeText(act, "Update check ho raha hai...", Toast.LENGTH_SHORT).show()
        Thread {
            val info = try { fetchLatest() } catch (e: Exception) { null }
            ui.post {
                when {
                    info == null -> Toast.makeText(act, "Update check nahi ho saka (internet ya GitHub Release check karo).", Toast.LENGTH_LONG).show()
                    info.code > currentCode(act) -> offer(act, info)
                    else -> Toast.makeText(act, "Aap latest version par hain.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun offer(act: Activity, info: Info) {
        if (act.isFinishing || act.isDestroyed) return
        val notes = if (info.notes.isNotBlank() && info.notes.length < 400) "\n\n" + info.notes else ""
        AlertDialog.Builder(act).setTitle("Naya update aya hai")
            .setMessage((if (info.name.isNotBlank()) info.name else "Anjoo AI ka naya version") +
                "\n\nUpdate ke baad app khud dobara khul jayegi." + notes)
            .setPositiveButton("Update") { _, _ -> start(act, info) }
            .setNegativeButton("Baad mein", null)
            .show()
    }

    private fun start(act: Activity, info: Info) {
        if (!act.packageManager.canRequestPackageInstalls()) {
            Toast.makeText(act, "Pehle 'Allow from this source' on karo, phir wapas aa kar Update dabao.", Toast.LENGTH_LONG).show()
            act.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + act.packageName)))
            return
        }
        val bar = ProgressBar(act, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100 }
        val label = TextView(act).apply { text = "Download ho raha hai..."; setPadding(0, 0, 0, 24) }
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL; setPadding(60, 40, 60, 20)
            addView(label); addView(bar)
        }
        val dlg = AlertDialog.Builder(act).setTitle("Updating").setView(box).setCancelable(false).create()
        dlg.show()
        Thread {
            try {
                val dir = File(act.cacheDir, "update").apply { mkdirs() }
                val f = File(dir, "AnjooAI.apk")
                http.newCall(Request.Builder().url(info.url).build()).execute().use { r ->
                    if (!r.isSuccessful) throw RuntimeException("HTTP " + r.code)
                    val body = r.body ?: throw RuntimeException("empty")
                    val total = body.contentLength()
                    var done = 0L
                    body.byteStream().use { i ->
                        f.outputStream().use { o ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val n = i.read(buf); if (n < 0) break
                                o.write(buf, 0, n); done += n
                                if (total > 0) ui.post { bar.progress = (done * 100 / total).toInt() }
                            }
                        }
                    }
                }
                ui.post { label.text = "Install ho raha hai..."; bar.progress = 100 }
                install(act, f)
                ui.post { try { dlg.dismiss() } catch (e: Exception) {} }
            } catch (e: Exception) {
                ui.post {
                    try { dlg.dismiss() } catch (x: Exception) {}
                    Toast.makeText(act, "Update fail: " + (e.message ?: "error"), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun install(ctx: Context, apk: File) {
        val pi = ctx.packageManager.packageInstaller
        val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
        pi.openSession(id).use { s ->
            apk.inputStream().use { i ->
                s.openWrite("anjoo", 0, apk.length()).use { o -> i.copyTo(o); s.fsync(o) }
            }
            val intent = Intent(ctx, InstallResultReceiver::class.java).setAction(ACTION_RESULT)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            s.commit(PendingIntent.getBroadcast(ctx, id, intent, flags).intentSender)
        }
    }
}

/** Receives the installer's answer: shows Android's "Update?" screen, or reports a failure. */
class InstallResultReceiver : BroadcastReceiver() {
    @Suppress("DEPRECATION")
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT) ?: return
                confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try { c.startActivity(confirm) } catch (e: Exception) {}
            }
            PackageInstaller.STATUS_SUCCESS -> {}
            else -> Toast.makeText(c, "Update install nahi hua: " + (i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""),
                Toast.LENGTH_LONG).show()
        }
    }
}

/** Runs inside the NEW version right after an update: cleans up and opens the app again. */
class UpdatedReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        try { File(c.cacheDir, "update").deleteRecursively() } catch (e: Exception) {}
        val launch = c.packageManager.getLaunchIntentForPackage(c.packageName) ?: return
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        // Android only lets a background app open a screen if it has "Display over other apps".
        if (Settings.canDrawOverlays(c)) {
            try { c.startActivity(launch); return } catch (e: Exception) {}
        }
        // Fallback: a tap-to-open notification.
        try {
            val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
                NotificationChannel("update", "App update", NotificationManager.IMPORTANCE_HIGH))
            val pi = PendingIntent.getActivity(c, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val b = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(c, "update")
                    else android.app.Notification.Builder(c)
            nm.notify(7701, b.setSmallIcon(c.applicationInfo.icon).setContentTitle("Anjoo AI update ho gaya")
                .setContentText("Kholne ke liye tap karo").setContentIntent(pi).setAutoCancel(true).build())
        } catch (e: Exception) {}
    }
}
