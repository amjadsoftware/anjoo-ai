package com.anjoo.assistant

import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.EditText
import kotlin.math.abs

/**
 * Instant press feedback for every tappable view, with no per-button code.
 *
 * Called from dispatchTouchEvent, so the view reacts on the very first touch (ACTION_DOWN), before the click is
 * even registered. It finds the tappable view under the finger, shrinks and dims it for a moment, and springs it
 * back on release, on cancel, or as soon as the finger starts to scroll. Large containers (chat bubbles, cards)
 * are skipped so scrolling a list never makes the whole screen flicker.
 */
object Touch {
    private var target: View? = null
    private var baseAlpha = 1f
    private var downX = 0f
    private var downY = 0f
    private val loc = IntArray(2)

    fun feedback(root: View, e: MotionEvent) {
        try {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    release()
                    val v = hit(root, e.rawX, e.rawY) ?: return
                    target = v; baseAlpha = v.alpha; downX = e.rawX; downY = e.rawY
                    v.animate().cancel()
                    v.animate().scaleX(0.93f).scaleY(0.93f).alpha(baseAlpha * 0.7f).setDuration(60).start()
                }
                MotionEvent.ACTION_MOVE -> {
                    val t = target ?: return
                    val slop = ViewConfiguration.get(t.context).scaledTouchSlop
                    if (abs(e.rawX - downX) > slop || abs(e.rawY - downY) > slop) release()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_DOWN -> release()
            }
        } catch (ex: Exception) { target = null }
    }

    private fun release() {
        val t = target ?: return
        target = null
        t.animate().cancel()
        t.animate().scaleX(1f).scaleY(1f).alpha(baseAlpha).setDuration(110).start()
    }

    /** Top-most visible, enabled, tappable view at the given screen point (deepest one wins). */
    private fun hit(v: View, x: Float, y: Float): View? {
        if (v.visibility != View.VISIBLE) return null
        v.getLocationOnScreen(loc)
        if (x < loc[0] || x > loc[0] + v.width || y < loc[1] || y > loc[1] + v.height) return null
        if (v is ViewGroup) {
            for (i in v.childCount - 1 downTo 0) {
                val r = hit(v.getChildAt(i), x, y)
                if (r != null) return r
            }
        }
        if (v is EditText || !v.isClickable || !v.isEnabled) return null
        val d = v.resources.displayMetrics.density
        // Big containers (message bubbles, cards, full-width bars) should not shrink under the finger.
        if (v.height > 96 * d || (v.width > 300 * d && v.height > 64 * d)) return null
        return v
    }
}
