package com.anjoo.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import java.util.Random

/** Falling "matrix rain" background. Purely decorative. */
class RainView(ctx: Context, private var color: Int) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
    private val rnd = Random()
    private val chars = "01ABCDEF<>/{}#\$%&*+=ANJOOアイウエオカキクケコ".toCharArray()
    private var drops = IntArray(0)
    private var cell = 0f
    private var running = false

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            step()
            invalidate()
            postDelayed(this, 90)
        }
    }

    fun setAccent(c: Int) { color = c }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cell = 15f * resources.displayMetrics.density
        paint.textSize = cell
        drops = IntArray(maxOf(1, (w / cell).toInt())) { -rnd.nextInt(40) }
    }

    private fun step() {
        for (i in drops.indices) {
            drops[i]++
            if (drops[i] * cell > height + 12 * cell && rnd.nextFloat() > 0.93f) {
                drops[i] = -rnd.nextInt(20)
            }
        }
    }

    override fun onDraw(c: Canvas) {
        paint.color = color
        for (i in drops.indices) {
            for (k in 0..11) {
                val row = drops[i] - k
                if (row < 0) continue
                val y = row * cell
                if (y > height + cell) continue
                paint.alpha = if (k == 0) 130 else maxOf(8, 80 - k * 7)
                c.drawText(chars[rnd.nextInt(chars.size)].toString(), i * cell, y, paint)
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        post(tick)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
