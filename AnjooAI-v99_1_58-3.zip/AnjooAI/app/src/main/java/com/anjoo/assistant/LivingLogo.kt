package com.anjoo.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.Choreographer
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

/**
 * The Anjoo logo as a living, faceless creature in Claude orange. With no background it drifts through
 * 27 forms on its own (feelings, animals, things, human moves) and never shows what it is acting.
 * It only animates while it is on screen.
 */
class LivingLogo(ctx: Context) : View(ctx) {
    /** Colour for the little "!" and "z" marks; the host sets it to its muted text colour. */
    var textColor: Int = 0xFF8A8A8A.toInt()

    private val P = Math.PI.toFloat()
    private val CL = 0xFFD97757.toInt()
    private val RED = 0xFFC2410C.toInt()

    private class Leg(val path: Path, val ph: Float, val sp: Float) { var a = 0f; var s = 1f }
    private class Act(
        val cat: Int, val d: Float, val hr: Boolean = false, val col: Int = 0, val ex: String = "",
        val bd: (Float, Float) -> FloatArray = { _, _ -> bd() },
        val lg: (Int, Float, Float) -> FloatArray = { _, _, _ -> lg() }
    )

    private val paths = shapes()

    private val legs = paths.map { Leg(it, (Math.random() * 6.28).toFloat(), (0.8 + Math.random() * 0.6).toFloat()) }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = CL; style = Paint.Style.FILL }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val oval = RectF()

    private val acts: List<Act> = listOf(
        // 0 feelings
        Act(0, 3f, bd = { u, _ -> bd(y = -abs(sin(u * 5f)) * 4f) }, lg = { i, u, _ -> lg(sin(u * 3f + i) * 7f) }),
        Act(0, 3.5f, ex = "drops", bd = { u, _ -> bd(y = 4f, s = 0.94f, r = sin(u) * 1.5f) }, lg = { i, u, _ -> lg(sin(u + i) * 2f, 0.78f) }),
        Act(0, 3f, col = RED, bd = { u, _ -> bd(x = sin(u * 30f) * 0.9f, s = 1.06f) }, lg = { i, u, _ -> lg(sin(u * 8f + i * 2f) * 13f + sin(u * 22f + i * 5f) * 1.6f, 1.12f) }),
        Act(0, 2.6f, ex = "bang", bd = { u, p -> val q = min(p * 3f, 1f); bd(y = -sin(min(p * 4f, 1f) * P) * 10f, s = 1.12f - 0.12f * q) },
            lg = { i, u, p -> val q = min(p * 3f, 1f); lg(sin(u * 10f + i) * 3f * (1f - q), 1.3f - 0.3f * q) }),
        Act(0, 4f, ex = "zz", bd = { u, _ -> bd(s = 1f + sin(u * 1.2f) * 0.05f, r = 6f) }, lg = { i, u, _ -> lg(sin(u + i) * 2f, 0.88f) }),
        Act(0, 3.5f, ex = "hearts", bd = { u, _ -> bd(s = 1f + abs(sin(u * 4f)).pow(6) * 0.12f) }, lg = { i, u, _ -> lg(sin(u * 3f + i) * 5f, 1f + abs(sin(u * 4f)).pow(6) * 0.1f) }),
        Act(0, 2.8f, ex = "sweat", bd = { u, _ -> bd(x = sin(u * 38f) * 1.2f, s = 0.95f) }, lg = { i, u, _ -> lg(sin(u * 30f + i) * 4f, 0.76f) }),
        // 1 animals
        Act(1, 4.5f, bd = { u, _ -> bd(x = sin(u * 1.3f) * 42f, y = -abs(sin(u * 9f)) * 1.8f) }, lg = { i, u, _ -> lg(sin(u * 9f + (i % 2) * P + (i / 4) * 0.9f) * 17f) }),
        Act(1, 4f, bd = { u, _ -> bd(y = sin(u * 2f) * 10f - 4f, s = 1f + sin(u * 4f) * 0.07f) }, lg = { i, u, _ -> lg(sin(u * 4f - i * 0.5f) * 14f, 1f + sin(u * 4f - i * 0.5f) * 0.1f) }),
        Act(1, 4f, bd = { u, _ -> bd(x = sin(u * 0.9f) * 34f, y = -8f + sin(u * 11f) * 3f) }, lg = { i, u, _ ->
            val w = sin(u * 11f) * 35f
            when (i) { in 1..3 -> lg(-w, 1.05f); in 9..11 -> lg(w, 1.05f); else -> lg(0f, 0.75f) }
        }),
        Act(1, 3.5f, bd = { _, p -> bd(s = 1f + 0.28f * sin(p * P)) }, lg = { i, u, p -> lg(sin(u * 20f + i) * 2f, 1f + 0.2f * sin(p * P)) }),
        Act(1, 4f, bd = { u, _ -> bd(x = sin(u * 2f) * 40f, y = -abs(sin(u * 12f)) * 0.8f) }, lg = { i, u, _ ->
            when (i) { 2 -> lg(-(sin(u * 8f) * 14f + 10f), 1.15f); 10 -> lg(sin(u * 8f + P) * 14f + 10f, 1.15f); else -> lg(sin(u * 12f + (i % 2) * P) * 8f, 0.9f) }
        }),
        Act(1, 4.5f, bd = { u, _ -> bd(x = sin(u) * 38f, y = sin(u * 3f) * 4f) }, lg = { i, u, _ ->
            lg(-cos(u) * 12f * (if (i in 4..8) 1.5f else 0.6f) + sin(u * 6f - i * 0.6f) * 8f, 1f + sin(u * 6f - i * 0.6f) * 0.08f)
        }),
        Act(1, 4f, bd = { u, _ -> bd(x = sin(u * 1.2f) * 38f, y = -abs(sin(u * 4f)) * 16f) }, lg = { i, u, _ ->
            when (i) { 11 -> lg(-12f + sin(u * 8f) * 8f, 1.3f); 1 -> lg(12f - sin(u * 8f) * 8f, 1.3f); else -> lg(0f, 0.7f) }
        }),
        // 2 things
        Act(2, 4f, bd = { u, _ -> bd(r = sin(u * 0.8f) * 3f) }, lg = { _, _, p -> lg(0f, 0.5f + 0.55f * ease(min(p * 1.5f, 1f))) }),
        Act(2, 4f, hr = true, bd = { _, p -> bd(r = p * 360f) }, lg = { i, u, _ -> lg(0f, 1f + sin(u * 5f + i) * 0.1f) }),
        Act(2, 3f, hr = true, bd = { _, p -> bd(r = ease(p) * 1080f) }, lg = { _, _, _ -> lg(0f, 1.1f) }),
        Act(2, 3f, ex = "sparks", bd = { _, p ->
            bd(y = if (p < 0.45f) -p / 0.45f * 14f else -14f + (p - 0.45f) * 10f, s = if (p < 0.45f) 0.55f else 1.25f - 0.25f * min((p - 0.45f) * 3f, 1f))
        }, lg = { i, u, p -> lg(if (p < 0.45f) 0f else sin(u * 12f + i) * 6f, if (p < 0.45f) 0.5f else 1.4f - 0.4f * min((p - 0.45f) * 3f, 1f)) }),
        Act(2, 3f, bd = { u, _ -> bd(s = 1f + abs(sin(u * 4f)).pow(8) * 0.3f) }, lg = { _, u, _ -> lg(0f, 1f + abs(sin(u * 4f)).pow(8) * 0.2f) }),
        Act(2, 4f, hr = true, bd = { u, _ -> val v = u * 3f; bd(r = (floor(v) + ease(min((v % 1f) * 2f, 1f))) * 30f) }),
        Act(2, 3.5f, lg = { i, u, _ -> lg(0f, 1f + 0.35f * max(0f, sin(u * 6f - i * 0.8f))) }),
        Act(2, 3f, bd = { u, _ -> bd(r = sin(u * 4f) * 25f) }),
        // 3 human moves
        Act(3, 3.5f, bd = { u, _ -> bd(r = sin(u * 2f) * 1.5f) }, lg = { i, u, _ -> if (i == 2) lg(-(40f + sin(u * 9f) * 25f), 1.1f) else lg(sin(u * 2f + i) * 3f) }),
        Act(3, 4f, bd = { u, _ -> bd(x = sin(u * 3f) * 18f, y = -abs(sin(u * 6f)) * 4f, r = sin(u * 3f) * 12f) }, lg = { i, u, _ -> lg(sin(u * 6f + i * P) * 15f) }),
        Act(3, 4f, bd = { u, _ -> bd(y = -abs(sin(u * 5f)) * 10f) }, lg = { i, u, _ ->
            val w = sin(u * 5f)
            when (i) { in 1..3 -> lg(-(w * 28f + 10f)); in 9..11 -> lg(w * 28f + 10f); 4, 5 -> lg(w * 16f); 7, 8 -> lg(-w * 16f); else -> lg(0f) }
        }),
        Act(3, 3.5f, bd = { u, _ -> bd(y = -abs(sin(u * 8f)) * 2f) }, lg = { i, u, _ ->
            val w = (sin(u * 8f) * 0.5f + 0.5f) * 60f
            when (i) { 3 -> lg(-w - 10f, 1.1f); 9 -> lg(w + 10f, 1.1f); else -> lg(sin(u * 2f + i) * 2f) }
        }),
        Act(3, 3.5f, bd = { u, _ -> bd(s = 1f + sin(u * 4f) * 0.04f) }, lg = { i, u, _ ->
            val w = 0.5f + 0.5f * sin(u * 4f)
            when (i) { 2 -> lg(-35f, 1f + 0.3f * w); 10 -> lg(35f, 1f + 0.3f * w); else -> lg(0f, 0.85f) }
        })
    )

    private var act: Act? = null
    private var last: Act? = null
    private var sT = 0f
    private var nextAct = 0.6f
    private var t0 = 0L
    private var lastNs = 0L
    private var bx = 0f; private var by = 0f; private var bs = 1f; private var rr = 0f
    private var colNow = CL
    private var attached = false
    private var running = false

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (running) { invalidate(); Choreographer.getInstance().postFrameCallback(this) }
        }
    }

    private fun refreshRun() {
        val go = attached && isShown && windowVisibility == VISIBLE
        if (go && !running) {
            running = true; lastNs = 0L
            Choreographer.getInstance().postFrameCallback(frame)
        } else if (!go && running) {
            running = false
            Choreographer.getInstance().removeFrameCallback(frame)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); attached = true; if (t0 == 0L) t0 = System.nanoTime(); refreshRun() }
    override fun onDetachedFromWindow() { attached = false; refreshRun(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changed: View, visibility: Int) { super.onVisibilityChanged(changed, visibility); refreshRun() }
    override fun onWindowVisibilityChanged(visibility: Int) { super.onWindowVisibilityChanged(visibility); refreshRun() }

    private fun pickNext(t: Float) {
        val cat = (Math.random() * 4).toInt()
        val pool = acts.filter { it.cat == cat && it !== last }
        val a = pool[(Math.random() * pool.size).toInt().coerceAtMost(pool.size - 1)]
        act = a; last = a; sT = t
    }

    private fun setColor(c: Int) { if (c != colNow) { colNow = c; fill.color = c } }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val now = System.nanoTime()
        val t = (now - t0) / 1e9f
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1e9f).coerceIn(0.001f, 0.05f)
        lastNs = now
        fun k(g: Float) = 1f - (1f - g).pow(dt * 60f)

        var u = t; var p = 0f
        if (act == null && t > nextAct) pickNext(t)
        act?.let { a ->
            u = t - sT; p = u / a.d
            if (p >= 1f) { act = null; nextAct = t + 0.5f + (Math.random() * 0.5).toFloat(); u = t; p = 0f }
        }
        val a = act
        val b = a?.bd?.invoke(u, p) ?: bd()
        val ty = b[1] + sin(t * 1.6f) * 0.6f
        val ts = b[2] * (1f + sin(t * 1.6f) * 0.025f)
        bx += (b[0] - bx) * k(0.2f); by += (ty - by) * k(0.2f); bs += (ts - bs) * k(0.2f)
        if (a != null && a.hr) rr = b[3] else if (abs(b[3] - rr) < 30f) rr += (b[3] - rr) * k(0.15f) else rr = b[3]
        setColor(if (a != null && a.col != 0) a.col else CL)

        for ((i, x) in legs.withIndex()) {
            val r = a?.lg?.invoke(i, u, p) ?: lg()
            val ta = r[0] + sin(t * 1.4f * x.sp + x.ph) * 1.8f
            val tsc = r[1] * (1f + sin(t * 1.8f + x.ph) * 0.04f)
            x.a += (ta - x.a) * k(0.22f); x.s += (tsc - x.s) * k(0.18f)
        }

        // viewBox is (-60,-20) to (168,108): room to wander sideways and for the little marks
        val sc = min(width / 228f, height / 128f)
        c.save()
        c.translate((width - 228f * sc) / 2f, (height - 128f * sc) / 2f)
        c.scale(sc, sc)
        c.translate(60f, 20f)
        c.translate(bx, by)
        c.save()
        c.rotate(rr, 54f, 54f); c.translate(54f, 54f); c.scale(bs, bs); c.translate(-54f, -54f)
        for (x in legs) {
            c.save()
            c.rotate(x.a, 54f, 54f); c.translate(54f, 54f); c.scale(x.s, x.s); c.translate(-54f, -54f)
            c.drawPath(x.path, fill)
            c.restore()
        }
        c.drawCircle(54f, 54f, 11.5f, fill)
        c.restore()
        drawMarks(c, a?.ex ?: "", u, p)
        c.restore()
    }

    private fun drawMarks(c: Canvas, k: String, u: Float, p: Float) {
        when (k) {
            "zz" -> for (j in 0..2) {
                val r = (u * 8f + j * 5f) % 16f
                mark.color = textColor; mark.alpha = ((1f - r / 16f) * 255).toInt(); mark.textSize = 8f + j * 2f; mark.typeface = Typeface.DEFAULT
                c.drawText("z", 86f + j * 6f, 34f - r, mark)
            }
            "hearts" -> for (j in 0..2) {
                val r = (u * 14f + j * 9f) % 26f
                mark.color = 0xFFE0707A.toInt(); mark.alpha = ((1f - r / 26f) * 255).toInt(); mark.textSize = 9f; mark.typeface = Typeface.DEFAULT
                c.drawText("\u2665", 38f + j * 16f + sin(u * 3f + j) * 3f, 14f - r, mark)
            }
            "drops" -> for (j in 0..2) {
                val r = (u * 26f + j * 13f) % 40f
                drop(c, 24f + j * 30f, 24f + r, 1f - r / 40f)
            }
            "sweat" -> for (j in 0..1) {
                val r = (u * 20f + j * 10f) % 20f
                drop(c, 86f + j * 8f, 20f + r, 1f - r / 20f)
            }
            "bang" -> {
                mark.color = textColor; mark.alpha = 255; mark.textSize = 18f; mark.typeface = Typeface.DEFAULT_BOLD
                c.drawText("!", 54f, 8f - sin(u * 14f) * 1.5f + 6f, mark)
            }
            "sparks" -> if (p > 0.45f) {
                val q = (p - 0.45f) / 0.55f
                for (j in 0..9) {
                    val ang = j * P / 5f
                    fill.color = if (j % 2 == 1) CL else 0xFFF2B84B.toInt()
                    fill.alpha = ((1f - q) * 255).toInt()
                    c.drawCircle(54f + cos(ang) * (18f + q * 48f), 54f + sin(ang) * (18f + q * 48f), 2.4f * (1f - q) + 0.4f, fill)
                }
                fill.color = colNow; fill.alpha = 255
            }
        }
    }

    private fun drop(c: Canvas, x: Float, y: Float, a: Float) {
        fill.color = 0xFF7DC4F0.toInt(); fill.alpha = (a.coerceIn(0f, 1f) * 255).toInt()
        oval.set(x - 1.5f, y - 2.4f, x + 1.5f, y + 2.4f)
        c.drawOval(oval, fill)
        fill.color = colNow; fill.alpha = 255
    }

    companion object {
        private const val DATA = ("M58.26,49.37 L55.25,19.95 Q52.84,16.34 50.66,20.09 L49.46,49.64 Z M59.95,51.94 L68.11,30.87 Q67.69,26.55 63.99,28.81 L52.07,48.01 Z " +
        "M60.05,55.72 L84.1,40.28 Q86.24,36.5 81.91,36.24 L55.86,47.99 Z M58.82,58.05 L79.1,54.43 Q82.6,51.86 78.76,49.84 L58.16,49.28 Z " +
        "M55.66,60.07 L82.18,73.17 Q86.51,73.04 84.5,69.2 L60.11,52.48 Z M52.58,60.13 L66.6,79.11 Q70.48,81.06 70.53,76.72 L60.1,55.55 Z " +
        "M49.96,58.83 L54.17,86.08 Q56.75,89.57 58.76,85.73 L58.73,58.15 Z M47.94,55.69 L38.98,75.35 Q39.13,79.68 42.96,77.65 L55.55,60.1 Z " +
        "M47.8,52.94 L24.71,71.43 Q22.99,75.41 27.33,75.21 L52.8,60.18 Z M49.45,49.65 L24.98,52.04 Q21.32,54.38 25.03,56.64 L49.55,58.45 Z " +
        "M51.85,48.08 L27.06,38.48 Q22.75,38.96 25.07,42.63 L48.04,56.01 Z M55.12,47.81 L41.33,31.18 Q37.36,29.42 37.52,33.76 L47.83,52.74 Z")

        /** The twelve tentacle outlines of the logo (shared with the small thinking mark). */
        internal fun shapes(): List<Path> = DATA.split(" M").mapIndexed { i, s -> parse(if (i == 0) s else "M$s") }

        private fun ease(p: Float) = if (p < 0.5f) 2f * p * p else 1f - (-2f * p + 2f).pow(2) / 2f
        private fun bd(x: Float = 0f, y: Float = 0f, s: Float = 1f, r: Float = 0f) = floatArrayOf(x, y, s, r)
        private fun lg(a: Float = 0f, s: Float = 1f) = floatArrayOf(a, s)

        /** Tiny parser for the absolute M / L / Q / Z path data used by the logo. */
        private fun parse(d: String): Path {
            val path = Path()
            val t = Regex("[MLQZ]|-?[0-9.]+").findAll(d).map { it.value }.toList()
            var i = 0
            while (i < t.size) {
                when (t[i]) {
                    "M" -> { path.moveTo(t[i + 1].toFloat(), t[i + 2].toFloat()); i += 3 }
                    "L" -> { path.lineTo(t[i + 1].toFloat(), t[i + 2].toFloat()); i += 3 }
                    "Q" -> { path.quadTo(t[i + 1].toFloat(), t[i + 2].toFloat(), t[i + 3].toFloat(), t[i + 4].toFloat()); i += 5 }
                    "Z" -> { path.close(); i++ }
                    else -> i++
                }
            }
            return path
        }
    }
}

/** The small Claude-style "thinking" mark: the logo's burst, slowly turning and breathing in the accent colour. */
class SparkMark(ctx: Context, color: Int) : View(ctx) {
    private val shapes = LivingLogo.shapes()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
    private var t0 = 0L
    private var attached = false
    private var running = false

    private val frame = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (running) { invalidate(); Choreographer.getInstance().postFrameCallback(this) }
        }
    }

    private fun refreshRun() {
        val go = attached && isShown && windowVisibility == VISIBLE
        if (go && !running) { running = true; Choreographer.getInstance().postFrameCallback(frame) }
        else if (!go && running) { running = false; Choreographer.getInstance().removeFrameCallback(frame) }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); attached = true; if (t0 == 0L) t0 = System.nanoTime(); refreshRun() }
    override fun onDetachedFromWindow() { attached = false; refreshRun(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changed: View, visibility: Int) { super.onVisibilityChanged(changed, visibility); refreshRun() }
    override fun onWindowVisibilityChanged(visibility: Int) { super.onWindowVisibilityChanged(visibility); refreshRun() }

    override fun onDraw(c: Canvas) {
        val t = (System.nanoTime() - t0) / 1e9f
        val sc = min(width, height) / 82f
        c.save()
        c.translate(width / 2f, height / 2f)
        c.rotate(t * 55f)
        c.scale(sc, sc)
        c.translate(-54f, -54f)
        for ((i, p) in shapes.withIndex()) {
            val k = 1f + 0.14f * sin(t * 4f + i * 0.9f)
            c.save(); c.translate(54f, 54f); c.scale(k, k); c.translate(-54f, -54f)
            c.drawPath(p, paint)
            c.restore()
        }
        c.drawCircle(54f, 54f, 11f, paint)
        c.restore()
    }
}
