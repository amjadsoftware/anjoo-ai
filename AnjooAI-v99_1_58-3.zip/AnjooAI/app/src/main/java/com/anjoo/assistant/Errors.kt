package com.anjoo.assistant

import android.content.Context
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * One place that turns any failure into a clear message in three parts: WHAT failed, WHY, and WHAT TO DO.
 * The user should never be left staring at a raw exception text or at a spinner that never ends.
 */
object Errors {

    private class Reason(val why: String, val fix: String)

    private fun httpReason(code: Int, detail: String): Reason = when (code) {
        400 -> Reason("Request galat gayi" + tail(detail) + ".", "Dobara try karein. Phir bhi ho to chhota message ya doosra model try karein.")
        401, 403 -> if (detail.contains("API key", true) || code == 401)
            Reason("API key galat ya band hai.", "Settings mein sahi API key dalein.")
        else Reason("Is kaam ki ijazat nahi mili" + tail(detail) + ".", "Settings mein API key aur model check karein.")
        404 -> Reason("Model ya address nahi mila.", "Settings mein model ka naam ya Base URL check karein.")
        408 -> Reason("Server ne waqt par jawab nahi diya.", "Internet check karke dobara try karein.")
        413 -> Reason("File ya photo bohat bari hai.", "Chhoti file ya kam photos bhejein.")
        429 -> Reason("Provider ki limit (quota) poori ho gayi.", "Ek minute ruk kar dobara try karein, ya Menu mein 🔑 Keys add karke doosri key lagayein.")
        in 500..599 -> Reason("Provider ka server abhi masla kar raha hai (error $code).", "Thori der baad dobara try karein, ya doosra model chunein.")
        else -> Reason("Server ne error $code diya" + tail(detail) + ".", "Dobara try karein; masla rahe to Settings check karein.")
    }

    private fun tail(d: String) = if (d.isBlank()) "" else ": " + d.take(140)

    private fun reasonOf(e: Throwable): Reason {
        var t: Throwable? = e
        var depth = 0
        while (t != null && depth++ < 6) {
            if (t is ApiException) {
                val detail = (t.message ?: "").replace(Regex("^\\(\\d+\\)\\s*"), "")
                return httpReason(t.code, detail)
            }
            t = t.cause
        }
        val msg = e.message ?: ""
        Regex("^HTTP (\\d{3})(?: - (.*))?$", RegexOption.DOT_MATCHES_ALL).find(msg)?.let {
            return httpReason(it.groupValues[1].toInt(), it.groupValues[2])
        }
        var c: Throwable? = e
        depth = 0
        while (c != null && depth++ < 6) {
            when (c) {
                is SocketTimeoutException -> return Reason("Server ne waqt par jawab nahi diya (timeout).", "Internet check karein aur dobara try karein.")
                is UnknownHostException -> return Reason("Server tak pohanch nahi saka (internet ya DNS nahi).", "Wi-Fi/mobile data check karein, phir dobara try karein.")
                is javax.net.ssl.SSLException -> return Reason("Mehfooz connection (SSL) qaim nahi hua.", "Phone ki date/time aur network check karein, ya doosra network try karein.")
                is java.net.ConnectException -> return Reason("Server se connection nahi bana.", "Internet check karein; Base URL ho to wo bhi dekhein.")
                is org.json.JSONException -> return Reason("Server ka jawab samajh nahi aaya (format galat).", "Dobara try karein. Custom provider ho to Base URL aur model check karein.")
                is OutOfMemoryError -> return Reason("Phone ki memory khatam ho gayi.", "Chhoti file ya kam photos bhejein, aur baaqi apps band karein.")
                is SecurityException -> return Reason("Android ne permission nahi di.", "Menu > Phone mein jaakar zaroori permission on karein.")
                is FileNotFoundException -> return Reason("File ya folder nahi mila.", "Path check karein ya folder dobara chunein.")
                is android.content.ActivityNotFoundException -> return Reason("Phone mein is kaam ke liye koi app nahi mili.", "Zaroori app install karein ya doosra tareeqa try karein.")
            }
            c = c.cause
        }
        if (e is IOException && (msg.contains("ENOSPC") || msg.contains("No space", true)))
            return Reason("Phone ki storage bhar gayi hai.", "Kuch jagah khali karein aur dobara try karein.")
        if (msg.contains("No answer came back", true))
            return Reason("Model ne koi jawab nahi diya" + (msg.substringAfter("No answer came back.", "").trim().let { if (it.isEmpty()) "" else " ($it)" }) + ".", "Sawal thora badal kar poochein ya doosra model chunein.")
        return Reason((if (msg.isBlank()) e.javaClass.simpleName else msg.take(220)), "Dobara try karein. Phir bhi ho to Menu mein se details copy karke bhejein.")
    }

    /** Message for a failed job. [what] says what was being done, e.g. "Jawab lana". */
    fun explain(e: Throwable, what: String): String {
        val r = reasonOf(e)
        return "⚠️ $what nahi ho saka.\nWajah: ${r.why}\nHal: ${r.fix}"
    }

    /** Text handed back to the model (and shown in the step list) when a tool fails, so it can tell the user plainly. */
    fun tool(name: String, e: Throwable): String {
        val r = reasonOf(e)
        return "FAIL: '$name' tool nahi chala. Wajah: ${r.why} Hal: ${r.fix} (User ko yehi wajah seedhe batao; jhooti kamyabi mat batao.)"
    }

    // ---------- crash report ----------

    private fun crashFile(ctx: Context) = File(ctx.filesDir, "last_crash.txt")

    /** Remembers an app crash so the next start can explain it instead of the app just vanishing. */
    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        if (old is CrashHook) return
        Thread.setDefaultUncaughtExceptionHandler(CrashHook(app, old))
    }

    private class CrashHook(val ctx: Context, val old: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try {
                val r = reasonOf(e)
                val top = e.stackTrace.take(8).joinToString("\n") { "  at $it" }
                val stamp = SimpleDateFormat("d MMM HH:mm:ss", Locale.ENGLISH).format(Date())
                crashFile(ctx).writeText("Waqt: $stamp\nThread: ${t.name}\nWajah: ${r.why}\nHal: ${r.fix}\n\nTechnical:\n${e.javaClass.name}: ${e.message}\n$top", Charsets.UTF_8)
            } catch (x: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    /** The saved crash report from the last run, if any. It is removed once read. */
    fun takeCrash(ctx: Context): String? = try {
        val f = crashFile(ctx)
        if (f.exists()) f.readText(Charsets.UTF_8).also { f.delete() } else null
    } catch (e: Exception) { null }
}
