package com.anjoo.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * A mouse-pointer arrow that glides over the screen to show where Anjoo is about to tap, type or scroll.
 * It is drawn on a see-through overlay, so it is also visible on top of other apps.
 */
class CursorView(ctx: Context, private var accent: Int) : View(ctx), Runnable {

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var cx = -1f
    private var cy = -1f
    private var tx = 0f
    private var ty = 0f
    private var label = ""
    private var alpha = 0f
    private var hideAt = 0L
    private var ripple = -1f
    private var running = false
    private var pressed = 0f

    fun setAccent(c: Int) { accent = c }

    /** Glide to (x, y) in screen pixels, show a small caption, and optionally "click" there. */
    fun moveTo(x: Float, y: Float, text: String, click: Boolean) {
        if (cx < 0) { cx = width / 2f; cy = height * 0.9f }
        tx = x; ty = y
        label = text
        alpha = 1f
        hideAt = System.currentTimeMillis() + 3500
        if (click) ripple = 0f
        wake()
    }

    private fun wake() {
        if (!running) { running = true; postOnAnimation(this) }
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(this)
        super.onDetachedFromWindow()
    }

    override fun run() {
        if (!running) return
        cx += (tx - cx) * 0.2f
        cy += (ty - cy) * 0.2f
        if (abs(tx - cx) < 0.6f) cx = tx
        if (abs(ty - cy) < 0.6f) cy = ty
        if (ripple >= 0f) { ripple += 0.035f; if (ripple > 1f) ripple = -1f }
        val arrived = cx == tx && cy == ty
        pressed = if (ripple in 0f..0.25f) 1f else 0f
        if (System.currentTimeMillis() > hideAt) alpha = max(0f, alpha - 0.06f)
        invalidate()
        if (alpha <= 0f) { running = false; return }
        postOnAnimation(this)
        if (arrived && ripple < 0f) {} // idle but visible until it fades
    }

    private fun arrow(s: Float): Path {
        val p = Path()
        p.moveTo(0f, 0f)
        p.lineTo(0f, 17f * s)
        p.lineTo(4.3f * s, 13.2f * s)
        p.lineTo(7.4f * s, 20f * s)
        p.lineTo(10f * s, 18.9f * s)
        p.lineTo(7f * s, 12.3f * s)
        p.lineTo(12.2f * s, 12.3f * s)
        p.close()
        return p
    }

    override fun onDraw(c: Canvas) {
        if (alpha <= 0f || cx < 0) return
        val a = (255 * min(1f, alpha)).toInt()

        if (ripple >= 0f) {
            val r = (10f + 46f * ripple) * d
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f * d
            paint.color = accent
            paint.alpha = (a * (1f - ripple)).toInt()
            c.drawCircle(tx, ty, r, paint)
        }

        val s = (if (pressed > 0f) 1.35f else 1.7f) * d
        c.save()
        c.translate(cx, cy)
        val path = arrow(s)
        // glow
        paint.style = Paint.Style.STROKE
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = 7f * d
        paint.color = accent
        paint.alpha = (a * 0.35f).toInt()
        c.drawPath(path, paint)
        // outline + white body
        paint.strokeWidth = 2.6f * d
        paint.color = Color.BLACK
        paint.alpha = a
        c.drawPath(path, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        paint.alpha = a
        c.drawPath(path, paint)
        c.restore()

        if (label.isNotEmpty()) {
            paint.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            paint.textSize = 12f * d
            paint.style = Paint.Style.FILL
            val w = paint.measureText(label) + 16f * d
            val h = 24f * d
            var lx = cx + 16f * d
            var ly = cy + 26f * d
            if (lx + w > width - 6 * d) lx = cx - w - 6f * d
            if (ly + h > height - 6 * d) ly = cy - h - 10f * d
            lx = max(6f * d, lx)
            val box = RectF(lx, ly, lx + w, ly + h)
            paint.color = Color.argb((210 * min(1f, alpha)).toInt(), 6, 14, 20)
            c.drawRoundRect(box, 8f * d, 8f * d, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 1.5f * d
            paint.color = accent
            paint.alpha = a
            c.drawRoundRect(box, 8f * d, 8f * d, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.WHITE
            paint.alpha = a
            c.drawText(label, lx + 8f * d, ly + h * 0.7f, paint)
        }
    }
}
