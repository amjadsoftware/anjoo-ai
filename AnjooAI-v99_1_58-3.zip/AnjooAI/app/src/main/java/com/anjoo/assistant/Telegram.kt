package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Control Anjoo from Telegram. You create your own bot with @BotFather, paste its token in Anjoo, and pair it with a
 * one-time code. After that only YOUR chat can talk to Anjoo; everything you write is answered by the same agent
 * (browser, tasks, schedule, sub-agents, phone tools). Calls, SMS and message replies are never done from Telegram.
 * The token is stored under "key_tg_token", so a backup made without the API key leaves it out.
 */
object Telegram {
    private const val TOKEN = "key_tg_token"
    private const val CHAT = "tgChat"
    private const val ON = "tgOn"
    private const val CODE = "tgCode"

    private fun p(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    fun token(ctx: Context) = p(ctx).getString(TOKEN, "") ?: ""
    fun chat(ctx: Context) = p(ctx).getLong(CHAT, 0L)
    fun enabled(ctx: Context) = p(ctx).getBoolean(ON, false) && token(ctx).isNotEmpty()

    private fun api(token: String, method: String, body: JSONObject?, readMs: Int = 20000): JSONObject {
        val c = URL("https://api.telegram.org/bot$token/$method").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 15000
        c.readTimeout = readMs
        c.setRequestProperty("Content-Type", "application/json")
        c.doOutput = true
        c.outputStream.use { it.write((body ?: JSONObject()).toString().toByteArray(Charsets.UTF_8)) }
        val stream = if (c.responseCode in 200..299) c.inputStream else (c.errorStream ?: c.inputStream)
        return JSONObject(stream.bufferedReader(Charsets.UTF_8).use { it.readText() })
    }

    fun send(token: String, chat: Long, text: String) {
        var rest = text.trim().ifEmpty { "…" }
        while (rest.isNotEmpty()) {
            val part = if (rest.length <= 3800) rest else rest.substring(0, 3800).let { s -> s.substring(0, maxOf(s.lastIndexOf('\n'), 2000)) }
            try { api(token, "sendMessage", JSONObject().put("chat_id", chat).put("text", part).put("disable_web_page_preview", true)) } catch (e: Exception) {}
            rest = rest.removePrefix(part).trim()
        }
    }

    /** Sends a result to your paired chat (used by scheduled jobs). Silent when Telegram is not set up. */
    fun notify(ctx: Context, text: String) {
        if (!enabled(ctx) || chat(ctx) == 0L) return
        val t = token(ctx); val c = chat(ctx)
        try { send(t, c, text) } catch (e: Exception) {}
    }

    fun start(ctx: Context) {
        if (!enabled(ctx) || TelegramService.running) return
        try {
            val i = Intent(ctx, TelegramService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        } catch (e: Exception) {}
    }

    fun stop(ctx: Context) {
        try { ctx.stopService(Intent(ctx, TelegramService::class.java)) } catch (e: Exception) {}
    }

    /** The Settings screen: token, pairing code, on/off. */
    fun showSettings(act: Activity) {
        val d = act.resources.displayMetrics.density
        val paired = chat(act) != 0L
        val status = when {
            !enabled(act) -> "Band hai."
            paired -> "Chal raha hai aur aap ka chat juda hua hai ✅"
            else -> "Token mil gaya. Ab pairing baaqi hai: bot ko /pair CODE bhejein."
        }
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding((20 * d).toInt(), (8 * d).toInt(), (20 * d).toInt(), 0) }
        box.addView(TextView(act).apply {
            text = status + "\n\n1) Telegram mein @BotFather kholein, /newbot likhein, bot ka token copy karein.\n2) Token yahan paste karke \"Save and turn on\" dabayein.\n3) Apne bot ko Telegram mein /pair CODE bhejein (CODE yahan dikhega).\n\nSirf aap ka chat Anjoo ko hukm de sakta hai. Call, SMS aur message reply Telegram se nahi hote."
            textSize = 13f
        })
        val et = EditText(act).apply { hint = "Bot token"; setText(token(act)); setSingleLine(true) }
        box.addView(et)
        val b = AlertDialog.Builder(act).setTitle("✈️ Telegram control").setView(box)
            .setPositiveButton("Save and turn on") { _, _ ->
                val tk = et.text.toString().trim()
                if (tk.isEmpty()) return@setPositiveButton
                Toast.makeText(act, "Token check ho raha hai...", Toast.LENGTH_SHORT).show()
                Thread {
                    val me = try { api(tk, "getMe", null) } catch (e: Exception) { null }
                    act.runOnUiThread {
                        if (me == null || !me.optBoolean("ok")) { Toast.makeText(act, "Token sahi nahi ya internet nahi.", Toast.LENGTH_LONG).show(); return@runOnUiThread }
                        val code = (100000 + java.security.SecureRandom().nextInt(900000)).toString()
                        p(act).edit().putString(TOKEN, tk).putBoolean(ON, true).putString(CODE, code).apply()
                        start(act)
                        val name = me.optJSONObject("result")?.optString("username") ?: ""
                        AlertDialog.Builder(act).setTitle("Bas ek qadam").setMessage(
                            (if (paired) "Pehle wala chat juda hua hai.\n\n" else "") +
                                "Telegram mein @" + name + " kholein aur ye bhejein:\n\n/pair " + code + "\n\nYe code sirf ek dafa kaam karta hai."
                        ).setPositiveButton("OK", null).show()
                    }
                }.start()
            }
            .setNegativeButton("Close", null)
        if (enabled(act)) b.setNeutralButton("Turn off") { _, _ ->
            p(act).edit().putBoolean(ON, false).apply(); stop(act)
            Toast.makeText(act, "Telegram control band.", Toast.LENGTH_SHORT).show()
        }
        b.show()
    }

    // ---------- the polling loop (runs in TelegramService) ----------

    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var agent: Agent? = null

    private fun helpText() = "Anjoo ready hai. Bas likhein kya karna hai, jaise:\n" +
        "• \"roz subah 8 baje tech news ka khulasa bhejo\"\n• \"is website se price dhoondo: ...\"\n• \"task add karo: kal supplier ko call\"\n" +
        "Commands: /tasks (board), /new (nayi baat), /unpair, /help"

    fun handle(ctx: Context, u: JSONObject) {
        val m = u.optJSONObject("message") ?: return
        val chatObj = m.optJSONObject("chat") ?: return
        if (chatObj.optString("type") != "private") return
        val cid = chatObj.optLong("id")
        val text = m.optString("text", "").trim()
        val tk = token(ctx)
        val paired = chat(ctx)

        if (paired == 0L) {
            val code = p(ctx).getString(CODE, "") ?: ""
            if (text.startsWith("/pair") && code.isNotEmpty() && text.removePrefix("/pair").trim() == code) {
                p(ctx).edit().putLong(CHAT, cid).remove(CODE).apply()
                send(tk, cid, "✅ Jur gaya! Ab sirf ye chat Anjoo ko hukm de sakta hai.\n\n" + helpText())
            } else send(tk, cid, "Pehle Anjoo app ka pairing code bhejein: /pair 123456")
            return
        }
        if (cid != paired) return   // somebody else found the bot: ignore completely

        when {
            text.isEmpty() -> { send(tk, cid, "Abhi sirf likha hua hukm samajhta hoon."); return }
            text == "/start" || text == "/help" -> { send(tk, cid, helpText()); return }
            text == "/tasks" -> { send(tk, cid, Tasks.summary(ctx)); return }
            text == "/new" -> { agent = null; send(tk, cid, "Nayi baat shuru."); return }
            text == "/unpair" -> { p(ctx).edit().putLong(CHAT, 0L).apply(); send(tk, cid, "Chat alag kar diya. Dobara jorne ke liye app mein Telegram control kholein."); return }
        }
        worker.execute {
            try { api(tk, "sendChatAction", JSONObject().put("chat_id", cid).put("action", "typing")) } catch (e: Exception) {}
            val ag = agent ?: AgentJobs.newAgent(ctx).also { agent = it }
            val reply = try { ag.ask(text) } catch (e: Exception) { Errors.explain(e, "Kaam") }
            send(tk, cid, reply.ifBlank { "Ho gaya." })
        }
    }

    fun loop(ctx: Context, alive: () -> Boolean) {
        var offset = p(ctx).getLong("tgOffset", 0L)
        while (alive()) {
            val tk = token(ctx)
            if (tk.isEmpty() || !p(ctx).getBoolean(ON, false)) return
            try {
                val r = api(tk, "getUpdates", JSONObject().put("offset", offset).put("timeout", 25).put("allowed_updates", JSONArray().put("message")), 40000)
                val a = r.optJSONArray("result") ?: JSONArray()
                for (i in 0 until a.length()) {
                    val u = a.getJSONObject(i)
                    offset = u.optLong("update_id") + 1
                    p(ctx).edit().putLong("tgOffset", offset).apply()
                    try { handle(ctx, u) } catch (e: Exception) {}
                }
                if (!r.optBoolean("ok", true)) Thread.sleep(8000)
            } catch (e: Exception) {
                try { Thread.sleep(6000) } catch (x: InterruptedException) { return }
            }
        }
    }
}

/** Keeps the Telegram connection alive in the background (shows a small notification while it runs). */
class TelegramService : Service() {
    companion object { @Volatile var running = false }
    @Volatile private var alive = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("anjoo_tg", "Anjoo Telegram", NotificationManager.IMPORTANCE_MIN))
            val open = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, "anjoo_tg").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Anjoo Telegram control on hai").setContentText("Aap ka bot hukm sun raha hai").setContentIntent(open).setOngoing(true).build()
            if (Build.VERSION.SDK_INT >= 29) startForeground(78, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(78, n)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        if (!running) {
            running = true
            alive = true
            Thread {
                try { Telegram.loop(applicationContext) { alive } } finally { running = false; stopSelf() }
            }.start()
        }
        return START_STICKY
    }

    override fun onDestroy() { alive = false; running = false; super.onDestroy() }
}
