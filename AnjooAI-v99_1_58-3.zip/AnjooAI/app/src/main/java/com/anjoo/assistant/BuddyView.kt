package com.anjoo.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import java.util.Locale
import java.util.Random
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.cos

enum class Mood {
    IDLE, HAPPY, LOVE, SAD, SURPRISED, THINKING, LISTENING, SLEEP;

    companion object {
        private val sad = listOf("sorry", "afsos", "udaas", "maaf", "nahi ho saka", "nahi mila", "masla", "error",
            "fail", "ghalat", "dukh", "bimar", "takleef", "rona", "nahi hua", "نہیں ہو", "مسئلہ", "افسوس", "معاف")
        private val sleep = listOf("good night", "shab bakhair", "so jao", "neend", "allah hafiz", "khuda hafiz",
            "alvida", "الوداع", "خدا حافظ", "اللہ حافظ", "شب بخیر")
        private val love = listOf("love", "pyar", "pyaar", "shukriya", "shukria", "thank", "mehrbani", "jaan",
            "شکریہ", "پیار", "مہربانی", "❤")
        private val wow = listOf("wow", "kya baat", "really", "hairat", "amazing", "are wah", "حیرت", "واہ واہ")
        private val happy = listOf("haha", "hehe", "khush", "mubarak", "congrat", "zabardast", "wah", "great", "acha",
            "achha", "shabash", "ho gaya", "kar diya", "kar di", "khol di", "khol diya", "done", "salam", "hello",
            "assalam", "ہو گیا", "شاباش", "خوش", "مبارک", "سلام", "😊", "😂")

        /** Guesses a feeling from what was said. Returns null when nothing stands out. */
        fun fromText(text: String): Mood? {
            val t = text.lowercase(Locale.ROOT)
            fun has(l: List<String>) = l.any { t.contains(it) }
            return when {
                has(sad) -> SAD
                has(sleep) -> SLEEP
                has(love) -> LOVE
                has(wow) -> SURPRISED
                has(happy) -> HAPPY
                else -> null
            }
        }
    }
}

/** Messages from the background voice service to the screen (what was heard and answered). */
object Buddy {
    @Volatile var stamp = 0L
    @Volatile var kind = 0
    @Volatile var text = ""
    fun post(k: Int, t: String) { text = t; kind = k; stamp = System.nanoTime() }
}

/**
 * A small friendly robot that floats around the screen, shows feelings on its face, reacts to what is
 * said and flies to wherever the user taps. Everything is drawn with code, no images.
 */
class BuddyView(ctx: Context, private var accent: Int) : View(ctx), Runnable {

    private val rnd = Random()
    private val d = resources.displayMetrics.density
    /** compact = a small fixed avatar (used in the chat header); otherwise it roams the whole view. */
    var compact = false
    private val u: Float get() = if (compact && width > 0) min(width, height) / 150f else 0.8f * d
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var px = -1f
    private var py = -1f
    private var tx = 0f
    private var ty = 0f
    private var moving = false
    private var lean = 0f
    private var vx = 0f
    private var t = 0f
    private var last = 0L
    private var waitUntil = 2f
    private var hop = 0f
    private var fleeUntil = 0f

    private var mood = Mood.IDLE
    private var moodUntil = 0L
    private var lastInteract = System.currentTimeMillis()
    private var talkUntil = 0L

    private var blink = 0f
    private var nextBlink = 2f
    private var spawnT = 0f

    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val kind: Int)
    private val parts = ArrayList<P>()

    private var birdOn = false
    private var birdX = 0f
    private var birdY = 0f
    private var nextBird = 6f

    private var running = false

    // ---------- public ----------

    fun setMood(m: Mood, holdMs: Long = 0) {
        val now = System.currentTimeMillis()
        mood = m
        moodUntil = if (holdMs > 0) now + holdMs else 0
        lastInteract = now
        if (m == Mood.SURPRISED || (m == Mood.HAPPY && rnd.nextBoolean()) || m == Mood.LOVE) hop = 1f
        if (m == Mood.SURPRISED) spawn(5)
    }

    fun talk(ms: Long) { talkUntil = System.currentTimeMillis() + ms }

    /**
     * Called for every touch on the robot's area. The robot is shy and playful: it runs away from the
     * touch (touch it and it hops a step back, touch beside it and it dashes to the far side).
     */
    fun onTap(x: Float, y: Float) {
        if (compact) return
        lastInteract = System.currentTimeMillis()
        if (mood == Mood.SLEEP) { mood = Mood.SURPRISED; moodUntil = lastInteract + 1500; hop = 1f }
        if (px < 0) return
        val near = hypot(x - px, y - py) < 55 * u
        var ax = px - x
        var ay = py - y
        var len = hypot(ax, ay)
        if (len < 1f) { ax = if (rnd.nextBoolean()) 1f else -1f; ay = rnd.nextFloat() - 0.5f; len = hypot(ax, ay) }
        val run = (if (near) 120f else 190f) * u
        var nx = clampX(px + ax / len * run)
        var ny = clampY(py + ay / len * run)
        // cornered against an edge: slip over to the opposite side instead of staying under the finger
        if (hypot(nx - px, ny - py) < 35 * u) {
            nx = clampX(width - x)
            ny = clampY(height - y)
        }
        tx = nx
        ty = ny
        fleeUntil = t + 1.2f
        waitUntil = t + 4f
        hop = 1f
        setMood(if (near) Mood.SURPRISED else Mood.HAPPY, 1400)
    }

    fun setAccent(c: Int) { accent = c }

    // ---------- loop ----------

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        last = 0L
        postOnAnimation(this)
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility != VISIBLE) { removeCallbacks(this) }
        else if (running) { last = 0L; removeCallbacks(this); postOnAnimation(this) }
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(this)
        super.onDetachedFromWindow()
    }

    override fun run() {
        if (!running) return
        if (!isShown) { last = 0L; postDelayed(this, 300L); return }   // hidden (other screen, empty-state avatar): do not draw
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.05f, (now - last) / 1e9f)
        last = now
        update(dt)
        invalidate()
        // 30 frames a second is plenty for a small avatar and leaves the UI thread free for scrolling and menus
        postDelayed(this, if (mood == Mood.SLEEP) 66L else 33L)
    }

    private fun clampX(x: Float) = max(42 * u, min(width - 42 * u, x))
    private fun clampY(y: Float) = max(64 * u, min(height - 62 * u, y))

    private fun pickTarget() {
        if (compact) return
        tx = clampX(42 * u + rnd.nextFloat() * (width - 84 * u))
        ty = clampY(64 * u + rnd.nextFloat() * (height - 126 * u))
    }

    private fun update(dt: Float) {
        if (width == 0 || height == 0) return
        t += dt
        val nowMs = System.currentTimeMillis()
        if (px < 0 || compact) { px = width * 0.5f; py = height * (if (compact) 0.5f else 0.6f); tx = px; ty = py }

        if (moodUntil > 0 && nowMs > moodUntil) { mood = Mood.IDLE; moodUntil = 0 }
        if (mood == Mood.IDLE && nowMs - lastInteract > 40000) mood = Mood.SLEEP

        val still = mood == Mood.SLEEP || mood == Mood.LISTENING || mood == Mood.THINKING
        val dx = tx - px
        val dy = ty - py
        val dist = hypot(dx, dy)
        if (!still && dist > 4f) {
            val sp = (if (t < fleeUntil) 420f else if (mood == Mood.HAPPY || mood == Mood.LOVE) 200f else 150f) * d * dt
            val k = min(1f, sp / dist)
            px += dx * k
            py += dy * k
            vx = dx / dist
            moving = true
        } else {
            moving = false
            vx = 0f
            if (!still && t >= waitUntil) { pickTarget(); waitUntil = t + 3f + rnd.nextFloat() * 5f }
        }
        lean += (vx * 9f - lean) * min(1f, dt * 6f)

        if (hop > 0f) hop = max(0f, hop - dt * 1.5f)

        nextBlink -= dt
        if (nextBlink <= 0f) { blink = 0.14f; nextBlink = 2f + rnd.nextFloat() * 3.5f }
        if (blink > 0f) blink -= dt

        spawnT -= dt
        if (spawnT <= 0f) {
            when (mood) {
                Mood.LOVE -> { spawn(0); spawnT = 0.3f }
                Mood.HAPPY -> { spawn(1); spawnT = 0.5f }
                Mood.SLEEP -> { spawn(2); spawnT = 1.3f }
                Mood.THINKING -> { spawn(3); spawnT = 1.4f }
                Mood.SAD -> { spawn(4); spawnT = 0.6f }
                Mood.SURPRISED -> { spawn(5); spawnT = 0.7f }
                else -> { if (moving) spawn(6); spawnT = 0.12f }
            }
        }
        val it = parts.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.life -= dt
            if (p.life <= 0f) it.remove()
        }

        nextBird -= dt
        if (!birdOn && nextBird <= 0f) {
            birdOn = true; birdX = -30 * d; birdY = height * (0.08f + rnd.nextFloat() * 0.3f)
        }
        if (birdOn) {
            birdX += 120 * d * dt
            birdY += sin(t * 2f) * 20f * dt
            if (birdX > width + 30 * d) { birdOn = false; nextBird = 12f + rnd.nextFloat() * 15f }
        }
    }

    private fun hopOff() = if (hop > 0f) sin((1f - hop) * Math.PI.toFloat()) * 26 * u else 0f
    private fun floatOff() = sin(t * 2.4f) * 3.5f * u

    private fun spawn(kind: Int) {
        val cx = px
        val cy = py - hopOff() + floatOff()
        when (kind) {
            0 -> parts.add(P(cx + (rnd.nextFloat() - 0.5f) * 40 * u, cy - 55 * u, (rnd.nextFloat() - 0.5f) * 30 * d, -45 * d, 1.8f, 0))
            1 -> parts.add(P(cx + (rnd.nextFloat() - 0.5f) * 60 * u, cy - 45 * u, (rnd.nextFloat() - 0.5f) * 50 * d, -30 * d, 1.2f, 1))
            2 -> parts.add(P(cx + 26 * u, cy - 40 * u, 14 * d, -22 * d, 2f, 2))
            3 -> parts.add(P(cx + 20 * u, cy - 62 * u, 0f, -6 * d, 1.6f, 3))
            4 -> parts.add(P(cx - 12 * u, cy - 2 * u, 0f, 50 * d, 1f, 4))
            5 -> parts.add(P(cx + 22 * u, cy - 62 * u, 0f, -8 * d, 1.2f, 5))
            6 -> parts.add(P(cx - lean * 3f * u + (rnd.nextFloat() - 0.5f) * 10 * u, cy + 50 * u, 0f, 10 * d, 0.6f, 6))
        }
    }

    // ---------- drawing ----------

    private fun fill(c: Int, a: Int = 255) { paint.style = Paint.Style.FILL; paint.color = c; paint.alpha = a }
    private fun line(c: Int, w: Float, a: Int = 255) {
        paint.style = Paint.Style.STROKE; paint.color = c; paint.strokeWidth = w
        paint.strokeCap = Paint.Cap.ROUND; paint.alpha = a
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, a: Int = 255) {
        val p = Path()
        p.moveTo(cx, cy + s * 0.9f)
        p.cubicTo(cx - s * 1.6f, cy - s * 0.2f, cx - s * 0.7f, cy - s * 1.3f, cx, cy - s * 0.4f)
        p.cubicTo(cx + s * 0.7f, cy - s * 1.3f, cx + s * 1.6f, cy - s * 0.2f, cx, cy + s * 0.9f)
        p.close()
        fill(color, a)
        c.drawPath(p, paint)
    }

    private fun star(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, a: Int) {
        val p = Path()
        p.moveTo(cx, cy - s); p.lineTo(cx + s * 0.3f, cy - s * 0.3f); p.lineTo(cx + s, cy)
        p.lineTo(cx + s * 0.3f, cy + s * 0.3f); p.lineTo(cx, cy + s); p.lineTo(cx - s * 0.3f, cy + s * 0.3f)
        p.lineTo(cx - s, cy); p.lineTo(cx - s * 0.3f, cy - s * 0.3f); p.close()
        fill(color, a)
        c.drawPath(p, paint)
    }

    override fun onDraw(c: Canvas) {
        if (px < 0) return
        if (!compact) {
            drawButterfly(c)
            if (birdOn) drawBird(c)
        }

        // ground shadow, smaller when the robot is high
        val high = hopOff() + floatOff()
        fill(Color.BLACK, 45)
        val sh = max(0.5f, 1f - high / (80 * u))
        c.drawOval(RectF(px - 24 * u * sh, py + 56 * u, px + 24 * u * sh, py + 62 * u), paint)

        c.save()
        c.translate(px, py - hopOff() + floatOff())
        c.rotate(lean)
        c.scale(u, u)
        drawBot(c)
        c.restore()

        drawParticles(c)
    }

    private fun drawBot(c: Canvas) {
        val shell = 0xFFDCE8F0.toInt()
        val shade = 0xFFB4C4D0.toInt()
        val screen = 0xFF06121A.toInt()
        val sad = mood == Mood.SAD
        val sleepy = mood == Mood.SLEEP
        val happy = mood == Mood.HAPPY || mood == Mood.LOVE
        val listen = mood == Mood.LISTENING
        val glow = if (sleepy) 70 else 255

        // hover glow under the robot
        val pulse = 0.6f + 0.4f * sin(t * 5f)
        fill(accent, (90 * pulse).toInt()); c.drawOval(RectF(-16f, 46f, 16f, 56f), paint)
        fill(accent, (160 * pulse).toInt()); c.drawOval(RectF(-9f, 48f, 9f, 54f), paint)

        // arms
        val wave = if (happy) sin(t * 10f) * 8f else if (mood == Mood.SURPRISED) -14f else sin(t * 2f) * 2f
        line(shade, 5f)
        c.drawLine(-17f, 30f, -29f, 38f - wave - (if (happy) 10f else 0f), paint)
        c.drawLine(17f, 30f, 29f, 38f + wave - (if (happy) 10f else 0f), paint)
        fill(shell); c.drawCircle(-29f, 38f - wave - (if (happy) 10f else 0f), 4f, paint)
        c.drawCircle(29f, 38f + wave - (if (happy) 10f else 0f), 4f, paint)

        // body
        fill(shade); c.drawRoundRect(RectF(-17f, 22f, 17f, 46f), 11f, 11f, paint)
        fill(shell); c.drawRoundRect(RectF(-17f, 22f, 17f, 42f), 11f, 11f, paint)
        fill(accent, glow); c.drawCircle(0f, 33f, 3f, paint)

        // antenna
        val sway = sin(t * 2f) * (if (sad) 1f else 3f)
        val ax = if (sad) -8f else sway
        val ay = if (sad) -43f else -52f
        line(shade, 2.6f); c.drawLine(0f, -36f, ax, ay, paint)
        val bulb = when {
            happy -> 0xFFFFD54F.toInt()
            sad -> 0xFF8899A6.toInt()
            mood == Mood.SURPRISED -> 0xFFFF5252.toInt()
            else -> accent
        }
        val bp = if (sleepy) 0.3f else 0.7f + 0.3f * sin(t * 6f)
        fill(bulb, (60 * bp).toInt()); c.drawCircle(ax, ay - 2f, 8f, paint)
        fill(bulb, glow); c.drawCircle(ax, ay - 2f, 4.4f, paint)

        // side ear discs (glow while listening)
        val ear = if (listen) (140 + 115 * sin(t * 10f)).toInt().coerceIn(0, 255) else 190
        fill(accent, ear); c.drawCircle(-37f, -7f, 6f, paint); c.drawCircle(37f, -7f, 6f, paint)

        // head
        fill(shade); c.drawRoundRect(RectF(-34f, -34f, 34f, 24f), 21f, 21f, paint)
        fill(shell); c.drawRoundRect(RectF(-34f, -36f, 34f, 20f), 21f, 21f, paint)
        fill(screen); c.drawRoundRect(RectF(-27f, -29f, 27f, 14f), 15f, 15f, paint)
        line(accent, 1.2f, 110); c.drawRoundRect(RectF(-27f, -29f, 27f, 14f), 15f, 15f, paint)

        drawFace(c, glow)

        if (listen) {
            for (i in 0..2) {
                val r = 8f + ((t * 22f + i * 8f) % 24f)
                val a = (200 * (1f - (r - 8f) / 24f)).toInt().coerceIn(0, 255)
                line(accent, 1.6f, a)
                c.drawArc(RectF(-37f - r, -7f - r, -37f + r, -7f + r), 130f, 100f, false, paint)
                c.drawArc(RectF(37f - r, -7f - r, 37f + r, -7f + r), -50f, 100f, false, paint)
            }
        }
    }

    private fun drawFace(c: Canvas, glow: Int) {
        val closed = mood == Mood.SLEEP || blink > 0f
        val ey = -10f
        var lx = if (moving) lean * 0.2f else sin(t * 0.7f) * 1.2f
        var ly = 0f
        if (mood == Mood.THINKING) { lx = 3f; ly = -3f }
        val xs = floatArrayOf(-12f, 12f)
        for (ex in xs) {
            when {
                mood == Mood.LOVE -> heart(c, ex, ey, 5.2f, 0xFFFF4D6D.toInt())
                mood == Mood.SLEEP || closed -> { line(accent, 2.6f, glow); c.drawLine(ex - 5f, ey + 1f, ex + 5f, ey + 1f, paint) }
                mood == Mood.HAPPY -> {
                    line(accent, 3f)
                    c.drawArc(RectF(ex - 5.5f, ey - 5f, ex + 5.5f, ey + 6f), 200f, 140f, false, paint)
                }
                mood == Mood.SAD -> {
                    fill(accent); c.drawOval(RectF(ex - 4f + lx * 0.3f, ey - 3f, ex + 4f + lx * 0.3f, ey + 7f), paint)
                    line(accent, 2.4f)
                    if (ex < 0) c.drawLine(ex - 6f, ey - 7f, ex + 4f, ey - 10.5f, paint)
                    else c.drawLine(ex - 4f, ey - 10.5f, ex + 6f, ey - 7f, paint)
                }
                mood == Mood.SURPRISED -> {
                    fill(accent); c.drawCircle(ex, ey, 7f, paint)
                    fill(screen2()); c.drawCircle(ex + lx * 0.4f, ey, 2.8f, paint)
                }
                else -> {
                    val h = if (mood == Mood.LISTENING) 8f else 6.5f
                    fill(accent); c.drawRoundRect(RectF(ex - 4.6f + lx, ey - h + ly, ex + 4.6f + lx, ey + h + ly), 4.6f, 4.6f, paint)
                    fill(Color.WHITE, 220); c.drawCircle(ex - 1.5f + lx, ey - h * 0.5f + ly, 1.3f, paint)
                }
            }
        }

        if (happy()) {
            fill(0xFFFF8FA3.toInt(), 150)
            c.drawCircle(-20f, 3f, 3.6f, paint)
            c.drawCircle(20f, 3f, 3.6f, paint)
        }

        // mouth
        val my = 5f
        val talking = System.currentTimeMillis() < talkUntil
        if (talking) {
            fill(accent)
            val h = 1.5f + 3.2f * abs(sin(t * 14f))
            c.drawOval(RectF(-4f, my, 4f, my + h * 2f), paint)
        } else when (mood) {
            Mood.HAPPY, Mood.LOVE -> { line(accent, 2.2f); c.drawArc(RectF(-8f, my - 4f, 8f, my + 5f), 20f, 140f, false, paint) }
            Mood.SAD -> { line(accent, 2.2f); c.drawArc(RectF(-5f, my + 1f, 5f, my + 8f), 200f, 140f, false, paint) }
            Mood.SURPRISED -> { fill(accent); c.drawOval(RectF(-3f, my - 1f, 3f, my + 6f), paint) }
            Mood.THINKING -> { line(accent, 2f); c.drawLine(-4f, my + 2f, 4f, my + 2f, paint) }
            else -> { line(accent, 2f, if (mood == Mood.SLEEP) 90 else 255); c.drawArc(RectF(-5f, my - 2f, 5f, my + 3f), 20f, 140f, false, paint) }
        }
    }

    private fun happy() = mood == Mood.HAPPY || mood == Mood.LOVE
    private fun screen2() = 0xFF06121A.toInt()

    private fun drawParticles(c: Canvas) {
        for (p in parts) {
            val a = (255 * min(1f, p.life)).toInt().coerceIn(0, 255)
            when (p.kind) {
                0 -> heart(c, p.x, p.y, 6 * d, 0xFFFF4D6D.toInt(), a)
                1 -> star(c, p.x, p.y, 6 * d, 0xFFFFD54F.toInt(), a)
                2, 3, 5 -> {
                    paint.style = Paint.Style.FILL
                    paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                    paint.textSize = (if (p.kind == 2) 16 else 20) * d
                    paint.color = if (p.kind == 5) 0xFFFFD54F.toInt() else accent
                    paint.alpha = a
                    c.drawText(if (p.kind == 2) "z" else if (p.kind == 3) "?" else "!", p.x, p.y, paint)
                }
                4 -> { fill(0xFF6EC6FF.toInt(), a); c.drawCircle(p.x, p.y, 2.6f * d, paint) }
                6 -> { fill(accent, (a * 0.5f).toInt()); c.drawCircle(p.x, p.y, 2.2f * d * p.life, paint) }
            }
        }
    }

    private fun drawButterfly(c: Canvas) {
        val bx = width * (0.5f + 0.42f * sin(t * 0.31f))
        val by = height * (0.45f + 0.3f * sin(t * 0.47f + 1f)) + sin(t * 3f) * 8f * d
        val flap = abs(sin(t * 14f))
        val w = 8 * d * (0.3f + 0.7f * flap)
        fill(accent, 190); c.drawOval(RectF(bx - w, by - 6 * d, bx, by + 1 * d), paint)
        fill(0xFFFF8AD8.toInt(), 190); c.drawOval(RectF(bx, by - 6 * d, bx + w, by + 1 * d), paint)
        fill(accent, 150); c.drawOval(RectF(bx - w * 0.8f, by, bx, by + 5 * d), paint)
        fill(0xFFFF8AD8.toInt(), 150); c.drawOval(RectF(bx, by, bx + w * 0.8f, by + 5 * d), paint)
        line(Color.WHITE, 1.4f * d, 200); c.drawLine(bx, by - 4 * d, bx, by + 5 * d, paint)
    }

    private fun drawBird(c: Canvas) {
        val f = sin(t * 12f)
        line(accent, 2.4f * d)
        c.drawLine(birdX, birdY, birdX - 9 * d, birdY - 7 * d * f, paint)
        c.drawLine(birdX, birdY, birdX + 9 * d, birdY - 7 * d * f, paint)
        fill(accent); c.drawCircle(birdX, birdY + 1 * d, 2.6f * d, paint)
    }
}
