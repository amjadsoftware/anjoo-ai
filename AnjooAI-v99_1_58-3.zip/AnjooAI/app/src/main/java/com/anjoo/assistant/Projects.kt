package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Named groups of chats. Each project has its own instructions that are added to the prompt of every chat inside it. */
object Projects {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    class P(val id: String, val name: String, val instructions: String)

    fun list(ctx: Context): List<P> = try {
        val a = JSONArray(prefs(ctx).getString("projects", "[]"))
        (0 until a.length()).map { val o = a.getJSONObject(it); P(o.getString("id"), o.getString("name"), o.optString("ins")) }
    } catch (e: Exception) { emptyList() }

    private fun save(ctx: Context, l: List<P>) {
        val a = JSONArray()
        for (p in l) a.put(JSONObject().put("id", p.id).put("name", p.name).put("ins", p.instructions))
        prefs(ctx).edit().putString("projects", a.toString()).apply()
    }

    fun create(ctx: Context, name: String, ins: String = ""): P {
        val p = P("p" + System.currentTimeMillis(), name.trim().take(40), ins.take(1500))
        save(ctx, list(ctx) + p)
        return p
    }

    fun update(ctx: Context, id: String, name: String, ins: String) =
        save(ctx, list(ctx).map { if (it.id == id) P(id, name.trim().take(40).ifBlank { it.name }, ins.take(1500)) else it })

    fun get(ctx: Context, id: String): P? = if (id.isEmpty()) null else list(ctx).firstOrNull { it.id == id }

    /** Deleting a project only ungroups its chats; the chats stay. */
    fun delete(ctx: Context, id: String) {
        save(ctx, list(ctx).filter { it.id != id })
        for (s in ChatStore.list(ctx)) if (s.optString("project") == id) ChatStore.setProject(ctx, s.getLong("id"), "")
    }

    /** Text added to the system prompt for the chat that is open. */
    fun promptFor(ctx: Context, chatId: Long): String {
        val p = get(ctx, ChatStore.projectOf(ctx, chatId)) ?: return ""
        return "\nPROJECT \"" + p.name + "\": " + (if (p.instructions.isBlank()) "no extra instructions." else "follow these project instructions: " + p.instructions)
    }
}
