package com.anjoo.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.widget.Toast
import java.io.File

/**
 * One place for every "download": the file goes straight into Download/Anjoo (no folder picker) and a normal
 * download notification appears. Tap the notification to open the file.
 */
object Dl {
    private const val CHANNEL = "downloads"
    private const val FOLDER = "Anjoo"
    private val ui = Handler(Looper.getMainLooper())
    private var nid = 8800

    fun mimeOf(name: String): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.', "").lowercase())
            ?: "application/octet-stream"

    fun safeName(name: String): String =
        name.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[^A-Za-z0-9._ -]"), "_").ifBlank { "download.bin" }

    /** Saves in the background, then shows a toast + notification. [done] gets true/false on the main thread. */
    fun save(ctx: Context, name: String, bytes: ByteArray, done: ((Boolean) -> Unit)? = null) {
        val app = ctx.applicationContext
        Thread {
            val safe = safeName(name)
            var uri: Uri? = null
            val ok = try { uri = write(app, safe, bytes); true } catch (e: Exception) { false }
            ui.post {
                if (ok) {
                    Toast.makeText(app, "Downloaded: $safe\nDownload/$FOLDER", Toast.LENGTH_SHORT).show()
                    notify(app, safe, uri)
                } else {
                    Toast.makeText(app, "Download nahi ho saka: $safe", Toast.LENGTH_LONG).show()
                }
                done?.invoke(ok)
            }
        }.start()
    }

    private fun write(ctx: Context, name: String, bytes: ByteArray): Uri? {
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/$FOLDER")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val cr = ctx.contentResolver
            val u = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw RuntimeException("insert failed")
            try {
                cr.openOutputStream(u)?.use { it.write(bytes) } ?: throw RuntimeException("open failed")
                cr.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) { try { cr.delete(u, null, null) } catch (x: Exception) {}; throw e }
            return u
        }
        // Android 8/9: public Download folder (needs the storage permission), else the app's own folder
        val dirs = listOfNotNull(
            File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), FOLDER),
            ctx.getExternalFilesDir(null)?.let { File(it, FOLDER) })
        for (d in dirs) {
            try {
                d.mkdirs()
                var f = File(d, name); var n = 1
                while (f.exists()) { f = File(d, name.substringBeforeLast('.', name) + " ($n)" + (if (name.contains('.')) "." + name.substringAfterLast('.') else "")); n++ }
                f.writeBytes(bytes)
                android.media.MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
                return null
            } catch (e: Exception) { /* try the next folder */ }
        }
        throw RuntimeException("no folder")
    }

    private fun notify(ctx: Context, name: String, uri: Uri?) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Downloads", NotificationManager.IMPORTANCE_DEFAULT))
            val open = if (uri != null)
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mimeOf(name)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            else Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(ctx, nid, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val b = if (Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(ctx, CHANNEL)
                    else android.app.Notification.Builder(ctx)
            nm.notify(nid++, b.setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle(name).setContentText("Download complete  •  Download/$FOLDER")
                .setContentIntent(pi).setAutoCancel(true).build())
        } catch (e: Exception) { /* no notification permission: the toast is enough */ }
    }
}
