package com.anjoo.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/**
 * On-device model-health observer. It alerts only on repeated, measured API failures
 * and never mistakes quota/key/server errors for proof that a model is unintelligent.
 * No prompts, API keys, or raw provider responses are included in notifications.
 */
object ModelHealthMonitor {
    private const val CHANNEL = "anjoo_model_health"
    @Volatile private var app: Context? = null

    fun bind(ctx: Context) {
        val c = ctx.applicationContext
        app = c
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = c.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "Anjoo AI model health", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Alerts when an AI connection repeatedly fails or recovers"
                })
            }
        } catch (_: Exception) {}
    }

    private fun token(provider: String, model: String): String = try {
        MessageDigest.getInstance("SHA-256").digest((provider + "|" + model).toByteArray(Charsets.UTF_8))
            .take(8).joinToString("") { "%02x".format(it) }
    } catch (_: Exception) { (provider + model).hashCode().toUInt().toString(16) }

    private fun issue(code: Int): Pair<String, String> = when (code) {
        401, 403 -> "API key / permission issue" to "Provider ne key ya access refuse kiya. Settings mein key aur model access check karein; ise model ki intelligence ka score na samjhein."
        404 -> "Model / endpoint not found" to "Provider ko yeh model ya endpoint nahi mila. Model name ya custom base URL check karein."
        429 -> "Provider limit reached" to "Is provider ki rate/quota limit hit ho rahi hai. Doosra provider use karein ya limit reset hone dein."
        400, 422 -> "Request compatibility issue" to "Yeh model is request ke format/tool ko accept nahi kar raha ho sakta hai. Doosra compatible model try karein."
        408 -> "Request timed out" to "Server ne waqt par jawab nahi diya. Network check karke dobara try karein."
        in 500..599 -> "Provider server unstable" to "Provider server ne repeated error diya. Thori der baad dobara try karein ya doosra provider use karein."
        else -> "Connection / transport issue" to "AI connection repeated fail hui. Internet, provider status aur Settings check karein."
    }

    /** Called by Router after the third consecutive failed attempt for one model. */
    fun onRepeatedFailure(provider: String, model: String, code: Int, consecutive: Int) {
        val c = app ?: return
        if (consecutive < 3) return
        val prefs = c.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("modelHealthAlerts", true)) return
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val id = token(provider, model)
        val now = System.currentTimeMillis()
        val throttle = "mh_alert_at_$id"
        if (now - prefs.getLong(throttle, 0L) < 8L * 60 * 60 * 1000) return
        val (title, advice) = issue(code)
        val modelShort = model.substringAfterLast('/').take(75)
        val body = "$modelShort · $consecutive consecutive failures. $advice"
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            val open = PendingIntent.getActivity(c, (id.hashCode() and 0x7fffffff),
                Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("Boss, AI connection ko attention chahiye")
                .setContentText("$provider · $modelShort: $title")
                .setStyle(Notification.BigTextStyle().bigText(body))
                .setContentIntent(open).setAutoCancel(true).setCategory(Notification.CATEGORY_STATUS)
                .build()
            nm.notify((id.hashCode() and 0x7fffffff), n)
            prefs.edit().putLong(throttle, now).putBoolean("mh_alerted_$id", true).putString("mh_last_issue", "$provider · $modelShort: $title\n$advice").apply()
        } catch (_: Exception) {}
    }

    /** One recovery ping only after Anjoo previously raised an alert for the same model. */
    fun onRecovered(provider: String, model: String) {
        val c = app ?: return
        val prefs = c.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val id = token(provider, model)
        if (!prefs.getBoolean("mh_alerted_$id", false) || !prefs.getBoolean("modelHealthAlerts", true)) return
        prefs.edit().putBoolean("mh_alerted_$id", false).apply()
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            val open = PendingIntent.getActivity(c, (id.hashCode() and 0x7fffffff),
                Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify((id.hashCode() and 0x7fffffff), Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                .setContentTitle("Boss, AI model phir chal gaya")
                .setContentText(provider + " · " + model.substringAfterLast('/').take(70) + " ne successful response diya.")
                .setContentIntent(open).setAutoCancel(true).build())
        } catch (_: Exception) {}
    }
}
