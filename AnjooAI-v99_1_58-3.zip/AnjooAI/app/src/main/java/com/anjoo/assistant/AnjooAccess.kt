package com.anjoo.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.PixelFormat
import android.accessibilityservice.GestureDescription
import android.util.Base64
import android.view.Display
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Lets Anjoo type text, tap buttons and press back/home in any app. The user must switch it on once. */
class AnjooAccess : AccessibilityService() {

    companion object {
        @Volatile var inst: AnjooAccess? = null
        const val OFF = "Accessibility band hai. Anjoo app mein ACCESS dabayein aur Anjoo AI ko on karein."

        /** Retries for a few seconds, because a freshly opened app needs a moment to appear. */
        fun <T> retry(tries: Int = 8, gap: Long = 500, block: () -> T?): T? {
            repeat(tries) {
                val r = block()
                if (r != null) return r
                try { Thread.sleep(gap) } catch (e: InterruptedException) { return null }
            }
            return null
        }
    }

    private var cursor: CursorView? = null
    private val mainH = Handler(Looper.getMainLooper())

    private fun ensureCursor() {
        if (cursor != null) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
            val accent = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)].accent
            val v = CursorView(this, accent)
            val lp = WindowManager.LayoutParams(
                -1, -1,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            cursor = v
        } catch (e: Exception) {}
    }

    /** Shows the mouse arrow at a screen position with a short caption (works over any app). */
    fun pointer(x: Int, y: Int, label: String, click: Boolean = false) {
        mainH.post { ensureCursor(); cursor?.moveTo(x.toFloat(), y.toFloat(), label, click) }
    }

    /** For tasks with no exact spot (opening an app, a call...): the arrow glides to mid-screen with a caption. */
    fun hint(label: String) {
        val m = resources.displayMetrics
        pointer(m.widthPixels / 2, (m.heightPixels * 0.55f).toInt(), label)
    }

    private fun pointAt(n: AccessibilityNodeInfo?, label: String, click: Boolean) {
        if (n == null) return
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return
        pointer(r.centerX(), r.centerY(), label, click)
        try { Thread.sleep(if (click) 650 else 500) } catch (e: InterruptedException) {}
    }

    private fun removeCursor() {
        val v = cursor ?: return
        cursor = null
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) {}
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; mainH.post { removeCursor() }; return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; removeCursor(); super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    fun typeText(text: String, append: Boolean): String {
        val done = retry {
            val root = rootInActiveWindow ?: return@retry null
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
                ?: findEditable(root) ?: return@retry null
            pointAt(node, "WRITE", false)
            val old = if (append && !node.isShowingHintText) (node.text?.toString() ?: "") else ""
            val b = Bundle()
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + text)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        }
        return if (done == true) "Text likh diya." else "Koi text box nahi mila ya text nahi likha ja saka."
    }

    private fun gestureTap(x: Float, y: Float, hold: Long = 80): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, hold)).build()
        return dispatchGesture(g, null, null)
    }

    fun tapText(label: String): String {
        val done = retry {
            val root = rootInActiveWindow ?: return@retry null
            val hits = root.findAccessibilityNodeInfosByText(label)
            for (h in hits) {
                var n: AccessibilityNodeInfo? = h
                while (n != null && !n.isClickable) n = n.parent
                if (n != null) {
                    pointAt(n, "TAP: " + label.take(18), true)
                    if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return@retry true
                }
            }
            // nothing clickable around it: touch the spot where the text is
            for (h in hits) {
                val r = Rect()
                h.getBoundsInScreen(r)
                if (!r.isEmpty && h.isVisibleToUser) {
                    pointer(r.centerX(), r.centerY(), "TAP: " + label.take(18), true)
                    try { Thread.sleep(650) } catch (e: InterruptedException) {}
                    if (gestureTap(r.centerX().toFloat(), r.centerY().toFloat())) return@retry true
                }
            }
            null
        }
        return if (done == true) "'$label' dba diya." else "Screen par '$label' nahi mila."
    }

    fun key(k: String): String {
        val m = resources.displayMetrics
        val w = m.widthPixels
        val h = m.heightPixels
        when (k.lowercase()) {
            "back" -> pointer((w * 0.2f).toInt(), (h * 0.96f).toInt(), "BACK", true)
            "home" -> pointer(w / 2, (h * 0.96f).toInt(), "HOME", true)
            "recents" -> pointer((w * 0.8f).toInt(), (h * 0.96f).toInt(), "RECENTS", true)
            "notifications" -> pointer(w / 2, (h * 0.03f).toInt(), "NOTIFICATIONS", true)
            "scroll_down" -> pointer(w / 2, (h * 0.6f).toInt(), "SCROLL DOWN", false)
            "scroll_up" -> pointer(w / 2, (h * 0.4f).toInt(), "SCROLL UP", false)
        }
        try { Thread.sleep(550) } catch (e: InterruptedException) {}
        val ok = when (k.lowercase()) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "scroll_down", "scroll_up" -> scroll(k.lowercase() == "scroll_down")
            "lock" -> if (android.os.Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else false
            "screenshot" -> if (android.os.Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT) else false
            "quick_settings" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
            "power_menu" -> performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
            else -> return "Yeh key samajh nahi aayi: $k"
        }
        return if (ok) "Ho gaya." else "Nahi ho saka."
    }

    private fun scrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) scrollable(n.getChild(i))?.let { return it }
        return null
    }

    private fun scroll(down: Boolean): Boolean {
        val s = scrollable(rootInActiveWindow) ?: return false
        return s.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    /** Takes a picture of what is on the screen right now (Android 11+). Returns a base64 JPEG, or null. */
    @android.annotation.SuppressLint("NewApi")
    fun screenshotB64(): String? {
        if (android.os.Build.VERSION.SDK_INT < 30) return null
        // hide the arrow for a moment so it is not in the picture
        mainH.post { cursor?.visibility = android.view.View.INVISIBLE }
        try { Thread.sleep(250) } catch (e: InterruptedException) {}
        val latch = java.util.concurrent.CountDownLatch(1)
        var out: String? = null
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, java.util.concurrent.Executors.newSingleThreadExecutor(),
                object : TakeScreenshotCallback {
                    override fun onSuccess(r: ScreenshotResult) {
                        try {
                            val hb = r.hardwareBuffer
                            val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                            var bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                            hb.close()
                            if (bmp != null) {
                                val big = maxOf(bmp.width, bmp.height)
                                if (big > 1800) {
                                    val k = 1800f / big
                                    bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * k).toInt(), (bmp.height * k).toInt(), true)
                                }
                                val bo = java.io.ByteArrayOutputStream()
                                bmp.compress(Bitmap.CompressFormat.JPEG, 88, bo)
                                out = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
                            }
                        } catch (e: Exception) {}
                        latch.countDown()
                    }

                    override fun onFailure(errorCode: Int) { latch.countDown() }
                })
            latch.await(6, java.util.concurrent.TimeUnit.SECONDS)
        } catch (e: Exception) {}
        mainH.post { cursor?.visibility = android.view.View.VISIBLE }
        return out
    }

    private fun collectPictures(n: AccessibilityNodeInfo?, into: MutableList<AccessibilityNodeInfo>, minW: Int, minH: Int) {
        if (n == null) return
        val cls = n.className?.toString() ?: ""
        val desc = n.contentDescription?.toString()?.lowercase() ?: ""
        if (cls.contains("ImageView") || desc.contains("photo") || desc.contains("image") || desc.contains("picture") || desc.contains("sticker")) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (n.isVisibleToUser && r.width() >= minW && r.height() >= minH) into.add(n)
        }
        for (i in 0 until n.childCount) collectPictures(n.getChild(i), into, minW, minH)
    }

    /** Opens a big picture in the current chat or list (the newest one by default, or the first visible). */
    fun tapImage(which: String): String {
        val m = resources.displayMetrics
        val done = retry(6, 500) {
            val root = rootInActiveWindow ?: return@retry null
            val list = ArrayList<AccessibilityNodeInfo>()
            collectPictures(root, list, (m.widthPixels * 0.25f).toInt(), (m.heightPixels * 0.08f).toInt())
            if (list.isEmpty()) return@retry null
            val rects = list.map { n -> Rect().also { r -> n.getBoundsInScreen(r) } }
            val idx = if (which.lowercase() == "first") rects.indices.minByOrNull { rects[it].top }!! else rects.indices.maxByOrNull { rects[it].bottom }!!
            val node = list[idx]
            val r = rects[idx]
            pointer(r.centerX(), r.centerY(), "OPEN IMAGE", true)
            try { Thread.sleep(650) } catch (e: InterruptedException) {}
            var c: AccessibilityNodeInfo? = node
            while (c != null && !c.isClickable) c = c.parent
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return@retry true
            val p = Path().apply { moveTo(r.centerX().toFloat(), r.centerY().toFloat()) }
            val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 80)).build()
            if (dispatchGesture(g, null, null)) true else null
        }
        try { Thread.sleep(1200) } catch (e: InterruptedException) {}
        return if (done == true) "Picture khol di." else "Screen par koi badi picture nahi mili."
    }

    /** Everything visible on screen with its position, so the assistant can choose where to tap (x, y are 0 to 1). */
    fun listScreen(): String {
        val m = resources.displayMetrics
        val sb = StringBuilder()
        var n = 0
        fun walk(nd: AccessibilityNodeInfo?) {
            if (nd == null || n >= 70) return
            val t = (nd.text?.toString() ?: nd.contentDescription?.toString())?.trim()
            val r = Rect()
            nd.getBoundsInScreen(r)
            val useful = nd.isVisibleToUser && !r.isEmpty && (!t.isNullOrBlank() || nd.isClickable || nd.isEditable)
            if (useful) {
                n++
                sb.append(String.format(java.util.Locale.ENGLISH, "[x=%.2f y=%.2f] ", r.centerX().toFloat() / m.widthPixels, r.centerY().toFloat() / m.heightPixels))
                if (nd.isEditable) sb.append("(text box) ") else if (nd.isClickable) sb.append("(tap) ")
                sb.append(t?.take(60) ?: (nd.className?.toString()?.substringAfterLast('.') ?: "item")).append('\n')
            }
            for (i in 0 until nd.childCount) walk(nd.getChild(i))
        }
        walk(rootInActiveWindow)
        return if (sb.isEmpty()) "Screen par kuch nahi mila (ho sakta hai app screen chhupa rahi ho). look_at_screen try karo." else sb.toString()
    }

    /** Touches a spot given as fractions of the screen (x across, y down, both 0 to 1). */
    fun tapXY(x: Double, y: Double, long: Boolean): String {
        val m = resources.displayMetrics
        val px = (x.coerceIn(0.0, 1.0) * m.widthPixels).toFloat()
        val py = (y.coerceIn(0.0, 1.0) * m.heightPixels).toFloat()
        pointer(px.toInt(), py.toInt(), if (long) "HOLD" else "TAP", true)
        try { Thread.sleep(650) } catch (e: InterruptedException) {}
        val ok = gestureTap(px, py, if (long) 900 else 80)
        try { Thread.sleep(500) } catch (e: InterruptedException) {}
        return if (ok) "Dba diya." else "Touch nahi ho saka."
    }

    /** Drags a finger across the screen: up, down, left or right (swipe up scrolls a list down). */
    fun swipe(direction: String): String {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val d = direction.lowercase()
        val (x1, y1, x2, y2) = when (d) {
            "up" -> listOf(w / 2, h * 0.72f, w / 2, h * 0.28f)
            "down" -> listOf(w / 2, h * 0.28f, w / 2, h * 0.72f)
            "left" -> listOf(w * 0.8f, h / 2, w * 0.2f, h / 2)
            "right" -> listOf(w * 0.2f, h / 2, w * 0.8f, h / 2)
            else -> return "Direction up, down, left ya right ho."
        }
        pointer(x1.toInt(), y1.toInt(), "SWIPE " + d.uppercase(), false)
        try { Thread.sleep(500) } catch (e: InterruptedException) {}
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 350)).build()
        val ok = dispatchGesture(g, null, null)
        try { Thread.sleep(600) } catch (e: InterruptedException) {}
        return if (ok) "Ho gaya." else "Swipe nahi ho saka."
    }

    /** Package name of the app that is on screen now. */
    fun currentPackage(): String? = try { rootInActiveWindow?.packageName?.toString() } catch (e: Exception) { null }

    fun readScreen(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 1800) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) sb.append(t.trim()).append(" | ")
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return if (sb.isEmpty()) "Screen par kuch parha nahi gaya." else sb.toString()
    }
}
