package com.anjoo.assistant

import java.net.HttpURLConnection

/** Thrown when the user pressed Stop. A RuntimeException so the network retry loops (which catch IOException) never retry it. */
class CancelledException : RuntimeException("Stopped")

/** Lets the Stop button cancel a running reply at once: it closes the open network calls and flags the run. */
object Cancel {
    @Volatile var requested = false
    private val conns = HashSet<HttpURLConnection>()

    /** Start of a new run. */
    fun begin() { synchronized(conns) { conns.clear() }; requested = false }

    /** End of a run (so background voice/Telegram runs are never affected by an old Stop). */
    fun end() { requested = false; synchronized(conns) { conns.clear() } }

    fun track(c: HttpURLConnection) {
        synchronized(conns) { if (conns.size > 20) conns.clear(); conns.add(c) }
        if (requested) kill(c)
    }

    fun check() { if (requested) throw CancelledException() }

    /** Cancels now. Safe to call from the UI thread. */
    fun stop() {
        requested = true
        val all = synchronized(conns) { conns.toList() }
        Thread { all.forEach { kill(it) } }.start()
    }

    private fun kill(c: HttpURLConnection) { try { c.disconnect() } catch (e: Exception) {} }

    /** Sleeps in short slices so a Stop interrupts it. */
    fun sleep(ms: Long) {
        var left = ms
        while (left > 0) { check(); val s = minOf(left, 150L); Thread.sleep(s); left -= s }
    }
}
