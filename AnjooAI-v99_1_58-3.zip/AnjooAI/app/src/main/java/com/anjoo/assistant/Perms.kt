package com.anjoo.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/** Every runtime permission the app can use, so "Grant all" asks for all of them in one go. */
object Perms {
    fun all(): Array<String> {
        val l = ArrayList<String>()
        l += Manifest.permission.RECORD_AUDIO
        l += Manifest.permission.CALL_PHONE
        l += Manifest.permission.SEND_SMS
        l += Manifest.permission.READ_SMS
        l += Manifest.permission.READ_CONTACTS
        l += Manifest.permission.WRITE_CONTACTS
        l += Manifest.permission.READ_CALENDAR
        l += Manifest.permission.WRITE_CALENDAR
        l += Manifest.permission.READ_CALL_LOG
        l += Manifest.permission.READ_PHONE_STATE
        l += Manifest.permission.ACCESS_FINE_LOCATION
        l += Manifest.permission.ACCESS_COARSE_LOCATION
        l += Manifest.permission.CAMERA
        if (Build.VERSION.SDK_INT >= 33) {
            l += Manifest.permission.POST_NOTIFICATIONS
            l += Manifest.permission.READ_MEDIA_IMAGES
            l += Manifest.permission.READ_MEDIA_VIDEO
            l += Manifest.permission.READ_MEDIA_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 31) l += Manifest.permission.BLUETOOTH_CONNECT
        return l.toTypedArray()
    }

    fun missing(ctx: Context): Array<String> =
        all().filter { ctx.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()
}
