package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Starred answers: kept on this phone, newest first, at most 200. */
object Stars {
    class S(val id: Long, val text: String, val chat: String, val ts: Long)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    fun list(ctx: Context): List<S> = try {
        val a = JSONArray(prefs(ctx).getString("stars", "[]"))
        (0 until a.length()).map { val o = a.getJSONObject(it); S(o.getLong("id"), o.getString("t"), o.optString("c"), o.optLong("ts")) }
    } catch (e: Exception) { emptyList() }

    private fun save(ctx: Context, l: List<S>) {
        val a = JSONArray()
        for (s in l.take(200)) a.put(JSONObject().put("id", s.id).put("t", s.text).put("c", s.chat).put("ts", s.ts))
        prefs(ctx).edit().putString("stars", a.toString()).apply()
    }

    fun has(ctx: Context, text: String) = list(ctx).any { it.text == text }

    /** Stars the text, or removes the star when it is already starred. Returns true when it is now starred. */
    @Synchronized fun toggle(ctx: Context, text: String, chat: String): Boolean {
        val l = list(ctx)
        if (l.any { it.text == text }) { save(ctx, l.filter { it.text != text }); return false }
        val now = System.currentTimeMillis()
        save(ctx, listOf(S(now, text, chat, now)) + l)
        return true
    }

    fun remove(ctx: Context, id: Long) = save(ctx, list(ctx).filter { it.id != id })
}
