package com.anjoo.assistant

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Status dashboard: every permission Anjoo can use, ON/OFF at a glance, with a one-tap shortcut to the right phone setting. */
class PermissionsActivity : Activity() {

    companion object {
        /** One-line status for the menu, e.g. "🟢 Storage  🔴 Accessibility  🟢 Notification access". */
        fun quick(ctx: Context): String {
            fun on(k: String) = (try { Settings.Secure.getString(ctx.contentResolver, k) ?: "" } catch (e: Exception) { "" }).contains(ctx.packageName)
            val items = listOf(
                "Storage" to (FileAccess.allFiles(ctx) || FileAccess.treeUri(ctx) != null),
                "Accessibility" to on("enabled_accessibility_services"),
                "Notification access" to on("enabled_notification_listeners")
            )
            return items.joinToString("  ") { (if (it.second) "🟢 " else "🔴 ") + it.first }
        }
    }

    private class Row(val title: String, val why: String, val on: Boolean, val open: () -> Unit)

    private lateinit var list: LinearLayout
    private lateinit var summary: TextView
    private val GREEN = Color.parseColor("#3DDC84")
    private val RED = Color.parseColor("#FF5C5C")

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        Touch.feedback(window.decorView, ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0F1512")); setPadding(dp(16), dp(36), dp(16), dp(16)) }
        root.addView(TextView(this).apply { text = "Permissions & status"; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        summary = TextView(this).apply { textSize = 14f; setTextColor(Color.parseColor("#B8C7BE")); setPadding(0, dp(6), 0, dp(12)) }
        root.addView(summary)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        root.addView(Button(this).apply { text = "Done"; isAllCaps = false; setOnClickListener { finish() } },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        setContentView(ScrollView(this).apply { addView(root); setBackgroundColor(Color.parseColor("#0F1512")) })
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onRequestPermissionsResult(req: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(req, perms, res)
        // Denied for good (Android no longer shows the question): go straight to this app's settings page.
        if (perms.isNotEmpty() && res.isNotEmpty() && res[0] != PackageManager.PERMISSION_GRANTED && !shouldShowRequestPermissionRationale(perms[0])) appSettings()
        refresh()
    }

    private fun appSettings() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) } catch (e: Exception) { toast("Settings nahi khuli.") }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun go(i: Intent, fallback: Intent? = null) {
        try { startActivity(i) } catch (e: Exception) {
            try { if (fallback != null) startActivity(fallback) else appSettings() } catch (e2: Exception) { toast("Settings nahi khuli.") }
        }
    }

    private fun has(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun runtime(p: String): () -> Unit = { if (has(p)) appSettings() else requestPermissions(arrayOf(p), 5) }

    private fun enabledIn(secureKey: String): Boolean {
        val v = try { Settings.Secure.getString(contentResolver, secureKey) ?: "" } catch (e: Exception) { "" }
        return v.contains(packageName)
    }

    private fun rows(): List<Row> {
        val out = ArrayList<Row>()
        out.add(Row("Storage", FileAccess.status(this).lineSequence().first(), FileAccess.allFiles(this) || FileAccess.treeUri(this) != null) {
            startActivity(Intent(this, StorageActivity::class.java))
        })
        out.add(Row("Accessibility", "Type, tap and read screen in other apps", enabledIn("enabled_accessibility_services")) {
            Toast.makeText(this, "Open Downloaded apps > Anjoo AI. If blocked: App info > menu > Allow restricted settings.", Toast.LENGTH_LONG).show()
            go(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        out.add(Row("Notification access", "Read messages and reply to them", enabledIn("enabled_notification_listeners")) {
            go(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        out.add(Row("Grant all permissions", "Asks for everything below in one go", Perms.missing(this).isEmpty()) {
            val m = Perms.missing(this)
            if (m.isEmpty()) appSettings() else requestPermissions(m, 6)
        })
        out.add(Row("Microphone", "Voice commands and wake word", has(Manifest.permission.RECORD_AUDIO), runtime(Manifest.permission.RECORD_AUDIO)))
        out.add(Row("Phone calls", "Call a contact (always asks you first)", has(Manifest.permission.CALL_PHONE), runtime(Manifest.permission.CALL_PHONE)))
        out.add(Row("Send SMS", "Send a text (always asks you first)", has(Manifest.permission.SEND_SMS), runtime(Manifest.permission.SEND_SMS)))
        out.add(Row("Read SMS", "Read your latest messages", has(Manifest.permission.READ_SMS), runtime(Manifest.permission.READ_SMS)))
        out.add(Row("Contacts", "Find phone numbers by name", has(Manifest.permission.READ_CONTACTS), runtime(Manifest.permission.READ_CONTACTS)))
        out.add(Row("Calendar", "Read today's events", has(Manifest.permission.READ_CALENDAR), runtime(Manifest.permission.READ_CALENDAR)))
        out.add(Row("Calendar (add events)", "Create events directly", has(Manifest.permission.WRITE_CALENDAR), runtime(Manifest.permission.WRITE_CALENDAR)))
        out.add(Row("Contacts (edit)", "Save new contacts", has(Manifest.permission.WRITE_CONTACTS), runtime(Manifest.permission.WRITE_CONTACTS)))
        out.add(Row("Call log", "Read recent calls", has(Manifest.permission.READ_CALL_LOG), runtime(Manifest.permission.READ_CALL_LOG)))
        out.add(Row("Phone state", "Know when a call is active", has(Manifest.permission.READ_PHONE_STATE), runtime(Manifest.permission.READ_PHONE_STATE)))
        out.add(Row("Location", "Where am I, navigation, nearby help", has(Manifest.permission.ACCESS_FINE_LOCATION), runtime(Manifest.permission.ACCESS_FINE_LOCATION)))
        out.add(Row("Camera", "Take photos inside apps", has(Manifest.permission.CAMERA), runtime(Manifest.permission.CAMERA)))
        if (Build.VERSION.SDK_INT >= 33) {
            out.add(Row("Photos, videos and audio", "Read your media files", has(Manifest.permission.READ_MEDIA_IMAGES), runtime(Manifest.permission.READ_MEDIA_IMAGES)))
        }
        if (Build.VERSION.SDK_INT >= 31) {
            out.add(Row("Bluetooth", "Connect to paired devices", has(Manifest.permission.BLUETOOTH_CONNECT), runtime(Manifest.permission.BLUETOOTH_CONNECT)))
        }
        if (Build.VERSION.SDK_INT >= 33) {
            out.add(Row("Notifications", "Reminders and alerts from Anjoo", has(Manifest.permission.POST_NOTIFICATIONS), runtime(Manifest.permission.POST_NOTIFICATIONS)))
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            out.add(Row("Exact alarms", "Reminders at the exact minute", am.canScheduleExactAlarms()) {
                go(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
            })
        }
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        out.add(Row("Run in background", "Keeps live voice and Telegram alive", pm.isIgnoringBatteryOptimizations(packageName)) {
            go(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")), Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        out.add(Row("Display over other apps", "Pointer arrow while Anjoo works", Settings.canDrawOverlays(this)) {
            go(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        return out
    }

    private fun refresh() {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val rs = rows()
        summary.text = rs.count { it.on }.toString() + " of " + rs.size + " active. Tap the button next to any item to open its setting."
        list.removeAllViews()
        for (r in rs) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(8), dp(10))
                background = GradientDrawable().apply { setColor(Color.parseColor("#16201B")); cornerRadius = dp(14).toFloat() }
            }
            row.addView(TextView(this).apply { text = "●"; textSize = 18f; setTextColor(if (r.on) GREEN else RED); setPadding(0, 0, dp(10), 0) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply { text = r.title + "  ·  " + (if (r.on) "ON" else "OFF"); textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
            col.addView(TextView(this).apply { text = r.why; textSize = 12f; setTextColor(Color.parseColor("#9FB0A6")) })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(Button(this).apply {
                text = if (r.on) "Settings" else "Allow"; isAllCaps = false; textSize = 12f
                minWidth = 0; minimumWidth = 0
                setOnClickListener { r.open() }
            })
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }
}
