package com.anjoo.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Small syntax highlighter (no libraries). Colours keywords, strings, comments, numbers, functions, types,
 * HTML tags/attributes, CSS properties and JSON keys. Works on any language; unknown ones get the C-like rules.
 */
object Hl {

    val def = Color.parseColor("#E6EDF3")
    private val cCom = Color.parseColor("#8B949E")
    private val cKw = Color.parseColor("#FF7B72")
    private val cStr = Color.parseColor("#A5D6FF")
    private val cNum = Color.parseColor("#79C0FF")
    private val cFn = Color.parseColor("#D2A8FF")
    private val cType = Color.parseColor("#FFA657")
    private val cTag = Color.parseColor("#7EE787")
    private val cAttr = Color.parseColor("#79C0FF")
    val gutterColor = Color.parseColor("#6E7681")

    /** Above this size the text is shown without colours so big files stay smooth. */
    private const val LIMIT = 60000

    private val KW_C = setOf(
        "abstract", "as", "async", "await", "break", "case", "catch", "class", "const", "continue", "data", "default", "do",
        "else", "enum", "export", "extends", "false", "final", "finally", "for", "fun", "function", "if", "implements",
        "import", "in", "interface", "is", "lateinit", "let", "new", "null", "object", "open", "override", "package",
        "private", "protected", "public", "return", "sealed", "static", "struct", "super", "switch", "this", "throw",
        "throws", "true", "try", "typeof", "undefined", "val", "var", "void", "when", "while", "yield", "impl", "fn",
        "mut", "pub", "use", "mod", "trait", "match", "func", "defer", "chan", "nil", "int", "long", "string", "bool",
        "boolean", "double", "float", "char", "byte", "short", "namespace", "using", "template", "virtual", "readonly",
        "declare", "companion", "suspend", "internal", "typealias", "elif", "foreach", "instanceof", "delete", "extern",
        "typedef", "unsigned", "signed", "inline", "operator", "explicit", "synchronized", "volatile", "transient",
        "native", "goto", "with", "type", "let", "echo", "isset", "unset", "list", "global", "dyn", "ref", "where"
    )
    private val KW_PY = setOf(
        "and", "as", "assert", "async", "await", "break", "class", "continue", "def", "del", "elif", "else", "except",
        "False", "finally", "for", "from", "global", "if", "import", "in", "is", "lambda", "None", "nonlocal", "not",
        "or", "pass", "raise", "return", "True", "try", "while", "with", "yield", "self", "print"
    )
    private val KW_SH = setOf(
        "if", "then", "else", "elif", "fi", "for", "do", "done", "while", "case", "esac", "function", "in", "echo",
        "export", "local", "return", "exit", "cd", "source", "true", "false"
    )
    private val KW_RB = setOf(
        "def", "end", "class", "module", "if", "elsif", "else", "unless", "while", "until", "for", "in", "do", "begin",
        "rescue", "ensure", "return", "yield", "self", "nil", "true", "false", "and", "or", "not", "require", "puts"
    )
    private val KW_DATA = setOf("true", "false", "null", "yes", "no", "on", "off")
    private val KW_SQL = setOf(
        "select", "from", "where", "insert", "into", "values", "update", "set", "delete", "create", "table", "drop",
        "alter", "join", "left", "right", "inner", "outer", "on", "group", "by", "order", "having", "limit", "as", "and",
        "or", "not", "null", "primary", "key", "foreign", "references", "index", "distinct", "union", "count", "sum",
        "avg", "min", "max", "like", "in", "between", "is", "default", "integer", "text", "varchar", "real", "boolean",
        "if", "exists", "unique", "autoincrement", "desc", "asc", "case", "when", "then", "else", "end"
    )

    private fun family(l: String): String = when (l) {
        "html", "htm", "xml", "svg", "xhtml", "vue", "xaml" -> "html"
        "css", "scss", "less" -> "css"
        "json", "jsonc", "geojson" -> "json"
        "py", "python", "rb", "ruby", "sh", "bash", "shell", "zsh", "yaml", "yml", "toml", "ini", "dockerfile",
        "makefile", "mk", "r", "pl", "env", "properties" -> "hash"
        "sql" -> "sql"
        "md", "markdown", "text", "txt", "log", "output", "console", "" -> "plain"
        else -> "c"
    }

    private fun keywords(l: String): Set<String> = when (l) {
        "py", "python" -> KW_PY
        "sh", "bash", "shell", "zsh" -> KW_SH
        "rb", "ruby" -> KW_RB
        "yaml", "yml", "toml", "ini", "properties", "env" -> KW_DATA
        "sql" -> KW_SQL
        else -> KW_C
    }

    private fun put(sb: SpannableStringBuilder, color: Int, from: Int, to: Int) {
        if (to > from) sb.setSpan(ForegroundColorSpan(color), from, to, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    private fun eol(s: String, i: Int, to: Int): Int {
        val k = s.indexOf('\n', i)
        return if (k < 0 || k > to) to else k
    }

    /** [lang] can be a language name (kotlin, js, html) or a file name (index.html, Main.kt). */
    fun span(code: String, lang: String): SpannableStringBuilder {
        val sb = SpannableStringBuilder(code)
        if (code.length > LIMIT) return sb
        val l = lang.lowercase().trim().substringAfterLast('.')
        try {
            val fam = family(l)
            when (fam) {
                "html" -> scanHtml(code, 0, code.length, sb)
                "css" -> scanCss(code, 0, code.length, sb)
                "json" -> scanJson(code, 0, code.length, sb)
                "plain" -> {}
                else -> scanCode(code, 0, code.length, l, fam, sb)
            }
        } catch (e: Exception) {
        }
        return sb
    }

    private fun scanCode(s: String, from: Int, to: Int, lang: String, fam: String, sb: SpannableStringBuilder) {
        val kw = keywords(lang)
        val hash = fam == "hash"
        val sql = fam == "sql"
        val rust = lang == "rs" || lang == "rust"
        var i = from
        while (i < to) {
            val c = s[i]
            if (c == '/' && !hash && !sql && i + 1 < to) {
                val n = s[i + 1]
                if (n == '/') { val e = eol(s, i, to); put(sb, cCom, i, e); i = e; continue }
                if (n == '*') {
                    val k = s.indexOf("*/", i + 2)
                    val e = if (k < 0 || k + 2 > to) to else k + 2
                    put(sb, cCom, i, e); i = e; continue
                }
            }
            if ((hash && c == '#') || (sql && c == '-' && i + 1 < to && s[i + 1] == '-')) {
                val e = eol(s, i, to); put(sb, cCom, i, e); i = e; continue
            }
            if (c == '"' || c == '\'' || (c == '`' && !sql)) {
                if (rust && c == '\'' && !(i + 2 < to && s[i + 2] == '\'') && !(i + 1 < to && s[i + 1] == '\\')) { i++; continue }
                var e = i + 1
                val triple = c != '`' && i + 2 < to && s[i + 1] == c && s[i + 2] == c
                if (triple) {
                    val k = s.indexOf("" + c + c + c, i + 3)
                    e = if (k < 0 || k + 3 > to) to else k + 3
                } else {
                    val multi = c == '`'
                    while (e < to) {
                        val d = s[e]
                        if (d == '\\' && !sql) { e += 2; continue }
                        if (d == c) { e++; break }
                        if (d == '\n' && !multi) break
                        e++
                    }
                    if (e > to) e = to
                }
                put(sb, cStr, i, e); i = e; continue
            }
            if (c.isDigit() && (i == from || !(s[i - 1].isLetterOrDigit() || s[i - 1] == '_'))) {
                var e = i + 1
                while (e < to && (s[e].isLetterOrDigit() || s[e] == '.' || s[e] == '_')) e++
                while (e > i + 1 && s[e - 1] == '.') e--
                put(sb, cNum, i, e); i = e; continue
            }
            if (c.isLetter() || c == '_' || c == '$' || c == '@') {
                var e = i + 1
                while (e < to && (s[e].isLetterOrDigit() || s[e] == '_' || s[e] == '$')) e++
                val w = s.substring(i, e)
                val key = if (sql) w.lowercase() else w
                var k = e
                while (k < to && (s[k] == ' ' || s[k] == '\t')) k++
                if (key in kw) put(sb, cKw, i, e)
                else if (c == '@') put(sb, cType, i, e)
                else if (k < to && s[k] == '(') put(sb, cFn, i, e)
                else if (c.isUpperCase() && w.length > 1) put(sb, cType, i, e)
                i = e; continue
            }
            i++
        }
    }

    private fun scanCss(s: String, from: Int, to: Int, sb: SpannableStringBuilder) {
        var i = from
        var depth = 0
        while (i < to) {
            val c = s[i]
            if (c == '/' && i + 1 < to && s[i + 1] == '*') {
                val k = s.indexOf("*/", i + 2)
                val e = if (k < 0 || k + 2 > to) to else k + 2
                put(sb, cCom, i, e); i = e; continue
            }
            if (c == '"' || c == '\'') {
                var e = i + 1
                while (e < to && s[e] != c && s[e] != '\n') { if (s[e] == '\\') e++; e++ }
                e = minOf(e + 1, to)
                put(sb, cStr, i, e); i = e; continue
            }
            if (c == '{') { depth++; i++; continue }
            if (c == '}') { if (depth > 0) depth--; i++; continue }
            if (c == '@') {
                var e = i + 1
                while (e < to && (s[e].isLetterOrDigit() || s[e] == '-')) e++
                put(sb, cKw, i, e); i = e; continue
            }
            if (c == '#' && depth > 0) {
                var e = i + 1
                while (e < to && (s[e].isLetterOrDigit())) e++
                put(sb, cNum, i, e); i = e; continue
            }
            if (c.isDigit() || (c == '.' && depth > 0 && i + 1 < to && s[i + 1].isDigit())) {
                var e = i + 1
                while (e < to && (s[e].isLetterOrDigit() || s[e] == '.' || s[e] == '%')) e++
                put(sb, cNum, i, e); i = e; continue
            }
            if (c == '.' || c == '#') {
                var e = i + 1
                while (e < to && (s[e].isLetterOrDigit() || s[e] == '-' || s[e] == '_')) e++
                put(sb, cFn, i, e); i = e; continue
            }
            if (c.isLetter() || c == '-' || c == '_') {
                var e = i + 1
                while (e < to && (s[e].isLetterOrDigit() || s[e] == '-' || s[e] == '_')) e++
                var k = e
                while (k < to && (s[k] == ' ' || s[k] == '\t')) k++
                if (depth > 0) {
                    if (k < to && s[k] == ':') put(sb, cAttr, i, e)
                    else if (k < to && s[k] == '(') put(sb, cFn, i, e)
                } else put(sb, cTag, i, e)
                i = e; continue
            }
            i++
        }
    }

    private fun scanJson(s: String, from: Int, to: Int, sb: SpannableStringBuilder) {
        var i = from
        while (i < to) {
            val c = s[i]
            if (c == '"') {
                var e = i + 1
                while (e < to) {
                    val d = s[e]
                    if (d == '\\') { e += 2; continue }
                    if (d == '"') { e++; break }
                    if (d == '\n') break
                    e++
                }
                if (e > to) e = to
                var k = e
                while (k < to && (s[k] == ' ' || s[k] == '\t')) k++
                put(sb, if (k < to && s[k] == ':') cAttr else cStr, i, e)
                i = e; continue
            }
            if (c.isDigit() || (c == '-' && i + 1 < to && s[i + 1].isDigit())) {
                var e = i + 1
                while (e < to && (s[e].isDigit() || s[e] == '.' || s[e] == 'e' || s[e] == 'E' || s[e] == '+' || s[e] == '-')) e++
                put(sb, cNum, i, e); i = e; continue
            }
            if (c.isLetter()) {
                var e = i + 1
                while (e < to && s[e].isLetter()) e++
                val w = s.substring(i, e)
                if (w == "true" || w == "false" || w == "null") put(sb, cKw, i, e)
                i = e; continue
            }
            i++
        }
    }

    private fun scanHtml(s: String, from: Int, to: Int, sb: SpannableStringBuilder) {
        var i = from
        while (i < to) {
            val lt = s.indexOf('<', i)
            if (lt < 0 || lt >= to) break
            if (s.startsWith("<!--", lt)) {
                val k = s.indexOf("-->", lt + 4)
                val e = if (k < 0 || k + 3 > to) to else k + 3
                put(sb, cCom, lt, e); i = e; continue
            }
            var j = lt + 1
            if (j < to && (s[j] == '/' || s[j] == '!' || s[j] == '?')) j++
            val nameStart = j
            while (j < to && (s[j].isLetterOrDigit() || s[j] == '-' || s[j] == ':' || s[j] == '_')) j++
            if (j == nameStart) { i = lt + 1; continue }
            put(sb, cTag, lt, j)
            val tagName = s.substring(nameStart, j).lowercase()
            val closing = s[lt + 1] == '/'
            var k = j
            while (k < to && s[k] != '>') {
                val ch = s[k]
                if (ch == '"' || ch == '\'') {
                    var e = k + 1
                    while (e < to && s[e] != ch) e++
                    e = minOf(e + 1, to)
                    put(sb, cStr, k, e); k = e; continue
                }
                if (ch.isLetter() || ch == '_' || ch == ':' || ch == '@') {
                    var e = k + 1
                    while (e < to && (s[e].isLetterOrDigit() || s[e] == '-' || s[e] == '_' || s[e] == ':' || s[e] == '.')) e++
                    put(sb, cAttr, k, e); k = e; continue
                }
                k++
            }
            if (k < to) put(sb, cTag, k, k + 1)
            i = if (k < to) k + 1 else to
            if (!closing && (tagName == "script" || tagName == "style")) {
                val endTag = s.indexOf("</" + tagName, i, true)
                val e = if (endTag < 0 || endTag > to) to else endTag
                if (tagName == "script") scanCode(s, i, e, "js", "c", sb) else scanCss(s, i, e, sb)
                i = e
            }
        }
    }
}

/** A code viewer: line numbers on the left, highlighted code on the right. Put [view] inside a HorizontalScrollView. */
class CodePane(ctx: Context, size: Float = 12f, selectable: Boolean = false) {
    val gutter = TextView(ctx)
    val code = TextView(ctx)
    val view = LinearLayout(ctx)

    init {
        val d = ctx.resources.displayMetrics.density
        gutter.typeface = Typeface.MONOSPACE
        code.typeface = Typeface.MONOSPACE
        gutter.textSize = size
        code.textSize = size
        gutter.setTextColor(Hl.gutterColor)
        gutter.gravity = Gravity.END
        gutter.setPadding((8 * d).toInt(), (6 * d).toInt(), (6 * d).toInt(), (6 * d).toInt())
        code.setTextColor(Hl.def)
        code.setPadding((8 * d).toInt(), (6 * d).toInt(), (14 * d).toInt(), (6 * d).toInt())
        if (selectable) code.setTextIsSelectable(true)
        view.orientation = LinearLayout.HORIZONTAL
        view.addView(gutter, LinearLayout.LayoutParams(-2, -2))
        view.addView(code, LinearLayout.LayoutParams(-2, -2))
    }

    /** [lang] may be a language name or a file name. */
    fun set(text: String, lang: String) {
        code.text = Hl.span(text, lang)
        val n = text.count { it == '\n' } + 1
        val sb = StringBuilder()
        for (k in 1..n) {
            if (k > 1) sb.append('\n')
            sb.append(k)
        }
        gutter.text = sb.toString()
    }

    fun text(): String = code.text.toString()
}
