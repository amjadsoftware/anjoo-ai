package com.anjoo.assistant

/**
 * A confirmation request travels as one string so existing (String) -> Boolean callbacks keep working:
 *   "§kind§Title\nDetails"   (plain old messages still work and count as kind "action").
 * The chat shows it as a card with Confirm / Cancel; voice mode reads title + details aloud.
 */
object Confirm {
    class Req(val kind: String, val title: String, val detail: String) {
        /** Deleting or overwriting always asks, even with "Do it without asking" on. */
        val strict get() = kind == "delete" || kind == "overwrite" || kind == "shell"
        val icon get() = when (kind) { "call" -> "📞"; "sms" -> "✉️"; "reply" -> "💬"; "delete" -> "🗑"; "overwrite" -> "⚠️"; "shell" -> "⌨️"; else -> "❓" }
        val danger get() = strict
    }

    fun msg(kind: String, title: String, detail: String = ""): String = "§$kind§$title\n$detail"

    fun parse(raw: String): Req {
        if (raw.startsWith("§")) {
            val end = raw.indexOf('§', 1)
            if (end > 1) {
                val rest = raw.substring(end + 1)
                return Req(raw.substring(1, end), rest.substringBefore('\n').trim(), rest.substringAfter('\n', "").trim())
            }
        }
        return Req("action", raw.substringBefore('\n').trim(), raw.substringAfter('\n', "").trim())
    }

    /** Spoken / plain version. */
    fun plain(raw: String): String { val r = parse(raw); return r.title + (if (r.detail.isNotEmpty()) ". " + r.detail else "") }
}
