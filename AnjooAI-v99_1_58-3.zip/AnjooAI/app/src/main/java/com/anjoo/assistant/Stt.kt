package com.anjoo.assistant

import android.content.SharedPreferences
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Speech-to-text for the "ear" engine.
 * When a Groq key is saved, Groq's free Whisper is tried first (large daily free allowance, no card needed).
 * If Groq fails, or there is no Groq key, Gemini is used when a Gemini key exists.
 */
object Stt {

    private const val GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions"
    private const val GROQ_MODEL = "whisper-large-v3-turbo"

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    // Whisper sometimes "hears" these in silence or noise.
    private val HALLUCINATIONS = setOf(
        "you", "thank you", "thank you.", "thanks", "thanks for watching", "thanks for watching!",
        "bye", "bye.", "okay", "ok", "."
    )

    fun groqKey(p: SharedPreferences): String = Providers.savedKey(p, "groq")

    /** True when at least one speech-to-text service has a key. */
    fun available(p: SharedPreferences): Boolean =
        groqKey(p).isNotBlank() || Providers.geminiKey(p).isNotBlank()

    /** Turns 16 kHz mono PCM into text. Returns "" when there was no clear speech. Throws on network/API errors. */
    fun transcribe(p: SharedPreferences, pcm: ByteArray, lang: String): String {
        val groq = groqKey(p)
        val gemini = Providers.geminiKey(p)
        if (groq.isNotBlank()) {
            try {
                return groqWhisper(groq, pcm, lang)
            } catch (e: Exception) {
                if (gemini.isBlank()) throw e
                // otherwise fall through to Gemini
            }
        }
        if (gemini.isBlank()) return ""
        val model = p.getString("sttModel", null) ?: "gemini-3.5-flash-lite"
        return Gemini.transcribe(gemini, model, pcm, lang)
    }

    private fun groqWhisper(key: String, pcm: ByteArray, lang: String): String {
        val wav = Ear.wav(Gemini.boost(pcm))
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", "speech.wav", wav.toRequestBody("audio/wav".toMediaType()))
            .addFormDataPart("model", GROQ_MODEL)
            .addFormDataPart("temperature", "0")
            .addFormDataPart("response_format", "json")
        if (lang == "en-US") {
            body.addFormDataPart("language", "en")
        } else {
            // No fixed language: Whisper follows the prompt's style, so a Roman Urdu prompt keeps Latin letters.
            body.addFormDataPart(
                "prompt",
                "Anjoo, WhatsApp kholo. Ammi ko call karo. Subah 6 baje alarm laga do. YouTube par search karo."
            )
        }
        val request = Request.Builder()
            .url(GROQ_URL)
            .header("Authorization", "Bearer $key")
            .post(body.build())
            .build()
        client.newCall(request).execute().use { r ->
            val raw = r.body?.string().orEmpty()
            if (!r.isSuccessful) {
                val detail = try { JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty() } catch (e: Exception) { "" }
                val hint = when (r.code) {
                    401 -> "Groq ki API key galat hai."
                    429 -> "Groq ki free limit poori ho gayi. Thori der baad try karein."
                    else -> detail.ifBlank { raw.take(120) }
                }
                throw IOException("(${r.code}) $hint")
            }
            val text = try { JSONObject(raw).optString("text").trim() } catch (e: Exception) { "" }
            val clean = text.trim('"', ' ')
            return if (clean.length < 2 || clean.lowercase() in HALLUCINATIONS) "" else clean
        }
    }
}
