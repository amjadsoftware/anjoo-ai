package com.anjoo.assistant

import android.content.SharedPreferences
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Cloud voices that need their own key: ElevenLabs and Microsoft Azure Speech. Both return raw 16-bit PCM at 24 kHz. */
object CloudVoice {
    const val RATE = 24000

    class Engine(val kind: String, val key: String, val voice: String, val model: String, val region: String = "")

    /** The cloud voice to use now, or null when no ElevenLabs/Azure key is saved. ElevenLabs wins when both exist. */
    fun engine(p: SharedPreferences): Engine? {
        try { Providers.load(p) } catch (e: Exception) { }
        val el = Providers.allKeys(p, "elevenlabs").firstOrNull()
        if (!el.isNullOrBlank()) {
            val male = p.getString("voiceGender", "female") == "male"
            val voice = p.getString("elevenVoice", "")?.trim().orEmpty()
                .ifBlank { if (male) "pNInz6obpgDQGcFmaJgB" else "EXAVITQu4vr4xnSDxMaL" }
            return Engine("elevenlabs", el.trim(), voice, Providers.savedModel(p, "elevenlabs").ifBlank { "eleven_multilingual_v2" })
        }
        val az = Providers.allKeys(p, "azuretts").firstOrNull()
        if (!az.isNullOrBlank() && az.contains(':')) {
            val region = az.substringBefore(':').trim().lowercase()
            val key = az.substringAfter(':').trim()
            if (region.isNotEmpty() && key.isNotEmpty())
                return Engine("azure", key, Providers.savedModel(p, "azuretts").ifBlank { "ur-PK-UzmaNeural" }, "", region)
        }
        return null
    }

    fun synth(e: Engine, text: String): Pair<ByteArray, Int> =
        if (e.kind == "elevenlabs") elevenLabs(e, text) else azure(e, text)

    private fun readAll(c: HttpURLConnection, what: String): ByteArray {
        val code = c.responseCode
        val bytes = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes() } ?: ByteArray(0)
        if (code !in 200..299) throw IOException("$what $code")
        if (bytes.size < 200) throw IOException("$what empty")
        return bytes
    }

    private fun elevenLabs(e: Engine, text: String): Pair<ByteArray, Int> {
        val c = URL("https://api.elevenlabs.io/v1/text-to-speech/" + e.voice + "?output_format=pcm_24000").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 40000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("xi-api-key", e.key)
        val body = JSONObject().put("text", text).put("model_id", e.model).toString()
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        return Pair(readAll(c, "elevenlabs"), RATE)
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")

    private fun azure(e: Engine, text: String): Pair<ByteArray, Int> {
        val lang = e.voice.split("-").take(2).joinToString("-").ifBlank { "en-US" }
        val ssml = "<speak version='1.0' xml:lang='$lang'><voice name='${esc(e.voice)}'>${esc(text)}</voice></speak>"
        val c = URL("https://" + e.region + ".tts.speech.microsoft.com/cognitiveservices/v1").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 40000; c.doOutput = true
        c.setRequestProperty("Ocp-Apim-Subscription-Key", e.key)
        c.setRequestProperty("Content-Type", "application/ssml+xml")
        c.setRequestProperty("X-Microsoft-OutputFormat", "raw-24khz-16bit-mono-pcm")
        c.setRequestProperty("User-Agent", "AnjooAI")
        c.outputStream.use { it.write(ssml.toByteArray(Charsets.UTF_8)) }
        return Pair(readAll(c, "azure"), RATE)
    }

    /** Key test for the keys screen. Throws "HTTP code" when the key is refused. */
    fun check(id: String, key: String) {
        val c: HttpURLConnection
        if (id == "elevenlabs") {
            c = URL("https://api.elevenlabs.io/v1/user").openConnection() as HttpURLConnection
            c.setRequestProperty("xi-api-key", key.trim())
        } else {
            val region = key.substringBefore(':', "").trim().lowercase()
            val k = key.substringAfter(':', "").trim()
            if (region.isEmpty() || k.isEmpty()) throw IOException("HTTP 400")
            c = URL("https://$region.api.cognitive.microsoft.com/sts/v1.0/issueToken").openConnection() as HttpURLConnection
            c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Ocp-Apim-Subscription-Key", k)
            c.setRequestProperty("Content-Length", "0")
            c.outputStream.use { }
        }
        c.connectTimeout = 15000; c.readTimeout = 20000
        val code = c.responseCode
        if (code !in 200..299) throw IOException("HTTP $code")
    }
}
