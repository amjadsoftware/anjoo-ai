package com.anjoo.assistant

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.RemoteViews

/** Home screen widget: New chat, Voice and Starred answers in one tap. */
class AnjooWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_anjoo)
        rv.setOnClickPendingIntent(R.id.w_new, tap(ctx, "new", 1))
        rv.setOnClickPendingIntent(R.id.w_voice, tap(ctx, "voice", 2))
        rv.setOnClickPendingIntent(R.id.w_stars, tap(ctx, "stars", 3))
        for (id in ids) mgr.updateAppWidget(id, rv)
    }

    private fun tap(ctx: Context, action: String, code: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .setData(Uri.parse("anjoo://widget/$action"))
            .putExtra("widget_action", action)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
