package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** A WebView that serves a project's files from https://app.local/, so pages, css, scripts and images link up. */
object ProjectWeb {

    fun create(ctx: Context, base: File): WebView {
        val wv = WebView(ctx)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true      // localStorage + IndexedDB, kept on the phone between launches
        @Suppress("DEPRECATION") run { wv.settings.databaseEnabled = true }
        wv.tag = base
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        wv.setBackgroundColor(Color.WHITE)
        wv.webChromeClient = WebChromeClient()
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                return PreviewServer.serve(base, u)
            }
        }
        return wv
    }

    /** Opens the main page, or [page] (a path inside the project). */
    fun load(wv: WebView, page: String? = null) {
        val base = wv.tag as? File
        val origin = if (base != null) PreviewServer.origin(base) else "https://app.local/"
        wv.loadUrl(origin + if (page == null) "" else Uri.encode(page, "/"))
    }
}

/**
 * Full-screen preview of a whole project (all its pages, styles and scripts) with the chat-style actions:
 * reload, pages, download as zip, and open in Code Studio. Opened from the project card in the chat.
 */
class ProjectPreviewActivity : Activity() {
    private lateinit var dir: File
    private var wv: WebView? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        dir = File(intent.getStringExtra("project") ?: "")
        if (!dir.isDirectory || PreviewServer.entry(dir) == null) {
            Toast.makeText(this, "Is project ka preview nahi ban sakta.", Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.WHITE) }
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#1B1B1F"))
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        fun btn(label: String, a: () -> Unit) = TextView(this).apply {
            text = label; textSize = 14f; setTextColor(Color.WHITE)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { a() }
        }
        bar.addView(btn("✕") { finish() })
        bar.addView(TextView(this).apply {
            text = Coder.name(dir); textSize = 14f; setTextColor(Color.WHITE)
            maxLines = 1; typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(btn("⟳") { wv?.reload() })
        if (PreviewServer.pages(dir).size > 1) bar.addView(btn("📄") { pickPage() })
        bar.addView(btn("⬇") { download() })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2))
        val w = ProjectWeb.create(this, dir)
        wv = w
        root.addView(w, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        ProjectWeb.load(w)
    }

    private fun pickPage() {
        val pages = PreviewServer.pages(dir)
        AlertDialog.Builder(this)
            .setTitle("Pages")
            .setItems(pages.toTypedArray()) { _, i -> wv?.let { ProjectWeb.load(it, pages[i]) } }
            .show()
    }

    private fun download() {
        val slug = Coder.name(dir).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "project" }
        Thread {
            val bytes = try { Coder.zip(dir) } catch (e: Exception) { null }
            runOnUiThread {
                if (bytes == null) Toast.makeText(this, "Zip nahi ban saki.", Toast.LENGTH_SHORT).show()
                else Dl.save(this, "$slug.zip", bytes)
            }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (requestCode != 77 || resultCode != RESULT_OK || uri == null) return
        Thread {
            val ok = try {
                contentResolver.openOutputStream(uri)?.use { it.write(Coder.zip(dir)) }
                true
            } catch (e: Exception) { false }
            runOnUiThread { Toast.makeText(this, if (ok) "Zip save ho gayi." else "Zip save nahi ho saki.", Toast.LENGTH_SHORT).show() }
        }.start()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val w = wv
        if (w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        try { wv?.destroy() } catch (e: Exception) { }
        super.onDestroy()
    }
}
