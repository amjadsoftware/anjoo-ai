package com.anjoo.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/** Thin rounded outline icons (camera, photo, file) drawn in code, in the clean style used by Claude. */
class LineIcon(ctx: Context, private val kind: Int, color: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; this.color = color
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val r = RectF()

    /** Changes the icon colour (used for the selected thumbs). */
    fun setTint(c: Int) { p.color = c; invalidate() }

    private fun filePath() = Path().apply {
        moveTo(13.5f, 3.5f); lineTo(6.8f, 3.5f); quadTo(5f, 3.5f, 5f, 5.3f); lineTo(5f, 18.7f)
        quadTo(5f, 20.5f, 6.8f, 20.5f); lineTo(17.2f, 20.5f); quadTo(19f, 20.5f, 19f, 18.7f)
        lineTo(19f, 9f); close()
    }

    private fun thumb() = Path().apply {
        moveTo(4.5f, 10.5f); lineTo(7.5f, 10.5f); lineTo(7.5f, 19.5f); lineTo(4.5f, 19.5f); close()
        moveTo(7.5f, 10.5f); lineTo(11f, 4.6f); quadTo(13.6f, 4.6f, 13.4f, 7f); lineTo(12.9f, 9.5f)
        lineTo(17.8f, 9.5f); quadTo(20f, 9.5f, 19.6f, 11.6f); lineTo(18.5f, 17.8f)
        quadTo(18.2f, 19.5f, 16.5f, 19.5f); lineTo(7.5f, 19.5f)
    }

    override fun onDraw(c: Canvas) {
        val s = min(width, height) / 24f
        c.save()
        c.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        c.scale(s, s)
        p.strokeWidth = 1.7f
        when (kind) {
            0 -> { // camera
                r.set(3f, 7f, 21f, 20f); c.drawRoundRect(r, 3.2f, 3.2f, p)
                val t = Path().apply { moveTo(8.2f, 7f); lineTo(9.6f, 4.6f); lineTo(14.4f, 4.6f); lineTo(15.8f, 7f) }
                c.drawPath(t, p)
                c.drawCircle(12f, 13.5f, 3.4f, p)
            }
            1 -> { // photo
                r.set(3f, 4f, 21f, 20f); c.drawRoundRect(r, 3.2f, 3.2f, p)
                c.drawCircle(8.6f, 9.4f, 1.7f, p)
                val m = Path().apply { moveTo(3.4f, 17f); lineTo(9f, 12.2f); lineTo(13f, 15.8f); lineTo(16f, 13.4f); lineTo(20.6f, 17.6f) }
                c.drawPath(m, p)
            }
            3 -> { // clock
                c.drawCircle(12f, 12f, 8.6f, p)
                val h = Path().apply { moveTo(12f, 7.2f); lineTo(12f, 12f); lineTo(15.4f, 14f) }
                c.drawPath(h, p)
            }
            4 -> { // zip file
                c.drawPath(filePath(), p)
                val f = Path().apply { moveTo(13.5f, 3.5f); lineTo(13.5f, 7.4f); quadTo(13.5f, 9f, 15.1f, 9f); lineTo(19f, 9f) }
                c.drawPath(f, p)
                c.drawLine(10.6f, 4.2f, 10.6f, 6.2f, p)
                c.drawLine(10.6f, 7.6f, 10.6f, 9.6f, p)
                c.drawLine(10.6f, 11f, 10.6f, 13f, p)
                r.set(9.2f, 14.4f, 12f, 18.4f); c.drawRoundRect(r, 1f, 1f, p)
            }
            5 -> { // copy
                r.set(4.5f, 8.5f, 15.5f, 20.5f); c.drawRoundRect(r, 2.4f, 2.4f, p)
                val b = Path().apply {
                    moveTo(8.5f, 8.5f); lineTo(8.5f, 6.5f); quadTo(8.5f, 4.5f, 10.5f, 4.5f); lineTo(17.5f, 4.5f)
                    quadTo(19.5f, 4.5f, 19.5f, 6.5f); lineTo(19.5f, 13.5f); quadTo(19.5f, 15.5f, 17.5f, 15.5f); lineTo(15.5f, 15.5f)
                }
                c.drawPath(b, p)
            }
            6 -> { // speaker
                val sp = Path().apply { moveTo(4f, 9.6f); lineTo(8f, 9.6f); lineTo(12.5f, 5.6f); lineTo(12.5f, 18.4f); lineTo(8f, 14.4f); lineTo(4f, 14.4f); close() }
                c.drawPath(sp, p)
                r.set(9.5f, 8f, 17f, 16f); c.drawArc(r, -50f, 100f, false, p)
                r.set(7f, 4.6f, 20f, 19.4f); c.drawArc(r, -50f, 100f, false, p)
            }
            7 -> c.drawPath(thumb(), p) // like
            8 -> { c.save(); c.scale(1f, -1f, 12f, 12f); c.drawPath(thumb(), p); c.restore() } // dislike
            9 -> { // retry
                r.set(3f, 3f, 21f, 21f); c.drawArc(r, 19.5f, 295.5f, false, p)
                val a = Path().apply { moveTo(18.37f, 5.64f); lineTo(21.8f, 9f); moveTo(21.8f, 4f); lineTo(21.8f, 9f); lineTo(16.8f, 9f) }
                c.drawPath(a, p)
            }
            10 -> { val a = Path().apply { moveTo(9f, 5.5f); lineTo(15.5f, 12f); lineTo(9f, 18.5f) }; c.drawPath(a, p) } // arrow right
            11 -> { // download
                c.drawLine(12f, 4f, 12f, 15f, p)
                val a = Path().apply { moveTo(7f, 10.5f); lineTo(12f, 15.5f); lineTo(17f, 10.5f) }
                c.drawPath(a, p)
                c.drawLine(5f, 19.5f, 19f, 19.5f, p)
            }
            12 -> { // more
                p.style = Paint.Style.FILL
                c.drawCircle(5.5f, 12f, 1.6f, p); c.drawCircle(12f, 12f, 1.6f, p); c.drawCircle(18.5f, 12f, 1.6f, p)
                p.style = Paint.Style.STROKE
            }
            13 -> { // eye
                val e = Path().apply { moveTo(2.5f, 12f); quadTo(12f, 3f, 21.5f, 12f); quadTo(12f, 21f, 2.5f, 12f); close() }
                c.drawPath(e, p); c.drawCircle(12f, 12f, 2.8f, p)
            }
            14 -> { // arrow up
                c.drawLine(12f, 19f, 12f, 5.5f, p)
                val a = Path().apply { moveTo(6f, 11.5f); lineTo(12f, 5.5f); lineTo(18f, 11.5f) }
                c.drawPath(a, p)
            }
            else -> { // file
                val d = Path().apply {
                    moveTo(13.5f, 3.5f); lineTo(6.8f, 3.5f); quadTo(5f, 3.5f, 5f, 5.3f); lineTo(5f, 18.7f)
                    quadTo(5f, 20.5f, 6.8f, 20.5f); lineTo(17.2f, 20.5f); quadTo(19f, 20.5f, 19f, 18.7f)
                    lineTo(19f, 9f); close()
                }
                c.drawPath(d, p)
                val f = Path().apply { moveTo(13.5f, 3.5f); lineTo(13.5f, 7.4f); quadTo(13.5f, 9f, 15.1f, 9f); lineTo(19f, 9f) }
                c.drawPath(f, p)
                c.drawLine(8.6f, 13.4f, 15.4f, 13.4f, p)
                c.drawLine(8.6f, 16.8f, 13.2f, 16.8f, p)
            }
        }
        c.restore()
    }
}

/** Drawn glyphs for the round main button: 14 = send arrow, 15 = sound waves, 16 = stop square. */
class GlyphDrawable(private val kind: Int, private val color: Int) : android.graphics.drawable.Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND }
    override fun draw(c: Canvas) {
        val b = bounds
        val s = min(b.width(), b.height()) / 24f
        c.save()
        c.translate(b.left + (b.width() - 24f * s) / 2f, b.top + (b.height() - 24f * s) / 2f)
        c.scale(s, s)
        p.color = color
        when (kind) {
            14 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 2.4f
                c.drawLine(12f, 19f, 12f, 5.5f, p)
                val a = Path().apply { moveTo(6f, 11.5f); lineTo(12f, 5.5f); lineTo(18f, 11.5f) }
                c.drawPath(a, p)
            }
            15 -> {
                p.style = Paint.Style.STROKE; p.strokeWidth = 2.2f
                val xs = floatArrayOf(4.5f, 8.25f, 12f, 15.75f, 19.5f)
                val hs = floatArrayOf(2f, 5.5f, 8.5f, 4.5f, 2f)
                for (i in xs.indices) c.drawLine(xs[i], 12f - hs[i], xs[i], 12f + hs[i], p)
            }
            else -> {
                p.style = Paint.Style.FILL
                val r = RectF(7f, 7f, 17f, 17f); c.drawRoundRect(r, 2f, 2f, p)
            }
        }
        c.restore()
    }
    override fun setAlpha(a: Int) { p.alpha = a }
    override fun setColorFilter(f: android.graphics.ColorFilter?) { p.colorFilter = f }
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
}
