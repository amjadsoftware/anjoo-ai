package com.anjoo.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Matrix
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView

/** Full-screen picture with pinch to zoom, drag to move and double-tap to zoom in or out. */
class ZoomImageView(ctx: Context) : ImageView(ctx) {
    private val m = Matrix()
    private val vals = FloatArray(9)
    private var base = 1f
    private var lastX = 0f
    private var lastY = 0f
    private var dragging = false

    /** Called on a single tap (the viewer uses it to show or hide its buttons). */
    var onTap: (() -> Unit)? = null

    private val scaler = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            val cur = scale()
            val f = (cur * d.scaleFactor).coerceIn(base, base * 6f) / cur
            m.postScale(f, f, d.focusX, d.focusY)
            fix()
            imageMatrix = m
            return true
        }
    })

    private val taps = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val target = if (scale() > base * 1.2f) base else base * 2.5f
            val f = target / scale()
            m.postScale(f, f, e.x, e.y)
            fix()
            imageMatrix = m
            return true
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            onTap?.invoke()
            return true
        }
    })

    init { scaleType = ScaleType.MATRIX }

    private fun scale(): Float { m.getValues(vals); return vals[Matrix.MSCALE_X] }

    fun show(b: Bitmap) {
        setImageBitmap(b)
        fit()
    }

    private fun fit() {
        val d = drawable ?: return
        if (width == 0 || height == 0) return
        val dw = d.intrinsicWidth.toFloat()
        val dh = d.intrinsicHeight.toFloat()
        base = minOf(width / dw, height / dh)
        m.reset()
        m.postScale(base, base)
        m.postTranslate((width - dw * base) / 2f, (height - dh * base) / 2f)
        imageMatrix = m
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fit()
    }

    /** Keeps the picture from being dragged out of view, and centres it when it is smaller than the screen. */
    private fun fix() {
        val d = drawable ?: return
        m.getValues(vals)
        val s = vals[Matrix.MSCALE_X]
        val w = d.intrinsicWidth * s
        val h = d.intrinsicHeight * s
        var tx = vals[Matrix.MTRANS_X]
        var ty = vals[Matrix.MTRANS_Y]
        tx = if (w <= width) (width - w) / 2f else tx.coerceIn(width - w, 0f)
        ty = if (h <= height) (height - h) / 2f else ty.coerceIn(height - h, 0f)
        vals[Matrix.MTRANS_X] = tx
        vals[Matrix.MTRANS_Y] = ty
        m.setValues(vals)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scaler.onTouchEvent(e)
        taps.onTouchEvent(e)
        if (!scaler.isInProgress) {
            when (e.actionMasked) {
                MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1) {
                    if (dragging) {
                        m.postTranslate(e.x - lastX, e.y - lastY)
                        fix()
                        imageMatrix = m
                    }
                    lastX = e.x
                    lastY = e.y
                    dragging = true
                }
                MotionEvent.ACTION_DOWN -> { lastX = e.x; lastY = e.y; dragging = true }
                MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_POINTER_UP -> dragging = false
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
            }
        } else dragging = false
        return true
    }

    override fun performClick(): Boolean = super.performClick()
}
