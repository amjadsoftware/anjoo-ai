package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.regex.Pattern

/**
 * The Code Studio toolbox: the same moves a careful engineer makes in a terminal, on a Code Studio project.
 * Explore (tree, search), read with line numbers, make exact edits, check/run/test, and keep history
 * (undo, diff, named checkpoints). Every tool works on one project; a blank `project` means the newest one.
 */
object CodeTools {

    val NAMES = setOf(
        "project_tree", "project_read", "project_write", "project_edit", "project_search",
        "project_replace", "project_manage", "project_check", "project_history", "project_template", "project_studio"
    )

    private const val CAP = 14000
    private const val NO_PROJECT = "Koi Code Studio project nahi mila. project_template ya write_code se naya project banao."

    fun run(ctx: Context, confirm: (String) -> Boolean, name: String, a: JSONObject): String? {
        if (name !in NAMES) return null
        return try {
            when (name) {
                "project_template" -> template(ctx, a)
                "project_manage" -> manage(ctx, confirm, a)
                "project_studio" -> studio(ctx, confirm, a)
                else -> {
                    val (dir, err) = find(ctx, a)
                    if (dir == null) return err
                    when (name) {
                        "project_tree" -> tree(dir)
                        "project_read" -> read(dir, a)
                        "project_write" -> write(ctx, dir, a)
                        "project_edit" -> edit(ctx, dir, a)
                        "project_search" -> search(dir, a)
                        "project_replace" -> replace(ctx, dir, a)
                        "project_check" -> check(ctx, dir, a)
                        else -> history(ctx, dir, a)
                    }
                }
            }
        } catch (e: Exception) {
            "Tool nakam: " + (e.message ?: e.javaClass.simpleName)
        }
    }


    // ------------------------------------------------------------------ chat-first Code Studio controls

    /**
     * Exposes the remaining Code Studio quick actions to the main chat, where a project card
     * is also rendered after a project_* tool call. No extra editor screen is required for the
     * usual preview/run/export/history workflow.
     */
    private fun studio(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val action = a.optString("action", "preview").trim().lowercase().replace(' ', '_').replace('-', '_')
        if (action in setOf("deep_think", "think", "thinking")) {
            val prefs = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
            val current = prefs.getBoolean("codeThink", true)
            val requested = a.optString("value", "toggle").trim().lowercase()
            val next = when (requested) {
                "on", "true", "yes", "enable", "enabled" -> true
                "off", "false", "no", "disable", "disabled" -> false
                "status", "check" -> current
                else -> !current
            }
            if (requested !in setOf("status", "check") && next != current) prefs.edit().putBoolean("codeThink", next).apply()
            return "Code Studio Deep Think: " + (if (next) "ON" else "OFF") +
                if (requested in setOf("status", "check")) " (status only; unchanged)." else "."
        }
        if (action in setOf("list", "list_projects", "projects"))
            return manage(ctx, confirm, JSONObject(a.toString()).put("action", "list_projects"))

        // The Code Studio prompt enhancer is also available from the main chat, even before a project exists.
        if (action in setOf("enhance_prompt", "improve_prompt", "polish_prompt")) {
            val request = a.optString("message", a.optString("instruction", a.optString("value", ""))).trim()
            if (request.isBlank()) return "Prompt improve karne ke liye message ya instruction do."
            val all = Coder.list(ctx)
            val hint = a.optString("project", "").trim()
            val project = if (hint.isBlank()) all.firstOrNull() else (
                all.firstOrNull { it.name.equals(hint, true) }
                    ?: all.firstOrNull { Coder.name(it).equals(hint, true) || Coder.name(it).contains(hint, true) }
                )
            val info = project?.let { d ->
                "Project: " + Coder.name(d) + "\nFiles: " + Coder.readFiles(d).keys.take(100).joinToString(", ")
            } ?: ""
            return PromptMaker.improve(ctx, request, info).ifBlank {
                "Prompt improve nahi ho saka. API key aur network check karein, phir dobara koshish karein."
            }
        }

        // New-project Build mode mirrors Code Studio's Build tab but keeps the result in this chat.
        if (action in setOf("build", "build_project", "new_project")) {
            val task = a.optString("message", a.optString("instruction", a.optString("value", ""))).trim()
            if (task.isBlank()) return "Naya project banane ke liye message mein requirements do."
            val language = a.optString("language", "auto").ifBlank { "auto" }
            val (built, notes) = Coder.build(ctx, task, language, true, Coder.deepDefault(ctx), {}, {})
            return "PROJECT_BUILT: '" + Coder.name(built) + "' tayyar hai (" + Coder.readFiles(built).size + " files). Chat mein project card, file list, preview aur ZIP download dikhaya jayega.\n" + notes
        }

        val (dir, err) = find(ctx, a)
        if (dir == null) return err

        val message = a.optString("message", a.optString("instruction", a.optString("value", ""))).trim()
        if (action in setOf("ask", "explain", "ask_about_project")) {
            if (message.isBlank()) return "Project ke baare mein sawal message mein do."
            return Coder.ask(ctx, dir, message, Coder.deepDefault(ctx))
        }
        if (action in setOf("edit", "revise", "apply_change")) {
            if (message.isBlank()) return "Project mein kya badalna hai, message mein likhein."
            val result = Coder.revise(ctx, dir, message, Coder.deepDefault(ctx), {}, {})
            return "PROJECT_EDITED: '" + Coder.name(dir) + "'\n" + result
        }
        val preset = when (action) {
            "find_bugs", "review_bugs" -> "Review the whole project for bugs, edge cases and crashes. Fix every real problem you find and list what you fixed."
            "optimize", "performance" -> "Optimize performance and clean the code without changing behaviour. Explain what improved."
            "add_tests", "tests" -> "Add automated tests (or a test page / test script for web projects) covering the main features and edge cases."
            "better_ui", "polish_ui" -> "Make the interface look more polished and professional: spacing, typography, colors, animations and mobile friendliness. Keep all features."
            "security", "security_review" -> "Do a security review (input validation, XSS, secrets, unsafe storage) and fix the issues you find."
            "cleanup", "clean_up", "refactor" -> "Refactor for readability: clear names, small functions, helpful comments. Keep behaviour identical."
            "responsive", "mobile_friendly" -> "Make it fully responsive and touch friendly for phones, tablets and desktop."
            else -> ""
        }
        if (preset.isNotBlank()) return "PROJECT_EDITED: '" + Coder.name(dir) + "'\n" + Coder.revise(ctx, dir, preset, Coder.deepDefault(ctx), {}, {})

        return when (action) {
            "preview", "show_preview", "preview_in_chat" -> {
                val entry = PreviewServer.entry(dir)
                    ?: return "Is project mein HTML/HTM entry page nahi mili; inline browser preview sirf web projects ke liye hai."
                val pages = PreviewServer.pages(dir)
                if (ctx is MainActivity) {
                    "PREVIEW_READY: '" + Coder.name(dir) + "' ka in-chat preview tayyar hai. Entry: " + entry +
                        "; pages: " + pages.size + ". Is chat reply ke project card mein Preview, Full screen, Download ZIP aur Code Studio actions honge."
                } else {
                    Coder.show(ctx, dir)
                    "Preview khol diya: '" + Coder.name(dir) + "' (" + pages.size + " HTML page(s))."
                }
            }
            "run_python", "python" -> {
                val entry = PyRun.entry(dir) ?: return "Is project mein run karne ke liye Python (.py) entry nahi mili."
                val syntaxOnly = PyRun.needsSyntaxOnly(dir)
                val r = PyRun.run(ctx, dir, entry, syntaxOnly)
                if (!r.loaded) return "Python runtime load nahi hua; pehli dafa internet chahiye."
                if (!r.finished) return "Python run waqt par khatam nahi hua (60-second limit). Mumkin hai program input ka intezar kar raha ho ya endless loop ho."
                buildString {
                    append("PYTHON RUN: ").append(entry).append('\n')
                    if (syntaxOnly) append("NOTE: project ki kuch libraries is runtime mein unsupported hain; sirf syntax check hua.\n")
                    if (r.out.isNotBlank()) append("STDOUT:\n").append(r.out.trim().take(9000)).append('\n')
                    if (r.err.isNotBlank()) append("STDERR:\n").append(r.err.trim().takeLast(5000)).append('\n')
                    if (r.out.isBlank() && r.err.isBlank()) append("Program chala; koi output nahi mila.")
                }.trim()
            }
            "run", "run_project", "test", "test_project", "lint", "check", "fix_preview_errors", "debug_preview" -> {
                val checkAction = when (action) {
                    "test", "test_project" -> "test"
                    "lint", "check" -> "lint"
                    else -> "run"
                }
                val result = check(ctx, dir, JSONObject().put("action", checkAction))
                if (action in setOf("fix_preview_errors", "debug_preview"))
                    "Preview/runtime diagnostics for '" + Coder.name(dir) + "':\n" + result +
                        "\nIf errors are reported, fix the actual files and run this check again; report only verified results."
                else result
            }
            "undo" -> history(ctx, dir, JSONObject().put("action", "undo"))
            "diff" -> history(ctx, dir, JSONObject().put("action", "diff"))
            "history", "log" -> history(ctx, dir, JSONObject().put("action", "log"))
            "checkpoint", "save_checkpoint" -> history(ctx, dir, JSONObject().put("action", "checkpoint").put("message", a.optString("message", "Saved from chat")))
            "restore" -> history(ctx, dir, JSONObject().put("action", "restore").put("id", a.optInt("id", -1)))
            "compare_checkpoint" -> history(ctx, dir, JSONObject().put("action", "compare").put("id", a.optInt("id", -1)))
            "stats", "deps", "format" -> manage(ctx, confirm, JSONObject(a.toString()).put("action", action))
            "export_zip", "download_zip" -> FileAccess.tool(ctx, confirm, "export_project",
                JSONObject().put("project", Coder.name(dir)).put("as_zip", true).put("folder", a.optString("folder", "")))
                ?: "ZIP export tool unavailable."
            "export_html", "single_html", "save_html" -> {
                val html = PreviewServer.inline(dir)
                    ?: return "Single-file HTML export ke liye web project ka HTML entry page chahiye."
                val slug = Coder.name(dir).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "website" }
                FileAccess.tool(ctx, confirm, "save_file", JSONObject()
                    .put("filename", "$slug.html").put("content", html).put("folder", a.optString("folder", "")))
                    ?: "HTML save tool unavailable."
            }
            "open_studio", "open_editor" -> {
                "Alag editor screen nahi hai: project '" + Coder.name(dir) + "' ka sab kaam isi chat mein hota hai (project_read / project_write / project_edit / project_studio)."
            }
            "rename" -> manage(ctx, confirm, JSONObject(a.toString()).put("action", "rename_project"))
            "delete" -> manage(ctx, confirm, JSONObject(a.toString()).put("action", "delete_project"))
            else -> "project_studio action chunein: build, ask, edit, enhance_prompt, find_bugs, optimize, add_tests, better_ui, security_review, cleanup, responsive, preview, run_python, run, test, lint, fix_preview_errors, undo, diff, history, checkpoint, restore, compare_checkpoint, stats, deps, format, export_zip, export_html, deep_think, open_studio, rename, delete, list_projects."
        }
    }

    // ------------------------------------------------------------------ helpers

    private fun find(ctx: Context, a: JSONObject): Pair<File?, String> {
        val all = Coder.list(ctx)
        val n = a.optString("project", "").trim()
        if (n.isEmpty()) return all.firstOrNull()?.let { Pair(it, "") } ?: Pair(null, NO_PROJECT)
        val hit = all.firstOrNull { it.name == n }
            ?: all.firstOrNull { Coder.name(it).equals(n, true) }
            ?: all.firstOrNull { Coder.name(it).contains(n, true) || it.name.contains(n, true) }
        return if (hit != null) Pair(hit, "") else Pair(null, "Is naam ka project nahi mila: $n. Projects: " + all.take(15).joinToString(", ") { Coder.name(it) })
    }

    private fun cleanPath(p: String): String? {
        val parts = p.replace('\\', '/').split('/').map { it.trim() }.filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty() || parts.any { it == ".." } || parts.size > 12) return null
        if (parts.last().startsWith(".anjoo")) return null
        return parts.joinToString("/")
    }

    private val SKIP_DIRS = setOf("node_modules", ".git", "__pycache__", "build", ".gradle")

    private fun listFiles(dir: File): List<File> =
        dir.walkTopDown().onEnter { it == dir || it.name !in SKIP_DIRS }
            .filter { it.isFile && !it.name.startsWith(".anjoo") }.take(3000).sortedBy { it.path }.toList()

    private fun rel(dir: File, f: File) = f.relativeTo(dir).path.replace('\\', '/')

    private fun isBinary(f: File): Boolean = try {
        f.inputStream().use { s -> val b = ByteArray(2000); val n = s.read(b); (0 until maxOf(n, 0)).any { b[it].toInt() == 0 } }
    } catch (e: Exception) { false }

    private fun readText(f: File): String? = if (isBinary(f)) null else try { f.readText(Charsets.UTF_8) } catch (e: Exception) { null }

    private fun textFiles(dir: File): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        for (f in listFiles(dir)) { if (f.length() > 1_500_000) continue; readText(f)?.let { out[rel(dir, f)] = it } }
        return out
    }

    /** One undo point per burst of edits: the first change after 90 quiet seconds saves the project. */
    private fun snap(ctx: Context, dir: File) {
        val f = File(File(ctx.filesDir, "undo"), dir.name + ".json")
        if (!f.exists() || System.currentTimeMillis() - f.lastModified() > 90_000) Coder.snapshot(ctx, dir)
    }

    private fun done(ctx: Context, dir: File) { dir.setLastModified(System.currentTimeMillis()); Coder.keepCopy(ctx, dir) }

    private fun cap(s: String, n: Int = CAP) = if (s.length <= n) s else s.take(n * 2 / 3) + "\n...[beech ka hissa kaat diya]...\n" + s.takeLast(n / 3)

    private fun lines(s: String): Int = if (s.isEmpty()) 0 else s.count { it == '\n' } + 1

    private fun sizeText(n: Long) = if (n < 1024) "$n B" else String.format(java.util.Locale.US, "%.1f KB", n / 1024.0)

    private fun globRegex(g: String): Regex {
        val sb = StringBuilder()
        var i = 0
        while (i < g.length) {
            val c = g[i]
            when {
                c == '*' && i + 1 < g.length && g[i + 1] == '*' -> { sb.append(".*"); i++; if (i + 1 < g.length && g[i + 1] == '/') i++ }
                c == '*' -> sb.append("[^/]*")
                c == '?' -> sb.append("[^/]")
                c == '{' -> sb.append("(")
                c == '}' -> sb.append(")")
                c == ',' -> sb.append("|")
                "\\.[]()+^$|".indexOf(c) >= 0 -> sb.append('\\').append(c)
                else -> sb.append(c)
            }
            i++
        }
        return Regex(sb.toString(), RegexOption.IGNORE_CASE)
    }

    private fun globOk(path: String, g: String): Boolean {
        if (g.isBlank()) return true
        val r = globRegex(g.trim())
        return if (g.contains('/')) r.matches(path) else r.matches(path.substringAfterLast('/'))
    }

    private fun regexOf(p: String, ignoreCase: Boolean, literal: Boolean = false): Regex {
        val opts = if (ignoreCase) setOf(RegexOption.IGNORE_CASE, RegexOption.MULTILINE) else setOf(RegexOption.MULTILINE)
        return if (literal) Regex(Regex.escape(p), opts) else try { Regex(p, opts) } catch (e: Exception) { Regex(Regex.escape(p), opts) }
    }

    /** Problems the quick checker sees in one file (empty when clean). */
    private fun quick(dir: File, path: String): String {
        val all = textFiles(dir)
        val l = Coder.lint(all).lines().filter { it.contains(path) }
        return if (l.isEmpty()) "" else "\nCHECK:\n" + l.joinToString("\n")
    }

    // ------------------------------------------------------------------ project_tree

    private fun tree(dir: File): String {
        val fs = listFiles(dir)
        if (fs.isEmpty()) return "Project '" + Coder.name(dir) + "' khaali hai."
        var total = 0
        val sb = StringBuilder()
        val shown = HashSet<String>()
        for (f in fs) {
            val p = rel(dir, f)
            val parts = p.split('/')
            for (i in 0 until parts.size - 1) {
                val d = parts.take(i + 1).joinToString("/")
                if (shown.add(d)) sb.append("  ".repeat(i)).append(parts[i]).append("/\n")
            }
            val t = if (f.length() > 1_500_000) null else readText(f)
            val ln = if (t == null) 0 else lines(t)
            total += ln
            sb.append("  ".repeat(parts.size - 1)).append(parts.last()).append("  (")
                .append(if (t == null) "binary, " + sizeText(f.length()) else "$ln lines, " + sizeText(f.length())).append(")\n")
        }
        return "PROJECT: " + Coder.name(dir) + "  [folder: " + dir.name + "]  " + fs.size + " files, ~" + total + " lines\n" + cap(sb.toString())
    }

    // ------------------------------------------------------------------ project_read

    private fun read(dir: File, a: JSONObject): String {
        val p = cleanPath(a.optString("path")) ?: return "path do (jaise src/app.js)."
        val f = File(dir, p)
        if (!f.isFile) {
            val near = listFiles(dir).map { rel(dir, it) }.filter { it.substringAfterLast('/').equals(p.substringAfterLast('/'), true) }.take(5)
            return "File nahi mili: $p." + (if (near.isNotEmpty()) " Milti julti: " + near.joinToString(", ") else " project_tree se dekho.")
        }
        val t = readText(f) ?: return "$p binary file hai (" + sizeText(f.length()) + "), text ki tarah nahi parh sakta."
        val all = t.split("\n")
        val off = a.optInt("offset", 1).coerceAtLeast(1)
        val lim = a.optInt("limit", 400).coerceIn(1, 1500)
        if (off > all.size) return "$p mein sirf " + all.size + " lines hain."
        val end = minOf(all.size, off - 1 + lim)
        val sb = StringBuilder()
        for (i in off - 1 until end) sb.append(String.format(java.util.Locale.US, "%5d\t", i + 1)).append(all[i].take(600)).append('\n')
        val more = if (end < all.size) "\n[...aur " + (all.size - end) + " lines hain: offset=" + (end + 1) + " do]" else ""
        return "FILE: $p  (" + all.size + " lines)\n" + cap(sb.toString(), 24000) + more
    }

    // ------------------------------------------------------------------ project_write

    private fun write(ctx: Context, dir: File, a: JSONObject): String {
        val p = cleanPath(a.optString("path")) ?: return "path sahi nahi (jaise src/app.js)."
        if (!a.has("content")) return "content do."
        val c = a.getString("content")
        val existed = File(dir, p).isFile
        snap(ctx, dir)
        if (!Coder.writeFile(dir, p, c)) return "File likh nahi saka: $p"
        done(ctx, dir)
        return (if (existed) "Overwrote " else "Created ") + p + " (" + lines(c) + " lines)" + quick(dir, p)
    }

    // ------------------------------------------------------------------ project_edit

    private class Ed(val old: String, val new: String, val all: Boolean)

    private fun edit(ctx: Context, dir: File, a: JSONObject): String {
        val p = cleanPath(a.optString("path")) ?: return "path do."
        val eds = ArrayList<Ed>()
        val arr = a.optJSONArray("edits")
        if (arr != null) for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            eds.add(Ed(o.optString("old_text"), o.optString("new_text"), o.optBoolean("replace_all", false)))
        }
        if (a.has("old_text") || a.has("new_text")) eds.add(Ed(a.optString("old_text"), a.optString("new_text"), a.optBoolean("replace_all", false)))
        if (eds.isEmpty()) return "old_text aur new_text do (ya edits ki list)."
        val f = File(dir, p)
        if (!f.isFile) {
            val e0 = eds.first()
            if (e0.old.isEmpty()) {
                snap(ctx, dir)
                if (!Coder.writeFile(dir, p, e0.new)) return "File nahi bani: $p"
                done(ctx, dir)
                return "Created $p (" + lines(e0.new) + " lines)" + quick(dir, p)
            }
            return "File nahi mili: $p. Pehle project_tree se path dekho."
        }
        var text = readText(f) ?: return "$p binary hai."
        val before = text
        var changed = 0
        for ((i, e) in eds.withIndex()) {
            val tag = if (eds.size > 1) "Edit " + (i + 1) + ": " else ""
            if (e.old.isEmpty()) return tag + "old_text khaali hai."
            if (e.old == e.new) return tag + "old_text aur new_text same hain."
            var n = 0; var at = 0
            while (true) { val k = text.indexOf(e.old, at); if (k < 0) break; n++; at = k + maxOf(1, e.old.length) }
            if (n == 0) {
                // forgive trailing-space / line-ending differences when the match is then unique
                val norm = { s: String -> s.replace("\r\n", "\n").split("\n").joinToString("\n") { it.trimEnd() } }
                val nt = norm(text); val no = norm(e.old)
                val k = nt.indexOf(no)
                if (no.isNotEmpty() && k >= 0 && nt.indexOf(no, k + 1) < 0) {
                    text = nt.replaceFirst(no, e.new.replace("\r\n", "\n")); changed++; continue
                }
                val first = e.old.lines().map { it.trim() }.firstOrNull { it.isNotEmpty() } ?: ""
                val ln = if (first.isEmpty()) -1 else text.lines().indexOfFirst { it.contains(first) } + 1
                return tag + "old_text file mein nahi mila (kuch badla nahi)." + (if (ln > 0) " Pehli line shayad line $ln ke aas paas hai: project_read se dekh kar BILKUL waisa hi copy karo." else " project_read se asli matn dekho.")
            }
            if (n > 1 && !e.all) return tag + "old_text " + n + " jagah mila (kuch badla nahi). Aas paas ki thori lines shamil karo, ya replace_all=true do."
            text = if (e.all) text.replace(e.old, e.new) else text.replaceFirst(e.old, e.new)
            changed += if (e.all) n else 1
        }
        if (text == before) return "Koi farq nahi pada."
        snap(ctx, dir)
        f.writeText(text, Charsets.UTF_8)
        done(ctx, dir)
        val d = Coder.lineDiff(before.split("\n"), text.split("\n"))
        val shown = d.filter { it.startsWith("+ ") || it.startsWith("- ") }.take(30)
        return "Edited $p: $changed replacement(s), +" + d.count { it.startsWith("+ ") } + " -" + d.count { it.startsWith("- ") } + "\n" + shown.joinToString("\n") { it.take(200) } + quick(dir, p)
    }

    // ------------------------------------------------------------------ project_search

    private val SYMBOLS = mapOf(
        "py" to Regex("^\\s*(?:async\\s+)?(?:def|class)\\s+\\w+.*"),
        "js" to Regex("^\\s*(?:export\\s+)?(?:default\\s+)?(?:async\\s+)?(?:function\\*?|class)\\s+\\w+.*|^\\s*(?:export\\s+)?(?:const|let|var)\\s+\\w+\\s*=\\s*(?:async\\s*)?(?:\\([^)]*\\)|\\w+)\\s*=>.*"),
        "kt" to Regex("^\\s*(?:(?:public|private|protected|internal|open|abstract|override|suspend|data|sealed|inline|const)\\s+)*(?:fun|class|interface|object)\\s+.*"),
        "java" to Regex("^\\s*(?:public|private|protected)\\s+[\\w<>\\[\\], .?]+\\s+\\w+\\s*\\(.*|^\\s*(?:public\\s+)?(?:abstract\\s+)?(?:class|interface|enum)\\s+\\w+.*"),
        "go" to Regex("^(?:func|type)\\s+.*"),
        "rs" to Regex("^\\s*(?:pub\\s+)?(?:fn|struct|enum|trait|impl)\\s+.*"),
        "php" to Regex("^\\s*(?:public|private|protected|static|abstract)?\\s*(?:function|class)\\s+\\w+.*"),
        "css" to Regex("^[^\\s@/*][^{]*\\{\\s*$|^@media.*\\{\\s*$"),
        "html" to Regex(".*\\bid\\s*=\\s*[\"'][^\"']+[\"'].*")
    )

    private fun symbolRegex(ext: String): Regex? = when (ext) {
        "py" -> SYMBOLS["py"]
        "js", "mjs", "jsx", "ts", "tsx" -> SYMBOLS["js"]
        "kt", "kts" -> SYMBOLS["kt"]
        "java", "cs", "dart", "swift" -> SYMBOLS["java"]
        "go" -> SYMBOLS["go"]
        "rs" -> SYMBOLS["rs"]
        "php" -> SYMBOLS["php"]
        "css", "scss" -> SYMBOLS["css"]
        "html", "htm" -> SYMBOLS["html"]
        else -> null
    }

    private fun search(dir: File, a: JSONObject): String {
        val mode = a.optString("mode", "grep").lowercase()
        val g = a.optString("glob", "")
        val max = a.optInt("max", 60).coerceIn(1, 300)
        if (mode == "glob") {
            val pat = a.optString("pattern", g).ifBlank { "**" }
            val hits = listFiles(dir).map { rel(dir, it) }.filter { globOk(it, pat) }
            return if (hits.isEmpty()) "Koi file match nahi hui: $pat" else hits.size.toString() + " files:\n" + cap(hits.take(max * 3).joinToString("\n"))
        }
        val files = textFiles(dir).filter { globOk(it.key, g) }
        val out = StringBuilder()
        var count = 0
        if (mode == "symbols") {
            val q = a.optString("pattern", "").trim()
            for ((p, c) in files) {
                val r = symbolRegex(p.substringAfterLast('.', "").lowercase()) ?: continue
                for ((i, l) in c.split("\n").withIndex()) {
                    if (!r.matches(l)) continue
                    if (q.isNotEmpty() && !l.contains(q, true)) continue
                    if (count++ < max) out.append(p).append(':').append(i + 1).append(": ").append(l.trim().take(140)).append('\n')
                }
            }
            return if (count == 0) "Koi function/class nahi mili." else "$count symbols:\n" + cap(out.toString())
        }
        val pattern = if (mode == "todos") "\\b(TODO|FIXME|HACK|XXX)\\b" else a.optString("pattern")
        if (pattern.isBlank()) return "pattern do."
        val re = regexOf(pattern, a.optBoolean("ignore_case", true))
        val ctxN = a.optInt("context", 0).coerceIn(0, 5)
        val filesOnly = a.optBoolean("files_only", false)
        for ((p, c) in files) {
            val ls = c.split("\n")
            var fileHit = false
            var lastShown = -1
            for (i in ls.indices) {
                if (!re.containsMatchIn(ls[i])) continue
                count++
                fileHit = true
                if (filesOnly) break
                if (count > max) continue
                val from = maxOf(maxOf(0, i - ctxN), lastShown + 1)
                if (ctxN > 0 && from > lastShown + 1 && lastShown >= 0) out.append("--\n")
                for (j in from..minOf(ls.size - 1, i + ctxN)) {
                    out.append(p).append(if (j == i) ':' else '-').append(j + 1).append(if (j == i) ": " else "- ").append(ls[j].take(220)).append('\n')
                    lastShown = j
                }
            }
            if (filesOnly && fileHit) out.append(p).append('\n')
        }
        if (count == 0) return "Koi match nahi: $pattern"
        return (if (filesOnly) "" else "$count match(es)" + (if (count > max) " (pehle $max dikhaye)" else "") + ":\n") + cap(out.toString())
    }

    // ------------------------------------------------------------------ project_replace

    private fun replace(ctx: Context, dir: File, a: JSONObject): String {
        val pat = a.optString("pattern")
        if (pat.isEmpty()) return "pattern do."
        val repl = a.optString("replacement", "")
        val literal = a.optBoolean("literal", false)
        val dry = a.optBoolean("dry_run", false)
        val re = try {
            Pattern.compile(if (literal) Pattern.quote(pat) else pat, (if (a.optBoolean("ignore_case", false)) Pattern.CASE_INSENSITIVE else 0) or Pattern.MULTILINE)
        } catch (e: Exception) { return "Regex sahi nahi: " + (e.message ?: "").take(120) }
        val rp = if (literal) java.util.regex.Matcher.quoteReplacement(repl) else repl
        val g = a.optString("glob", "")
        val changes = LinkedHashMap<String, Pair<String, Int>>()
        for ((p, c) in textFiles(dir)) {
            if (!globOk(p, g)) continue
            val m = re.matcher(c)
            var n = 0
            while (m.find()) { n++; if (m.end() == m.start() && m.end() >= c.length) break }
            if (n == 0) continue
            val nc = try { re.matcher(c).replaceAll(rp) } catch (e: Exception) { return "Replacement sahi nahi: " + (e.message ?: "").take(120) }
            if (nc != c) changes[p] = Pair(nc, n)
        }
        if (changes.isEmpty()) return "Kuch match nahi hua, kuch nahi badla."
        val summary = changes.entries.joinToString("\n") { it.key + ": " + it.value.second + " jagah" }
        if (dry) return "DRY RUN (kuch nahi badla): " + changes.size + " files:\n" + cap(summary)
        snap(ctx, dir)
        for ((p, v) in changes) File(dir, p).writeText(v.first, Charsets.UTF_8)
        done(ctx, dir)
        return "Replaced in " + changes.size + " files:\n" + cap(summary) + "\n(undo: project_history action=undo)"
    }

    // ------------------------------------------------------------------ project_manage

    private fun manage(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val act = a.optString("action", "list_projects").lowercase()
        if (act == "list_projects") {
            val all = Coder.list(ctx)
            if (all.isEmpty()) return NO_PROJECT
            return all.take(40).joinToString("\n") { d ->
                val fs = listFiles(d)
                "- " + Coder.name(d) + "  [folder: " + d.name + "]  " + fs.size + " files"
            }
        }
        val (dir, err) = find(ctx, a)
        if (dir == null) return err
        when (act) {
            "stats" -> {
                val byExt = java.util.TreeMap<String, IntArray>()
                var todo = 0
                for ((p, c) in textFiles(dir)) {
                    val e = p.substringAfterLast('.', "none").lowercase()
                    val x = byExt.getOrPut(e) { IntArray(2) }
                    x[0]++; x[1] += lines(c)
                    todo += Regex("\\b(TODO|FIXME)\\b").findAll(c).count()
                }
                val rows = byExt.entries.sortedByDescending { it.value[1] }.joinToString("\n") { "." + it.key + ": " + it.value[0] + " files, " + it.value[1] + " lines" }
                return "STATS " + Coder.name(dir) + ":\n" + rows + "\nTODO/FIXME: $todo\nCheckpoints: " + checkpoints(ctx, dir).size
            }
            "deps" -> {
                val imports = java.util.TreeSet<String>()
                for ((p, c) in textFiles(dir)) {
                    val ext = p.substringAfterLast('.', "").lowercase()
                    if (ext == "py") for (m in Regex("(?m)^\\s*(?:from|import)\\s+([A-Za-z_][\\w]*)").findAll(c)) imports.add("py: " + m.groupValues[1])
                    if (ext in setOf("js", "mjs", "jsx", "ts", "tsx")) {
                        for (m in Regex("(?:from\\s+|require\\()\\s*[\"']([^\"'.][^\"']*)[\"']").findAll(c)) imports.add("js: " + m.groupValues[1])
                    }
                    if (ext == "html") for (m in Regex("(?:src|href)\\s*=\\s*[\"'](https?://[^\"']+)[\"']").findAll(c)) imports.add("cdn: " + m.groupValues[1].take(100))
                }
                val local = listFiles(dir).map { rel(dir, it).substringBefore('/').substringBeforeLast('.') }.toSet()
                val shown = imports.filter { !local.contains(it.substringAfter(": ").substringBefore('/')) }
                return if (shown.isEmpty()) "Koi bahari dependency nahi mili." else "Dependencies:\n" + cap(shown.joinToString("\n"))
            }
            "format" -> {
                val p = a.optString("path", "")
                var n = 0
                snap(ctx, dir)
                for ((rp, c) in textFiles(dir)) {
                    if (p.isNotBlank() && cleanPath(p) != rp) continue
                    var t = c.replace("\r\n", "\n").split("\n").joinToString("\n") { it.trimEnd() }.trimEnd('\n') + "\n"
                    if (rp.endsWith(".json")) t = try { (if (t.trimStart().startsWith("[")) JSONArray(t).toString(2) else JSONObject(t).toString(2)) + "\n" } catch (e: Exception) { t }
                    if (t != c) { File(dir, rp).writeText(t, Charsets.UTF_8); n++ }
                }
                done(ctx, dir)
                return "Format kiya: $n files (trailing spaces hatay, aakhri newline, JSON pretty)."
            }
            "new_file", "touch" -> {
                val p = cleanPath(a.optString("path")) ?: return "path do."
                if (File(dir, p).exists()) return "$p pehle se hai."
                snap(ctx, dir); Coder.writeFile(dir, p, ""); done(ctx, dir); return "Created empty $p"
            }
            "move_file", "rename_file" -> {
                val from = cleanPath(a.optString("path")) ?: return "path do."
                val to = cleanPath(a.optString("to")) ?: return "to (naya path) do."
                val src = File(dir, from)
                if (!src.exists()) return "Nahi mila: $from"
                val dst = File(dir, to)
                if (dst.exists()) return "$to pehle se maujood hai."
                snap(ctx, dir)
                dst.parentFile?.mkdirs()
                if (!src.renameTo(dst)) { src.copyRecursively(dst, false); src.deleteRecursively() }
                done(ctx, dir)
                return "Moved $from -> $to (imports/links khud check karo: project_search + project_check)."
            }
            "delete_file" -> {
                val p = cleanPath(a.optString("path")) ?: return "path do."
                val f = File(dir, p)
                if (!f.exists()) return "Nahi mila: $p"
                if (!confirm(Confirm.msg("delete", "Delete " + p + " from project " + Coder.name(dir) + "?", "Undo: project_history action=undo"))) return "User ne mana kar diya."
                snap(ctx, dir)
                f.deleteRecursively()
                done(ctx, dir)
                return "Deleted $p"
            }
            "rename_project" -> {
                val to = a.optString("to").trim()
                if (to.isEmpty()) return "to (naya naam) do."
                Coder.rename(dir, to); return "Project ka naam ab: " + to
            }
            "delete_project" -> {
                if (!confirm(Confirm.msg("delete", "Delete the whole project " + Coder.name(dir) + "?", listFiles(dir).size.toString() + " files. Yeh wapas nahi aayega."))) return "User ne mana kar diya."
                Coder.delete(dir); return "Project hata diya."
            }
            else -> return "action: list_projects, stats, deps, format, new_file, move_file, delete_file, rename_project ya delete_project."
        }
    }

    // ------------------------------------------------------------------ project_check

    private fun check(ctx: Context, dir: File, a: JSONObject): String {
        val act = a.optString("action", "lint").lowercase()
        val files = textFiles(dir)
        when (act) {
            "lint" -> {
                val l = Coder.lint(files).trim()
                return if (l.isEmpty()) "Lint saaf: koi masla nahi mila (brackets, JSON, HTML ids/links, stubs)." else "Lint ne yeh dekha:\n" + cap(l)
            }
            "run" -> {
                if (Runner.entry(dir) == null && PyRun.entry(dir) == null) return "Chalane layak entry nahi mili (index.html ya main.py chahiye). project_check action=lint chalao."
                val r = Runner.check(ctx, dir)
                return if (r.isBlank()) "Project saaf chala: koi error nahi (ya bahari package ki wajah se test nahi ho saka)." else "Chalane par masle:\n" + cap(r)
            }
            "test" -> {
                val hasTests = files.keys.any { val n = it.substringAfterLast('/'); n.startsWith("test") && n.endsWith(".py") || it.startsWith("tests/") && n.endsWith(".py") }
                if (!hasTests) return "Koi Python test file nahi mili (test_*.py). Pehle test likho (project_template python ek sample deta hai). JS ke liye action=run se page chalao."
                val runner = "_anjoo_run_tests.py"
                Coder.writeFile(dir, runner, "import unittest, sys\nsys.path.insert(0, '.')\nres = unittest.TextTestRunner(verbosity=2, stream=sys.stdout).run(unittest.defaultTestLoader.discover('.', pattern='test*.py'))\nprint('RESULT: ' + ('PASS' if res.wasSuccessful() else 'FAIL') + ' ran=' + str(res.testsRun) + ' failures=' + str(len(res.failures)) + ' errors=' + str(len(res.errors)))\n")
                try {
                    val r = PyRun.run(ctx, dir, runner, false, 70000, 60000)
                    if (!r.loaded) return "Python runtime load nahi hua (pehli baar internet chahiye)."
                    if (!r.finished) return "Tests 60 second mein khatam nahi huay."
                    return cap("TEST OUTPUT:\n" + (r.out + "\n" + r.err).trim(), 9000)
                } finally { File(dir, runner).delete() }
            }
            else -> return "action: lint, run ya test."
        }
    }

    // ------------------------------------------------------------------ project_history

    private fun cpRoot(ctx: Context, dir: File) = File(File(ctx.filesDir, "checkpoints"), dir.name).also { it.mkdirs() }

    private class Cp(val id: Int, val msg: String, val time: Long, val files: JSONObject)

    private fun checkpoints(ctx: Context, dir: File): List<Cp> =
        (cpRoot(ctx, dir).listFiles()?.filter { it.name.endsWith(".json") } ?: emptyList()).mapNotNull { f ->
            try {
                val o = JSONObject(f.readText(Charsets.UTF_8))
                Cp(o.getInt("id"), o.optString("msg"), o.optLong("t"), o.getJSONObject("files"))
            } catch (e: Exception) { null }
        }.sortedBy { it.id }

    private fun diffMaps(old: Map<String, String>, now: Map<String, String>): String {
        val sb = StringBuilder()
        for ((p, c) in now) {
            val o = old[p]
            if (o == null) { sb.append("+++ ").append(p).append("  (new, ").append(lines(c)).append(" lines)\n"); continue }
            if (o == c) continue
            val d = Coder.lineDiff(o.split("\n"), c.split("\n"))
            sb.append("~~~ ").append(p).append("  +").append(d.count { it.startsWith("+ ") }).append(" -").append(d.count { it.startsWith("- ") }).append('\n')
            for (l in d.filter { it.startsWith("+ ") || it.startsWith("- ") }.take(40)) sb.append("    ").append(l.take(180)).append('\n')
        }
        for (p in old.keys) if (!now.containsKey(p)) sb.append("--- ").append(p).append("  (deleted)\n")
        return sb.toString().trim()
    }

    private fun history(ctx: Context, dir: File, a: JSONObject): String {
        val act = a.optString("action", "diff").lowercase()
        when (act) {
            "diff" -> {
                val ch = Coder.diffs(ctx, dir)
                if (ch.isEmpty()) return "Pichhle snapshot ke baad koi badlav nahi."
                val sb = StringBuilder()
                for (c in ch) {
                    sb.append(if (c.status == "new") "+++ " else if (c.status == "deleted") "--- " else "~~~ ").append(c.path).append("  +").append(c.add).append(" -").append(c.del).append('\n')
                    for (l in c.diff.filter { it.startsWith("+ ") || it.startsWith("- ") }.take(40)) sb.append("    ").append(l.take(180)).append('\n')
                }
                return cap(sb.toString())
            }
            "undo" -> return if (Coder.undo(ctx, dir)) { done(ctx, dir); "Pichhla badlav wapas kar diya." } else "Wapas karne ke liye koi snapshot nahi."
            "checkpoint", "commit" -> {
                val files = textFiles(dir)
                val list = checkpoints(ctx, dir)
                val id = (list.maxOfOrNull { it.id } ?: 0) + 1
                val o = JSONObject()
                for ((k, v) in files) o.put(k, v)
                val msg = a.optString("message", a.optString("name", "")).trim().ifEmpty { "checkpoint $id" }.take(100)
                File(cpRoot(ctx, dir), "$id.json").writeText(JSONObject().put("id", id).put("msg", msg).put("t", System.currentTimeMillis()).put("files", o).toString(), Charsets.UTF_8)
                // keep the newest 30
                list.sortedBy { it.id }.dropLast(29).forEach { File(cpRoot(ctx, dir), it.id.toString() + ".json").delete() }
                return "Checkpoint #$id saved: " + msg + " (" + files.size + " files)"
            }
            "log" -> {
                val l = checkpoints(ctx, dir)
                if (l.isEmpty()) return "Koi checkpoint nahi. action=checkpoint se banao."
                val f = java.text.SimpleDateFormat("d MMM HH:mm", java.util.Locale.ENGLISH)
                return l.reversed().joinToString("\n") { "#" + it.id + "  " + f.format(java.util.Date(it.time)) + "  " + it.msg + "  (" + it.files.length() + " files)" }
            }
            "compare", "restore" -> {
                val id = a.optInt("id", -1)
                val cp = checkpoints(ctx, dir).let { l -> if (id >= 0) l.firstOrNull { it.id == id } else l.lastOrNull() } ?: return "Aisa checkpoint nahi mila. action=log dekho."
                val old = LinkedHashMap<String, String>()
                for (k in cp.files.keys()) old[k] = cp.files.getString(k)
                if (act == "compare") {
                    val d = diffMaps(old, textFiles(dir))
                    return "Checkpoint #" + cp.id + " (" + cp.msg + ") se ab tak:\n" + (if (d.isEmpty()) "koi farq nahi." else cap(d))
                }
                Coder.snapshot(ctx, dir)
                val now = textFiles(dir)
                for (p in now.keys) if (!old.containsKey(p)) File(dir, p).delete()
                for ((p, c) in old) Coder.writeFile(dir, p, c)
                done(ctx, dir)
                return "Project checkpoint #" + cp.id + " (" + cp.msg + ") par wapas. (Pehli halat undo se mil sakti hai.)"
            }
            else -> return "action: diff, undo, checkpoint, log, compare ya restore."
        }
    }

    // ------------------------------------------------------------------ project_template

    private val TEMPLATES: Map<String, List<Pair<String, String>>> = mapOf(
        "web" to listOf(
            "index.html" to "<!doctype html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  <title>My App</title>\n  <link rel=\"stylesheet\" href=\"style.css\">\n</head>\n<body>\n  <main id=\"app\">\n    <h1>My App</h1>\n    <button id=\"btn\">Click me</button>\n    <p id=\"out\"></p>\n  </main>\n  <script src=\"script.js\"></script>\n</body>\n</html>\n",
            "style.css" to ":root { --bg: #faf9f5; --ink: #1f1e1d; --accent: #c96442; }\n* { box-sizing: border-box; }\nbody { margin: 0; font-family: system-ui, sans-serif; background: var(--bg); color: var(--ink); }\nmain { max-width: 640px; margin: 0 auto; padding: 24px 16px; }\nbutton { background: var(--accent); color: #fff; border: 0; border-radius: 12px; padding: 10px 18px; font-size: 16px; }\n",
            "script.js" to "const btn = document.getElementById('btn');\nconst out = document.getElementById('out');\nlet n = 0;\nbtn.addEventListener('click', () => {\n  n += 1;\n  out.textContent = 'Clicked ' + n + ' times';\n});\n"
        ),
        "python" to listOf(
            "main.py" to "def greet(name):\n    return 'Hello, ' + name + '!'\n\n\ndef main():\n    print(greet('world'))\n\n\nif __name__ == '__main__':\n    main()\n",
            "test_main.py" to "import unittest\nfrom main import greet\n\n\nclass GreetTest(unittest.TestCase):\n    def test_greet(self):\n        self.assertEqual(greet('Ali'), 'Hello, Ali!')\n\n\nif __name__ == '__main__':\n    unittest.main()\n",
            "requirements.txt" to "",
            "README.md" to "# Python project\n\nRun: `python main.py`\n\nTest: `python -m unittest`\n"
        ),
        "node" to listOf(
            "package.json" to "{\n  \"name\": \"my-app\",\n  \"version\": \"1.0.0\",\n  \"main\": \"index.js\",\n  \"scripts\": {\n    \"start\": \"node index.js\",\n    \"test\": \"node test.js\"\n  }\n}\n",
            "index.js" to "function add(a, b) {\n  return a + b;\n}\n\nmodule.exports = { add };\n\nif (require.main === module) {\n  console.log('2 + 3 =', add(2, 3));\n}\n",
            "test.js" to "const assert = require('assert');\nconst { add } = require('./index');\n\nassert.strictEqual(add(2, 3), 5);\nconsole.log('all tests passed');\n",
            "README.md" to "# Node project\n\nRun: `npm start`\n\nTest: `npm test`\n"
        ),
        "pwa" to listOf(
            "index.html" to "<!doctype html>\n<html lang=\"en\">\n<head>\n  <meta charset=\"utf-8\">\n  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n  <meta name=\"theme-color\" content=\"#c96442\">\n  <link rel=\"manifest\" href=\"manifest.json\">\n  <title>My PWA</title>\n</head>\n<body>\n  <h1>My PWA</h1>\n  <script>\n    if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js');\n  </script>\n</body>\n</html>\n",
            "manifest.json" to "{\n  \"name\": \"My PWA\",\n  \"short_name\": \"PWA\",\n  \"start_url\": \"index.html\",\n  \"display\": \"standalone\",\n  \"background_color\": \"#faf9f5\",\n  \"theme_color\": \"#c96442\",\n  \"icons\": []\n}\n",
            "sw.js" to "const CACHE = 'v1';\nconst FILES = ['index.html', 'manifest.json'];\nself.addEventListener('install', e => e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES))));\nself.addEventListener('fetch', e => e.respondWith(caches.match(e.request).then(r => r || fetch(e.request))));\n"
        ),
        "readme" to listOf("README.md" to "# Project name\n\nWhat it does in one line.\n\n## Run\n\n```\n...\n```\n\n## Test\n\n```\n...\n```\n\n## Structure\n\n- `file` - what it is for\n"),
        "gitignore" to listOf(".gitignore" to "node_modules/\n__pycache__/\n*.pyc\n.env\n.DS_Store\nbuild/\ndist/\n*.log\n"),
        "dockerfile" to listOf("Dockerfile" to "FROM python:3.12-slim\nWORKDIR /app\nCOPY requirements.txt .\nRUN pip install --no-cache-dir -r requirements.txt\nCOPY . .\nCMD [\"python\", \"main.py\"]\n"),
        "github_actions" to listOf(".github/workflows/ci.yml" to "name: CI\non: [push, pull_request]\njobs:\n  test:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-python@v5\n        with:\n          python-version: '3.12'\n      - run: python -m unittest\n")
    )

    private fun template(ctx: Context, a: JSONObject): String {
        val t = a.optString("template", "").lowercase().replace('-', '_')
        val tpl = TEMPLATES[t] ?: return "template chuno: " + TEMPLATES.keys.joinToString(", ")
        val overwrite = a.optBoolean("overwrite", false)
        val n = a.optString("project", "").trim()
        val existing = if (n.isEmpty()) null else find(ctx, a).first
        val dir: File
        val added = ArrayList<String>()
        if (existing != null) {
            dir = existing
            snap(ctx, dir)
        } else {
            val first = tpl.first()
            dir = Coder.fileProject(ctx, first.first.substringAfterLast('/'), "")
            if (n.isNotEmpty()) Coder.rename(dir, n)
            File(dir, first.first.substringAfterLast('/')).delete()
        }
        for ((p, c) in tpl) {
            if (File(dir, p).exists() && !overwrite) continue
            if (Coder.writeFile(dir, p, c)) added.add(p)
        }
        done(ctx, dir)
        return "Template '$t' project '" + Coder.name(dir) + "' mein lagaya: " + (if (added.isEmpty()) "kuch naya nahi (files pehle se thi, overwrite=true do)" else added.joinToString(", "))
    }
}
