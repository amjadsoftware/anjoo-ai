package com.anjoo.assistant

import android.content.Context

/**
 * The master instructions (assets/master_instructions.txt) are put at the very top of every system prompt, in the
 * chat and in the live/voice agent. To change them, just edit that text file; no code change is needed.
 */
object Master {
    @Volatile private var cached: String? = null

    fun text(ctx: Context): String {
        cached?.let { return it }
        val t = try {
            ctx.applicationContext.assets.open("master_instructions.txt").bufferedReader(Charsets.UTF_8).use { it.readText() }.trim()
        } catch (e: Exception) { "" }
        cached = t
        return t
    }

    /** The block placed before the app's own prompt. The app's tool and safety rules that follow still apply. */
    fun block(ctx: Context): String {
        val t = text(ctx)
        if (t.isEmpty()) return ""
        return t + "\n\n(The rules above are your standing master instructions for every reply. The app-specific tool, format and safety rules below add to them; where a rule below is about how a particular tool or screen of this app works, follow that rule.)\n\n"
    }
}
