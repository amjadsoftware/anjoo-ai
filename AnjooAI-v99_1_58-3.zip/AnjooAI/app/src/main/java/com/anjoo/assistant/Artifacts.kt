package com.anjoo.assistant

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Artifacts and docs: web pages, dashboards, small apps, slide decks (HTML) and documents, reports (Markdown) that Anjoo builds,
 * keeps in a library, can change later (every change is a saved version), and hands over as a file or a Wi-Fi link.
 * Phone storage is private to Anjoo: <filesDir>/artifacts/<id>/{meta.json, content.html|md, history/}.
 */
object Artifacts {
    const val AUTH = "com.anjoo.assistant.artifacts"
    val KINDS = listOf("page", "dashboard", "app", "slides", "document", "report")
    private const val MAX_CHARS = 2_000_000

    class Meta(val id: String, var title: String, var kind: String, val format: String, val created: Long, var updated: Long, var version: Int)

    // ---------- storage ----------

    private fun root(ctx: Context) = File(ctx.filesDir, "artifacts").also { it.mkdirs() }
    fun dir(ctx: Context, id: String) = File(root(ctx), id)
    fun formatOf(kind: String) = if (kind == "document" || kind == "report") "md" else "html"

    fun icon(kind: String) = when (kind) {
        "dashboard" -> "📊"; "app" -> "🧩"; "slides" -> "🎞"; "document" -> "📄"; "report" -> "📑"; else -> "🌐"
    }

    private fun readMeta(d: File): Meta? = try {
        val j = JSONObject(File(d, "meta.json").readText(Charsets.UTF_8))
        Meta(j.getString("id"), j.optString("title", "Untitled"), j.optString("kind", "page"), j.optString("format", "html"),
            j.optLong("created"), j.optLong("updated"), j.optInt("version", 1))
    } catch (e: Exception) { null }

    private fun writeMeta(ctx: Context, m: Meta) {
        val d = dir(ctx, m.id)
        d.mkdirs()
        File(d, "meta.json").writeText(JSONObject().put("id", m.id).put("title", m.title).put("kind", m.kind).put("format", m.format)
            .put("created", m.created).put("updated", m.updated).put("version", m.version).toString(), Charsets.UTF_8)
    }

    fun list(ctx: Context): List<Meta> =
        (root(ctx).listFiles()?.filter { it.isDirectory && !it.name.startsWith("_") } ?: emptyList()).mapNotNull { readMeta(it) }.sortedByDescending { it.updated }

    fun meta(ctx: Context, id: String): Meta? = readMeta(dir(ctx, id))

    private fun contentFile(ctx: Context, m: Meta) = File(dir(ctx, m.id), "content." + m.format)

    fun source(ctx: Context, m: Meta): String = try { contentFile(ctx, m).readText(Charsets.UTF_8) } catch (e: Exception) { "" }

    /** Finds an artifact by list number (1 = newest), id, exact title or part of the title. Blank / "latest" = newest. */
    fun find(ctx: Context, ref: String): Meta? {
        val all = list(ctx)
        if (all.isEmpty()) return null
        val r = ref.trim()
        if (r.isEmpty() || r.equals("latest", true) || r.equals("last", true)) return all.first()
        val n = r.toIntOrNull()
        if (n != null && n in 1..all.size) return all[n - 1]
        return all.firstOrNull { it.id == r } ?: all.firstOrNull { it.title.equals(r, true) } ?: all.firstOrNull { it.title.contains(r, true) }
    }

    /** Writes new content. The old content is kept as a version (last 25). */
    fun write(ctx: Context, m: Meta, content: String) {
        val d = dir(ctx, m.id)
        val cf = contentFile(ctx, m)
        if (cf.isFile) {
            val h = File(d, "history").also { it.mkdirs() }
            val old = File(h, m.version.toString() + "." + m.format)
            try { cf.copyTo(old, true); old.setLastModified(m.updated) } catch (e: Exception) {}
            val fs = h.listFiles()?.sortedByDescending { it.nameWithoutExtension.toIntOrNull() ?: 0 } ?: emptyList()
            for (f in fs.drop(25)) f.delete()
            m.version += 1
        }
        d.mkdirs()
        cf.writeText(content, Charsets.UTF_8)
        m.updated = System.currentTimeMillis()
        writeMeta(ctx, m)
    }

    class Ver(val number: Int, val time: Long, val current: Boolean)

    fun versions(ctx: Context, m: Meta): List<Ver> {
        val out = ArrayList<Ver>()
        out.add(Ver(m.version, m.updated, true))
        File(dir(ctx, m.id), "history").listFiles()?.forEach { f ->
            val n = f.nameWithoutExtension.toIntOrNull()
            if (n != null) out.add(Ver(n, f.lastModified(), false))
        }
        return out.sortedByDescending { it.number }
    }

    fun versionText(ctx: Context, m: Meta, number: Int): String? {
        if (number == m.version) return source(ctx, m)
        val f = File(File(dir(ctx, m.id), "history"), number.toString() + "." + m.format)
        return try { f.readText(Charsets.UTF_8) } catch (e: Exception) { null }
    }

    fun restore(ctx: Context, m: Meta, number: Int): Boolean {
        val t = versionText(ctx, m, number) ?: return false
        if (number == m.version) return true
        write(ctx, m, t)
        return true
    }

    fun rename(ctx: Context, m: Meta, title: String) {
        m.title = title.trim().take(80).ifEmpty { m.title }
        writeMeta(ctx, m)
    }

    fun delete(ctx: Context, m: Meta) { dir(ctx, m.id).deleteRecursively() }

    private fun newId(): String = "a" + java.lang.Long.toString(System.currentTimeMillis(), 36) + (1000 + (Math.random() * 8999).toInt())

    fun slug(t: String): String = t.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(32).ifEmpty { "artifact" }

    fun ago(t: Long): String {
        val s = (System.currentTimeMillis() - t) / 1000
        return when {
            s < 60 -> "abhi"
            s < 3600 -> (s / 60).toString() + " min pehle"
            s < 86400 -> (s / 3600).toString() + " ghante pehle"
            else -> (s / 86400).toString() + " din pehle"
        }
    }

    // ---------- rendering ----------

    private fun ensureHtml(src: String, title: String): String =
        if (Regex("(?is)<html|<!doctype").containsMatchIn(src.take(3000))) src
        else "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>" +
            MdHtml.esc(title) + "</title></head><body>" + src + "</body></html>"

    /** The complete page for the viewer, the Wi-Fi link and HTML export. */
    fun pageHtml(m: Meta, src: String): String =
        if (m.format == "html") ensureHtml(src, m.title) else MdHtml.page(m.title, MdHtml.render(src))

    private fun plainText(m: Meta, src: String): String {
        if (m.format == "md") return src
        var s = Regex("(?is)<(script|style|head)\\b.*?</\\1>").replace(src, " ")
        s = Regex("(?is)<br\\s*/?>|</(p|div|li|tr|h[1-6]|section)>").replace(s, "\n")
        s = Regex("(?s)<[^>]+>").replace(s, "")
        s = s.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&amp;", "&")
        return s.replace(Regex("[ \\t]+"), " ").replace(Regex("\\n\\s*\\n+"), "\n\n").trim()
    }

    /** One export file: (file name, bytes, mime). format = html | md | txt | doc. Returns null when that format does not fit. */
    fun export(ctx: Context, m: Meta, format: String): Triple<String, ByteArray, String>? {
        val src = source(ctx, m)
        val base = slug(m.title) + "-v" + m.version
        return when (format.lowercase().removePrefix(".")) {
            "html", "htm" -> Triple("$base.html", pageHtml(m, src).toByteArray(Charsets.UTF_8), "text/html")
            "md", "markdown" -> if (m.format == "md") Triple("$base.md", src.toByteArray(Charsets.UTF_8), "text/markdown") else null
            "txt", "text" -> Triple("$base.txt", plainText(m, src).toByteArray(Charsets.UTF_8), "text/plain")
            "doc", "word", "docx" -> {
                val body = if (m.format == "md") MdHtml.render(src) else Regex("(?is)<body[^>]*>(.*?)</body>").find(src)?.groupValues?.get(1) ?: src
                Triple("$base.doc", MdHtml.wordDoc(m.title, body).toByteArray(Charsets.UTF_8), "application/msword")
            }
            else -> null
        }
    }

    // ---------- opening and sharing ----------

    fun openLibrary(ctx: Context) {
        ctx.startActivity(Intent(ctx, ArtifactActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun open(ctx: Context, id: String, print: Boolean = false) {
        ctx.startActivity(Intent(ctx, ArtifactActivity::class.java).putExtra("id", id).putExtra("print", print)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }

    private fun toClipboard(ctx: Context, label: String, text: String) {
        Handler(Looper.getMainLooper()).post {
            try { (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText(label, text)) } catch (e: Exception) {}
        }
    }

    /** Opens the system share sheet with the artifact as a file (html / md / doc). */
    fun shareFile(ctx: Context, m: Meta, format: String): String {
        val ex = export(ctx, m, format) ?: return "Is artifact ko '" + format + "' mein nahi de sakta (Markdown sirf documents/reports ke liye hai). html, txt ya doc chunein."
        val d = File(root(ctx), "_share").also { it.mkdirs() }
        d.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 24 * 3600 * 1000L) it.delete() }
        File(d, ex.first).writeBytes(ex.second)
        val uri = Uri.parse("content://$AUTH/" + Uri.encode(ex.first))
        val i = Intent(Intent.ACTION_SEND).setType(ex.third).putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_SUBJECT, m.title)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.clipData = ClipData.newRawUri(ex.first, uri)
        ctx.startActivity(Intent.createChooser(i, "Share " + m.title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Share screen khol di: " + ex.first + " (" + ex.second.size + " bytes). Aap jis app mein bhejna chahein chunein."
    }

    fun shareText(ctx: Context, m: Meta): String {
        val t = plainText(m, source(ctx, m))
        ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, m.title)
            .putExtra(Intent.EXTRA_TEXT, t), "Share " + m.title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "Share screen khol di (text ki surat mein)."
    }

    /** Starts the Wi-Fi link (asks first). Returns the links, or an explanation. */
    fun shareLink(ctx: Context, m: Meta, confirm: (String) -> Boolean): String {
        if (!confirm(Confirm.msg("action", "Share '" + m.title + "' on Wi-Fi?",
                "Ek link banega jo isi Wi-Fi/hotspot par jude dusre phone ya laptop mein khulega. Sirf yeh artifact dikhega, 60 minute baad band ho jata hai. Link jis ke paas ho wo dekh sakta hai."))) {
            return "User ne link banane se mana kar diya."
        }
        val r = ArtifactServer.share(ctx, m.id)
        if (r.startsWith("ERR:")) return r.removePrefix("ERR:")
        val first = r.lines().first()
        toClipboard(ctx, "Anjoo link", first)
        return "Link tayyar (copy bhi ho gaya):\n" + r + "\n\nYeh sirf isi Wi-Fi/hotspot par kaam karta hai, jab tak Anjoo app chal rahi ho, aur 60 minute baad band ho jata hai. " +
            "Internet par sab ko dikhne wala link (hosting) is app mein nahi hai; uske liye file share karein."
    }

    // ---------- generation (the model writes the artifact) ----------

    private const val HTML_RULES = "You build ONE complete, self-contained, production-quality HTML file. Output ONLY the HTML (start with <!doctype html>), no markdown fences, no explanation. " +
        "Inline all CSS and JavaScript in the file. No external images; draw with CSS, inline SVG, canvas or emoji. If you need a library, load it only from https://cdnjs.cloudflare.com with a pinned version. " +
        "Mobile-first and responsive (viewport meta tag, flexible layout, touch-friendly 44px targets), works in portrait and landscape. Use CSS variables and support both light and dark mode with prefers-color-scheme. " +
        "Distinctive, polished design: a deliberate colour palette, good typography with system font stack, spacing, subtle shadows and transitions; never a plain default look. " +
        "Interactive parts must really work (no placeholders or TODO). Handle empty and error states. Use realistic sample data only when the user gave none. " +
        "Do not use localStorage for anything required to function (keep state in JavaScript variables); it is fine only for small optional conveniences wrapped in try/catch. " +
        "Write the visible text in the language the user used (Urdu, Roman Urdu or English); for Urdu add dir=\"rtl\" where needed."

    private const val DOC_RULES = "You write ONE complete, well-organised document in Markdown. Output ONLY the Markdown (no code fences around the whole thing, no preface or closing remarks). " +
        "Start with a single # title, then a short intro, then clear ## sections and ### subsections, lists, tables where comparing, **bold** for key terms. " +
        "Be specific and substantive, not generic; use real numbers, names and steps from the user's request. Finish every section (no TODO or placeholders). " +
        "Write in the language the user used (Urdu, Roman Urdu or English)."

    private const val KIND_HINT = "page = a web page or landing page; dashboard = charts/tables/KPIs with filters; app = a working small tool, calculator or game; " +
        "slides = a slide deck as one HTML page with a slide per screen, next/previous buttons, arrow-key and swipe navigation and a progress indicator; " +
        "document = letter, resume, guide, notes, article, proposal or plan; report = structured analysis with summary, findings and recommendations."

    private fun strip(s: String): String {
        var t = s.trim()
        if (t.startsWith("```")) t = t.substringAfter("\n")
        if (t.endsWith("```")) t = t.substringBeforeLast("```")
        return t.trim()
    }

    /** Asks the model. Returns the content, or a text starting with "ERR:". */
    private fun ask(ctx: Context, system: String, text: String): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        Providers.load(p)
        val key = p.getString("key", "") ?: ""
        if (key.isEmpty()) return "ERR:Pehle Settings mein API key dalein."
        val model = p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
        val out = try {
            strip(Gemini.plain(key, model, system, JSONArray().put(JSONObject().put("text", text)), 14000))
        } catch (e: Exception) { return "ERR:" + (e.message ?: e.javaClass.simpleName) }
        return if (out.isBlank()) "ERR:Kuch ban nahi saka, dobara koshish karein." else out
    }

    private fun looksComplete(format: String, out: String): Boolean =
        if (format == "html") out.contains("</html>", true) || out.contains("</body>", true) || out.length < 3000 else true

    // ---------- tools ----------

    fun create(ctx: Context, a: JSONObject): String {
        val title0 = a.optString("title", "").trim()
        val desc = a.optString("description", "").trim()
        val given = a.optString("content", "")
        var kind = a.optString("kind", "").trim().lowercase().ifEmpty { "page" }
        if (kind !in KINDS) kind = when {
            kind.contains("dash") -> "dashboard"; kind.contains("slide") || kind.contains("deck") || kind.contains("ppt") -> "slides"
            kind.contains("report") -> "report"; kind.contains("doc") || kind.contains("letter") || kind.contains("resume") || kind.contains("cv") -> "document"
            kind.contains("app") || kind.contains("tool") || kind.contains("game") || kind.contains("calc") -> "app"
            else -> "page"
        }
        if (title0.isEmpty() && desc.isEmpty() && given.isBlank()) return "Kya banana hai? title ya description do."
        if (Guard.hasCardData(desc) || Guard.hasCardData(given)) return Guard.CARD_MSG
        val format = formatOf(kind)
        val title = title0.ifEmpty { desc.take(50) }.take(80)
        var content = strip(given)
        if (content.isBlank()) {
            val sys = (if (format == "html") HTML_RULES else DOC_RULES) + " Kind: $kind. ($KIND_HINT)"
            content = ask(ctx, sys, "Title: $title\nWhat to build:\n" + desc.ifEmpty { title })
            if (content.startsWith("ERR:")) return content.removePrefix("ERR:")
        }
        if (content.length > MAX_CHARS) return "Content bohat bara hai (2 MB se zyada)."
        val now = System.currentTimeMillis()
        val m = Meta(newId(), title, kind, format, now, now, 1)
        write(ctx, m, content)
        val inChat = ctx is MainActivity
        if (!inChat) open(ctx, m.id)
        val warn = if (!looksComplete(format, content)) "\nNote: output adhoora lag raha hai; update_artifact se 'poora karo' kahein." else ""
        return (if (inChat) "Artifact ban gaya, chat mein card aur preview dikhaya jayega: '" else "Artifact ban gaya aur screen par khol diya: '") +
            title + "' (" + kind + ", " + content.length + " harf, id " + m.id + ")." + warn +
            "\nAb: update_artifact (badlav), export_artifact (html/doc/txt/md/pdf), share_artifact (file ya Wi-Fi link)." +
            (if (inChat) " [artifact:" + m.id + "]" else "")
    }

    fun update(ctx: Context, a: JSONObject): String {
        val m = find(ctx, a.optString("artifact", "")) ?: return "Aisa artifact nahi mila. list_artifacts se dekho."
        val cur = source(ctx, m)
        val oldT = a.optString("old_text", "")
        val instr = a.optString("instruction", "").trim()
        if (Guard.hasCardData(oldT) || Guard.hasCardData(a.optString("new_text", "")) || Guard.hasCardData(instr)) return Guard.CARD_MSG
        val next: String
        if (oldT.isNotEmpty()) {
            val nw = a.optString("new_text", "")
            val n = cur.split(oldT).size - 1
            if (n == 0) return "old_text artifact mein nahi mila. read_artifact se exact text dekh kar dobara do."
            if (n > 1 && !a.optBoolean("replace_all", false)) return "old_text $n jagah hai; zyada lamba hissa do ya replace_all=true do."
            next = if (a.optBoolean("replace_all", false)) cur.replace(oldT, nw) else cur.replaceFirst(oldT, nw)
        } else if (instr.isNotEmpty()) {
            val sys = (if (m.format == "html") HTML_RULES else DOC_RULES) +
                " You are EDITING the file below. Apply ONLY the change the user asks for, keep everything else exactly as it is (same design, content, structure), and return the COMPLETE updated file."
            val out = ask(ctx, sys, "CURRENT FILE:\n" + cur + "\n\nCHANGE REQUESTED:\n" + instr)
            if (out.startsWith("ERR:")) return out.removePrefix("ERR:")
            if (cur.length > 2000 && out.length < cur.length * 0.4) return "Model ka jawab asal se bohat chhota tha, is liye badlav nahi kiya (kuch kharab hone se bachane ke liye). Dobara kahein ya old_text/new_text se chhota badlav karein."
            next = out
        } else return "Kya badalna hai? instruction do, ya old_text + new_text."
        if (next.length > MAX_CHARS) return "Content bohat bara hai (2 MB se zyada)."
        write(ctx, m, next)
        val inChat = ctx is MainActivity
        if (!inChat) open(ctx, m.id)
        return "Artifact '" + m.title + "' update ho gaya (version " + m.version + "). Purana version history mein hai." +
            (if (inChat) " Chat mein naya card aur preview dikhaya jayega. [artifact:" + m.id + "]" else "")
    }

    fun read(ctx: Context, a: JSONObject): String {
        val m = find(ctx, a.optString("artifact", "")) ?: return "Aisa artifact nahi mila. list_artifacts se dekho."
        val lines = source(ctx, m).split("\n")
        val off = a.optInt("offset", 1).coerceAtLeast(1)
        val lim = a.optInt("limit", 200).coerceIn(1, 600)
        if (off > lines.size) return "offset ($off) file ki lines (" + lines.size + ") se bahar hai."
        val end = minOf(lines.size, off - 1 + lim)
        val sb = StringBuilder("ARTIFACT '" + m.title + "' (" + m.kind + ", " + m.format + ", v" + m.version + ") lines $off-$end of " + lines.size + ":\n")
        for (i in (off - 1) until end) sb.append(i + 1).append("\t").append(lines[i].take(600)).append('\n')
        if (end < lines.size) sb.append("[aur hai: offset=").append(end + 1).append(" do]")
        return sb.toString().trimEnd()
    }

    fun listText(ctx: Context, q: String): String {
        val all = list(ctx)
        val shown = all.withIndex().filter { q.isBlank() || it.value.title.contains(q, true) || it.value.kind.contains(q, true) }
        if (shown.isEmpty()) return if (all.isEmpty()) "Abhi koi artifact nahi hai. create_artifact se banayein." else "Is naam ka koi artifact nahi mila."
        return shown.joinToString("\n") { (i, m) -> "${i + 1}. " + icon(m.kind) + " " + m.title + " [" + m.kind + ", v" + m.version + ", " + ago(m.updated) + ", id " + m.id + "]" }
    }

    fun exportTool(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val m = find(ctx, a.optString("artifact", "")) ?: return "Aisa artifact nahi mila. list_artifacts se dekho."
        val fmt = a.optString("format", "html").trim().lowercase().ifEmpty { "html" }
        if (fmt == "pdf") {
            open(ctx, m.id, true)
            return "Print screen khol di: wahan 'Save as PDF' chunein (PDF phone mein save hota hai)."
        }
        val ex = export(ctx, m, fmt) ?: return "Is artifact ko '" + fmt + "' mein nahi de sakta (md sirf documents/reports ke liye). html, txt, doc ya pdf chunein."
        val folder0 = a.optString("folder", "").ifBlank { FileAccess.defaultFolder(ctx).ifBlank { "Documents/Anjoo" } }
        return FileAccess.write(ctx, "$folder0/Artifacts", ex.first, ex.second, false) { p -> confirm(Confirm.msg("overwrite", "Overwrite this file?", p)) }
    }

    fun shareTool(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val m = find(ctx, a.optString("artifact", "")) ?: return "Aisa artifact nahi mila. list_artifacts se dekho."
        return when (a.optString("how", "file").trim().lowercase()) {
            "link", "wifi", "url" -> shareLink(ctx, m, confirm)
            "text" -> shareText(ctx, m)
            else -> shareFile(ctx, m, a.optString("format", "html").ifBlank { "html" })
        }
    }

    fun deleteTool(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val m = find(ctx, a.optString("artifact", "")) ?: return "Aisa artifact nahi mila."
        if (!confirm(Confirm.msg("delete", "Delete this artifact?", m.title + " (" + m.kind + ", v" + m.version + ") aur uski saari versions hamesha ke liye hat jayengi."))) return "User ne delete karne se mana kar diya."
        delete(ctx, m)
        return "'" + m.title + "' hata diya."
    }

    fun tool(ctx: Context, confirm: (String) -> Boolean, name: String, a: JSONObject): String? = when (name) {
        "create_artifact" -> create(ctx, a)
        "update_artifact" -> update(ctx, a)
        "read_artifact" -> read(ctx, a)
        "list_artifacts" -> listText(ctx, a.optString("query", ""))
        "open_artifact" -> (find(ctx, a.optString("artifact", ""))?.let { if (ctx is MainActivity) "Chat mein card aur preview dikhaya jayega: " + it.title + " [artifact:" + it.id + "]" else { open(ctx, it.id); "Screen par khol diya: " + it.title } } ?: "Aisa artifact nahi mila. list_artifacts se dekho.")
        "export_artifact" -> exportTool(ctx, confirm, a)
        "share_artifact" -> shareTool(ctx, confirm, a)
        "stop_sharing" -> { ArtifactServer.stop(); "Wi-Fi link band kar diya." }
        "delete_artifact" -> deleteTool(ctx, confirm, a)
        else -> null
    }
}
