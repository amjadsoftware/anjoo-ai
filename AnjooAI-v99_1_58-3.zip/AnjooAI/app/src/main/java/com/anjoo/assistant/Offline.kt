package com.anjoo.assistant

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Is the phone connected, and tell me when that changes. */
object Offline {

    /**
     * True when the phone has a network that can reach the internet. This deliberately does not wait for Android's own
     * "validated" check (it can be wrong on some networks); a real failed request is caught separately by [isNetworkError].
     */
    fun online(ctx: Context): Boolean = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork
        val c = if (n != null) cm.getNetworkCapabilities(n) else null
        c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (e: Exception) { true }

    /** Starts listening for connection changes. Callback runs on a background thread. Pass the result to [unwatch]. */
    fun watch(ctx: Context, onChange: (Boolean) -> Unit): ConnectivityManager.NetworkCallback? = try {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { onChange(true) }
            override fun onLost(network: Network) { onChange(online(ctx)) }
        }
        cm.registerDefaultNetworkCallback(cb)
        cb
    } catch (e: Exception) { null }

    fun unwatch(ctx: Context, cb: ConnectivityManager.NetworkCallback?) {
        if (cb == null) return
        try { (ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(cb) } catch (e: Exception) {}
    }

    /** True when the error means "could not reach the server" (as opposed to a bad key or a limit). */
    fun isNetworkError(e: Throwable?): Boolean {
        var t = e
        var depth = 0
        while (t != null && depth++ < 6) {
            if (t is java.net.UnknownHostException || t is java.net.ConnectException || t is java.net.NoRouteToHostException ||
                t is java.net.SocketTimeoutException || t is javax.net.ssl.SSLException
            ) return true
            val m = (t.message ?: "").lowercase(Locale.ROOT)
            if (m.contains("unable to resolve host") || m.contains("failed to connect") || m.contains("network is unreachable") ||
                m.contains("software caused connection abort") || m.contains("connection reset")
            ) return true
            t = t.cause
        }
        return false
    }
}

/**
 * Answers the simple things on the phone itself when there is no internet (notes, tasks, reminders, alarm, timer,
 * torch, volume, battery, open app, time, calculator). It only acts on clear commands. Anything else returns null
 * and the message is saved in the [Outbox] for later.
 */
object OfflineBrain {

    const val HELP = "Internet nahi hai, lekin ye kaam ho sakte hain:\n" +
        "• Notes: \"note: doodh lana\", \"notes dikhao\", \"note 2\", \"note 2 delete\", \"notes search doodh\"\n" +
        "• Tasks: \"task add: bill bharna\", \"tasks dikhao\", \"task 3 done\"\n" +
        "• Yaad dihani: \"10 minute baad yaad dilao chai\", \"shaam 6 baje yaad dilao call\"\n" +
        "• \"alarm 6:30 am\", \"timer 5 minute\", \"torch on\", \"volume up\", \"battery\", \"open YouTube\"\n" +
        "• \"time kya hua\", \"2*(3+4)\"\n" +
        "Baqi sawal (AI wale) save ho jate hain aur net aane par aap ki ijazat se bheje jate hain."

    private val FILLER = setOf(
        "baad", "bad", "later", "in", "mein", "me", "ke", "ki", "ka", "ko", "yaad", "dilao", "dila", "dilana", "do", "dena", "de",
        "remind", "reminder", "set", "karo", "kar", "mujhe", "mjhe", "me", "to", "please", "pls", "plz", "ek", "at", "par", "pe", "baje", "bje"
    )

    private fun fmtTime(ms: Long) = SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH).format(Date(ms))

    private fun stripEdges(words: List<String>): String {
        var a = 0
        var b = words.size
        while (a < b && words[a] in FILLER) a++
        while (b > a && words[b - 1] in FILLER) b--
        return words.subList(a, b).joinToString(" ")
    }

    private val DUR = Regex("(\\d+)\\s*(sec\\w*|min\\w*|minute\\w*|ghant\\w*|ghanta|hour\\w*|hr\\w*|din|day\\w*)")

    private fun durationMs(s: String): Pair<Long, IntRange>? {
        val m = DUR.find(s) ?: return null
        val n = m.groupValues[1].toLongOrNull() ?: return null
        val u = m.groupValues[2]
        val ms = when {
            u.startsWith("sec") -> n * 1000
            u.startsWith("min") -> n * 60_000
            u.startsWith("ghant") || u.startsWith("hour") || u.startsWith("hr") -> n * 3_600_000
            u.startsWith("din") || u.startsWith("day") -> n * 86_400_000
            else -> return null
        }
        return Pair(ms, m.range)
    }

    private val CLOCK = Regex("(\\d{1,2})(?:[:.](\\d{2}))?\\s*(am|pm|baje|bje)?")

    /** "6:30 pm", "shaam 6 baje", "18:30" -> hour and minute. Needs a colon, am/pm or "baje" so plain numbers are not mistaken for times. */
    private fun clock(s: String): Triple<Int, Int, IntRange>? {
        for (m in CLOCK.findAll(s)) {
            val hasColon = m.groupValues[2].isNotEmpty()
            val suffix = m.groupValues[3]
            if (!hasColon && suffix.isEmpty()) continue
            var h = m.groupValues[1].toInt()
            val min = if (hasColon) m.groupValues[2].toInt() else 0
            if (h > 23 || min > 59) continue
            val pm = suffix == "pm" || Regex("\\b(shaam|sham|raat|rat|evening|night|dopahar|dopehar|afternoon)\\b").containsMatchIn(s)
            val am = suffix == "am" || Regex("\\b(subah|subha|morning|fajr)\\b").containsMatchIn(s)
            if (pm && h in 1..11) h += 12
            if (am && h == 12) h = 0
            return Triple(h, min, m.range)
        }
        return null
    }

    private val CALC_OK = Regex("^[0-9+\\-*/x×÷().,%^ ]+$")

    private fun calc(expr: String): String? {
        val e = expr.replace('x', '*').replace('×', '*').replace('÷', '/').replace(",", "").replace(" ", "")
        if (!e.any { it in "+-*/^%" }) return null
        return try {
            val p = Parser(e)
            val v = p.parse()
            if (v.isNaN() || v.isInfinite()) "Ye hisaab nahi ho sakta (zero se taqseem?)."
            else if (v == Math.rint(v) && Math.abs(v) < 1e15) v.toLong().toString() else String.format(Locale.ENGLISH, "%.8g", v).trimEnd('0').trimEnd('.')
        } catch (ex: Exception) { null }
    }

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double { val v = expr(); if (i != s.length) throw IllegalArgumentException(); return v }
        private fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) { val op = s[i++]; val r = term(); v = if (op == '+') v + r else v - r }
            return v
        }
        private fun term(): Double {
            var v = pow()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) { val op = s[i++]; val r = pow(); v = if (op == '*') v * r else v / r }
            return v
        }
        private fun pow(): Double {
            val b = unary()
            if (i < s.length && s[i] == '^') { i++; return Math.pow(b, pow()) }
            return b
        }
        private fun unary(): Double {
            if (i < s.length && s[i] == '-') { i++; return -unary() }
            if (i < s.length && s[i] == '+') { i++; return unary() }
            return atom()
        }
        private fun atom(): Double {
            var v: Double
            if (i < s.length && s[i] == '(') { i++; v = expr(); if (i >= s.length || s[i] != ')') throw IllegalArgumentException(); i++ }
            else {
                val st = i
                while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
                if (st == i) throw IllegalArgumentException()
                v = s.substring(st, i).toDouble()
            }
            while (i < s.length && s[i] == '%') { i++; v /= 100.0 }
            return v
        }
    }

    /**
     * Returns the reply text, or null when this needs the AI. [run] runs one phone tool (same names as the AI tools).
     */
    fun handle(ctx: Context, text: String, run: (String, JSONObject) -> String): String? {
        val raw = text.trim()
        if (raw.isEmpty()) return null
        val s = raw.lowercase(Locale.ROOT).trim().trimEnd('.', '!', '?', '۔').trim()

        // ---- help
        if (Regex("^(help|madad|offline help|kya kar sakte ho|kya kar sakta hai|what can you do|offline)$").matches(s)) return HELP

        // ---- notes
        Regex("(?:delete|hatao|remove|mita\\w*)\\s+note\\s*#?(\\d+)|note\\s*#?(\\d+)\\s*(?:delete|hatao|remove|mita\\w*)").find(s)?.let { m ->
            val n = (m.groupValues[1].ifEmpty { m.groupValues[2] }).toInt()
            val note = Notes.byNumber(ctx, n) ?: return "Note $n nahi mila. \"notes dikhao\" se list dekhein."
            Notes.delete(ctx, note.id)
            return "Note $n hata diya: " + note.title.ifEmpty { "(no title)" }
        }
        Regex("^notes?\\s*#?(\\d+)(?:\\s+(?:dikhao|padho|kholo|show|read))?$").find(s)?.let { m ->
            val n = m.groupValues[1].toInt()
            val note = Notes.byNumber(ctx, n) ?: return "Note $n nahi mila."
            return (if (note.title.isNotEmpty()) note.title + "\n\n" else "") + note.body
        }
        Regex("^(?:notes?\\s+(?:search|find|dhoondo|dhundo|talash)\\s+|(?:search|find|dhoondo|dhundo)\\s+notes?\\s+)(.+)$").find(s)?.let { m ->
            return Notes.summary(ctx, m.groupValues[1])
        }
        if (Regex("^(?:show |list |my |mere |saare |all )*notes?$|\\bnotes?\\b.*\\b(?:dikhao|dikha|show|list|dekho|kholo|batao|padho)\\b").containsMatchIn(s)) {
            return Notes.summary(ctx)
        }
        Regex("^(?:(?:add|save|new|naya|ek)\\s+)?note\\b\\s*(?:likho|karo|save|add|bana|banao|rakho|kar do|daalo)?\\s*[:\\-]?\\s*(.+)$").find(raw.lowercase(Locale.ROOT))?.let { m ->
            // keep the user's own capitals: cut the same amount from the original text
            val body = raw.substring(raw.length - m.groupValues[1].length).trim()
            if (body.isNotEmpty()) { val n = Notes.add(ctx, "", body); return "Note save ho gaya: " + n.title }
        }
        Regex("^(.+?)\\s+(?:ka |ki |ko )?note\\s*(?:likho|karo|kar do|save|rakho)$").find(raw.lowercase(Locale.ROOT))?.let { m ->
            val body = raw.substring(0, m.groupValues[1].length).trim()
            if (body.isNotEmpty()) { val n = Notes.add(ctx, "", body); return "Note save ho gaya: " + n.title }
        }

        // ---- tasks
        Regex("task\\s*#?(\\d+)\\s*(done|complete\\w*|finish\\w*|ho gaya|khatam|doing|start\\w*|todo|delete|hatao|remove)").find(s)?.let { m ->
            val id = m.groupValues[1].toInt()
            val t = Tasks.find(ctx, id.toString()) ?: return "Task #$id nahi mila. \"tasks dikhao\" se dekhein."
            val w = m.groupValues[2]
            if (w == "delete" || w == "hatao" || w == "remove") { Tasks.delete(ctx, id); return "Task #$id hata diya." }
            Tasks.move(ctx, id, w)
            return "Task #$id (" + t.optString("title") + ") ab " + Tasks.LABELS[when {
                w.startsWith("done") || w.startsWith("complete") || w.startsWith("finish") || w == "ho gaya" || w == "khatam" -> "done"
                w.startsWith("doing") || w.startsWith("start") -> "doing"
                else -> "todo"
            }] + " mein hai."
        }
        if (Regex("^(?:show |list |my |mere |saare |all )*tasks?$|\\btasks?\\b.*\\b(?:dikhao|dikha|show|list|dekho|batao)\\b").containsMatchIn(s)) return Tasks.summary(ctx)
        Regex("^(?:(?:add|new|naya)\\s+)?task\\b\\s*(?:add|likho|karo|banao|bana|daalo|kar do)?\\s*[:\\-]?\\s*(.+)$").find(raw.lowercase(Locale.ROOT))?.let { m ->
            var title = raw.substring(raw.length - m.groupValues[1].length).trim()
            val lead = Regex("^(?:add|karo|likho|banao|bana|daalo|kar do|new)\\b[\\s:\\-]*", RegexOption.IGNORE_CASE)
            while (lead.containsMatchIn(title)) title = title.replaceFirst(lead, "")
            if (title.isNotEmpty()) { val id = Tasks.add(ctx, title); return "Task #$id add ho gaya: $title" }
        }

        // ---- reminders (run by the phone's alarm clock, so they fire with no internet)
        if (Regex("\\b(yaad\\s*dil\\w*|remind\\w*)\\b").containsMatchIn(s)) {
            val d = durationMs(s)
            val c = clock(s)
            var at = 0L
            var cut: IntRange? = null
            if (d != null && d.first > 0) { at = System.currentTimeMillis() + d.first; cut = d.second }
            else if (c != null) { at = Reminders.nextAt(c.first, c.second); cut = c.third }
            if (at == 0L) return "Kitni der baad ya kis waqt? Jaise: \"10 minute baad yaad dilao chai\" ya \"shaam 6 baje yaad dilao call\"."
            var rest = s
            if (cut != null) rest = s.removeRange(cut)
            rest = rest.replace(Regex("\\b(yaad\\s*dil\\w*|remind\\w*)\\b"), " ").replace(Regex("\\b(shaam|sham|subah|subha|raat|rat|dopahar|evening|morning|night|am|pm)\\b"), " ")
            val what = stripEdges(rest.split(Regex("\\s+")).filter { it.isNotEmpty() }).ifEmpty { "yaad dihani" }
            Reminders.add(ctx, at, what, "reminder")
            return "Theek hai, " + fmtTime(at) + " par yaad dila dunga: " + what
        }

        // ---- alarm and timer
        if (Regex("\\balarm\\b").containsMatchIn(s)) {
            val c = clock(s) ?: return "Kis waqt ka alarm? Jaise: \"alarm 6:30 am\"."
            return run("set_alarm", JSONObject().put("hour", c.first).put("minute", c.second).put("label", "Anjoo AI"))
        }
        if (Regex("\\btimer\\b").containsMatchIn(s)) {
            val d = durationMs(s) ?: return "Kitni der ka timer? Jaise: \"timer 5 minute\"."
            return run("set_timer", JSONObject().put("seconds", (d.first / 1000).toInt()).put("label", "Anjoo AI"))
        }

        // ---- phone controls
        if (Regex("\\b(torch|flashlight|flash light)\\b").containsMatchIn(s)) {
            val off = Regex("\\b(off|band|bujha\\w*|stop)\\b").containsMatchIn(s)
            val on = Regex("\\b(on|jala\\w*|chala\\w*|kholo|start)\\b").containsMatchIn(s)
            if (!off && !on) return "Torch on karun ya off?"
            return run("flashlight", JSONObject().put("on", on && !off))
        }
        if (Regex("\\b(volume|awaaz|awaz)\\b").containsMatchIn(s)) {
            val a = when {
                Regex("\\b(mute|silent|khamosh)\\b").containsMatchIn(s) -> "mute"
                Regex("\\b(max|full)\\b").containsMatchIn(s) -> "max"
                Regex("\\b(up|badha\\w*|barha\\w*|zyada|zyadah|increase|loud|high)\\b").containsMatchIn(s) -> "up"
                Regex("\\b(down|kam|ghata\\w*|decrease|low)\\b").containsMatchIn(s) -> "down"
                else -> return "Volume up karun ya down?"
            }
            return run("volume", JSONObject().put("action", a))
        }
        if (Regex("\\b(battery|charge kitna|charging)\\b").containsMatchIn(s)) return run("battery", JSONObject())

        Regex("^(?:open|launch)\\s+(.+)$").find(raw)?.let { m -> return run("open_app", JSONObject().put("name", m.groupValues[1].trim())) }
        Regex("^(.+?)\\s+(?:kholo|khol do|khol dein|open karo|open kar do|chalao|chala do)$", RegexOption.IGNORE_CASE).find(raw)?.let { m ->
            return run("open_app", JSONObject().put("name", m.groupValues[1].trim()))
        }

        // ---- time and date
        if (Regex("^(time|waqt)$|\\b(time|waqt)\\b.*\\b(kya|what|kitna|hua|hai|bata\\w*)\\b|\\bkitne baje\\b|\\bkitna baja\\b").containsMatchIn(s) && !Regex("\\d").containsMatchIn(s)) {
            return "Abhi " + SimpleDateFormat("HH:mm", Locale.ENGLISH).format(Date()) + " baje hain."
        }
        if (Regex("\\b(date|tareekh|tarikh|which day|kaun sa din|aaj kya din)\\b").containsMatchIn(s) && !Regex("\\d").containsMatchIn(s)) {
            return SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).format(Date())
        }

        // ---- calculator
        val ce = s.removePrefix("calculate").removePrefix("calc").removePrefix("hisaab").removePrefix("hisab").trim().trimEnd('=', '?').trim()
        if (ce.isNotEmpty() && CALC_OK.matches(ce)) calc(ce)?.let { return "$ce = $it" }

        return null
    }
}
