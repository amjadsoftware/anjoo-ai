package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The privacy lock must never silently weaken. */
class SandboxTest {

    @Test fun onlyTheAnjooFolderIsInside() {
        assertTrue(Sandbox.inside(listOf("Anjoo AI")))
        assertTrue(Sandbox.inside(listOf("anjoo ai", "Projects", "app")))
        assertFalse(Sandbox.inside(listOf("DCIM", "Camera")))
        assertFalse(Sandbox.inside(listOf("Documents", "Anjoo AI")))
        assertFalse(Sandbox.inside(emptyList()))
    }

    @Test fun appDataIsEncryptedButShareFoldersStayNormal() {
        assertTrue(Sandbox.encrypts(listOf("Anjoo AI", "Chats", "Auto-saved")))
        assertTrue(Sandbox.encrypts(listOf("Anjoo AI", "Projects", "shop")))
        assertTrue(Sandbox.encrypts(listOf("Anjoo AI", "App Backups")))
        assertTrue(Sandbox.encrypts(listOf("Anjoo AI")))
        assertFalse(Sandbox.encrypts(listOf("Anjoo AI", "Documents", "PDF")))
        assertFalse(Sandbox.encrypts(listOf("Anjoo AI", "Chats", "Exports")))
        assertFalse(Sandbox.encrypts(listOf("Anjoo AI", "Images", "Saved")))
        assertFalse(Sandbox.encrypts(listOf("Anjoo AI", "Downloads")))
        assertFalse(Sandbox.encrypts(listOf("DCIM")))
    }

    @Test fun commandsAndCodeCannotWalkIntoOtherFolders() {
        assertTrue(Sandbox.touchesPhone("ls /sdcard/DCIM"))
        assertTrue(Sandbox.touchesPhone("cat /storage/emulated/0/Pictures/a.jpg"))
        assertTrue(Sandbox.touchesPhone("import os; os.listdir('/storage/emulated/0')"))
        assertTrue(Sandbox.touchesPhone("ls /sdcard/Anjoo AI/ ; ls /sdcard/Movies"))
        assertFalse(Sandbox.touchesPhone("ls /sdcard/Anjoo AI/Projects"))
        assertFalse(Sandbox.touchesPhone("print(2 + 2)"))
        assertFalse(Sandbox.touchesPhone("ls -la"))
    }

    @Test fun galleryAndFileManagerAppsAreOffLimits() {
        assertTrue(Sandbox.isMediaApp("com.google.android.apps.photos"))
        assertTrue(Sandbox.isMediaApp("com.sec.android.gallery3d"))
        assertTrue(Sandbox.isMediaApp("com.google.android.documentsui"))
        assertFalse(Sandbox.isMediaApp("com.whatsapp"))
        assertFalse(Sandbox.isMediaApp("com.anjoo.assistant"))
        assertFalse(Sandbox.isMediaApp(null))
    }

    @Test fun internalSavesAreMovedIntoTheAnjooFolder() {
        assertEquals(listOf("Anjoo AI", "Documents", "Anjoo", "Artifacts", "a.html"), Sandbox.remap(listOf("Documents", "Anjoo", "Artifacts", "a.html")))
    }
}
