package com.anjoo.assistant

import org.junit.Assert.assertTrue
import org.junit.Test

/** Guards the quality bar of Anjoo's coding brain: a prompt edit must not silently drop a rule. */
class CoderPromptTest {

    @Test fun rulesAreNumberedWithoutGaps() {
        for (n in 1..22) {
            assertTrue("rule $n is missing", Coder.SYSTEM.contains("\n$n. "))
        }
    }

    @Test fun codeMustBeCompleteAndRunnable() {
        assertTrue(Coder.SYSTEM.contains("Never use placeholders"))
        assertTrue(Coder.SYSTEM.contains("COMPLETE and RUNNABLE"))
    }

    @Test fun everyRequirementMustBeTraced() {
        assertTrue(Coder.SYSTEM.contains("REQUIREMENTS TRACEABILITY"))
    }

    @Test fun deliveryRulesRequireReadmeAndTests() {
        assertTrue(Coder.SYSTEM.contains("README.md"))
        assertTrue(Coder.SYSTEM.contains("TESTABILITY"))
    }

    @Test fun outputFormatDefinesTheFileMarkers() {
        assertTrue(Coder.FORMAT.contains("=== NOTES ==="))
        assertTrue(Coder.FORMAT.contains("=== FILE:"))
    }
}
