package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The bank/wallet/card safety rules must never silently weaken. */
class GuardTest {

    @Test fun bankAndWalletAppsAreBlocked() {
        assertTrue(Guard.isFinancialApp("com.easypaisa.app"))
        assertTrue(Guard.isFinancialApp("com.techlogix.mobilinkcustomer"))
        assertTrue(Guard.isFinancialApp("com.hbl.android.hblmobile"))
        assertTrue(Guard.isFinancialApp("com.samsung.android.spay"))
        assertTrue(Guard.isFinancialApp("COM.PayPal.Android"))
    }

    @Test fun ordinaryAppsAreAllowed() {
        assertFalse(Guard.isFinancialApp("com.whatsapp"))
        assertFalse(Guard.isFinancialApp("com.google.android.youtube"))
        assertFalse(Guard.isFinancialApp("com.android.chrome"))
        assertFalse(Guard.isFinancialApp("com.anjoo.assistant"))
    }

    @Test fun emptyPackageIsNotFinancial() {
        assertFalse(Guard.isFinancialApp(null))
        assertFalse(Guard.isFinancialApp(""))
        assertFalse(Guard.isFinancialApp("   "))
    }

    @Test fun cardNumbersAndSecretsAreDetected() {
        assertTrue(Guard.hasCardData("my card is 4111 1111 1111 1111"))
        assertTrue(Guard.hasCardData("otp is 123456"))
        assertTrue(Guard.hasCardData("CVV: 123"))
    }

    @Test fun phoneNumbersAndPlainTextAreNotCardData() {
        assertFalse(Guard.hasCardData("Call me on 03001234567"))
        assertFalse(Guard.hasCardData("WhatsApp kholo"))
    }

    @Test fun accountNumberNextToItsLabelIsAllowed() {
        assertFalse(Guard.hasCardData("account number: 4111111111111111"))
    }

    @Test fun redactHidesCardNumbersAndOtps() {
        val card = Guard.redact("card 4111 1111 1111 1111 ok")
        assertTrue(card.contains("[card number hidden]"))
        assertFalse(card.contains("4111"))
        assertEquals("otp: [hidden]", Guard.redact("otp: 654321"))
    }

    @Test fun redactKeepsHarmlessText() {
        assertEquals("Subah 6 baje alarm laga do", Guard.redact("Subah 6 baje alarm laga do"))
    }

    @Test fun accountNumbersAreNotCardNumbers() {
        assertTrue(Guard.isAccountNumber("1234567890"))
        assertFalse(Guard.isAccountNumber("4111111111111111"))
        assertFalse(Guard.isAccountNumber("hello world"))
    }
}
