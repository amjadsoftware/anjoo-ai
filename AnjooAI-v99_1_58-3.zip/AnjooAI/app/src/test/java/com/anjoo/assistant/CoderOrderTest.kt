package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Big projects are written in this order, so later files can reuse what earlier files define. */
class CoderOrderTest {

    @Test fun setupThenStylesThenDataThenLogicThenPagesThenDocs() {
        val files = listOf("README.md", "index.html", "about.html", "js/app.js", "data/products.json", "css/style.css", "package.json")
        val sorted = files.sortedBy { Coder.orderRank(it) }
        assertEquals(
            listOf("package.json", "css/style.css", "data/products.json", "js/app.js", "about.html", "index.html", "README.md"),
            sorted
        )
    }

    @Test fun entryPageComesAfterInnerPages() {
        assertTrue(Coder.orderRank("index.html") > Coder.orderRank("pages/contact.html"))
    }

    @Test fun orderingIsStableForEqualRank() {
        val files = listOf("js/b.js", "js/a.js", "js/c.js")
        assertEquals(files, files.sortedBy { Coder.orderRank(it) })
    }
}
