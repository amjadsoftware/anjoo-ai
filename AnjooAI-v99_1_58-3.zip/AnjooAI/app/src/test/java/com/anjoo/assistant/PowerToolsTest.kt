package com.anjoo.assistant

import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PowerToolsTest {
    private val names: List<String> by lazy {
        val d = JSONArray(Gemini.DECLARATIONS)
        (0 until d.length()).map { d.getJSONObject(it).getString("name") }
    }

    @Test fun toolNamesAreUnique() = assertEquals(names.size, names.toSet().size)

    @Test fun universalToolsAreDeclared() {
        for (n in listOf("http_request", "ask_model", "list_tools", "current_time", "device_info",
            "search_calendar", "make_document", "read_document", "look_at_file", "check_keys")) assertTrue("missing $n", n in names)
    }

    @Test fun noLocationTool() { assertTrue("get_location" !in names) }

    @Test fun neverSayNoToolRuleIsInThePrompt() {
        assertTrue(Style.RESOURCEFUL.contains("http_request"))
        assertTrue(Style.RESOURCEFUL.contains("list_tools"))
        assertTrue(!Style.HONEST.contains("mere paas yeh abhi nahi hai"))
    }
}
