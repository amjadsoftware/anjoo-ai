package com.anjoo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DocDetectTest {
    @Test fun documentsAreDetected() {
        assertTrue(Coder.isDocument("climate change par report banao"))
        assertTrue(Coder.isDocument("mera resume banao"))
        assertTrue(Coder.isDocument("write a cover letter for a job"))
    }

    @Test fun softwareIsNotADocument() {
        assertFalse(Coder.isDocument("todo app banao"))
        assertFalse(Coder.isDocument("website banao"))
        assertFalse(Coder.isDocument("python script to rename files"))
    }
}
