package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

/** Provider list integrity and the rules that decide when Auto mode moves to the next free AI. */
class ProvidersTest {

    @Test fun providerIdsAreUnique() {
        val ids = Providers.ALL.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test fun everyProviderHasALabelAndKnownKind() {
        for (p in Providers.ALL) {
            assertTrue("label of ${p.id}", p.label.isNotBlank())
            assertTrue("kind of ${p.id}", p.kind in setOf("gemini", "openai", "anthropic"))
        }
    }

    @Test fun freeProvidersAreAvailable() {
        for (id in listOf("gemini", "groq", "openrouter")) {
            assertEquals(id, Providers.byId(id).id)
        }
    }

    @Test fun unknownProviderFallsBackToTheFirst() {
        assertEquals(Providers.ALL[0].id, Providers.byId("no-such-provider").id)
        assertEquals(Providers.ALL[0].id, Providers.byId(null).id)
    }

    @Test fun quotaServerAndKeyErrorsFailOver() {
        assertTrue(Providers.shouldFailOver(ApiException(429, "quota")))
        assertTrue(Providers.shouldFailOver(ApiException(503, "busy")))
        assertTrue(Providers.shouldFailOver(ApiException(401, "bad key")))
        assertTrue(Providers.shouldFailOver(ApiException(404, "no model")))
    }

    @Test fun badRequestsDoNotFailOver() {
        assertFalse(Providers.shouldFailOver(ApiException(400, "bad request")))
        assertFalse(Providers.shouldFailOver(ApiException(422, "unprocessable")))
    }

    @Test fun networkErrorsFailOverButStopDoesNot() {
        assertTrue(Providers.shouldFailOver(IOException("connection reset")))
        assertFalse(Providers.shouldFailOver(CancelledException()))
        assertFalse(Providers.shouldFailOver(IllegalStateException("bug")))
    }
}

/** The extra companies added with direct key links (v91). */
class MoreProvidersTest {
    private val NEW = listOf("cloudflare", "nvidia", "cohere", "huggingface", "github", "alibaba", "zai", "kilo", "chutes")

    @Test fun newCompaniesArePresentWithModels() {
        for (id in NEW) {
            val p = Providers.byId(id)
            assertEquals(id, p.id)
            assertTrue("models of $id", p.models.isNotEmpty())
            assertEquals("openai", p.kind)
        }
    }

    @Test fun everyCompanyHasADirectKeyLinkWithoutSpaces() {
        for (p in Providers.ALL.filter { it.id != "custom" }) {
            assertTrue("keyUrl of ${p.id}", p.keyUrl.isNotBlank())
            assertFalse("keyUrl of ${p.id} has a space", p.keyUrl.contains(' '))
        }
        for (l in Providers.EXTRA_LINKS) assertTrue(l.label, l.url.isNotBlank() && !l.url.contains(' '))
    }

    @Test fun everyCompanyHasAnAddressExceptCloudflareAndCustom() {
        for (p in Providers.ALL.filter { it.id != "custom" && it.id != "cloudflare" }) assertTrue("base of ${p.id}", p.baseUrl.startsWith("https://"))
    }

    @Test fun keysAreRecognisedByTheirStart() {
        assertEquals("nvidia", Providers.guessProvider("nvapi-abcdefghijklmnopqrstuvwxyz"))
        assertEquals("huggingface", Providers.guessProvider("hf_abcdefghijklmnopqrstuvwxyz"))
        assertEquals("chutes", Providers.guessProvider("cpk_abcdefghijklmnopqrstuvwxyz"))
        assertEquals("github", Providers.guessProvider("github_pat_abcdefghijklmnopqrstuvwxyz"))
        assertEquals("cloudflare", Providers.guessProvider("0123456789abcdef0123456789abcdef:AbCdEfGhIjKlMnOpQrStUvWxYz-_12"))
        assertEquals("zai", Providers.guessProvider("0123456789abcdef0123456789abcdef.AbCdEfGhIjKlMnOp"))
    }

    @Test fun cloudflareKeyIsSplitIntoAccountAndToken() {
        val (base, token) = Providers.endpointFor(Providers.byId("cloudflare"), "abc123:TOKEN-xyz")
        assertEquals("https://api.cloudflare.com/client/v4/accounts/abc123/ai/v1", base)
        assertEquals("TOKEN-xyz", token)
    }

    @Test fun cloudflareKeyWithoutAccountIsRejected() {
        try {
            Providers.endpointFor(Providers.byId("cloudflare"), "justatoken")
            org.junit.Assert.fail("should have thrown")
        } catch (e: IOException) { /* expected */ }
    }

    @Test fun otherCompaniesKeepTheirKeyAndAddress() {
        val (base, token) = Providers.endpointFor(Providers.byId("nvidia"), "nvapi-xyz")
        assertEquals("https://integrate.api.nvidia.com/v1", base)
        assertEquals("nvapi-xyz", token)
    }
}
