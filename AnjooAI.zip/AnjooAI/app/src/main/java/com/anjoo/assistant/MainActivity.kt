package com.anjoo.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.CountDownLatch

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    private val SYSTEM = """
Tum "Anjoo AI" ho, Android phone ka awaazi assistant. User ke hukm tools ke zariye poore karo: app kholna, call, SMS, WhatsApp, alarm, timer, search, rasta.
Agar kaam ke liye tool maujood hai to pehle kaam karo, phir bas ek chhota jumla bolo ke kya hua.
Contact ka naam jaisa user ne bola waisa hi tool ko do. Agar kai contacts milen ya naam saaf na ho to user se ek chhota sawal poochho.
User ke likhe hue ya bole hue ki zubaan aur script mein jawab do: Urdu script ho to Urdu script mein, Roman Urdu ho to Roman Urdu mein, English ho to English mein.
Tumhara jawab awaaz mein parha jayega, isliye bohat chhota rakho: ek ya do jumle, markdown, list ya emoji ke baghair.
Jo kaam tools se nahi ho sakta (jaise doosri app ke andar tap karna), saaf bata do ke yeh abhi nahi ho sakta.
Jab user kahe "yaad rakho" ya koi pakki zaroori baat bataye (naam, rishte, aadatein), remember tool se save karo. Pehle se yaad rakhi baatein neeche likhi hain, unhe zaroorat par istemal karo.
Waqt ya tareekh waale kaam (alarm, calendar) ke liye neeche diye gaye abhi ke waqt se hisab lagao.
""".trim()

    private fun systemPrompt(): String {
        val now = java.text.SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(java.util.Date())
        val n = actions.notes()
        val sb = StringBuilder(SYSTEM)
        sb.append("\nAbhi ka waqt: ").append(now).append(" (").append(java.util.TimeZone.getDefault().id).append(").")
        if (n.isNotEmpty()) sb.append("\nYaad rakhi baatein:\n- ").append(n.joinToString("\n- "))
        return sb.toString()
    }

    private lateinit var log: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var mic: Button
    private lateinit var langBtn: Button

    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    @Volatile private var busy = false
    private var lang = "ur-PK"

    private val DEFAULT_MODEL = "gemini-3.8-flash"

    private val history = JSONArray()
    private lateinit var actions: Actions
    private val prefs by lazy { getSharedPreferences("anjoo", MODE_PRIVATE) }

    private val BG = Color.parseColor("#0E1512")
    private val SURFACE = Color.parseColor("#17211C")
    private val ACCENT = Color.parseColor("#3FD2A5")
    private val USER = Color.parseColor("#17695A")
    private val INK = Color.parseColor("#E6EFE9")
    private val MUTED = Color.parseColor("#93A59B")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        requestPermissions(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS
            ), 1
        )
        tts = TextToSpeech(this, this)
        actions = Actions(this) { confirmDialog(it) }
        addBubble("Assalam o Alaikum! Mic dabayein aur hukm dein.", false)
        if (apiKey().isEmpty()) showSettings()
    }

    override fun onDestroy() {
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        ttsOk = status == TextToSpeech.SUCCESS
    }

    // ---------- UI ----------

    private fun roundBg(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat() }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(BG)
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val title = TextView(this).apply {
            text = "Anjoo AI"
            setTextColor(INK)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
        }
        top.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        langBtn = smallButton("اردو") { toggleLang() }
        top.addView(langBtn)
        top.addView(smallButton("Settings") { showSettings() })
        root.addView(top)

        log = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(log) }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        input = EditText(this).apply {
            hint = "Ya yahan likhein..."
            setHintTextColor(MUTED)
            setTextColor(INK)
            background = roundBg(SURFACE, dp(22))
            setPadding(dp(16), dp(10), dp(16), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            maxLines = 3
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, id, _ ->
                if (id == EditorInfo.IME_ACTION_SEND) { sendTyped(); true } else false
            }
        }
        row.addView(input, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(smallButton("Bhejein") { sendTyped() })
        root.addView(row)

        mic = Button(this).apply {
            text = "Bolein"
            textSize = 18f
            setTextColor(Color.parseColor("#04251B"))
            background = roundBg(ACCENT, dp(32))
            setOnClickListener { onMicClick() }
        }
        val mlp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(64))
        mlp.topMargin = dp(10)
        root.addView(mic, mlp)

        setContentView(root)
    }

    private fun smallButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(INK)
        background = roundBg(SURFACE, dp(18))
        setPadding(dp(14), 0, dp(14), 0)
        minHeight = 0
        minimumHeight = dp(40)
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, dp(40)
        ).apply { leftMargin = dp(8) }
        setOnClickListener { onClick() }
    }

    private fun addBubble(text: String, user: Boolean) {
        runOnUiThread {
            val tv = TextView(this).apply {
                this.text = text
                textSize = 16f
                setTextColor(INK)
                textDirection = TextView.TEXT_DIRECTION_FIRST_STRONG
                background = roundBg(if (user) USER else SURFACE, dp(18))
                setPadding(dp(14), dp(10), dp(14), dp(10))
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
            )
            lp.topMargin = dp(8)
            lp.gravity = if (user) Gravity.END else Gravity.START
            lp.marginStart = if (user) dp(48) else 0
            lp.marginEnd = if (user) 0 else dp(48)
            log.addView(tv, lp)
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun setMic(text: String) = runOnUiThread { mic.text = text }

    // ---------- settings ----------

    private fun apiKey() = prefs.getString("key", "") ?: ""
    private fun model() = prefs.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL

    private fun showSettings() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), 0)
        }
        val key = EditText(this).apply {
            hint = "Gemini API key (AIza...)"
            setText(apiKey())
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val mod = EditText(this).apply {
            hint = "Model"
            setText(model())
            inputType = InputType.TYPE_CLASS_TEXT
        }
        box.addView(key)
        box.addView(mod)
        AlertDialog.Builder(this)
            .setTitle("Settings")
            .setMessage("API key aistudio.google.com/apikey se banayein. Model ka naam wahin se dekh kar badal sakte hain (default: gemini-3.8-flash).")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit()
                    .putString("key", key.text.toString().trim())
                    .putString("model", mod.text.toString().trim().ifEmpty { DEFAULT_MODEL })
                    .apply()
            }
            .setNegativeButton("Band", null)
            .show()
    }

    private fun toggleLang() {
        lang = if (lang == "ur-PK") "en-US" else "ur-PK"
        langBtn.text = if (lang == "ur-PK") "اردو" else "English"
    }

    private fun confirmDialog(msg: String): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        runOnUiThread {
            AlertDialog.Builder(this)
                .setMessage(msg)
                .setCancelable(false)
                .setPositiveButton("Haan") { _, _ -> ok = true; latch.countDown() }
                .setNegativeButton("Nahi") { _, _ -> latch.countDown() }
                .show()
        }
        latch.await()
        return ok
    }

    // ---------- voice in ----------

    private fun onMicClick() {
        tts?.stop()
        if (busy) return
        if (listening) { recognizer?.stopListening(); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Mic ki ijazat dein (Settings > Apps > Anjoo AI > Permissions).", Toast.LENGTH_LONG).show()
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Is phone par awaaz pehchaan maujood nahi. Google app install karein.", Toast.LENGTH_LONG).show()
            return
        }
        if (apiKey().isEmpty()) { showSettings(); return }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { listening = true; setMic("Sun raha hoon...") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false; setMic("Samajh raha hoon...") }
            override fun onError(error: Int) {
                listening = false
                setMic("Bolein")
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Awaaz samajh nahi aayi, dobara bolein."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Internet check karein."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic ki ijazat nahi."
                    else -> "Awaaz ka masla aaya ($error)."
                }
                Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
            }
            override fun onResults(results: Bundle?) {
                listening = false
                setMic("Bolein")
                val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = list?.firstOrNull()
                if (!text.isNullOrBlank()) submit(text)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        recognizer?.startListening(i)
    }

    private fun sendTyped() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        submit(t)
    }

    // ---------- Claude loop ----------

    private fun submit(text: String) {
        if (busy) return
        if (apiKey().isEmpty()) { showSettings(); return }
        busy = true
        addBubble(text, true)
        setMic("Soch raha hoon...")
        Thread { runAgent(text) }.start()
    }

    private fun trimHistory() {
        // Keep roughly the last 30 messages, always starting at a plain user message.
        while (history.length() > 30) history.remove(0)
        while (history.length() > 0) {
            val m = history.getJSONObject(0)
            val first = m.getJSONArray("parts").optJSONObject(0)
            if (m.getString("role") == "user" && first != null && first.has("text")) break
            history.remove(0)
        }
    }

    private fun runAgent(text: String) {
        trimHistory()
        val startSize = history.length()
        history.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", text)))
        )
        var finalText = ""
        try {
            var steps = 0
            while (steps++ < 8) {
                val resp = Gemini.send(apiKey(), model(), systemPrompt(), history)
                val cands = resp.optJSONArray("candidates")
                if (cands == null || cands.length() == 0) {
                    val why = resp.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
                    throw java.io.IOException("Jawab nahi mila. $why".trim())
                }
                val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                    ?: JSONArray()
                // Keep the model turn exactly as received (Gemini needs thought signatures echoed back).
                if (parts.length() > 0) {
                    history.put(JSONObject().put("role", "model").put("parts", parts))
                }

                val results = JSONArray()
                val said = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val fc = p.optJSONObject("functionCall")
                    if (fc != null) {
                        val name = fc.getString("name")
                        val out = try {
                            actions.run(name, fc.optJSONObject("args") ?: JSONObject())
                        } catch (e: Exception) {
                            "Kaam nahi ho saka: " + (e.message ?: e.javaClass.simpleName)
                        }
                        results.put(
                            JSONObject().put(
                                "functionResponse",
                                JSONObject().put("name", name)
                                    .put("response", JSONObject().put("result", out))
                            )
                        )
                    } else if (p.has("text") && !p.optBoolean("thought", false)) {
                        said.append(p.getString("text")).append(' ')
                    }
                }
                if (said.isNotBlank()) finalText = said.toString().trim()
                if (results.length() == 0) break
                history.put(JSONObject().put("role", "user").put("parts", results))
            }
            if (finalText.isNotEmpty()) {
                addBubble(finalText, false)
                speak(finalText)
            }
        } catch (e: Exception) {
            while (history.length() > startSize) history.remove(history.length() - 1)
            addBubble("Masla: " + (e.message ?: e.javaClass.simpleName), false)
        } finally {
            busy = false
            setMic("Bolein")
        }
    }

    // ---------- voice out ----------

    private fun speak(text: String) {
        val engine = tts ?: return
        if (!ttsOk) return
        val urduScript = text.any { it in '؀'..'ۿ' }
        val locale = if (urduScript) Locale("ur", "PK") else Locale("en", "IN")
        val r = engine.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) return
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "anjoo")
    }
}
