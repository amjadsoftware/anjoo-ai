# Anjoo AI v100.0.40 — Claude Skills integration

## What was added
Claude Skills pack (20 skills, 446 files) is bundled (`app/src/main/assets/skills_pack.zip`, sha256 verified) and auto-installed on first start into `filesDir/skills`. No database / migration: file-based store, nothing existing is changed or removed.

## How it works (automatic, user never names a skill)
1. **Import/validate** (`SkillCore.extractZip`, `SkillStore.importZip`): zip-slip, size/ratio/entry limits; original structure preserved byte-for-byte; duplicates detected, updates tracked by content hash/version; files outside skills kept in `_pack/`; problems reported, never silently skipped.
2. **Registry/metadata**: SKILL.md frontmatter parsed (name, description, version); cached metadata only — skills are never all loaded per request.
3. **Router** (`SkillCore.route`): BM25-style scoring on name/description/triggers/synonyms (incl. Roman Urdu/Urdu), threshold + relative cut, max 3 skills, user-named skill wins, follow-ups stay sticky.
4. **Dynamic loader/compose**: only chosen skills' full SKILL.md are loaded; orchestration with precedence (user > app safety > skills; format skill > design > workflow); size cut is announced and rest is read via `skill_read offset=`.
5. **Tools** (5 new): `skill_find`, `skill_files`, `skill_read`, `skill_run`, `skill_verify`.
6. **Execution**: Python scripts run in a Pyodide sandbox (`SkillRunner`) with virtual FS only. Static analysis classifies scripts (runnable / needs packages / unsupported / blocked). Bundled scripts trusted; imported scripts need "Allow scripts"; per-run confirmation; tamper check by sha256.
7. **Verification** (`Skills.finish`): a "Verification" step is added to the chat timeline from real checks.
8. **UI**: Tools → "Skills" tab (no new nav item): Installed / Active / History, auto switch, import/update ZIP, details, SKILL.md viewer, enable/disable, search, delete. Execution history and logs are stored per skill.

## Install / start
Build as usual (Gradle). First launch installs the bundled pack automatically. Import more skills via Tools → Skills → Import ZIP. Turn auto-routing off with the switch there.

## Imported skills (20)
academy-guide, algorithmic-art, brand-guidelines, canvas-design, claude-api, discernment-nudge, doc-coauthoring, docx, frontend-design, internal-comms, mcp-builder, pdf, pptx, skill-creator, slack-gif-creator, template-skill (disabled by default: placeholder), theme-factory, web-artifacts-builder, webapp-testing, xlsx.
5 non-skill pack files (README, THIRD_PARTY_NOTICES, spec, .claude-plugin, .gitignore) are kept under `_pack/`.

## Unsupported / incompatible on a phone (reported, not hidden)
Scripts: 77 total → 38 run (Python), 13 run after downloading Python packages (internet), 25 cannot run on a phone, 1 blocked by the security check. Instructions and references of those skills still work.

### Unsupported / blocked scripts
```
UNSUPPORTED / BLOCKED SCRIPTS
- algorithmic-art/templates/generator_template.js: UNSUPPORTED — needs Node.js, which is not on the phone
- claude-api/shared/evals/report/build-report-lite.mjs: UNSUPPORTED — needs Node.js, which is not on the phone
- claude-api/shared/evals/report/runner-scaffold.mjs: UNSUPPORTED — needs Node.js, which is not on the phone
- claude-api/shared/preserved-thinking-migration/drop_block_probe.py: UNSUPPORTED — imports 'socket': raw sockets are not available
- docx/scripts/accept_changes.py: UNSUPPORTED — imports 'subprocess': starts external programs (not available on Android/WebAssembly)
- docx/scripts/office/soffice.py: UNSUPPORTED — imports 'socket': raw sockets are not available
- docx/scripts/office/validators/redlining.py: UNSUPPORTED — imports 'subprocess': starts external programs (not available on Android/WebAssembly)
- mcp-builder/scripts/evaluation.py: UNSUPPORTED — imports 'anthropic': needs the Anthropic SDK and network from Python
- pdf/scripts/convert_pdf_to_images.py: UNSUPPORTED — imports 'pdf2image': needs poppler
- pdf/scripts/extract_form_structure.py: UNSUPPORTED — imports 'pdfplumber': not available in Pyodide
- pptx/scripts/office/soffice.py: UNSUPPORTED — imports 'socket': raw sockets are not available
- pptx/scripts/office/validators/redlining.py: UNSUPPORTED — imports 'subprocess': starts external programs (not available on Android/WebAssembly)
- pptx/scripts/thumbnail.py: UNSUPPORTED — imports 'subprocess': starts external programs (not available on Android/WebAssembly)
- skill-creator/eval-viewer/generate_review.py: BLOCKED — uses process/delete call in os
- skill-creator/scripts/improve_description.py: UNSUPPORTED — imports 'subprocess': starts external programs (not available on Android/WebAssembly)
- skill-creator/scripts/run_eval.py: UNSUPPORTED — imports 'subprocess': starts external programs (not available on Android/WebAssembly)
- slack-gif-creator/core/gif_builder.py: UNSUPPORTED — imports 'imageio': not available
- web-artifacts-builder/scripts/bundle-artifact.sh: UNSUPPORTED — shell scripts need a Linux environment
- web-artifacts-builder/scripts/init-artifact.sh: UNSUPPORTED — shell scripts need a Linux environment
- webapp-testing/examples/console_logging.py: UNSUPPORTED — imports 'playwright': needs a real browser
- webapp-testing/examples/element_discovery.py: UNSUPPORTED — imports 'playwright': needs a real browser
- webapp-testing/examples/static_html_automation.py: UNSUPPORTED — imports 'playwright': needs a real browser
- webapp-testing/scripts/with_server.py: UNSUPPORTED — imports 'subprocess': starts external programs (not available on Android/WebAssembly)
- xlsx/scripts/office/soffice.py: UNSUPPORTED — imports 'socket': raw sockets are not available
- xlsx/scripts/office/validators/redlining.py: UNSUPPORTED — imports 'subprocess': starts external programs (not available on Android/WebAssembly)
- xlsx/scripts/recalc.py: UNSUPPORTED — imports 'subprocess': starts external programs (not available on Android/WebAssembly)

NEEDS PACKAGES
- docx/scripts/comment.py: needs defusedxml from PyPI (pure-Python only)
- docx/scripts/merge_runs.py: needs defusedxml from PyPI (pure-Python only)
- docx/scripts/office/validate.py: needs defusedxml from PyPI (pure-Python only)
- docx/scripts/office/validators/base.py: needs defusedxml from PyPI (pure-Python only)
- docx/scripts/office/validators/docx.py: needs defusedxml from PyPI (pure-Python only)
- mcp-builder/scripts/connections.py: needs mcp from PyPI (pure-Python only)
- pptx/scripts/clean.py: needs defusedxml from PyPI (pure-Python only)
- pptx/scripts/office/validate.py: needs defusedxml from PyPI (pure-Python only)
- pptx/scripts/office/validators/base.py: needs defusedxml from PyPI (pure-Python only)
- pptx/scripts/office/validators/docx.py: needs defusedxml from PyPI (pure-Python only)
- xlsx/scripts/office/validate.py: needs defusedxml from PyPI (pure-Python only)
- xlsx/scripts/office/validators/base.py: needs defusedxml from PyPI (pure-Python only)
- xlsx/scripts/office/validators/docx.py: needs defusedxml from PyPI (pure-Python only)

RUNNABLE
- claude-api/shared/preserved-thinking-migration/prefix_diff.py
- docx/scripts/__init__.py
- docx/scripts/office/helpers/__init__.py
- docx/scripts/office/helpers/pptx_chart.py
- docx/scripts/office/helpers/pptx_slide.py
- docx/scripts/office/helpers/pptx_theme.py
- docx/scripts/office/validators/__init__.py
- docx/scripts/office/validators/pptx.py
- pdf/scripts/check_bounding_boxes.py
- pdf/scripts/check_fillable_fields.py
- pdf/scripts/create_validation_image.py
- pdf/scripts/extract_form_field_info.py
- pdf/scripts/fill_fillable_fields.py
- pdf/scripts/fill_pdf_form_with_annotations.py
- pptx/scripts/__init__.py
- pptx/scripts/add_slide.py
- pptx/scripts/office/helpers/__init__.py
- pptx/scripts/office/helpers/pptx_chart.py
- pptx/scripts/office/helpers/pptx_slide.py
- pptx/scripts/office/helpers/pptx_theme.py
- pptx/scripts/office/validators/__init__.py
- pptx/scripts/office/validators/pptx.py
- skill-creator/scripts/__init__.py
- skill-creator/scripts/aggregate_benchmark.py
- skill-creator/scripts/generate_report.py
- skill-creator/scripts/package_skill.py
- skill-creator/scripts/quick_validate.py
- skill-creator/scripts/run_loop.py
- skill-creator/scripts/utils.py
- slack-gif-creator/core/easing.py
- slack-gif-creator/core/frame_composer.py
- slack-gif-creator/core/validators.py
- xlsx/scripts/office/helpers/__init__.py
- xlsx/scripts/office/helpers/pptx_chart.py
- xlsx/scripts/office/helpers/pptx_slide.py
- xlsx/scripts/office/helpers/pptx_theme.py
- xlsx/scripts/office/validators/__init__.py
- xlsx/scripts/office/validators/pptx.py
```

Notes: template-skill is a placeholder; claude-api description is 1068 chars (>1024 recommended).
The pack has no backend/database skills, so an "e-commerce site" request activates frontend-design + web-artifacts-builder only.

## Testing report (honest)
**Tested (JVM, 31 unit tests, all pass):** import of all 20 skills / 446 files with byte-for-byte preservation; duplicates, updates, version tracking; bad SKILL.md reporting; zip-slip/case/size limits; safe path resolution incl. symlink; frontmatter forms; routing (positive, negative, multi-skill, user-named, disabled, imported); composition and truncation; references/errors; find tool; script classification of all 77 scripts; dangerous-code detection; script gate/tamper; delete/history; verifier. Skills.kt and SkillRunner.kt type-check against stubs; tool declarations JSON valid (164 unique tools).

**NOT tested (no Android SDK / device / network here):** full Gradle build; SkillsActivity UI on a device (hand-reviewed only); live chat activation in MainActivity/Agent; Pyodide script execution on the phone; regression of existing features on a device. Build and smoke-test these before relying on them.
