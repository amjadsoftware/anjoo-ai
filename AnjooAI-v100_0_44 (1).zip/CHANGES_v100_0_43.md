# v100.0.43 — PPT Master in Anjoo

Anjoo can now build professional, fully editable PowerPoint decks with PPT Master (https://github.com/hugohe3/ppt-master, MIT) and edit existing .pptx files.

## What was added
- `assets/ppt_master_pack.zip` (+ `.sha256`): the `ppt-master` skill as a second bundled pack. Upstream files are byte-identical
  (SKILL.md, LICENSE, SPONSORS*.md, scripts, references, workflows, templates), so PPT Master's attribution/integrity guard passes.
  Left out only: `scripts/tests`, `templates/sounds` (13 MB audio) and the icon libraries (see next line). Added: `ANJOO_PHONE.md`
  (how the desktop instructions map onto phone tools; appended to the skill instructions when the skill is active).
- `assets/ppt_icons.zip`: all 12,027 PPT Master icons, kept zipped; only the icons a deck references are mounted at build time.
- `assets/anjoo_ppt_driver.py`: runs the real PPT Master scripts in-process in the Pyodide sandbox (no subprocess).
- `PptRun.kt` + tool `ppt_run` (actions: new, build, import, exec, icons, info). A deck is a Code Studio project; slides are
  `svg_output/pNN_*.svg` written with `project_write`. `build` = PPT Master quality gate -> native editable .pptx; `import` + `build mode=edit`
  = edit an existing .pptx; PPTX is saved with FileAccess and the project gets an `index.html` slide preview.
- `SkillRunner.run`: optional `extraReqs` (micropip, python-pptx is installed this way), `importsOverride`, `maxOutBytes` (all defaulted; existing callers unchanged).
- `Skills.ensureBuiltIn` installs the second pack (own sha preference); `SkillStore.load` appends `ANJOO_PHONE.md`.
- Wiring: Gemini declaration, MoreTools dispatch, ToolRegistry (category/risk/hint), Actions + MainActivity labels, master instructions.
- Test: `PptMasterPackTest.kt`. The existing skills pack and `SkillsTest` counts are untouched.

## Not available on the phone (stated honestly to the model and user)
Narration audio, video export, live preview server, confirm UI, animation sounds, PPT Master's own AI image generation
(use `generate_image`, pass the file in `inputs`). First run needs internet (Python runtime + python-pptx via PyPI). A build has a 4-minute limit.

## Verified vs not verified
Verified on a desktop with CPython 3.12: the PPT Master pipeline (checker -> exporter, icons, Urdu text, PPTX round-trip edit) through the exact driver and
the exact trimmed pack, also with threads/subprocess/fcntl disabled to imitate Pyodide; output passes the OOXML validator and renders correctly.
NOT verified (no Android SDK / Pyodide in the build environment): Kotlin compilation, JUnit run, and the run inside the phone's Pyodide.
