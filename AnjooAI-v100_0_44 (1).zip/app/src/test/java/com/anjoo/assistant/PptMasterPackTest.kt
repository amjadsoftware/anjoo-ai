package com.anjoo.assistant

import org.json.JSONArray
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.util.zip.ZipFile

/** The bundled PPT Master pack (src/main/assets/ppt_master_pack.zip) and the pieces ppt_run depends on. */
class PptMasterPackTest {
    private val assets = File("src/main/assets")
    private val pack = File(assets, "ppt_master_pack.zip")
    private lateinit var tmp: File
    private lateinit var store: SkillStore

    @Before fun setUp() {
        tmp = File(System.getProperty("java.io.tmpdir"), "pptmaster-test-" + System.nanoTime()); tmp.mkdirs()
        store = SkillStore(File(tmp, "skills"))
    }

    private fun importPack(): SkillStore.ImportReport = pack.inputStream().use { store.importZip(it, "bundled-ppt", true, tmp) }

    @Test fun packChecksumMatchesItsShaFile() {
        val shipped = File(assets, "ppt_master_pack.zip.sha256").readText().trim().substringBefore(' ')
        assertEquals(shipped, SkillCore.sha256(pack.readBytes()))
    }

    @Test fun packInstallsAsOneSkillWithoutRejections() {
        val r = importPack()
        assertEquals(r.text(), 1, r.imported.size)
        assertTrue(r.text(), r.rejected.isEmpty())
        assertNotNull(store.find("ppt-master"))
    }

    @Test fun attributionAndIdentityFilesAreByteIdenticalToTheUpstreamEntries() {
        importPack()
        val dir = store.skillDir("ppt-master")
        ZipFile(pack).use { zf ->
            for (n in listOf("SKILL.md", "LICENSE", "SPONSORS.md", "SPONSORS_CN.md", "scripts/attribution_guard.py")) {
                val e = zf.getEntry("ppt-master/$n")
                assertNotNull("missing in pack: $n", e)
                assertTrue("not installed: $n", File(dir, n).isFile)
                assertTrue("changed on install: $n", zf.getInputStream(e).use { it.readBytes() }.contentEquals(File(dir, n).readBytes()))
            }
        }
    }

    @Test fun everythingPptRunMountsIsThere() {
        importPack()
        val dir = store.skillDir("ppt-master")
        for (n in listOf("ANJOO_PHONE.md", "scripts/svg_to_pptx.py", "scripts/svg_quality_checker.py", "scripts/pptx_to_svg.py", "scripts/project_manager.py",
            "scripts/console_encoding.py", "scripts/pptx_shapes/data/presetShapeDefinitions.xml", "scripts/pptx_animation_presets.json",
            "workflows/profiles/quick-generate.md", "references/shared-standards-core.md", "references/executor-base.md", "references/canvas-formats.md")) {
            assertTrue("missing: $n", File(dir, n).isFile)
        }
        val runtime = store.meta("ppt-master")!!.files.count { it.path.startsWith("scripts/") && it.path.substringAfterLast('.', "") in setOf("py", "json", "xml") }
        assertTrue("runtime files: $runtime", runtime >= 200)
    }

    @Test fun phoneNotesAreAppendedToTheLoadedInstructions() {
        importPack()
        val doc = store.enabledDocs().first { it.id == "ppt-master" }
        val loaded = store.load(listOf(SkillCore.Pick(doc, 10.0, "test")))
        assertEquals(1, loaded.size)
        assertTrue(loaded[0].text.contains("ANJOO PHONE ADAPTATION"))
        assertTrue(loaded[0].text.contains("ppt_run"))
    }

    @Test fun iconLibraryAndDriverAssetsAreShipped() {
        ZipFile(File(assets, "ppt_icons.zip")).use { zf ->
            assertNotNull(zf.getEntry("tabler-outline/home.svg"))
            assertTrue(zf.size() >= 12000)
        }
        val driver = File(assets, "anjoo_ppt_driver.py").readText()
        assertTrue(driver.contains("skill_runtime.zip"))
        assertTrue(driver.contains("job.json"))
    }

    @Test fun pptRunIsDeclaredAsATool() {
        val decls = JSONArray(Gemini.DECLARATIONS)
        var found = false
        for (i in 0 until decls.length()) {
            val o = decls.optJSONObject(i) ?: continue
            if (o.optString("name") == "ppt_run") {
                found = true
                assertTrue(o.getJSONObject("parameters").getJSONObject("properties").has("action"))
            }
        }
        assertTrue(found)
    }
}
