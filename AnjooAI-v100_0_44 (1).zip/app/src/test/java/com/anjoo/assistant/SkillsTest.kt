package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/** Tests of the Skills system on the REAL bundled pack (src/main/assets/skills_pack.zip) plus hostile ZIPs. */
class SkillsTest {
    private val pack = File(System.getProperty("skills.pack") ?: "src/main/assets/skills_pack.zip")
    private lateinit var tmp: File
    private lateinit var store: SkillStore

    @Before fun setUp() {
        tmp = File(System.getProperty("java.io.tmpdir"), "skills-test-" + System.nanoTime()); tmp.mkdirs()
        store = SkillStore(File(tmp, "skills"))
    }

    private fun importPack(): SkillStore.ImportReport = pack.inputStream().use { store.importZip(it, "bundled", true, tmp) }
    private fun zipOf(vararg entries: Pair<String, String>): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z -> for ((n, c) in entries) { z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray()); z.closeEntry() } }
        return bo.toByteArray()
    }
    private fun skillMd(name: String, desc: String) = "---\nname: $name\ndescription: $desc\n---\n# $name\nDo the thing.\n"

    // ── 1. import ───────────────────────────────────────────────
    @Test fun allSkillsImportWithNoRejections() {
        val r = importPack()
        assertEquals(r.text(), 20, r.imported.size)
        assertTrue(r.text(), r.rejected.isEmpty())
        assertTrue(r.text(), r.problems.isEmpty())
        assertEquals(r.text(), 5, r.extras.size)
        assertEquals(446, r.totalFiles)
        assertEquals(20, store.list().size)
    }

    @Test fun originalFileContentsArePreservedByteForByte() {
        importPack()
        val zf = ZipFile(pack)
        var checked = 0
        for (e in zf.entries()) {
            if (e.isDirectory) continue
            val rel = e.name.removePrefix("skills-main/")
            val f = when {
                rel.startsWith("skills/") -> File(store.skillDir(rel.removePrefix("skills/").substringBefore('/')), rel.removePrefix("skills/").substringAfter('/'))
                rel.startsWith("template/") -> File(store.skillDir("template-skill"), rel.removePrefix("template/"))
                else -> File(store.root, "_pack/bundled/" + e.name)      // README, licences, spec, plugin manifest
            }
            val id = f.path
            assertTrue("missing $id", f.isFile)
            assertEquals("content differs: $id", SkillCore.sha256(zf.getInputStream(e).readBytes()), SkillCore.sha256(f.readBytes()))
            checked++
        }
        assertEquals(446, checked)
    }

    @Test fun dotfilesAndNestedFoldersSurvive() {
        importPack()
        assertTrue(File(store.skillDir("docx"), "scripts/office/validators/redlining.py").isFile)
        assertTrue(store.get("claude-api")!!.fileCount >= 90)
        assertTrue(store.integrityProblems("docx").isEmpty())
    }

    @Test fun secondImportIsDetectedAsDuplicateNotReinstalled() {
        importPack()
        val r = importPack()
        assertEquals(20, r.unchanged.size); assertTrue(r.imported.isEmpty()); assertTrue(r.updated.isEmpty())
    }

    @Test fun changedSkillIsUpdatedAndVersionTracked() {
        store.importZip(zipOf("a/SKILL.md" to skillMd("demo", "Does demo things for tests only")).inputStream(), "zip", false, tmp)
        val v1 = store.get("demo")!!
        store.setEnabled("demo", false)
        val r = store.importZip(zipOf("a/SKILL.md" to (skillMd("demo", "Does demo things for tests only") + "more\n")).inputStream(), "zip", false, tmp)
        assertEquals(1, r.updated.size)
        val v2 = store.get("demo")!!
        assertTrue(v1.hash != v2.hash); assertEquals(v1.version, v2.prevVersion)
        assertFalse("user's disabled choice survives an update", v2.enabled)
    }

    @Test fun sameFilesUnderAnotherNameAreRejectedAsDuplicate() {
        store.importZip(zipOf("a/SKILL.md" to skillMd("one", "First skill description")).inputStream(), "zip", false, tmp)
        val r = store.importZip(zipOf("b/SKILL.md" to skillMd("one", "First skill description").replace("name: one", "name: two")).inputStream(), "zip", false, tmp)
        // different name => different SKILL.md text => not identical; installs as a second skill
        assertEquals(listOf("two"), r.imported)
        val r2 = store.importZip(zipOf("c/SKILL.md" to skillMd("one", "First skill description")).inputStream(), "zip", false, tmp)
        assertEquals(listOf("one"), r2.unchanged)
    }

    @Test fun templateSkillIsImportedButDisabledByDefault() {
        importPack()
        val t = store.get("template-skill")!!
        assertFalse(t.enabled)
        assertEquals(19, store.enabledDocs().size)
    }

    @Test fun badSkillMdIsReportedNotSilentlySkipped() {
        val r = store.importZip(zipOf("x/SKILL.md" to "no frontmatter here", "y/SKILL.md" to "---\nname: ok-skill\n---\nbody").inputStream(), "zip", false, tmp)
        assertEquals(2, r.rejected.size)
        assertTrue(r.rejected.any { it.second.contains("---") })
        assertTrue(r.rejected.any { it.second.contains("description") })
    }

    @Test fun zipWithoutAnySkillIsReported() {
        val r = store.importZip(zipOf("readme.txt" to "hi").inputStream(), "zip", false, tmp)
        assertTrue(r.rejected.isNotEmpty())
    }

    // ── 2. ZIP safety ───────────────────────────────────────────
    @Test fun zipSlipAndAbsolutePathsAreRefused() {
        val bytes = zipOf("../evil.txt" to "x", "/abs.txt" to "x", "ok/SKILL.md" to skillMd("safe-one", "A safe skill used in tests"), "ok/../../up.txt" to "x")
        val dest = File(tmp, "x")
        val ex = SkillCore.extractZip(bytes.inputStream(), dest)
        assertEquals(listOf("ok/SKILL.md"), ex.files)
        assertEquals(3, ex.problems.size)
        assertFalse(File(tmp, "evil.txt").exists()); assertFalse(File(tmp, "up.txt").exists())
    }

    @Test fun caseCollisionsAndJunkAreReported() {
        val ex = SkillCore.extractZip(zipOf("a/SKILL.md" to "x", "A/skill.md" to "y", "__MACOSX/a" to "z", "a/.DS_Store" to "q").inputStream(), File(tmp, "y"))
        assertEquals(1, ex.files.size)
        assertEquals(1, ex.problems.size)
        assertEquals(2, ex.skipped.size)
    }

    @Test fun oversizedFilesAreRefused() {
        val big = "a".repeat(200_000)
        val ex = SkillCore.extractZip(zipOf("s/SKILL.md" to "x", "s/big.txt" to big).inputStream(), File(tmp, "z"), SkillCore.ZipLimits(maxFileBytes = 100_000))
        assertEquals(listOf("s/SKILL.md"), ex.files); assertEquals(1, ex.problems.size)
    }

    @Test fun safeResolveBlocksEscapes() {
        val root = File(tmp, "r").also { it.mkdirs() }
        assertNull(SkillCore.safeResolve(root, "../x")); assertNull(SkillCore.safeResolve(root, "/etc/passwd")); assertNull(SkillCore.safeResolve(root, "a/../../x"))
        assertNull(SkillCore.safeResolve(root, "C:\\Windows")); assertNull(SkillCore.safeResolve(root, ""))
        assertNotNull(SkillCore.safeResolve(root, "a/b/c.txt")); assertNotNull(SkillCore.safeResolve(root, "./a//b.txt"))
        // symlink pointing outside must not be followed
        val outside = File(tmp, "outside.txt").also { it.writeText("secret") }
        try { java.nio.file.Files.createSymbolicLink(File(root, "link.txt").toPath(), outside.toPath()); assertNull(SkillCore.safeResolve(root, "link.txt")) } catch (_: UnsupportedOperationException) {}
    }

    // ── 3. frontmatter ──────────────────────────────────────────
    @Test fun frontmatterFormsParse() {
        val a = SkillCore.parseFrontmatter("---\nname: x-y\ndescription: >\n  folded text\n  continues here\nlicense: MIT\nmetadata:\n  version: 2.1\n---\nBODY")
        assertTrue(a.ok); assertEquals("folded text continues here", a.description); assertEquals("2.1", a.version); assertEquals("BODY", a.body); assertEquals("MIT", a.license)
        val b = SkillCore.parseFrontmatter("---\nname: q\ndescription: \"He said \\\"hi\\\": ok\"\n---\n")
        assertEquals("He said \"hi\": ok", b.description)
        val c = SkillCore.parseFrontmatter("---\nname: q\ndescription: |-\n  line1\n  line2\n---\n")
        assertEquals("line1\nline2", c.description)
        assertFalse(SkillCore.parseFrontmatter("---\nname: q\n---\n").ok)
        assertFalse(SkillCore.parseFrontmatter("# no fm").ok)
        assertFalse(SkillCore.parseFrontmatter("---\nname: q\ndescription: d").ok)
    }

    // ── 4. routing ──────────────────────────────────────────────
    private fun routeNames(q: String, store: SkillStore = this.store): List<String> = SkillCore.route(q, store.enabledDocs()).picks.map { it.skill.name }

    @Test fun automaticDetectionPicksTheRightSkill() {
        importPack()
        val cases = mapOf(
            "Make me a Word document resume" to "docx", "excel sheet banao monthly budget with formulas" to "xlsx", "create a pitch deck presentation about our startup" to "pptx",
            "mujhe ek presentation banani hai" to "pptx", "merge these two pdf files and extract tables" to "pdf", "make a poster for my cafe" to "canvas-design",
            "animated gif for slack of a cat" to "slack-gif-creator", "build an MCP server for github" to "mcp-builder", "generative art with flow fields" to "algorithmic-art",
            "test my web app with playwright and take screenshots" to "webapp-testing", "write a status report and newsletter for the team" to "internal-comms",
            "fix typos in attached .docx" to "docx", "ایکسل شیٹ" to "xlsx", "how do I use claude api with tool use" to "claude-api", "write a technical spec proposal doc" to "doc-coauthoring"
        )
        for ((q, want) in cases) assertEquals("for '$q'", want, routeNames(q).firstOrNull())
    }

    @Test fun smallTalkAndPhoneTasksActivateNothing() {
        importPack()
        for (q in listOf("hello how are you", "kya haal hai", "weather in Lahore today", "what is 2+2", "send sms to ali", "translate this to urdu", "call mom"))
            assertTrue("'$q' must not activate a skill: " + routeNames(q), routeNames(q).isEmpty())
    }

    @Test fun multipleSkillsCooperateOnOneTask() {
        importPack()
        val web = routeNames("Build a professional e-commerce website with authentication, database, responsive design and payment integration")
        assertTrue(web.toString(), "frontend-design" in web && web.size >= 2)
        val deck = routeNames("apply a dark theme to my slides")
        assertTrue(deck.toString(), "theme-factory" in deck && "pptx" in deck)
        assertTrue(routeNames("make a react dashboard with tailwind").containsAll(listOf("web-artifacts-builder", "frontend-design")))
    }

    @Test fun userNamingASkillAlwaysSelectsIt() {
        importPack()
        assertEquals("skill-creator", routeNames("use the skill-creator skill to make a new skill").first())
    }

    @Test fun disabledSkillsNeverActivate() {
        importPack()
        assertEquals("docx", routeNames("make a word document").first())
        store.setEnabled("docx", false)
        assertFalse("docx" in routeNames("make a word document"))
        assertTrue(store.readResource("docx", "SKILL.md", 0, 1000).contains("disabled"))
        assertTrue(store.scriptGate("docx", "scripts/accept_changes.py").second!!.contains("disabled"))
        store.setEnabled("docx", true)
        assertEquals("docx", routeNames("make a word document").first())
    }

    @Test fun importedSkillsAreRoutedWithoutAnyKeywordList() {
        store.importZip(zipOf("pet/SKILL.md" to skillMd("pet-care-plans", "Create vaccination schedules and feeding plans for dogs and cats. Use when the user asks about puppy, kitten or veterinary reminders.")).inputStream(), "zip", false, tmp)
        assertEquals(listOf("pet-care-plans"), routeNames("make a vaccination schedule for my puppy"))
    }

    // ── 5. instructions given to the model ──────────────────────
    @Test fun composedBlockHasFullInstructionsResourcesAndPrecedenceRules() {
        importPack()
        val picks = SkillCore.route("create a word document report", store.enabledDocs()).picks
        val (block, loaded) = store.composeFor(picks)
        val docx = loaded.first { it.name == "docx" }
        assertTrue(block.contains(docx.text.trim().take(300)) && block.contains(docx.text.trim().takeLast(200)))   // complete SKILL.md, nothing cut
        assertTrue(block.contains("ACTIVE SKILLS FOR THIS REQUEST") && block.contains("precedence") && block.contains("ENVIRONMENT MAPPING"))
        assertTrue(block.contains("scripts/"))            // resource list
        assertFalse(block.contains("name: docx"))         // frontmatter is not duplicated
    }

    @Test fun hugeSkillIsCutHonestlyAndRestIsReadable() {
        importPack()
        val r = store.get("claude-api")!!
        val (block, _) = store.composeFor(listOf(SkillCore.Pick(SkillCore.SkillDoc(r.id, r.name, ""), 99.0, "test")))
        assertTrue(block.contains("SKILL.md CUT HERE") && block.contains("skill_read name=claude-api path=SKILL.md offset="))
        val off = Regex("offset=(\\d+)").find(block)!!.groupValues[1].toInt()
        val next = store.readResource("claude-api", "SKILL.md", off, 40_000)
        assertTrue(next.contains("characters $off–"))
        val total = store.instructions(r).length
        // whole text is reachable through repeated reads: nothing is lost
        var pos = off; var guard = 0
        while (pos < total && guard++ < 20) { val t = store.readResource("claude-api", "SKILL.md", pos, 40_000); assertTrue(t.startsWith("SKILL FILE")); pos += 40_000 }
        assertTrue(pos >= total)
    }

    @Test fun twoSkillsStayWithinTotalBudget() {
        importPack()
        val picks = listOf("claude-api", "skill-creator", "pptx").map { n -> store.get(n)!!.let { SkillCore.Pick(SkillCore.SkillDoc(it.id, it.name, ""), 50.0, "t") } }
        val (block, _) = store.composeFor(picks)
        assertTrue(block.length < SkillCore.TOTAL_CHARS + 6000)
    }

    // ── 6. references / resources ───────────────────────────────
    @Test fun referencesCanBeReadAndMissingOnesGiveUsefulErrors() {
        importPack()
        val ok = store.readResource("docx", "scripts/office/soffice.py", 0, 2000)
        assertTrue(ok.startsWith("SKILL FILE docx/scripts/office/soffice.py"))
        val missing = store.readResource("pdf", "FORMS", 0, 1000)
        assertTrue(missing, missing.contains("does not exist") && missing.contains("forms.md"))
        assertTrue(store.readResource("pdf", "FORMS.md", 0, 500).startsWith("SKILL FILE pdf/forms.md"))   // case-insensitive when unambiguous
        assertTrue(store.readResource("pdf", "../docx/SKILL.md", 0, 1000).contains("not allowed"))
        assertTrue(store.readResource("pdf", "/etc/passwd", 0, 1000).contains("not allowed"))
        assertTrue(store.readResource("nope", "SKILL.md", 0, 100).contains("No installed skill"))
        assertTrue(store.readResource("theme-factory", "theme-showcase.pdf", 0, 1000).contains("binary"))
        assertTrue(store.readResource("pdf", "", 0, 500).startsWith("SKILL FILE pdf/SKILL.md"))
        assertTrue(store.listFiles("docx").contains("scripts/accept_changes.py"))
        assertTrue(store.listFiles("pdf", "nothing-here").contains("No files"))
    }

    @Test fun findToolRanksAndListsSkills() {
        importPack()
        assertTrue(store.findText("pdf forms").lines()[1].contains("pdf"))
        assertTrue(store.findText("").contains("ENABLED SKILLS (19)"))
    }

    // ── 7. scripts ──────────────────────────────────────────────
    @Test fun everyScriptIsClassifiedAndTheReportIsConsistent() {
        importPack()
        var total = 0
        val by = HashMap<SkillCore.RunStatus, Int>()
        for (r in store.list()) for (s in store.meta(r.id)!!.scripts) { total++; by[s.status] = (by[s.status] ?: 0) + 1 }
        assertEquals(77, total)   // 72 .py + 2 .sh + 2 .mjs + 1 .js
        assertTrue(by.toString(), (by[SkillCore.RunStatus.RUNNABLE] ?: 0) > 10)
        assertTrue(by.toString(), (by[SkillCore.RunStatus.UNSUPPORTED] ?: 0) > 3)
    }

    @Test fun dangerousAndUnsupportedScriptsAreStopped() {
        val danger = SkillCore.analyzeScript("x.py", "import os\nos.system('rm -rf /')\n")
        assertEquals(SkillCore.RunStatus.BLOCKED, danger.status)
        assertEquals(SkillCore.RunStatus.BLOCKED, SkillCore.analyzeScript("x.py", "import shutil\nshutil.rmtree('/data')").status)
        assertEquals(SkillCore.RunStatus.BLOCKED, SkillCore.analyzeScript("x.py", "open('/home/u/.ssh/id_rsa')").status)
        assertEquals(SkillCore.RunStatus.UNSUPPORTED, SkillCore.analyzeScript("x.py", "import subprocess\nsubprocess.run(['ls'])").status)
        assertEquals(SkillCore.RunStatus.UNSUPPORTED, SkillCore.analyzeScript("x.sh", "echo hi").status)
        assertEquals(SkillCore.RunStatus.UNSUPPORTED, SkillCore.analyzeScript("x.js", "console.log(1)").status)
        assertEquals(SkillCore.RunStatus.RUNNABLE, SkillCore.analyzeScript("x.py", "import json, re\nfrom lxml import etree\nprint(1)").status)
        assertEquals(SkillCore.RunStatus.NEEDS_PACKAGES, SkillCore.analyzeScript("x.py", "import defusedxml\n").status)
        assertEquals(SkillCore.RunStatus.RUNNABLE, SkillCore.analyzeScript("x.py", "import helper\n", setOf("helper")).status)
    }

    @Test fun importedScriptsNeedApprovalAndTamperingIsDetected() {
        val zip = zipOf("s/SKILL.md" to skillMd("tooly", "Tool skill for testing script gates"), "s/scripts/run.py" to "import json\nprint(json.dumps({'a':1}))\n", "s/scripts/bad.py" to "import os\nos.system('id')\n", "s/scripts/x.sh" to "echo 1")
        val rep = store.importZip(zip.inputStream(), "zip", false, tmp)
        assertTrue(rep.warnings.any { it.contains("bad.py") && it.contains("blocked") })
        assertTrue(store.scriptGate("tooly", "scripts/run.py").second!!.contains("not allowed yet"))
        store.setScriptsAllowed("tooly", true)
        assertNull(store.scriptGate("tooly", "scripts/run.py").second)
        assertTrue(store.scriptGate("tooly", "scripts/bad.py").second!!.contains("blocked"))
        assertTrue(store.scriptGate("tooly", "scripts/x.sh").second!!.contains("Cannot run"))
        assertTrue(store.scriptGate("tooly", "scripts/missing.py").second!!.contains("not a script"))
        assertTrue(store.scriptGate("tooly", "../../etc/passwd").second!!.contains("not allowed"))
        File(store.skillDir("tooly"), "scripts/run.py").writeText("print('evil')")
        assertTrue(store.scriptGate("tooly", "scripts/run.py").second!!.contains("no longer match"))
    }

    @Test fun bundledSkillScriptsAreTrustedButStillGated() {
        importPack()
        assertTrue(store.get("docx")!!.scriptsAllowed)
        val gate = store.scriptGate("docx", "scripts/accept_changes.py")
        assertTrue(gate.second ?: "ok", gate.second == null || gate.second!!.contains("Cannot run"))
    }

    // ── 8. delete / history ─────────────────────────────────────
    @Test fun deleteRemovesEverythingAndHistoryIsRecorded() {
        importPack()
        assertTrue(store.delete("xlsx"))
        assertNull(store.get("xlsx")); assertFalse(store.skillDir("xlsx").exists()); assertNull(store.meta("xlsx"))
        assertEquals(19, store.list().size)
        store.log("activate", "docx, pdf", "ok", "make a doc"); store.log("run", "docx", "failed", "script x")
        assertEquals(2, store.history().size)
        assertEquals(1, store.usage()["docx"]!!.first)
    }

    // ── 9. verification of results ──────────────────────────────
    private fun fakeDocx(valid: Boolean): ByteArray = zipOf(
        "[Content_Types].xml" to "<?xml version=\"1.0\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Override PartName=\"/word/document.xml\" ContentType=\"x\"/></Types>",
        "_rels/.rels" to "<?xml version=\"1.0\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"/>",
        "word/document.xml" to if (valid) "<w:document xmlns:w=\"urn:w\"><w:body/></w:document>" else "<w:document><w:body></w:document>")

    @Test fun verifierPassesGoodOfficeFilesAndFailsBrokenOnes() {
        assertTrue(SkillCore.verifyBytes("a.docx", fakeDocx(true)).report(), SkillCore.verifyBytes("a.docx", fakeDocx(true)).ok)
        val bad = SkillCore.verifyBytes("a.docx", fakeDocx(false)); assertFalse(bad.ok); assertTrue(bad.report().contains("well-formed"))
        assertFalse(SkillCore.verifyBytes("a.docx", "not a zip".toByteArray()).ok)
        assertFalse(SkillCore.verifyBytes("a.xlsx", fakeDocx(true)).ok)          // docx content is not an xlsx
        assertFalse(SkillCore.verifyBytes("a.pdf", ByteArray(0)).ok)
        assertTrue(SkillCore.verifyBytes("a.pdf", "%PDF-1.4\n1 0 obj << /Type /Page >> endobj\n%%EOF".toByteArray()).ok)
        assertFalse(SkillCore.verifyBytes("a.pdf", "%PDF-1.4 truncated".toByteArray()).ok)
        assertFalse(SkillCore.verifyBytes("a.weird", "x".toByteArray()).ok)        // unknown type is never reported as passed
    }
}
