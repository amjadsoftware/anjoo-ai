"""Anjoo <-> PPT Master driver.

Runs the UNMODIFIED ppt-master scripts in-process (no subprocess, no shell) inside the Pyodide sandbox.
Layout inside the sandbox (all under /proj, or $ANJOO_PROJ when testing on a desktop):
    job.json                     what to run (written by PptRun.kt)
    skill/ppt-master/...         the installed skill (scripts, LICENSE, SKILL.md ... exactly as shipped)
    ws/...                       the deck project (Code Studio project files)
    _out/ws_changes.zip          every new or changed file of ws/ (the PPTX is in exports/)
    _out/result.json             per-step exit codes and timings
"""
import contextlib
import hashlib
import io
import json
import os
import re
import runpy
import sys
import time
import traceback
import zipfile

ROOT = os.environ.get("ANJOO_PROJ", "/proj")
WS = os.path.join(ROOT, "ws")  # becomes ws/<deck-name> once job.json is read
OUT = os.path.join(ROOT, "_out")


def _sha(path):
    h = hashlib.sha1()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _snapshot():
    snap = {}
    for dp, dn, fn in os.walk(WS):
        dn[:] = [d for d in dn if d not in ("__pycache__", "backup")]
        for n in fn:
            p = os.path.join(dp, n)
            snap[os.path.relpath(p, WS).replace(os.sep, "/")] = _sha(p)
    return snap


def _run_step(skill_scripts, script, args, name):
    path = os.path.join(skill_scripts, script)
    if not os.path.isfile(path):
        return 127, "script not found in the skill: %s" % script
    buf = io.StringIO()
    code = 0
    old_argv, old_cwd = sys.argv, os.getcwd()
    sys.argv = [path] + [str(a).replace("{P}", name) for a in args]
    os.chdir(os.path.dirname(WS))   # cwd = ws/, the deck project is ws/<name> (referred to as {P})
    try:
        with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
            runpy.run_path(path, run_name="__main__")
    except SystemExit as e:
        if isinstance(e.code, int):
            code = e.code
        elif e.code is None:
            code = 0
        else:
            code = 1
            buf.write(str(e.code) + "\n")
    except BaseException:
        code = 1
        buf.write(traceback.format_exc())
    finally:
        sys.argv = old_argv
        os.chdir(old_cwd)
    return code, buf.getvalue()


def _summary(script, text, code):
    lines = [l.rstrip() for l in text.splitlines() if l.strip()]
    if "svg_quality_checker" in script:
        keep, cur = [], ""
        for l in lines:
            if l.startswith("[ERROR]") or l.startswith("[WARN]") and " - " in l and l.split(" - ")[0].endswith(".svg"):
                cur = l
            if "[ERROR]" in l:
                if cur and cur not in keep and cur != l:
                    keep.append(cur)
                keep.append(l.strip())
        errs = [l for l in keep if "[ERROR]" in l]
        if code != 0:
            out = keep[:40] if keep else lines[-25:]
            return "\n".join(x[:400] for x in out)
        warn = sum(1 for l in lines if l.strip().startswith("[WARN]") and ".svg" not in l.split(" - ")[0])
        return "passed (%d advisory warnings)" % warn
    return "\n".join(x[:300] for x in lines[-18:])


def _gallery(ws_files_changed):
    svg_dir = os.path.join(WS, "svg_output")
    if not os.path.isdir(svg_dir):
        return
    pages = sorted(f for f in os.listdir(svg_dir) if f.lower().endswith(".svg"))
    if not pages:
        return
    parts = []
    for f in pages:
        try:
            s = open(os.path.join(svg_dir, f), encoding="utf-8").read()
        except Exception:
            continue
        s = re.sub(r"^\s*<\?xml[^>]*\?>", "", s)
        parts.append('<div class="s">%s</div>' % s)
    html = ('<!doctype html><html><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            "<title>Slides preview</title><style>body{margin:0;padding:8px;background:#1e1e1e}"
            ".s{margin:0 0 10px;background:#fff;box-shadow:0 1px 4px #0006}"
            ".s svg{display:block;width:100%;height:auto}</style></head><body>"
            + "".join(parts) + "</body></html>")
    with open(os.path.join(WS, "index.html"), "w", encoding="utf-8") as f:
        f.write(html)


def main():
    global WS
    os.makedirs(OUT, exist_ok=True)
    job = json.load(open(os.path.join(ROOT, "job.json"), encoding="utf-8"))
    WS = os.path.join(ROOT, "ws", re.sub(r"[^A-Za-z0-9_-]", "_", job.get("name") or "deck"))
    os.makedirs(WS, exist_ok=True)
    rt = os.path.join(ROOT, "skill_runtime.zip")   # the skill's runtime files, zipped by the app to keep the bridge payload small
    if os.path.isfile(rt):
        with zipfile.ZipFile(rt) as z:
            z.extractall(ROOT)
    skill = os.path.join(ROOT, job["skill"])
    scripts = os.path.join(skill, "scripts")
    sys.path[:0] = [scripts, skill]
    try:
        import pptx  # noqa: F401  (python-pptx is installed by the app through micropip)
    except Exception as e:
        print("[PYTHON-PPTX MISSING] python-pptx could not be imported: %s" % e)
        print("The app installs it from PyPI on the first run, so the phone needs internet. Nothing was exported.")
        json.dump({"steps": [], "fatal": "python-pptx missing"}, open(os.path.join(OUT, "result.json"), "w"))
        return
    before = _snapshot()
    results = []
    stop = False
    for st in job["steps"]:
        if stop:
            break
        t0 = time.time()
        code, text = _run_step(scripts, st["script"], st.get("args", []), os.path.basename(WS))
        secs = round(time.time() - t0, 1)
        results.append({"script": st["script"], "exit": code, "secs": secs})
        print("=== %s (exit %s, %ss) ===" % (st["script"], code, secs))
        print(_summary(st["script"], text, code))
        if code != 0 and st.get("stop_on_fail", True):
            stop = True
    after = _snapshot()
    changed = [p for p, h in after.items() if before.get(p) != h]
    if any(p.startswith("exports/") and p.endswith(".pptx") for p in changed):
        _gallery(changed)
        after = _snapshot()
        changed = [p for p, h in after.items() if before.get(p) != h]
    with zipfile.ZipFile(os.path.join(OUT, "ws_changes.zip"), "w", zipfile.ZIP_DEFLATED) as z:
        for p in changed:
            z.write(os.path.join(WS, p), p)
    json.dump({"steps": results, "changed": changed}, open(os.path.join(OUT, "result.json"), "w"))
    print("changed files: %d" % len(changed))


main()
