package com.anjoo.assistant

import java.io.File
import java.io.InputStream
import java.util.Locale

/**
 * On-disk registry of installed skills (pure JVM: java.io only, so it is unit-tested with the real skills pack).
 *
 * Layout under [root]:
 *   <id>/…                 the skill exactly as shipped (never modified)
 *   _registry.tsv          one line per skill (state: enabled, scripts allowed, version, hash …)
 *   _meta/<id>.tsv         description + every file (size, sha-256, kind) + script compatibility
 *   _history.tsv           execution history
 */
class SkillStore(val root: File) {

    data class Rec(
        val id: String, val name: String, val version: String, val hash: String, val enabled: Boolean, val scriptsAllowed: Boolean,
        val source: String, val builtin: Boolean, val installedAt: Long, val updatedAt: Long, val fileCount: Int, val note: String,
        val prevVersion: String = ""
    )
    data class FileRec(val path: String, val size: Long, val sha: String, val kind: SkillCore.Kind)
    data class Meta(val description: String, val license: String, val files: List<FileRec>, val scripts: List<SkillCore.ScriptInfo>)

    class ImportReport(
        val imported: List<String>, val updated: List<String>, val unchanged: List<String>,
        val rejected: List<Pair<String, String>>, val warnings: List<String>, val problems: List<String>, val skippedEntries: List<String>,
        val scripts: Map<SkillCore.RunStatus, Int>, val totalFiles: Int, val extras: List<String> = emptyList()
    ) {
        val changed: Boolean get() = imported.isNotEmpty() || updated.isNotEmpty()
        fun text(): String {
            val sb = StringBuilder()
            sb.append("Files read from ZIP: ").append(totalFiles).append('\n')
            if (imported.isNotEmpty()) sb.append("New skills (").append(imported.size).append("): ").append(imported.joinToString(", ")).append('\n')
            if (updated.isNotEmpty()) sb.append("Updated (").append(updated.size).append("): ").append(updated.joinToString(", ")).append('\n')
            if (unchanged.isNotEmpty()) sb.append("Already installed, identical (").append(unchanged.size).append("): ").append(unchanged.joinToString(", ")).append('\n')
            if (rejected.isNotEmpty()) { sb.append("Not imported (").append(rejected.size).append("):\n"); for ((n, why) in rejected) sb.append("  • ").append(n).append(" — ").append(why).append('\n') }
            if (problems.isNotEmpty()) { sb.append("ZIP problems:\n"); for (p in problems.take(20)) sb.append("  • ").append(p).append('\n') }
            if (extras.isNotEmpty()) sb.append("Pack files that are not part of any skill (kept under _pack, not activated): ").append(extras.size).append(" (").append(extras.take(6).joinToString(", ")).append(if (extras.size > 6) ", …" else "").append(")\n")
            if (skippedEntries.isNotEmpty()) sb.append("Skipped ZIP entries: ").append(skippedEntries.size).append(" (").append(skippedEntries.take(5).joinToString("; ")).append(")\n")
            if (warnings.isNotEmpty()) { sb.append("Notes:\n"); for (w in warnings.take(30)) sb.append("  • ").append(w).append('\n') }
            if (scripts.isNotEmpty()) sb.append("Scripts: ").append(scripts.entries.joinToString("; ") { "${it.value} ${it.key.label}" }).append('\n')
            return sb.toString().trimEnd()
        }
    }

    private val registryFile get() = File(root, "_registry.tsv")
    private val metaDir get() = File(root, "_meta")
    private val historyFile get() = File(root, "_history.tsv")
    private val textCache = object : LinkedHashMap<String, String>(8, 0.75f, true) { override fun removeEldestEntry(e: MutableMap.MutableEntry<String, String>?) = size > 12 }

    // ───────────── tsv helpers ─────────────
    private fun esc(s: String) = s.replace("\\", "\\\\").replace("\t", "\\t").replace("\n", "\\n").replace("\r", "")
    private fun unesc(s: String): String {
        val sb = StringBuilder(); var i = 0
        while (i < s.length) { val c = s[i]; if (c == '\\' && i + 1 < s.length) { when (s[i + 1]) { 't' -> sb.append('\t'); 'n' -> sb.append('\n'); '\\' -> sb.append('\\'); else -> sb.append(s[i + 1]) }; i += 2 } else { sb.append(c); i++ } }
        return sb.toString()
    }
    private fun writeAtomic(f: File, text: String) {
        f.parentFile?.mkdirs()
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text, Charsets.UTF_8)
        if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) { f.writeText(text, Charsets.UTF_8); tmp.delete() } }
    }

    // ───────────── registry ─────────────
    @Synchronized fun list(): List<Rec> {
        if (!registryFile.isFile) return emptyList()
        return registryFile.readLines(Charsets.UTF_8).mapNotNull { line ->
            val p = line.split('\t')
            if (p.size < 13) return@mapNotNull null
            try { Rec(p[0], unesc(p[1]), unesc(p[2]), p[3], p[4] == "1", p[5] == "1", unesc(p[6]), p[7] == "1", p[8].toLong(), p[9].toLong(), p[10].toInt(), unesc(p[11]), unesc(p[12])) } catch (_: Exception) { null }
        }.sortedBy { it.name }
    }
    @Synchronized private fun saveAll(list: List<Rec>) {
        writeAtomic(registryFile, list.joinToString("\n") { r ->
            listOf(r.id, esc(r.name), esc(r.version), r.hash, if (r.enabled) "1" else "0", if (r.scriptsAllowed) "1" else "0", esc(r.source), if (r.builtin) "1" else "0", r.installedAt, r.updatedAt, r.fileCount, esc(r.note), esc(r.prevVersion)).joinToString("\t")
        } + "\n")
    }
    fun get(id: String): Rec? = list().firstOrNull { it.id == id }
    fun find(idOrName: String): Rec? { val k = idOrName.trim().lowercase(Locale.ROOT); return list().firstOrNull { it.id == k || it.name.lowercase(Locale.ROOT) == k || it.id == SkillCore.sanitizeId(k) } }
    fun skillDir(id: String) = File(root, id)

    @Synchronized private fun update(id: String, f: (Rec) -> Rec): Boolean {
        val all = list().toMutableList(); val i = all.indexOfFirst { it.id == id }
        if (i < 0) return false
        all[i] = f(all[i]); saveAll(all); return true
    }
    fun setEnabled(id: String, on: Boolean) = update(id) { it.copy(enabled = on) }
    fun setScriptsAllowed(id: String, on: Boolean) = update(id) { it.copy(scriptsAllowed = on) }

    @Synchronized fun delete(id: String): Boolean {
        val all = list().toMutableList()
        if (all.none { it.id == id }) return false
        all.removeAll { it.id == id }; saveAll(all)
        skillDir(id).deleteRecursively(); File(metaDir, "$id.tsv").delete()
        textCache.keys.removeAll { it.startsWith("$id:") }
        return true
    }

    // ───────────── meta ─────────────
    @Synchronized fun meta(id: String): Meta? {
        val f = File(metaDir, "$id.tsv"); if (!f.isFile) return null
        var desc = ""; var lic = ""
        val files = ArrayList<FileRec>(); val scripts = ArrayList<SkillCore.ScriptInfo>()
        for (line in f.readLines(Charsets.UTF_8)) {
            val p = line.split('\t')
            try {
                when (p[0]) {
                    "D" -> desc = unesc(p[1]); "L" -> lic = unesc(p[1])
                    "F" -> files.add(FileRec(unesc(p[1]), p[2].toLong(), p[3], SkillCore.Kind.valueOf(p[4])))
                    "S" -> scripts.add(SkillCore.ScriptInfo(unesc(p[1]), p[2], SkillCore.RunStatus.valueOf(p[3]), unesc(p[4]), p[5].split(',').filter { it.isNotEmpty() }.toSet()))
                }
            } catch (_: Exception) {}
        }
        return Meta(desc, lic, files, scripts)
    }
    fun enabledDocs(): List<SkillCore.SkillDoc> = list().filter { it.enabled }.mapNotNull { r -> meta(r.id)?.let { SkillCore.SkillDoc(r.id, r.name, it.description) } }

    // ───────────── import / update ─────────────
    /** Imports every skill found in a ZIP. Identical skills are left alone, changed ones are updated (version tracked), bad ones are reported. */
    @Synchronized fun importZip(input: InputStream, source: String, builtin: Boolean, tmpParent: File, now: Long = System.currentTimeMillis(), disabledByDefault: Set<String> = setOf("template-skill")): ImportReport {
        val tmp = File(tmpParent, "skills-import-" + now + "-" + (Math.random() * 1e6).toInt())
        tmp.deleteRecursively(); tmp.mkdirs()
        try {
            val ex = SkillCore.extractZip(input, tmp)
            val found = SkillCore.discover(tmp, ex.files)
            val imported = ArrayList<String>(); val updated = ArrayList<String>(); val unchanged = ArrayList<String>()
            val rejected = ArrayList<Pair<String, String>>(); val warnings = ArrayList<String>()
            val scriptCount = java.util.EnumMap<SkillCore.RunStatus, Int>(SkillCore.RunStatus::class.java)
            val seenIds = HashSet<String>()
            if (found.isEmpty()) rejected.add("(ZIP)" to "No SKILL.md found. A skill is a folder with a SKILL.md that starts with name/description frontmatter.")
            root.mkdirs()
            for (f in found) {
                val label = f.dirRel.ifEmpty { "(zip root)" }
                if (!f.md.ok) { rejected.add(label to f.md.error); continue }
                val id = SkillCore.sanitizeId(f.md.name)
                if (!seenIds.add(id)) { rejected.add(label to "Duplicate name '${f.md.name}' inside the same ZIP."); continue }
                val base = if (f.dirRel.isEmpty()) tmp else File(tmp, f.dirRel)
                val hashes = LinkedHashMap<String, String>(); val sizes = HashMap<String, Long>()
                for (rel in f.fileRels) { val bf = File(base, rel); hashes[rel] = SkillCore.sha256(bf.readBytes()); sizes[rel] = bf.length() }
                val tree = SkillCore.treeHash(hashes)
                val existing = get(id)
                val dupOf = list().firstOrNull { it.hash == tree && it.id != id }
                if (dupOf != null) { rejected.add(label to "Duplicate of installed skill '${dupOf.name}' (identical files)."); continue }
                if (existing != null && existing.hash == tree) { unchanged.add(f.md.name); continue }
                // stage then swap, so a failed copy never leaves a half-installed skill
                val stage = File(root, ".stage-$id"); stage.deleteRecursively()
                if (!base.copyRecursively(stage, overwrite = true)) { rejected.add(label to "Could not copy files."); stage.deleteRecursively(); continue }
                val dest = skillDir(id); dest.deleteRecursively()
                if (!stage.renameTo(dest)) { stage.copyRecursively(dest, overwrite = true); stage.deleteRecursively() }
                // scripts
                val py = f.fileRels.filter { it.endsWith(".py") }
                val siblings = HashSet<String>()
                for (r in py) { siblings.add(r.substringAfterLast('/').removeSuffix(".py")); r.split('/').dropLast(1).forEach { siblings.add(it) } }
                val scripts = ArrayList<SkillCore.ScriptInfo>()
                for (rel in f.fileRels) if (SkillCore.kindOf(rel) == SkillCore.Kind.SCRIPT) {
                    val text = try { File(base, rel).readText(Charsets.UTF_8) } catch (_: Exception) { "" }
                    val info = SkillCore.analyzeScript(rel, text, siblings)
                    scripts.add(info); scriptCount[info.status] = (scriptCount[info.status] ?: 0) + 1
                }
                val files = f.fileRels.map { FileRecOf(it, sizes[it] ?: 0, hashes[it].orEmpty()) }
                writeMeta(id, f.md.description, f.md.license, files, scripts)
                val version = f.md.version.ifEmpty { "h" + tree.take(8) }
                val disabled = f.md.name in disabledByDefault
                val note = if (disabled) "Placeholder template; disabled by default." else ""
                val all = list().toMutableList()
                val old = all.firstOrNull { it.id == id }
                all.removeAll { it.id == id }
                all.add(Rec(id, f.md.name, version, tree, if (old != null) old.enabled else !disabled, if (old != null) old.scriptsAllowed else builtin, source, builtin, old?.installedAt ?: now, now, files.size, note, old?.version.orEmpty()))
                saveAll(all)
                textCache.keys.removeAll { it.startsWith("$id:") }
                if (old != null) updated.add(f.md.name + " (" + old.version + " → " + version + ")") else imported.add(f.md.name)
                for (w in f.problems) warnings.add(f.md.name + ": " + w)
                if (disabled) warnings.add(f.md.name + ": " + note)
                val bad = scripts.filter { it.status == SkillCore.RunStatus.BLOCKED }
                for (b in bad) warnings.add(f.md.name + ": script " + b.path + " blocked — " + b.reason)
            }
            // Files that belong to no skill (README, licences, spec, plugin manifest) are kept, never dropped silently.
            val owned = found.map { it.dirRel }
            val extras = ex.files.filter { f -> owned.none { d -> d.isEmpty() || f.startsWith("$d/") } }
            if (extras.isNotEmpty()) {
                val packDir = File(root, "_pack/" + SkillCore.sanitizeId(source))
                packDir.deleteRecursively()
                for (rel in extras) { val to = SkillCore.safeResolve(packDir, rel) ?: continue; to.parentFile?.mkdirs(); File(tmp, rel).copyTo(to, overwrite = true) }
            }
            return ImportReport(imported, updated, unchanged, rejected, warnings, ex.problems, ex.skipped, scriptCount, ex.files.size, extras)
        } finally { tmp.deleteRecursively() }
    }

    private fun FileRecOf(path: String, size: Long, sha: String) = FileRec(path, size, sha, SkillCore.kindOf(path))

    private fun writeMeta(id: String, desc: String, license: String, files: List<FileRec>, scripts: List<SkillCore.ScriptInfo>) {
        val sb = StringBuilder()
        sb.append("D\t").append(esc(desc)).append('\n').append("L\t").append(esc(license)).append('\n')
        for (f in files) sb.append("F\t").append(esc(f.path)).append('\t').append(f.size).append('\t').append(f.sha).append('\t').append(f.kind.name).append('\n')
        for (s in scripts) sb.append("S\t").append(esc(s.path)).append('\t').append(s.lang).append('\t').append(s.status.name).append('\t').append(esc(s.reason)).append('\t').append(s.imports.joinToString(",")).append('\n')
        writeAtomic(File(metaDir, "$id.tsv"), sb.toString())
    }

    // ───────────── integrity ─────────────
    /** Compares the files on disk with the hashes recorded at import. Empty list = untouched. */
    fun integrityProblems(id: String, onlyScripts: Boolean = false): List<String> {
        val m = meta(id) ?: return listOf("no manifest for '$id'")
        val dir = skillDir(id)
        val out = ArrayList<String>()
        for (f in m.files) {
            if (onlyScripts && f.kind != SkillCore.Kind.SCRIPT) continue
            val file = File(dir, f.path)
            if (!file.isFile) { out.add("missing: ${f.path}"); continue }
            if (SkillCore.sha256(file.readBytes()) != f.sha) out.add("changed: ${f.path}")
        }
        return out
    }

    // ───────────── reading for the model ─────────────
    fun instructions(r: Rec): String {
        val key = r.id + ":" + r.hash
        synchronized(textCache) { textCache[key]?.let { return it } }
        val raw = try { File(skillDir(r.id), "SKILL.md").readText(Charsets.UTF_8) } catch (_: Exception) { return "" }
        val meta = SkillCore.parseFrontmatter(raw)
        val text = if (meta.ok) meta.body else raw
        synchronized(textCache) { textCache[key] = text }
        return text
    }

    /** Resource list shown to the model: references and templates first, then scripts, then assets (SKILL.md and LICENSE left out). */
    fun resourceList(id: String): List<String> {
        val m = meta(id) ?: return emptyList()
        val order = mapOf(SkillCore.Kind.REFERENCE to 0, SkillCore.Kind.TEMPLATE to 1, SkillCore.Kind.SCRIPT to 2, SkillCore.Kind.ASSET to 3, SkillCore.Kind.INSTRUCTIONS to 9)
        return m.files.filter { it.kind != SkillCore.Kind.INSTRUCTIONS && !it.path.endsWith("LICENSE.txt") }.sortedWith(compareBy({ order[it.kind] ?: 5 }, { it.path })).map { it.path }
    }

    fun runnableScripts(id: String): List<String> = meta(id)?.scripts?.filter { it.status == SkillCore.RunStatus.RUNNABLE || it.status == SkillCore.RunStatus.NEEDS_PACKAGES }?.map { it.path }.orEmpty()

    fun load(picks: List<SkillCore.Pick>): List<SkillCore.Loaded> = picks.mapNotNull { p ->
        val r = get(p.skill.id) ?: return@mapNotNull null
        val t = instructions(r); if (t.isEmpty()) return@mapNotNull null
        // a bundled skill may ship ANJOO_PHONE.md: how its desktop instructions map onto this phone's tools (read together with SKILL.md)
        val notes = try { File(skillDir(r.id), "ANJOO_PHONE.md").let { if (it.isFile && it.length() < 20_000) it.readText(Charsets.UTF_8).trim() else "" } } catch (_: Exception) { "" }
        SkillCore.Loaded(r.id, r.name, p.skill.description, if (notes.isEmpty()) t else t + "\n\n" + notes, resourceList(r.id), p.why)
    }

    fun composeFor(picks: List<SkillCore.Pick>): Pair<String, List<SkillCore.Loaded>> {
        val loaded = load(picks)
        return SkillCore.compose(loaded, loaded.associate { it.id to runnableScripts(it.id) }) to loaded
    }

    private fun enabledOrError(idOrName: String): Pair<Rec?, String?> {
        val r = find(idOrName) ?: return null to "No installed skill named '$idOrName'. Installed: " + list().joinToString(", ") { it.name } + ". Use skill_find to search."
        if (!r.enabled) return null to "Skill '${r.name}' is disabled by the user (Tools Hub > Skills). Do not use it; tell the user it is switched off if it was needed."
        return r to null
    }

    fun readResource(idOrName: String, relIn: String, offset: Int, limit: Int): String {
        val (r, err) = enabledOrError(idOrName); if (r == null) return err!!
        val rel = relIn.trim().ifEmpty { "SKILL.md" }
        val dir = skillDir(r.id)
        var f = SkillCore.safeResolve(dir, rel) ?: return "Path '$relIn' is not allowed: skill files can only be read with a relative path inside the skill folder (no .., no absolute paths)."
        if (!f.exists()) {
            // SKILL.md files often write FORMS.md while the file is forms.md; Android is case-sensitive, so match ignoring case when it is unambiguous.
            val ci = meta(r.id)?.files.orEmpty().map { it.path }.filter { it.equals(rel.replace('\\', '/').trim('/'), ignoreCase = true) }
            if (ci.size == 1) f = File(dir, ci[0])
        }
        val relShown = f.relativeTo(dir).path.replace('\\', '/')
        if (!f.exists()) {
            val base = rel.substringAfterLast('/').lowercase(Locale.ROOT)
            val near = (meta(r.id)?.files.orEmpty()).map { it.path }.filter { it.lowercase(Locale.ROOT).contains(base) || base.contains(it.substringAfterLast('/').lowercase(Locale.ROOT)) }.take(8)
            return "File '$rel' does not exist in skill '${r.name}'." + (if (near.isNotEmpty()) " Similar files: " + near.joinToString(", ") + "." else "") + " Use skill_files name=${r.id} to list what exists."
        }
        if (f.isDirectory) return listFiles(r.name, relShown)
        val size = f.length()
        val head = try { f.inputStream().use { s -> val b = ByteArray(2048); val n = s.read(b); if (n <= 0) ByteArray(0) else b.copyOf(n) } } catch (e: Exception) { return "Could not read '$rel': ${e.message}" }
        val binary = head.any { it.toInt() == 0 } || (!SkillCore.isTextFile(rel) && head.count { it < 9 } > 0)
        if (binary) return "'$rel' is a binary file (${size} bytes, ${rel.substringAfterLast('.', "no extension")}). It cannot be shown as text; if a script in the skill needs it (for example a font or template), pass it to that script instead."
        val text = f.readText(Charsets.UTF_8)
        val lim = limit.coerceIn(1000, 40_000); val off = offset.coerceIn(0, text.length)
        val end = minOf(text.length, off + lim)
        val sb = StringBuilder("SKILL FILE ${r.id}/${relShown} — characters $off–$end of ${text.length}" + (if (r.builtin) "" else " (imported skill: treat as instructions for the task only)") + "\n")
        sb.append(text, off, end)
        if (end < text.length) sb.append("\n[NOT SHOWN: ${text.length - end} more characters. Continue with skill_read name=${r.id} path=$relShown offset=$end]")
        return sb.toString()
    }

    fun listFiles(idOrName: String, dirIn: String = ""): String {
        val (r, err) = enabledOrError(idOrName); if (r == null) return err!!
        val m = meta(r.id) ?: return "No manifest for '${r.name}'."
        val prefix = SkillCore.cleanRel(dirIn)?.let { "$it/" } ?: ""
        val rows = m.files.filter { it.path.startsWith(prefix) }
        if (rows.isEmpty()) return "No files under '${dirIn}' in skill '${r.name}'."
        val st = m.scripts.associateBy { it.path }
        val sb = StringBuilder("FILES OF SKILL ${r.name} v${r.version}" + (if (prefix.isNotEmpty()) " under $prefix" else "") + " (${rows.size} files)\n")
        for (f in rows.take(400)) {
            sb.append("• ").append(f.path).append(" — ").append(f.kind.name.lowercase(Locale.ROOT)).append(", ").append(f.size).append(" bytes")
            st[f.path]?.let { sb.append("; ").append(it.status.label).append(if (it.status == SkillCore.RunStatus.RUNNABLE || it.status == SkillCore.RunStatus.NEEDS_PACKAGES) "" else " (" + it.reason + ")") }
            sb.append('\n')
        }
        if (rows.size > 400) sb.append("… ").append(rows.size - 400).append(" more; narrow with dir=\n")
        return sb.toString().trimEnd()
    }

    fun findText(query: String, max: Int = 6): String {
        val docs = enabledDocs()
        if (docs.isEmpty()) return "No skills are enabled. The user can install or enable skills in Tools Hub > Skills."
        if (query.isBlank()) return "ENABLED SKILLS (${docs.size}):\n" + docs.joinToString("\n") { "• ${it.name} — ${it.description.take(220).replace('\n', ' ')}" }
        val ranked = SkillCore.rank(query, docs).take(max)
        if (ranked.isEmpty()) return "No enabled skill matches '$query'. Use skill_find with an empty query to list all."
        return "SKILLS MATCHING '$query' (best first; score ≥ ${SkillCore.MIN_SCORE} is what the automatic router treats as relevant):\n" +
            ranked.joinToString("\n") { "• ${it.skill.name} (score ${"%.1f".format(it.score)}; matched: ${it.why}) — ${it.skill.description.take(220).replace('\n', ' ')}" } +
            "\nRead one with skill_read name=<skill>."
    }

    /** Returns null when the script may run, else the reason it may not. */
    fun scriptGate(idOrName: String, relIn: String): Pair<SkillCore.ScriptInfo?, String?> {
        val (r, err) = enabledOrError(idOrName); if (r == null) return null to err
        val rel = SkillCore.cleanRel(relIn) ?: return null to "Script path '$relIn' is not allowed."
        val m = meta(r.id) ?: return null to "No manifest for '${r.name}'."
        val info = m.scripts.firstOrNull { it.path == rel } ?: return null to "'$rel' is not a script of skill '${r.name}'. Scripts: " + (m.scripts.joinToString(", ") { it.path }.ifEmpty { "none" })
        when (info.status) {
            SkillCore.RunStatus.UNSUPPORTED -> return info to "Cannot run '$rel' on this phone: ${info.reason}. Do the same job with the phone tools (run_python, make_document, project_*) and follow the skill's instructions manually; say plainly that the script was not run."
            SkillCore.RunStatus.BLOCKED -> return info to "'$rel' is blocked by the security check (${info.reason}). It will not be run."
            else -> {}
        }
        if (!r.scriptsAllowed) return info to "Scripts of the imported skill '${r.name}' are not allowed yet. The user must open Tools Hub > Skills > ${r.name} and turn on 'Allow scripts' after reviewing it."
        val bad = integrityProblems(r.id, onlyScripts = true)
        if (bad.isNotEmpty()) return info to "The skill's scripts no longer match what was imported (${bad.take(3).joinToString("; ")}). Refusing to run; re-import the skill."
        return info to null
    }

    // ───────────── history ─────────────
    class Hist(val ts: Long, val action: String, val skills: String, val status: String, val detail: String)

    @Synchronized fun log(action: String, skills: String, status: String, detail: String, ts: Long = System.currentTimeMillis()) {
        try {
            root.mkdirs()
            historyFile.appendText("$ts\t${esc(action)}\t${esc(skills)}\t${esc(status)}\t${esc(detail.take(240))}\n", Charsets.UTF_8)
            if (historyFile.length() > 200_000) { val keep = historyFile.readLines(Charsets.UTF_8).takeLast(500); writeAtomic(historyFile, keep.joinToString("\n") + "\n") }
        } catch (_: Exception) {}
    }
    @Synchronized fun history(max: Int = 100): List<Hist> {
        if (!historyFile.isFile) return emptyList()
        return historyFile.readLines(Charsets.UTF_8).takeLast(max).mapNotNull { l -> val p = l.split('\t'); if (p.size < 5) null else try { Hist(p[0].toLong(), unesc(p[1]), unesc(p[2]), unesc(p[3]), unesc(p[4])) } catch (_: Exception) { null } }.reversed()
    }
    /** skill name → number of automatic activations and last time. */
    fun usage(): Map<String, Pair<Int, Long>> {
        val m = HashMap<String, Pair<Int, Long>>()
        for (h in history(500)) if (h.action == "activate") for (n in h.skills.split(',').map { it.trim() }.filter { it.isNotEmpty() }) { val o = m[n]; m[n] = Pair((o?.first ?: 0) + 1, maxOf(o?.second ?: 0L, h.ts)) }
        return m
    }
}
