package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * ppt_run: PPT Master (the "ppt-master" skill, shipped unmodified in ppt_master_pack.zip) on the phone.
 *
 * A deck is a Code Studio project (svg_output/pNN_*.svg pages written with project_write). Building a deck runs the real
 * PPT Master scripts (svg_quality_checker.py, svg_to_pptx.py, pptx_to_svg.py ...) in-process in the Pyodide sandbox
 * (SkillRunner) through assets/anjoo_ppt_driver.py. The sandbox sees only the deck's files and the skill runtime; the changed
 * files (including exports/NAME.pptx) come back as one ZIP and are written into the project, and the PPTX is also saved with FileAccess.
 */
object PptRun {
    private const val SKILL = "ppt-master"
    private const val ICON_ASSET = "ppt_icons.zip"
    private const val ICON_VER = "1"
    private const val WS_LIMIT = 24_000_000L
    private val SKIP_DIRS = listOf("scripts/confirm_ui/", "scripts/svg_editor/", "scripts/tts_backends/", "scripts/image_backends/", "scripts/image_sources/")
    private val RUNTIME_EXT = setOf("py", "json", "xml", "txt", "yml", "yaml", "csv")
    private val IDENTITY = setOf("SKILL.md", "LICENSE", "SPONSORS.md", "SPONSORS_CN.md")
    private val TEXT_EXT = setOf("svg", "md", "txt", "json", "xml", "html", "css", "csv", "yml", "yaml", "log")
    private val REQS = listOf("python-pptx==1.0.2", "XlsxWriter")
    private val ICON_RX = Regex("data-icon\\s*=\\s*[\"']([A-Za-z0-9_-]+/[A-Za-z0-9._-]+)[\"']")

    @Volatile private var iconNames: List<String>? = null

    fun run(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        Skills.ensureBuiltIn(ctx)
        val st = Skills.store(ctx)
        val rec = st.find(SKILL) ?: return "PPT Master is not installed (it ships inside the app as a skills pack). Open Tools Hub > Skills and check 'ppt-master'."
        if (!rec.enabled) return "PPT Master is switched off by the user (Tools Hub > Skills). Do not use ppt_run; tell the user it is off if it was needed."
        val action = a.optString("action", "info").trim().lowercase()
        return try {
            when (action) {
                "info" -> info()
                "new" -> newDeck(ctx, a)
                "icons" -> icons(ctx, a)
                "build", "import", "exec" -> sandbox(ctx, st, rec.id, confirm, action, a)
                else -> "Unknown action '$action'. Use new, build, import, exec, icons or info."
            }
        } catch (e: Exception) {
            "ppt_run failed: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    private fun info(): String =
        "PPT Master (ppt-master skill) on this phone. Actions: new (create a deck project), build (quality gate + export .pptx; mode=edit for an imported deck), " +
        "import (existing .pptx -> editable SVG pages), exec (run another PPT Master script), icons (search the 12,000-icon library). " +
        "Write pages with project_write into svg_output/pNN_name.svg. First run needs internet (Python runtime + python-pptx) and may take a minute. " +
        "Not available here: narration audio, video export, live preview server, AI image generation inside PPT Master (use generate_image)."

    // ───────────── deck projects ─────────────

    private fun slug(s: String): String = s.replace(Regex("[^A-Za-z0-9_-]"), "_").trim('_').take(40).ifEmpty { "deck" }

    private fun findDeck(ctx: Context, name: String): File? {
        val n = name.trim()
        if (n.isEmpty()) return null
        return Coder.list(ctx).firstOrNull { it.name.equals(n, true) || Coder.name(it).equals(n, true) }
    }

    private fun createDeck(ctx: Context, a: JSONObject): File {
        val title = a.optString("title", a.optString("project", "")).trim().ifEmpty { "Presentation" }.replace(Regex("[./\\\\]"), " ").take(40).trim().ifEmpty { "Presentation" }
        val dir = findDeck(ctx, a.optString("project", title)) ?: Coder.fileProject(ctx, "$title.md", "# $title\n\nDeck brief and outline (edit freely). Slides live in svg_output/.\n")
        for (d in listOf("svg_output", "notes", "images", "sources")) File(dir, d).mkdirs()
        return dir
    }

    private fun copyInputs(ctx: Context, dir: File, inputs: JSONArray?, sub: String): Pair<List<String>, String?> {
        val done = ArrayList<String>()
        if (inputs == null) return done to null
        for (i in 0 until minOf(inputs.length(), 8)) {
            val p = inputs.optString(i, "")
            if (p.isBlank()) continue
            val (bytes, e) = FileAccess.bytesOf(ctx, p, 12_000_000)
            if (bytes == null) return done to "Cannot read input file '$p': $e"
            val fname = p.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").ifEmpty { "input$i" }
            val target = SkillCore.safeResolve(dir, "$sub/$fname") ?: return done to "Bad file name '$fname'."
            target.parentFile?.mkdirs()
            target.writeBytes(bytes)
            done.add("$sub/$fname")
        }
        return done to null
    }

    private fun newDeck(ctx: Context, a: JSONObject): String {
        val dir = createDeck(ctx, a)
        val (copied, err) = copyInputs(ctx, dir, a.optJSONArray("inputs"), "images")
        if (err != null) return err
        try { Coder.onChanged?.invoke(dir) } catch (_: Exception) {}
        return "DECK READY: project '" + Coder.name(dir) + "' (canvas 1280x720 / ppt169 unless you decide otherwise). Folders: svg_output/ (slide pages), notes/, images/, sources/." +
            (if (copied.isNotEmpty()) " Copied: " + copied.joinToString(", ") + "." else "") +
            " Next: write each slide with project_write path=svg_output/p01_<name>.svg (one page per call), then ppt_run action=build project=\"" + Coder.name(dir) + "\"."
    }

    // ───────────── icons ─────────────

    private fun iconZip(ctx: Context): File {
        val f = File(ctx.cacheDir, "ppt_icons_$ICON_VER.zip")
        if (!f.exists() || f.length() < 1000) {
            val tmp = File(ctx.cacheDir, "ppt_icons_$ICON_VER.tmp")
            ctx.assets.open(ICON_ASSET).use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
            f.delete()
            if (!tmp.renameTo(f)) throw IllegalStateException("the icon library could not be prepared")
        }
        return f
    }

    private fun iconList(ctx: Context): List<String> {
        iconNames?.let { return it }
        val z = ZipFile(iconZip(ctx))
        val out = ArrayList<String>(12100)
        try {
            val en = z.entries()
            while (en.hasMoreElements()) {
                val n = en.nextElement().name
                if (n.endsWith(".svg")) out.add(n.removeSuffix(".svg"))
            }
        } finally { z.close() }
        out.sort()
        iconNames = out
        return out
    }

    private fun icons(ctx: Context, a: JSONObject): String {
        val q = a.optString("query", "").trim().lowercase()
        val lib = a.optString("library", "").trim().lowercase()
        val limit = a.optInt("limit", 40).coerceIn(5, 100)
        val all = try { iconList(ctx) } catch (e: Exception) { return "The icon library is not available: " + (e.message ?: "") }
        if (q.isEmpty() && lib.isEmpty()) {
            val counts = all.groupBy { it.substringBefore('/') }.map { it.key + " (" + it.value.size + ")" }
            return "Icon libraries: " + counts.joinToString(", ") + ". Search with query=\"chart\" (optional library=tabler-outline). Use one of the four stylistic libraries per deck; simple-icons = brand logos."
        }
        val words = q.split(Regex("[\\s,]+")).filter { it.isNotEmpty() }
        val hits = all.filter { n -> (lib.isEmpty() || n.startsWith("$lib/")) && words.all { n.substringAfter('/').contains(it) } }
        if (hits.isEmpty()) return "No icon matches '$q'. Try a simpler or more general word."
        return hits.size.toString() + " match(es)" + (if (hits.size > limit) ", first $limit" else "") + ":\n" + hits.take(limit).joinToString("\n") +
            "\nUse as <use data-icon=\"LIB/NAME\" x=\"..\" y=\"..\" width=\"40\" height=\"40\" fill=\"#HEX\"/>."
    }

    // ───────────── sandbox runs ─────────────

    private fun collectWs(dir: File, slug: String, text: MutableMap<String, String>, bin: MutableMap<String, ByteArray>): String? {
        var total = 0L
        val base = dir.canonicalFile
        for (f in base.walkTopDown()) {
            if (!f.isFile) continue
            val rel = f.relativeTo(base).invariantSeparatorsPath
            val top = rel.substringBefore('/')
            if (f.name.startsWith(".anjoo") || top == "backup" || top == "exports" || top == "validation") continue
            total += f.length()
            if (total > WS_LIMIT) return "The deck project is too large for the sandbox (over 24 MB of files). Remove big images from images/ or split the deck."
            val ext = rel.substringAfterLast('.', "").lowercase()
            if (ext in TEXT_EXT && f.length() <= 3_000_000L) text["ws/$slug/$rel"] = f.readText(Charsets.UTF_8)
            else bin["ws/$slug/$rel"] = f.readBytes()
        }
        return null
    }

    /** Mounts every icon the pages refer to (data-icon="lib/name") into the project's icons/ pool, like icon_sync.py does on a desktop. */
    private fun mountIcons(ctx: Context, slug: String, text: MutableMap<String, String>): List<String> {
        val wanted = LinkedHashSet<String>()
        for ((k, v) in text) {
            if (!k.endsWith(".svg") || (!k.contains("/svg_output/") && !k.contains("/authoring-svg-flat/"))) continue
            for (m in ICON_RX.findAll(v)) wanted.add(m.groupValues[1])
        }
        if (wanted.isEmpty()) return emptyList()
        val missing = ArrayList<String>()
        val z = try { ZipFile(iconZip(ctx)) } catch (e: Exception) { return wanted.toList() }
        try {
            for (n in wanted.take(150)) {
                val key = "ws/$slug/icons/$n.svg"
                if (text.containsKey(key)) continue
                val ent = z.getEntry("$n.svg")
                if (ent == null) { missing.add(n); continue }
                text[key] = z.getInputStream(ent).use { it.readBytes() }.toString(Charsets.UTF_8)
            }
        } finally { z.close() }
        return missing
    }

    private fun runtimeZip(st: SkillStore, id: String): Pair<ByteArray?, String?> {
        val dir = st.skillDir(id)
        val meta = st.meta(id) ?: return null to "PPT Master's files are missing; reinstall it from Tools Hub > Skills."
        val bos = ByteArrayOutputStream()
        var n = 0
        ZipOutputStream(bos).use { z ->
            z.setLevel(6)
            for (f in meta.files) {
                val p = f.path
                val ext = p.substringAfterLast('.', "").lowercase()
                val isRun = p.startsWith("scripts/") && ext in RUNTIME_EXT && SKIP_DIRS.none { p.startsWith(it) } && !p.contains("/docs/")
                if (!isRun && p !in IDENTITY) continue
                val file = File(dir, p)
                if (!file.isFile) continue
                z.putNextEntry(ZipEntry("skill/$id/$p"))
                z.write(file.readBytes())
                z.closeEntry()
                n++
            }
        }
        if (n < 100) return null to "PPT Master's scripts are incomplete ($n files). Reinstall it from Tools Hub > Skills."
        return bos.toByteArray() to null
    }

    private fun sandbox(ctx: Context, st: SkillStore, id: String, confirm: (String) -> Boolean, action: String, a: JSONObject): String {
        val projectName = a.optString("project", "").trim()
        if (projectName.isEmpty() && action != "import") return "Give project = the deck name (create it first with action=new)."
        val dir: File = if (action == "import") createDeck(ctx, a)
            else findDeck(ctx, projectName) ?: return "No deck project named '$projectName'. Create it with ppt_run action=new project=\"$projectName\" first."
        val slug = slug(Coder.name(dir))
        val steps = ArrayList<Pair<String, List<String>>>()
        var label: String

        when (action) {
            "build" -> {
                val (_, err) = copyInputs(ctx, dir, a.optJSONArray("inputs"), "images")
                if (err != null) return err
                if (a.optString("mode", "new").lowercase() == "edit") {
                    if (!File(dir, "sources/source.pptx").isFile) return "mode=edit needs an imported deck (ppt_run action=import first)."
                    steps.add("svg_to_pptx.py" to listOf("{P}", "--roundtrip"))
                    label = "Export edited deck"
                } else {
                    val pages = File(dir, "svg_output").listFiles { f -> f.isFile && f.name.lowercase().endsWith(".svg") }?.size ?: 0
                    if (pages == 0) return "svg_output/ has no slides yet. Write them with project_write path=svg_output/p01_<name>.svg first."
                    steps.add("svg_quality_checker.py" to listOf("{P}", "--canonical-authoring", "--stage", "final", "--quick-generate", "--json"))
                    steps.add("svg_to_pptx.py" to listOf("{P}", "--quick-generate"))
                    label = "Build $pages slide(s)"
                }
            }
            "import" -> {
                val inputs = a.optJSONArray("inputs")
                val (copied, err) = copyInputs(ctx, dir, inputs, "_in")
                if (err != null) return err
                val src = copied.firstOrNull { it.lowercase().endsWith(".pptx") } ?: return "Give inputs = [path of the .pptx to edit]."
                steps.add("pptx_to_svg.py" to listOf("{P}/$src", "-o", "{P}", "--inheritance-mode", "both", "--roundtrip"))
                label = "Import " + src.substringAfterLast('/')
            }
            else -> {
                val script = a.optString("script", "").trim().replace('\\', '/')
                if (!script.endsWith(".py") || SkillCore.cleanRel(script) == null) return "Give script = a .py file name under PPT Master's scripts/ (for example svg_to_pptx.py)."
                if (SKIP_DIRS.any { ("scripts/" + script).startsWith(it) }) return "That script needs a GUI, a network service or audio tools that do not exist on the phone."
                val aj = a.optJSONArray("args") ?: JSONArray()
                if (aj.length() > 30) return "Too many arguments (max 30)."
                val args = ArrayList<String>()
                for (i in 0 until aj.length()) {
                    val s = aj.optString(i, "")
                    if (s.length > 2000) return "Argument ${i + 1} is too long."
                    if (s.startsWith("/") || s.split('/', '\\').contains("..")) return "Argument '$s' points outside the sandbox. Use relative paths or {P} for the deck folder."
                    args.add(s)
                }
                steps.add(script to args)
                label = "Run $script"
            }
        }

        if (!confirm(Confirm.msg("run", "PPT Master: $label?", "Deck '" + Coder.name(dir) + "'. Runs the PPT Master scripts in an isolated Python sandbox (first run downloads the runtime; needs internet). It cannot touch your phone's other files."))) {
            return "The user declined to run PPT Master."
        }

        val text = LinkedHashMap<String, String>()
        val bin = LinkedHashMap<String, ByteArray>()
        val wsErr = collectWs(dir, slug, text, bin)
        if (wsErr != null) return wsErr
        val missingIcons = mountIcons(ctx, slug, text)
        val (rt, rtErr) = runtimeZip(st, id)
        if (rt == null) return rtErr ?: "PPT Master runtime could not be prepared."
        bin["skill_runtime.zip"] = rt
        val driver = try { ctx.assets.open("anjoo_ppt_driver.py").bufferedReader().use { it.readText() } } catch (e: Exception) { return "The PPT Master driver is missing from the app." }
        text["anjoo_ppt_driver.py"] = driver
        val job = JSONObject().put("name", slug).put("skill", "skill/$id")
        val sj = JSONArray()
        for ((s, args) in steps) sj.put(JSONObject().put("script", s).put("args", JSONArray(args)))
        text["job.json"] = job.put("steps", sj).toString()

        val res = SkillRunner.run(ctx, "anjoo_ppt_driver.py", "skill/$id", emptyList(), text, bin, 120_000, 240_000, REQS, "import lxml\nimport PIL\n", 16_000_000)
        if (!res.loaded) return "The Python sandbox did not start (it needs internet the first time to fetch the runtime). " + res.err.take(300) + "\nNothing was built."
        if (!res.finished) return "PPT Master did not finish within 4 minutes and was stopped. " + res.out.take(1500) + "\nTry fewer slides or fewer/smaller images per build."

        // bring the changed files back into the deck project
        var wrote = 0
        var pptxRel = ""
        var pptxBytes: ByteArray? = null
        val changes = res.outputs["ws_changes.zip"]
        if (changes != null) {
            try {
                ZipInputStream(changes.inputStream()).use { zin ->
                    var e = zin.nextEntry
                    while (e != null) {
                        if (!e.isDirectory) {
                            val rel = SkillCore.cleanRel(e.name)
                            val bytes = zin.readBytes()
                            val target = if (rel != null) SkillCore.safeResolve(dir, rel) else null
                            if (rel != null && target != null && !target.name.startsWith(".anjoo")) {
                                target.parentFile?.mkdirs()
                                target.writeBytes(bytes)
                                wrote++
                                if (rel.startsWith("exports/") && rel.endsWith(".pptx")) { pptxRel = rel; pptxBytes = bytes }
                            }
                        }
                        e = zin.nextEntry
                    }
                }
            } catch (e: Exception) { return "PPT Master ran but its result could not be unpacked: " + (e.message ?: "") }
            try { Coder.onChanged?.invoke(dir) } catch (_: Exception) {}
        }

        val sb = StringBuilder()
        val out = res.out.trim()
        val missingLib = out.contains("[PYTHON-PPTX MISSING]")
        val failedStep = Regex("=== \\S+ \\(exit [1-9]").containsMatchIn(out)
        val ok = !missingLib && !failedStep && res.err.indexOf("Traceback") < 0
        sb.append(if (ok) "PPT MASTER OK: " else "PPT MASTER FAILED: ").append(label).append('\n')
        sb.append(out.take(3800)).append('\n')
        if (!ok && res.err.isNotBlank()) sb.append("stderr:\n").append(res.err.trim().takeLast(1500)).append('\n')
        if (missingIcons.isNotEmpty()) sb.append("Icons not found in the library (fix the names with action=icons): ").append(missingIcons.take(10).joinToString(", ")).append('\n')
        val pb = pptxBytes
        if (pb != null) {
            val fname = pptxRel.substringAfterLast('/')
            val saved = try { FileAccess.write(ctx, "", fname, pb, false) { p -> confirm(Confirm.msg("overwrite", "Overwrite existing file?", p)) } } catch (e: Exception) { "Could not save: " + (e.message ?: "") }
            sb.append("PPTX: ").append(saved).append(" (also in the project as ").append(pptxRel).append(")\n")
            sb.append("Slide preview: open the project's index.html in Code Studio. Next, run skill_verify on the .pptx path before telling the user it is done.\n")
        } else if (ok && action != "exec") {
            sb.append("No .pptx was produced.\n")
        }
        if (!ok && !missingLib) sb.append("Fix the problems above (edit the named pages with project_edit/project_write) and call ppt_run again.\n")
        return sb.toString().trimEnd()
    }
}
