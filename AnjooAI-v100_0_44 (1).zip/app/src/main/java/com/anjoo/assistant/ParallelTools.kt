package com.anjoo.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Callable
import java.util.concurrent.Executors

/**
 * Runs the read-only tool calls of ONE model turn at the same time (for example five web searches or three file reads),
 * so a research or analysis turn takes about as long as the slowest call instead of the sum.
 * Only tools that cannot change anything and do not touch the screen are run in parallel; every other tool still runs
 * one after another in the normal loop.
 */
object ParallelTools {
    val SAFE = setOf(
        "search_web", "fetch_page", "read_file", "find_files", "grep_files", "list_files",
        "read_document", "search_document", "document_info", "weather", "news", "skill_find", "skill_files"
    )
    private const val MAX_AT_ONCE = 5

    class Out(val text: String?, val error: Throwable?)

    private val pool = Executors.newFixedThreadPool(MAX_AT_ONCE) { r -> Thread(r, "anjoo-tool").apply { isDaemon = true } }

    /** Indexes (in [parts]) of the safe calls that may run together; empty when fewer than two. */
    fun pick(parts: JSONArray): List<Int> {
        val idx = ArrayList<Int>()
        for (i in 0 until parts.length()) {
            val fc = parts.optJSONObject(i)?.optJSONObject("functionCall") ?: continue
            if (fc.optString("name") in SAFE) idx.add(i)
        }
        return if (idx.size >= 2) idx.take(MAX_AT_ONCE * 2) else emptyList()
    }

    /** Starts every picked call at once and waits for all of them. Errors are returned, not thrown, so the caller reports them per call. */
    fun prefetch(parts: JSONArray, run: (String, JSONObject) -> String): Map<Int, Out> {
        val idx = pick(parts)
        if (idx.isEmpty()) return emptyMap()
        val jobs = idx.map { i ->
            val fc = parts.getJSONObject(i).getJSONObject("functionCall")
            val name = fc.getString("name"); val args = fc.optJSONObject("args") ?: JSONObject()
            i to pool.submit(Callable { try { Out(run(name, args), null) } catch (t: Throwable) { Out(null, t) } })
        }
        val out = HashMap<Int, Out>()
        for ((i, f) in jobs) out[i] = try { f.get() } catch (t: Throwable) { Out(null, t) }
        return out
    }

    /** The prefetched result of part [i], or [orRun] when that call was not run in parallel. */
    fun take(pre: Map<Int, Out>, i: Int, orRun: () -> String): String {
        val o = pre[i] ?: return orRun()
        o.error?.let { throw it }
        return o.text ?: ""
    }
}
