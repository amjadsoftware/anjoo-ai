package com.anjoo.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Runs ONE skill script in a fresh Pyodide (CPython on WebAssembly) inside a hidden WebView: the same sandbox idea as PyRun,
 * but with what skill scripts need (sys.argv, binary input files, output files). The script only sees a virtual in-memory
 * filesystem (/proj): the skill's own text files, the input files the user's request named (/proj/_in) and an output folder
 * (/proj/_out). It cannot reach the phone's files, start programs or open sockets. Needs internet the first time (runtime download).
 */
object SkillRunner {
    private const val BASE = "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/"

    class Result(val loaded: Boolean, val finished: Boolean, val out: String, val err: String, val outputs: Map<String, ByteArray>)

    private const val SETUP = """
import json, os, sys, base64
root = '/proj'
for p, c in json.loads(FILES_JSON).items():
    fp = os.path.join(root, p)
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    with open(fp, 'w', encoding='utf-8') as f:
        f.write(c)
for p, c in json.loads(BIN_JSON).items():
    fp = os.path.join(root, p)
    os.makedirs(os.path.dirname(fp), exist_ok=True)
    with open(fp, 'wb') as f:
        f.write(base64.b64decode(c))
os.makedirs(os.path.join(root, '_out'), exist_ok=True)
os.chdir(root)
"""

    private const val RUN = """
import os, sys, runpy, traceback, json
script = os.path.join('/proj', ENTRY)
sys.path[:0] = [os.path.dirname(script), os.path.join('/proj', SKILL_ROOT), '/proj']
sys.argv = [script] + json.loads(ARGV_JSON)
try:
    runpy.run_path(script, run_name='__main__')
except SystemExit as e:
    if e.code not in (None, 0):
        print('[exit code %s]' % (e.code,), file=sys.stderr)
except BaseException:
    print(traceback.format_exc(), file=sys.stderr)
"""

    private const val COLLECT = """
import os, json, base64
out = {}
for dp, dn, fn in os.walk('/proj/_out'):
    for n in fn:
        p = os.path.join(dp, n)
        if os.path.getsize(p) <= 6000000 and len(out) < 8:
            with open(p, 'rb') as f:
                out[os.path.relpath(p, '/proj/_out')] = base64.b64encode(f.read()).decode()
json.dumps(out)
"""

    private fun page(): String = "<!doctype html><html><body><script src=\"" + BASE + "pyodide.js\"></script><script>\n" +
        "var OUT='',ERR='';\n" +
        "async function go(){\n" +
        " try{\n" +
        "  var py=await loadPyodide({indexURL:\"" + BASE + "\"});\n" +
        "  Bridge.loaded();\n" +
        "  py.setStdout({batched:function(s){OUT+=s+\"\\n\";}});\n" +
        "  py.setStderr({batched:function(s){ERR+=s+\"\\n\";}});\n" +
        "  py.setStdin({stdin:function(){return null;}});\n" +
        "  py.globals.set('FILES_JSON',Bridge.files());\n" +
        "  py.globals.set('BIN_JSON',Bridge.bin());\n" +
        "  py.globals.set('ENTRY',Bridge.entry());\n" +
        "  py.globals.set('SKILL_ROOT',Bridge.skillRoot());\n" +
        "  py.globals.set('ARGV_JSON',Bridge.argv());\n" +
        "  await py.runPythonAsync(Bridge.pySetup());\n" +
        "  try{await py.loadPackagesFromImports(Bridge.imports());}catch(e){ERR+='[package load] '+e+\"\\n\";}\n" +
        "  if(Bridge.reqs()!='[]'){try{await py.loadPackage('micropip');py.globals.set('REQS_JSON',Bridge.reqs());await py.runPythonAsync('import micropip, json\\nawait micropip.install(json.loads(REQS_JSON), keep_going=True)');}catch(e){ERR+='[pip install] '+e+\"\\n\";}}\n" +
        "  await py.runPythonAsync(Bridge.pyRun());\n" +
        "  try{Bridge.outputs(py.runPython(Bridge.pyCollect()));}catch(e){ERR+='[collect] '+e+\"\\n\";}\n" +
        " }catch(e){ERR+=String((e&&e.message)||e)+\"\\n\";}\n" +
        " Bridge.done(OUT,ERR);\n" +
        "}\n" +
        "go();\n" +
        "</script></body></html>"

    class Bridge(
        val files: String, val bin: String, val entry: String, val skillRoot: String, val argv: String, val imports: String, val reqs: String,
        val loadedLatch: CountDownLatch, val doneLatch: CountDownLatch, val collect: String
    ) {
        @Volatile var out = ""
        @Volatile var err = ""
        @Volatile var finished = false
        @Volatile var didLoad = false
        @Volatile var outputsJson = "{}"
        @JavascriptInterface fun files() = files
        @JavascriptInterface fun bin() = bin
        @JavascriptInterface fun entry() = entry
        @JavascriptInterface fun skillRoot() = skillRoot
        @JavascriptInterface fun argv() = argv
        @JavascriptInterface fun imports() = imports
        @JavascriptInterface fun reqs() = reqs
        @JavascriptInterface fun pySetup() = SETUP
        @JavascriptInterface fun pyRun() = RUN
        @JavascriptInterface fun pyCollect() = collect
        @JavascriptInterface fun outputs(json: String) { outputsJson = json }
        @JavascriptInterface fun loaded() { didLoad = true; loadedLatch.countDown() }
        @JavascriptInterface fun done(o: String, e: String) { out = o; err = e; finished = true; loadedLatch.countDown(); doneLatch.countDown() }
    }

    /**
     * Blocking: call from a background thread.
     * [textFiles] and [binFiles] are paths relative to /proj; [entry] and [skillRoot] are relative to /proj too.
     */
    fun run(
        ctx: Context, entry: String, skillRoot: String, argv: List<String>,
        textFiles: Map<String, String>, binFiles: Map<String, ByteArray>, loadWaitMs: Long = 70000, runWaitMs: Long = 90000,
        extraReqs: List<String> = emptyList(), importsOverride: String? = null, maxOutBytes: Long = 6_000_000
    ): Result {
        val files = JSONObject(); for ((k, v) in textFiles) files.put(k, v)
        val bin = JSONObject(); for ((k, v) in binFiles) bin.put(k, java.util.Base64.getEncoder().encodeToString(v))
        val py = textFiles.filterKeys { it.endsWith(".py") }
        val imports = importsOverride ?: py.values.joinToString("\n")
        val reqs = JSONArray(Deps.pipRequirements(py) + extraReqs).toString()
        val loadedLatch = CountDownLatch(1)
        val doneLatch = CountDownLatch(1)
        val b = Bridge(files.toString(), bin.toString(), entry, skillRoot, JSONArray(argv).toString(), imports, reqs, loadedLatch, doneLatch,
            COLLECT.replace("6000000", maxOutBytes.toString()))
        val main = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        val jsErr = StringBuilder()
        main.post {
            try {
                val w = WebView(ctx.applicationContext)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.allowFileAccess = false
                w.settings.allowContentAccess = false
                w.addJavascriptInterface(b, "Bridge")
                w.webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(m: android.webkit.ConsoleMessage?): Boolean {
                        if (m != null && m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR && jsErr.length < 600)
                            jsErr.append(m.message()).append("\n")
                        return true
                    }
                }
                w.loadDataWithBaseURL("https://py.local/", page(), "text/html", "UTF-8", null)
            } catch (e: Exception) { loadedLatch.countDown(); doneLatch.countDown() }
        }
        try { loadedLatch.await(loadWaitMs, TimeUnit.MILLISECONDS) } catch (e: Exception) {}
        if (b.didLoad && !b.finished) try { doneLatch.await(runWaitMs, TimeUnit.MILLISECONDS) } catch (e: Exception) {}
        main.post { try { wv?.stopLoading(); wv?.destroy() } catch (e: Exception) {} }
        val err = if (b.finished) b.err else (b.err + jsErr.toString())
        val outs = LinkedHashMap<String, ByteArray>()
        try {
            val o = JSONObject(b.outputsJson)
            for (k in o.keys()) outs[k] = java.util.Base64.getDecoder().decode(o.getString(k))
        } catch (_: Exception) {}
        return Result(b.didLoad, b.finished, b.out, err, outs)
    }
}
