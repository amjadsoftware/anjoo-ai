package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Skills management: installed skills, import / update from a ZIP, details, enable / disable, delete, search,
 * which skills are active and the execution history. Opened from Tools Hub > Skills.
 */
class SkillsActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private lateinit var theme: CyberTheme
    private lateinit var content: LinearLayout
    private lateinit var search: EditText
    private var tab = 0            // 0 Installed, 1 Active, 2 History
    private var query = ""
    private var busy = ""
    private val good = Color.rgb(46, 125, 50)
    private val warn = Color.rgb(230, 126, 0)
    private val bad = Color.rgb(198, 40, 40)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun faint() = Color.argb(70, 128, 128, 128)
    private fun shape(fill: Int, stroke: Int = faint(), radius: Int = 14) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(radius).toFloat()
    }
    private fun label(text: String, size: Float = 14f, color: Int = theme.ink, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(theme.surface); setPadding(dp(14), dp(12), dp(14), dp(12)) }
    private fun gap() = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    private fun button(text: String, onClick: () -> Unit) = label(text, 13f, theme.accent, true).apply {
        background = shape(Color.TRANSPARENT, theme.accent, 16); setPadding(dp(12), dp(7), dp(12), dp(7)); setOnClickListener { onClick() }
    }
    private fun time(ts: Long) = SimpleDateFormat("d MMM, HH:mm", Locale.ENGLISH).format(Date(ts))
    private val store get() = Skills.store(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        theme = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        Style.bars(window, theme)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(theme.bg)
            setPadding(dp(14), dp(28), dp(14), dp(10))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("‹", 30f).apply { setPadding(dp(6), 0, dp(18), dp(4)); setOnClickListener { finish() } })
        header.addView(label("Skills", 20f, theme.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("↻", 24f, theme.accent).apply { setPadding(dp(14), 0, dp(6), dp(2)); setOnClickListener { render() } })
        root.addView(header)

        search = EditText(this).apply {
            hint = "Search skills…"; textSize = 14f; setTextColor(theme.ink); setHintTextColor(theme.muted); isSingleLine = true
            setPadding(dp(14), dp(10), dp(14), dp(10)); background = shape(theme.surface, faint(), 13)
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { query = s?.toString().orEmpty(); render() }
            override fun afterTextChanged(s: Editable?) {}
        })
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Installed", "Active", "History").forEachIndexed { i, t ->
            tabs.addView(label(t, 14f, theme.accent, true).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(9), 0, dp(9))
                setOnClickListener { tab = i; render() }
                tag = i
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(6) })
        }
        tabsRow = tabs
        root.addView(tabs, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        setContentView(root)
        render()
        // First visit: the bundled pack installs itself (a few seconds); never block the screen for it.
        if (store.list().isEmpty()) {
            busy = "Installing the bundled skills pack…"; render()
            Thread {
                val msg = try { Skills.ensureBuiltIn(this) } catch (e: Throwable) { "Install failed: " + e.message }
                runOnUiThread { busy = ""; render(); if (msg != null && store.list().isEmpty()) Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
            }.start()
        }
    }

    private lateinit var tabsRow: LinearLayout

    override fun onResume() { super.onResume(); if (::content.isInitialized) render() }

    private fun render() {
        for (i in 0 until tabsRow.childCount) (tabsRow.getChildAt(i) as TextView).apply {
            background = if (i == tab) shape(theme.surface, theme.accent, 14) else shape(Color.TRANSPARENT, faint(), 14)
        }
        search.visibility = if (tab == 0) android.view.View.VISIBLE else android.view.View.GONE
        content.removeAllViews()
        when (tab) { 0 -> renderInstalled(); 1 -> renderActive(); else -> renderHistory() }
    }

    // ───────────── Installed ─────────────

    private fun renderInstalled() {
        val all = store.list()
        val auto = Skills.autoOn(this)

        val top = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(label("Automatic skills", 15f, theme.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Switch(this).apply { isChecked = auto; setOnCheckedChangeListener { _, on -> Skills.setAuto(this@SkillsActivity, on); render() } })
        top.addView(row)
        top.addView(label(if (auto) "Anjoo reads your request, picks the skills that apply and follows their full instructions. You never have to name a skill." else "Off: skills are not added to requests on their own. Anjoo can still use skill_find / skill_read if you ask for a skill.", 12.5f, theme.muted).apply { setPadding(0, dp(4), 0, dp(6)) })
        top.addView(label("${all.size} installed · ${all.count { it.enabled }} enabled", 12.5f, theme.muted))
        val btns = LinearLayout(this).apply { gravity = Gravity.START; setPadding(0, dp(8), 0, 0) }
        btns.addView(button("Import / update ZIP") { pickZip() })
        top.addView(btns)
        content.addView(top, LinearLayout.LayoutParams(-1, -2))

        if (busy.isNotEmpty()) content.addView(card().apply { addView(label(busy, 13.5f, theme.muted)) }, gap())

        val q = query.trim().lowercase(Locale.ROOT)
        val shown = all.filter { r -> q.isEmpty() || r.name.lowercase(Locale.ROOT).contains(q) || (store.meta(r.id)?.description.orEmpty().lowercase(Locale.ROOT).contains(q)) }
        if (all.isEmpty() && busy.isEmpty()) content.addView(card().apply { addView(label("No skills installed. Import a skills ZIP (a folder per skill, each with a SKILL.md).", 13.5f, theme.muted)) }, gap())
        if (all.isNotEmpty() && shown.isEmpty()) content.addView(card().apply { addView(label("No skill matches '$query'.", 13.5f, theme.muted)) }, gap())
        for (r in shown) {
            val meta = store.meta(r.id)
            val c = card().apply { setOnClickListener { showDetails(r.id) } }
            val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            head.addView(label(r.name, 15.5f, theme.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
            head.addView(Switch(this).apply {
                isChecked = r.enabled
                setOnCheckedChangeListener { _, on -> store.setEnabled(r.id, on); store.log(if (on) "enable" else "disable", r.name, "ok", "by user"); render() }
            })
            c.addView(head)
            c.addView(label(meta?.description.orEmpty().replace('\n', ' ').take(240), 12.5f, theme.muted).apply { maxLines = 3; setPadding(0, dp(3), 0, dp(4)) })
            val runnable = meta?.scripts?.count { it.status == SkillCore.RunStatus.RUNNABLE || it.status == SkillCore.RunStatus.NEEDS_PACKAGES } ?: 0
            val scripts = meta?.scripts?.size ?: 0
            c.addView(label("v${r.version} · ${r.fileCount} files · $scripts scripts ($runnable run on phone) · " + (if (r.builtin) "bundled" else "imported") + (if (r.note.isNotEmpty()) " · ${r.note}" else ""), 11.5f, if (r.enabled) theme.muted else warn))
            content.addView(c, gap())
        }
    }

    private fun pickZip() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(i, 520)
        } catch (e: Exception) { Toast.makeText(this, "Could not open the file picker: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Legacy result API retained for compatibility with minSdk and existing activities")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 520 || resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        val name = (try { contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) it.getString(0) else null } } catch (e: Exception) { null }) ?: "skills.zip"
        busy = "Importing $name…"; render()
        Thread {
            val rep = try { contentResolver.openInputStream(uri)?.use { Skills.importZip(this, it, name) } } catch (e: Exception) { null }
            runOnUiThread {
                busy = ""; render()
                val text = rep?.text() ?: "Could not read the file."
                AlertDialog.Builder(this).setTitle(if (rep != null && rep.changed) "Skills imported" else "Nothing imported").setMessage(text).setPositiveButton("OK", null).show()
            }
        }.start()
    }

    private fun showDetails(id: String) {
        val r = store.get(id) ?: return
        val m = store.meta(id)
        Thread {
            val problems = store.integrityProblems(id)
            val sb = StringBuilder()
            sb.append(m?.description.orEmpty()).append("\n\n")
            sb.append("Version: ").append(r.version).append(if (r.prevVersion.isNotEmpty()) " (previous: ${r.prevVersion})" else "").append('\n')
            sb.append("Source: ").append(if (r.builtin) "bundled with Anjoo" else r.source).append('\n')
            sb.append("Installed ").append(time(r.installedAt)).append(" · updated ").append(time(r.updatedAt)).append('\n')
            if (!m?.license.isNullOrEmpty()) sb.append("License: ").append(m!!.license.take(120)).append('\n')
            sb.append("Content hash: ").append(r.hash.take(16)).append("…\n")
            sb.append("Integrity: ").append(if (problems.isEmpty()) "all ${r.fileCount} files match the import" else problems.take(5).joinToString("; ")).append("\n\n")
            val byKind = m?.files.orEmpty().groupBy { it.kind }
            sb.append("Files: ").append(SkillCore.Kind.values().filter { byKind.containsKey(it) }.joinToString(", ") { "${byKind[it]!!.size} ${it.name.lowercase(Locale.ROOT)}" }).append('\n')
            val sc = m?.scripts.orEmpty()
            if (sc.isNotEmpty()) {
                sb.append("\nScripts (").append(sc.size).append("):\n")
                for (s in sc.take(40)) sb.append("• ").append(s.path).append(" — ").append(s.status.label).append(if (s.status == SkillCore.RunStatus.RUNNABLE) "" else " (" + s.reason + ")").append('\n')
                if (sc.size > 40) sb.append("… ").append(sc.size - 40).append(" more\n")
                sb.append("Scripts may run: ").append(if (r.scriptsAllowed) "yes (each run still asks you)" else "NO — turn on only after reviewing this skill").append('\n')
            }
            runOnUiThread {
                val tv = TextView(this).apply { text = sb.toString(); textSize = 13f; setTextColor(theme.ink); setPadding(dp(20), dp(10), dp(20), dp(6)) }
                AlertDialog.Builder(this).setTitle(r.name).setView(ScrollView(this).apply { addView(tv) })
                    .setPositiveButton("View SKILL.md") { _, _ -> showInstructions(r) }
                    .setNegativeButton("Delete") { _, _ -> confirmDelete(r) }
                    .setNeutralButton(if (r.scriptsAllowed) "Block scripts" else "Allow scripts") { _, _ -> store.setScriptsAllowed(r.id, !r.scriptsAllowed); store.log("scripts", r.name, "ok", if (r.scriptsAllowed) "blocked" else "allowed"); render() }
                    .show()
            }
        }.start()
    }

    private fun showInstructions(r: SkillStore.Rec) {
        val text = try { java.io.File(store.skillDir(r.id), "SKILL.md").readText(Charsets.UTF_8) } catch (e: Exception) { "Could not read SKILL.md: ${e.message}" }
        val tv = TextView(this).apply { this.text = text.take(60_000) + if (text.length > 60_000) "\n… (${text.length - 60_000} more characters)" else ""; textSize = 12f; typeface = Typeface.MONOSPACE; setTextColor(theme.ink); setPadding(dp(16), dp(8), dp(16), dp(8)); setTextIsSelectable(true) }
        AlertDialog.Builder(this).setTitle("${r.name} · SKILL.md").setView(ScrollView(this).apply { addView(tv) }).setPositiveButton("Close", null).show()
    }

    private fun confirmDelete(r: SkillStore.Rec) {
        AlertDialog.Builder(this).setTitle("Delete ${r.name}?").setMessage("The skill and all its files are removed from this phone. " + if (r.builtin) "It stays deleted after app updates; you can bring it back by importing its folder as a ZIP." else "This cannot be undone.")
            .setPositiveButton("Delete") { _, _ -> Skills.delete(this, r.id); render() }.setNegativeButton("Cancel", null).show()
    }

    // ───────────── Active ─────────────

    private fun renderActive() {
        val all = store.list()
        val on = all.filter { it.enabled }
        val auto = Skills.autoOn(this)
        val c = card()
        c.addView(label("Active skills status", 15f, theme.ink, true))
        c.addView(label((if (auto) "Automatic activation is ON." else "Automatic activation is OFF.") + " ${on.size} of ${all.size} skills are enabled and can be picked for a request.", 13f, if (auto) good else warn).apply { setPadding(0, dp(4), 0, dp(4)) })
        val cur = Skills.current
        c.addView(label(if (cur != null) "Last request: ${cur.names.joinToString(", ")}" + (if (cur.sticky) " (continued)" else "") + " — verification: " + (when (cur.verified) { true -> "passed"; false -> "failed"; null -> "not run" }) else "No skill has been used since the app started.", 12.5f, theme.muted))
        content.addView(c, LinearLayout.LayoutParams(-1, -2))
        val usage = store.usage()
        val rows = on.sortedByDescending { usage[it.name]?.second ?: 0L }
        for (r in rows) {
            val u = usage[r.name]
            content.addView(card().apply {
                addView(label(r.name, 14.5f, theme.ink, true))
                addView(label(if (u != null) "Used ${u.first}× · last ${time(u.second)}" else "Enabled · not used yet", 12f, theme.muted))
            }, gap())
        }
        val off = all.filter { !it.enabled }
        if (off.isNotEmpty()) content.addView(card().apply {
            addView(label("Disabled (never activate)", 13f, warn, true)); addView(label(off.joinToString(", ") { it.name }, 12.5f, theme.muted))
        }, gap())
    }

    // ───────────── History ─────────────

    private fun renderHistory() {
        val h = store.history(120)
        if (h.isEmpty()) { content.addView(card().apply { addView(label("No skill activity yet. Every automatic activation, file read, script run, verification and import is listed here.", 13.5f, theme.muted)) }, LinearLayout.LayoutParams(-1, -2)); return }
        content.addView(button("Clear history shown") {
            AlertDialog.Builder(this).setMessage("Delete the skill history?").setPositiveButton("Delete") { _, _ -> try { java.io.File(store.root, "_history.tsv").delete() } catch (_: Exception) {}; render() }.setNegativeButton("Cancel", null).show()
        })
        for (e in h) {
            val col = when (e.status) { "ok", "continued" -> good; "failed", "error" -> bad; else -> warn }
            content.addView(card().apply {
                val head = LinearLayout(this@SkillsActivity)
                head.addView(label(e.action + (if (e.skills.isNotEmpty()) " · " + e.skills else ""), 13.5f, theme.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
                head.addView(label(e.status, 12f, col, true))
                addView(head)
                if (e.detail.isNotEmpty()) addView(label(e.detail, 12f, theme.muted))
                addView(label(time(e.ts), 11f, theme.muted))
            }, gap())
        }
    }
}
