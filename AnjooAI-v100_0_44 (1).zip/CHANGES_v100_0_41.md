# v100.0.41

- Fix: GitHub build failed at `validateSigningDebug` with "Keystore file .../app/anjoo.keystore not found for signing config 'anjooFixed'".
- The build now falls back to the standard Android debug key when `app/anjoo.keystore` is missing, so the APK always builds.
- Warning: an APK signed with the fallback key will not install over an app signed with the old key. Put the original `app/anjoo.keystore` back to keep updates working.
