# v100.0.42

- Restored `app/anjoo.keystore` (the original fixed key, taken from v100.0.38) so new APKs install over the existing app again (fixes INSTALL_FAILED_UPDATE_INCOMPATIBLE).
- The debug-key fallback from v100.0.41 stays as a safety net, but it is not used while the keystore is present.
