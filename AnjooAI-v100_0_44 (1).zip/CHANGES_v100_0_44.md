# v100.0.44 — build fix

GitHub debug build of v100.0.43 failed in `compileDebugKotlin`:
- `PptRun.kt:338:1 Unclosed comment` and `Skills.kt:179:26 Unresolved reference: PptRun` (the second error was only a result of the first).

Cause: the header comment of `PptRun.kt` contained the text `exports/*.pptx`. In Kotlin, `/*` inside a block comment starts a nested comment, so the comment never closed.
Fix: text changed to `exports/NAME.pptx`. No code changed. A scan of all .kt files found no other unbalanced block comments.
