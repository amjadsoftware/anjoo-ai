# Anjoo AI: Android awaazi assistant

Mic dabayein aur bolein. Gemini hukm samajhta hai aur phone par kaam karta hai.

## Kya kar sakta hai
- Koi bhi installed app kholna ("WhatsApp kholo", "YouTube kholo")
- Contacts se naam dhoond kar call karna (call se pehle "Haan/Nahi" poochta hai)
- SMS bhejna (bhejne se pehle poochta hai)
- WhatsApp chat kholna aur paigham likh dena (send ka button aap dabate hain)
- Alarm aur timer lagana
- Web search, website kholna, Maps mein rasta
- Jawab awaaz mein bhi sunata hai (agar phone mein Urdu/English voice maujood ho)

## Jo nahi kar sakta
- Doosri apps ke andar khud tap karna (jaise bank app mein paise bhejna). Yeh jaan boojh kar nahi rakha.
- WhatsApp ka paigham khud send karna. Android is ki ijazat nahi deta, aap ko ek tap karna hota hai.

## Banane ke qadam (pehli baar)
1. Computer par Android Studio install karein (developer.android.com/studio).
2. Android Studio mein File > Open, aur is `AnjooAI` folder ko kholein. Gradle sync poora hone dein (internet chahiye, pehli baar kuch minute lagte hain).
3. Phone mein Settings > About phone > Build number par 7 baar tap karein, phir Developer options mein USB debugging on karein.
4. Phone ko USB se jorain, Android Studio mein upar ka hara Run button dabayein. App phone par install ho jayegi.
   (Ya Build > Build APK(s) se APK bana kar phone mein copy karke install karein.)

## Pehli dafa istemal
1. App kholte hi Settings aayegi. Apni Gemini API key dalein: aistudio.google.com/apikey par apne Google account se "Create API key" dabayein. Model "gemini-3.8-flash" rakhein (ya wahan ki list se jo naam dikhe).
2. Mic, contacts, call aur SMS ki ijazat "Allow" karein.
3. Mic dabayein aur bolein: "Ahmed ko call karo", "Subah 6 baje ka alarm lagao", "WhatsApp kholo".
   Zubaan ka button "اردو / English" bolne ki zubaan badalta hai.

## Zaroori baatein
- Gemini Pro subscription aur API key do alag cheezein hain. Key AI Studio se banti hai, us par free limit hoti hai aur us se zyada istemal par kharcha ho sakta hai. Key kisi ko na dein; yeh sirf aap ke phone mein rehti hai.
- WhatsApp ke liye "0300..." wale number Pakistan ke code (92) mein badal diye jate hain.
- Awaaz pehchaan Google ki service use karti hai, is liye internet aur Google app chahiye.
- Pehle kuch din call/SMS ki tasdeeq wali screen par nazar rakhein ke naam aur number sahi hain.

## v12 naye kaam
- Naya Anjoo AI app icon (robot + neon circuit).
- Markhor hata diya: ab ek cute robot (Buddy) screen par ghoomta hai, aapki baat par chehre ke expressions badalta hai (khush, pyar, udaas, hairan, soch, sunna, neend).
- Mouse jaisa arrow (cursor): jab Anjoo koi kaam kare (tap, likhna, back/home, scroll, app kholna) to arrow dusri apps ke upar bhi dikhta hai ke kahan ja raha hai. Iske liye Accessibility on honi chahiye.
- Awaaz pehchan behtar aur tez: jumla 0.7 sec khamoshi par poora, jawab ki awaz pehle jumle se shuru, Anjoo soch raha ho tab bhi aapki nayi baat sunta hai, aur samajhne par chhoti beep aati hai.

## v14 Code Studio (Claude jaisi coding)
- Menu > "Code Studio": likhein ya bolein kya banana hai. Pehle architecture plan, phir poora multi-file project (README aur dependency file samet), phir bug review.
- Project ke har file ka tab: dekhein, Copy, Share, haath se Edit/Save.
- Badlav: "dark mode lagao", "login add karo" likhein, sirf zaroori files badalti hain. Ask: koi bhi code ya bug ka sawal, project dekh kar jawab.
- Web projects ke liye Run (live preview), Zip se poora project save.
- Awaaz se: "Anjoo, ek calculator app banao" (write_code) ya "isme history add karo" (edit_code).

## v15 Professional chat app
- Boot lines ("loading...") aur screen par ghoomta robot hata diya. Ab saaf chat screen hai; robot sirf chhote avatar ki tarah header mein (expressions ke saath) aur khali screen par.
- Header: history, avatar, naam + model, naya chat, menu. Khali chat par suggestions (Claude/ChatGPT/Gemini jaisa).
- Jawab Markdown mein: headings, lists, bold, code blocks (Copy ke saath), links. Har jawab ke neeche Copy, Listen, Share, Retry.
- Think (DeepSeek jaisa gehri soch, "Thought process" dikhta hai) aur Web (Google Search se taaza maloomat + sources) chips.
- "+" se Photo, Camera, PDF/text/code file attach (Kimi jaisa lambi file parhna).
- Custom instructions (ChatGPT jaisa), Code Studio, Live voice (mic button), phone control sab isi app mein.
- Settings grouped: Voice and language, Phone control, Appearance, Backup, API key.

## v16 Coding aur Thinking advanced
- Chat mein code likhwayein to jawab ke code block par Code | Preview tabs aate hain (HTML/SVG ka live preview usi chat mein), saath Full screen, Studio, Copy.
- Code Studio ki chat mein har project ka card: files, code viewer, live Preview aur Edit, sab usi chat ke andar.
- Deep think (Code Studio mein ON/OFF): pehle gehra analysis (requirements, edge cases, test scenarios), phir code, phir 2 round review/test. "Thought process" dekh sakte hain.
- Main chat ka Think chip ab advanced level (high thinking) par chalta hai.

## v31 naya icon, opening scene, image generation, behtar coding
- Naya icon: koi harf nahi, ek roshan "spark" aur ghoomta hua orbit ring (gradient background). Android 13+ par themed icon bhi.
- App khulte hi chhoti film jaisi scene: raat ka aasman, taare, aurora, ubharta hua orb, shooting star, jugnu, aur beech mein Anjoo spark. Tap karein to foran skip.
- Chat mein image banana: "Image" chip dabayein ya seedha likhein/bolein "ek sheer ki tasveer banao". Picture chat mein aati hai; tap par full screen, Save (Pictures/AnjooAI), Share, Edit (photo bhej kar "isko cartoon bana do" bhi chalta hai). Model: gemini-2.5-flash-image (agar aapke account par na ho to khud doosre model par chala jata hai).
- Coding: ab har web project banne ke baad chhupe hue browser mein khud chalta hai; JavaScript errors, missing files ya khali page mile to Anjoo khud theek karta hai (2 round). Naye rules: behtar UI design, games, tests, scripts, backend.

## Naye AI providers (v34)
Settings mein ab teen cheezein chunni hoti hain: **AI** (Google Gemini free by default, OpenAI, Claude, OpenRouter, Groq, DeepSeek, Mistral, xAI, ya Custom URL), phir **Model** (list se tap karke, ya "Load all models" se poori list), phir us ki **API key**. Har provider ki key alag save hoti hai.
Voice typing, Gemini voice aur picture banana hamesha Google Gemini key se chalte hain, chahe chat kisi aur AI se ho.

## v38 Claude jaisa interface, Thinking aur Commands summary
- **Look:** naye themes "Claude Light" (garam cream + terracotta) aur "Claude Dark". Pehli dafa phone ke dark/light mode ke mutabiq khud lag jate hain; Menu > Appearance se badal sakte hain (purane themes bhi maujood hain). Jawab serif font mein, bubble ke baghair, har jawab ke neeche ✦ ke saath Copy/Listen/Share/Retry. Composer gol card jaisa, khali screen par waqt ke mutabiq salam.
- **Thinking:** jawab se pehle live card: "✦ Thinking… 4s" aur model ki soch ka khulasa. Jawab shuru hote hi yeh "Thought for 4s ›" ban jata hai, tap karke poori soch dekhein. Ab har sawal par aata hai (pehle sirf Think chip par).
- **Commands summary:** jo bhi phone ka kaam Anjoo karta hai (app kholna, alarm, call, SMS, search...) woh live list mein dikhta hai: `… chal raha hai`, `✓ ho gaya`, `! masla`, `✕ nakam`. Jawab ke upar "⌘ Ran 2 commands ›" ke neeche ek line ka khulasa; tap karein to har command aur uska natija. Yeh chat history mein bhi save rehta hai.
- Menu > "Show thinking and commands" se yeh dono band/on kar sakte hain.
- Anjoo ab commands dohrata nahi: sirf ek chhota sachcha jumla batata hai ke kya hua aur kya nahi.

## v39 Sharmila robot
- Screen par ghoomne wala robot ab touch se bhagta hai: robot ko chhuen to ek qadam peechay hop karke hat jata hai, uske bagal mein tap karen to touch se door tez bhag jata hai. Kone mein phans jaye to doosri taraf nikal jata hai. Robot ko ungli se ghaseet kar kahin bhi rakh sakte hain (pehle jaisa).

## v40 Movie jaisa opening (Splash)
App khulte hi ~6 sec ki chhoti film: letterbox, terminal boot lines, hara code barish ki tarah girta hai, 10 parasite tentacles (chamakte hue, suckers aur roshan nok ke saath) char taraf se rengte hain, code ko pakar kar jhatke dete hain (glitch aur camera shake), phir sab kuch center mein khinch kar safed flash aur shockwave, tentacles teal rang mein shant ho jate hain aur Anjoo logo orbit rings, lens flare aur sparks ke saath ubharta hai. Haptic jhatka bhi aata hai. Tap karein to foran skip.

## v41 Image upgrade: padhna, text parhna, banana
- **Photo ke quick buttons:** photo lagate hi 📝 Read text, 🔍 Describe, 🌐 Translate, 🧮 Solve, ✏️ Edit ke buttons aate hain. PDF par Summary / Read text / Translate.
- **Text parhna (OCR):** chip "📝 Read text" ya menu se photo chunein. Urdu, Arabic, English, haath ka likha, tables, receipts, screenshots. Text jaisa likha hai waisa hi aata hai (translate/summary ke bina), neeche Copy aur "Translate / Summarize / Fix spelling" ke suggestions.
- **Ek se zyada photos:** gallery se 4 tak photos ek saath (compare, ya kai pages ka text). Photo ki quality OCR ke liye behtar (1800px).
- **Photo par follow-up:** pehle agla sawal aate hi photo bhool jati thi. Ab "ab isko English mein karo" jaise sawal chalte hain. Retry bhi photo ke saath chalta hai.
- **Dusri apps se Share:** Gallery, WhatsApp, Chrome se photo/PDF/text "Share" > Anjoo AI. Seedha chat mein aa jata hai.
- **Image banana:** 🎨 Image chip dabane par Style (Realistic, Anime, 3D, Logo, Oil painting, Cinematic...), Size (1:1, 16:9, 9:16...) aur Versions (1 se 3 ek saath) ke chips. Awaaz ya chat mein "teen options banao" bhi chalta hai.
- **Banai hui picture par:** Save, Share, Edit, **Another** (naya version, usi idea se) aur **More** (background hatao, cartoon, anime, oil painting, black and white, cinematic, HD/sharper, sticker).
- **Zoom viewer:** picture par tap karein: pinch se zoom, double-tap se zoom in/out, ungli se khiskayein, Save/Share neeche.
- Gemini key chahiye (image padhna aur banana dono Google Gemini se). Pehle build ke baad phone par test zaroor karein: yeh badlav is machine par compile nahi kiye ja sake (Android SDK nahi tha).

## v41 WhatsApp ki bheji hui picture kholo aur parho
Bolein ya likhein: "Ahmed ne WhatsApp par jo image bheji hai wo kholo aur parho". Anjoo ye karta hai: WhatsApp kholna, Ahmed ka chat kholna, sabse nayi picture kholna (`tap_image`), phir screen ki picture le kar Gemini se parhwana (`look_at_screen`): picture ka text (Urdu/English/Arabic) aur usmein kya hai.
- Zaroori: Accessibility on honi chahiye. Naye version ke baad **ek dafa Accessibility band karke dobara on karein**, warna screenshot ki nayi ijazat nahi milti.
- Android 11 ya naya chahiye. Gemini key chahiye.
- Agar chat ya picture na mile to Anjoo saaf bata deta hai. Picture ke andar likhi hidayat ko hukm nahi samjha jata.

## v41 "Jo bolo wo karo" (full control)
- Anjoo ab kabhi nahi kehta "tool nahi hai". Har hukm ko steps mein todta hai aur ek tareeqa na chale to doosra ajmata hai (25 steps tak ek hukm mein).
- Naye tools: `list_screen` (screen par kya hai aur kahan), `tap_xy` (kisi bhi point par tap/long press), `swipe`, `wait`, aur keys: lock, screenshot, quick_settings, power_menu. `tap_text` ab text ke paas clickable na ho to us jagah touch karta hai.
- Menu > "⚡ Do it without asking (call, SMS, replies)" on karein to call/SMS/reply bina Yes/No ke seedha ho jate hain. Default off hai (galat naam sunne par galat call se bachne ke liye).
- Hadd: bank/payment apps ya FLAG_SECURE wali screens Android screenshot/touch rok sakta hai; password/OTP daalna Anjoo apni taraf se nahi karta.

## v41 Bank, wallet aur card se door (Guard)
- Anjoo bank/wallet apps (JazzCash, Easypaisa, HBL, UBL, Meezan, SadaPay, NayaPay, PayPal, Google Pay, STC Pay, Al Rajhi waghera) ke andar na parhta hai, na dabata hai, na screenshot leta hai. App kholna theek hai.
- Card number, CVV, PIN, OTP, expiry, password: na parhta, na copy/likhta, na bhejta, na yaad rakhta. Screen, SMS, notifications aur screenshot ke natije mein yeh `[hidden]` ho jate hain; aap ki likhi/boli hui baat mein card number AI ko jane se pehle chhupa diya jata hai.
- Sirf **account number / IBAN**: aap bolein "mera account number 0123456789 copy karo" ya "paste karo" to copy_text/type_text se ho jata hai (bank app ke text box mein bhi likh deta hai, lekin us app mein aur kuch nahi dabata).
- Code: `Guard.kt`.

## v42 Coding: Claude jaisa dikhana, tez edit, behtar check
- **Rang-birangi code (syntax highlighting):** chat ke code blocks, Code Studio ki files aur project card, sab mein keywords, strings, comments, numbers, functions, HTML tags aur CSS alag rang mein, line numbers ke saath. Har block par "kotlin · 42 lines" jaisi detail. 60,000 se bade code mein rang band ho jate hain taake app smooth rahe.
- **Live code dikhna:** jab Anjoo project likh raha hota hai to working card mein asli code (aakhri 10 lines, rang ke saath) saath saath chalta dikhta hai, kaunsi file ban chuki hai (✓) aur kaunsi likhi ja rahi hai, aur kitne seconds se kaam chal raha hai.
- **■ Stop button:** kaam ke dauran ➤ button ■ ban jata hai. Dabate hi screen foran free; background kaam agle step par ruk jata hai (naya model call nahi hota, aur roka hua jawab project par lagta nahi).
- **Tez edits (EDIT blocks):** project badalte waqt model ab poori file dobara nahi likhta, sirf SEARCH/REPLACE tukde likhta hai (Claude Code jaisa). Kam intezar, kam kharcha. Agar koi tukda file se match na kare to sirf wahi files poori dobara likhi jati hain.
- **Behtar auto-check (lint):** bracket ( [ { ka sahi jora (strings aur comments ko chhod kar), HTML ke duplicate id, JavaScript jo aisi id dhoondta hai jo HTML mein hai hi nahi, inline scripts ki jaanch, Python mein tab aur space ki milawat. Yeh nataij reviewer ko haqeeqat ki tarah diye jate hain.
- **Tez build:** Deep think OFF ho aur local check saaf aaye to model review ka extra round chhod diya jata hai.
- **Behtar prompts:** pehle asal maqsad samajhna, sawal poochne ki bajaye samajhdar defaults, poora kaam (empty state, keyboard, error messages) magar bila-zaroorat extras nahi. Har jawab ke aakhir mein "Next:" ke 2 mashware. Ask mode mein pehle seedha jawab, phir wajah, phir theek kiya hua code (file ka naam ke saath).
- Naye/badle files: `Hl.kt` (naya), `Md.kt`, `CodeActivity.kt`, `Coder.kt`.
- **Zaroori:** yeh badlav is machine par compile nahi kiye ja sake (Android SDK/Kotlin compiler nahi tha). Pehle Android Studio mein build karke test karein; agar koi compile error aaye to error ki line bhej dein, foran theek kar dunga.
