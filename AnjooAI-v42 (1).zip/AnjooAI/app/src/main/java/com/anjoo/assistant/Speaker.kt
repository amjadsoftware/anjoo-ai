package com.anjoo.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Speaks a line out loud and waits until it is finished. Call from a background thread only. */
object Speaker {
    fun say(ctx: Context, text: String, cloud: Boolean = true) {
        if (cloud && GeminiVoice.say(ctx, text)) return
        val ready = CountDownLatch(1)
        var ok = false
        val t = TextToSpeech(ctx.applicationContext) { st -> ok = st == TextToSpeech.SUCCESS; ready.countDown() }
        ready.await(8, TimeUnit.SECONDS)
        if (!ok) { t.shutdown(); return }
        val urdu = text.any { it in '؀'..'ۿ' }
        val urOk = t.isLanguageAvailable(Locale("ur", "PK")) >= TextToSpeech.LANG_AVAILABLE
        t.setLanguage(if (urdu && urOk) Locale("ur", "PK") else Locale("en", "IN"))
        val gender = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getString("voiceGender", "female")
        t.setPitch(if (gender == "male") 0.92f else 1.03f)
        t.setSpeechRate(0.94f)
        val done = CountDownLatch(1)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { done.countDown() }
            override fun onError(utteranceId: String?) { done.countDown() }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sp")
        done.await(10L + text.length / 6, TimeUnit.SECONDS)
        t.shutdown()
    }
}
