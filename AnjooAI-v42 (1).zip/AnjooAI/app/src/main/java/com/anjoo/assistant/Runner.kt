package com.anjoo.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Runs a web project in an invisible browser and reports what went wrong (script errors, missing files,
 * a blank page). The coder uses this to fix its own mistakes before the user ever sees them.
 */
object Runner {

    private fun mime(n: String): String = when (n.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "css" -> "text/css"
        "js", "mjs" -> "application/javascript"
        "json" -> "application/json"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "wasm" -> "application/wasm"
        else -> "text/plain"
    }

    fun entry(dir: File): String? {
        val all = Coder.readFiles(dir).keys
        return if (all.contains("index.html")) "index.html" else all.firstOrNull { it.lowercase().endsWith(".html") }
    }

    /** Returns a plain list of problems, or an empty string when the page loaded and ran cleanly (or cannot be tested). */
    fun check(ctx: Context, dir: File, waitMs: Long = 3500): String {
        val page = entry(dir) ?: return ""
        val found = StringBuilder()
        val missing = LinkedHashSet<String>()
        val done = CountDownLatch(1)
        val main = Handler(Looper.getMainLooper())
        var wv: WebView? = null
        val base = dir
        main.post {
            try {
                val w = WebView(ctx.applicationContext)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.layout(0, 0, 900, 1600)
                w.webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(m: ConsoleMessage?): Boolean {
                        if (m != null && m.messageLevel() == ConsoleMessage.MessageLevel.ERROR && found.length < 2500)
                            found.append("- ").append(m.message()).append(" (").append((m.sourceId() ?: "").substringAfterLast('/')).append(":").append(m.lineNumber()).append(")\n")
                        return true
                    }
                    override fun onJsAlert(view: WebView?, url: String?, message: String?, result: android.webkit.JsResult?): Boolean { result?.confirm(); return true }
                }
                w.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val u = request?.url ?: return null
                        if (u.host != "app.local") return null
                        val rel = (u.path ?: "").trimStart('/')
                        val f = File(base, rel)
                        return try {
                            if (f.isFile && f.canonicalPath.startsWith(base.canonicalPath)) WebResourceResponse(mime(f.name), "UTF-8", FileInputStream(f))
                            else { missing.add(rel); WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0))) }
                        } catch (e: Exception) { null }
                    }
                    override fun onPageFinished(view: WebView?, url: String?) {
                        // give timers and fetches a moment, then look at the page
                        main.postDelayed({
                            try {
                                view?.evaluateJavascript("(function(){var b=document.body;return b?((b.innerText||'').trim().length+'|'+b.children.length):'nobody'})()") { r ->
                                    val v = (r ?: "").trim('"')
                                    if (v == "nobody" || v.startsWith("0|") || v == "0|0") found.append("- The page is blank: nothing visible was drawn.\n")
                                    done.countDown()
                                }
                            } catch (e: Exception) { done.countDown() }
                        }, waitMs)
                    }
                }
                w.loadUrl("https://app.local/$page")
            } catch (e: Exception) { done.countDown() }
        }
        try { done.await(waitMs + 9000, TimeUnit.MILLISECONDS) } catch (e: Exception) {}
        main.post { try { wv?.stopLoading(); wv?.destroy() } catch (e: Exception) {} }
        for (m in missing) if (!m.endsWith("favicon.ico") && m.isNotEmpty() && found.length < 2800) found.append("- File not found when the page loaded: ").append(m).append("\n")
        return found.toString().trim()
    }
}
