package com.anjoo.assistant

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Random
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Opening scene, a short film:
 *  1. letterboxed black screen, a terminal boots and green code rains down;
 *  2. glowing parasite tentacles creep in from every edge, grab the code and thrash (glitches, camera shake);
 *  3. the code is dragged into the centre, a white impact flash, shockwave;
 *  4. the tentacles calm down and turn teal, and the Anjoo logo bursts out with an orbit ring, lens flare and sparks.
 * Everything is drawn with code. Tap to skip.
 */
class SplashActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var opened = false
    private var anim: ValueAnimator? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private class Tent(
        val ang: Float, val ph: Float, val amp: Float, val sp: Float, val delay: Float, val thick: Float
    )

    private class Scene(ctx: Context) : View(ctx) {
        var t = 0f // seconds
        private val d = resources.displayMetrics.density
        private val rnd = Random(11)
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.MONOSPACE }
        private val rect = RectF()
        private val logo = ctx.resources.getDrawable(R.drawable.ic_launcher_foreground, null)
        private var hit = false

        private val IMPACT = 3.1f

        // ---- code rain
        private val CODE = "{}()<>/;=+*&|!?#01abcdefxyz[]%".toCharArray()
        private val COLS = 24
        private val TRAIL = 13
        private val colSp = FloatArray(COLS) { 0.35f + rnd.nextFloat() * 0.7f }
        private val colOff = FloatArray(COLS) { rnd.nextFloat() }

        // ---- tentacles
        private val NT = 10
        private val NS = 18
        private val tents = List(NT) { i ->
            Tent(
                ang = i * (2 * PI / NT).toFloat() + rnd.nextFloat() * 0.4f,
                ph = rnd.nextFloat() * 6.28f,
                amp = 0.7f + rnd.nextFloat() * 0.8f,
                sp = 1.4f + rnd.nextFloat() * 1.6f,
                delay = rnd.nextFloat() * 0.9f,
                thick = 18f + rnd.nextFloat() * 10f
            )
        }
        private val gx = FloatArray(NT * (NS + 1))
        private val gy = FloatArray(NT * (NS + 1))
        private val reachA = FloatArray(NT)
        private val tipX = FloatArray(NT)
        private val tipY = FloatArray(NT)

        // ---- sparks
        private val spAng = FloatArray(56) { rnd.nextFloat() * 6.2832f }
        private val spSpd = FloatArray(56) { 90f + rnd.nextFloat() * 260f }
        private val spSz = FloatArray(56) { 1.2f + rnd.nextFloat() * 2.6f }

        private val LINES = listOf(
            Pair(0.35f, "> boot anjoo_ai --cinematic"),
            Pair(1.00f, "> WARNING: 10 parasites inside the code"),
            Pair(1.85f, "> they are eating the logic..."),
            Pair(2.55f, "> counter-measure: SPARK"),
            Pair(3.30f, "> contained. ANJOO online")
        )

        private fun ease(x: Float): Float { val k = x.coerceIn(0f, 1f); return 1f - (1f - k) * (1f - k) * (1f - k) }

        private fun back(x: Float): Float {
            val k = x.coerceIn(0f, 1f) - 1f
            return 1f + 2.70158f * k * k * k + 1.70158f * k * k
        }

        private fun mix(a: Int, b: Int, k: Float): Int {
            val q = k.coerceIn(0f, 1f)
            return Color.rgb(
                (Color.red(a) + (Color.red(b) - Color.red(a)) * q).toInt(),
                (Color.green(a) + (Color.green(b) - Color.green(a)) * q).toInt(),
                (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * q).toInt()
            )
        }

        /** Where every point of every tentacle is right now. */
        private fun geometry(w: Float, h: Float, cx: Float, cy: Float) {
            val morph = ease((t - 2.4f) / 0.7f)
            val calm = ease((t - IMPACT) / 0.6f)
            val kx = w * 0.62f
            val ky = h * 0.62f + (w * 0.62f - h * 0.62f) * morph
            val rt = when {
                t < 2.4f -> 0.55f
                t < IMPACT -> 0.55f + (0.12f - 0.55f) * ease((t - 2.4f) / 0.7f)
                else -> 0.12f + (0.5f - 0.12f) * ease((t - IMPACT) / 0.9f)
            }
            for (i in 0 until NT) {
                val tn = tents[i]
                val reach = ease((t - 0.5f - tn.delay) / 1.4f)
                reachA[i] = reach
                val bx = cx + cos(tn.ang) * w * 0.62f
                val by = cy + sin(tn.ang) * h * 0.62f
                val angTip = tn.ang + sin(t * tn.sp + tn.ph) * (0.26f - 0.14f * calm)
                val txx = cx + cos(angTip) * rt * kx
                val tyy = cy + sin(angTip) * rt * ky
                val ex = bx + (txx - bx) * reach
                val ey = by + (tyy - by) * reach
                val dx = ex - bx
                val dy = ey - by
                val len = max(1f, hypot(dx, dy))
                val nx = -dy / len
                val ny = dx / len
                val thrash = if (t > 1.5f && t < IMPACT) 1.5f else 1f
                val amp = tn.amp * thrash * (1f - 0.55f * calm) * 24f * d
                for (s in 0..NS) {
                    val f = s / NS.toFloat()
                    val wv = sin(f * 7f - t * tn.sp * 2.2f + tn.ph) * amp * (0.3f + f)
                    gx[i * (NS + 1) + s] = bx + dx * f + nx * wv
                    gy[i * (NS + 1) + s] = by + dy * f + ny * wv
                }
                tipX[i] = gx[i * (NS + 1) + NS]
                tipY[i] = gy[i * (NS + 1) + NS]
            }
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            if (w == 0f) return
            val cx = w / 2f
            val cy = h * 0.40f
            val calm = ease((t - IMPACT) / 0.6f)

            if (!hit && t >= IMPACT) { hit = true; try { performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) } catch (e: Exception) {} }

            geometry(w, h, cx, cy)

            // camera shake
            c.save()
            var shake = 0f
            if (t in 1.5f..2.4f) shake = 1.6f * d
            if (t in 3.05f..3.4f) shake = 7f * d * (1f - (t - 3.05f) / 0.35f)
            if (shake > 0f) c.translate(sin(t * 83f) * shake, cos(t * 71f) * shake)

            // background + infection tint (violet) that turns teal after the impact
            p.shader = LinearGradient(0f, 0f, 0f, h, Color.rgb(8, 6, 24), Color.rgb(2, 2, 10), Shader.TileMode.CLAMP)
            c.drawRect(-20f * d, -20f * d, w + 20f * d, h + 20f * d, p)
            val infect = ease((t - 0.8f) / 1.6f) * (1f - calm * 0.8f)
            val tint = mix(Color.rgb(150, 20, 150), Color.rgb(20, 150, 140), calm)
            p.shader = RadialGradient(cx, cy, hypot(w, h) * 0.62f,
                intArrayOf(Color.argb(0, 0, 0, 0), Color.argb((95 * infect).toInt(), Color.red(tint), Color.green(tint), Color.blue(tint))),
                floatArrayOf(0.35f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(-20f * d, -20f * d, w + 20f * d, h + 20f * d, p)
            p.shader = null

            // code rain
            drawRain(c, w, h, cx, cy)

            // impact glow behind the logo
            if (t >= IMPACT) {
                val lt = t - IMPACT
                val ga = ease(lt / 0.6f)
                val gr = 190f * d * (1f + 0.04f * sin(t * 3f))
                p.shader = RadialGradient(cx, cy, gr,
                    intArrayOf(Color.argb((170 * ga).toInt(), 90, 255, 225), Color.argb((60 * ga).toInt(), 120, 110, 255), Color.argb(0, 20, 40, 120)),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
                c.drawCircle(cx, cy, gr, p)
                p.shader = null
            }

            drawTentacles(c)

            if (t >= IMPACT) drawLogo(c, w, h, cx, cy)

            c.restore()

            // glitch strips
            if ((t in 1.55f..1.72f) || (t in 2.88f..3.02f)) {
                for (i in 0 until 7) {
                    val y = rnd.nextFloat() * h
                    val gh = (2f + rnd.nextFloat() * 10f) * d
                    val ox = (rnd.nextFloat() - 0.5f) * 40f * d
                    p.color = if (i % 2 == 0) Color.argb(110, 0, 255, 230) else Color.argb(110, 255, 40, 180)
                    c.drawRect(ox, y, w + ox, y + gh, p)
                }
            }

            // impact flash
            if (t in IMPACT..(IMPACT + 0.4f)) c.drawColor(Color.argb((235 * (1f - (t - IMPACT) / 0.4f)).toInt(), 255, 255, 255))

            // scanlines + vignette for the film look
            p.color = Color.argb(20, 0, 0, 0)
            var y = 0f
            while (y < h) { c.drawRect(0f, y, w, y + d, p); y += 3f * d }
            p.shader = RadialGradient(cx, h / 2f, hypot(w, h) * 0.6f,
                intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(150, 0, 0, 0)), floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
            p.shader = null

            drawTerminal(c, h)

            // letterbox bars open up after the impact
            val bar = h * 0.10f * (1f - ease((t - 3.5f) / 0.7f))
            if (bar > 0f) {
                p.color = Color.BLACK
                c.drawRect(0f, 0f, w, bar, p)
                c.drawRect(0f, h - bar, w, h, p)
            }

            // fade in from black
            if (t < 0.5f) c.drawColor(Color.argb((255 * (1f - t / 0.5f)).toInt(), 0, 0, 0))
        }

        private fun drawRain(c: Canvas, w: Float, h: Float, cx: Float, cy: Float) {
            val impacted = t >= IMPACT
            val fade = ease(t / 0.9f)
            val pull = if (t in 2.4f..IMPACT) ease((t - 2.4f) / 0.7f) else 0f
            val gap = 15f * d
            tp.textSize = 12f * d
            tp.textAlign = Paint.Align.CENTER
            val grabbing = t > 0.9f && t < IMPACT
            for (i in 0 until COLS) {
                val x0 = (i + 0.5f) / COLS * w
                val headY = (((t * colSp[i] + colOff[i]) % 1f) * 1.3f - 0.15f) * h
                for (k in 0 until TRAIL) {
                    var x = x0
                    var y = headY - k * gap
                    if (y < -gap || y > h + gap) continue
                    var a = (1f - k / TRAIL.toFloat())
                    a *= a
                    var col = if (k == 0) Color.rgb(220, 255, 240) else Color.rgb(70, 255, 185)
                    if (grabbing) {
                        for (j in 0 until NT) {
                            if (reachA[j] < 0.3f) continue
                            val dd = hypot(x - tipX[j], y - tipY[j])
                            if (dd < 80f * d) {
                                col = Color.rgb(255, 70, 200)
                                a = max(a, 0.9f)
                                x += sin(t * 60f + k) * 3f * d
                                y += cos(t * 50f + i) * 3f * d
                                break
                            }
                        }
                    }
                    if (pull > 0f) { x += (cx - x) * pull; y += (cy - y) * pull; a *= (1f - 0.6f * pull) }
                    val total = if (impacted) 0.16f * a else fade * a * 0.85f
                    if (total <= 0.01f) continue
                    tp.color = Color.argb((255 * total).toInt(), Color.red(col), Color.green(col), Color.blue(col))
                    val ch = CODE[(i * 31 + k * 17 + (t * (if (k == 0) 14f else 3f)).toInt()) % CODE.size]
                    c.drawText(ch.toString(), x, y, tp)
                }
            }
        }

        private fun drawTentacles(c: Canvas) {
            val calm = ease((t - IMPACT) / 0.5f)
            val vein = mix(Color.rgb(255, 60, 200), Color.rgb(60, 255, 210), calm)
            val body = mix(Color.rgb(22, 6, 34), Color.rgb(4, 34, 42), calm)
            p.strokeCap = Paint.Cap.ROUND
            p.style = Paint.Style.STROKE
            for (i in 0 until NT) {
                val tn = tents[i]
                val al = min(1f, reachA[i] * 1.6f) * (1f - 0.35f * calm)
                if (al <= 0.01f) continue
                val base = i * (NS + 1)
                // glow, body, glowing vein
                for (pass in 0..2) {
                    for (s in 0 until NS) {
                        val f = s / NS.toFloat()
                        val wd = (tn.thick * d * (1f - 0.85f * f) + 1.5f * d)
                        when (pass) {
                            0 -> { p.color = Color.argb((70 * al).toInt(), Color.red(vein), Color.green(vein), Color.blue(vein)); p.strokeWidth = wd * 2.3f }
                            1 -> { p.color = Color.argb((255 * al).toInt(), Color.red(body), Color.green(body), Color.blue(body)); p.strokeWidth = wd }
                            else -> { p.color = Color.argb((170 * al).toInt(), Color.red(vein), Color.green(vein), Color.blue(vein)); p.strokeWidth = max(1.2f * d, wd * 0.14f) }
                        }
                        c.drawLine(gx[base + s], gy[base + s], gx[base + s + 1], gy[base + s + 1], p)
                    }
                }
                // suckers
                p.style = Paint.Style.FILL
                var s = 4
                while (s < NS - 1) {
                    val f = s / NS.toFloat()
                    p.color = Color.argb((130 * al).toInt(), Color.red(vein), Color.green(vein), Color.blue(vein))
                    c.drawCircle(gx[base + s], gy[base + s], (tn.thick * 0.16f * (1f - f) + 1.2f) * d, p)
                    s += 3
                }
                // glowing tip
                p.color = Color.argb((230 * al).toInt(), 255, 255, 255)
                c.drawCircle(tipX[i], tipY[i], 2.6f * d, p)
                p.shader = RadialGradient(tipX[i], tipY[i], 16f * d,
                    intArrayOf(Color.argb((200 * al).toInt(), Color.red(vein), Color.green(vein), Color.blue(vein)), Color.argb(0, Color.red(vein), Color.green(vein), Color.blue(vein))),
                    null, Shader.TileMode.CLAMP)
                c.drawCircle(tipX[i], tipY[i], 16f * d, p)
                p.shader = null
                p.style = Paint.Style.STROKE
            }
            p.style = Paint.Style.FILL
        }

        private fun drawLogo(c: Canvas, w: Float, h: Float, cx: Float, cy: Float) {
            val lt = t - IMPACT
            val ga = ease(lt / 0.6f)

            // shockwave
            if (lt < 1.3f) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = (3f + 6f * (1f - lt / 1.3f)) * d
                p.color = Color.argb((200 * (1f - lt / 1.3f)).toInt(), 190, 255, 245)
                c.drawCircle(cx, cy, lt * w * 0.9f, p)
                p.style = Paint.Style.FILL
            }

            // two tilted orbit rings
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * d
            for (r in 0..1) {
                c.save()
                c.rotate(if (r == 0) t * 40f else -t * 30f + 60f, cx, cy)
                rect.set(cx - 125f * d, cy - 46f * d, cx + 125f * d, cy + 46f * d)
                p.color = Color.argb((120 * ga).toInt(), 120, 255, 230)
                c.drawOval(rect, p)
                c.restore()
            }
            p.style = Paint.Style.FILL

            // logo pops out
            val k = back(lt / 0.8f)
            val s = (150f * d * k).toInt()
            if (s > 0) {
                logo.alpha = (255 * ease(lt / 0.3f)).toInt()
                logo.setBounds((cx - s / 2f).toInt(), (cy - s / 2f).toInt(), (cx + s / 2f).toInt(), (cy + s / 2f).toInt())
                logo.draw(c)
            }

            // anamorphic lens flare
            val fa = ga * (0.55f + 0.45f * sin(t * 5f))
            p.shader = LinearGradient(0f, cy, w, cy,
                intArrayOf(Color.argb(0, 140, 255, 240), Color.argb((230 * fa).toInt(), 200, 255, 250), Color.argb(0, 140, 255, 240)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, cy - 1.5f * d, w, cy + 1.5f * d, p)
            p.shader = null

            // spark burst
            if (lt < 1.6f) {
                for (i in spAng.indices) {
                    val dist = spSpd[i] * d * lt * (1f - lt * 0.25f)
                    val a = 1f - lt / 1.6f
                    p.color = if (i % 3 == 0) Color.argb((255 * a).toInt(), 255, 255, 255)
                    else if (i % 3 == 1) Color.argb((255 * a).toInt(), 90, 255, 225)
                    else Color.argb((255 * a).toInt(), 255, 110, 210)
                    c.drawCircle(cx + cos(spAng[i]) * dist, cy + sin(spAng[i]) * dist, spSz[i] * d * a, p)
                }
            }
        }

        private fun drawTerminal(c: Canvas, h: Float) {
            tp.textAlign = Paint.Align.LEFT
            tp.textSize = 11.5f * d
            var row = 0
            for (idx in LINES.indices) {
                val st = LINES[idx].first
                if (t < st) break
                val txt = LINES[idx].second
                val n = min(txt.length, ((t - st) * 38f).toInt())
                val warn = idx == 1 || idx == 2
                val ok = idx == 4
                tp.color = if (warn) Color.argb(235, 255, 90, 190) else if (ok) Color.argb(240, 150, 255, 200) else Color.argb(215, 90, 255, 215)
                val shown = txt.substring(0, n) + (if (n < txt.length && ((t * 6f).toInt() % 2 == 0)) "_" else "")
                c.drawText(shown, 16f * d, h * 0.10f + 26f * d + row * 17f * d, tp)
                row++
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val base = Color.parseColor("#07061A")
        window.setBackgroundDrawable(ColorDrawable(base))
        try { window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = base } catch (e: Exception) {}

        val root = FrameLayout(this)
        val scene = Scene(this)
        root.addView(scene, FrameLayout.LayoutParams(-1, -1))

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; alpha = 0f; translationY = dp(20).toFloat() }
        texts.addView(TextView(this).apply {
            text = "ANJOO AI"; textSize = 34f; setTextColor(Color.WHITE); letterSpacing = 0.22f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setShadowLayer(dp(16).toFloat(), 0f, 0f, Color.parseColor("#8838E8D0"))
        })
        texts.addView(TextView(this).apply {
            text = "Talk. Chat. Create. Code."; textSize = 14f; setTextColor(Color.parseColor("#A9E8DE")); letterSpacing = 0.1f
            setPadding(0, dp(8), 0, 0)
        })
        val top = (resources.displayMetrics.heightPixels * 0.40f + dp(112)).toInt()
        root.addView(texts, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = top })

        setContentView(root)
        texts.animate().alpha(1f).translationY(0f).setDuration(800).setStartDelay(3700).start()

        val started = System.nanoTime()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 60000
            interpolator = LinearInterpolator()
            addUpdateListener { scene.t = (System.nanoTime() - started) / 1e9f; scene.invalidate() }
            start()
        }
        ui.postDelayed({ openApp() }, 6000)
        root.setOnClickListener { openApp() }
    }

    private fun openApp() {
        if (opened) return
        opened = true
        val i = Intent(this, MainActivity::class.java)
        intent?.extras?.let { i.putExtras(it) }
        startActivity(i)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        anim?.cancel()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
