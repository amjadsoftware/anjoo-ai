package com.anjoo.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/** Thin rounded outline icons (camera, photo, file) drawn in code, in the clean style used by Claude. */
class LineIcon(ctx: Context, private val kind: Int, color: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; this.color = color
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val s = min(width, height) / 24f
        c.save()
        c.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        c.scale(s, s)
        p.strokeWidth = 1.7f
        when (kind) {
            0 -> { // camera
                r.set(3f, 7f, 21f, 20f); c.drawRoundRect(r, 3.2f, 3.2f, p)
                val t = Path().apply { moveTo(8.2f, 7f); lineTo(9.6f, 4.6f); lineTo(14.4f, 4.6f); lineTo(15.8f, 7f) }
                c.drawPath(t, p)
                c.drawCircle(12f, 13.5f, 3.4f, p)
            }
            1 -> { // photo
                r.set(3f, 4f, 21f, 20f); c.drawRoundRect(r, 3.2f, 3.2f, p)
                c.drawCircle(8.6f, 9.4f, 1.7f, p)
                val m = Path().apply { moveTo(3.4f, 17f); lineTo(9f, 12.2f); lineTo(13f, 15.8f); lineTo(16f, 13.4f); lineTo(20.6f, 17.6f) }
                c.drawPath(m, p)
            }
            else -> { // file
                val d = Path().apply {
                    moveTo(13.5f, 3.5f); lineTo(6.8f, 3.5f); quadTo(5f, 3.5f, 5f, 5.3f); lineTo(5f, 18.7f)
                    quadTo(5f, 20.5f, 6.8f, 20.5f); lineTo(17.2f, 20.5f); quadTo(19f, 20.5f, 19f, 18.7f)
                    lineTo(19f, 9f); close()
                }
                c.drawPath(d, p)
                val f = Path().apply { moveTo(13.5f, 3.5f); lineTo(13.5f, 7.4f); quadTo(13.5f, 9f, 15.1f, 9f); lineTo(19f, 9f) }
                c.drawPath(f, p)
                c.drawLine(8.6f, 13.4f, 15.4f, 13.4f, p)
                c.drawLine(8.6f, 16.8f, 13.2f, 16.8f, p)
            }
        }
        c.restore()
    }
}
