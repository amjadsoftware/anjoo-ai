package com.anjoo.assistant

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.method.LinkMovementMethod
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.URLSpan
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Turns an AI reply written in Markdown into clean native views (headings, lists, code blocks with Copy, links). */
object Md {

    private val INLINE = Regex("\\*\\*(.+?)\\*\\*|`([^`\\n]+)`|\\[([^\\]\\n]+)\\]\\((https?://[^)\\s]+)\\)|(?<![*\\w])\\*([^*\\n]+)\\*(?!\\w)|__(.+?)__")

    fun inline(src: String, th: CyberTheme): CharSequence {
        val sb = SpannableStringBuilder()
        var pos = 0
        for (m in INLINE.findAll(src)) {
            if (m.range.first > pos) sb.append(src.substring(pos, m.range.first))
            val start = sb.length
            val g = m.groupValues
            when {
                g[1].isNotEmpty() -> { sb.append(g[1]); sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                g[6].isNotEmpty() -> { sb.append(g[6]); sb.setSpan(StyleSpan(Typeface.BOLD), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
                g[2].isNotEmpty() -> {
                    sb.append(g[2])
                    sb.setSpan(TypefaceSpan("monospace"), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(BackgroundColorSpan(Color.argb(48, 128, 128, 128)), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(RelativeSizeSpan(0.92f), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                g[3].isNotEmpty() -> {
                    sb.append(g[3])
                    sb.setSpan(URLSpan(g[4]), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb.setSpan(ForegroundColorSpan(th.accent), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                g[5].isNotEmpty() -> { sb.append(g[5]); sb.setSpan(StyleSpan(Typeface.ITALIC), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
            }
            pos = m.range.last + 1
        }
        if (pos < src.length) sb.append(src.substring(pos))
        return sb
    }

    private fun copy(ctx: Context, t: String) {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Anjoo", t))
        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show()
    }

    /** Set by the chat screen: called with the selected text when the user taps "Reply" in the selection bar. */
    var onReply: ((String) -> Unit)? = null

    private fun text(ctx: Context, th: CyberTheme, s: CharSequence, size: Float = 16.5f): TextView = TextView(ctx).apply {
        this.text = s
        textSize = size
        setTextColor(th.ink)
        typeface = Typeface.SERIF
        setLineSpacing(0f, 1.45f)
        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        setTextIsSelectable(true)
        movementMethod = LinkMovementMethod.getInstance()
        setLinkTextColor(th.accent)
        customSelectionActionModeCallback = object : android.view.ActionMode.Callback {
            override fun onCreateActionMode(mode: android.view.ActionMode, menu: android.view.Menu): Boolean {
                if (onReply != null) menu.add(0, 7001, 0, "Reply").setShowAsAction(android.view.MenuItem.SHOW_AS_ACTION_ALWAYS)
                return true
            }
            override fun onPrepareActionMode(mode: android.view.ActionMode, menu: android.view.Menu) = false
            override fun onActionItemClicked(mode: android.view.ActionMode, item: android.view.MenuItem): Boolean {
                if (item.itemId != 7001) return false
                val tv = this@apply
                val a = tv.selectionStart.coerceAtLeast(0); val b = tv.selectionEnd.coerceAtLeast(0)
                val sel = tv.text.subSequence(minOf(a, b), maxOf(a, b)).toString().trim()
                mode.finish()
                if (sel.isNotEmpty()) onReply?.invoke(sel)
                return true
            }
            override fun onDestroyActionMode(mode: android.view.ActionMode) {}
        }
    }

    /** Builds the views for one reply. */
    fun render(ctx: Context, raw: String, th: CyberTheme): LinearLayout {
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        fun add(v: View, top: Int = 6) {
            root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
        }

        val lines = raw.replace("\r", "").split("\n")
        var i = 0
        val para = StringBuilder()
        fun flush() {
            if (para.isNotBlank()) add(text(ctx, th, inline(para.toString().trim(), th)), 10)
            para.setLength(0)
        }
        while (i < lines.size) {
            val ln = lines[i]
            val t = ln.trim()
            if (t.startsWith("```")) {
                flush()
                val lang = t.removePrefix("```").trim()
                val code = StringBuilder()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) { code.append(lines[i]).append("\n"); i++ }
                val body = code.toString().trimEnd()
                val l = lang.lowercase()
                val previewable = l == "html" || l == "htm" || l == "svg"
                val prose = l in PROSE_LANGS
                val page = if (l == "svg") "<html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head><body style=\"margin:0;display:flex;align-items:center;justify-content:center;min-height:100vh;background:#fff\">" + body + "</body></html>" else body
                val box = LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    background = GradientDrawable().apply { setColor(0xFF1F1E1D.toInt()); cornerRadius = dp(12).toFloat(); setStroke(dp(1) / 2 + 1, Color.argb(60, 128, 128, 128)) }
                }
                val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(8), dp(2), dp(4), 0) }
                var outViewForPython: TextView? = null
                fun act(label: String, f: () -> Unit) = TextView(ctx).apply {
                    this.text = label; textSize = 12f; setTextColor(th.accent)
                    setPadding(dp(8), dp(8), dp(8), dp(8)); setOnClickListener { f() }
                }
                val hs = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
                val pane = CodePane(ctx, 12.5f)
                pane.set(body, l)
                pane.view.setPadding(0, dp(2), 0, dp(10))
                hs.addView(pane.view)
                val nLines = body.count { it == '\n' } + 1
                val holder = FrameLayout(ctx).apply { visibility = View.GONE }
                var wv: WebView? = null
                val tCode = act("Code") {}
                val tPrev = act("Preview") {}
                fun showCode() {
                    hs.visibility = View.VISIBLE; holder.visibility = View.GONE
                    tCode.setTypeface(null, Typeface.BOLD); tPrev.setTypeface(null, Typeface.NORMAL)
                }
                fun showPreview() {
                    if (wv == null) {
                        val w = WebView(ctx)
                        w.settings.javaScriptEnabled = true
                        w.settings.domStorageEnabled = true
                        w.setBackgroundColor(Color.WHITE)
                        w.setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
                        w.loadDataWithBaseURL("https://preview.local/", page, "text/html", "UTF-8", null)
                        holder.addView(w, FrameLayout.LayoutParams(-1, -1))
                        wv = w
                    }
                    hs.visibility = View.GONE; holder.visibility = View.VISIBLE
                    tPrev.setTypeface(null, Typeface.BOLD); tCode.setTypeface(null, Typeface.NORMAL)
                }
                if (previewable) {
                    tCode.setOnClickListener { showCode() }
                    tPrev.setOnClickListener { showPreview() }
                    head.addView(tCode); head.addView(tPrev)
                } else {
                    head.addView(TextView(ctx).apply {
                        this.text = (if (l == "prompt") "Prompt" else if (prose) "Text" else lang.ifEmpty { "code" }); textSize = 12f; setTextColor(0xFFA3A199.toInt())
                        setPadding(dp(10), dp(8), dp(8), dp(8))
                    })
                }
                head.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f))
                if (previewable) head.addView(act("Full screen") {
                    try {
                        val f = java.io.File(java.io.File(ctx.filesDir, "studio").also { it.mkdirs() }, "snippet-" + (System.currentTimeMillis() / 1000) + ".html")
                        f.writeText(page, Charsets.UTF_8)
                        Studio.open(ctx, f)
                    } catch (e: Exception) {}
                })
                if (l == "python" || l == "py") {
                    val out = TextView(ctx).apply {
                        textSize = 12f; setTextColor(th.ink); typeface = Typeface.MONOSPACE; setTextIsSelectable(true)
                        setPadding(dp(12), dp(6), dp(12), dp(10)); visibility = View.GONE
                    }
                    val runBtn = act("\u25B6 Run") {}
                    runBtn.setOnClickListener {
                        if (runBtn.tag == "busy") return@setOnClickListener
                        runBtn.tag = "busy"
                        out.visibility = View.VISIBLE
                        out.text = "Python chal raha hai... (pehli baar runtime download hota hai, internet chahiye)"
                        Thread {
                            val dd = java.io.File(ctx.cacheDir, "pychat-" + System.currentTimeMillis())
                            val res = try {
                                dd.mkdirs()
                                java.io.File(dd, "main.py").writeText(body, Charsets.UTF_8)
                                PyRun.run(ctx, dd, "main.py", false, 70000, 40000)
                            } catch (e: Exception) { null } finally { try { dd.deleteRecursively() } catch (e: Exception) {} }
                            val sb = StringBuilder()
                            when {
                                res == null || !res.loaded -> sb.append("Runtime load nahi hua. Internet check karein.")
                                !res.finished -> sb.append("Program waqt par khatam nahi hua (endless loop ya input ka intezar?).")
                                else -> {
                                    if (res.out.isNotBlank()) sb.append(res.out.trim().take(4000))
                                    if (res.err.isNotBlank()) sb.append(if (sb.isEmpty()) "" else "\n\n").append("\u26A0\uFE0F ").append(res.err.trim().takeLast(2000))
                                    if (sb.isEmpty()) sb.append("\u2705 Chal gaya (kuch print nahi hua).")
                                }
                            }
                            out.post { out.text = sb.toString(); runBtn.tag = null }
                        }.start()
                    }
                    head.addView(runBtn)
                    outViewForPython = out
                }
                head.addView(act("Studio") {
                    try { Coder.open(ctx, Coder.snippetProject(ctx, l, body)) } catch (e: Exception) {}
                })
                head.addView(act(if (l == "prompt") "Copy prompt" else "Copy") { copy(ctx, body) })
                box.addView(head)
                if (prose) {
                    box.addView(TextView(ctx).apply {
                        this.text = body; textSize = 14.5f; setTextColor(th.ink); setLineSpacing(0f, 1.3f)
                        textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                        setTextIsSelectable(true); setPadding(dp(12), dp(4), dp(12), dp(12))
                    }, LinearLayout.LayoutParams(-1, -2))
                } else box.addView(hs)
                outViewForPython?.let { box.addView(it) }
                outViewForPython = null
                box.addView(holder, LinearLayout.LayoutParams(-1, dp(380)))
                if (previewable) showCode()
                add(box, 8)
                i++
                continue
            }
            val h = Regex("^(#{1,4})\\s+(.*)$").find(t)
            if (h != null) {
                flush()
                val lvl = h.groupValues[1].length
                val tv = text(ctx, th, inline(h.groupValues[2], th), if (lvl == 1) 20f else if (lvl == 2) 18f else 16.5f)
                tv.setTypeface(tv.typeface, Typeface.BOLD)
                add(tv, 18)
                i++
                continue
            }
            val bullet = Regex("^([-*•+])\\s+(.*)$").find(t)
            val num = Regex("^(\\d{1,3})[.)]\\s+(.*)$").find(t)
            if (bullet != null || num != null) {
                flush()
                val indent = ln.length - ln.trimStart().length
                val marker = if (bullet != null) "•" else num!!.groupValues[1] + "."
                val body = if (bullet != null) bullet.groupValues[2] else num!!.groupValues[2]
                val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(text(ctx, th, marker).apply { setTextColor(th.muted) }, LinearLayout.LayoutParams(dp(24), -2))
                row.addView(text(ctx, th, inline(body, th)), LinearLayout.LayoutParams(0, -2, 1f))
                root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5); marginStart = dp(4 + minOf(indent, 8) * 4) })
                i++
                continue
            }
            if (t.startsWith(">")) {
                flush()
                val q = text(ctx, th, inline(t.removePrefix(">").trim(), th), 15f).apply { setTextColor(th.muted); setPadding(dp(12), dp(2), 0, dp(2)) }
                val wrap = LinearLayout(ctx).apply {
                    background = GradientDrawable().apply { setColor(Color.TRANSPARENT); setStroke(0, Color.TRANSPARENT) }
                }
                wrap.addView(View(ctx).apply { setBackgroundColor(Color.argb(90, 128, 128, 128)) }, LinearLayout.LayoutParams(dp(2), -1))
                wrap.addView(q, LinearLayout.LayoutParams(0, -2, 1f))
                add(wrap, 6)
                i++
                continue
            }
            if (t.startsWith("|") && t.endsWith("|")) {
                flush()
                val tbl = StringBuilder()
                while (i < lines.size && lines[i].trim().startsWith("|")) {
                    val row = lines[i].trim()
                    if (!Regex("^\\|[\\s:|-]+\\|$").matches(row)) tbl.append(row.trim('|').split("|").joinToString("  |  ") { it.trim() }).append("\n")
                    i++
                }
                val hs = HorizontalScrollView(ctx)
                hs.addView(TextView(ctx).apply {
                    this.text = tbl.toString().trimEnd(); typeface = Typeface.MONOSPACE; textSize = 12.5f; setTextColor(th.ink)
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    background = GradientDrawable().apply { setColor(Color.argb(60, 128, 128, 128)); cornerRadius = dp(8).toFloat() }
                })
                add(hs, 8)
                continue
            }
            if (Regex("^(-{3,}|\\*{3,}|_{3,})$").matches(t)) {
                flush()
                add(View(ctx).apply { setBackgroundColor(Color.argb(60, 128, 128, 128)) }.also {
                    it.layoutParams = LinearLayout.LayoutParams(-1, dp(1))
                }, 10)
                i++
                continue
            }
            if (t.isEmpty()) { flush(); i++; continue }
            if (para.isNotEmpty()) para.append("\n")
            para.append(ln.trimEnd())
            i++
        }
        flush()
        if (root.childCount == 0) add(text(ctx, th, raw))
        return root
    }

    private val PROSE_LANGS = setOf("prompt", "text", "txt", "md", "markdown")

    /** The fenced blocks of a reply as (language, text), in order. */
    fun blocks(raw: String): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        val lines = raw.replace("\r", "").split("\n")
        var i = 0
        while (i < lines.size) {
            val t = lines[i].trim()
            if (t.startsWith("```")) {
                val lang = t.removePrefix("```").trim().lowercase()
                val sb = StringBuilder()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) { sb.append(lines[i]).append("\n"); i++ }
                out.add(Pair(lang, sb.toString().trimEnd()))
            }
            i++
        }
        return out
    }

    /** Plain text for copying/sharing/speaking: markdown marks removed. */
    fun plain(raw: String): String = raw.replace(Regex("```[a-zA-Z0-9+#-]*\\n?"), "")
        .replace(Regex("\\*\\*|__|`"), "").replace(Regex("(?m)^#{1,4}\\s+"), "").trim()
}
