package com.anjoo.assistant

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Makes pictures with the best engine the user has a key for (OpenAI, Gemini, xAI, FLUX) and edits them with Gemini. Pictures are stored in the app and shown inside the chat. */
object ImageGen {

    /** Base64 JPEG of the photo the user attached to the current message (for "edit this"). */
    @Volatile var input: String? = null

    /** More photos attached to the same message, sent as extra references when editing/combining. */
    @Volatile var extra: List<String> = emptyList()

    /** When the chat screen is running a request it collects the new picture names here. */
    @Volatile var sink: MutableList<String>? = null

    @Volatile var lastFile: File? = null

    private val MODELS = listOf("gemini-3-pro-image-preview", "gemini-2.5-flash-image", "gemini-2.0-flash-preview-image-generation")

    fun dir(ctx: Context) = File(ctx.filesDir, "images").also { it.mkdirs() }

    fun file(ctx: Context, name: String) = File(dir(ctx), name.replace("/", "").replace("..", ""))

    /** The prompt a saved picture was made from (used by the "Another version" button). */
    fun promptOf(ctx: Context, name: String): String = try { File(dir(ctx), name.replace("/", "").replace("..", "") + ".txt").readText() } catch (e: Exception) { "" }

    private class Fail(val code: Int, msg: String) : Exception(msg)

    private fun call(key: String, model: String, prompt: String, src: String?, aspect: String?): Pair<String, String> {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (src != null) parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", src)))
        if (src != null) for (e in extra.take(3)) parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", e)))
        val gc = JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE"))
        if (aspect != null && src == null) gc.put("imageConfig", JSONObject().put("aspectRatio", aspect))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", gc)
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 150000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val txt = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt.take(160) }
            throw Fail(code, msg)
        }
        val j = JSONObject(txt)
        val ps = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        var said = ""
        if (ps != null) for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            val inl = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
            if (inl != null && inl.optString("data").isNotEmpty()) return Pair(inl.getString("data"), inl.optString("mimeType", inl.optString("mime_type", "image/png")))
            if (p.has("text")) said += p.getString("text")
        }
        val why = j.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
        throw Fail(0, (said.ifBlank { "No picture came back." } + " " + why).trim())
    }

    // ---------- other picture makers (used when the user has their key) ----------

    private fun http(url: String, headers: Map<String, String>, body: String): Pair<Int, ByteArray> {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 170000
        c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        for ((k, v) in headers) c.setRequestProperty(k, v)
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val bytes = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes() } ?: ByteArray(0)
        return Pair(code, bytes)
    }

    private fun errMsg(b: ByteArray): String {
        val t = String(b, Charsets.UTF_8)
        return try {
            val e = JSONObject(t).opt("error")
            if (e is JSONObject) e.optString("message") else (e?.toString() ?: t.take(160))
        } catch (x: Exception) { t.take(160) }
    }

    private fun mimeOf(b: ByteArray) = if (b.size > 2 && b[0] == 0xFF.toByte() && b[1] == 0xD8.toByte()) "image/jpeg" else "image/png"

    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)

    /** OpenAI-style images API (OpenAI gpt-image-1, xAI grok-2-image): returns base64 or a link. */
    private fun callImagesApi(url: String, key: String, body: JSONObject): Pair<String, String> {
        val (code, b) = http(url, mapOf("Authorization" to "Bearer $key"), body.toString())
        if (code !in 200..299) throw Fail(code, errMsg(b))
        val d = JSONObject(String(b, Charsets.UTF_8)).optJSONArray("data")?.optJSONObject(0) ?: throw Fail(0, "No picture came back.")
        val inline = d.optString("b64_json")
        if (inline.isNotEmpty()) return Pair(inline, "image/png")
        val link = d.optString("url")
        if (link.isNotEmpty()) {
            val u = URL(link)
            if ((u.protocol != "https" && u.protocol != "http") || Web.isPrivateHost(u.host)) throw Fail(0, "Picture link safe nahi.")
            val c = u.openConnection() as HttpURLConnection
            c.connectTimeout = 20000; c.readTimeout = 60000
            val bytes = c.inputStream.use { it.readBytes() }
            return Pair(b64(bytes), mimeOf(bytes))
        }
        throw Fail(0, "No picture came back.")
    }

    private fun callHuggingFace(key: String, prompt: String): Pair<String, String> {
        val body = JSONObject().put("inputs", prompt).toString()
        val (code, b) = http("https://router.huggingface.co/hf-inference/models/black-forest-labs/FLUX.1-dev", mapOf("Authorization" to "Bearer $key", "Accept" to "image/png"), body)
        if (code !in 200..299) throw Fail(code, errMsg(b))
        if (b.size < 1000) throw Fail(0, "No picture came back.")
        return Pair(b64(b), mimeOf(b))
    }

    private fun callCloudflare(key: String, prompt: String): Pair<String, String> {
        val i = key.indexOf(':').let { if (it > 0) it else key.indexOf('|') }
        if (i <= 0 || i >= key.length - 1) throw Fail(401, "Cloudflare key ACCOUNT_ID:API_TOKEN format mein honi chahiye.")
        val acct = key.substring(0, i).trim()
        val (code, b) = http("https://api.cloudflare.com/client/v4/accounts/$acct/ai/run/@cf/black-forest-labs/flux-1-schnell", mapOf("Authorization" to "Bearer " + key.substring(i + 1).trim()), JSONObject().put("prompt", prompt).put("steps", 8).toString())
        if (code !in 200..299) throw Fail(code, errMsg(b))
        val img = JSONObject(String(b, Charsets.UTF_8)).optJSONObject("result")?.optString("image") ?: ""
        if (img.isEmpty()) throw Fail(0, "No picture came back.")
        return Pair(img, "image/jpeg")
    }

    private fun callOpenRouterImage(key: String, prompt: String): Pair<String, String> {
        val body = JSONObject().put("model", "google/gemini-2.5-flash-image")
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            .put("modalities", JSONArray().put("image").put("text"))
        val (code, b) = http("https://openrouter.ai/api/v1/chat/completions", mapOf("Authorization" to "Bearer $key"), body.toString())
        if (code !in 200..299) throw Fail(code, errMsg(b))
        val url = JSONObject(String(b, Charsets.UTF_8)).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")
            ?.optJSONArray("images")?.optJSONObject(0)?.optJSONObject("image_url")?.optString("url") ?: ""
        val i = url.indexOf("base64,")
        if (!url.startsWith("data:") || i < 0) throw Fail(0, "No picture came back.")
        return Pair(url.substring(i + 7), url.substring(5, url.indexOf(';').coerceAtLeast(5)).ifEmpty { "image/png" })
    }

    private fun callNvidia(key: String, prompt: String): Pair<String, String> {
        val body = JSONObject().put("prompt", prompt).put("width", 1024).put("height", 1024).put("steps", 4).put("seed", 0)
        val (code, b) = http("https://ai.api.nvidia.com/v1/genai/black-forest-labs/flux.1-schnell", mapOf("Authorization" to "Bearer $key", "Accept" to "application/json"), body.toString())
        if (code !in 200..299) throw Fail(code, errMsg(b))
        val img = JSONObject(String(b, Charsets.UTF_8)).optJSONArray("artifacts")?.optJSONObject(0)?.optString("base64") ?: ""
        if (img.isEmpty()) throw Fail(0, "No picture came back.")
        return Pair(img, "image/jpeg")
    }

    /** Free, no key. Only the picture description is sent to this service. Last resort. */
    private fun callPollinations(prompt: String, size: String): Pair<String, String> {
        val (w, h) = when (size) { "1536x1024" -> Pair(1344, 896); "1024x1536" -> Pair(896, 1344); else -> Pair(1024, 1024) }
        val u = "https://image.pollinations.ai/prompt/" + java.net.URLEncoder.encode(prompt.take(900), "UTF-8").replace("+", "%20") +
            "?width=$w&height=$h&model=flux&nologo=true&seed=" + (System.nanoTime() % 1000000)
        val c = URL(u).openConnection() as HttpURLConnection
        c.connectTimeout = 20000; c.readTimeout = 150000
        c.setRequestProperty("User-Agent", "AnjooAI")
        val code = c.responseCode
        val bytes = (if (code in 200..299) c.inputStream else c.errorStream)?.use { it.readBytes() } ?: ByteArray(0)
        if (code !in 200..299 || bytes.size < 2000) throw Fail(code, "Pollinations ne picture nahi di.")
        return Pair(b64(bytes), mimeOf(bytes))
    }

    /** One line for the chat prompt: which picture makers work right now, so the assistant never guesses. */
    fun summary(ctx: Context): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        Providers.load(p)
        val on = ArrayList<String>()
        if (Providers.allKeys(p, "openai").isNotEmpty()) on.add("OpenAI gpt-image-1")
        if (Providers.geminiKey(p).isNotEmpty()) on.add("Google Gemini image (picture edit bhi)")
        if (Providers.allKeys(p, "xai").isNotEmpty()) on.add("xAI grok-2-image")
        if (Providers.allKeys(p, "openrouter").isNotEmpty()) on.add("OpenRouter (Gemini image)")
        if (Providers.allKeys(p, "nvidia").isNotEmpty()) on.add("NVIDIA FLUX")
        if (Providers.allKeys(p, "huggingface").isNotEmpty()) on.add("Hugging Face FLUX")
        if (Providers.allKeys(p, "cloudflare").isNotEmpty()) on.add("Cloudflare FLUX")
        if (p.getBoolean("freeImages", true)) on.add("Pollinations (free, bina key)")
        return "PICTURE MAKERS (generate_image inhe khud chunta hai, best pehle, nakam ho to agla): " + on.joinToString(", ") +
            ". Kabhi mat kaho ke sirf OpenAI ya Gemini se picture banti hai; bas generate_image chalao.\n"
    }

    private class Eng(val label: String, val id: String, val keys: List<String>, val run: (String) -> Pair<String, String>)

    /**
     * Creates (or, with [edit], changes) a picture. Returns the saved file name. Throws with a readable message.
     * Every company the user has a key for is tried, best quality first: OpenAI gpt-image-1, Gemini Pro image, xAI,
     * Gemini Flash image, FLUX on Hugging Face, FLUX on Cloudflare. [engine] (e.g. "openai", "gemini", "flux") picks one.
     * Editing a photo is done by Gemini.
     */
    fun make(ctx: Context, prompt: String, edit: Boolean, aspect: String?, engine: String? = null): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        Providers.load(p)
        var src: String? = null
        if (edit) {
            src = input
            if (src == null) {
                val f = lastFile
                if (f != null && f.exists()) {
                    try {
                        val bmp = android.graphics.BitmapFactory.decodeFile(f.absolutePath)
                        if (bmp != null) {
                            val bo = java.io.ByteArrayOutputStream()
                            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, bo)
                            src = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
                        }
                    } catch (e: Exception) {}
                }
            }
        }
        val useAspect = aspect?.takeIf { it in listOf("1:1", "16:9", "9:16", "4:3", "3:4") }
        val size = when (useAspect) { "16:9", "4:3" -> "1536x1024"; "9:16", "3:4" -> "1024x1536"; "1:1" -> "1024x1024"; else -> "auto" }
        val gemKey = Providers.geminiKey(p)
        val first = (p.getString("imageModel", "") ?: "").trim()
        val gemModels = (listOf(first).filter { it.isNotEmpty() } + MODELS).distinct()
        val engines = ArrayList<Eng>()
        fun gemini(m: String) {
            if (gemKey.isEmpty()) return
            engines.add(Eng("Gemini $m", "gemini", listOf(gemKey)) { k ->
                try { call(k, m, prompt, src, useAspect) } catch (e: Fail) { if (e.code == 400 && useAspect != null) call(k, m, prompt, src, null) else throw e }
            })
        }
        if (src == null) {
            val ok = Providers.allKeys(p, "openai")
            if (ok.isNotEmpty()) engines.add(Eng("OpenAI gpt-image-1", "openai", ok) { k ->
                callImagesApi("https://api.openai.com/v1/images/generations", k, JSONObject().put("model", "gpt-image-1").put("prompt", prompt).put("size", size).put("quality", "high").put("n", 1))
            })
        }
        gemModels.firstOrNull { it.contains("pro") }?.let { gemini(it) }
        if (src == null) {
            val xk = Providers.allKeys(p, "xai")
            if (xk.isNotEmpty()) engines.add(Eng("xAI grok-2-image", "xai", xk) { k ->
                callImagesApi("https://api.x.ai/v1/images/generations", k, JSONObject().put("model", "grok-2-image").put("prompt", prompt).put("response_format", "b64_json"))
            })
        }
        if (src == null) {
            val ork = Providers.allKeys(p, "openrouter")
            if (ork.isNotEmpty()) engines.add(Eng("OpenRouter Gemini image", "openrouter", ork) { k -> callOpenRouterImage(k, prompt) })
        }
        for (m in gemModels) if (!m.contains("pro")) gemini(m)
        if (src == null) {
            val nk = Providers.allKeys(p, "nvidia")
            if (nk.isNotEmpty()) engines.add(Eng("FLUX (NVIDIA)", "nvidia", nk) { k -> callNvidia(k, prompt) })
            val hk = Providers.allKeys(p, "huggingface")
            if (hk.isNotEmpty()) engines.add(Eng("FLUX (Hugging Face)", "huggingface", hk) { k -> callHuggingFace(k, prompt) })
            val ck = Providers.allKeys(p, "cloudflare")
            if (ck.isNotEmpty()) engines.add(Eng("FLUX (Cloudflare)", "cloudflare", ck) { k -> callCloudflare(k, prompt) })
            if (p.getBoolean("freeImages", true)) engines.add(Eng("Pollinations (free)", "pollinations", listOf("-")) { _ -> callPollinations(prompt, size) })
        }
        val want = engine?.trim()?.lowercase(java.util.Locale.ROOT).orEmpty()
        val use = if (want.isEmpty()) engines else engines.filter { it.id == want || it.label.lowercase(java.util.Locale.ROOT).contains(want) || (want == "flux" && it.label.contains("FLUX")) }
        if (use.isEmpty()) {
            throw IllegalStateException(
                if (want.isNotEmpty() && engines.isNotEmpty()) "'$want' se picture nahi ban sakti (key nahi ya edit ke liye nahi). Chal sakte: " + engines.joinToString(", ") { it.id }
                else if (edit && gemKey.isEmpty()) "Photo edit karne ke liye Google Gemini ki key chahiye (Settings > Keys)."
                else "Picture banane ke liye OpenAI, Gemini, xAI, OpenRouter, NVIDIA, Hugging Face ya Cloudflare mein se kisi ki key add karo (Menu > Keys)."
            )
        }
        val errors = ArrayList<String>()
        var quota = false
        for (e in use) {
            keys@ for (k in e.keys) {
                var tries = 0
                while (true) {
                    try {
                        Cancel.check()
                        val (data, mime) = e.run(k)
                        val ext = if (mime.contains("jpeg") || mime.contains("jpg")) "jpg" else "png"
                        val f = File(dir(ctx), "img_" + System.currentTimeMillis() + "." + ext)
                        f.writeBytes(Base64.decode(data, Base64.DEFAULT))
                        try { File(f.parentFile, f.name + ".txt").writeText(prompt.take(2000)) } catch (e2: Exception) {}
                        lastFile = f
                        Router.noteUsed(e.label, e.id, Task.CHAT)
                        // keep the storage small: remove the oldest pictures beyond 120 (with their prompt notes)
                        dir(ctx).listFiles { x -> !x.name.endsWith(".txt") }?.sortedBy { it.lastModified() }?.let { all ->
                            if (all.size > 120) all.take(all.size - 120).forEach { it.delete(); File(it.parentFile, it.name + ".txt").delete() }
                        }
                        return f.name
                    } catch (x: Fail) {
                        if ((x.code == 500 || x.code == 502 || x.code == 503) && tries++ < 1) { Thread.sleep(1500); continue }
                        if (x.code == 429) quota = true
                        errors.add(e.label + ": " + x.message)
                        if (x.code == 401 || x.code == 402 || x.code == 403 || x.code == 429) continue@keys
                        break@keys
                    } catch (x: CancelledException) {
                        throw x
                    } catch (x: java.io.IOException) {
                        errors.add(e.label + ": " + (x.message ?: x.javaClass.simpleName))
                        break@keys
                    }
                }
            }
        }
        throw IllegalStateException(
            (if (quota) "Kuch companies ki image limit khatam hai. " else "") + errors.take(3).joinToString(" | ").ifEmpty { "Could not make the picture." }
        )
    }

    /** A short idea becomes a detailed picture prompt (subject, style, light, camera, composition). Falls back to the original. */
    private fun enrich(ctx: Context, prompt: String): String {
        if (prompt.length > 450) return prompt
        return try {
            val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
            Providers.load(p)
            val key = p.getString("key", "") ?: ""
            if (key.isEmpty()) return prompt
            val model = p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
            val sys = "You write prompts for image-generation models. Rewrite the user's idea as ONE rich English prompt of at most 110 words: subject and action, setting, style or medium, lighting, camera/lens or perspective, composition, colour palette, mood, and 'highly detailed, sharp focus, professional quality'. Keep every detail the user gave. Any text that must appear inside the picture stays exactly as given, in quotes. Output only the prompt."
            val out = Gemini.plain(key, model, sys, JSONArray().put(JSONObject().put("text", prompt)), 400, 0.7, false)
            if (out.length in 40..1500) out else prompt
        } catch (e: CancelledException) { throw e } catch (e: Exception) { prompt }
    }

    /** The tool entry point (chat and voice). n = how many versions (1 to 3, made at the same time). */
    fun tool(ctx: Context, a: JSONObject): String {
        val prompt0 = a.optString("prompt").trim()
        if (prompt0.isEmpty()) return "Koi description nahi mili."
        val edit = a.optBoolean("edit", false)
        val prompt = if (edit) prompt0 else enrich(ctx, prompt0)
        val aspect = a.optString("aspect", "").ifBlank { null }
        val n = a.optInt("n", 1).coerceIn(1, 3)
        val engine = a.optString("engine", "").ifBlank { null }
        val names = java.util.Collections.synchronizedList(ArrayList<String>())
        val errors = java.util.Collections.synchronizedList(ArrayList<String>())
        val jobs = (0 until n).map {
            Thread {
                try { names.add(make(ctx, prompt, edit, aspect, engine)) } catch (e: Exception) { errors.add(e.message ?: e.javaClass.simpleName) }
            }.also { t -> t.start() }
        }
        jobs.forEach { try { it.join() } catch (e: InterruptedException) {} }
        if (names.isEmpty()) return "Picture nahi ban saki: " + (errors.firstOrNull() ?: "unknown error")
        val s = sink
        for (name in names) {
            if (s != null) synchronized(s) { s.add(name) } else ChatStore.append(ctx, 1, "[[img:$name]]")
        }
        val partial = if (names.size < n) " (sirf ${names.size} ban saki)" else ""
        return "Picture ban gayi$partial aur chat mein user ko dikha di gayi. Bas ek chhota jumla kaho; picture ka link ya file ka zikr mat karo."
    }
}
