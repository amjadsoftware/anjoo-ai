package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Local-first dashboard to inspect, edit, import, search and delete personal memory and knowledge. */
class MemoryActivity : Activity() {
    private lateinit var theme: CyberTheme
    private lateinit var root: LinearLayout
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var memoryTab: TextView
    private lateinit var knowledgeTab: TextView
    private var section = 0 // 0 memories, 1 knowledge

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun faint() = Color.argb(70, 128, 128, 128)
    private fun shape(fill: Int, stroke: Int = faint(), radius: Int = 14) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(radius).toFloat()
    }
    private fun label(text: String, size: Float = 14f, color: Int = theme.ink, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        Touch.feedback(window.decorView, ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        theme = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        Style.bars(window, theme)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(theme.bg)
            setPadding(dp(14), dp(28), dp(14), dp(10))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("‹", 30f).apply { setPadding(dp(6), 0, dp(18), dp(4)); setOnClickListener { finish() } })
        header.addView(label("Memory & Knowledge", 20f, theme.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(action("⋮", false) { menu() })
        root.addView(header)

        status = label("Private on this device", 11.5f, theme.muted)
        status.setPadding(dp(8), dp(6), dp(8), dp(10))
        root.addView(status)

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = shape(theme.surface, faint(), 20); setPadding(dp(4), dp(4), dp(4), dp(4)) }
        memoryTab = tab("🧠  Memories") { setSection(0) }
        knowledgeTab = tab("📚  Knowledge") { setSection(1) }
        tabs.addView(memoryTab, LinearLayout.LayoutParams(0, dp(42), 1f))
        tabs.addView(knowledgeTab, LinearLayout.LayoutParams(0, dp(42), 1f))
        root.addView(tabs)

        search = EditText(this).apply {
            hint = "Search memories"; setHintTextColor(theme.muted); setTextColor(theme.ink); textSize = 14f
            background = shape(theme.surface, faint(), 18); setPadding(dp(14), dp(10), dp(14), dp(10))
            maxLines = 1; isSingleLine = true; inputType = InputType.TYPE_CLASS_TEXT
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { refresh() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val semanticRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        semanticRow.addView(action("AI Semantic Search", false) { semanticSearch() }, LinearLayout.LayoutParams(0, dp(36), 1f).apply { marginEnd = dp(4) })
        semanticRow.addView(action("Build AI Index", false) { buildSemanticIndex() }, LinearLayout.LayoutParams(0, dp(36), 1f).apply { marginStart = dp(4) })
        root.addView(semanticRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })

        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(9), 0, dp(8)) }
        controls.addView(action("+ Add memory", true) { editMemory(null) }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
        controls.addView(action("+ Add text", false) { addKnowledgeDialog() }, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
        root.addView(controls)

        val importRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        importRow.addView(action("Import document / PDF / image", false) { importFile() }, LinearLayout.LayoutParams(0, dp(38), 1f))
        importRow.addView(action("Backup", false) { backupMenu() }, LinearLayout.LayoutParams(dp(95), dp(38)).apply { marginStart = dp(8) })
        root.addView(importRow)

        val toggles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(theme.surface, faint(), 14); setPadding(dp(12), dp(6), dp(12), dp(6)) }
        val save = Switch(this).apply {
            text = "Save Memory"; textSize = 13f; setTextColor(theme.ink); isChecked = prefs.getBoolean("saveMemory", true)
            buttonTintList = android.content.res.ColorStateList.valueOf(theme.accent)
            setOnCheckedChangeListener { _, value -> prefs.edit().putBoolean("saveMemory", value).apply() }
        }
        val auto = Switch(this).apply {
            text = "Auto Memory"; textSize = 13f; setTextColor(theme.ink); isChecked = prefs.getBoolean("autoMemory", true)
            buttonTintList = android.content.res.ColorStateList.valueOf(theme.accent)
            setOnCheckedChangeListener { _, value -> prefs.edit().putBoolean("autoMemory", value).apply() }
            isEnabled = prefs.getBoolean("saveMemory", true)
        }
        save.setOnCheckedChangeListener { _, value ->
            prefs.edit().putBoolean("saveMemory", value).apply()
            auto.isEnabled = value
        }
        val include = Switch(this).apply {
            text = "Use Knowledge in AI answers"; textSize = 13f; setTextColor(theme.ink); isChecked = prefs.getBoolean("knowledgeContext", false)
            buttonTintList = android.content.res.ColorStateList.valueOf(theme.accent)
        }
        include.setOnCheckedChangeListener { _, value ->
            if (value) {
                AlertDialog.Builder(this).setTitle("Allow Knowledge in AI answers?")
                    .setMessage("Privacy notice: when this is enabled, relevant excerpts from your locally stored documents and your question are included in requests sent to the chat AI provider configured in this app. Your entire local library is not sent automatically; only a small number of matching excerpts are added when relevant. Turn this off any time to keep Knowledge out of chat requests.")
                    .setPositiveButton("I agree · Enable") { _, _ -> prefs.edit().putBoolean("knowledgeContext", true).apply() }
                    .setNegativeButton("Cancel") { _, _ -> include.isChecked = false }
                    .setOnCancelListener { include.isChecked = false }.show()
            } else prefs.edit().putBoolean("knowledgeContext", false).apply()
        }
        val semantic = Switch(this).apply {
            text = "AI Semantic Search (Google Gemini)"; textSize = 13f; setTextColor(theme.ink)
            isChecked = prefs.getBoolean("semanticKnowledge", false)
            buttonTintList = android.content.res.ColorStateList.valueOf(theme.accent)
        }
        semantic.setOnCheckedChangeListener { _, value ->
            if (value) {
                AlertDialog.Builder(this).setTitle("Enable AI Semantic Search?")
                    .setMessage("Privacy notice: your Knowledge document text is sent to Google's Gemini Embedding API to create searchable vectors. Your search queries are also sent to Google when AI semantic search is used in chat or tools. Google API usage may incur charges or quotas. Original files remain on this phone. Enable only if you agree.")
                    .setPositiveButton("I agree · Enable") { _, _ ->
                        prefs.edit().putBoolean("semanticKnowledge", true).apply()
                        status.text = "AI semantic index building…"
                        KnowledgeEmbeddings.scheduleAll(this)
                    }.setNegativeButton("Cancel") { _, _ -> semantic.isChecked = false }
                    .setOnCancelListener { semantic.isChecked = false }.show()
            } else {
                prefs.edit().putBoolean("semanticKnowledge", false).apply()
                KnowledgeEmbeddings.clearQueryCache()
            }
        }
        toggles.addView(save); toggles.addView(auto); toggles.addView(include); toggles.addView(semantic)
        root.addView(toggles, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isFillViewport = true; addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(10) })
        setContentView(root)
        setSection(intent.getStringExtra("section")?.let { if (it == "knowledge") 1 else 0 } ?: 0)
        if (intent.getBooleanExtra("open_import", false)) root.post { importFile() }
    }

    override fun onResume() {
        super.onResume(); refresh()
        if (KnowledgeEmbeddings.enabled(this)) KnowledgeEmbeddings.scheduleAll(this)
    }

    private fun tab(text: String, click: () -> Unit) = label(text, 13f, theme.muted, true).apply {
        gravity = Gravity.CENTER; setOnClickListener { click() }
    }

    private fun action(text: String, primary: Boolean, click: () -> Unit) = label(text, 12.5f,
        if (primary) theme.bg else theme.ink, true).apply {
        gravity = Gravity.CENTER; setPadding(dp(8), dp(7), dp(8), dp(7))
        background = shape(if (primary) theme.accent else theme.surface, if (primary) theme.accent else faint(), 18)
        setOnClickListener { click() }
    }

    private fun setSection(value: Int) {
        section = value.coerceIn(0, 1)
        memoryTab.setTextColor(if (section == 0) theme.ink else theme.muted)
        memoryTab.background = if (section == 0) shape(theme.bg, faint(), 16) else null
        knowledgeTab.setTextColor(if (section == 1) theme.ink else theme.muted)
        knowledgeTab.background = if (section == 1) shape(theme.bg, faint(), 16) else null
        search.hint = if (section == 0) "Search memories" else "Search documents and knowledge"
        refresh()
    }

    private fun refresh() {
        if (!::list.isInitialized || !::search.isInitialized) return
        list.removeAllViews()
        val q = search.text.toString()
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        val memCount = LongMemory.all(this).size
        val docStats = KnowledgeBase.stats(this)
        status.text = "$memCount memories  ·  ${docStats.optInt("documents")} knowledge docs  ·  ${docStats.optInt("semantic_indexed_chunks")}/${docStats.optInt("semantic_total_chunks")} AI vectors  ·  ${ChatStore.all(this).length()} chats"
        // Context capture follows the master Save Memory switch; Knowledge has its own prompt toggle.
        if (section == 0) {
            val items = LongMemory.search(this, q)
            if (items.isEmpty()) {
                empty(if (q.isBlank()) "No saved memories yet. Add one, or enable Auto Memory." else "No matching memories.")
                return
            }
            for (item in items) list.addView(memoryCard(item), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        } else {
            val docs = if (q.isBlank()) KnowledgeBase.list(this) else KnowledgeBase.search(this, q, 100).map { it.doc }.distinctBy { it.id }
            if (docs.isEmpty()) {
                empty(if (q.isBlank()) "Knowledge base is empty. Import a document or add text." else "No matching documents. Try a different query.")
                return
            }
            for (doc in docs) list.addView(knowledgeCard(doc), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
    }

    private fun empty(text: String) {
        list.addView(label(text, 14f, theme.muted).apply { setPadding(dp(8), dp(28), dp(8), dp(22)) })
    }

    private fun memoryCard(m: MemItem) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = shape(theme.surface); setPadding(dp(13), dp(11), dp(13), dp(11))
        val kind = mapOf("pref" to "PREFERENCE", "task" to "TASK", "person" to "PERSON", "fact" to "FACT")[m.kind] ?: "FACT"
        addView(label((if (m.pinned) "📌  " else "") + kind + (if (m.done) "  · DONE" else ""), 10.5f, theme.accent, true))
        addView(label(m.text, 14f, theme.ink).apply { setPadding(0, dp(5), 0, dp(4)) })
        addView(label("Updated ${date(m.updated)}  ·  Used ${m.hits} times  ·  ID ${m.id}", 10.5f, theme.muted))
        setOnClickListener { editMemory(m) }
        setOnLongClickListener { memoryMenu(m); true }
    }

    private fun knowledgeCard(d: KnowledgeDoc) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; background = shape(theme.surface); setPadding(dp(13), dp(11), dp(13), dp(11))
        addView(label((if (d.pinned) "📌  " else "📚  ") + d.title, 15f, theme.ink, true))
        addView(label(d.source.ifBlank { "Local document" }, 11f, theme.muted).apply { setPadding(0, dp(4), 0, 0) })
        addView(label("${d.chars} characters  ·  ${d.chunks} searchable chunks  ·  ${date(d.updated)}", 10.5f, theme.muted).apply { setPadding(0, dp(4), 0, 0) })
        setOnClickListener { readKnowledge(d) }
        setOnLongClickListener { knowledgeMenu(d); true }
    }

    private fun date(ms: Long) = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.ENGLISH).format(Date(ms))

    private fun editMemory(item: MemItem?) {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        val kind = Spinner(this).apply {
            adapter = ArrayAdapter(this@MemoryActivity, android.R.layout.simple_spinner_dropdown_item, listOf("Preference", "Task", "Person", "Fact"))
            setSelection(listOf("pref", "task", "person", "fact").indexOf(item?.kind ?: "fact").coerceAtLeast(0))
        }
        val text = EditText(this).apply {
            hint = "What should Anjoo remember?"; setText(item?.text ?: ""); minLines = 3; gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        val pin = Switch(this).apply { text = "Pin this memory"; setTextColor(theme.ink); isChecked = item?.pinned ?: false }
        wrap.addView(kind); wrap.addView(text); wrap.addView(pin)
        AlertDialog.Builder(this).setTitle(if (item == null) "Add memory" else "Edit memory").setView(wrap)
            .setPositiveButton("Save") { _, _ ->
                val key = listOf("pref", "task", "person", "fact")[kind.selectedItemPosition]
                val result = if (item == null) LongMemory.add(this, key, text.text.toString(), pin.isChecked)
                    else LongMemory.update(this, item.id, key, text.text.toString())
                if (item != null) LongMemory.pin(this, item.id, pin.isChecked)
                Toast.makeText(this, result, Toast.LENGTH_SHORT).show(); refresh()
            }.setNeutralButton(if (item == null) "Cancel" else "Delete") { _, _ ->
                if (item != null) confirm("Delete this saved memory? It will be removed from future AI context.") {
                    LongMemory.deleteId(this, item.id); refresh()
                }
            }.setNegativeButton("Cancel", null).show()
    }

    private fun memoryMenu(m: MemItem) {
        val options = arrayOf("Edit", if (m.pinned) "Unpin" else "Pin", if (m.kind == "task" && !m.done) "Mark completed" else "Status", "Delete")
        AlertDialog.Builder(this).setTitle("Memory ${m.id}").setItems(options) { _, which ->
            when (which) {
                0 -> editMemory(m)
                1 -> { LongMemory.pin(this, m.id, !m.pinned); refresh() }
                2 -> if (m.kind == "task" && !m.done) { LongMemory.complete(this, m.text); refresh() }
                3 -> confirm("Delete this memory permanently?") { LongMemory.deleteId(this, m.id); refresh() }
            }
        }.show()
    }

    private fun addKnowledgeDialog() {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
        val title = EditText(this).apply { hint = "Title"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
        val content = EditText(this).apply {
            hint = "Paste text, reference notes, instructions or information"; minLines = 7; gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        wrap.addView(title); wrap.addView(content)
        AlertDialog.Builder(this).setTitle("Add to Knowledge Base").setView(wrap)
            .setPositiveButton("Save") { _, _ ->
                val titleText = title.text.toString()
                val txt = content.text.toString()
                Thread {
                    val msg = try {
                        val r = KnowledgeBase.addText(this, titleText, "Manual entry", "text/plain", txt)
                        if (KnowledgeEmbeddings.enabled(this)) KnowledgeEmbeddings.scheduleDocument(this, r.id)
                        "Saved ${r.chunks} searchable chunks${if (r.redactions > 0) " · ${r.redactions} sensitive values redacted" else ""}."
                    } catch (e: Exception) { "Could not save: ${e.message}" }
                    runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); setSection(1) }
                }.start()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun importFile() {
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*")
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivityForResult(i, 410)
        } catch (e: Exception) { Toast.makeText(this, "File picker open nahi hua: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    @Deprecated("Legacy result API retained for compatibility with minSdk and existing activities")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val uri = data.data!!
        if (requestCode == 411) {
            Thread {
                val msg = try {
                    val json = JSONObject().put("app", "AnjooAI-memory").put("version", 1).put("at", System.currentTimeMillis())
                        .put("memories", LongMemory.exportArray(this)).put("deletedMemories", LongMemory.exportDeletedArray(this)).put("knowledge", KnowledgeBase.exportArray(this)).toString()
                    contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                    "Memory & Knowledge export saved."
                } catch (e: Exception) { "Export failed: ${e.message}" }
                runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
            }.start()
            return
        }
        if (requestCode == 412) {
            Thread {
                val msg = try {
                    val raw = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                        ?: throw IllegalArgumentException("File read nahi hui.")
                    require(raw.length <= 50_000_000) { "Backup file 50 MB se bari hai." }
                    val json = JSONObject(raw)
                    require(json.optString("app") == "AnjooAI-memory") { "Yeh Anjoo Memory & Knowledge export nahi hai." }
                    val m = json.optJSONArray("memories") ?: org.json.JSONArray()
                    val k = json.optJSONArray("knowledge") ?: org.json.JSONArray()
                    LongMemory.merge(this, m, json.optJSONArray("deletedMemories") ?: org.json.JSONArray())
                    val n = KnowledgeBase.merge(this, k)
                    if (KnowledgeEmbeddings.enabled(this)) KnowledgeEmbeddings.scheduleAll(this)
                    "Merged ${m.length()} memories and $n knowledge documents. Newer edits were kept."
                } catch (e: Exception) { "Import failed: ${e.message}" }
                runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); refresh() }
            }.start()
            return
        }
        if (requestCode != 410) return
        val name = KnowledgeImporter.displayName(this, uri)
        if (KnowledgeImporter.requiresRemoteOcr(name)) {
            AlertDialog.Builder(this).setTitle("Allow AI OCR for this file?")
                .setMessage("This PDF/image needs OCR. Its rendered pages or image will be sent to the AI vision provider configured in Anjoo AI (Google Gemini is used when a Gemini key is configured; otherwise the main AI provider may be used) to transcribe text. PDF import processes up to 50 pages. Provider usage may count against quota or billing. Original selected file is not changed. Continue only if you agree.")
                .setPositiveButton("I agree · Import") { _, _ -> importKnowledgeUri(uri) }
                .setNegativeButton("Cancel", null).show()
        } else importKnowledgeUri(uri)
    }

    private fun importKnowledgeUri(uri: android.net.Uri) {
        status.text = "Importing ${KnowledgeImporter.displayName(this, uri)}…"
        Thread {
            val msg = try {
                val file = KnowledgeImporter.extract(this, uri)
                val r = KnowledgeBase.addText(this, file.title, file.source, file.mime, file.text)
                if (KnowledgeEmbeddings.enabled(this)) KnowledgeEmbeddings.scheduleDocument(this, r.id)
                "${r.title}: ${r.chars} characters, ${r.chunks} chunks saved" +
                    (if (r.duplicate) " (existing document refreshed)" else "") +
                    (if (r.redactions > 0) " · ${r.redactions} credential/payment values redacted" else "")
            } catch (e: Exception) { "Import failed: ${e.message ?: e.javaClass.simpleName}" }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); setSection(1); refresh() }
        }.start()
    }

    private fun readKnowledge(doc: KnowledgeDoc) {
        Thread {
            val text = KnowledgeBase.read(this, doc.id, 0, 12000) ?: "Document content unavailable."
            runOnUiThread {
                val body = TextView(this).apply {
                    this.text = text; textSize = 13f; setTextColor(theme.ink); setPadding(dp(18), dp(10), dp(18), dp(10))
                    textIsSelectable = true
                }
                AlertDialog.Builder(this).setTitle(doc.title).setView(ScrollView(this).apply { addView(body) })
                    .setPositiveButton("Close", null).setNeutralButton("Copy") { _, _ ->
                        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                        cm.setPrimaryClip(android.content.ClipData.newPlainText(doc.title, text))
                        Toast.makeText(this, "Copied first retrieved section", Toast.LENGTH_SHORT).show()
                    }.show()
            }
        }.start()
    }

    private fun knowledgeMenu(doc: KnowledgeDoc) {
        val options = arrayOf("Read", "Edit title and text", if (doc.pinned) "Unpin" else "Pin", "Delete")
        AlertDialog.Builder(this).setTitle(doc.title).setItems(options) { _, which ->
            when (which) {
                0 -> readKnowledge(doc)
                1 -> editKnowledge(doc)
                2 -> { KnowledgeBase.pin(this, doc.id, !doc.pinned); refresh() }
                3 -> confirm("Delete this document and all of its indexed chunks?") { KnowledgeBase.delete(this, doc.id); refresh() }
            }
        }.show()
    }

    private fun editKnowledge(doc: KnowledgeDoc) {
        Thread {
            val full = KnowledgeBase.content(this, doc.id) ?: ""
            runOnUiThread {
                val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(8), dp(18), 0) }
                val title = EditText(this).apply { setText(doc.title); hint = "Title" }
                val body = EditText(this).apply {
                    setText(full); minLines = 8; gravity = Gravity.TOP or Gravity.START
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                }
                wrap.addView(title); wrap.addView(body)
                AlertDialog.Builder(this).setTitle("Edit knowledge document").setView(wrap)
                    .setPositiveButton("Save") { _, _ ->
                        val newTitle = title.text.toString()
                        val newContent = body.text.toString()
                        Thread {
                            val msg = try {
                                if (KnowledgeBase.updateText(this, doc.id, newTitle, newContent)) {
                                    if (KnowledgeEmbeddings.enabled(this)) KnowledgeEmbeddings.scheduleDocument(this, doc.id)
                                    "Knowledge document updated."
                                } else "Document no longer exists."
                            }
                                catch (e: Exception) { "Update failed: ${e.message}" }
                            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show(); refresh() }
                        }.start()
                    }.setNegativeButton("Cancel", null).show()
            }
        }.start()
    }

    private fun semanticSearch() {
        val q = search.text.toString().trim()
        if (q.isBlank()) { Toast.makeText(this, "Pehle search box mein sawal likhein.", Toast.LENGTH_SHORT).show(); return }
        if (!KnowledgeEmbeddings.enabled(this)) {
            Toast.makeText(this, "AI Semantic Search pehle enable karein. Is se query Google ko bheji jayegi.", Toast.LENGTH_LONG).show(); return
        }
        status.text = "AI semantic search running…"
        Thread {
            val result = try {
                val hits = KnowledgeEmbeddings.search(this, q, 8)
                if (hits.isEmpty()) "Semantic index mein matching chunks nahi mile. Build AI Index chalayein." else
                    hits.joinToString("\n\n") { "${it.doc.title}\n${it.doc.source}\nSimilarity ${String.format(Locale.US, "%.3f", it.score)}\n${it.snippet}" }
            } catch (e: Exception) { "Semantic search failed: ${e.message}" }
            runOnUiThread {
                status.text = KnowledgeEmbeddings.status(this)
                AlertDialog.Builder(this).setTitle("AI Semantic Search Results").setMessage(result)
                    .setPositiveButton("Close", null).show()
            }
        }.start()
    }

    private fun buildSemanticIndex() {
        if (!KnowledgeEmbeddings.enabled(this)) {
            Toast.makeText(this, "Pehle AI Semantic Search enable karein aur privacy notice accept karein.", Toast.LENGTH_LONG).show(); return
        }
        status.text = "Building semantic index…"
        Thread {
            val msg = try {
                val indexed = KnowledgeEmbeddings.indexAll(this)
                val stats = KnowledgeBase.semanticStats(this)
                "Indexed $indexed new chunks. Total ${stats.first}/${stats.second} chunks ready."
            } catch (e: Exception) { "Indexing failed: ${e.message}" }
            runOnUiThread { status.text = KnowledgeEmbeddings.status(this); Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); refresh() }
        }.start()
    }

    private fun backupMenu() {
        val opts = arrayOf("Export Memory & Knowledge JSON", "Merge from Memory & Knowledge JSON")
        AlertDialog.Builder(this).setTitle("Memory backup")
            .setMessage("Export includes saved memories and extracted knowledge text. The full Anjoo backup also includes chats, notes, settings and projects.")
            .setItems(opts) { _, which ->
                val i = if (which == 0) Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
                    .putExtra(Intent.EXTRA_TITLE, "anjoo-memory-${System.currentTimeMillis()}.json")
                else Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json")
                startActivityForResult(i, if (which == 0) 411 else 412)
            }.show()
    }

    private fun confirm(message: String, yes: () -> Unit) {
        AlertDialog.Builder(this).setMessage(message).setPositiveButton("Delete") { _, _ -> yes() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun menu() {
        val options = arrayOf("View all memories", "View all knowledge documents", "Delete all memories", "Delete all knowledge documents", "Delete AI semantic index", "Memory & Knowledge privacy")
        AlertDialog.Builder(this).setTitle("Memory tools").setItems(options) { _, i ->
            when (i) {
                0 -> { setSection(0); search.setText("") }
                1 -> { setSection(1); search.setText("") }
                2 -> confirm("Delete every saved memory? This cannot be undone.") { val n = LongMemory.clear(this); Toast.makeText(this, "$n memories deleted", Toast.LENGTH_SHORT).show(); refresh() }
                3 -> confirm("Delete all knowledge documents and indexed text? This cannot be undone.") {
                    val docs = KnowledgeBase.list(this)
                    docs.forEach { KnowledgeBase.delete(this, it.id) }
                    Toast.makeText(this, "${docs.size} documents deleted", Toast.LENGTH_SHORT).show(); refresh()
                }
                4 -> confirm("Delete every stored AI embedding vector? Original document text will stay on this phone. Semantic search results will be unavailable until you rebuild the index.") {
                    val n = KnowledgeBase.clearSemanticIndex(this)
                    Toast.makeText(this, "$n AI vectors deleted", Toast.LENGTH_SHORT).show(); refresh()
                }
                5 -> AlertDialog.Builder(this).setTitle("Privacy")
                    .setMessage("Memories and extracted documents are stored in this app's private local database/files. Relevant excerpts are sent to your selected chat AI provider only after you explicitly enable Use Knowledge in AI answers. PDF/image OCR also requires a separate confirmation before pages are sent to the configured vision provider. By default, semantic embeddings are OFF and document text stays on this phone. If you opt in to AI Semantic Search, document chunks and search queries are sent to Google's Gemini Embedding API; usage may count against your API quota or billing. Original selected files are not modified or automatically uploaded as original files; only rendered PDF pages or images are sent for OCR after separate consent. Backups may contain personal data; keep them private. Deleting a knowledge document removes its content, vectors and search chunks immediately; an empty sync tombstone remains so a newer deletion is not restored from another device.")
                    .setPositiveButton("Close", null).show()
            }
        }.show()
    }
}
