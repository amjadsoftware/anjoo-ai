package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** The conversation loop used by the background voice service. Call [ask] from a background thread. */
class Agent(ctx: Context, private val actions: Actions) {

    private val appCtx: Context = ctx

    /** True when the phone has an Urdu voice, so replies may use Urdu script. */
    var urduScriptVoice = false

    private val prefs = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    private val history = JSONArray()

    private fun systemPrompt(): String {
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", Locale.ENGLISH).format(Date())
        val notes = actions.notes()
        val sb = StringBuilder()
        sb.append("Tum \"Anjoo AI\" ho, Android phone ka awaazi assistant jo background mein chalta hai.\n")
        sb.append("User ki baat awaaz se likhi gayi hai, is liye kabhi naam ya lafz ghalat ho sakta hai. Samajhdari se andaza lagao, aur zaroorat ho to ek chhota sawal poochho.\n")
        sb.append("User ke hukm tools ke zariye poore karo: app kholna, call, SMS, WhatsApp, alarm, timer, torch, volume, music, search, rasta.\n")
        sb.append("Kaam karo, phir ek chhota jumla bolo ke kya hua. Tumhara jawab awaaz mein sunaya jayega, is liye bohat chhota, bina markdown, list ya emoji.\n")
        sb.append("Call aur SMS se pehle app khud user se awaaz mein tasdeeq le lega, tum dobara mat poochho.\n")
        if (urduScriptVoice) {
            sb.append("Jawab usi script mein do jis mein user ne baat likhi (Urdu script ya Roman Urdu ya English).\n")
        } else {
            sb.append("Hamesha Roman Urdu (English harf) mein jawab do, kyunke phone Urdu script bol nahi sakta.\n")
        }
        sb.append("Jo kaam tools se nahi ho sakta (jaise doosri app ke andar tap karna) wo saaf bata do.\n")
        sb.append("Jab user kahe \"yaad rakho\", remember tool se save karo.\n")
        sb.append(Style.officer(appCtx).persona).append("\n")
        sb.append("Abhi ka waqt: ").append(now).append(" (").append(TimeZone.getDefault().id).append(").")
        if (notes.isNotEmpty()) sb.append("\nYaad rakhi baatein:\n- ").append(notes.joinToString("\n- "))
        return sb.toString()
    }

    private fun trim() {
        while (history.length() > 30) history.remove(0)
        while (history.length() > 0) {
            val m = history.getJSONObject(0)
            val first = m.getJSONArray("parts").optJSONObject(0)
            if (m.getString("role") == "user" && first != null && first.has("text")) break
            history.remove(0)
        }
    }

    /** Sends one spoken command and returns the assistant's short reply. */
    fun ask(text: String): String {
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty()) return "Pehle app ki Settings mein Gemini key dalein."
        val model = prefs.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"

        trim()
        val start = history.length()
        history.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", text)))
        )
        var finalText = ""
        try {
            var steps = 0
            while (steps++ < 8) {
                val resp = Gemini.sendWithFallback(key, model, systemPrompt(), history)
                val cands = resp.optJSONArray("candidates")
                if (cands == null || cands.length() == 0) throw IOException("Jawab nahi mila.")
                val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                    ?: JSONArray()
                if (parts.length() > 0) {
                    history.put(JSONObject().put("role", "model").put("parts", parts))
                }

                val results = JSONArray()
                val said = StringBuilder()
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    val fc = p.optJSONObject("functionCall")
                    if (fc != null) {
                        val name = fc.getString("name")
                        val out = try {
                            actions.run(name, fc.optJSONObject("args") ?: JSONObject())
                        } catch (e: Exception) {
                            "Kaam nahi ho saka: " + (e.message ?: e.javaClass.simpleName)
                        }
                        results.put(
                            JSONObject().put(
                                "functionResponse",
                                JSONObject().put("name", name)
                                    .put("response", JSONObject().put("result", out))
                            )
                        )
                    } else if (p.has("text") && !p.optBoolean("thought", false)) {
                        said.append(p.getString("text")).append(' ')
                    }
                }
                if (said.isNotBlank()) finalText = said.toString().trim()
                if (results.length() == 0) break
                history.put(JSONObject().put("role", "user").put("parts", results))
            }
        } catch (e: Exception) {
            while (history.length() > start) history.remove(history.length() - 1)
            throw e
        }
        return finalText.replace(Regex("[*_`#]"), "")
    }
}
