# Anjoo AI v16 - UI refresh

- Reworked MainActivity home UI into a premium dark workspace.
- Added compact brand/header and connection-settings selector.
- Added four quick action cards: Write, Learn, Create, Code.
- Added dedicated conversation heading and uncluttered composer.
- Kept image picker, send action, voice toggle, existing menus/settings and conversation rendering connected to existing handlers.
- Removed the full-screen BuddyView overlay from the main interface while retaining BuddyView mood logic for existing code.
- Kept app versionCode 16 / versionName 16.0.

Build and device validation: not performed in this environment (Gradle executable unavailable).
