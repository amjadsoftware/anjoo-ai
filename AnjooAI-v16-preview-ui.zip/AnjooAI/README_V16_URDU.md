# Anjoo AI v16

V16 mein existing Android project ke main screen ko approved premium preview ke qareeb redesign kiya gaya hai:

- Dark, compact header with Anjoo AI branding and settings shortcut
- AI connection/model settings shortcut (sirf configured backend ko use karta hai)
- Write, Learn, Create aur Code quick-action cards
- Separate Conversation area
- Rounded message composer with image, send, and voice controls
- Full-screen BuddyView overlay removed from the main screen so it no longer covers the interface
- Existing chat, settings, tools, image picker, voice service and phone-action code retained

## Build status

This is the Android Studio source project, not a prebuilt APK. The current environment did not have Gradle available, so compilation and physical-device testing could not be verified. Please open the project in Android Studio and run a Gradle sync/build before installing.
