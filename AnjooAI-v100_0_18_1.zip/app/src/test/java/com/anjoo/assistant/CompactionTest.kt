package com.anjoo.assistant

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CompactionTest {
    private fun e(role: String, text: String) = JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))
    private fun chat(n: Int): JSONArray { val h = JSONArray(); for (i in 0 until n) h.put(e(if (i % 2 == 0) "user" else "model", "message $i")); return h }

    @Test fun shortChatNeedsNothing() { assertFalse(Compaction.needed(chat(10))) }
    @Test fun manyEntriesTrigger() { assertTrue(Compaction.needed(chat(30))) }
    @Test fun bigTextTriggers() {
        val h = chat(12); h.put(e("user", "x".repeat(60_000)))
        assertTrue(Compaction.needed(h))
    }
    @Test fun splitStartsAtUserText() {
        val h = chat(30)
        val i = Compaction.splitIndex(h)
        assertTrue(i > 0)
        assertEquals("user", h.getJSONObject(i).getString("role"))
    }
    @Test fun applyKeepsTailAndRoles() {
        val h = chat(30)
        val i = Compaction.splitIndex(h)
        Compaction.apply(h, i, "- goal: build an app")
        assertEquals("user", h.getJSONObject(0).getString("role"))
        assertEquals("model", h.getJSONObject(1).getString("role"))
        assertTrue(Compaction.existing(h).contains("goal"))
        assertEquals("message 29", Compaction.textOf(h.getJSONObject(h.length() - 1)))
    }
    @Test fun runUsesSummarizerAndFailsSafely() {
        val h = chat(30)
        assertFalse(Compaction.run(h) { _, _ -> throw RuntimeException("offline") })
        assertEquals(30, h.length())
        assertTrue(Compaction.run(h) { _, _ -> "- the user is building an app with many details" })
        assertTrue(h.length() < 30)
    }
    @Test fun secondRoundKeepsEarlierSummary() {
        val h = chat(30)
        Compaction.run(h) { _, _ -> "- first summary of the earlier talk here" }
        for (i in 0 until 20) h.put(e(if (i % 2 == 0) "user" else "model", "more $i"))
        var seenPrior = ""
        Compaction.run(h) { _, t -> seenPrior = t; "- second summary including the first one" }
        assertTrue(seenPrior.contains("first summary"))
    }
}
