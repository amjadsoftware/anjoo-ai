package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Context compaction: when a chat gets long, the oldest part of the conversation is replaced by a short summary
 * (written by the AI itself) instead of being cut off. The newest messages stay word for word.
 * The summary is saved per chat so it survives restarting the app.
 */
object Compaction {
    const val MARK = "[Summary of the earlier conversation]"
    const val MAX_CHARS = 48_000
    const val MAX_ENTRIES = 22
    const val KEEP_ENTRIES = 8
    private const val ENTRY_CAP = 1500
    private const val PREF = "anjoo"

    /** Plain text of one history entry; tool calls and results become short markers. */
    fun textOf(entry: JSONObject): String {
        val ps = entry.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until ps.length()) {
            val p = ps.optJSONObject(i) ?: continue
            when {
                p.has("text") -> sb.append(p.optString("text")).append(' ')
                p.has("functionCall") -> sb.append("[tool: ").append(p.optJSONObject("functionCall")?.optString("name") ?: "?").append("] ")
                p.has("functionResponse") -> sb.append("[tool result: ").append(p.optJSONObject("functionResponse")?.optString("name") ?: "?").append("] ")
            }
        }
        return sb.toString().trim()
    }

    fun totalChars(history: JSONArray): Int {
        var n = 0
        for (i in 0 until history.length()) n += textOf(history.getJSONObject(i)).length
        return n
    }

    fun needed(history: JSONArray): Boolean =
        history.length() > MAX_ENTRIES || (history.length() > KEEP_ENTRIES + 2 && totalChars(history) > MAX_CHARS)

    private fun isUserText(e: JSONObject): Boolean {
        if (e.optString("role") != "user") return false
        val first = e.optJSONArray("parts")?.optJSONObject(0)
        return first != null && first.has("text")
    }

    /**
     * Index where the "kept" tail starts: at least [keep] entries from the end, moved back so the tail begins with a
     * real user message (never in the middle of a tool call/result pair). Returns 0 when there is nothing to summarize.
     */
    fun splitIndex(history: JSONArray, keep: Int = KEEP_ENTRIES): Int {
        var i = history.length() - keep
        if (i <= 0) return 0
        while (i > 0 && !isUserText(history.getJSONObject(i))) i--
        return i
    }

    /** The old part as a transcript for the summarizer. */
    fun transcript(history: JSONArray, upTo: Int): String {
        val sb = StringBuilder()
        for (i in 0 until upTo) {
            val e = history.getJSONObject(i)
            val t = textOf(e)
            if (t.isEmpty()) continue
            sb.append(if (e.optString("role") == "user") "USER: " else "ANJOO: ").append(t.take(ENTRY_CAP)).append("\n\n")
        }
        return sb.toString().trim()
    }

    val SYSTEM = "You compress a long chat into a briefing for yourself. Keep every fact the conversation still needs: " +
        "the user's goals, decisions, names, numbers, file names and paths, code or settings that were chosen, what is done, " +
        "what is still open, and the user's language and tone (Roman Urdu, Urdu or English). Drop greetings, repetition and " +
        "tool noise. Write short bullet points, no more than 350 words. Output only the summary."

    fun prompt(prior: String, transcript: String): String =
        (if (prior.isNotBlank()) "EARLIER SUMMARY (keep what still matters):\n$prior\n\n" else "") +
            "CONVERSATION TO ADD TO THE SUMMARY:\n$transcript"

    fun isSummaryEntry(e: JSONObject): Boolean = isUserText(e) && textOf(e).startsWith(MARK)

    /** Existing summary text at the front of the history, or "". */
    fun existing(history: JSONArray): String {
        if (history.length() == 0) return ""
        val e = history.getJSONObject(0)
        return if (isSummaryEntry(e)) textOf(e).removePrefix(MARK).trim() else ""
    }

    /** Replaces entries [0, upTo) with one summary pair (user + model) so roles keep alternating. */
    fun apply(history: JSONArray, upTo: Int, summary: String) {
        if (upTo <= 0 || summary.isBlank()) return
        val tail = ArrayList<JSONObject>()
        for (i in upTo until history.length()) tail.add(history.getJSONObject(i))
        while (history.length() > 0) history.remove(history.length() - 1)
        history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", MARK + "\n" + summary.trim()))))
        history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", "Understood. I will continue from this summary."))))
        for (t in tail) history.put(t)
    }

    /** Runs the compaction when needed. Call off the UI thread. Returns true when the history was shortened. */
    fun run(history: JSONArray, summarize: (system: String, text: String) -> String): Boolean {
        if (!needed(history)) return false
        val upTo = splitIndex(history)
        if (upTo <= 0) return false
        val prior = existing(history)
        val summary = try { summarize(SYSTEM, prompt(prior, transcript(history, upTo))).trim() } catch (e: Exception) { "" }
        if (summary.length < 20) return false
        apply(history, upTo, summary)
        return true
    }

    fun save(ctx: Context, chatId: Long, history: JSONArray) {
        try {
            ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("compact_$chatId", existing(history)).apply()
        } catch (e: Exception) {}
    }

    fun restore(ctx: Context, chatId: Long, history: JSONArray) {
        try {
            val s = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("compact_$chatId", "") ?: ""
            if (s.isBlank() || existing(history).isNotEmpty()) return
            val tail = ArrayList<JSONObject>()
            for (i in 0 until history.length()) tail.add(history.getJSONObject(i))
            while (history.length() > 0) history.remove(history.length() - 1)
            history.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", MARK + "\n" + s))))
            history.put(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", "Understood. I will continue from this summary."))))
            for (t in tail) history.put(t)
        } catch (e: Exception) {}
    }

    fun clear(ctx: Context, chatId: Long) {
        try { ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().remove("compact_$chatId").apply() } catch (e: Exception) {}
    }
}
