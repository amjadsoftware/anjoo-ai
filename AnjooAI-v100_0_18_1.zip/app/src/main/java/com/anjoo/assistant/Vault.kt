package com.anjoo.assistant

import android.content.Context
import android.os.Environment
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * The permanent "Anjoo AI" folder on the phone's internal storage (/storage/emulated/0/Anjoo AI).
 *
 * Why it survives uninstall: it lives in shared storage, not in the app's own data (Android/data or filesDir),
 * and Android never deletes shared folders when an app is removed. After a reinstall the same folder is simply
 * used again (nothing new is created) and [restore] brings everything back.
 * It needs "All files access" (the same switch the Storage screen already offers). Without it the app keeps
 * working as before and nothing here runs.
 *
 *   Chats/Auto-saved        one .json per chat (used to restore)
 *   Chats/Readable          one .txt per chat (for you to read)
 *   Chats/Attachments       files attached in chats (used to restore)
 *   Chats/Exports           chats exported as PDF / Word / text
 *   Documents/PDF|Word|Excel|Other   files Anjoo makes for you
 *   Projects                Code Studio projects (+ "From chat", "Older pages")
 *   Images/Created          pictures Anjoo made
 *   Notes                   notes.json (restore) and notes.txt (readable)
 *   Artifacts               saved artifacts and docs
 *   App Backups             full ZIP backups (settings, chats, projects, images), newest 7 kept
 *   Key Backups             API keys, ENCRYPTED with your passphrase, newest 5 kept
 *   Downloads               other files
 *
 * Nothing is ever deleted from this folder by the sync: it only adds and updates.
 */
object Vault {
    const val NAME = "Anjoo AI"
    private const val KEEP_BACKUPS = 7
    private const val KEEP_KEYS = 5

    private val TREE = listOf(
        "Chats/Auto-saved", "Chats/Readable", "Chats/Attachments", "Chats/Exports",
        "Documents/PDF", "Documents/Word", "Documents/Excel", "Documents/Other",
        "Projects", "Images/Created", "Images/Saved", "Notes", "Artifacts", "App Backups", "Key Backups", "Downloads"
    )

    fun root(): File = File(Environment.getExternalStorageDirectory(), NAME)

    /** True when the app may write into shared storage ("All files access"). */
    fun ready(ctx: Context): Boolean = FileAccess.allFiles(ctx)

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    // ------------------------------------------------------------------ folder

    fun hasRecoveryKey(): Boolean = File(File(root(), "Key Backups"), Crypt.WRAP_FILE).isFile

    /** Saves a copy of the data key locked with [pass] so the folder can be opened again after a reinstall. */
    @Synchronized fun saveRecovery(ctx: Context, pass: CharArray): String {
        if (pass.size < 6) return "Make the passphrase at least 6 characters."
        if (!ensure(ctx)) return "The Anjoo AI folder is not ready: turn on 'All files access'."
        val w = Crypt.wrapForPassphrase(ctx, pass) ?: return "Encryption is not working on this phone."
        return try {
            File(File(root(), "Key Backups"), Crypt.WRAP_FILE).writeText(w)
            "Recovery passphrase set. Remember it: without it the encrypted files cannot be opened after reinstalling."
        } catch (e: Exception) { "Could not save: " + (e.message ?: e.javaClass.simpleName) }
    }

    /** Older versions stored plain files here: encrypt them once (Documents, Downloads, Exports, Saved images and Key Backups stay as they are). */
    private fun encryptOld(ctx: Context) {
        val p = prefs(ctx)
        if (p.getBoolean("vaultEncDone", false) || !Sandbox.on(ctx) || !Crypt.available(ctx)) return
        val r = root()
        var failed = 0
        for (f in r.walkTopDown()) {
            if (!f.isFile || f.name == ".anjoo-vault.json" || f.name == "README.txt") continue
            val rel = f.relativeTo(r).path.split(File.separatorChar)
            if (rel.first() == "Key Backups") continue
            if (!Sandbox.encrypts(listOf(NAME) + rel.dropLast(1))) continue
            try {
                val head = ByteArray(7)
                val n = f.inputStream().use { it.read(head) }
                if (n == 7 && Crypt.isEnc(head)) continue
                val tmp = File(f.parentFile, f.name + ".enc-tmp")
                val t = f.lastModified()
                if (Crypt.encryptFile(ctx, f, tmp) && tmp.renameTo(f)) f.setLastModified(t) else { tmp.delete(); failed++ }
            } catch (e: Exception) { failed++ }
        }
        if (failed == 0) p.edit().putBoolean("vaultEncDone", true).apply()
    }

    /** Creates the folders that are missing (never a second copy of the ones that exist). */
    @Synchronized fun ensure(ctx: Context): Boolean {
        Sandbox.on(ctx)
        if (!ready(ctx)) return false
        return try {
            val r = root()
            r.mkdirs()
            for (t in TREE) File(r, t).mkdirs()
            val mark = File(r, ".anjoo-vault.json")
            if (!mark.exists()) mark.writeText(JSONObject().put("app", "AnjooAI").put("vault", 1).put("created", System.currentTimeMillis()).toString())
            val readme = File(r, "README.txt")
            if (!readme.exists()) readme.writeText(
                "Anjoo AI folder\n\n" +
                "This folder keeps your Anjoo AI data on the phone. It stays when the app is uninstalled.\n" +
                "After you install Anjoo AI again and switch on 'All files access', Anjoo finds this folder and offers to restore everything.\n\n" +
                "Chats: auto-saved chats (and a readable copy)\nDocuments: PDF, Word, Excel and other files Anjoo made\nProjects: Code Studio projects\n" +
                "Images: pictures Anjoo made\nNotes: your notes\nArtifacts: saved artifacts\nApp Backups: full backups (ZIP)\n" +
                "Key Backups: API keys, encrypted with your passphrase. Without the passphrase they cannot be opened.\n\n" +
                "Everything here (chats, projects, notes, images, backups) is stored ENCRYPTED. Only Documents, Downloads, Chats/Exports and Images/Saved hold normal files you can open in other apps.\n\n" +
                "Do not rename or delete the folder names above; Anjoo looks for them by name.\n")
            true
        } catch (e: Exception) { false }
    }

    /** Folder (relative to internal storage) where a file Anjoo makes should go, by its type. */
    fun docFolder(name: String): String {
        val sub = when (name.substringAfterLast('.', "").lowercase(Locale.ROOT)) {
            "pdf" -> "Documents/PDF"
            "docx", "doc", "dotx" -> "Documents/Word"
            "xlsx", "xls", "csv", "tsv" -> "Documents/Excel"
            "png", "jpg", "jpeg", "webp", "gif" -> "Images/Saved"
            "zip", "apk", "tar", "gz" -> "Downloads"
            else -> "Documents/Other"
        }
        return "$NAME/$sub"
    }

    fun hasData(): Boolean = try {
        val r = root()
        r.isDirectory && (
            (File(r, "App Backups").listFiles { f -> f.name.endsWith(".zip") }?.isNotEmpty() == true) ||
            (File(r, "Chats/Auto-saved").listFiles { f -> f.name.endsWith(".json") }?.isNotEmpty() == true) ||
            (File(r, "Key Backups").listFiles { f -> f.name.endsWith(".anjookeys") }?.isNotEmpty() == true) ||
            (File(r, "Projects").walkTopDown().any { it.isFile }))
    } catch (e: Exception) { false }

    fun hasKeyBackup(): Boolean = latestKeyFile() != null
    private fun latestKeyFile(): File? = File(root(), "Key Backups").listFiles { f -> f.name.endsWith(".anjookeys") }?.maxByOrNull { it.lastModified() }
    private fun latestZip(): File? = File(root(), "App Backups").listFiles { f -> f.name.endsWith(".zip") }?.maxByOrNull { it.lastModified() }

    /** True when this looks like a fresh install: no chats, no keys and no projects inside the app yet. */
    fun looksFresh(ctx: Context): Boolean = try {
        ChatStore.all(ctx).length() == 0 && KeyFile.count(ctx) == 0 && Coder.list(ctx).isEmpty()
    } catch (e: Exception) { false }

    // ------------------------------------------------------------------ copying

    /** Copies new or changed files from [src] to [dst]. Never deletes anything. Returns how many files were copied. */
    private fun mirror(ctx: Context, src: File, dst: File, skipTop: Set<String> = emptySet(), toFolder: Boolean): Int {
        if (!src.isDirectory) return 0
        var n = 0
        for (f in src.walkTopDown()) {
            if (!f.isFile) continue
            val rel = f.relativeTo(src)
            if (rel.path.substringBefore(File.separatorChar) in skipTop) continue
            val out = File(dst, rel.path)
            try {
                if (out.exists() && out.lastModified() >= f.lastModified()) continue
                out.parentFile?.mkdirs()
                val ok = if (toFolder) Crypt.encryptFile(ctx, f, out) else Crypt.decryptFile(ctx, f, out)
                if (!ok) continue
                out.setLastModified(f.lastModified())
                n++
            } catch (e: Exception) { /* one unreadable file never stops the rest */ }
        }
        return n
    }

    private fun writeIfChanged(ctx: Context, f: File, text: String) {
        try {
            if (f.exists() && Crypt.readText(ctx, f) == text) return
            Crypt.writeText(ctx, f, text)
        } catch (e: Exception) {}
    }

    private fun safeName(s: String) = s.replace(Regex("[\\\\/:*?\"<>|\\s]+"), "_").trim('_').take(40).ifEmpty { "chat" }

    // ------------------------------------------------------------------ sync (phone -> folder)

    private val worker = Executors.newSingleThreadExecutor()
    @Volatile private var lastSync = 0L
    @Volatile private var queued = false

    /** Copies chats, notes, projects, images and artifacts into the folder in the background (at most every 15 seconds). */
    fun syncSoon(ctx: Context) {
        if (!ready(ctx)) return
        val app = ctx.applicationContext
        if (queued) return
        queued = true
        val wait = maxOf(0L, 15_000L - (System.currentTimeMillis() - lastSync))
        worker.execute {
            try { if (wait > 0) Thread.sleep(wait) } catch (e: Exception) {}
            queued = false
            try { syncNow(app) } catch (e: Exception) {}
        }
    }

    @Synchronized fun syncNow(ctx: Context): String {
        if (!ensure(ctx)) return "The Anjoo AI folder is not ready: turn on 'All files access'."
        try { encryptOld(ctx) } catch (e: Exception) {}
        val r = root()
        var n = 0
        // chats: json for restore, txt for reading
        try {
            val all = ChatStore.all(ctx)
            val auto = File(r, "Chats/Auto-saved"); val read = File(r, "Chats/Readable")
            for (i in 0 until all.length()) {
                val s = all.getJSONObject(i)
                val id = s.getLong("id")
                val f = File(auto, "chat_$id.json")
                if (!f.exists() || f.lastModified() < s.optLong("last")) {
                    Crypt.writeText(ctx, f, s.toString()); f.setLastModified(maxOf(s.optLong("last"), System.currentTimeMillis())); n++
                    val name = "$id - " + safeName(ChatStore.title(s)) + ".txt"
                    read.listFiles { x -> x.name.startsWith("$id - ") && x.name != name }?.forEach { it.delete() }
                    writeIfChanged(ctx, File(read, name), ChatStore.title(s) + "\n\n" + ChatStore.transcript(ctx, id))
                }
            }
        } catch (e: Exception) {}
        // notes
        try {
            val notes = Notes.exportArray(ctx)
            writeIfChanged(ctx, File(r, "Notes/notes.json"), notes.toString())
            val sb = StringBuilder()
            for (i in 0 until notes.length()) {
                val o = notes.getJSONObject(i)
                if (o.optBoolean("deleted")) continue
                sb.append(o.optString("title")).append("\n").append(o.optString("body")).append("\n\n----\n\n")
            }
            writeIfChanged(ctx, File(r, "Notes/notes.txt"), sb.toString().trim())
        } catch (e: Exception) {}
        // folders
        val fd = ctx.filesDir
        n += mirror(ctx, File(fd, "projects"), File(r, "Projects"), toFolder = true)
        n += mirror(ctx, File(fd, "chatkeep"), File(r, "Projects/From chat"), toFolder = true)
        n += mirror(ctx, File(fd, "studio"), File(r, "Projects/Older pages"), toFolder = true)
        n += mirror(ctx, File(fd, "images"), File(r, "Images/Created"), toFolder = true)
        n += mirror(ctx, File(fd, "attach"), File(r, "Chats/Attachments"), toFolder = true)
        n += mirror(ctx, File(fd, "artifacts"), File(r, "Artifacts"), setOf("_share"), toFolder = true)
        lastSync = System.currentTimeMillis()
        prefs(ctx).edit().putLong("vaultSync", lastSync).apply()
        return "Sync done ($n new or changed files)."
    }

    // ------------------------------------------------------------------ backups

    /** Full ZIP backup (settings, chats, projects, images; no keys) into App Backups. */
    @Synchronized fun backupNow(ctx: Context): String {
        if (!ensure(ctx)) return "The Anjoo AI folder is not ready: turn on 'All files access'."
        return try {
            val dir = File(root(), "App Backups")
            val f = File(dir, "anjoo-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.ENGLISH).format(Date()) + ".zip")
            val tmp = File(ctx.cacheDir, "bk-" + System.nanoTime() + ".zip")
            val n = try { FileOutputStream(tmp).use { Backup.write(ctx, it, false) } } catch (e: Exception) { tmp.delete(); throw e }
            val sealed = try { Crypt.encryptFile(ctx, tmp, f) } finally { tmp.delete() }
            if (!sealed) { f.delete(); return "The backup could not be encrypted, so it was not saved." }
            dir.listFiles { x -> x.name.startsWith("anjoo-backup-") && x.name.endsWith(".zip") }
                ?.sortedByDescending { it.lastModified() }?.drop(KEEP_BACKUPS)?.forEach { it.delete() }
            prefs(ctx).edit().putLong("lastAutoBackup", System.currentTimeMillis()).apply()
            "Backup created: App Backups/" + f.name + " ($n files)."
        } catch (e: Exception) { "Could not create the backup: " + (e.message ?: e.javaClass.simpleName) }
    }

    private fun derive(pass: CharArray, salt: ByteArray): SecretKeySpec {
        val k = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(pass, salt, 200_000, 256)).encoded
        return SecretKeySpec(k, "AES")
    }

    /** API keys, encrypted with the passphrase (AES-256-GCM, PBKDF2). The passphrase is never stored anywhere. */
    @Synchronized fun backupKeys(ctx: Context, pass: CharArray): String {
        if (pass.size < 6) return "Make the passphrase at least 6 characters."
        if (KeyFile.count(ctx) == 0) return "No key is saved yet."
        if (!ensure(ctx)) return "The Anjoo AI folder is not ready: turn on 'All files access'."
        return try {
            val rnd = SecureRandom()
            val salt = ByteArray(16).also { rnd.nextBytes(it) }
            val iv = ByteArray(12).also { rnd.nextBytes(it) }
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, derive(pass, salt), GCMParameterSpec(128, iv))
            val ct = c.doFinal(KeyFile.export(ctx).toByteArray(Charsets.UTF_8))
            val o = JSONObject().put("app", "AnjooAI").put("type", "keys-enc").put("v", 1)
                .put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                .put("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
                .put("ct", Base64.encodeToString(ct, Base64.NO_WRAP))
            val dir = File(root(), "Key Backups")
            val f = File(dir, "keys-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.ENGLISH).format(Date()) + ".anjookeys")
            f.writeText(o.toString())
            val wrapped = Crypt.wrapForPassphrase(ctx, pass)
            if (wrapped != null) File(dir, Crypt.WRAP_FILE).writeText(wrapped)
            dir.listFiles { x -> x.name.endsWith(".anjookeys") }?.sortedByDescending { it.lastModified() }?.drop(KEEP_KEYS)?.forEach { it.delete() }
            "Encrypted keys backup created: Key Backups/" + f.name + ". The Anjoo AI folder's encryption recovery was also saved with this same passphrase. Remember the passphrase; without it this cannot be opened."
        } catch (e: Exception) { "Could not back up the keys: " + (e.message ?: e.javaClass.simpleName) }
    }

    /** Opens the newest key backup with the passphrase and imports the keys. */
    private fun restoreKeys(ctx: Context, pass: CharArray): String {
        val f = latestKeyFile() ?: return "No file in Key Backups."
        return try {
            val o = JSONObject(f.readText())
            if (o.optString("type") != "keys-enc") return "This does not look like a valid keys backup file."
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, derive(pass, Base64.decode(o.getString("salt"), Base64.NO_WRAP)),
                GCMParameterSpec(128, Base64.decode(o.getString("iv"), Base64.NO_WRAP)))
            val json = String(c.doFinal(Base64.decode(o.getString("ct"), Base64.NO_WRAP)), Charsets.UTF_8)
            KeyFile.import(ctx, json)
        } catch (e: javax.crypto.AEADBadTagException) { "The passphrase is wrong (or the file is damaged)." }
        catch (e: Exception) { "Could not restore the keys: " + (e.message ?: e.javaClass.simpleName) }
    }

    // ------------------------------------------------------------------ restore (folder -> phone)

    /** Brings everything back from the folder. [pass] is only needed for the keys (leave null to skip them). */
    @Synchronized fun restore(ctx: Context, pass: CharArray?): String {
        if (!ready(ctx) || !root().isDirectory) return "The Anjoo AI folder was not found."
        val out = StringBuilder()
        // 0. folder is encrypted: bring back the data key first (needs the passphrase)
        if (pass != null && pass.isNotEmpty()) {
            val w = File(File(root(), "Key Backups"), Crypt.WRAP_FILE)
            if (w.isFile) Crypt.unwrapWithPassphrase(ctx, w.readText(), pass)?.let { out.append(it).append('\n') }
        }
        // 1. newest full backup: settings, chats, projects, images
        latestZip()?.let { z ->
            val tmp = File(ctx.cacheDir, "rs-" + System.nanoTime() + ".zip")
            try {
                if (!Crypt.decryptFile(ctx, z, tmp)) out.append("The backup is encrypted and could not be opened: give the correct passphrase first.\n")
                else out.append(FileInputStream(tmp).use { Backup.restore(ctx, it) }).append('\n')
            } catch (e: Exception) { out.append("The backup file could not be opened.\n") } finally { tmp.delete() }
        }
        // 2. anything newer or missing, straight from the folders
        val r = root(); val fd = ctx.filesDir
        var n = 0
        n += mirror(ctx, File(r, "Projects/From chat"), File(fd, "chatkeep"), toFolder = false)
        n += mirror(ctx, File(r, "Projects/Older pages"), File(fd, "studio"), toFolder = false)
        n += mirror(ctx, File(r, "Images/Created"), File(fd, "images"), toFolder = false)
        n += mirror(ctx, File(r, "Chats/Attachments"), File(fd, "attach"), toFolder = false)
        n += mirror(ctx, File(r, "Artifacts"), File(fd, "artifacts"), toFolder = false)
        n += mirror(ctx, File(r, "Projects"), File(fd, "projects"), setOf("From chat", "Older pages"), toFolder = false)
        // 3. chats: the folder copy wins when it is newer than the backup
        try {
            val cur = HashMap<Long, JSONObject>()
            val all = ChatStore.all(ctx)
            for (i in 0 until all.length()) all.getJSONObject(i).let { cur[it.getLong("id")] = it }
            var chats = 0
            File(r, "Chats/Auto-saved").listFiles { f -> f.name.endsWith(".json") }?.forEach { f ->
                try {
                    val s = JSONObject(Crypt.readText(ctx, f) ?: return@forEach)
                    val id = s.getLong("id")
                    val old = cur[id]
                    if (old == null || s.optLong("last") > old.optLong("last")) { cur[id] = s; chats++ }
                } catch (e: Exception) {}
            }
            if (chats > 0) {
                val a = JSONArray()
                cur.values.sortedBy { it.optLong("last") }.forEach { a.put(it) }
                ChatStore.replaceAll(ctx, a)
            }
            out.append("Chats: ").append(cur.size).append(" (from the folder ").append(chats).append(" new/changed).\n")
        } catch (e: Exception) {}
        // 4. notes
        try {
            val nf = File(r, "Notes/notes.json")
            if (nf.exists()) Crypt.readText(ctx, nf)?.let { Notes.merge(ctx, JSONArray(it)) }
        } catch (e: Exception) {}
        out.append(n).append(" files (projects, images, attachments, artifacts) wapas.\n")
        // 5. keys
        if (pass != null && pass.isNotEmpty()) out.append(restoreKeys(ctx, pass)).append('\n')
        prefs(ctx).edit().putLong("vaultSync", 0L).apply()
        return out.toString().trim()
    }

    // ------------------------------------------------------------------ info

    fun info(ctx: Context): String {
        if (!ready(ctx)) return "The folder is not active yet: turn on 'All files access', then this folder will be created and will stay even after uninstalling."
        val r = root()
        var files = 0; var bytes = 0L
        try { for (f in r.walkTopDown()) if (f.isFile) { files++; bytes += f.length() } } catch (e: Exception) {}
        val last = prefs(ctx).getLong("vaultSync", 0L)
        val zip = latestZip()
        return "📁 " + r.absolutePath + "\n" + files + " files, " + (bytes / 1024) + " KB\n" +
            "Last sync: " + (if (last == 0L) "not yet" else ChatStore.dateOf(last)) + "\n" +
            "Last app backup: " + (if (zip == null) "not yet" else ChatStore.dateOf(zip.lastModified())) + "\n" +
            "Keys backup: " + (if (hasKeyBackup()) "yes (encrypted)" else "not yet")
    }
}
