package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream

/**
 * Code Studio: build a multi-file project from an idea, edit it by asking, ask questions about it,
 * read and copy every file, preview web projects, and export everything as a zip.
 */
class CodeActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var th: CyberTheme
    private var dir: File? = null
    private var cur: String? = null
    private var busy = false
    private var web: WebView? = null

    private lateinit var titleTv: TextView
    private lateinit var status: TextView
    private lateinit var tabs: LinearLayout
    private lateinit var area: FrameLayout
    private lateinit var logBox: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var codeWrap: LinearLayout
    private lateinit var pane: CodePane
    private lateinit var codeName: TextView
    private lateinit var input: EditText
    private lateinit var attachChip: TextView
    private lateinit var follower: SmartScroll
    private var attached: Pair<String, String>? = null
    private lateinit var goBtn: TextView
    private lateinit var host: FrameLayout
    private lateinit var chipRow: LinearLayout
    private var side: SideMenu? = null
    private lateinit var quickRow: HorizontalScrollView
    private val jsErrors = StringBuilder()
    private var mode = 2 // 0 ask, 1 edit, 2 build new

    private fun toggleThink() {
        val p = getSharedPreferences("anjoo", MODE_PRIVATE)
        p.edit().putBoolean("codeThink", !p.getBoolean("codeThink", true)).apply()
        val on = p.getBoolean("codeThink", true)
        Toast.makeText(this, if (on) "Deep think ON" else "Deep think OFF", Toast.LENGTH_SHORT).show()
    }

    private fun setMode(m: Int) {
        mode = m
        input.hint = when (m) {
            0 -> "Code ke bare mein poochein..."
            1 -> "Kya badalna hai?"
            else -> "Kya banana hai? (naya project)"
        }
        chipRow.removeAllViews()
        val names = listOf("💬 Ask", "✏️ Edit", "⚡ Build")
        for (i in listOf(2, 1, 0)) {
            val sel = i == m
            chipRow.addView(TextView(this).apply {
                text = names[i]; textSize = 12.5f; gravity = Gravity.CENTER
                setTextColor(if (sel) th.bg else th.muted)
                background = box(if (sel) th.accent else Color.TRANSPARENT, if (sel) th.accent else faint(), dp(16))
                setPadding(dp(14), dp(5), dp(14), dp(5))
                setOnClickListener { setMode(i) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
    }

    private fun openSide() {
        val sm = side ?: SideMenu(this, host, th.bg, th.surface, th.ink, th.muted, th.accent).also { side = it }
        sm.open("Code Studio", "New project", { if (!busy) newProject() },
            {
                Coder.list(this).map { d ->
                    SideMenu.Item(Coder.name(d), d == dir,
                        { if (!busy) openProject(d) },
                        { copy(transcript(d)) },
                        { share(transcript(d)) },
                        { Coder.delete(d); if (dir == d) newProject() },
                        false,
                        { nt -> Coder.rename(d, nt); if (dir == d) titleTv.text = Coder.name(d) },
                        null)
                }
            },
            listOf(mi("💬  Back to Anjoo chat") { finish() }),
            "Abhi koi project nahi. Kuch banane ko bolein.", "Your projects", "📁")
    }

    private fun mi(l: String, f: () -> Unit) = Pair(l, f)

    private fun fixErrors() {
        if (busy) return
        if (dir == null) { Toast.makeText(this, "Pehle project banayein.", Toast.LENGTH_SHORT).show(); return }
        val e = jsErrors.toString().trim()
        if (e.isEmpty()) { Toast.makeText(this, "Preview chalayein; abhi koi error nahi mila.", Toast.LENGTH_SHORT).show(); return }
        jsErrors.setLength(0)
        input.setText("Preview mein ye errors aa rahe hain, inko theek karo:\n" + e.take(1500))
        go(1)
    }

    private fun undoEdit() {
        val d = dir ?: return
        if (busy) return
        if (!Coder.canUndo(this, d)) { Toast.makeText(this, "Undo ke liye kuch nahi.", Toast.LENGTH_SHORT).show(); return }
        if (Coder.undo(this, d)) { openProject(d); Toast.makeText(this, "Pichla badlav wapas ho gaya.", Toast.LENGTH_SHORT).show() }
    }

    private fun transcript(d: File): String {
        val sb = StringBuilder(Coder.name(d)).append("\n\n")
        for ((r, t) in Coder.history(d)) sb.append(if (r == "u") "You: " else "Anjoo: ").append(t).append("\n\n")
        return sb.toString().trim()
    }

    private fun moreMenu(v: View) {
        val pm = android.widget.PopupMenu(this, v)
        pm.menu.add("▶️  Run preview"); pm.menu.add("🐍  Run Python"); pm.menu.add("🛠  Fix preview errors"); pm.menu.add("↩️  Undo last edit"); pm.menu.add("📦  Download zip"); pm.menu.add("🌍  Export as one HTML file")
        pm.menu.add(if (getSharedPreferences("anjoo", MODE_PRIVATE).getBoolean("codeThink", true)) "🧠  Deep think: ON" else "🧠  Deep think: OFF")
        pm.menu.add("🗑  Delete project")
        pm.setOnMenuItemClickListener { m ->
            val tt = m.title?.toString() ?: ""
            when {
                tt.endsWith("Run preview") -> preview()
                tt.endsWith("Run Python") -> runPython()
                tt.endsWith("Download zip") -> exportZip()
                tt.endsWith("Export as one HTML file") -> exportHtml()
                tt.endsWith("Fix preview errors") -> fixErrors()
                tt.endsWith("Undo last edit") -> undoEdit()
                tt.contains("Deep think") -> toggleThink()
                else -> deleteProject()
            }
            true
        }
        pm.show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int, r: Int) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = r.toFloat()
    }

    private fun btn(t: String, a: () -> Unit): Button = Button(this).apply {
        text = t; isAllCaps = false; textSize = 11f; setTextColor(th.accent)
        background = box(th.surface, th.accent, dp(8))
        minWidth = 0; minimumWidth = 0; setPadding(dp(10), 0, dp(10), 0)
        layoutParams = LinearLayout.LayoutParams(-2, dp(36)).apply { leftMargin = dp(5) }
        setOnClickListener { a() }
    }

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        Touch.feedback(window.decorView, ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        th = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        Style.bars(window, th)

        host = FrameLayout(this).apply { setBackgroundColor(th.bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        host.addView(root, FrameLayout.LayoutParams(-1, -1))

        fun icon(t: String, a: (View) -> Unit) = TextView(this).apply {
            text = t; textSize = 22f; setTextColor(th.ink); gravity = Gravity.CENTER
            setOnClickListener { a(this) }
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(icon("≡") { openSide() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        titleTv = TextView(this).apply {
            text = "Code Studio"; setTextColor(th.ink); textSize = 17f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        bar.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
        bar.addView(icon("+") { if (!busy) newProject() }, LinearLayout.LayoutParams(dp(42), dp(42)))
        bar.addView(icon("⋮") { moreMenu(it) }, LinearLayout.LayoutParams(dp(42), dp(42)))
        root.addView(bar)
        root.addView(View(this).apply { setBackgroundColor(faint()) }, LinearLayout.LayoutParams(-1, dp(1)))

        status = TextView(this).apply { setTextColor(th.muted); textSize = 11f; typeface = Typeface.MONOSPACE; setPadding(0, dp(4), 0, dp(4)) }
        root.addView(status)

        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabScroll.addView(tabs)
        root.addView(tabScroll, LinearLayout.LayoutParams(-1, dp(44)))

        area = FrameLayout(this)
        logBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(2)) }
        logScroll = ScrollView(this).apply { addView(logBox) }
        follower = SmartScroll(logScroll)

        codeName = TextView(this).apply { setTextColor(th.accent); typeface = Typeface.MONOSPACE; textSize = 12f }
        val crow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(2), 0, dp(4)) }
        crow.addView(codeName, LinearLayout.LayoutParams(0, -2, 1f))
        crow.addView(btn("Edit") { editFile() })
        crow.addView(btn("Copy") { copy(pane.text()) })
        crow.addView(btn("Share") { share(pane.text()) })
        pane = CodePane(this, 12f, true)
        val hs = HorizontalScrollView(this).apply { addView(pane.view) }
        val vs = ScrollView(this).apply { addView(hs); setBackgroundColor(Color.argb(120, 0, 0, 0)) }
        codeWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        codeWrap.addView(crow)
        codeWrap.addView(vs, LinearLayout.LayoutParams(-1, 0, 1f))

        area.addView(logScroll, FrameLayout.LayoutParams(-1, -1))
        area.addView(codeWrap, FrameLayout.LayoutParams(-1, -1))
        root.addView(area, LinearLayout.LayoutParams(-1, 0, 1f))

        quickRow = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; visibility = View.GONE }
        val qBox = LinearLayout(this).apply { setPadding(dp(2), dp(6), dp(2), 0) }
        val quicks = listOf(
            Triple("🐞 Find bugs", "Review the whole project for bugs, edge cases and crashes. Fix every real problem you find and list what you fixed.", 1),
            Triple("⚡ Optimize", "Optimize performance and clean the code without changing behaviour. Explain what improved.", 1),
            Triple("🧪 Add tests", "Add automated tests (or a test page / test script for web projects) covering the main features and edge cases.", 1),
            Triple("📝 Explain", "Explain how this project works file by file in simple words.", 0),
            Triple("🎨 Better UI", "Make the interface look more polished and professional: spacing, typography, colors, animations and mobile friendliness. Keep all features.", 1),
            Triple("🔒 Security", "Do a security review (input validation, XSS, secrets, unsafe storage) and fix the issues you find.", 1),
            Triple("🧹 Clean up", "Refactor for readability: clear names, small functions, helpful comments. Keep behaviour identical.", 1),
            Triple("📱 Responsive", "Make it fully responsive and touch friendly for phones, tablets and desktop.", 1)
        )
        for ((label, ins, k) in quicks) {
            qBox.addView(TextView(this).apply {
                text = label; textSize = 12f; setTextColor(th.accent); gravity = Gravity.CENTER
                background = box(Color.TRANSPARENT, th.accent, dp(16))
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener { quick(ins, k) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        quickRow.addView(qBox)
        root.addView(quickRow)
        chipRow = LinearLayout(this).apply { setPadding(dp(2), dp(8), 0, dp(2)) }
        root.addView(chipRow)
        attachChip = TextView(this).apply {
            textSize = 12f; setTextColor(th.accent); visibility = View.GONE
            setPadding(dp(12), dp(4), dp(12), dp(4))
            setOnClickListener { attached = null; visibility = View.GONE }
        }
        root.addView(attachChip)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(4), 0, 0) }
        input = EditText(this).apply {
            setHintTextColor(th.muted); setTextColor(th.ink); textSize = 15f
            background = box(th.surface, faint(), dp(22))
            setPadding(dp(16), dp(10), dp(16), dp(10))
            maxLines = 5
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(TextView(this).apply {
            text = "📎"; textSize = 17f; gravity = Gravity.CENTER
            background = box(Color.TRANSPARENT, th.accent, dp(22))
            setOnClickListener { attachMenu() }
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        row.addView(TextView(this).apply {
            text = "✨"; textSize = 18f; gravity = Gravity.CENTER
            background = box(Color.TRANSPARENT, th.accent, dp(22))
            setOnClickListener { enhanceInput() }
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        goBtn = TextView(this).apply {
            text = "➤"; textSize = 18f; gravity = Gravity.CENTER; setTextColor(th.bg)
            background = GradientDrawable().apply { setColor(th.accent); shape = GradientDrawable.OVAL }
            setOnClickListener { if (busy) stopRun() else go(mode) }
        }
        row.addView(goBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(8) })
        root.addView(row)

        setContentView(host)
        setMode(2)
        welcome()
        handle(intent)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        handle(i)
    }

    private fun handle(i: Intent?) {
        val p = i?.getStringExtra("project") ?: return
        val d = File(p)
        if (d.isDirectory) {
            openProject(d)
            if (i?.getBooleanExtra("preview", false) == true && PreviewServer.entry(d) != null) ui.postDelayed({ if (dir == d) preview() }, 400)
        }
    }

    // ---------- state ----------

    private fun welcome() {
        logBox.removeAllViews()
        addLog("a", "👋 Assalam o alaikum! Main Code Studio hoon. Likhein kya banana hai.")
        addReadMe("📖 Read Me", "Code Studio guide",
            "⚡ BUILD: likhein kya banana hai (website, app, script, game...). Main pehle plan banata hoon, phir poora project likhta hoon aur khud check karta hoon.\n\n" +
            "✏️ EDIT: project khulne ke baad likhein 'dark mode lagao', 'login page add karo'. Har edit ke baad dikhata hoon kaunsi file mein kya badla.\n\n" +
            "💬 ASK: koi bhi code sawal ya bug poochein.\n\n" +
            "🚀 Project khulne par upar ke quick buttons se Find bugs, Optimize, Add tests, Better UI, Security jaise kaam ek tap mein chalayein.\n\n" +
            "📎 Upload ki hui file chat mein card ki tarah dikhti hai (card par tap = download, 👁 = dekhna). Har edit ke baad "Files Processed" section aata hai (+/− diff, tap karke dekhein), aur har file ke saath ⬇ Download hai.\n\n" +
            "📦 Files tabs mein hain, ▶ Preview se chalayein, 📦 Zip se poora project save karein.")
    }

    /** A short tappable line in the chat; tapping it opens the long text as a card. */
    private fun addReadMe(label: String, title: String, body: String) {
        val line = TextView(this).apply {
            text = "$label  ›"; textSize = 13.5f; setTextColor(th.accent)
            background = box(th.surface, th.accent, dp(20))
            setPadding(dp(14), dp(7), dp(14), dp(7))
            setOnClickListener { showReadMeCard(title, body) }
        }
        logBox.addView(line, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
    }

    private fun showReadMeCard(title: String, body: String) {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(th.surface, th.accent, dp(16))
            setPadding(dp(16), dp(14), dp(16), dp(12))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply {
            text = "📖  $title"; textSize = 16f; setTextColor(th.ink); typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(this).apply {
            text = "✕"; textSize = 18f; setTextColor(th.muted); setPadding(dp(10), 0, 0, 0)
            setOnClickListener { dlg.dismiss() }
        })
        card.addView(head)
        val sv = android.widget.ScrollView(this)
        sv.addView(TextView(this).apply {
            text = body; textSize = 14f; setTextColor(th.ink); setTextIsSelectable(true)
            setLineSpacing(0f, 1.15f); setPadding(0, dp(10), 0, dp(4))
        })
        card.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        dlg.setContentView(card)
        dlg.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            setLayout((resources.displayMetrics.widthPixels * 0.92f).toInt(), (resources.displayMetrics.heightPixels * 0.72f).toInt())
        }
        dlg.show()
    }

    private fun say(s: String) {
        status.text = s
        if (liveCard != null && s.isNotBlank()) {
            if (stepList.lastOrNull() != s) stepList.add(s)
            liveSteps?.text = stepList.mapIndexed { i, x -> (if (i < stepList.size - 1) "✓  " else "▸  ") + x }.takeLast(5).joinToString("\n")
            liveNow?.text = ""
            liveCode?.text = ""
        }
    }

    // ---- live activity card: shows what Anjoo is doing while it thinks and codes ----
    private var liveCard: LinearLayout? = null
    private var liveSteps: TextView? = null
    private var liveNow: TextView? = null
    private var liveThought: TextView? = null
    private var liveCode: TextView? = null
    private var liveTitle: TextView? = null
    private var liveStart = 0L
    private var token = 0
    private val stepList = ArrayList<String>()
    private var lastLive = 0L

    private val tick = object : Runnable {
        override fun run() {
            val t = liveTitle ?: return
            val sec = (android.os.SystemClock.elapsedRealtime() - liveStart) / 1000
            t.text = "\u25CF  Anjoo is working  \u00b7  " + sec + "s"
            ui.postDelayed(this, 1000)
        }
    }

    /** Stop button: the screen is released at once; the background work is told to stop at its next step. */
    private fun stopRun() {
        if (!busy) return
        token++
        Coder.stop()
        stopLive()
        addLog("a", "\u23F9 Roka gaya. Jo files pehle ban chuki thin woh project mein mojood hain (Undo se wapas bhi ja sakte hain).")
        say("Stopped")
        setBusy(false)
        refreshTabs()
    }

    private fun startLive() {
        stepList.clear()
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(th.surface, th.accent, dp(12))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        liveTitle = TextView(this).apply {
            text = "\u25CF  Anjoo is working  \u00b7  0s"; textSize = 13f; setTextColor(th.accent)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }
        c.addView(liveTitle)
        liveStart = android.os.SystemClock.elapsedRealtime()
        ui.removeCallbacks(tick)
        ui.postDelayed(tick, 1000)
        liveSteps = TextView(this).apply { textSize = 12.5f; setTextColor(th.ink); setPadding(0, dp(8), 0, 0) }
        liveNow = TextView(this).apply {
            textSize = 12.5f; setTextColor(th.accent); setPadding(0, dp(4), 0, 0)
            minLines = 4; maxLines = 4; ellipsize = android.text.TextUtils.TruncateAt.END
        }
        liveThought = TextView(this).apply {
            textSize = 12f; setTextColor(th.muted); setTypeface(null, Typeface.ITALIC); setPadding(0, dp(6), 0, 0)
            minLines = 3; maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.START
        }
        liveCode = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 11f; setTextColor(Hl.def)
            background = box(Color.argb(200, 0, 0, 0), faint(), dp(8))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setHorizontallyScrolling(true); maxLines = 10; gravity = Gravity.BOTTOM or Gravity.START
            ellipsize = null
        }
        c.addView(liveSteps); c.addView(liveNow)
        c.addView(liveCode, LinearLayout.LayoutParams(-1, dp(196)).apply { topMargin = dp(6) })
        c.addView(liveThought)
        logBox.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        liveCard = c
        Coder.live = { thought, answer -> onLive(thought, answer) }
        follower.toBottom()
    }

    private fun onLive(thought: String, answer: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastLive < 150) return
        lastLive = now
        ui.post {
            if (liveCard == null) return@post
            if (answer.isBlank()) {
                if (thought.isNotBlank()) { liveThought?.text = "💭 " + thought.replace("*", "").takeLast(600) }
            } else {
                val marks = Regex("=== (?:FILE|EDIT): (.+?) ===").findAll(answer).toList()
                val m = marks.lastOrNull()
                val kb = String.format(java.util.Locale.US, "%.1f", answer.length / 1000.0)
                if (m != null) {
                    val name = m.groupValues[1].trim()
                    val body = answer.substring(m.range.last + 1).trim('\n')
                    val done = marks.dropLast(1).map { it.groupValues[1].trim() }.distinct().takeLast(3)
                    val head = done.joinToString("") { "\u2713  " + it + "  \u00b7  done\n" }
                    liveNow?.text = head + "\u270D  Writing " + name + "  (" + (body.count { it == '\n' } + 1) + " lines, " + kb + "k chars)"
                    val tail = body.split('\n').takeLast(10).joinToString("\n") { if (it.length > 90) it.take(90) + "\u2026" else it }
                    liveCode?.text = Hl.span(tail, name)
                } else {
                    liveNow?.text = "\u270D  Writing the answer...  (" + kb + "k characters so far)"
                }
            }
            follower.toBottom()
        }
    }

    private fun stopLive() {
        Coder.live = null
        ui.removeCallbacks(tick)
        liveCard?.let { logBox.removeView(it) }
        liveCard = null; liveSteps = null; liveNow = null; liveThought = null; liveCode = null; liveTitle = null
    }

    private fun setBusy(b: Boolean) {
        busy = b
        goBtn.text = if (b) "\u25A0" else "\u27A4"
        goBtn.alpha = 1f
    }

    private fun newProject() {
        if (busy) return
        dir = null; cur = null
        titleTv.text = "Code Studio"
        welcome(); refreshTabs(); show(null)
        setMode(2)
        say("")
    }

    private fun openProject(d: File) {
        dir = d; cur = null
        titleTv.text = Coder.name(d)
        logBox.removeAllViews()
        val h = Coder.history(d)
        if (h.isEmpty()) addLog("a", "Project khul gaya. Badlav likhein ya sawal poochein.")
        for ((r, t) in h) addLog(r, t)
        addChangesCard(d, Coder.diffs(this, d), false)
        addProjectCard(d, false)
        follower.toBottom(true)
        setMode(1)
        refreshTabs(); show(null)
        say(Coder.readFiles(d).size.toString() + " files")
    }

    private fun pickProject() { openSide() }

    private fun pickProjectOld() {
        val ps = Coder.list(this)
        if (ps.isEmpty()) { Toast.makeText(this, "Abhi koi project nahi. Kuch banane ko bolein.", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Projects")
            .setItems(ps.map { Coder.name(it) }.toTypedArray()) { _, i -> if (!busy) openProject(ps[i]) }.show()
    }

    private fun deleteProject() {
        val d = dir ?: return
        AlertDialog.Builder(this).setMessage("Delete project '" + Coder.name(d) + "'?")
            .setPositiveButton("Delete") { _, _ -> Coder.delete(d); newProject() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- tabs and viewers ----------

    private fun fileIcon(p: String): String = when (p.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "🌐"
        "css" -> "🎨"
        "js", "ts", "jsx", "tsx" -> "⚙️"
        "py" -> "🐍"
        "json" -> "📋"
        "md", "txt" -> "📝"
        "kt", "java" -> "☕"
        "png", "jpg", "jpeg", "svg", "gif", "webp" -> "🖼️"
        else -> "📄"
    }

    private fun quick(instruction: String, kind: Int) {
        if (busy || dir == null) return
        input.setText(instruction)
        go(kind)
    }

    private fun refreshTabs() {
        tabs.removeAllViews()
        fun tab(label: String, sel: Boolean, a: () -> Unit) {
            val t = TextView(this).apply {
                text = label; textSize = 12f; typeface = Typeface.MONOSPACE
                setTextColor(if (sel) th.bg else th.accent)
                background = box(if (sel) th.accent else th.surface, th.accent, dp(8))
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setOnClickListener { a() }
            }
            tabs.addView(t, LinearLayout.LayoutParams(-2, dp(34)).apply { rightMargin = dp(5); topMargin = dp(4) })
        }
        tab("💬 CHAT", cur == null) { show(null) }
        quickRow.visibility = if (dir == null) View.GONE else View.VISIBLE
        val d = dir ?: return
        for (p in Coder.readFiles(d).keys) tab(fileIcon(p) + " " + p, cur == p) { show(p) }
    }

    private fun show(path: String?) {
        cur = path
        web?.visibility = View.GONE
        if (path == null) {
            logScroll.visibility = View.VISIBLE
            codeWrap.visibility = View.GONE
        } else {
            val d = dir
            val text = if (d != null) try { File(d, path).readText(Charsets.UTF_8) } catch (e: Exception) { "File nahi khuli." } else ""
            codeName.text = path + "   \u00b7   " + (text.count { it == '\n' } + 1) + " lines"
            pane.set(text, path)
            logScroll.visibility = View.GONE
            codeWrap.visibility = View.VISIBLE
        }
        refreshTabs()
    }

    private fun editFile() {
        val d = dir ?: return
        val p = cur ?: return
        editFileDialog(d, p) {
            show(p)
            if (web?.visibility == View.VISIBLE) preview()
        }
    }

    private fun editFileDialog(d: File, p: String, saved: () -> Unit) {
        val et = EditText(this).apply {
            setText(try { File(d, p).readText(Charsets.UTF_8) } catch (e: Exception) { "" })
            typeface = Typeface.MONOSPACE; textSize = 12f
            setHorizontallyScrolling(true); gravity = Gravity.TOP or Gravity.START
            minLines = 12
        }
        AlertDialog.Builder(this).setTitle(p).setView(et)
            .setPositiveButton("Save") { _, _ ->
                Coder.writeFile(d, p, et.text.toString())
                saved()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun copy(t: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Anjoo", t))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun share(t: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Share"))
    }

    // ---------- file cards (upload, edit details, download) ----------

    private val ATT_RE = Regex("^ATTACHED FILE: (.+?)\\n```\\n([\\s\\S]*?)(?:\\n```\\n\\n([\\s\\S]*))?$")
    private var pendingSave: Pair<String, ByteArray>? = null

    private fun sizeText(n: Int): String = when {
        n < 1024 -> "$n B"
        n < 1024 * 1024 -> String.format(java.util.Locale.US, "%.1f KB", n / 1024.0)
        else -> String.format(java.util.Locale.US, "%.2f MB", n / (1024.0 * 1024.0))
    }

    /** Human name of a file type, e.g. "HTML document". */
    private fun kindName(n: String): String = when (n.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "HTML document"; "css" -> "CSS stylesheet"; "js" -> "JavaScript"; "ts" -> "TypeScript"
        "jsx", "tsx" -> "React component"; "py" -> "Python script"; "json" -> "JSON data"; "md" -> "Markdown document"
        "txt" -> "Text file"; "kt" -> "Kotlin source"; "java" -> "Java source"; "xml" -> "XML file"; "zip" -> "ZIP archive"
        "pdf" -> "PDF document"; "png", "jpg", "jpeg", "gif", "webp" -> "Image"; "svg" -> "SVG image"; "csv" -> "CSV table"
        "sql" -> "SQL script"; "sh" -> "Shell script"; "docx" -> "Word document"; "xlsx" -> "Excel sheet"
        "" -> "File"; else -> n.substringAfterLast('.').uppercase() + " file"
    }



    /** Download one file to the phone (the system "Save to" screen opens). */
    private fun saveFile(name: String, bytes: ByteArray) {
        pendingSave = Pair(name, bytes)
        try {
            startActivityForResult(
                Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/octet-stream").putExtra(Intent.EXTRA_TITLE, name.substringAfterLast('/')), 47
            )
        } catch (e: Exception) { Toast.makeText(this, "Save nahi ho saka.", Toast.LENGTH_SHORT).show() }
    }

    private fun viewFile(name: String, text: String, bytes: ByteArray) {
        val cp = CodePane(this, 12f, true)
        cp.set(if (text.length > 60000) text.take(60000) + "\n... (baqi file download mein hai)" else text, name)
        val vs = ScrollView(this).apply { addView(HorizontalScrollView(this@CodeActivity).apply { addView(cp.view) }); setBackgroundColor(Color.argb(140, 0, 0, 0)) }
        AlertDialog.Builder(this).setTitle(name).setView(vs)
            .setPositiveButton("⬇ Download") { _, _ -> saveFile(name, bytes) }
            .setNeutralButton("Copy") { _, _ -> copy(text) }
            .setNegativeButton("Close", null).show()
    }

    /** One file as a card row: icon, name, details, optional badge and a download button. Tap = open. */
    private fun fileRow(name: String, sub: String, badge: String?, onOpen: () -> Unit, onSave: (() -> Unit)?, icon: String = fileIcon(name)): LinearLayout {
        val r = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = box(Color.TRANSPARENT, faint(), dp(10))
            setPadding(dp(10), dp(8), dp(8), dp(8))
            // Tap the row = download. The 👁 button opens it for reading.
            setOnClickListener { if (onSave != null) onSave() else onOpen() }
        }
        r.addView(TextView(this).apply {
            text = icon + "\n" + name.substringAfterLast('.', "file").uppercase().take(5); textSize = 9f; gravity = Gravity.CENTER; setTextColor(th.muted)
            setLineSpacing(0f, 0.9f)
        }, LinearLayout.LayoutParams(dp(40), -2))
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(this).apply {
            text = name; textSize = 12.5f; typeface = Typeface.MONOSPACE; setTextColor(th.ink)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        })
        col.addView(TextView(this).apply { text = sub; textSize = 11f; setTextColor(th.muted) })
        r.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(6) })
        if (badge != null) r.addView(TextView(this).apply {
            text = badge; textSize = 9.5f; setTextColor(th.accent); setPadding(dp(6), dp(2), dp(6), dp(2))
            background = box(Color.TRANSPARENT, th.accent, dp(6))
        }, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(6) })
        if (onSave != null) r.addView(TextView(this).apply {
            text = "👁"; textSize = 15f; gravity = Gravity.CENTER; setTextColor(th.accent)
            background = box(Color.TRANSPARENT, th.accent, dp(18))
            setOnClickListener { onOpen() }
        }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginEnd = dp(6) })
        if (onSave != null) r.addView(TextView(this).apply {
            text = "⬇"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(th.accent)
            background = box(Color.TRANSPARENT, th.accent, dp(18))
            setOnClickListener { onSave() }
        }, LinearLayout.LayoutParams(dp(36), dp(36)))
        return r
    }

    private fun fileBytes(d: File, p: String): ByteArray = try { File(d, p).readBytes() } catch (e: Exception) { ByteArray(0) }

    private fun cardBox(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = box(th.surface, th.accent, dp(12))
        setPadding(dp(10), dp(8), dp(10), dp(10))
    }

    /** The steps Anjoo went through (plan, write, review, run check), kept in the chat after it finishes. */
    private fun addChecksCard() {
        val steps = stepList.map { it.trimEnd('.', ' ') }.filter { it.isNotBlank() }
        if (steps.isEmpty()) return
        val sec = (android.os.SystemClock.elapsedRealtime() - liveStart) / 1000
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(th.surface, faint(), dp(12)); setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        val body = TextView(this).apply {
            text = steps.joinToString("\n") { "✓  " + it }; textSize = 12.5f; setTextColor(th.ink)
            setPadding(0, dp(6), 0, dp(2)); visibility = View.GONE
        }
        val head = TextView(this).apply {
            text = "✓ Checked and done  ·  " + steps.size + " steps  ·  " + sec + "s  ▸"; textSize = 12.5f; setTextColor(th.accent)
            setOnClickListener {
                val open = body.visibility == View.VISIBLE
                body.visibility = if (open) View.GONE else View.VISIBLE
                text = "✓ Checked and done  ·  " + steps.size + " steps  ·  " + sec + "s  " + (if (open) "▸" else "▾")
            }
        }
        c.addView(head); c.addView(body)
        logBox.addView(c, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
    }

    /** Files created or edited by Anjoo: one row per file with +/- counts, tap to see the diff, ⬇ to download. */
    private fun addChangesCard(d: File, list: List<Coder.Change>, startOpen: Boolean = true) {
        if (list.isEmpty()) return
        val adds = list.sumOf { it.add }
        val dels = list.sumOf { it.del }
        val onlyNew = list.all { it.status == "new" }
        val card = cardBox()
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = if (startOpen) View.VISIBLE else View.GONE }
        val headText = { open: Boolean ->
            "📂 Files Processed  ·  " + list.size + (if (list.size == 1) " file" else " files") +
                (if (onlyNew) "" else "   +" + adds + "  −" + dels) + "   " + (if (open) "▾" else "▸")
        }
        card.addView(TextView(this).apply {
            text = headText(startOpen)
            textSize = 13.5f; setTextColor(th.accent); typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setPadding(0, dp(2), 0, dp(2))
            setOnClickListener {
                val open = content.visibility != View.VISIBLE
                content.visibility = if (open) View.VISIBLE else View.GONE
                text = headText(open)
                if (open) follower.toBottom()
            }
        })
        card.addView(content, LinearLayout.LayoutParams(-1, -2))
        for (c in list) {
            val rowBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val diffBox = ScrollView(this).apply {
                visibility = View.GONE; setBackgroundColor(Color.argb(140, 0, 0, 0))
                setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
            }
            if (c.diff.isNotEmpty() && c.status == "edit") {
                val sb = android.text.SpannableStringBuilder()
                for (l in c.diff) {
                    val st = sb.length
                    sb.append(l).append('\n')
                    val col = when { l.startsWith("+ ") -> Color.argb(90, 46, 160, 67); l.startsWith("- ") -> Color.argb(90, 218, 54, 51); else -> 0 }
                    if (col != 0) sb.setSpan(android.text.style.BackgroundColorSpan(col), st, sb.length, android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                }
                diffBox.addView(HorizontalScrollView(this).apply {
                    addView(TextView(this@CodeActivity).apply {
                        text = sb; typeface = Typeface.MONOSPACE; textSize = 11f; setTextColor(Hl.def)
                        setHorizontallyScrolling(true); setPadding(dp(8), dp(6), dp(8), dp(6))
                    })
                })
            }
            val icon = if (c.status == "deleted") "🗑" else fileIcon(c.path)
            val fsize = sizeText(File(d, c.path).length().toInt())
            val sub = when (c.status) {
                "new" -> kindName(c.path) + "  ·  " + fsize + "  ·  " + c.add + " lines"
                "deleted" -> kindName(c.path) + "  ·  deleted"
                else -> kindName(c.path) + "  ·  " + fsize + "  ·  +" + c.add + " −" + c.del + "  (👁 for changes)"
            }
            val open: () -> Unit = {
                if (diffBox.childCount > 0) {
                    diffBox.visibility = if (diffBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                } else if (c.status != "deleted") {
                    val t = try { File(d, c.path).readText(Charsets.UTF_8) } catch (e: Exception) { "" }
                    viewFile(c.path, t, t.toByteArray(Charsets.UTF_8))
                }
            }
            rowBox.addView(fileRow(c.path, sub, c.status.uppercase(), open,
                if (c.status == "deleted") null else { { saveFile(c.path, fileBytes(d, c.path)) } }, icon))
            rowBox.addView(diffBox, LinearLayout.LayoutParams(-1, dp(240)).apply { topMargin = dp(4) })
            content.addView(rowBox, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
        val acts = LinearLayout(this).apply { setPadding(0, dp(8), 0, 0) }
        acts.addView(btn("📦 Download all (zip)") { dir = d; exportZip() }, LinearLayout.LayoutParams(-2, dp(36)).apply { leftMargin = 0 })
        if (!onlyNew && Coder.canUndo(this, d)) acts.addView(btn("↩ Undo") { dir = d; undoEdit() })
        content.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(acts) })
        logBox.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        follower.toBottom()
    }

    private fun createdList(d: File): List<Coder.Change> =
        Coder.readFiles(d).map { (p, c) -> Coder.Change(p, "new", c.count { it == '\n' } + 1, 0, emptyList()) }

    // ---------- chat log ----------

    private fun addLog(role: String, text: String, thought: String = "") {
        val user = role == "u"
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = box(if (user) th.user else th.surface, if (user) th.user else faint(), dp(12))
        }
        if (user) {
            val am = ATT_RE.find(text)
            if (am != null) {
                val an = am.groupValues[1].trim()
                val body = am.groupValues[2]
                val rest = am.groupValues[3].trim()
                val bytes = body.toByteArray(Charsets.UTF_8)
                v.addView(fileRow(an, (body.count { it == '\n' } + 1).toString() + " lines  \u00b7  " + sizeText(bytes.size) + "  \u00b7  " + (an.substringAfterLast('.', "file").uppercase()), "UPLOADED",
                    { viewFile(an, body, bytes) }, { saveFile(an, bytes) }),
                    LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
                if (rest.isNotEmpty()) v.addView(TextView(this).apply { this.text = rest; setTextColor(th.ink); textSize = 14.5f; setTextIsSelectable(true) })
            } else {
                v.addView(TextView(this).apply { this.text = text; setTextColor(th.ink); textSize = 14.5f; setTextIsSelectable(true) })
            }
        } else {
            if (thought.isNotBlank()) {
                val body = TextView(this).apply {
                    this.text = thought; textSize = 12.5f; setTextColor(th.muted); visibility = View.GONE
                    setPadding(dp(8), dp(2), dp(4), dp(8))
                }
                v.addView(TextView(this).apply {
                    this.text = "Thought process  ▸"; textSize = 12f; setTextColor(th.muted); setPadding(0, dp(2), 0, dp(6))
                    setOnClickListener {
                        val open = body.visibility == View.VISIBLE
                        body.visibility = if (open) View.GONE else View.VISIBLE
                        this.text = if (open) "Thought process  ▸" else "Thought process  ▾"
                    }
                })
                v.addView(body)
            }
            v.addView(Md.render(this, text, th))
        }
        logBox.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        follower.toBottom()
    }

    private fun faint() = Color.argb(70, 128, 128, 128)

    /** A project card inside the chat: file list, code viewer and live preview, all without leaving the chat. */
    private fun addProjectCard(d: File, open: Boolean) {
        val files = Coder.readFiles(d)
        if (files.isEmpty()) return
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(th.surface, th.accent, dp(12))
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            this.text = Coder.name(d) + "  ·  " + files.size + " files"; setTextColor(th.accent)
            textSize = 13.5f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val codeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val prevBox = FrameLayout(this).apply { visibility = View.GONE }
        var wv: WebView? = null
        val name = files.keys.firstOrNull { it.equals("index.html", true) }
            ?: files.keys.firstOrNull { it.equals("README.md", true) } ?: files.keys.first()
        val pane2 = CodePane(this, 12f, true)
        var curName = name
        fun load(n: String) {
            curName = n
            pane2.set(try { File(d, n).readText(Charsets.UTF_8) } catch (e: Exception) { "File nahi khuli." }, n)
        }
        val fileRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (n in files.keys) {
            fileRow.addView(TextView(this).apply {
                this.text = n; textSize = 11.5f; typeface = Typeface.MONOSPACE; setTextColor(th.accent)
                background = box(Color.TRANSPARENT, faint(), dp(8)); setPadding(dp(9), dp(5), dp(9), dp(5))
                setOnClickListener { load(n) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        codeBox.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(fileRow) })
        val hsv = HorizontalScrollView(this).apply { addView(pane2.view) }
        val vsv = ScrollView(this).apply {
            addView(hsv); setBackgroundColor(Color.argb(140, 0, 0, 0))
            setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
        }
        codeBox.addView(vsv, LinearLayout.LayoutParams(-1, dp(300)).apply { topMargin = dp(6) })
        val bar = LinearLayout(this).apply { gravity = Gravity.END }
        bar.addView(TextView(this).apply {
            this.text = "Copy file"; textSize = 12f; setTextColor(th.accent); setPadding(dp(8), dp(8), dp(8), dp(4))
            setOnClickListener { copy(pane2.text()) }
        })
        bar.addView(TextView(this).apply {
            this.text = "⬇ Download"; textSize = 12f; setTextColor(th.accent); setPadding(dp(8), dp(8), dp(8), dp(4))
            setOnClickListener { saveFile(curName, fileBytes(d, curName)) }
        })
        bar.addView(TextView(this).apply {
            this.text = "Edit"; textSize = 12f; setTextColor(th.accent); setPadding(dp(8), dp(8), dp(8), dp(4))
            setOnClickListener { editFileDialog(d, curName) { load(curName) } }
        })
        codeBox.addView(bar)
        load(name)

        fun showCode() { codeBox.visibility = if (codeBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE; prevBox.visibility = View.GONE }
        fun openPage(p: String) {
            var w = wv
            if (w == null) {
                w = projectWebView(d)
                w.setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
                prevBox.addView(w, FrameLayout.LayoutParams(-1, -1))
                wv = w
            }
            w.loadUrl("https://app.local/" + p)
            codeBox.visibility = View.GONE
            prevBox.visibility = View.VISIBLE
        }
        fun showPrev() {
            val entry = PreviewServer.entry(d)
            if (entry == null) { Toast.makeText(this, "Preview sirf web (HTML) projects ke liye hai.", Toast.LENGTH_SHORT).show(); return }
            if (prevBox.visibility == View.VISIBLE) { prevBox.visibility = View.GONE; return }
            if (wv == null) openPage(entry) else { wv?.reload(); codeBox.visibility = View.GONE; prevBox.visibility = View.VISIBLE }
        }
        fun pickPage() {
            val pages = PreviewServer.pages(d)
            if (pages.size < 2) { Toast.makeText(this, "Is project mein sirf ek page hai.", Toast.LENGTH_SHORT).show(); return }
            AlertDialog.Builder(this).setTitle("Open page").setItems(pages.toTypedArray()) { _, i -> openPage(pages[i]) }.show()
        }
        val acts = LinearLayout(this).apply { setPadding(0, dp(6), 0, 0) }
        acts.addView(btn("▶ Preview") { showPrev() }, LinearLayout.LayoutParams(-2, dp(36)).apply { leftMargin = 0 })
        acts.addView(btn("⛶ Full screen") { dir = d; preview() })
        if (PreviewServer.pages(d).size > 1) acts.addView(btn("📄 Pages") { pickPage() })
        val filesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        for (n in files.keys) {
            val txt = files[n] ?: ""
            filesBox.addView(fileRow(n, (txt.count { it == '\n' } + 1).toString() + " lines  ·  " + sizeText(txt.toByteArray(Charsets.UTF_8).size), null,
                { viewFile(n, txt, txt.toByteArray(Charsets.UTF_8)) }, { saveFile(n, fileBytes(d, n)) }),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        }
        acts.addView(btn("📁 Files") { filesBox.visibility = if (filesBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE })
        acts.addView(btn("{ } Code") { showCode() })
        acts.addView(btn("🛠 Fix") { dir = d; fixErrors() })
        acts.addView(btn("↩ Undo") { dir = d; undoEdit() })
        acts.addView(btn("📦 Zip") { dir = d; exportZip() })
        card.addView(top)
        card.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(acts) })
        card.addView(filesBox, LinearLayout.LayoutParams(-1, -2))
        card.addView(codeBox, LinearLayout.LayoutParams(-1, -2))
        card.addView(prevBox, LinearLayout.LayoutParams(-1, dp(420)).apply { topMargin = dp(6) })
        logBox.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        if (open) {
            if (PreviewServer.entry(d) != null) showPrev() else showCode()
        }
        follower.toBottom()
    }

    private fun mime(n: String): String = when (n.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "css" -> "text/css"
        "js", "mjs" -> "application/javascript"
        "json" -> "application/json"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        else -> "text/plain"
    }

    /** A WebView that serves the project's files from https://app.local/ (so css/js/images link up). */
    private fun projectWebView(base: File): WebView {
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.mediaPlaybackRequiresUserGesture = false
        wv.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        wv.settings.javaScriptCanOpenWindowsAutomatically = true
        wv.setBackgroundColor(Color.WHITE)
        wv.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onConsoleMessage(m: android.webkit.ConsoleMessage?): Boolean {
                if (m != null && m.messageLevel() == android.webkit.ConsoleMessage.MessageLevel.ERROR && jsErrors.length < 3000)
                    jsErrors.append(m.message()).append(" (").append((m.sourceId() ?: "").substringAfterLast('/')).append(":").append(m.lineNumber()).append(")\n")
                return true
            }
        }
        wv.webViewClient = object : WebViewClient() {
            override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                if (request?.isForMainFrame == true) view?.loadData("<body style='font-family:sans-serif;padding:24px'><h3>Preview load nahi hua</h3><p>Is project ko server chahiye ho sakta hai. Code tab mein files dekhein.</p></body>", "text/html", "UTF-8")
            }
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                return PreviewServer.serve(base, u)
            }
        }
        return wv
    }

    // ---------- work ----------

    private fun go(kind: Int) {
        val t = input.text.toString().trim()
        if (t.isEmpty() || busy) return
        input.setText("")
        val att = attached
        attached = null
        attachChip.visibility = View.GONE
        val ask = if (att != null) "ATTACHED FILE: " + att.first + "\n```\n" + att.second + "\n```\n\n" + t else t
        addLog("u", ask)
        follower.toBottom(true)
        if (cur != null) show(null)
        setBusy(true)
        startLive()
        token++
        val my = token
        say(if (kind == 0) "Reading your question..." else "Working...")
        val d = dir
        val deep = getSharedPreferences("anjoo", MODE_PRIVATE).getBoolean("codeThink", true)
        val thoughts = StringBuilder()
        Thread {
            try {
                if (kind == 0) {
                    val ans = Coder.ask(this, d, ask, deep, { tt -> thoughts.append(tt).append("\n") })
                    ui.post { if (my != token) return@post; stopLive(); addLog("a", ans, thoughts.toString().trim()); say(""); setBusy(false) }
                } else if (d == null || kind == 2) {
                    val r = Coder.build(this, ask, "auto", true, deep, { tt -> thoughts.append(tt).append("\n\n") }) { s -> ui.post { if (my == token) say(s) } }
                    ui.post {
                        if (my != token) return@post
                        stopLive()
                        addChecksCard()
                        dir = r.first
                        setMode(1)
                        titleTv.text = Coder.name(r.first)
                        addLog("a", r.second, thoughts.toString().trim())
                        addChangesCard(r.first, createdList(r.first))
                        addProjectCard(r.first, true)
                        say(Coder.readFiles(r.first).size.toString() + " files ready")
                        setBusy(false); refreshTabs()
                    }
                } else {
                    Coder.snapshot(this, d)
                    val notes = Coder.revise(this, d, ask, deep, { tt -> thoughts.append(tt).append("\n\n") }) { s -> ui.post { if (my == token) say(s) } }
                    ui.post {
                        if (my != token) return@post
                        stopLive()
                        addChecksCard()
                        addLog("a", notes, thoughts.toString().trim())
                        addChangesCard(d, Coder.diffs(this, d))
                        addProjectCard(d, true)
                        say("Updated")
                        setBusy(false)
                        if (cur != null && !File(d, cur!!).exists()) cur = null
                        refreshTabs()
                        if (web?.visibility == View.VISIBLE) preview()
                    }
                }
            } catch (e: Exception) {
                ui.post { if (my != token) return@post; stopLive(); addLog("a", "Error: " + (e.message ?: e.javaClass.simpleName)); say(""); setBusy(false) }
            }
        }.start()
    }


    // ---------- attach a file / import a ZIP ----------

    private fun attachMenu() {
        AlertDialog.Builder(this).setTitle("Add")
            .setItems(arrayOf("📄  Attach a file (code, text, ZIP) to my message", "📦  Open a ZIP as a new project")) { _, i ->
                try {
                    startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), if (i == 0) 45 else 46)
                } catch (e: Exception) { Toast.makeText(this, "File picker nahi khul saka.", Toast.LENGTH_SHORT).show() }
            }.show()
    }

    private fun pickedName(uri: Uri): String {
        var name = "file"
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: "file"
            }
        } catch (e: Exception) {}
        return name
    }

    private fun handlePicked(req: Int, uri: Uri) {
        Toast.makeText(this, if (req == 45) "File parh raha hoon..." else "ZIP khol raha hoon...", Toast.LENGTH_SHORT).show()
        Thread {
            val name = pickedName(uri)
            val bytes = try { contentResolver.openInputStream(uri)?.use { it.readBytes() } } catch (e: Exception) { null }
            if (bytes == null || bytes.size > 25 * 1024 * 1024) {
                runOnUiThread { Toast.makeText(this, "File parhi nahi ja saki (ya 25 MB se bari hai).", Toast.LENGTH_LONG).show() }
                return@Thread
            }
            if (req == 46) {
                val d = Coder.importZip(this, bytes, name)
                runOnUiThread {
                    if (d == null) Toast.makeText(this, "ZIP mein koi text/code file nahi mili.", Toast.LENGTH_LONG).show()
                    else {
                        openProject(d)
                        val zc = cardBox()
                        zc.addView(fileRow(name, "ZIP  ·  " + Coder.readFiles(d).size + " files  ·  " + sizeText(bytes.size), "UPLOADED",
                            { AlertDialog.Builder(this).setTitle(name).setMessage(Coder.readFiles(d).keys.joinToString("\n")).setPositiveButton("Close", null).show() },
                            { saveFile(name, bytes) }, "📦"))
                        logBox.addView(zc, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
                        addLog("a", "ZIP project ban gaya: " + Coder.readFiles(d).size + " files. Ab badlav likhein, sawal poochein, ya 🐍 / ▶ se chalayein.")
                        follower.toBottom(true)
                    }
                }
            } else {
                val txt = Coder.attachmentText(name, bytes)
                runOnUiThread {
                    if (txt == null) Toast.makeText(this, "Ye file text/code/ZIP nahi lagti (PDF aur photo main chat mein lagayein).", Toast.LENGTH_LONG).show()
                    else {
                        attached = Pair(name, txt)
                        attachChip.text = fileIcon(name) + " " + name + "  ·  " + sizeText(txt.toByteArray(Charsets.UTF_8).size) + "  ·  ready to send  ✕"
                        attachChip.visibility = View.VISIBLE
                        input.requestFocus()
                    }
                }
            }
        }.start()
    }

    // ---------- Python and prompt helper ----------

    /** Runs the project's Python entry file inside the app and shows what it printed. */
    private fun runPython() {
        val d = dir
        if (d == null) { Toast.makeText(this, "Pehle project banayein.", Toast.LENGTH_SHORT).show(); return }
        val entry = PyRun.entry(d)
        if (entry == null) { Toast.makeText(this, "Is project mein Python (.py) file nahi hai.", Toast.LENGTH_LONG).show(); return }
        val syntax = PyRun.needsSyntaxOnly(d)
        Toast.makeText(this, "Python chal raha hai ($entry). Pehli baar runtime download hoga (internet chahiye).", Toast.LENGTH_LONG).show()
        Thread {
            val r = PyRun.run(this, d, entry, syntax)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                val sb = StringBuilder()
                if (syntax) sb.append("ℹ️ Is project mein aisi library hai (jaise tkinter, pygame, Flask) jo yahan chal nahi sakti, is liye sirf syntax check hua.\n\n")
                when {
                    !r.loaded -> sb.append("Python runtime load nahi hua. Internet check karke dobara koshish karein.")
                    !r.finished -> sb.append("Program waqt par khatam nahi hua (shayad endless loop ya input ka intezar).")
                    else -> {
                        if (r.out.isNotBlank()) sb.append(r.out.trim().take(6000))
                        if (r.err.isNotBlank()) sb.append(if (sb.isEmpty()) "" else "\n\n").append("⚠️ ").append(r.err.trim().takeLast(2500))
                        if (r.out.isBlank() && r.err.isBlank()) sb.append("✅ Chal gaya, koi error nahi (kuch print nahi hua).")
                    }
                }
                val tv = TextView(this).apply {
                    text = sb.toString(); typeface = Typeface.MONOSPACE; textSize = 12f
                    setTextColor(th.ink); setTextIsSelectable(true); setPadding(dp(16), dp(10), dp(16), dp(10))
                }
                val b = AlertDialog.Builder(this).setTitle("🐍 " + entry).setView(ScrollView(this).apply { addView(tv) })
                    .setPositiveButton("Close", null)
                if (r.finished && r.loaded && r.err.isNotBlank() && !busy) {
                    b.setNeutralButton("Fix with AI") { _, _ ->
                        input.setText("Python chalane par ye error aaya, root cause dhoond kar theek karo:\n" + r.err.trim().takeLast(1500))
                        go(1)
                    }
                }
                b.show()
            }
        }.start()
    }

    /** ✨ Turns the short request in the box into a precise engineering brief (the user can edit it before sending). */
    private fun enhanceInput() {
        if (busy) return
        val t = input.text.toString().trim()
        if (t.isEmpty()) { Toast.makeText(this, "Pehle thori si baat likhein, ✨ usay behtar prompt bana dega.", Toast.LENGTH_SHORT).show(); return }
        val d = dir
        val info = if (d != null) "Name: " + Coder.name(d) + "\nFiles: " + Coder.readFiles(d).keys.take(40).joinToString(", ") else ""
        Toast.makeText(this, "✨ Prompt behtar ho raha hai...", Toast.LENGTH_SHORT).show()
        Thread {
            val better = PromptMaker.improve(this, t, info)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (better.isBlank()) Toast.makeText(this, "Abhi behtar nahi ho saka (API key / internet check karein).", Toast.LENGTH_LONG).show()
                else if (input.text.toString().trim() == t) { input.setText(better); input.setSelection(input.text.length) }
            }
        }.start()
    }

    // ---------- preview and export ----------

    private fun preview() {
        val d = dir
        if (d == null) { Toast.makeText(this, "Pehle project banayein.", Toast.LENGTH_SHORT).show(); return }
        val entry = PreviewServer.entry(d)
        if (entry == null) { Toast.makeText(this, "Preview sirf web (HTML) projects ke liye hai.", Toast.LENGTH_LONG).show(); return }
        val w = web ?: projectWebView(d).also { area.addView(it, FrameLayout.LayoutParams(-1, -1)); web = it }
        logScroll.visibility = View.GONE
        codeWrap.visibility = View.GONE
        w.visibility = View.VISIBLE
        w.loadUrl("https://app.local/" + entry)
        say("Preview: " + entry)
    }

    private fun exportZip() {
        val d = dir
        if (d == null) { Toast.makeText(this, "Pehle project banayein.", Toast.LENGTH_SHORT).show(); return }
        val slug = Coder.name(d).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "project" }
        try {
            startActivityForResult(
                Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/zip").putExtra(Intent.EXTRA_TITLE, "$slug.zip"), 41
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Zip save nahi ho saka.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun exportHtml() {
        val d = dir
        if (d == null) { Toast.makeText(this, "Pehle project banayein.", Toast.LENGTH_SHORT).show(); return }
        if (PreviewServer.entry(d) == null) { Toast.makeText(this, "Ye web project nahi hai.", Toast.LENGTH_SHORT).show(); return }
        val slug = Coder.name(d).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "website" }
        try {
            startActivityForResult(
                Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("text/html").putExtra(Intent.EXTRA_TITLE, "$slug.html"), 44
            )
        } catch (e: Exception) { Toast.makeText(this, "Save nahi ho saka.", Toast.LENGTH_SHORT).show() }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if ((req == 45 || req == 46) && res == RESULT_OK) { data?.data?.let { handlePicked(req, it) }; return }
        if (req == 47) {
            val ps = pendingSave; pendingSave = null
            val u = data?.data
            if (res == RESULT_OK && u != null && ps != null) {
                try { contentResolver.openOutputStream(u)?.use { it.write(ps.second) }; Toast.makeText(this, "Saved ✅  " + ps.first, Toast.LENGTH_SHORT).show() }
                catch (e: Exception) { Toast.makeText(this, "Save nahi ho saka.", Toast.LENGTH_SHORT).show() }
            }
            return
        }
        if ((req != 41 && req != 44) || res != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        val d = dir ?: return
        try {
            val bytes = if (req == 41) Coder.zip(d) else (PreviewServer.inline(d) ?: "").toByteArray(Charsets.UTF_8)
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            Toast.makeText(this, "Saved ✅", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Save nahi ho saka.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        if (side?.isOpen == true) { side?.close(); return }
        val w = web
        if (w != null && w.visibility == View.VISIBLE) { show(cur); return }
        if (cur != null) { show(null); return }
        super.onBackPressed()
    }
}
