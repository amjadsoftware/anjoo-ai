package com.anjoo.assistant

import android.content.Context
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * project_debug: from "it failed" to "this line, with these values".
 *
 *  diagnose ..... paste any error output (Python/Node/Java/Kotlin/C/C++/Go/Rust/PHP/Ruby/TypeScript stack traces and compiler
 *                 errors, run_code or Gradle output): every file:line is mapped to the project file and shown with its
 *                 surrounding source lines
 *  inspect ...... Python projects: runs the program on the phone and, when it crashes, prints the local variables of every
 *                 project frame; breakpoints=["main.py:12"] (optional condition=) records the variables each time the line
 *                 runs (non-interactive breakpoints: up to 20 hits)
 *  build_log .... the latest cloud APK build (HS APK builder, GitHub Actions): the failing step's errors, mapped to source lines
 *  logcat ....... this app's own Android log (an app can only read its own log, not other apps')
 *
 * Not possible here: stepping, attaching to other processes, native debuggers.
 */
object Debug {

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build()
    }

    class Frame(val path: String, val line: Int, val col: Int, val text: String)

    // ============================================================ parsing (pure)

    private val PY = Regex("File \"([^\"]+)\", line (\\d+)")
    private val PAREN = Regex("\\(([^()\\s]+\\.\\w{1,5}):(\\d+)(?::(\\d+))?\\)")
    private val PLAIN = Regex("(?:^|[\\s>])((?:[A-Za-z]:)?[\\w./\\\\@$-]*\\w\\.\\w{1,5}):(\\d+)(?::(\\d+))?(?=[:\\s,]|$)")
    private val TSC = Regex("([\\w./\\\\-]+\\.tsx?)\\((\\d+),(\\d+)\\)")
    private val KT = Regex("([\\w./\\\\-]+\\.kts?): \\((\\d+), (\\d+)\\)")
    private val PHP = Regex("in (\\S+\\.php) on line (\\d+)")
    private val RUBY_IN = Regex("([\\w./-]+\\.rb):(\\d+):in ")

    fun parseFrames(output: String): List<Frame> {
        val text = output.replace("file://", "").replace("\r\n", "\n")
        val frames = ArrayList<Frame>()
        val lines = text.split("\n")
        val traceback = text.contains("Traceback (most recent call last)")
        for (raw in lines) {
            val line = raw.replace(Regex("^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z "), "")
            val found = ArrayList<Frame>()
            PY.find(line)?.let { found.add(Frame(it.groupValues[1], it.groupValues[2].toInt(), 0, line.trim())) }
            if (found.isEmpty()) KT.find(line)?.let { found.add(Frame(it.groupValues[1], it.groupValues[2].toInt(), it.groupValues[3].toInt(), line.trim())) }
            if (found.isEmpty()) TSC.find(line)?.let { found.add(Frame(it.groupValues[1], it.groupValues[2].toInt(), it.groupValues[3].toInt(), line.trim())) }
            if (found.isEmpty()) PHP.find(line)?.let { found.add(Frame(it.groupValues[1], it.groupValues[2].toInt(), 0, line.trim())) }
            if (found.isEmpty()) RUBY_IN.find(line)?.let { found.add(Frame(it.groupValues[1], it.groupValues[2].toInt(), 0, line.trim())) }
            if (found.isEmpty()) for (m in PAREN.findAll(line)) found.add(Frame(m.groupValues[1], m.groupValues[2].toInt(), m.groupValues[3].toIntOrNull() ?: 0, line.trim()))
            if (found.isEmpty()) for (m in PLAIN.findAll(line)) found.add(Frame(m.groupValues[1], m.groupValues[2].toInt(), m.groupValues[3].toIntOrNull() ?: 0, line.trim()))
            frames.addAll(found)
        }
        val unique = frames.distinctBy { it.path + ":" + it.line }
        return if (traceback) unique.reversed() else unique
    }

    private val GENERIC_NAMES = setOf("script", "main", "prog", "program", "source", "solution", "code", "box", "input", "a")

    /** The project file a path from an error message points to, or null. */
    fun resolve(path: String, known: Collection<String>): String? {
        val p = path.replace('\\', '/').removePrefix("./")
        if (p in known) return p
        val parts = p.split('/').filter { it.isNotEmpty() }
        for (n in minOf(parts.size, 6) downTo 1) {
            val suffix = parts.takeLast(n).joinToString("/")
            val hits = known.filter { it == suffix || it.endsWith("/$suffix") }
            if (hits.size == 1) return hits[0]
            if (hits.size > 1 && n == minOf(parts.size, 6)) return null
        }
        val base = parts.lastOrNull() ?: return null
        val ext = base.substringAfterLast('.', "")
        if (base.substringBeforeLast('.').lowercase() in GENERIC_NAMES && ext.isNotEmpty()) {
            val same = known.filter { it.endsWith(".$ext") && !it.contains("test", true) }
            if (same.size == 1) return same[0]
        }
        return null
    }

    /** Last line that names an error (exception, "error:", Gradle failure), or "". */
    fun headline(output: String): String {
        val lines = output.replace("\r\n", "\n").split("\n").map { it.trim() }.filter { it.isNotEmpty() }
        val pat = Regex("^(?:[\\w.$]+\\.)?\\w*(?:Error|Exception|Failure|Panic)\\b.*|.*\\b(?:error|fatal error|panic|FAILED|Cannot find symbol|undefined reference)\\b.*", RegexOption.IGNORE_CASE)
        return lines.lastOrNull { pat.matches(it) && !it.startsWith("File \"") && !it.startsWith("at ") }?.take(240) ?: ""
    }

    fun diagnose(files: Map<String, String>, output: String, maxFrames: Int = 6, context: Int = 4): String {
        if (output.isBlank()) return "Give output= (the error text from run_code, project_check, a stack trace or a build log)."
        val head = headline(output)
        val used = LinkedHashMap<String, Frame>()
        for (f in parseFrames(output)) {
            val p = resolve(f.path, files.keys) ?: continue
            val total = files[p]!!.split("\n").size
            if (f.line < 1 || f.line > total) continue
            used.putIfAbsent(p + ":" + f.line, Frame(p, f.line, f.col, f.text))
            if (used.size >= maxFrames) break
        }
        val sb = StringBuilder()
        if (head.isNotEmpty()) sb.append("ERROR: ").append(head).append('\n')
        if (used.isEmpty()) return sb.append("No file:line in this output points to a file of this project (library or system frames only, or an unsupported format). Use project_code action=locate or project_search with the message text.").toString().trim()
        sb.append(used.size).append(" location(s) in project files").append(if (output.contains("Traceback (most recent call last)")) " (innermost first)" else "").append(":\n")
        var n = 0
        for ((_, f) in used) {
            n++
            val ls = files[f.path]!!.split("\n")
            sb.append('\n').append(n).append(". ").append(f.path).append(':').append(f.line).append(if (f.col > 0) ":" + f.col else "").append('\n')
            for (k in maxOf(1, f.line - context)..minOf(ls.size, f.line + context))
                sb.append(if (k == f.line) " >> " else "    ").append(String.format(java.util.Locale.US, "%4d | ", k)).append(ls[k - 1].take(180)).append('\n')
        }
        sb.append("\nFix the source at the marked line (read more with project_read offset=...), then run again. Do not claim it is fixed until the run/check output is clean.")
        return sb.toString().trim()
    }

    /** Error-relevant lines of a CI / Gradle build log (timestamps stripped); the log tail when nothing matches. */
    fun buildErrors(log: String, max: Int = 45): String {
        val lines = log.replace("\r\n", "\n").split("\n").map { it.replace(Regex("^\\d{4}-\\d\\d-\\d\\dT[\\d:.]+Z "), "").trimEnd() }
        val out = LinkedHashSet<String>()
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            val hit = Regex("^e: |^error: |\\berror:|FAILURE: Build failed|Execution failed for task|Could not resolve|AAPT: error|Unresolved reference|Task :.*FAILED|Compilation error|cannot find symbol|BUILD FAILED|Duplicate class|Manifest merger failed", RegexOption.IGNORE_CASE).containsMatchIn(l)
            if (l.contains("* What went wrong:")) { for (k in i until minOf(lines.size, i + 5)) out.add(lines[k]); i += 5; continue }
            if (hit) out.add(l.take(300))
            i++
            if (out.size >= max) break
        }
        if (out.isEmpty()) return lines.filter { it.isNotBlank() }.takeLast(30).joinToString("\n")
        return out.joinToString("\n")
    }

    // ============================================================ inspect (Python)

    private const val DEBUG_PY = """
import sys, os, json, runpy, traceback
CFG = json.loads(CONFIG_JSON)
ROOT = '/proj'
BPS = {}
for b in CFG.get('breakpoints', []):
    BPS.setdefault((b['file'], b['line']), b.get('condition', ''))
HITS = []
def fmt(v):
    try:
        r = repr(v)
    except Exception:
        r = '<unprintable>'
    return r if len(r) <= 140 else r[:137] + '...'
def locs(frame):
    d = {}
    for k, v in list(frame.f_locals.items())[:30]:
        if k.startswith('__') or isinstance(v, type(os)):
            continue
        d[k] = fmt(v)
    return d
def rel(fn):
    try:
        if fn.startswith('<'):
            return None
        fn = os.path.abspath(fn)
        return os.path.relpath(fn, ROOT) if fn.startswith(ROOT + '/') else None
    except Exception:
        return None
def local_trace(frame, event, arg):
    if event == 'line':
        r = rel(frame.f_code.co_filename)
        key = (r, frame.f_lineno)
        if key in BPS and len(HITS) < 20:
            cond = BPS[key]
            ok = True
            if cond:
                try:
                    ok = bool(eval(cond, frame.f_globals, frame.f_locals))
                except Exception:
                    ok = False
            if ok:
                HITS.append({'file': r, 'line': frame.f_lineno, 'func': frame.f_code.co_name, 'vars': locs(frame)})
    return local_trace
def global_trace(frame, event, arg):
    if event == 'call' and rel(frame.f_code.co_filename) is not None:
        return local_trace
    return None
CRASH = []
if BPS:
    sys.settrace(global_trace)
try:
    runpy.run_path(CFG['entry'], run_name='__main__')
except SystemExit:
    pass
except BaseException as ex:
    sys.settrace(None)
    tb = ex.__traceback__
    frames = []
    while tb is not None:
        r = rel(tb.tb_frame.f_code.co_filename)
        if r is not None:
            frames.append({'file': r, 'line': tb.tb_lineno, 'func': tb.tb_frame.f_code.co_name, 'vars': locs(tb.tb_frame)})
        tb = tb.tb_next
    CRASH = {'type': type(ex).__name__, 'msg': str(ex)[:300], 'frames': frames}
sys.settrace(None)
print('@@ANJOO_DEBUG@@' + json.dumps({'hits': HITS, 'crash': CRASH}))
"""

    /** Debug report text from the JSON the wrapper printed; [stdout] is everything the program printed before it. */
    fun formatInspect(stdout: String, stderr: String, files: Map<String, String>): String {
        val marker = "@@ANJOO_DEBUG@@"
        val at = stdout.lastIndexOf(marker)
        val program = (if (at >= 0) stdout.substring(0, at) else stdout).trim()
        val report = if (at >= 0) try { JSONObject(stdout.substring(at + marker.length).trim()) } catch (_: Exception) { null } else null
        val sb = StringBuilder()
        if (report == null) {
            sb.append("The debug run did not complete.\n")
            if (stderr.isNotBlank()) sb.append(stderr.trim().takeLast(1500)).append('\n')
            return sb.toString().trim()
        }
        val hits = report.optJSONArray("hits") ?: JSONArray()
        for (i in 0 until hits.length()) {
            val h = hits.optJSONObject(i) ?: continue
            sb.append("BREAKPOINT HIT ").append(i + 1).append(": ").append(h.optString("file")).append(':').append(h.optInt("line")).append(" in ").append(h.optString("func")).append('\n')
            appendVars(sb, h.optJSONObject("vars"))
        }
        val crash = report.optJSONObject("crash")
        if (crash != null && crash.has("type")) {
            sb.append("CRASH: ").append(crash.optString("type")).append(": ").append(crash.optString("msg")).append('\n')
            val fr = crash.optJSONArray("frames") ?: JSONArray()
            for (i in fr.length() - 1 downTo 0) {
                val f = fr.optJSONObject(i) ?: continue
                val p = f.optString("file"); val ln = f.optInt("line")
                sb.append(if (i == fr.length() - 1) "  innermost: " else "  called from: ").append(p).append(':').append(ln).append(" in ").append(f.optString("func")).append('\n')
                files[p]?.split("\n")?.getOrNull(ln - 1)?.let { sb.append("    > ").append(it.trim().take(160)).append('\n') }
                appendVars(sb, f.optJSONObject("vars"))
            }
        } else if (hits.length() == 0) sb.append("The program finished without an exception and no breakpoint was reached.\n")
        if (program.isNotEmpty()) sb.append("\nProgram output:\n").append(program.takeLast(1500)).append('\n')
        return sb.toString().trim()
    }

    private fun appendVars(sb: StringBuilder, vars: JSONObject?) {
        if (vars == null || vars.length() == 0) { sb.append("    (no local variables)\n"); return }
        for (k in vars.keys()) sb.append("    ").append(k).append(" = ").append(vars.optString(k)).append('\n')
    }

    // ============================================================ tool entry

    fun run(ctx: Context, a: JSONObject, find: () -> Pair<File?, String>): String {
        val action = a.optString("action", "diagnose").trim().lowercase().replace('-', '_').replace(' ', '_')
        if (action == "logcat" || action == "log") return logcat(a)
        val (dir, err) = find()
        if (dir == null) return err
        val files = try { Coder.readFiles(dir) } catch (_: Exception) { emptyMap() }
        return try {
            when (action) {
                "diagnose", "explain_error", "map_error", "trace" -> diagnose(files, a.optString("output", a.optString("error", a.optString("text", ""))))
                "inspect", "breakpoint", "breakpoints", "variables", "debug" -> inspect(ctx, dir, files, a)
                "build_log", "apk_log", "build_error" -> buildLog(ctx, files, a)
                else -> "project_debug action chunein: diagnose, inspect, build_log, logcat."
            }
        } catch (e: CancelledException) { throw e
        } catch (e: java.io.IOException) { "Debug nakam: network problem (" + (e.message ?: "io") + ")."
        }
    }

    private fun inspect(ctx: Context, dir: File, files: Map<String, String>, a: JSONObject): String {
        val entry = a.optString("entry", "").trim().ifEmpty { PyRun.entry(dir) ?: "" }
        if (entry.isEmpty() || !entry.endsWith(".py")) return "inspect works for Python projects (a .py entry file). For other languages run with run_code and use action=diagnose on its error output."
        if (PyRun.needsSyntaxOnly(dir)) return "This project uses libraries the phone's Python cannot run (tkinter, flask, pygame ...), so it cannot be run here; use action=diagnose with the error from where it runs."
        val bps = JSONArray()
        val raw = a.opt("breakpoints")
        val list = ArrayList<String>()
        if (raw is JSONArray) for (i in 0 until raw.length()) list.add(raw.optString(i)) else if (raw is String) list.addAll(raw.split(',', ' ').filter { it.isNotBlank() })
        for (b in list) {
            val file = b.substringBeforeLast(':').trim(); val line = b.substringAfterLast(':').trim().toIntOrNull() ?: return "breakpoints: use \"file.py:12\" (got \"$b\")."
            val path = resolve(file, files.keys) ?: return "breakpoints: no project file matches \"$file\"."
            bps.put(JSONObject().put("file", path).put("line", line).put("condition", a.optString("condition", "")))
        }
        val cfg = JSONObject().put("entry", entry).put("breakpoints", bps)
        val runner = "_anjoo_debug.py"
        Coder.writeFile(dir, runner, "CONFIG_JSON = " + JSONObject.quote(cfg.toString()) + "\n" + DEBUG_PY)
        try {
            val r = PyRun.run(ctx, dir, runner, false, 70000, 60000)
            if (!r.loaded) return "The Python runtime did not load (internet is needed the first time)."
            if (!r.finished) return "The program did not finish in 60 seconds (endless loop or waiting for input?). Add a breakpoint inside the loop, or reduce the work."
            return "DEBUG RUN of $entry\n" + formatInspect(r.out, r.err, files).take(7000)
        } finally { File(dir, runner).delete() }
    }

    private fun buildLog(ctx: Context, files: Map<String, String>, a: JSONObject): String {
        val prefs = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val repo = a.optString("repo", "").ifBlank { prefs.getString("hs_apk_github_repo", "").orEmpty() }.trim()
        var token = ""
        try {
            val enc = prefs.getString("hs_apk_github_token", null)
            if (enc != null) token = (Crypt.decrypt(ctx, android.util.Base64.decode(enc, android.util.Base64.DEFAULT)) ?: ByteArray(0)).toString(Charsets.UTF_8)
        } catch (_: Exception) {}
        if (token.isBlank()) token = GitHubPages.token(ctx)
        if (repo.isEmpty() || token.isBlank()) return "No APK build repository/token saved yet. Build once from the APK builder (HS) first; this reads the logs of that build."
        fun get(url: String): Pair<Int, String> {
            Cancel.check()
            val req = Request.Builder().url(url).header("Authorization", "Bearer $token").header("Accept", "application/vnd.github+json").header("X-GitHub-Api-Version", "2022-11-28").build()
            return http.newCall(req).execute().use { Pair(it.code, it.body?.string().orEmpty()) }
        }
        val runs = get("https://api.github.com/repos/$repo/actions/workflows/hs-build-apk.yml/runs?per_page=1")
        if (runs.first != 200) return "GitHub answered ${runs.first} for $repo (check the token and repository)."
        val run = JSONObject(runs.second).optJSONArray("workflow_runs")?.optJSONObject(0) ?: return "No APK build run found in $repo."
        val status = run.optString("status"); val concl = run.optString("conclusion")
        if (status != "completed") return "The latest build is still $status. Try again when it has finished: " + run.optString("html_url")
        if (concl == "success") return "The latest APK build succeeded (nothing to debug): " + run.optString("html_url")
        val jobs = get("https://api.github.com/repos/$repo/actions/runs/" + run.optLong("id") + "/jobs")
        val ja = JSONObject(jobs.second).optJSONArray("jobs") ?: JSONArray()
        var job: JSONObject? = null
        for (i in 0 until ja.length()) { val j = ja.optJSONObject(i) ?: continue; if (j.optString("conclusion") == "failure") { job = j; break } }
        if (job == null) return "The build $concl but no failed job was reported: " + run.optString("html_url")
        var failedStep = ""
        val steps = job.optJSONArray("steps") ?: JSONArray()
        for (i in 0 until steps.length()) { val s = steps.optJSONObject(i) ?: continue; if (s.optString("conclusion") == "failure") { failedStep = s.optString("name"); break } }
        val log = get("https://api.github.com/repos/$repo/actions/jobs/" + job.optLong("id") + "/logs")
        if (log.first != 200) return "Build failed in step \"$failedStep\" but the log could not be read (GitHub ${log.first}). Open: " + run.optString("html_url")
        val errors = buildErrors(log.second)
        val mapped = diagnose(files, errors)
        return "APK BUILD FAILED" + (if (failedStep.isNotEmpty()) " in step \"$failedStep\"" else "") + " (" + run.optString("html_url") + ")\n\nERROR LINES:\n" + errors.take(3500) +
            (if (mapped.contains("location(s)")) "\n\n" + mapped.substringAfter("\n", mapped).take(3000) else "")
    }

    private fun logcat(a: JSONObject): String {
        val n = a.optInt("lines", 200).coerceIn(20, 1000)
        val level = a.optString("level", "").trim().uppercase().take(1).takeIf { it in setOf("V", "D", "I", "W", "E", "F") } ?: ""
        val filter = a.optString("filter", "").trim()
        val cmd = ArrayList<String>(listOf("logcat", "-d", "-t", n.toString()))
        if (level.isNotEmpty()) { cmd.add("*:$level") }
        val out = try {
            val p = ProcessBuilder(cmd).redirectErrorStream(true).start()
            val t = p.inputStream.bufferedReader().readText()
            p.waitFor(5, TimeUnit.SECONDS); t
        } catch (e: Exception) { return "Could not read the log: " + (e.message ?: "error") }
        var lines = out.lines().filter { it.isNotBlank() && !it.startsWith("---------") }
        if (filter.isNotEmpty()) lines = lines.filter { it.contains(filter, true) }
        if (lines.isEmpty()) return "No log lines" + (if (filter.isNotEmpty()) " containing \"$filter\"" else "") + ". Note: an app can only read its own log; other apps' crashes are not visible."
        return "Android log of this app (newest last, " + lines.size + " lines; other apps' logs are not readable):\n" + lines.takeLast(120).joinToString("\n") { it.take(240) }.takeLast(7000)
    }
}
