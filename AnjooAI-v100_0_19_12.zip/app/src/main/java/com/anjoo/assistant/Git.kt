package com.anjoo.assistant

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.security.MessageDigest
import java.util.concurrent.TimeUnit
import java.util.zip.ZipInputStream

/**
 * project_git: real Git on a Code Studio project, through the GitHub API (a phone has no git binary).
 *
 * What it keeps: a small state file (.anjoo-git.json) in the project folder with the repository, the branch, the
 * commit the project is based on, and the Git blob id of every tracked file. A blob id is the real Git hash, so
 * "what changed" is computed exactly like git does it, without storing a second copy of the files.
 *
 *  clone / init  .... get a repository into a project, or turn a project into a new repository
 *  status / diff .... what changed since the last commit or pull (also tells when the remote has newer commits)
 *  commit (= push) .. one real commit on the current branch (there is no local-only commit; it goes straight to GitHub)
 *  pull / checkout .. 3-way merge: your edits stay, remote edits come in, real conflicts get markers
 *  branch / log / pr / prs / pr_merge
 *
 * Limits: no history rewrite (rebase, amend, force push), executable bits and symlinks are not kept, files over
 * 25 MB are not handled. Pushes are refused when a changed file looks like it holds a secret (override: allow_secrets).
 */
object Git {

    private const val API = "https://api.github.com"
    const val STATE = ".anjoo-git.json"
    private val JSON = "application/json".toMediaType()
    private const val MAX_FILE = 25L * 1024 * 1024
    private const val MAX_TOTAL = 80L * 1024 * 1024
    private const val MAX_FILES = 3000
    private const val INLINE_MAX = 1024 * 1024
    private const val CAP = 6000
    private val ALWAYS_SKIP = setOf("node_modules", ".git", "__pycache__", ".gradle", ".idea", "venv", ".venv", "__MACOSX")

    private val http: OkHttpClient by lazy {
        OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(90, TimeUnit.SECONDS).writeTimeout(90, TimeUnit.SECONDS).build()
    }

    const val MARK_LOCAL = "<<<<<<< local"
    const val MARK_REMOTE = ">>>>>>> remote"

    // ============================================================ pure helpers (unit tested)

    /** The real Git blob id (what `git hash-object` prints) of [bytes]. */
    fun blobSha(bytes: ByteArray): String {
        val md = MessageDigest.getInstance("SHA-1")
        md.update(("blob " + bytes.size + "\u0000").toByteArray(Charsets.UTF_8))
        md.update(bytes)
        return hex(md.digest())
    }

    private fun hex(b: ByteArray): String = b.joinToString("") { String.format("%02x", it) }

    private fun fileSha(f: File): String {
        val md = MessageDigest.getInstance("SHA-1")
        md.update(("blob " + f.length() + "\u0000").toByteArray(Charsets.UTF_8))
        f.inputStream().use { s ->
            val buf = ByteArray(64 * 1024)
            while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        return hex(md.digest())
    }

    /** "owner/name", "https://github.com/owner/name(.git)" or "git@github.com:owner/name.git" -> (owner, name). */
    fun parseRepo(raw: String): Pair<String, String>? {
        var s = raw.trim().removeSuffix("/")
        s = s.removePrefix("git@github.com:")
        s = s.replace(Regex("^(https?://)?(www\\.)?github\\.com/"), "")
        val parts = s.split('/').filter { it.isNotEmpty() }
        if (parts.size < 2) return null
        val ok = Regex("^[A-Za-z0-9_.-]+$")
        val owner = parts[0]
        val name = parts[1].removeSuffix(".git")
        return if (ok.matches(owner) && ok.matches(name) && name.isNotEmpty()) Pair(owner, name) else null
    }

    private fun globToRegex(g: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < g.length) {
            val c = g[i]
            if (c == '*' && i + 1 < g.length && g[i + 1] == '*') {
                if (i + 2 < g.length && g[i + 2] == '/') { sb.append("(?:.*/)?"); i += 3 } else { sb.append(".*"); i += 2 }
                continue
            }
            when (c) {
                '*' -> sb.append("[^/]*")
                '?' -> sb.append("[^/]")
                else -> sb.append(Regex.escape(c.toString()))
            }
            i++
        }
        return sb.toString()
    }

    /** A small .gitignore: names, *.ext, dir/, /rooted, dir/file and ** patterns. Negation (!) lines are ignored. */
    class Ignore(lines: List<String>) {
        private val rules: List<Regex> = lines.map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") && !it.startsWith("!") }
            .map { raw ->
                val dirOnly = raw.endsWith("/")
                var p = raw.trimEnd('/')
                val anchored = p.startsWith("/") || p.contains('/')
                p = p.trimStart('/')
                val body = globToRegex(p)
                val tail = if (dirOnly) "/.*" else "(?:/.*)?"
                Regex((if (anchored) "^" else "^(?:.*/)?") + body + tail + "$")
            }
        fun matches(rel: String): Boolean = rules.any { it.matches(rel) }
    }

    class Status(val added: List<String>, val modified: List<String>, val deleted: List<String>) {
        val clean: Boolean get() = added.isEmpty() && modified.isEmpty() && deleted.isEmpty()
        val total: Int get() = added.size + modified.size + deleted.size
    }

    /** [base] = path -> blob id at the last commit/pull, [local] = path -> blob id on disk now. */
    fun status(base: Map<String, String>, local: Map<String, String>): Status {
        val added = local.keys.filter { it !in base }.sorted()
        val modified = local.keys.filter { base[it] != null && base[it] != local[it] }.sorted()
        val deleted = base.keys.filter { it !in local }.sorted()
        return Status(added, modified, deleted)
    }

    class PullPlan(val take: List<String>, val remove: List<String>, val conflicts: List<String>)

    /**
     * 3-way decision for every path. A path stays as it is when the remote did not change it or when both sides now
     * have the same thing. When only the remote changed it, the remote version is taken (or the file removed).
     * When both changed it differently, it is a conflict.
     */
    fun planPull(base: Map<String, String>, local: Map<String, String>, remote: Map<String, String>): PullPlan {
        val take = ArrayList<String>(); val remove = ArrayList<String>(); val conflicts = ArrayList<String>()
        for (p in (base.keys + local.keys + remote.keys).toSortedSet()) {
            val b = base[p]; val l = local[p]; val r = remote[p]
            if (r == b) continue
            if (l == r) continue
            if (l == b) { if (r == null) remove.add(p) else take.add(p) } else conflicts.add(p)
        }
        return PullPlan(take, remove, conflicts)
    }

    fun conflictText(local: String, remote: String): String =
        MARK_LOCAL + "\n" + local.trimEnd('\n') + "\n=======\n" + remote.trimEnd('\n') + "\n" + MARK_REMOTE + "\n"

    fun hasConflictMarkers(text: String): Boolean {
        val lines = text.split("\n")
        return lines.any { it.startsWith(MARK_LOCAL) } && lines.any { it.startsWith(MARK_REMOTE) }
    }

    private val SECRET_FILE = Regex("(?i)(^|/)(\\.env(\\.[^/]*)?|keys\\.properties|signing\\.properties|local\\.properties|[^/]*\\.(jks|keystore|p12|pfx|pem)|id_rsa|id_ed25519)$")
    private val SAFE_FILE = Regex("(?i)(example|sample|template)")
    private val SECRET_PATTERNS = listOf(
        "GitHub token" to Regex("\\bgh[pousr]_[A-Za-z0-9]{30,}|\\bgithub_pat_[A-Za-z0-9_]{40,}"),
        "AWS access key" to Regex("\\bAKIA[0-9A-Z]{16}\\b"),
        "private key" to Regex("-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----"),
        "Google API key" to Regex("\\bAIza[0-9A-Za-z_-]{35}"),
        "AI provider key" to Regex("\\bsk-(?:ant-|proj-)?[A-Za-z0-9_-]{32,}"),
        "Slack token" to Regex("\\bxox[baprs]-[A-Za-z0-9-]{10,}"),
        "key/password assigned in code" to Regex("(?i)(?:api[_-]?key|secret|password|passwd|token)\\s*[:=]\\s*[\"'][A-Za-z0-9_\\-/+=]{20,}[\"']")
    )

    /** What looks like a secret in this file (never the secret itself). [text] is null for binary files. */
    fun secretHits(path: String, text: String?): List<String> {
        val out = ArrayList<String>()
        val name = path.substringAfterLast('/')
        if (SECRET_FILE.containsMatchIn(path) && !SAFE_FILE.containsMatchIn(name)) out.add("secret-type file name")
        if (text != null) for ((label, re) in SECRET_PATTERNS) if (re.containsMatchIn(text)) out.add(label)
        if (text != null) for (hit in SecretScan.scan(path, text)) if (hit.kind != "secret-type file" && hit.kind !in out) out.add(hit.kind)
        return out
    }

    /** A short unified diff (3 lines of context). Falls back to a plain summary for very large changes. */
    fun unifiedDiff(path: String, old: String, new: String, context: Int = 3, maxLines: Int = 160): String {
        val a = old.split("\n"); val b = new.split("\n")
        var pre = 0
        while (pre < a.size && pre < b.size && a[pre] == b[pre]) pre++
        var suf = 0
        while (suf < a.size - pre && suf < b.size - pre && a[a.size - 1 - suf] == b[b.size - 1 - suf]) suf++
        val am = a.subList(pre, a.size - suf); val bm = b.subList(pre, b.size - suf)
        val ops = ArrayList<Pair<Char, String>>()
        for (i in 0 until pre) ops.add(Pair(' ', a[i]))
        if (am.size.toLong() * bm.size > 2_000_000L) {
            for (s in am) ops.add(Pair('-', s))
            for (s in bm) ops.add(Pair('+', s))
        } else {
            val n = am.size; val m = bm.size
            val dp = Array(n + 1) { IntArray(m + 1) }
            for (i in n - 1 downTo 0) for (j in m - 1 downTo 0)
                dp[i][j] = if (am[i] == bm[j]) dp[i + 1][j + 1] + 1 else maxOf(dp[i + 1][j], dp[i][j + 1])
            var i = 0; var j = 0
            while (i < n && j < m) {
                if (am[i] == bm[j]) { ops.add(Pair(' ', am[i])); i++; j++ }
                else if (dp[i + 1][j] >= dp[i][j + 1]) { ops.add(Pair('-', am[i])); i++ }
                else { ops.add(Pair('+', bm[j])); j++ }
            }
            while (i < n) { ops.add(Pair('-', am[i])); i++ }
            while (j < m) { ops.add(Pair('+', bm[j])); j++ }
        }
        for (i in a.size - suf until a.size) ops.add(Pair(' ', a[i]))

        val oldNo = IntArray(ops.size); val newNo = IntArray(ops.size)
        var o = 1; var nn = 1
        for ((k, op) in ops.withIndex()) {
            oldNo[k] = o; newNo[k] = nn
            if (op.first != '+') o++
            if (op.first != '-') nn++
        }
        val changed = ops.indices.filter { ops[it].first != ' ' }
        if (changed.isEmpty()) return ""
        // merge the changed positions, widened by the context, into hunks
        val hunks = ArrayList<IntRange>()
        var s = maxOf(0, changed[0] - context); var e = minOf(ops.size - 1, changed[0] + context)
        for (c in changed.drop(1)) {
            val cs = maxOf(0, c - context); val ce = minOf(ops.size - 1, c + context)
            if (cs <= e + 1) e = maxOf(e, ce) else { hunks.add(s..e); s = cs; e = ce }
        }
        hunks.add(s..e)
        val sb = StringBuilder("--- a/").append(path).append("\n+++ b/").append(path).append("\n")
        var lines = 0
        for (h in hunks) {
            val oc = h.count { ops[it].first != '+' }; val nc = h.count { ops[it].first != '-' }
            sb.append("@@ -").append(oldNo[h.first]).append(',').append(oc).append(" +").append(newNo[h.first]).append(',').append(nc).append(" @@\n")
            for (k in h) {
                if (lines++ >= maxLines) return sb.append("... (diff cut)\n").toString()
                sb.append(ops[k].first).append(ops[k].second).append('\n')
            }
        }
        return sb.toString()
    }

    // ============================================================ state on disk

    class State(var owner: String, var repo: String, var branch: String, var defaultBranch: String, var base: String, var files: MutableMap<String, String>) {
        val slug get() = "$owner/$repo"
    }

    private fun loadState(dir: File): State? = try {
        val o = JSONObject(File(dir, STATE).readText(Charsets.UTF_8))
        val f = o.optJSONObject("files") ?: JSONObject()
        val map = LinkedHashMap<String, String>()
        for (k in f.keys()) map[k] = f.optString(k)
        State(o.getString("owner"), o.getString("repo"), o.optString("branch", "main"), o.optString("default", "main"), o.optString("base"), map)
    } catch (_: Exception) { null }

    private fun saveState(dir: File, s: State) {
        val f = JSONObject()
        for ((k, v) in s.files) f.put(k, v)
        val o = JSONObject().put("owner", s.owner).put("repo", s.repo).put("branch", s.branch).put("default", s.defaultBranch).put("base", s.base).put("files", f)
        File(dir, STATE).writeText(o.toString(), Charsets.UTF_8)
        dir.setLastModified(System.currentTimeMillis())
    }

    /** path -> blob id of the working files. Tracked files are always included, even when .gitignore would hide them. */
    fun scan(dir: File, tracked: Map<String, String>): Map<String, String> {
        val ign = Ignore(try { File(dir, ".gitignore").readLines() } catch (_: Exception) { emptyList() })
        val out = java.util.TreeMap<String, String>()
        dir.walkTopDown().onEnter { it == dir || it.name !in ALWAYS_SKIP }.forEach { f ->
            if (!f.isFile || f.name.startsWith(".anjoo")) return@forEach
            val rel = f.relativeTo(dir).path.replace('\\', '/')
            val isTracked = tracked.containsKey(rel)
            if (!isTracked && ign.matches(rel)) return@forEach
            if (f.length() > MAX_FILE || (out.size >= MAX_FILES && !isTracked)) { tracked[rel]?.let { out[rel] = it }; return@forEach }
            out[rel] = fileSha(f)
        }
        return out
    }

    private fun cleanRel(p: String): String? {
        val parts = p.replace('\\', '/').split('/').filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty() || parts.size > 20 || parts.any { it == ".." || it == ".git" } || parts.last().startsWith(".anjoo")) return null
        return parts.joinToString("/")
    }

    private fun decodeText(bytes: ByteArray): String? {
        if (bytes.any { it.toInt() == 0 }) return null
        return try {
            Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString()
        } catch (_: Exception) { null }
    }

    private fun cap(s: String, n: Int = CAP) = if (s.length <= n) s else s.take(n * 2 / 3) + "\n...[middle trimmed]...\n" + s.takeLast(n / 3)

    private fun short(sha: String) = sha.take(7)

    // ============================================================ GitHub API

    private class Res(val code: Int, val body: String, val rateLeft: String?, val scopes: String?) {
        fun json(): JSONObject = try { JSONObject(body) } catch (_: Exception) { JSONObject() }
        fun arr(): JSONArray = try { JSONArray(body) } catch (_: Exception) { JSONArray() }
        fun message(): String = json().optString("message").ifBlank { body.take(160) }
    }

    private fun request(token: String, method: String, path: String, body: JSONObject?): Request {
        Cancel.check()
        val rb = if (body != null) body.toString().toRequestBody(JSON) else if (method == "GET" || method == "DELETE") null else "{}".toRequestBody(JSON)
        return Request.Builder().url(if (path.startsWith("http")) path else API + path).method(method, rb)
            .header("Authorization", "Bearer $token")
            .header("Accept", "application/vnd.github+json")
            .header("X-GitHub-Api-Version", "2022-11-28").build()
    }

    private fun call(token: String, method: String, path: String, body: JSONObject? = null): Res =
        http.newCall(request(token, method, path, body)).execute().use { r ->
            Res(r.code, r.body?.string().orEmpty(), r.header("x-ratelimit-remaining"), r.header("x-oauth-scopes"))
        }

    private fun callBytes(token: String, path: String): ByteArray {
        http.newCall(request(token, "GET", path, null)).execute().use { r ->
            if (r.code != 200) throw IllegalStateException("GitHub error ${r.code} while downloading the repository.")
            return r.body?.bytes() ?: ByteArray(0)
        }
    }

    private fun fail(r: Res, what: String): Nothing {
        val msg = r.message()
        when {
            r.code == 401 -> throw IllegalStateException("The GitHub token is wrong or expired. Set a new token (Settings > GitHub token).")
            r.code == 403 && r.rateLeft == "0" -> throw IllegalStateException("GitHub rate limit reached. Try again in a few minutes.")
            r.code == 403 || r.code == 404 -> throw IllegalStateException("GitHub did not allow $what (${r.code}): $msg. Check the repository name. The token needs 'repo' (classic) or Contents + Pull requests read/write (fine-grained), and must cover this repository.")
            r.code == 409 && msg.contains("empty", true) -> throw IllegalStateException("The repository is empty. Create it with a README first, then clone it.")
            else -> throw IllegalStateException("GitHub error ${r.code} ($what): $msg")
        }
    }

    private fun ok(r: Res, what: String): Res { if (r.code !in 200..299) fail(r, what); return r }

    private fun headSha(token: String, st: State, branch: String): String {
        val r = call(token, "GET", "/repos/${st.slug}/git/ref/heads/$branch")
        if (r.code == 404) throw IllegalStateException("Branch '$branch' was not found in ${st.slug}.")
        return ok(r, "branch dekhna").json().optJSONObject("object")?.optString("sha").orEmpty()
    }

    /** path -> blob id of every file in the commit's tree (symlinks and submodules left out), plus the tree id. */
    private fun remoteTree(token: String, slug: String, commit: String): Pair<String, Map<String, String>> {
        val c = ok(call(token, "GET", "/repos/$slug/git/commits/$commit"), "commit padhna")
        val treeSha = c.json().optJSONObject("tree")?.optString("sha").orEmpty()
        val t = ok(call(token, "GET", "/repos/$slug/git/trees/$treeSha?recursive=1"), "tree padhna").json()
        if (t.optBoolean("truncated")) throw IllegalStateException("This repository is too large for the phone tool (file list was cut by GitHub).")
        val arr = t.optJSONArray("tree") ?: JSONArray()
        val out = LinkedHashMap<String, String>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            if (o.optString("type") == "blob" && o.optString("mode") != "120000") out[o.optString("path")] = o.optString("sha")
        }
        return Pair(treeSha, out)
    }

    private fun blobBytes(token: String, slug: String, sha: String): ByteArray {
        val j = ok(call(token, "GET", "/repos/$slug/git/blobs/$sha"), "file download").json()
        return java.util.Base64.getMimeDecoder().decode(j.optString("content"))
    }

    /** Extracts a GitHub zipball into [dir]; only paths listed in [tree] (and in [only] when given). Returns path -> blob id written. */
    private fun unzipInto(dir: File, zip: ByteArray, tree: Map<String, String>, only: Set<String>?): Map<String, String> {
        val written = LinkedHashMap<String, String>()
        var total = 0L
        ZipInputStream(zip.inputStream()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                val rel = cleanRel(e.name.substringAfter('/', "")) ?: continue
                if (!tree.containsKey(rel) || (only != null && rel !in only)) continue
                val bytes = z.readBytes()
                total += bytes.size
                if (total > MAX_TOTAL) throw IllegalStateException("The repository is larger than 80 MB.")
                val f = File(dir, rel)
                f.parentFile?.mkdirs()
                f.writeBytes(bytes)
                written[rel] = blobSha(bytes)
            }
        }
        return written
    }

    private fun touch(ctx: Context, dir: File) {
        dir.setLastModified(System.currentTimeMillis())
        Coder.keepCopy(ctx, dir)
        try { Coder.onChanged?.invoke(dir) } catch (_: Exception) {}
    }

    // ============================================================ actions

    private const val NO_TOKEN = "No GitHub token. Ask the user to open Settings > GitHub token and paste a token (classic with 'repo', or fine-grained with Contents + Pull requests read/write). Never ask them to type the token in chat."
    private const val NOT_CONNECTED = "This project is not connected to Git. Use project_git action=clone (repo=owner/name) to get a repository, or action=init to create a new repository from this project."

    fun run(ctx: Context, confirm: (String) -> Boolean, a: JSONObject, find: () -> Pair<File?, String>): String {
        val action = a.optString("action", "status").trim().lowercase().replace('-', '_').replace(' ', '_')
        val token = GitHubPages.token(ctx)
        val needsToken = action !in setOf("status", "disconnect")
        if (needsToken && token.isBlank()) return NO_TOKEN
        return try {
            when (action) {
                "whoami", "login", "auth" -> whoami(token)
                "clone" -> clone(ctx, token, a)
                else -> {
                    val (dir, err) = find()
                    if (dir == null) return err
                    when (action) {
                        "init", "create_repo" -> init(ctx, confirm, token, dir, a)
                        "status" -> statusReport(dir, token, a)
                        "diff" -> diff(dir, token, a)
                        "commit", "push", "commit_push" -> commit(ctx, confirm, token, dir, a)
                        "pull", "fetch", "sync" -> pull(ctx, confirm, token, dir, a, null)
                        "checkout", "switch" -> checkout(ctx, confirm, token, dir, a)
                        "branch", "branches" -> branch(token, dir, a)
                        "log", "history" -> log(token, dir, a)
                        "pr", "pull_request" -> pr(confirm, token, dir, a)
                        "prs", "pr_list" -> prList(token, dir)
                        "pr_merge", "merge_pr" -> prMerge(confirm, token, dir, a)
                        "disconnect" -> { File(dir, STATE).delete(); "Disconnected. The files stay; Git history on GitHub is untouched." }
                        else -> "project_git action chunein: whoami, clone, init, status, diff, commit, pull, branch, checkout, log, pr, prs, pr_merge, disconnect."
                    }
                }
            }
        } catch (e: CancelledException) { throw e
        } catch (e: IllegalStateException) { "Git nakam: " + (e.message ?: "error")
        } catch (e: java.io.IOException) { "Git nakam: network problem (" + (e.message ?: "io") + "). Check the internet and try again."
        }
    }

    /** Used by Settings > GitHub token > Test. */
    fun selfTest(ctx: Context): String {
        val t = GitHubPages.token(ctx)
        if (t.isBlank()) return "No token saved yet."
        return try { whoami(t) } catch (e: Exception) { "Test failed: " + (e.message ?: "error") }
    }

    private fun whoami(token: String): String {
        val r = ok(call(token, "GET", "/user"), "login check")
        val scopes = (r.scopes ?: "").ifBlank { "fine-grained token (per-repository)" }
        return "GitHub login OK: " + r.json().optString("login") + ". Token permissions: " + scopes + "."
    }

    private fun clone(ctx: Context, token: String, a: JSONObject): String {
        val (owner, repo) = parseRepo(a.optString("repo", a.optString("url", ""))) ?: return "Give repo as owner/name or a GitHub URL."
        val info = ok(call(token, "GET", "/repos/$owner/$repo"), "repository dekhna").json()
        val def = info.optString("default_branch", "main")
        val branch = a.optString("ref", a.optString("branch", "")).ifBlank { def }
        val st = State(info.optJSONObject("owner")?.optString("login").orEmpty().ifBlank { owner }, info.optString("name", repo), branch, def, "", LinkedHashMap())
        val head = headSha(token, st, branch)
        val (_, tree) = remoteTree(token, st.slug, head)
        if (tree.size > MAX_FILES) return "This repository has ${tree.size} files; the phone tool handles up to $MAX_FILES."
        val zip = callBytes(token, "/repos/${st.slug}/zipball/$head")
        val dir = Coder.fileProject(ctx, "README.md", "")
        File(dir, "README.md").delete()
        Coder.rename(dir, a.optString("project", "").trim().ifBlank { st.repo })
        val written = unzipInto(dir, zip, tree, null)
        st.base = head
        st.files = LinkedHashMap(written)
        saveState(dir, st)
        touch(ctx, dir)
        return "Cloned ${st.slug} (branch $branch, commit ${short(head)}) into project '${Coder.name(dir)}': ${written.size} files." +
            (if (tree.size > written.size) " (${tree.size - written.size} files were not in the download and will arrive on the next pull.)" else "") +
            " Use project_git status / commit / pull / branch / pr from here."
    }

    private fun init(ctx: Context, confirm: (String) -> Boolean, token: String, dir: File, a: JSONObject): String {
        loadState(dir)?.let { return "Already connected to ${it.slug}. Use commit / pull." }
        val me = ok(call(token, "GET", "/user"), "login check").json().optString("login")
        val wanted = a.optString("repo", "").trim()
        val name = (parseRepo(wanted)?.second ?: wanted.ifBlank { Coder.name(dir) })
            .lowercase().replace(Regex("[^a-z0-9._-]+"), "-").trim('-').take(80).ifEmpty { "anjoo-project" }
        val owner = parseRepo(wanted)?.first
        if (owner != null && !owner.equals(me, true)) return "init creates repositories in your own account ($me). To use another owner, create the repository on GitHub and clone it."
        val isPrivate = a.optBoolean("private", true)
        val local = scan(dir, emptyMap())
        if (local.isEmpty()) return "The project has no files to commit."
        if (!confirm(Confirm.msg("action", "Create a " + (if (isPrivate) "PRIVATE" else "PUBLIC") + " GitHub repository?", "$me/$name with ${local.size} file(s) from project '${Coder.name(dir)}'."))) return "The user declined."
        val mk = call(token, "POST", "/user/repos", JSONObject().put("name", name).put("private", isPrivate).put("auto_init", true).put("description", "Made with Anjoo AI"))
        if (mk.code == 422) return "A repository named $me/$name already exists. Use project_git action=clone to get it, or pick another repo name."
        ok(mk, "repository banane")
        val def = mk.json().optString("default_branch", "main")
        val st = State(me, name, def, def, "", LinkedHashMap())
        var head = ""
        for (i in 0 until 4) {
            val r = call(token, "GET", "/repos/${st.slug}/git/ref/heads/$def")
            if (r.code == 200) { head = r.json().optJSONObject("object")?.optString("sha").orEmpty(); break }
            Cancel.sleep(1200)
        }
        if (head.isEmpty()) return "Repository ${st.slug} was created but is not ready yet. Run project_git action=pull in a minute."
        st.base = head
        st.files = LinkedHashMap(remoteTree(token, st.slug, head).second)
        saveState(dir, st)
        return commitNow(ctx, token, dir, st, a.optString("message", "Initial commit from Anjoo AI").ifBlank { "Initial commit from Anjoo AI" }, a.optBoolean("allow_secrets", false))
    }

    private fun statusReport(dir: File, token: String, a: JSONObject): String {
        val st = loadState(dir) ?: return NOT_CONNECTED
        val local = scan(dir, st.files)
        val s = status(st.files, local)
        val sb = StringBuilder("GIT STATUS · ${st.slug} · branch ${st.branch} · based on ${short(st.base)}\n")
        if (s.clean) sb.append("Working tree clean: nothing to commit.\n") else {
            sb.append("${s.total} change(s):\n")
            for (p in s.added.take(40)) sb.append("  + ").append(p).append('\n')
            for (p in s.modified.take(40)) sb.append("  ~ ").append(p).append('\n')
            for (p in s.deleted.take(40)) sb.append("  - ").append(p).append('\n')
            if (s.total > 120) sb.append("  ...\n")
        }
        if (token.isNotBlank() && a.optBoolean("remote", true)) {
            try {
                val r = call(token, "GET", "/repos/${st.slug}/compare/${st.base}...${st.branch}")
                if (r.code == 200) {
                    val n = r.json().optInt("ahead_by", 0)
                    sb.append(if (n == 0) "Remote: up to date.\n" else "Remote: $n newer commit(s) on ${st.branch}. Run project_git action=pull before committing.\n")
                } else sb.append("Remote: not checked (${r.code}).\n")
            } catch (_: Exception) { sb.append("Remote: not checked (offline).\n") }
        }
        val conflicted = s.modified.filter { p -> try { hasConflictMarkers(File(dir, p).readText()) } catch (_: Exception) { false } }
        if (conflicted.isNotEmpty()) sb.append("UNRESOLVED CONFLICT MARKERS in: ").append(conflicted.joinToString(", ")).append(". Merge them, then commit.\n")
        return cap(sb.toString())
    }

    private fun diff(dir: File, token: String, a: JSONObject): String {
        val st = loadState(dir) ?: return NOT_CONNECTED
        val s = status(st.files, scan(dir, st.files))
        if (s.clean) return "No changes."
        val only = a.optString("path", "").trim().trim('/')
        val paths = (s.modified + s.added + s.deleted).filter { only.isEmpty() || it == only || it.startsWith("$only/") }
        if (paths.isEmpty()) return "No changes in '$only'."
        val sb = StringBuilder()
        for (p in paths.take(8)) {
            val f = File(dir, p)
            val newBytes = if (f.exists()) f.readBytes() else ByteArray(0)
            val oldSha = st.files[p]
            val oldBytes = if (oldSha != null) blobBytes(token, st.slug, oldSha) else ByteArray(0)
            val newText = decodeText(newBytes); val oldText = decodeText(oldBytes)
            if (newText == null || oldText == null) sb.append("Binary file changed: ").append(p).append('\n')
            else sb.append(unifiedDiff(p, oldText, newText).ifEmpty { "(no text change: $p)\n" }).append('\n')
            if (sb.length > CAP * 2) break
        }
        if (paths.size > 8) sb.append("... and ${paths.size - 8} more changed file(s); pass path= to see one.\n")
        return cap(sb.toString())
    }

    private fun commit(ctx: Context, confirm: (String) -> Boolean, token: String, dir: File, a: JSONObject): String {
        val st = loadState(dir) ?: return NOT_CONNECTED
        val msg = a.optString("message", "").trim()
        if (msg.isEmpty()) return "Write a commit message (message)."
        val s = status(st.files, scan(dir, st.files))
        if (s.clean) return "Nothing to commit: working tree clean."
        if (!confirm(Confirm.msg("action", "Commit and push to GitHub?", "${st.slug} · branch ${st.branch}\n${s.added.size} new, ${s.modified.size} changed, ${s.deleted.size} deleted\n\"" + msg.take(100) + "\""))) return "The user declined."
        return commitNow(ctx, token, dir, st, msg, a.optBoolean("allow_secrets", false))
    }

    /** Creates one commit with every working change on top of st.base and moves the branch to it (no force). */
    private fun commitNow(ctx: Context, token: String, dir: File, st: State, msg: String, allowSecrets: Boolean): String {
        val local = scan(dir, st.files)
        val s = status(st.files, local)
        if (s.clean) return "Nothing to commit."
        val changed = s.added + s.modified
        var total = 0L
        val bad = ArrayList<String>(); val secrets = ArrayList<String>()
        for (p in changed) {
            val f = File(dir, p)
            total += f.length()
            val bytes = f.readBytes()
            val text = decodeText(bytes)
            if (text != null && hasConflictMarkers(text)) bad.add(p)
            val hits = secretHits(p, text)
            if (hits.isNotEmpty()) secrets.add(p + " (" + hits.joinToString(", ") + ")")
        }
        if (total > MAX_TOTAL) return "The changes are larger than 80 MB."
        if (bad.isNotEmpty()) return "Commit stopped: unresolved conflict markers (<<<<<<< local ... >>>>>>> remote) in ${bad.joinToString(", ")}. Merge them first."
        if (secrets.isNotEmpty() && !allowSecrets)
            return "Commit stopped: these files look like they hold secrets: ${secrets.joinToString("; ")}. Remove them (use environment variables or a .gitignore entry), or tell the user and retry with allow_secrets=true only if they confirm it is safe."

        val head = headSha(token, st, st.branch)
        if (head != st.base) return "The remote branch ${st.branch} has newer commits (${short(head)}). Run project_git action=pull first, then commit again."

        val baseTree = ok(call(token, "GET", "/repos/${st.slug}/git/commits/${st.base}"), "commit padhna").json().optJSONObject("tree")?.optString("sha").orEmpty()
        val entries = JSONArray()
        for (p in changed) {
            val bytes = File(dir, p).readBytes()
            val text = if (bytes.isNotEmpty() && bytes.size <= INLINE_MAX) decodeText(bytes) else null
            val e = JSONObject().put("path", p).put("mode", "100644").put("type", "blob")
            if (text != null) e.put("content", text)
            else {
                val body = if (bytes.isEmpty()) JSONObject().put("content", "").put("encoding", "utf-8")
                else JSONObject().put("content", java.util.Base64.getEncoder().encodeToString(bytes)).put("encoding", "base64")
                val b = ok(call(token, "POST", "/repos/${st.slug}/git/blobs", body), "file upload ($p)")
                e.put("sha", b.json().optString("sha"))
            }
            entries.put(e)
        }
        for (p in s.deleted) entries.put(JSONObject().put("path", p).put("mode", "100644").put("type", "blob").put("sha", JSONObject.NULL))
        val tree = ok(call(token, "POST", "/repos/${st.slug}/git/trees", JSONObject().put("base_tree", baseTree).put("tree", entries)), "tree banana").json().optString("sha")
        val commit = ok(call(token, "POST", "/repos/${st.slug}/git/commits", JSONObject().put("message", msg).put("tree", tree).put("parents", JSONArray().put(st.base))), "commit banana").json().optString("sha")
        val move = call(token, "PATCH", "/repos/${st.slug}/git/refs/heads/${st.branch}", JSONObject().put("sha", commit).put("force", false))
        if (move.code == 422) return "GitHub refused the push (the branch moved while committing). Run project_git action=pull and try again."
        ok(move, "branch update")
        st.base = commit
        st.files = LinkedHashMap(local)
        saveState(dir, st)
        touch(ctx, dir)
        return "Committed ${short(commit)} to ${st.slug}@${st.branch}: ${s.added.size} new, ${s.modified.size} changed, ${s.deleted.size} deleted. https://github.com/${st.slug}/commit/$commit"
    }

    private fun pull(ctx: Context, confirm: (String) -> Boolean, token: String, dir: File, a: JSONObject, targetBranch: String?): String {
        val st = loadState(dir) ?: return NOT_CONNECTED
        val branch = targetBranch ?: st.branch
        val head = headSha(token, st, branch)
        if (branch == st.branch && head == st.base) return "Already up to date (${short(head)})."
        val strategy = a.optString("strategy", "markers").trim().lowercase().let { if (it in setOf("markers", "theirs", "ours")) it else "markers" }
        val local = scan(dir, st.files)
        val remote = remoteTree(token, st.slug, head).second
        val plan = planPull(st.files, local, remote)
        if (strategy == "theirs" && plan.conflicts.isNotEmpty() &&
            !confirm(Confirm.msg("overwrite", "Replace your version of ${plan.conflicts.size} file(s) with the GitHub version?", plan.conflicts.take(8).joinToString(", "))))
            return "The user declined."

        Coder.snapshot(ctx, dir) // project_history undo can bring the old files back
        val fetch = plan.take.toMutableList()
        if (strategy == "theirs") fetch.addAll(plan.conflicts.filter { remote.containsKey(it) })
        val needText = if (strategy == "markers") plan.conflicts.filter { remote.containsKey(it) && File(dir, it).exists() } else emptyList()
        val wanted = (fetch + needText).toSet()
        val fetched = HashMap<String, ByteArray>()
        if (wanted.size > 40) {
            val zip = callBytes(token, "/repos/${st.slug}/zipball/$head")
            val tmp = File(dir, ".anjoo-pull-tmp")
            tmp.deleteRecursively()
            tmp.mkdirs()
            try {
                unzipInto(tmp, zip, remote, wanted)
                for (p in wanted) { val f = File(tmp, p); if (f.exists()) fetched[p] = f.readBytes() }
            } finally { tmp.deleteRecursively() }
        }
        for (p in wanted) if (!fetched.containsKey(p)) fetched[p] = blobBytes(token, st.slug, remote.getValue(p))

        var updated = 0; var removed = 0
        val merged = ArrayList<String>(); val keptLocal = ArrayList<String>()
        val newFiles = LinkedHashMap<String, String>(remote)
        for (p in fetch) {
            val rel = cleanRel(p) ?: continue
            val f = File(dir, rel)
            f.parentFile?.mkdirs()
            f.writeBytes(fetched.getValue(p)); updated++
        }
        for (p in plan.remove) {
            val rel = cleanRel(p) ?: continue
            File(dir, rel).delete(); removed++
        }
        for (p in plan.conflicts) {
            val rel = cleanRel(p) ?: continue
            val f = File(dir, rel)
            when (strategy) {
                "theirs" -> { if (remote.containsKey(p)) { f.parentFile?.mkdirs(); f.writeBytes(fetched.getValue(p)); updated++ } else { f.delete(); removed++ } }
                "markers" -> {
                    val lt = if (f.exists()) decodeText(f.readBytes()) else null
                    val rt = fetched[p]?.let { decodeText(it) }
                    if (lt != null && rt != null) { f.writeText(conflictText(lt, rt), Charsets.UTF_8); merged.add(p) } else keptLocal.add(p)
                    resetEntry(newFiles, st.files, p)
                }
                else -> { keptLocal.add(p); resetEntry(newFiles, st.files, p) }
            }
        }
        // files the remote still has but a pull never wrote (not in the zip) are simply not claimed as present
        st.files = newFiles
        st.base = head
        if (targetBranch != null) st.branch = targetBranch
        saveState(dir, st)
        touch(ctx, dir)
        val sb = StringBuilder(if (targetBranch != null) "Switched to branch $branch (${short(head)}). " else "Pulled ${short(head)}. ")
        sb.append("$updated file(s) updated, $removed removed.")
        if (merged.isNotEmpty()) sb.append("\nCONFLICTS (both you and GitHub changed these): ").append(merged.joinToString(", "))
            .append("\nEach file now holds both versions between $MARK_LOCAL / ======= / $MARK_REMOTE. Edit them into the final version, remove the markers, then commit.")
        if (keptLocal.isNotEmpty()) sb.append("\nKept your version of: ").append(keptLocal.joinToString(", ")).append(" (binary, deleted on one side, or strategy=ours). Your version will overwrite the remote one on the next commit.")
        sb.append("\nUndo is possible with project_history undo.")
        return cap(sb.toString())
    }

    /** A conflicted path keeps its OLD base id so the working file still counts as changed and gets committed. */
    private fun resetEntry(newFiles: MutableMap<String, String>, oldBase: Map<String, String>, p: String) {
        val old = oldBase[p]
        if (old != null) newFiles[p] = old else newFiles.remove(p)
    }

    private fun checkout(ctx: Context, confirm: (String) -> Boolean, token: String, dir: File, a: JSONObject): String {
        val st = loadState(dir) ?: return NOT_CONNECTED
        val name = a.optString("name", a.optString("branch", a.optString("ref", ""))).trim()
        if (name.isEmpty()) return "Give the branch name (name)."
        if (name == st.branch) return "Already on branch $name."
        return pull(ctx, confirm, token, dir, a, name)
    }

    private fun branch(token: String, dir: File, a: JSONObject): String {
        val st = loadState(dir) ?: return NOT_CONNECTED
        val name = a.optString("name", "").trim()
        if (name.isEmpty()) {
            val arr = ok(call(token, "GET", "/repos/${st.slug}/branches?per_page=50"), "branches").arr()
            val sb = StringBuilder("BRANCHES of ${st.slug} (current: ${st.branch})\n")
            for (i in 0 until arr.length()) {
                val b = arr.optJSONObject(i)?.optString("name").orEmpty()
                sb.append(if (b == st.branch) "* " else "  ").append(b).append(if (b == st.defaultBranch) "  (default)" else "").append('\n')
            }
            return sb.toString().trim()
        }
        if (!Regex("^[A-Za-z0-9._/-]{1,100}$").matches(name) || name.contains("..") || name.startsWith("/") || name.endsWith("/"))
            return "Branch name can use letters, digits, . _ - and / only."
        val r = call(token, "POST", "/repos/${st.slug}/git/refs", JSONObject().put("ref", "refs/heads/$name").put("sha", st.base))
        if (r.code == 422) return "Branch '$name' already exists. Use action=checkout name=$name."
        ok(r, "branch banana")
        st.branch = name
        saveState(dir, st)
        return "Created branch '$name' from ${short(st.base)} and switched to it. Your uncommitted changes stay. Commit now to put them on this branch."
    }

    private fun log(token: String, dir: File, a: JSONObject): String {
        val st = loadState(dir) ?: return NOT_CONNECTED
        val n = a.optInt("count", 10).coerceIn(1, 30)
        val arr = ok(call(token, "GET", "/repos/${st.slug}/commits?sha=${st.branch}&per_page=$n"), "log").arr()
        if (arr.length() == 0) return "No commits."
        val sb = StringBuilder("LOG ${st.slug}@${st.branch}\n")
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val c = o.optJSONObject("commit")
            val who = c?.optJSONObject("author")?.optString("name").orEmpty()
            val day = c?.optJSONObject("author")?.optString("date").orEmpty().take(10)
            val msg = c?.optString("message").orEmpty().substringBefore('\n').take(90)
            sb.append(short(o.optString("sha"))).append(" · ").append(day).append(" · ").append(who).append(" · ").append(msg).append('\n')
        }
        return cap(sb.toString().trim())
    }

    private fun pr(confirm: (String) -> Boolean, token: String, dir: File, a: JSONObject): String {
        val st = loadState(dir) ?: return NOT_CONNECTED
        val title = a.optString("title", "").trim()
        if (title.isEmpty()) return "Give the pull request title (title)."
        val base = a.optString("base", "").trim().ifBlank { st.defaultBranch }
        val head = st.branch
        if (head == base) return "You are on '$base'. Create a branch first (action=branch name=...), commit there, then open the PR."
        val dirty = !status(st.files, scan(dir, st.files)).clean
        if (!confirm(Confirm.msg("action", "Open a pull request on GitHub?", "${st.slug}: $head → $base\n\"" + title.take(100) + "\"" + (if (dirty) "\nNote: uncommitted changes are not part of it." else "")))) return "The user declined."
        val r = call(token, "POST", "/repos/${st.slug}/pulls", JSONObject().put("title", title).put("head", head).put("base", base).put("body", a.optString("body", "")))
        if (r.code == 422) return "GitHub did not open the PR: " + r.message() + " (commit and push the branch first; a PR needs at least one commit that $base does not have)."
        val j = ok(r, "pull request").json()
        return "Pull request #${j.optInt("number")} opened: ${j.optString("html_url")}"
    }

    private fun prList(token: String, dir: File): String {
        val st = loadState(dir) ?: return NOT_CONNECTED
        val arr = ok(call(token, "GET", "/repos/${st.slug}/pulls?state=open&per_page=15"), "PR list").arr()
        if (arr.length() == 0) return "No open pull requests in ${st.slug}."
        val sb = StringBuilder("OPEN PULL REQUESTS · ${st.slug}\n")
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            sb.append("#").append(o.optInt("number")).append(" ").append(o.optString("title").take(80)).append(" (")
                .append(o.optJSONObject("head")?.optString("ref").orEmpty()).append(" → ").append(o.optJSONObject("base")?.optString("ref").orEmpty())
                .append(") ").append(o.optString("html_url")).append('\n')
        }
        return cap(sb.toString().trim())
    }

    private fun prMerge(confirm: (String) -> Boolean, token: String, dir: File, a: JSONObject): String {
        val st = loadState(dir) ?: return NOT_CONNECTED
        val n = a.optInt("number", 0)
        if (n <= 0) return "Give the pull request number (number). See prs for the list."
        val method = a.optString("merge_method", "squash").lowercase().let { if (it in setOf("merge", "squash", "rebase")) it else "squash" }
        if (!confirm(Confirm.msg("action", "Merge pull request #$n on GitHub?", "${st.slug} · method: $method. This changes the base branch on GitHub."))) return "The user declined."
        val r = call(token, "PUT", "/repos/${st.slug}/pulls/$n/merge", JSONObject().put("merge_method", method))
        if (r.code == 405 || r.code == 409) return "GitHub cannot merge #$n now: " + r.message()
        ok(r, "PR merge")
        return "Pull request #$n merged ($method). Run project_git action=pull on the base branch to bring it in."
    }
}
