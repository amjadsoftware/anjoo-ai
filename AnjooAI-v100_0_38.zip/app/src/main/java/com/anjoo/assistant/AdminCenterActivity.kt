package com.anjoo.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Admin Center: the one entry point for everything about running Anjoo AI, in the 12 sections of the enterprise plan.
 * It runs in LOCAL MODE: every number is measured on this phone. Each section shows its honest status:
 * Ready, Partly ready, Needs backend (multi-user, payments, servers: not connected) or Not built yet.
 * A section that is not built is not tappable, so there is no button that does nothing.
 */
class AdminCenterActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private enum class Status(val label: String) { READY("Ready"), PARTIAL("Partly ready"), BACKEND("Needs backend"), PLANNED("Not built yet") }
    private class Section(val icon: String, val title: String, val status: Status, val summary: String, val open: (() -> Unit)? = null)

    private lateinit var theme: CyberTheme
    private lateinit var content: LinearLayout
    private val good = Color.rgb(46, 125, 50)
    private val warn = Color.rgb(230, 126, 0)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun faint() = Color.argb(70, 128, 128, 128)
    private fun shape(fill: Int, stroke: Int = faint(), radius: Int = 14) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = dp(radius).toFloat()
    }
    private fun label(text: String, size: Float = 14f, color: Int = theme.ink, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        theme = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        Style.bars(window, theme)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(theme.bg)
            setPadding(dp(14), dp(28), dp(14), dp(10))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("‹", 30f).apply { setPadding(dp(6), 0, dp(18), dp(4)); setOnClickListener { finish() } })
        header.addView(label("Admin Center", 20f, theme.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("↻", 24f, theme.accent).apply { setPadding(dp(14), 0, dp(6), dp(2)); setOnClickListener { render() } })
        root.addView(header)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(content) }, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = dp(8) })
        setContentView(root)
        render()
    }

    override fun onResume() { super.onResume(); if (::content.isInitialized) render() }

    private fun safe(f: () -> String): String = try { f() } catch (e: Exception) { "Not available right now." }

    private fun go(cls: Class<*>, section: String? = null): () -> Unit = {
        startActivity(Intent(this, cls).apply { if (section != null) putExtra("section", section) })
    }

    private fun sections(): List<Section> {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        val all = Tasks.all(this)
        var runs = 0; var todo = 0; var doing = 0; var done = 0
        for (i in 0 until all.length()) {
            val o = all.optJSONObject(i) ?: continue
            if (o.has("agentStage")) runs++
            when (o.optString("status")) { "doing" -> doing++; "done" -> done++; else -> todo++ }
        }
        val attention = AdminAudit.suspicious(AdminAudit.entries(this), System.currentTimeMillis()).size
        return listOf(
            Section("📊", "Overview", Status.READY, safe {
                val rows = TokenLedger.totalsFor(this, today).values
                "${rows.sumOf { it.calls }} AI requests and ${rows.sumOf { it.input + it.output }} tokens today. Usage, models, tools and tasks, measured on this phone."
            }, go(OpsDashboardActivity::class.java)),
            Section("👥", "Users", Status.BACKEND, "This phone has one owner. More users, roles and subscriptions need a backend, which is not connected."),
            Section("🤖", "AI Models", Status.PARTIAL, safe {
                val n = Router.healthRows().size
                (if (n == 0) "No model has been used yet." else "$n models have measured results (see Overview).") + " Providers and keys are in Settings > AI models and keys."
            }),
            Section("🧭", "Agents", Status.PARTIAL, "$runs autonomous runs. Plan, timeline, result, and the limits and permissions agents run under.", go(AgentRunsActivity::class.java)),
            Section("✅", "Tasks & Workflows", Status.PARTIAL, if (all.length() == 0) "No tasks on the board." else "${all.length()} tasks: $todo to do, $doing doing, $done done.", go(TasksActivity::class.java)),
            Section("💳", "Finance & Billing", Status.PLANNED, "Token cost is in Overview. Revenue and payments need a payment provider, which is not connected."),
            Section("🧠", "Memory & Knowledge", Status.READY, safe {
                "${LongMemory.all(this).size} memories and ${KnowledgeBase.stats(this).optInt("documents")} documents. All layers, with sizes, in the Overview tab."
            }, go(MemoryActivity::class.java, "overview")),
            Section("🖥", "System Monitoring", Status.PLANNED, "Model and tool health are in Overview. Server and database monitoring need a backend."),
            Section("🔐", "Security & Audit", Status.READY, safe {
                "${AdminAudit.entries(this).size} events logged" + (if (attention > 0) ", $attention need attention." else ". Nothing unusual in the last 10 minutes.")
            }, go(AuditLogActivity::class.java)),
            Section("🔔", "Notifications", Status.PLANNED, "A notification center is not built yet."),
            Section("📑", "Reports & Analytics", Status.PLANNED, "CSV and PDF reports are not built yet."),
            Section("⚙️", "Settings", Status.PLANNED, "Central configuration is not built yet. The existing Settings in the main menu still work.")
        )
    }

    private fun render() {
        content.removeAllViews()
        val list = sections()
        val ready = list.count { it.status == Status.READY }
        val partial = list.count { it.status == Status.PARTIAL }

        val banner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(theme.surface); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        banner.addView(label("Local mode", 14.5f, theme.ink, true))
        banner.addView(label("Everything here is measured on this phone. Multi-user accounts, payments and server monitoring are not connected, and no number is invented.", 12.5f, theme.muted).apply { setPadding(0, dp(4), 0, 0) })
        banner.addView(label("$ready of ${list.size} sections ready, $partial partly ready.", 12.5f, theme.accent, true).apply { setPadding(0, dp(6), 0, 0) })
        content.addView(banner, LinearLayout.LayoutParams(-1, -2))

        for (s in list) {
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = shape(theme.surface); setPadding(dp(14), dp(12), dp(14), dp(12)) }
            val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            top.addView(label(s.icon + "  " + s.title, 14.5f, theme.ink, true), LinearLayout.LayoutParams(0, -2, 1f))
            val color = when (s.status) { Status.READY -> good; Status.PARTIAL -> warn; else -> theme.muted }
            top.addView(label(s.status.label, 11.5f, color, true).apply {
                background = shape(Color.TRANSPARENT, color, 10); setPadding(dp(9), dp(3), dp(9), dp(3))
            })
            card.addView(top)
            card.addView(label(s.summary, 12.5f, theme.muted).apply { setPadding(0, dp(5), 0, 0) })
            if (s.open != null) {
                card.addView(label("Open  ›", 12.5f, theme.accent, true).apply { setPadding(0, dp(7), 0, 0) })
                card.setOnClickListener { s.open.invoke() }
            }
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        }
    }
}
