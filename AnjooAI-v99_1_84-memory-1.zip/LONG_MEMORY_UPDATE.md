# Long-term memory - v99.1.84 (draft)

- NEW LongMemory.kt: Anjoo's memory is no longer 50 plain notes. Items have a kind: pref (pasand/aadat), task (chal raha kaam), person (log/rishte), fact. Up to 600 items, saved in long_memory.json.
- Old notes move over automatically once.
- Duplicates are merged (updated, not repeated).
- Each prompt gets only the memories that fit the current message (all preferences, open tasks, best-matching people/facts), within ~2200 characters.
- Related old chats are added to the prompt when they share words with the current message.
- Auto Memory (Settings, default on, needs Save Memory on): clear statements ("mujhe ... pasand hai", "meri behan ...", "main ... bana raha hoon") are saved without saying "yaad rakho". Questions and commands are ignored. Saying a task is done ("ho gaya") closes it.
- Never stored: password, PIN, OTP, card number, API key.
- New tools: memory_done, list_memory. remember now takes kind and pin.
- Backup/restore include the memory (merged, newest edit wins).
- Tests: LongMemoryTest.kt (not run yet - no Kotlin compiler where this was written).

# GF mode
- Say "GF" (or "gf mode on", "gf ban jao") and Anjoo talks warmly like a girlfriend. Say "normal" or "gf off" to go back. Off by default; the setting is remembered.
- A sentence about someone's gf ("meri gf ko message bhejo") does not switch it on.
- Stays affectionate but clean; no jealousy or guilt-tripping; tools, confirmations and safety rules are unchanged.

# Maker credit
- Asked who made Anjoo: answers "Amjad ne banaya hai". For new features or changes: contact Amjad on WhatsApp +92 300 1122810. Works in GF mode too. If asked which AI model runs inside, it answers honestly. (Credit.kt)
