package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class GfModeTest {
    @Test fun gfSwitchesOn() {
        assertEquals(true, GfLogic.trigger("GF"))
        assertEquals(true, GfLogic.trigger("gf mode on"))
        assertEquals(true, GfLogic.trigger("gf ban jao!"))
    }
    @Test fun normalSwitchesOff() {
        assertEquals(false, GfLogic.trigger("normal"))
        assertEquals(false, GfLogic.trigger("GF off"))
    }
    @Test fun talkingAboutAGfIsNotASwitch() {
        assertNull(GfLogic.trigger("meri gf ko message bhejo"))
        assertNull(GfLogic.trigger("gf ke liye gift idea do"))
        assertNull(GfLogic.trigger("aaj mausam kaisa hai"))
    }
}
