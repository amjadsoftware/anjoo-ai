package com.anjoo.assistant

import org.junit.Assert.assertTrue
import org.junit.Test

class AppMapTest {
    @Test fun lookupFindsHologramAndOrb() {
        val r = AppMap.lookup("hologram")
        assertTrue(r.contains("Hologram tasveer"))
        assertTrue(r.contains("default Off"))
    }

    @Test fun emptyQueryReturnsEverything() {
        val r = AppMap.lookup("")
        assertTrue(r.contains("Main chat screen"))
        assertTrue(r.contains("Backup and restore"))
    }

    @Test fun unknownQueryIsHonest() = assertTrue(AppMap.lookup("zzzqqq").contains("nahi"))

    @Test fun promptBlockMentionsToolAndQualityBar() {
        assertTrue(AppMap.promptBlock().contains("app_map"))
        assertTrue(Style.INTELLIGENCE.contains("run_python"))
    }
}
