package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LongMemoryTest {
    private val now = 1_800_000_000_000L
    private fun item(id: Long, k: String, t: String, upd: Long = now, done: Boolean = false, pin: Boolean = false) =
        MemItem(id, k, t, upd, upd, 0, done, pin)

    @Test fun sensitiveTextIsRejected() {
        assertTrue(MemLogic.isSensitive("mera password abc123 hai"))
        assertTrue(MemLogic.isSensitive("card 4111 1111 1111 1111"))
        assertFalse(MemLogic.isSensitive("mujhe chai pasand hai"))
    }

    @Test fun duplicatesAreMergedNotRepeated() {
        val items = listOf(item(1, "pref", "mujhe garam chai pasand hai"))
        assertNotNull(MemLogic.findDuplicate(items, "pref", "mujhe chai pasand hai"))
        assertNull(MemLogic.findDuplicate(items, "pref", "mujhe cricket pasand hai"))
        assertNull(MemLogic.findDuplicate(items, "task", "mujhe garam chai pasand hai"))
    }

    @Test fun relevantFactsRankFirst() {
        val items = listOf(
            item(1, "fact", "ghar ka wifi router tp-link hai"),
            item(2, "person", "meri behan ka naam Sana hai"),
        )
        val got = MemLogic.pick(items, "behan Sana ko message bhejo", now)
        assertEquals(2L, got.first { it.kind == "person" }.id)
        assertEquals(2L, got.first().id)
    }

    @Test fun finishedTasksAreHiddenAndOpenOnesKept() {
        val items = listOf(item(1, "task", "AnjooAI ka memory feature bana raha hoon", done = true), item(2, "task", "exam ki tayari kar raha hoon"))
        val got = MemLogic.pick(items, "", now)
        assertEquals(listOf(2L), got.map { it.id })
    }

    @Test fun promptStaysWithinBudget() {
        val items = (1..200L).map { item(it, "fact", "yeh ek lambi si baat number $it " + "x".repeat(100)) }
        val used = MemLogic.pick(items, "", now, 1000).sumOf { it.text.length + 12 }
        assertTrue(used <= 1000)
    }

    @Test fun autoCaptureIsConservative() {
        assertEquals("pref", MemLogic.extract("mujhe subah ki chai bohat pasand hai")!!.first)
        assertEquals("person", MemLogic.extract("meri behan ka naam Sana hai")!!.first)
        assertEquals("task", MemLogic.extract("main apna project bana raha hoon")!!.first)
        assertNull(MemLogic.extract("kya mujhe chai pasand hai?"))
        assertNull(MemLogic.extract("alarm laga do"))
        assertNull(MemLogic.extract("mera password 1234 hai aur mujhe pasand hai"))
    }

    @Test fun kindsAreNormalised() {
        assertEquals("pref", MemLogic.normalizeKind("Pasand"))
        assertEquals("task", MemLogic.normalizeKind("kaam"))
        assertEquals("fact", MemLogic.normalizeKind(null))
    }
}
