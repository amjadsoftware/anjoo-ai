package com.anjoo.assistant

import org.junit.Assert.assertTrue
import org.junit.Test

/** Guards the quality bar of Anjoo's coding brain: a prompt edit must not silently drop a rule. */
class CoderPromptTest {

    @Test fun rulesAreNumberedWithoutGaps() {
        for (n in 1..23) {
            assertTrue("rule $n is missing", Coder.SYSTEM.contains("\n$n. "))
        }
    }

    @Test fun codeMustBeCompleteAndRunnable() {
        assertTrue(Coder.SYSTEM.contains("Never use placeholders"))
        assertTrue(Coder.SYSTEM.contains("COMPLETE and RUNNABLE"))
    }

    @Test fun everyRequirementMustBeTraced() {
        assertTrue(Coder.SYSTEM.contains("REQUIREMENTS TRACEABILITY"))
    }

    @Test fun deliveryRulesRequireReadmeAndTests() {
        assertTrue(Coder.SYSTEM.contains("README.md"))
        assertTrue(Coder.SYSTEM.contains("TESTABILITY"))
    }

    @Test fun outputFormatDefinesTheFileMarkers() {
        assertTrue(Coder.FORMAT.contains("=== NOTES ==="))
        assertTrue(Coder.FORMAT.contains("=== FILE:"))
    }

    @Test fun masterPlanCoversDesignGraphicsAndFormats() {
        val plan = Coder.planPromptForTest()
        for (h in listOf("VISION", "USER JOURNEYS", "SCREENS", "ARCHITECTURE", "DESIGN SYSTEM", "GRAPHICS", "DATA FORMATS", "QUALITY GATES", "FILE SIZE RULE")) {
            assertTrue("plan prompt lost $h", plan.contains(h))
        }
    }

    @Test fun designSystemRuleKeepsFilesSubstantial() {
        assertTrue(Coder.SYSTEM.contains("DESIGN SYSTEM FIDELITY"))
        assertTrue(Coder.SYSTEM.contains("never create a file for a few lines"))
    }

    @Test fun readmeLineDoesNotEndTheFilesList() {
        val plan = "NAME: Demo\nFILES\n- index.html - entry\n- README.md - docs\n- app.js - logic\nDESIGN SYSTEM\n- tokens"
        val files = Coder.planFilesForTest(plan)
        assertTrue(files.contains("README.md") && files.contains("app.js"))
    }
}
