package com.anjoo.assistant

import org.junit.Assert.assertTrue
import org.junit.Test

class CreditTest {
    @Test fun promptNamesMakerAndWhatsapp() {
        val b = Credit.promptBlock()
        assertTrue(b.contains("Amjad"))
        assertTrue(b.contains("+92 300 1122810"))
    }
}
