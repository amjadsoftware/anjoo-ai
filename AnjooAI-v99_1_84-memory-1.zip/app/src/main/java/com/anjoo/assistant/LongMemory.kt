package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One remembered thing. kind: "pref" (pasand/aadat), "task" (chal raha kaam), "person" (log/rishte), "fact" (baaqi). */
data class MemItem(
    val id: Long,
    val kind: String,
    val text: String,
    val created: Long,
    val updated: Long,
    val hits: Int = 0,
    val done: Boolean = false,
    val pinned: Boolean = false,
)

/**
 * Pure logic (no Android): word matching, duplicate detection, ranking and auto-capture rules.
 * Kept separate from storage so it can be unit tested on the JVM.
 */
object MemLogic {
    const val MAX_ITEMS = 600
    const val MAX_TEXT = 240

    private val STOP = setOf(
        "the", "a", "an", "is", "are", "to", "of", "and", "or", "in", "on", "for", "my", "me", "i", "it", "that", "this",
        "hai", "hain", "ho", "hoon", "tha", "thi", "ka", "ki", "ke", "ko", "se", "me", "mein", "par", "aur", "ya", "ye",
        "yeh", "wo", "woh", "main", "mujhe", "meri", "mera", "mere", "hum", "tum", "aap", "bhi", "to", "toh", "nahi", "na"
    )

    private val SENSITIVE = Regex(
        "(?i)(\\b(cvv|cvc|pin|otp|password|passcode|passwd|iban|api[ _-]?key|secret|token)\\b|\\b(?:\\d[ -]?){13,19}\\b)"
    )

    fun isSensitive(t: String) = SENSITIVE.containsMatchIn(t)

    fun words(t: String): Set<String> =
        t.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length > 1 && it !in STOP }.toSet()

    fun similarity(a: String, b: String): Double {
        val x = words(a); val y = words(b)
        if (x.isEmpty() || y.isEmpty()) return 0.0
        val inter = x.intersect(y).size.toDouble()
        return inter / (x.size + y.size - inter)
    }

    fun clean(t: String): String = t.trim().replace(Regex("\\s+"), " ").trim('.', ' ', '\n').take(MAX_TEXT)

    fun normalizeKind(k: String?): String = when ((k ?: "").lowercase(Locale.ROOT).trim()) {
        "pref", "preference", "pasand", "aadat", "habit" -> "pref"
        "task", "kaam", "project", "todo", "ongoing" -> "task"
        "person", "log", "rishta", "contact", "family" -> "person"
        else -> "fact"
    }

    /** Finds an existing item that says (almost) the same thing, so we update instead of piling up copies. */
    fun findDuplicate(items: List<MemItem>, kind: String, text: String): MemItem? =
        items.filter { it.kind == kind }.firstOrNull { it.text.equals(text, true) || similarity(it.text, text) >= 0.7 }

    /** How useful this item is for the current message: word overlap first, then pinned, usage and recency. */
    fun score(it: MemItem, query: String, now: Long): Double {
        val q = words(query)
        val overlap = if (q.isEmpty()) 0.0 else words(it.text).intersect(q).size.toDouble()
        val ageDays = ((now - it.updated).coerceAtLeast(0L)) / 86_400_000.0
        val recency = 1.0 / (1.0 + ageDays / 30.0)
        return overlap * 3.0 + (if (it.pinned) 2.0 else 0.0) + minOf(it.hits, 10) * 0.1 + recency
    }

    /** What to put in front of the model for this message, limited so the prompt stays small. */
    fun pick(items: List<MemItem>, query: String, now: Long, maxChars: Int = 2200): List<MemItem> {
        val live = items.filter { !(it.kind == "task" && it.done) }
        val prefs = live.filter { it.kind == "pref" }.sortedByDescending { score(it, query, now) }.take(15)
        val tasks = live.filter { it.kind == "task" }.sortedByDescending { it.updated }.take(10)
        val rest = live.filter { it.kind == "person" || it.kind == "fact" }
            .map { it to score(it, query, now) }.sortedByDescending { it.second }.take(14).map { it.first }
        val out = ArrayList<MemItem>()
        var used = 0
        for (m in prefs + tasks + rest) {
            val cost = m.text.length + 12
            if (used + cost > maxChars) break
            out.add(m); used += cost
        }
        return out
    }

    private val PREF_RX = listOf(
        Regex("(?i)\\bmujhe\\b.{2,80}\\b(pasand|achha|acha|bura|nahi pasand|pasand nahi)\\b.*"),
        Regex("(?i)\\bmain\\b.{2,80}\\b(hamesha|aksar|roz|kabhi nahi)\\b.*"),
        Regex("(?i)\\b(i (really )?(prefer|like|love|hate|always|never|usually))\\b.*"),
        Regex("(?i)\\bmeri (pasand|aadat)\\b.*"),
    )
    private val PERSON_RX = listOf(
        Regex("(?i)\\b(meri|mera|mere)\\s+(ammi|abbu|bhai|behan|bahan|biwi|shohar|beta|beti|dost|boss|chacha|mama|khala|phupho|dada|dadi|nana|nani)\\b.*"),
        Regex("(?i)\\bmy\\s+(mother|father|mom|dad|brother|sister|wife|husband|son|daughter|friend|boss)\\b.*"),
        Regex("(?i)\\b(mera naam|my name is)\\b.*"),
    )
    private val TASK_RX = listOf(
        Regex("(?i)\\b(main|hum)\\b.{2,80}\\b(bana raha|bana rahi|likh raha|likh rahi|kar raha hoon|kar rahi hoon|seekh raha|seekh rahi)\\b.*"),
        Regex("(?i)\\b(i am|i'm) (working on|building|writing|learning|preparing)\\b.*"),
        Regex("(?i)\\bmera (project|kaam|exam|paper|interview)\\b.*"),
    )

    /** A clear, single statement about the user -> (kind, text). Conservative on purpose; questions and commands are ignored. */
    fun extract(userText: String): Pair<String, String>? {
        val t = clean(userText)
        if (t.length < 12 || t.length > MAX_TEXT) return null
        if (t.endsWith("?") || isSensitive(t)) return null
        val low = t.lowercase(Locale.ROOT)
        if (Regex("^(kya|kaise|kyun|kab|kahan|kaun|what|how|why|when|where|who|can you|could you|please|karo|kholo|bhejo)\\b").containsMatchIn(low)) return null
        if (PERSON_RX.any { it.containsMatchIn(t) }) return "person" to t
        if (TASK_RX.any { it.containsMatchIn(t) }) return "task" to t
        if (PREF_RX.any { it.containsMatchIn(t) }) return "pref" to t
        return null
    }

    /** Words that mean "this ongoing thing is finished". */
    fun looksFinished(t: String) =
        Regex("(?i)\\b(ho gaya|ho gayi|khatam|complete|completed|done|finished|mukammal)\\b").containsMatchIn(t)
}

/** Anjoo's long-term memory on the phone (a JSON file). Survives app updates; included in Backup. */
object LongMemory {
    private const val FILE = "long_memory.json"

    @Volatile private var lastQuery: String = ""

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    fun enabled(ctx: Context) = prefs(ctx).getBoolean("saveMemory", true)
    fun auto(ctx: Context) = enabled(ctx) && prefs(ctx).getBoolean("autoMemory", true)

    private fun toJson(m: MemItem) = JSONObject().put("id", m.id).put("k", m.kind).put("t", m.text)
        .put("c", m.created).put("u", m.updated).put("h", m.hits).put("d", m.done).put("p", m.pinned)

    private fun fromJson(o: JSONObject) = MemItem(
        o.getLong("id"), o.optString("k", "fact"), o.getString("t"), o.optLong("c"), o.optLong("u"),
        o.optInt("h"), o.optBoolean("d"), o.optBoolean("p")
    )

    @Synchronized
    fun all(ctx: Context): List<MemItem> {
        migrateOldNotes(ctx)
        return try {
            val a = JSONArray(file(ctx).takeIf { it.exists() }?.readText(Charsets.UTF_8) ?: "[]")
            (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) { emptyList() }
    }

    @Synchronized
    private fun save(ctx: Context, items: List<MemItem>) {
        var list = items
        if (list.size > MemLogic.MAX_ITEMS) {
            // drop the least useful first: finished tasks, then old unpinned items nobody asked about
            val keep = list.sortedByDescending {
                (if (it.pinned) 1000.0 else 0.0) + (if (it.kind == "task" && !it.done) 500.0 else 0.0) +
                    (if (it.done) -500.0 else 0.0) + it.hits * 2.0 + it.updated / 1.0e12
            }.take(MemLogic.MAX_ITEMS).map { it.id }.toSet()
            list = list.filter { it.id in keep }
        }
        val a = JSONArray()
        list.forEach { a.put(toJson(it)) }
        file(ctx).writeText(a.toString(), Charsets.UTF_8)
    }

    /** The old app kept up to 50 plain notes in settings. Move them over once, then leave them alone. */
    private fun migrateOldNotes(ctx: Context) {
        val p = prefs(ctx)
        if (p.getBoolean("memMigrated", false)) return
        p.edit().putBoolean("memMigrated", true).apply()
        try {
            val old = JSONArray(p.getString("notes", "[]"))
            if (old.length() == 0) return
            val now = System.currentTimeMillis()
            val a = JSONArray()
            for (i in 0 until old.length()) {
                val t = MemLogic.clean(old.getString(i))
                if (t.isNotEmpty()) a.put(toJson(MemItem(now + i, "fact", t, now, now)))
            }
            file(ctx).writeText(a.toString(), Charsets.UTF_8)
        } catch (e: Exception) {}
    }

    /** Saves (or refreshes) one memory. Returns a short message for the user. */
    @Synchronized
    fun add(ctx: Context, kindIn: String?, textIn: String, pinned: Boolean = false): String {
        if (!enabled(ctx)) return "Save Memory band hai, is liye yaad nahi rakha. (+ dabayen aur Save Memory on karein.)"
        val text = MemLogic.clean(textIn)
        if (text.length < 3) return "Kya yaad rakhna hai? Thori tafseel batayen."
        if (MemLogic.isSensitive(text)) return "Password, PIN, OTP, card ya API key main yaad nahi rakhta."
        val kind = MemLogic.normalizeKind(kindIn)
        val items = all(ctx).toMutableList()
        val now = System.currentTimeMillis()
        val dup = MemLogic.findDuplicate(items, kind, text)
        if (dup != null) {
            items[items.indexOf(dup)] = dup.copy(text = text, updated = now, done = false, pinned = dup.pinned || pinned)
            save(ctx, items)
            return "Pehle se yaad tha, taza kar diya."
        }
        items.add(MemItem(now, kind, text, now, now, pinned = pinned))
        save(ctx, items)
        return "Yaad rakh liya."
    }

    @Synchronized
    fun forget(ctx: Context, q: String): String {
        val items = all(ctx)
        val key = q.trim()
        if (key.length < 2) return "Kya bhulana hai?"
        val keep = items.filterNot { it.text.contains(key, true) }
        if (keep.size == items.size) return "Aisi koi yaad rakhi baat nahi mili."
        save(ctx, keep)
        return "${items.size - keep.size} baat bhula di."
    }

    /** Marks an ongoing job as finished (kept for history, not shown in the prompt any more). */
    @Synchronized
    fun complete(ctx: Context, q: String): String {
        val items = all(ctx).toMutableList()
        val m = items.filter { it.kind == "task" && !it.done }
            .maxByOrNull { if (it.text.contains(q, true)) 100.0 else MemLogic.similarity(it.text, q) * 10 }
            ?: return "Koi chal raha kaam nahi mila."
        if (!m.text.contains(q, true) && MemLogic.similarity(m.text, q) < 0.2) return "Is naam ka koi chal raha kaam nahi mila."
        items[items.indexOf(m)] = m.copy(done = true, updated = System.currentTimeMillis())
        save(ctx, items)
        return "Kaam mukammal likh liya: ${m.text}"
    }

    @Synchronized
    fun list(ctx: Context, kind: String? = null): String {
        val k = kind?.takeIf { it.isNotBlank() }?.let { MemLogic.normalizeKind(it) }
        val items = all(ctx).filter { k == null || it.kind == k }.sortedByDescending { it.updated }
        if (items.isEmpty()) return "Abhi kuch yaad nahi rakha."
        val label = mapOf("pref" to "pasand", "task" to "kaam", "person" to "log", "fact" to "baat")
        val sb = StringBuilder()
        for (m in items.take(60)) {
            sb.append("- [").append(label[m.kind]).append(if (m.done) ", mukammal" else "").append("] ").append(m.text).append("\n")
        }
        return sb.toString().trim()
    }

    /** Lines for the system prompt, chosen for the message the user just sent. */
    fun promptLines(ctx: Context): List<String> {
        if (!enabled(ctx)) return emptyList()
        val now = System.currentTimeMillis()
        val items = all(ctx)
        if (items.isEmpty()) return emptyList()
        val chosen = MemLogic.pick(items, lastQuery, now)
        touch(ctx, chosen.map { it.id }.toSet())
        val label = mapOf("pref" to "pasand", "task" to "chal raha kaam", "person" to "log", "fact" to "baat")
        return chosen.map { "[" + label[it.kind] + "] " + it.text }
    }

    @Synchronized
    private fun touch(ctx: Context, ids: Set<Long>) {
        if (ids.isEmpty()) return
        val items = all(ctx).map { if (it.id in ids) it.copy(hits = it.hits + 1) else it }
        save(ctx, items)
    }

    /** Old chats that mention the same words as the current message (so Anjoo can pick up where you left off). */
    fun relatedChats(ctx: Context, limit: Int = 3): String {
        val q = MemLogic.words(lastQuery)
        if (q.size < 2) return ""
        val cur = ChatStore.currentId(ctx)
        val a = ChatStore.all(ctx)
        data class Hit(val score: Int, val at: Long, val line: String)
        val hits = ArrayList<Hit>()
        for (i in 0 until a.length()) {
            val s = a.getJSONObject(i)
            if (s.optLong("id") == cur) continue
            val ls = s.optJSONArray("lines") ?: continue
            var best = 0; var bestLine = ""; var bestAt = 0L
            for (j in 0 until ls.length()) {
                val o = ls.getJSONObject(j)
                if (o.optInt("k") > 1) continue
                val n = MemLogic.words(o.optString("t")).intersect(q).size
                if (n > best) { best = n; bestLine = o.optString("t"); bestAt = o.optLong("at") }
            }
            if (best >= 2) hits.add(Hit(best, bestAt, bestLine.take(140)))
        }
        if (hits.isEmpty()) return ""
        val fmt = SimpleDateFormat("d MMM", Locale.ENGLISH)
        val sb = StringBuilder("Purani baat-cheet jo is baat se milti hai:\n")
        hits.sortedWith(compareByDescending<Hit> { it.score }.thenByDescending { it.at }).take(limit)
            .forEach { sb.append("- ").append(fmt.format(Date(it.at))).append(": ").append(it.line).append("\n") }
        return sb.toString()
    }

    /** Called for every message the user sends (typed or spoken). Remembers it as the "current topic" and saves clear facts on its own. */
    fun onUserMessage(ctx: Context, text: String) {
        lastQuery = text.take(400)
        if (!auto(ctx)) return
        try {
            if (MemLogic.looksFinished(text)) {
                val open = all(ctx).filter { it.kind == "task" && !it.done }
                val hit = open.firstOrNull { MemLogic.similarity(it.text, text) >= 0.25 }
                if (hit != null) { complete(ctx, hit.text); return }
            }
            val e = MemLogic.extract(text) ?: return
            add(ctx, e.first, e.second)
        } catch (e: Exception) { /* memory must never break chatting */ }
    }

    // ---- backup support
    fun exportArray(ctx: Context): JSONArray { val a = JSONArray(); all(ctx).forEach { a.put(toJson(it)) }; return a }

    /** Merges items from a backup: same id keeps the newest edit. */
    @Synchronized
    fun merge(ctx: Context, a: JSONArray) {
        val map = LinkedHashMap<Long, MemItem>()
        all(ctx).forEach { map[it.id] = it }
        for (i in 0 until a.length()) {
            val m = try { fromJson(a.getJSONObject(i)) } catch (e: Exception) { continue }
            val cur = map[m.id]
            if (cur == null || m.updated > cur.updated) map[m.id] = m
        }
        save(ctx, map.values.toList())
    }
}
