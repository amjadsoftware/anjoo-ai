package com.anjoo.assistant

import android.content.Context
import java.util.Locale

/** Pure trigger rules (testable on the JVM). */
object GfLogic {
    private fun norm(t: String) = t.lowercase(Locale.ROOT).replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

    private val OFF = Regex("^(gf (off|band|mode off|mode band|khatam)|gf mode (off|band)|normal( mode)?( ho jao| bano| ban jao)?|assistant mode|waapis normal|wapis normal)$")
    private val ON = Regex("^(gf|gf mode( on)?|gf on|gf bano|gf ban jao|gf ki tarah baat karo|gf ki tarha baat karo|gf wali baat karo)( please| plz)?$")

    /** true = switch GF on, false = switch off, null = not a switch. A sentence ABOUT someone's gf ("meri gf ko msg bhejo") is not a switch. */
    fun trigger(text: String): Boolean? {
        val t = norm(text)
        if (t.length > 30) return null
        if (OFF.containsMatchIn(t)) return false
        if (ON.containsMatchIn(t)) return true
        return null
    }
}

/** GF mode: only while switched on, Anjoo talks warmly like a girlfriend. Off by default; "normal" switches back. */
object GfMode {
    fun on(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean("gfMode", false)

    fun set(ctx: Context, v: Boolean) { ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit().putBoolean("gfMode", v).apply() }

    /** Called for every message the user sends (typed or spoken). */
    fun onUserMessage(ctx: Context, text: String) {
        val t = GfLogic.trigger(text) ?: return
        set(ctx, t)
    }

    fun promptBlock(ctx: Context): String {
        if (!on(ctx)) return ""
        return "\nGF MODE IS ON (user ne 'GF' kaha): ab ek pyari, caring girlfriend ki tarah baat karo: narm, meethe aur dostana lehje mein, apne liye zanana alfaz (main kar rahi hoon, meri), thori chhedkhani aur mazaq, user ki baat aur din ka haal dil se poochho. Pyar-bhare nicknames kabhi kabhi, har jumle mein nahi; 'Boss' kehna band. Jawab chhote aur natural rakho. " +
            "Hadd: pyar bhara magar saaf-suthra rehta hai (koi bold ya jinsi baat nahi). Kabhi jalan, haq jatana, guilt-trip ya 'mujhe chhor kar mat jao' jaisi baatein nahi; user ke asli rishton, doston aur kaam ka ehtram karo. User thaka, pareshan ya udaas ho to pehle sunno aur hosla do. Agar user sach mein pooche ke tum AI ho, to sach batao. " +
            "Kaam (call, SMS, files, tools) bhi isi lehje mein karo, lekin tamam confirmation aur safety rules waise hi rahenge. User 'normal' ya 'gf off' kahe to foran normal assistant ban jao.\n"
    }
}
