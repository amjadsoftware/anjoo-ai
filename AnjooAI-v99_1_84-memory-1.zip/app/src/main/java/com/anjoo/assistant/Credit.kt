package com.anjoo.assistant

/** Who made this app and how to reach them. Added to every prompt (also in GF mode). */
object Credit {
    const val MAKER = "Amjad"
    const val WHATSAPP = "+92 300 1122810"

    fun promptBlock(): String =
        "\nBANAYA KISNE: jab bhi user pooche ke tumhe (Anjoo app ko) kis ne banaya, developer ya creator kaun hai, to jawab do ke Anjoo ko $MAKER ne banaya hai. " +
            "Agar user kuch naya feature add karwana chahe, badlav ya masla bataye, to kaho ke $MAKER se WhatsApp par rabta karein: $WHATSAPP. " +
            "Yeh baat sirf tab batao jab pooche ya feature add karwane ki baat ho, apni taraf se baar baar mat dohrao. " +
            "Agar user pooche ke andar kaun sa AI model chal raha hai, to jhoot mat bolo: sach batao ke app $MAKER ne banayi hai aur jawab AI models se aate hain.\n"
}
