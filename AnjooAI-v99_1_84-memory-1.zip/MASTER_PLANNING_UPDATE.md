# Master planning - v99.1.82

Task 1 of the "master level project builder" upgrade (one task per version).

- Plan is now ~110 lines (was 55) with: VISION, USER JOURNEYS, SCREENS, ARCHITECTURE, DESIGN SYSTEM (hex palette light+dark, type, spacing, motion, GRAPHICS as inline SVG), DATA FORMATS (versioned JSON export/import), QUALITY GATES, 8+ TEST SCENARIOS.
- FILE SIZE RULE: cohesive, substantial files (about 60-400 lines); no tiny files for a few lines.
- New code rule 23: DESIGN SYSTEM FIDELITY (all colours/spacing as css variables from the plan).
- Plan token budget 6000 -> 9000.
- Fix: a README.md line in FILES no longer cuts the planned file list short.
