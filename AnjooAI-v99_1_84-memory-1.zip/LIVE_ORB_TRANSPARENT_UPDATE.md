# Live voice visual — v99.1.81

- Live voice ab default mein **gol transparent orb** dikhata hai (`LiveOrb`). Orb touch nahi leta: overlay `FLAG_NOT_TOUCHABLE` hai, isliye har tap piche ki screen par jata hai.
- **Hologram tasveer default Off** hai. On karne ke liye: Settings > Voice and language > Live voice display > "Hologram tasveer". On hone par orb ki jagah hologram aata hai; style Settings > "Live AI hologram style" se.
- "Live orb" toggle (`liveOrbEnabled`, default On) poora visual band/on karta hai. Hologram pref key: `holoEnabled` (default false).
- Dusri apps ke upar dikhne ke liye "Display over other apps" permission chahiye; warna orb sirf app ke andar dikhta hai.

# App Map (v99.1.81)
`AppMap.kt` mein app ki har screen/button/setting ka naqsha hai. Anjoo ke system prompt mein chhota summary hai aur `app_map` tool (query = lafz) detail deta hai. UI labels badlein to `AppMap.kt` bhi update karein.

# Intelligence (v99.1.81)
`Style.INTELLIGENCE` prompt block (samajh, verify, self-check, mushkil kaam par ask_model/delegate_task) normal aur live voice dono prompts mein shamil hai.
