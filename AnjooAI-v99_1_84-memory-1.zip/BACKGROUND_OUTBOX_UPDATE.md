# Background outbox - v99.1.83

- Offline messages that need AI stay in the Outbox (as before).
- NEW: when the internet returns, Android starts BgDrainService (JobScheduler, survives app close and reboot). It answers the waiting messages in the background, stores the answers (bg_results.json) and posts a notification.
- NEW: opening the app shows the finished answers in the chat (marked with the time they were prepared).
- If the net drops again mid-way, unanswered messages stay waiting and the job retries with backoff.
- Background mode never calls, sends SMS or replies for you.
- Setting: shared pref "bgAuto" (default true). When false the old "Send now?" dialog is used.
