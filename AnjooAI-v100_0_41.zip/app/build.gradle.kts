import java.util.Properties

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Private signing values are read from environment variables or the untracked local.properties file.
// The keystore and its passwords are deliberately never embedded in this source distribution.
val signingProperties = Properties().apply {
    val local = rootProject.file("local.properties")
    if (local.isFile) local.inputStream().use { load(it) }
}
fun privateValue(name: String): String? = System.getenv(name)?.takeIf { it.isNotBlank() }
    ?: signingProperties.getProperty(name)?.takeIf { it.isNotBlank() }
val signingStorePath = privateValue("ANJOO_STORE_FILE")
val signingStorePassword = privateValue("ANJOO_STORE_PASSWORD")
val signingKeyAlias = privateValue("ANJOO_KEY_ALIAS")
val signingKeyPassword = privateValue("ANJOO_KEY_PASSWORD")
// The fixed legacy key lives in app/anjoo.keystore. If that file is missing (for example it was
// not part of the ZIP that was unzipped over the repository), the build falls back to the standard
// Android debug key instead of failing. Such an APK builds fine, but it will NOT install over an
// app signed with the old key. Restore app/anjoo.keystore to keep in-place updates working.
val fixedKeystoreAvailable = file("anjoo.keystore").isFile
if (!fixedKeystoreAvailable) {
    logger.warn("WARNING: app/anjoo.keystore not found - signing with the default debug key. " +
        "Updates over an app signed with the old key will fail until the keystore is restored.")
}
val releaseSigningReady = !signingStorePath.isNullOrBlank() && !signingStorePassword.isNullOrBlank() &&
    !signingKeyAlias.isNullOrBlank() && !signingKeyPassword.isNullOrBlank() && project.file(signingStorePath).isFile

android {
    namespace = "com.anjoo.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.anjoo.assistant"
        minSdk = 26
        targetSdk = 34
        val buildNumber = System.getenv("BUILD_NUMBER")?.toIntOrNull()
        versionCode = buildNumber ?: 100041
        versionName = "100.0.41" + (System.getenv("BUILD_LABEL")?.let { " ($it)" } ?: "")
        buildConfigField("String", "UPDATE_REPO", "\"" + (System.getenv("GITHUB_REPOSITORY") ?: "") + "\"")
        val hsSupabaseAnonKey = System.getenv("HS_SUPABASE_ANON_KEY") ?: "sb_publishable__HUv75xSBdu0NPQf4ijgPQ_o1VK_rRL"
        buildConfigField("String", "HS_SUPABASE_ANON_KEY", "\"" + hsSupabaseAnonKey.replace("\\", "\\\\").replace("\"", "\\\"") + "\"")
    }

    // Fixed legacy key: every build (GitHub debug builds too) is signed with the same key,
    // so a new APK installs over the old app. Do not remove, or Android refuses updates.
    signingConfigs {
        create("anjooFixed") {
            storeFile = file("anjoo.keystore")
            storePassword = "anjoo123"
            keyAlias = "anjoo"
            keyPassword = "anjoo123"
        }
        if (releaseSigningReady) {
            create("anjoo") {
                storeFile = project.file(signingStorePath!!)
                storePassword = signingStorePassword
                keyAlias = signingKeyAlias
                keyPassword = signingKeyPassword
            }
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName(if (fixedKeystoreAvailable) "anjooFixed" else "debug")
        }
        release {
            // A release APK is signed only when the owner supplies a private signing key.
            // Without one, Gradle produces an unsigned release; never fall back to a public test key.
            signingConfig = signingConfigs.getByName(
                when {
                    releaseSigningReady -> "anjoo"
                    fixedKeystoreAvailable -> "anjooFixed"
                    else -> "debug"
                }
            )
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    buildFeatures { buildConfig = true }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
        htmlReport = true
        xmlReport = true
    }

    testOptions {
        unitTests { isReturnDefaultValues = true }
    }

    packaging {
        resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" }
    }
}

dependencies {
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20240303")
}
