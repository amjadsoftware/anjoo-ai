package com.anjoo.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** The opening screen: the Anjoo AI mark glows in, then the app opens. */
class SplashActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var opened = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /** A soft teal glow that slowly breathes behind the logo. */
    private class Glow(ctx: android.content.Context) : View(ctx) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(c: android.graphics.Canvas) {
            val r = minOf(width, height) / 2f
            p.shader = RadialGradient(width / 2f, height / 2f, r,
                intArrayOf(Color.argb(130, 45, 212, 191), Color.argb(45, 45, 212, 191), Color.argb(0, 45, 212, 191)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(width / 2f, height / 2f, r, p)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val top = Color.parseColor("#050B10")
        val mid = Color.parseColor("#0A2428")
        window.setBackgroundDrawable(ColorDrawable(top))
        try { window.statusBarColor = top; window.navigationBarColor = top } catch (e: Exception) {}

        val root = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, mid, top))
        }

        val glow = Glow(this).apply { alpha = 0f }
        root.addView(glow, FrameLayout.LayoutParams(dp(420), dp(420), Gravity.CENTER).apply { bottomMargin = dp(70) })

        val tile = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#0A1520"), Color.parseColor("#0C2F36"), Color.parseColor("#12665F"))).apply {
                cornerRadius = dp(38).toFloat(); setStroke(dp(1), Color.argb(90, 45, 212, 191))
            }
            elevation = dp(14).toFloat()
            alpha = 0f; scaleX = 0.6f; scaleY = 0.6f
        }
        tile.addView(ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground) },
            FrameLayout.LayoutParams(dp(210), dp(210), Gravity.CENTER))
        root.addView(tile, FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER).apply { bottomMargin = dp(70) })

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; alpha = 0f; translationY = dp(24).toFloat() }
        texts.addView(TextView(this).apply {
            text = "Anjoo AI"; textSize = 34f; setTextColor(Color.WHITE); letterSpacing = 0.06f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        })
        texts.addView(TextView(this).apply {
            text = "Aapki awaaz. Aapka assistant."; textSize = 14f; setTextColor(Color.parseColor("#8FD9CD")); letterSpacing = 0.04f
            setPadding(0, dp(8), 0, 0)
        })
        root.addView(texts, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { topMargin = dp(190) })

        root.addView(TextView(this).apply {
            text = "Voice  ·  Chat  ·  Code  ·  Phone"; textSize = 11.5f; setTextColor(Color.parseColor("#5E7F7B")); letterSpacing = 0.12f
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(48) })

        setContentView(root)

        glow.animate().alpha(1f).setDuration(900).start()
        glow.animate().scaleX(1.08f).scaleY(1.08f).setDuration(1400).setInterpolator(AccelerateDecelerateInterpolator()).start()
        tile.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(750).setInterpolator(OvershootInterpolator(1.1f)).start()
        texts.animate().alpha(1f).translationY(0f).setDuration(650).setStartDelay(450).start()

        ui.postDelayed({ openApp() }, 2200)
        root.setOnClickListener { openApp() }
    }

    private fun openApp() {
        if (opened) return
        opened = true
        val i = Intent(this, MainActivity::class.java)
        intent?.extras?.let { i.putExtras(it) }
        startActivity(i)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
