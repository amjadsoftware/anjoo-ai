package com.anjoo.assistant

import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Random
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private const val PIF = 3.1415927f
private const val TWO_PI = 6.2831855f
private const val NSYM = 5          // five symbiotes
private const val NS = 12           // segments per tentacle
private const val T_CLASH = 2.0f    // the fight starts
private const val T_MERGE = 4.0f    // they spiral into one
private const val IMPACT = 5.4f     // merge completes, logo bursts out

/**
 * Opening scene, a short film (all drawn with code, tap to skip):
 *  1. a deep-space nebula with stars; five living symbiotes, each with its own colour and tentacle style, rush in from the edges;
 *  2. ACTION: they lunge at each other, lightning arcs between them, impacts throw sparks, the camera shakes;
 *  3. MERGE: the stars are pulled in, the five spiral into the centre and fuse into one glowing core;
 *  4. a flash, multi-colour shockwaves and the Anjoo logo (same shape as the app icon, in Claude orange) bursts out.
 */
class SplashActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private var opened = false
    private var anim: ValueAnimator? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private class Sym(val body: Int, val vein: Int, val style: Int, val n: Int, val size: Float, val ph: Float)

    private class Scene(ctx: Context) : View(ctx) {
        var t = 0f // seconds
        private val d = resources.displayMetrics.density
        private val rnd = Random(7)
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        private val path = Path()
        private val rect = RectF()
        private val CLAUDE = Color.rgb(217, 119, 87)
        private val logo = ctx.resources.getDrawable(R.drawable.ic_launcher_foreground, null).mutate().also { it.setTint(CLAUDE) }
        private var hit = false
        private var hit2 = false
        private val tmp = FloatArray(2)
        private val tmp2 = FloatArray(2)
        private val xs = FloatArray(NS + 1)
        private val ys = FloatArray(NS + 1)

        // five symbiotes: body colour, vein/glow colour, tentacle style, tentacle count, size, phase
        private val syms = listOf(
            Sym(Color.rgb(6, 6, 12), Color.rgb(215, 230, 255), 0, 7, 1.00f, 0.0f),     // obsidian: thick spiky
            Sym(Color.rgb(110, 4, 16), Color.rgb(255, 64, 74), 1, 9, 0.90f, 1.3f),     // crimson: thin fast whips
            Sym(Color.rgb(8, 38, 110), Color.rgb(70, 225, 255), 2, 5, 1.05f, 2.1f),    // azure: smooth ribbons
            Sym(Color.rgb(18, 64, 18), Color.rgb(150, 255, 70), 3, 6, 0.95f, 3.4f),    // toxic green: zig-zag
            Sym(Color.rgb(58, 10, 88), Color.rgb(255, 95, 230), 4, 6, 1.00f, 4.6f)     // violet: curling spirals
        )

        // ---- stars
        private val NST = 110
        private val stX = FloatArray(NST) { rnd.nextFloat() }
        private val stY = FloatArray(NST) { rnd.nextFloat() }
        private val stS = FloatArray(NST) { 0.6f + rnd.nextFloat() * 1.8f }
        private val stP = FloatArray(NST) { rnd.nextFloat() * 6.28f }
        private val stL = FloatArray(NST) { 0.3f + rnd.nextFloat() * 0.9f }

        // ---- sparks of the final burst
        private val spAng = FloatArray(56) { rnd.nextFloat() * TWO_PI }
        private val spSpd = FloatArray(56) { 90f + rnd.nextFloat() * 260f }
        private val spSz = FloatArray(56) { 1.2f + rnd.nextFloat() * 2.6f }

        private fun ease(x: Float): Float { val k = x.coerceIn(0f, 1f); return 1f - (1f - k) * (1f - k) * (1f - k) }
        private fun smooth(x: Float): Float { val k = x.coerceIn(0f, 1f); return k * k * (3f - 2f * k) }

        private fun back(x: Float): Float {
            val k = x.coerceIn(0f, 1f) - 1f
            return 1f + 2.70158f * k * k * k + 1.70158f * k * k
        }

        private fun mix(a: Int, b: Int, k: Float): Int {
            val q = k.coerceIn(0f, 1f)
            return Color.rgb(
                (Color.red(a) + (Color.red(b) - Color.red(a)) * q).toInt(),
                (Color.green(a) + (Color.green(b) - Color.green(a)) * q).toInt(),
                (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * q).toInt()
            )
        }

        private fun argb(a: Float, col: Int): Int =
            Color.argb((255f * a.coerceIn(0f, 1f)).toInt(), Color.red(col), Color.green(col), Color.blue(col))

        private fun angLerp(a: Float, b: Float, k: Float): Float {
            var df = (b - a) % TWO_PI
            if (df > PIF) df -= TWO_PI
            if (df < -PIF) df += TWO_PI
            return a + df * k.coerceIn(0f, 1f)
        }

        private fun tri(x: Float): Float {
            val q = ((x % 2f) + 2f) % 2f
            return (if (q < 1f) q else 2f - q) * 2f - 1f
        }

        private fun symAng(i: Int) = -PIF / 2f + i * TWO_PI / NSYM

        /** 1 while the fight is on, 0 before and after. */
        private fun clashAt(tt: Float): Float =
            ((tt - T_CLASH) / 0.3f).coerceIn(0f, 1f) * (1f - ((tt - T_MERGE) / 0.4f).coerceIn(0f, 1f))

        /** Each symbiote lunges at its neighbour in turn. */
        private fun lunge(i: Int, tt: Float): Float {
            val s = sin((tt - T_CLASH) * 3.4f + i * 1.256f)
            return if (s > 0f) s * s else 0f
        }

        /** Impact flash (0..1) where symbiote i hits the next one. */
        private fun flashOf(i: Int): Float {
            val ph = (t - T_CLASH) * 3.4f + i * 1.256f
            val q = ((ph % TWO_PI) + TWO_PI) % TWO_PI
            if (q >= PIF) return 0f
            return (1f - abs(q - PIF / 2f) / 0.55f).coerceIn(0f, 1f)
        }

        /** Where symbiote i is at time tt: rush in, fight, then spiral to the centre. */
        private fun posAt(i: Int, tt: Float, w: Float, h: Float, cx: Float, cy: Float, out: FloatArray) {
            val a = symAng(i)
            val sx = cx + cos(a) * w * 0.30f
            val sy = cy + sin(a) * h * 0.15f
            val ox = cx + cos(a) * w * 1.0f
            val oy = cy + sin(a) * h * 0.55f
            val arr = ease((tt - 0.3f - 0.12f * i) / 1.4f)
            var x = ox + (sx - ox) * arr
            var y = oy + (sy - oy) * arr
            val on = clashAt(tt)
            if (on > 0f) {
                val j = (i + 1) % NSYM
                val nx = cx + cos(symAng(j)) * w * 0.30f
                val ny = cy + sin(symAng(j)) * h * 0.15f
                val lun = lunge(i, tt) * on
                x += (nx - sx) * 0.42f * lun
                y += (ny - sy) * 0.42f * lun
            }
            x += sin(tt * 1.7f + i) * 6f * d * arr
            y += cos(tt * 1.3f + i * 2f) * 6f * d * arr
            val m = smooth((tt - T_MERGE) / (IMPACT - T_MERGE))
            if (m > 0f) {
                val rot = m * 5.2f
                val dx = x - cx
                val dy = y - cy
                val cr = cos(rot)
                val sr = sin(rot)
                val k = 1f - m * 0.97f
                x = cx + (dx * cr - dy * sr) * k
                y = cy + (dx * sr + dy * cr) * k
            }
            out[0] = x
            out[1] = y
        }

        /** Tentacle shape per style: how much the direction bends along its length. */
        private fun bend(style: Int, f: Float, ph: Float, dir: Float): Float = when (style) {
            0 -> sin(f * 4f - t * 3.5f + ph) * 0.55f * f
            1 -> sin(f * 9f - t * 9f + ph) * 0.95f * f
            2 -> sin(f * 2.6f - t * 2.2f + ph) * 0.9f
            3 -> tri(f * 7f - t * 4f + ph) * 0.85f * f
            else -> f * f * 3.3f * dir + sin(t * 2f + ph) * 0.2f
        }

        override fun onDraw(c: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            if (w == 0f) return
            val cx = w / 2f
            val cy = h * 0.40f
            val on = clashAt(t)
            var fs = 0f
            if (on > 0f) for (i in 0 until NSYM) fs += flashOf(i)

            if (!hit2 && t >= T_CLASH) { hit2 = true; try { performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) } catch (e: Exception) {} }
            if (!hit && t >= IMPACT) { hit = true; try { performHapticFeedback(HapticFeedbackConstants.LONG_PRESS) } catch (e: Exception) {} }

            // camera shake: grows with the fight, spikes at the final impact
            c.save()
            var shake = 0f
            if (on > 0f) shake = on * (1.2f + 3.5f * min(1f, fs)) * d
            if (t > IMPACT - 0.35f && t < IMPACT + 0.35f) shake = max(shake, 7f * d * (1f - abs(t - IMPACT) / 0.35f))
            if (shake > 0f) c.translate(sin(t * 83f) * shake, cos(t * 71f) * shake)

            drawBackground(c, w, h, cx, cy, on)

            if (t < IMPACT) {
                for (i in 0 until NSYM) drawTrail(c, i, w, h, cx, cy)
                for (i in 0 until NSYM) drawSym(c, i, w, h, cx, cy)
                drawClash(c, w, h, cx, cy, on)
                drawOrb(c, cx, cy)
            }
            if (t >= IMPACT) drawLogo(c, w, h, cx, cy)

            c.restore()

            // glitch strips at the big moments
            if ((t > 1.95f && t < 2.07f) || (t > 3.95f && t < 4.07f) || (t > IMPACT - 0.1f && t < IMPACT)) {
                p.style = Paint.Style.FILL
                for (i in 0 until 7) {
                    val y = rnd.nextFloat() * h
                    val gh = (2f + rnd.nextFloat() * 10f) * d
                    val ox = (rnd.nextFloat() - 0.5f) * 40f * d
                    p.color = if (i % 2 == 0) Color.argb(110, 255, 255, 255) else argb(0.45f, syms[i % NSYM].vein)
                    c.drawRect(ox, y, w + ox, y + gh, p)
                }
            }

            // impact flash
            if (t >= IMPACT && t <= IMPACT + 0.4f) c.drawColor(Color.argb((235 * (1f - (t - IMPACT) / 0.4f)).toInt(), 255, 255, 255))

            // scanlines + vignette for the film look
            p.style = Paint.Style.FILL
            p.color = Color.argb(18, 0, 0, 0)
            var yy = 0f
            while (yy < h) { c.drawRect(0f, yy, w, yy + d, p); yy += 3f * d }
            p.shader = RadialGradient(cx, h / 2f, hypot(w, h) * 0.6f,
                intArrayOf(Color.argb(0, 0, 0, 0), Color.argb(150, 0, 0, 0)), floatArrayOf(0.55f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, p)
            p.shader = null

            // letterbox bars open up after the impact
            val bar = h * 0.10f * (1f - ease((t - (IMPACT + 0.2f)) / 0.7f))
            if (bar > 0f) {
                p.color = Color.BLACK
                c.drawRect(0f, 0f, w, bar, p)
                c.drawRect(0f, h - bar, w, h, p)
            }

            // fade in from black
            if (t < 0.5f) c.drawColor(Color.argb((255 * (1f - t / 0.5f)).toInt(), 0, 0, 0))
        }

        private fun nebula(c: Canvas, x: Float, y: Float, r: Float, col: Int, a: Float) {
            p.shader = RadialGradient(x, y, r, intArrayOf(argb(a, col), argb(0f, col)), null, Shader.TileMode.CLAMP)
            c.drawCircle(x, y, r, p)
            p.shader = null
        }

        /** Deep-space nebula and stars; it turns warm Claude orange after the merge. */
        private fun drawBackground(c: Canvas, w: Float, h: Float, cx: Float, cy: Float, on: Float) {
            p.style = Paint.Style.FILL
            val warm = smooth((t - IMPACT) / 1.2f)
            val m = smooth((t - T_MERGE) / (IMPACT - T_MERGE))
            p.shader = LinearGradient(0f, 0f, 0f, h,
                mix(Color.rgb(6, 3, 20), Color.rgb(26, 10, 6), warm), mix(Color.rgb(2, 2, 10), Color.rgb(8, 4, 4), warm), Shader.TileMode.CLAMP)
            c.drawRect(-20f * d, -20f * d, w + 20f * d, h + 20f * d, p)
            p.shader = null

            val inten = 0.30f + 0.22f * on + 0.15f * m
            val orange = Color.rgb(217, 119, 87)
            val pull = m * 0.55f
            val x1 = (w * (0.22f + 0.08f * sin(t * 0.3f))).let { it + (cx - it) * pull }
            val y1 = (h * (0.18f + 0.05f * cos(t * 0.25f))).let { it + (cy - it) * pull }
            val x2 = (w * (0.82f + 0.06f * cos(t * 0.27f))).let { it + (cx - it) * pull }
            val y2 = (h * (0.52f + 0.06f * sin(t * 0.22f))).let { it + (cy - it) * pull }
            val x3 = (w * (0.35f + 0.07f * sin(t * 0.21f))).let { it + (cx - it) * pull }
            val y3 = (h * (0.88f + 0.04f * cos(t * 0.3f))).let { it + (cy - it) * pull }
            nebula(c, x1, y1, w * 0.95f, mix(Color.rgb(125, 45, 210), orange, warm), inten)
            nebula(c, x2, y2, w * 0.85f, mix(Color.rgb(35, 100, 230), Color.rgb(240, 150, 110), warm), inten * 0.9f)
            nebula(c, x3, y3, w * 0.95f, mix(Color.rgb(220, 45, 150), Color.rgb(180, 80, 60), warm), inten * 0.8f)
            nebula(c, cx, cy, w * 0.7f, mix(Color.rgb(40, 200, 200), orange, warm), 0.10f + 0.12f * on)

            // stars: they twinkle, drift down, and are pulled toward the centre during the merge
            p.strokeCap = Paint.Cap.ROUND
            for (i in 0 until NST) {
                val x = stX[i] * w
                val y = ((stY[i] + t * 0.012f * stL[i]) % 1f) * h
                val tw = 0.35f + 0.65f * (0.5f + 0.5f * sin(t * (1.5f + stL[i] * 2f) + stP[i]))
                val col = if (i % 5 == 0) Color.rgb(255, 215, 190) else if (i % 7 == 0) Color.rgb(190, 210, 255) else Color.WHITE
                if (m > 0.05f && t < IMPACT + 0.1f) {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = stS[i] * d * 0.8f
                    p.color = argb(tw, col)
                    c.drawLine(x, y, x + (cx - x) * 0.14f * m * stL[i], y + (cy - y) * 0.14f * m * stL[i], p)
                    p.style = Paint.Style.FILL
                } else {
                    p.color = argb(tw, col)
                    c.drawCircle(x, y, stS[i] * d * 0.7f, p)
                }
            }

            // shooting stars
            p.style = Paint.Style.STROKE
            for (k in 0..1) {
                val q = (t * 0.55f + k * 0.8f) % 2.4f
                if (q < 0.45f) {
                    val f = q / 0.45f
                    val hx = w * (0.10f + 0.5f * k) + f * w * 0.38f
                    val hy = h * (0.05f + 0.10f * k) + f * h * 0.13f
                    for (s in 0 until 7) {
                        p.strokeWidth = (2.2f - s * 0.28f) * d
                        p.color = argb((1f - f) * (1f - s / 7f), Color.WHITE)
                        c.drawLine(hx - s * 11f * d, hy - s * 3.3f * d, hx - (s + 1) * 11f * d, hy - (s + 1) * 3.3f * d, p)
                    }
                }
            }
            p.style = Paint.Style.FILL
        }

        /** A comet tail behind a symbiote while it moves fast. */
        private fun drawTrail(c: Canvas, i: Int, w: Float, h: Float, cx: Float, cy: Float) {
            val s = syms[i]
            posAt(i, t, w, h, cx, cy, tmp)
            var px = tmp[0]
            var py = tmp[1]
            posAt(i, t - 0.035f, w, h, cx, cy, tmp2)
            val sp = min(1f, hypot(px - tmp2[0], py - tmp2[1]) / (14f * d))
            if (sp < 0.05f) return
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            for (k in 1..14) {
                posAt(i, t - k * 0.035f, w, h, cx, cy, tmp2)
                val f = k / 14f
                p.color = argb(0.5f * sp * (1f - f), s.vein)
                p.strokeWidth = 26f * d * (1f - f) * s.size
                c.drawLine(px, py, tmp2[0], tmp2[1], p)
                px = tmp2[0]
                py = tmp2[1]
            }
            p.style = Paint.Style.FILL
        }

        private fun drawSym(c: Canvas, i: Int, w: Float, h: Float, cx: Float, cy: Float) {
            val s = syms[i]
            val arr = ease((t - 0.3f - 0.12f * i) / 1.4f)
            if (arr <= 0.01f) return
            val m = smooth((t - T_MERGE) / (IMPACT - T_MERGE))
            val al = 1f - smooth((t - (IMPACT - 0.2f)) / 0.2f)
            if (al <= 0.01f) return
            posAt(i, t, w, h, cx, cy, tmp)
            val x = tmp[0]
            val y = tmp[1]
            posAt((i + 1) % NSYM, t, w, h, cx, cy, tmp2)
            val aim = atan2(tmp2[1] - y, tmp2[0] - x)
            val on = clashAt(t)
            val lun = lunge(i, t) * on
            val br = 34f * d * s.size * (1f - 0.35f * m) * (0.5f + 0.5f * arr)
            val dir = if (i % 2 == 0) 1f else -1f

            // glow
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(x, y, br * 3.2f, intArrayOf(argb(0.55f * al, s.vein), argb(0f, s.vein)), null, Shader.TileMode.CLAMP)
            c.drawCircle(x, y, br * 3.2f, p)
            p.shader = null

            // tentacles
            val base = when (s.style) { 0 -> 12f; 1 -> 4f; 2 -> 9f; 3 -> 8f; else -> 7f }
            val thick = base * d * s.size
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            for (q in 0 until s.n) {
                val striker = q % 2 == 0
                var th = q * TWO_PI / s.n + t * 0.45f * dir + s.ph + m * 5.2f
                if (striker && lun > 0f) th = angLerp(th, aim, lun * 0.85f)
                val grow = if (striker) 1.15f * lun else 0.15f * on
                val len = (78f + 46f * ((q * 37) % 10) / 10f) * d * s.size * (0.4f + 0.6f * arr) * (1f + grow) * (1f - 0.45f * m)
                var px = x + cos(th) * br * 0.7f
                var py = y + sin(th) * br * 0.7f
                xs[0] = px
                ys[0] = py
                val step = len / NS
                val ph = s.ph + q * 0.9f
                for (k in 1..NS) {
                    val f = k / NS.toFloat()
                    val a = th + bend(s.style, f, ph, dir)
                    px += cos(a) * step
                    py += sin(a) * step
                    xs[k] = px
                    ys[k] = py
                }
                for (pass in 0..2) {
                    for (k in 0 until NS) {
                        val f = k / NS.toFloat()
                        val wd = thick * (1f - 0.88f * f) + 1.2f * d
                        if (pass == 0) { p.color = argb(0.28f * al, s.vein); p.strokeWidth = wd * 2.4f }
                        else if (pass == 1) { p.color = argb(al, s.body); p.strokeWidth = wd }
                        else { p.color = argb(0.85f * al, s.vein); p.strokeWidth = max(1.1f * d, wd * 0.16f) }
                        c.drawLine(xs[k], ys[k], xs[k + 1], ys[k + 1], p)
                    }
                }
                p.style = Paint.Style.FILL
                p.color = argb(al, Color.WHITE)
                c.drawCircle(xs[NS], ys[NS], 2.4f * d, p)
                p.style = Paint.Style.STROKE
            }
            p.style = Paint.Style.FILL

            // body: a main blob with wobbling satellites
            p.color = argb(al, s.body)
            c.drawCircle(x, y, br, p)
            for (k in 0 until 6) {
                val aa = k * PIF / 3f + t * (1.1f + 0.2f * k) * dir + s.ph
                val off = br * (0.62f + 0.22f * sin(t * 3.2f + k * 1.7f + s.ph))
                c.drawCircle(x + cos(aa) * off, y + sin(aa) * off, br * (0.46f + 0.12f * sin(t * 2.4f + k)), p)
            }
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * d
            p.color = argb(0.65f * al, s.vein)
            c.drawCircle(x, y, br * 1.02f, p)
            p.style = Paint.Style.FILL
            p.color = argb(0.22f * al, s.vein)
            c.drawCircle(x - br * 0.3f, y - br * 0.3f, br * 0.4f, p)

            // angry glowing eyes that look at the opponent (or the centre)
            val face = if (on > 0.5f) aim else atan2(cy - y, cx - x)
            c.save()
            c.translate(x, y)
            c.rotate(Math.toDegrees(face.toDouble()).toFloat())
            for (sg in intArrayOf(-1, 1)) {
                c.save()
                c.translate(br * 0.42f, sg * br * 0.3f)
                c.rotate(sg * 24f)
                rect.set(-br * 0.36f, -br * 0.15f, br * 0.36f, br * 0.15f)
                p.color = argb(0.55f * al, s.vein)
                c.drawOval(rect, p)
                rect.set(-br * 0.28f, -br * 0.08f, br * 0.28f, br * 0.08f)
                p.color = argb(al, Color.WHITE)
                c.drawOval(rect, p)
                c.restore()
            }
            c.restore()
        }

        /** Lightning between fighters and a burst of sparks where they hit. */
        private fun drawClash(c: Canvas, w: Float, h: Float, cx: Float, cy: Float, on: Float) {
            if (on <= 0f) return
            for (i in 0 until NSYM) {
                val j = (i + 1) % NSYM
                posAt(i, t, w, h, cx, cy, tmp)
                val ax = tmp[0]
                val ay = tmp[1]
                posAt(j, t, w, h, cx, cy, tmp2)
                val bx = tmp2[0]
                val by = tmp2[1]
                val si = syms[i]
                val sj = syms[j]
                val lun = lunge(i, t)
                if (lun > 0.3f) {
                    val rr = Random(((t * 24f).toInt() * 31 + i * 7).toLong())
                    val nx = -(by - ay)
                    val ny = bx - ax
                    val ln = max(1f, hypot(nx, ny))
                    path.reset()
                    path.moveTo(ax, ay)
                    val n = 8
                    for (k in 1 until n) {
                        val f = k / n.toFloat()
                        val o = (rr.nextFloat() - 0.5f) * 46f * d * lun
                        path.lineTo(ax + (bx - ax) * f + nx / ln * o, ay + (by - ay) * f + ny / ln * o)
                    }
                    path.lineTo(bx, by)
                    p.style = Paint.Style.STROKE
                    p.strokeCap = Paint.Cap.ROUND
                    p.strokeWidth = 5f * d
                    p.color = argb(0.35f * on * lun, mix(si.vein, sj.vein, 0.5f))
                    c.drawPath(path, p)
                    p.strokeWidth = 1.6f * d
                    p.color = argb(0.95f * on * lun, Color.WHITE)
                    c.drawPath(path, p)
                    p.style = Paint.Style.FILL
                }
                val fl = flashOf(i) * on
                if (fl > 0.02f) {
                    val mx = (ax + bx) / 2f
                    val my = (ay + by) / 2f
                    val col = mix(si.vein, sj.vein, 0.5f)
                    val r = 70f * d * fl
                    p.style = Paint.Style.FILL
                    p.shader = RadialGradient(mx, my, r,
                        intArrayOf(argb(0.95f * fl, Color.WHITE), argb(0.6f * fl, col), argb(0f, col)),
                        floatArrayOf(0f, 0.3f, 1f), Shader.TileMode.CLAMP)
                    c.drawCircle(mx, my, r, p)
                    p.shader = null
                    val cyc = (((t - T_CLASH) * 3.4f + i * 1.256f) / TWO_PI).toInt()
                    val sr = Random(cyc * 17L + i)
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = 2f * d
                    p.strokeCap = Paint.Cap.ROUND
                    for (k in 0 until 12) {
                        val ang = sr.nextFloat() * TWO_PI
                        val l1 = (12f + sr.nextFloat() * 20f) * d
                        val l2 = l1 + (24f + sr.nextFloat() * 70f) * d * fl
                        p.color = argb(fl, if (k % 2 == 0) Color.WHITE else if (k % 4 == 1) si.vein else sj.vein)
                        c.drawLine(mx + cos(ang) * l1, my + sin(ang) * l1, mx + cos(ang) * l2, my + sin(ang) * l2, p)
                    }
                    p.style = Paint.Style.FILL
                }
            }
        }

        /** The fused core that grows in the middle while the five spiral in. */
        private fun drawOrb(c: Canvas, cx: Float, cy: Float) {
            val k = smooth((t - (T_MERGE + 0.3f)) / (IMPACT - T_MERGE - 0.3f))
            if (k <= 0f) return
            val r = (14f + 70f * k) * d
            val col = mix(syms[(t * 6f).toInt() % NSYM].vein, Color.WHITE, 0.35f * k)
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(cx, cy, r * 2.4f,
                intArrayOf(argb(0.9f * k, Color.WHITE), argb(0.75f * k, col), argb(0f, col)),
                floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 2.4f, p)
            p.shader = null
            for (i in 0 until NSYM) {
                val aa = t * 7f + i * TWO_PI / NSYM
                p.color = argb(0.9f * k, syms[i].vein)
                c.drawCircle(cx + cos(aa) * r * 1.1f, cy + sin(aa) * r * 0.9f, 5f * d * (0.6f + 0.4f * k), p)
            }
        }

        private fun drawLogo(c: Canvas, w: Float, h: Float, cx: Float, cy: Float) {
            val lt = t - IMPACT
            val ga = ease(lt / 0.6f)
            p.style = Paint.Style.FILL

            // god rays
            val ra = smooth(lt / 0.8f) * 0.30f
            if (ra > 0.01f) {
                val rr = hypot(w, h) * 0.7f
                p.shader = RadialGradient(cx, cy, rr, intArrayOf(argb(ra, Color.rgb(240, 160, 120)), argb(0f, CLAUDE)), null, Shader.TileMode.CLAMP)
                for (k in 0 until 14) {
                    val a = k * TWO_PI / 14f + t * 0.15f
                    path.reset()
                    path.moveTo(cx, cy)
                    path.lineTo(cx + cos(a - 0.07f) * rr, cy + sin(a - 0.07f) * rr)
                    path.lineTo(cx + cos(a + 0.07f) * rr, cy + sin(a + 0.07f) * rr)
                    path.close()
                    c.drawPath(path, p)
                }
                p.shader = null
            }

            // glow behind the logo
            val gr = 190f * d * (1f + 0.04f * sin(t * 3f))
            p.shader = RadialGradient(cx, cy, gr,
                intArrayOf(Color.argb((170 * ga).toInt(), 217, 119, 87), Color.argb((60 * ga).toInt(), 201, 100, 66), Color.argb(0, 60, 30, 20)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, gr, p)
            p.shader = null

            // shockwaves: one ring in each symbiote colour, then Claude orange
            p.style = Paint.Style.STROKE
            for (k in 0..5) {
                val rl = lt - 0.09f * k
                if (rl < 0f || rl > 1.4f) continue
                val f = rl / 1.4f
                p.strokeWidth = (2f + 6f * (1f - f)) * d
                p.color = argb(0.85f * (1f - f), if (k < NSYM) syms[k].vein else CLAUDE)
                c.drawCircle(cx, cy, rl * w * 0.85f, p)
            }

            // two tilted orbit rings
            p.strokeWidth = 2f * d
            for (r in 0..1) {
                c.save()
                c.rotate(if (r == 0) t * 40f else -t * 30f + 60f, cx, cy)
                rect.set(cx - 125f * d, cy - 46f * d, cx + 125f * d, cy + 46f * d)
                p.color = Color.argb((120 * ga).toInt(), 217, 119, 87)
                c.drawOval(rect, p)
                c.restore()
            }
            p.style = Paint.Style.FILL

            // logo pops out (same shape as the app icon, Claude orange)
            val k = back(lt / 0.8f)
            val s = (150f * d * k).toInt()
            if (s > 0) {
                logo.alpha = (255 * ease(lt / 0.3f)).toInt()
                logo.setBounds((cx - s / 2f).toInt(), (cy - s / 2f).toInt(), (cx + s / 2f).toInt(), (cy + s / 2f).toInt())
                logo.draw(c)
            }

            // anamorphic lens flare
            val fa = ga * (0.55f + 0.45f * sin(t * 5f))
            p.shader = LinearGradient(0f, cy, w, cy,
                intArrayOf(Color.argb(0, 217, 119, 87), Color.argb((230 * fa).toInt(), 245, 190, 165), Color.argb(0, 217, 119, 87)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(0f, cy - 1.5f * d, w, cy + 1.5f * d, p)
            p.shader = null

            // spark burst in all the colours
            if (lt < 1.6f) {
                for (i in spAng.indices) {
                    val dist = spSpd[i] * d * lt * (1f - lt * 0.25f)
                    val a = 1f - lt / 1.6f
                    p.color = when (i % 4) {
                        0 -> argb(a, Color.WHITE)
                        1 -> argb(a, CLAUDE)
                        2 -> argb(a, syms[i % NSYM].vein)
                        else -> argb(a, Color.rgb(240, 170, 140))
                    }
                    c.drawCircle(cx + cos(spAng[i]) * dist, cy + sin(spAng[i]) * dist, spSz[i] * d * a, p)
                }
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val base = Color.parseColor("#07061A")
        window.setBackgroundDrawable(ColorDrawable(base))
        try { window.statusBarColor = Color.TRANSPARENT; window.navigationBarColor = base } catch (e: Exception) {}

        val root = FrameLayout(this)
        val scene = Scene(this)
        root.addView(scene, FrameLayout.LayoutParams(-1, -1))

        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; alpha = 0f; translationY = dp(20).toFloat() }
        texts.addView(TextView(this).apply {
            text = "ANJOO AI"; textSize = 34f; setTextColor(Color.WHITE); letterSpacing = 0.22f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            setShadowLayer(dp(16).toFloat(), 0f, 0f, Color.parseColor("#88D97757"))
        })
        texts.addView(TextView(this).apply {
            text = "Talk. Chat. Create. Code."; textSize = 14f; setTextColor(Color.parseColor("#F0B49A")); letterSpacing = 0.1f
            setPadding(0, dp(8), 0, 0)
        })
        val top = (resources.displayMetrics.heightPixels * 0.40f + dp(112)).toInt()
        root.addView(texts, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL or Gravity.TOP).apply { topMargin = top })

        setContentView(root)
        texts.animate().alpha(1f).translationY(0f).setDuration(800).setStartDelay(((IMPACT + 0.6f) * 1000).toLong()).start()

        val started = System.nanoTime()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 60000
            interpolator = LinearInterpolator()
            addUpdateListener { scene.t = (System.nanoTime() - started) / 1e9f; scene.invalidate() }
            start()
        }
        ui.postDelayed({ openApp() }, ((IMPACT + 3.2f) * 1000).toLong())
        root.setOnClickListener { openApp() }
    }

    private fun openApp() {
        if (opened) return
        opened = true
        val i = Intent(this, MainActivity::class.java)
        intent?.extras?.let { i.putExtras(it) }
        startActivity(i)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        finish()
    }

    override fun onDestroy() {
        anim?.cancel()
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
