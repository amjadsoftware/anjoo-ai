package com.anjoo.assistant

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * The coding brain. It plans the architecture first, writes a complete multi-file project, reviews it for
 * bugs, edits it later on request, and answers code questions with the whole project as context.
 * Projects are real folders of real files, so they can be opened, edited, previewed and exported as a zip.
 */
object Coder {

    const val SYSTEM = "You are Anjoo Code, a principal software engineer with deep expertise in every mainstream language and framework " +
        "(Kotlin/Android, Java, Python, JavaScript/TypeScript, HTML/CSS, Node, Flutter/Dart, C/C++, C#, Go, Rust, PHP, SQL, shell). " +
        "You write code the way a careful senior engineer ships it.\n" +
        "RULES:\n" +
        "1. COMPLETE and RUNNABLE: every file is fully written. Never use placeholders, TODO, '...', 'rest of code here' or pseudo-code.\n" +
        "2. ARCHITECTURE: sensible file structure, separation of concerns, small focused functions, clear names. Follow the given plan.\n" +
        "3. CORRECTNESS: before answering, mentally compile and run the code. Check imports, names that must match across files, " +
        "element ids between HTML and JS, async/await, null safety, types, off-by-one errors, resource cleanup.\n" +
        "4. ROBUST: validate input, handle errors and empty states, never crash on bad data. No hardcoded secrets.\n" +
        "5. SECURE: escape untrusted output, use parameterized queries, least privilege.\n" +
        "6. MODERN: use current stable APIs and idioms. Include the dependency/build file the project needs " +
        "(package.json, requirements.txt, build.gradle, pubspec.yaml ...) and a short README.md with how to run it.\n" +
        "7. WEB UI: semantic HTML, responsive mobile-first CSS, accessible, good spacing and typography, tasteful animation, " +
        "works offline without external libraries unless truly needed (cdnjs only).\n" +
        "8. ANDROID: Kotlin, minSdk 26, no deprecated calls, handle runtime permissions and lifecycle.\n" +
        "9. COMMENTS: short and meaningful, only where the reason is not obvious.\n" +
        "10. Choose the best language/stack yourself when it is not specified (websites and small tools: HTML/CSS/JS; scripts: Python).\n"

    const val FORMAT = "\nOUTPUT FORMAT (strict, never wrap the whole answer in code fences):\n" +
        "=== NOTES ===\n" +
        "2-5 short lines: what you built or changed, how to run it, anything the user must know. Same language style as the user (Roman Urdu or English).\n" +
        "=== FILE: relative/path/name.ext ===\n" +
        "the full raw content of that file (no code fences)\n" +
        "=== FILE: next/file.ext ===\n" +
        "...\n" +
        "Use forward slashes in paths. Put nothing between files except the markers.\n"

    private const val PLAN_SYS = "You are a principal software architect doing a DEEP ANALYSIS before any code is written. Reply with at most 45 lines and NO code. " +
        "Line 1 must be: NAME: a short project name (2-4 words). Then these sections: " +
        "REQUIREMENTS (explicit and implicit, as short bullets); STACK (language, libraries and why); " +
        "FILES (path - purpose, one per line); DATA MODEL (main structures and state); " +
        "KEY ALGORITHMS (with time complexity where relevant); EDGE CASES AND FAILURE MODES (empty input, huge input, network failure, bad data, permissions...); " +
        "SECURITY AND PERFORMANCE NOTES; TEST SCENARIOS (at least 6 concrete input -> expected output examples). " +
        "Be precise and practical. Prefer the simplest design that fully meets the requirements."

    private const val REVIEW_SYS = "You are a meticulous code reviewer, debugger and tester. Mentally compile and run the whole project, then walk through every TEST SCENARIO from the design plan and check the result. " +
        "Look for: syntax errors, wrong or missing imports, names that do not match between files, undefined variables, " +
        "async/await mistakes, null errors, off-by-one errors, broken element ids between HTML and JS, missing dependencies, " +
        "unhandled edge cases, logic bugs, memory/performance traps and security holes. Fix every REAL problem (do not rewrite for style). " +
        "Output ONLY the files you changed, each one complete, in the format below. If everything is already correct output exactly NO_CHANGES."

    private const val REVISE_RULES = "\nYou are modifying an existing project. Make the smallest correct change that fully satisfies the request " +
        "and keep everything else working. Output every file you change or add in FULL (never diffs or snippets). " +
        "To remove a file output a line like: === DELETE: path/name.ext ===\n"

    private const val ASK_SYS = "You are Anjoo Code, an expert pair-programmer. Explain, debug, review and compare approaches precisely. " +
        "Show code in fenced blocks with the language name, and give corrected complete snippets rather than vague advice. " +
        "Use the user's language style (Roman Urdu or English). Be concise but complete."

    class Out(val notes: String, val files: List<Pair<String, String>>, val deletes: List<String>)

    // ---------- storage ----------

    private fun root(ctx: Context) = File(ctx.filesDir, "projects").also { it.mkdirs() }
    private const val META = ".anjoo-meta.json"

    fun list(ctx: Context): List<File> =
        (root(ctx).listFiles()?.filter { it.isDirectory }?.toList() ?: emptyList()).sortedByDescending { it.lastModified() }

    fun latest(ctx: Context): File? = list(ctx).firstOrNull()

    private fun meta(dir: File): JSONObject =
        try { JSONObject(File(dir, META).readText(Charsets.UTF_8)) } catch (e: Exception) { JSONObject() }

    private fun saveMeta(dir: File, m: JSONObject) {
        try { File(dir, META).writeText(m.toString(), Charsets.UTF_8) } catch (e: Exception) {}
        dir.setLastModified(System.currentTimeMillis())
    }

    fun name(dir: File): String = meta(dir).optString("name", dir.name)

    fun history(dir: File): List<Pair<String, String>> {
        val h = meta(dir).optJSONArray("history") ?: return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until h.length()) {
            val o = h.optJSONObject(i) ?: continue
            out.add(Pair(o.optString("r"), o.optString("t")))
        }
        return out
    }

    private fun addHistory(dir: File, role: String, text: String) {
        val m = meta(dir)
        val h = m.optJSONArray("history") ?: JSONArray()
        h.put(JSONObject().put("r", role).put("t", text.take(6000)))
        // keep the file small
        val keep = JSONArray()
        val from = maxOf(0, h.length() - 60)
        for (i in from until h.length()) keep.put(h.get(i))
        m.put("history", keep)
        saveMeta(dir, m)
    }

    fun readFiles(dir: File): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        val all = dir.walkTopDown().filter { it.isFile && !it.name.startsWith(".anjoo") }.toList().sortedBy { it.path }
        for (f in all) {
            val rel = f.relativeTo(dir).path.replace('\\', '/')
            out[rel] = try { f.readText(Charsets.UTF_8) } catch (e: Exception) { "" }
        }
        return out
    }

    fun writeFile(dir: File, rel: String, content: String): Boolean {
        val p = safe(rel) ?: return false
        val f = File(dir, p)
        return try {
            f.parentFile?.mkdirs()
            f.writeText(content, Charsets.UTF_8)
            dir.setLastModified(System.currentTimeMillis())
            true
        } catch (e: Exception) { false }
    }

    private fun safe(p: String): String? {
        val parts = p.replace('\\', '/').split('/').map { it.trim() }.filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty() || parts.any { it == ".." } || parts.size > 7) return null
        if (parts.last().startsWith(".anjoo")) return null
        return parts.joinToString("/")
    }

    fun delete(dir: File) { try { dir.deleteRecursively() } catch (e: Exception) {} }

    fun rename(dir: File, name: String) {
        val m = meta(dir)
        m.put("name", name.trim().take(60).ifEmpty { dir.name })
        saveMeta(dir, m)
    }

    private fun undoFile(ctx: Context, dir: File) = File(File(ctx.filesDir, "undo").also { it.mkdirs() }, dir.name + ".json")

    /** Saves the project's files so the next edit can be undone. */
    fun snapshot(ctx: Context, dir: File) {
        try {
            val o = JSONObject()
            for ((k, v) in readFiles(dir)) o.put(k, v)
            undoFile(ctx, dir).writeText(o.toString(), Charsets.UTF_8)
        } catch (e: Exception) {}
    }

    fun canUndo(ctx: Context, dir: File) = undoFile(ctx, dir).exists()

    /** A short list of what the last edit changed, like a mini diff. */
    fun changes(ctx: Context, dir: File): String {
        val f = undoFile(ctx, dir)
        if (!f.exists()) return ""
        return try {
            val old = JSONObject(f.readText(Charsets.UTF_8))
            val now = readFiles(dir)
            val sb = StringBuilder()
            for ((p, c) in now) {
                if (!old.has(p)) { sb.append("➕ ").append(p).append("  (new, ").append(c.split("\n").size).append(" lines)\n"); continue }
                val o = old.getString(p)
                if (o == c) continue
                val cnt = HashMap<String, Int>()
                for (l in o.split("\n")) cnt[l] = (cnt[l] ?: 0) + 1
                var add = 0
                for (l in c.split("\n")) { val n = cnt[l] ?: 0; if (n > 0) cnt[l] = n - 1 else add++ }
                val del = cnt.values.sum()
                sb.append("✏️ ").append(p).append("  +").append(add).append("  -").append(del).append("\n")
            }
            for (k in old.keys()) if (!now.containsKey(k)) sb.append("🗑 ").append(k).append("  (deleted)\n")
            if (sb.isEmpty()) "" else "Changed files:\n" + sb.toString().trim()
        } catch (e: Exception) { "" }
    }

    /** Puts the project back to how it was before the last edit. */
    fun undo(ctx: Context, dir: File): Boolean {
        val f = undoFile(ctx, dir)
        if (!f.exists()) return false
        return try {
            val o = JSONObject(f.readText(Charsets.UTF_8))
            for (k in readFiles(dir).keys) File(dir, k).delete()
            for (k in o.keys()) writeFile(dir, k, o.getString(k))
            f.delete()
            true
        } catch (e: Exception) { false }
    }

    private fun newDir(ctx: Context, name: String): File {
        val slug = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(24).ifEmpty { "project" }
        val d = File(root(ctx), slug + "-" + (System.currentTimeMillis() / 1000))
        d.mkdirs()
        return d
    }

    fun zip(dir: File): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            for ((rel, c) in readFiles(dir)) {
                z.putNextEntry(ZipEntry(rel))
                z.write(c.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
        return bo.toByteArray()
    }

    fun projectDir(ctx: Context, name: String): File = File(root(ctx), name)

    private fun keepRoot(ctx: Context) = File(ctx.filesDir, "chatkeep").also { it.mkdirs() }

    /** A second copy of a chat's project, so the files in the chat survive even if the project is deleted in Code Studio. */
    fun keepCopy(ctx: Context, dir: File) {
        try { dir.copyRecursively(File(keepRoot(ctx), dir.name), overwrite = true) } catch (e: Exception) {}
    }

    /** The project folder for a chat card; brings it back from the kept copy when it was deleted. */
    fun ensureProject(ctx: Context, name: String): File? {
        val d = projectDir(ctx, name)
        if (d.exists()) return d
        val k = File(keepRoot(ctx), name)
        if (!k.exists()) return null
        return try { k.copyRecursively(d, overwrite = true); d } catch (e: Exception) { null }
    }

    private val SKIP_LANGS = setOf("", "text", "txt", "output", "console", "bash", "sh", "shell", "zsh", "diff", "log", "markdown", "md")

    private fun snippetName(l: String): String = when (l) {
        "html", "htm" -> "index.html"
        "svg" -> "image.svg"
        "css" -> "style.css"
        "js", "javascript" -> "script.js"
        "ts", "typescript" -> "index.ts"
        "py", "python" -> "main.py"
        "kotlin", "kt" -> "Main.kt"
        "java" -> "Main.java"
        "c" -> "main.c"
        "cpp", "c++" -> "main.cpp"
        "go" -> "main.go"
        "rust", "rs" -> "main.rs"
        "php" -> "index.php"
        "json" -> "data.json"
        "sql" -> "query.sql"
        "dart" -> "main.dart"
        else -> ""
    }

    /**
     * Turns the code blocks of a chat reply into project files inside Code Studio.
     * A file name is taken from the line just before a block (FILE: x), from a first-line comment, or from the language.
     * Returns the folder and its file count, or null when there is nothing worth keeping.
     * When [existing] already holds a file with the same name, that project is updated instead of a new one.
     */
    fun saveFromChat(ctx: Context, reply: String, title: String, existing: File?): Pair<File, Int>? {
        val fence = Regex("```([A-Za-z0-9+#._-]*)[ \\t]*\\r?\\n([\\s\\S]*?)```")
        val tokRe = Regex("([A-Za-z0-9_][A-Za-z0-9_./-]*\\.[A-Za-z0-9]{1,6})")
        val commentRe = Regex("^(?://|#|--|<!--|/\\*)\\s*(?:file(?:name)?\\s*[:=]\\s*)?([A-Za-z0-9_][A-Za-z0-9_./-]*\\.[A-Za-z0-9]{1,6})\\s*(?:-->|\\*/)?\\s*$", RegexOption.IGNORE_CASE)
        val names = ArrayList<String>()
        val codes = ArrayList<String>()
        var labelled = false
        var lineCount = 0
        var firstLang = ""
        for (m in fence.findAll(reply)) {
            val lang = m.groupValues[1].lowercase()
            val code = m.groupValues[2].trimEnd()
            if (code.isBlank()) continue
            val before = reply.substring(maxOf(0, m.range.first - 160), m.range.first).trimEnd().lines().lastOrNull() ?: ""
            var name: String? = null
            var isLabel = false
            val tok = tokRe.find(before)?.groupValues?.get(1)
            if (tok != null && before.length < 90 &&
                (before.contains("file", true) || before.trim().trim('*', '_', '`', ':', ' ', '#', '>', '-') == tok)) { name = tok; isLabel = true }
            if (name == null) {
                val c = commentRe.find(code.lines().first().trim())?.groupValues?.get(1)
                if (c != null) { name = c; isLabel = true }
            }
            if (name == null) {
                if (lang in SKIP_LANGS) continue
                name = snippetName(lang)
                if (name.isEmpty()) continue
            }
            name = name.trimStart('/', '.')
            if (name.isEmpty()) continue
            val at = names.indexOf(name)
            if (at >= 0) {
                if (isLabel) { codes[at] = code; continue }
                var n = 2
                val dot = name.lastIndexOf('.')
                val stem = if (dot > 0) name.substring(0, dot) else name
                val ext = if (dot > 0) name.substring(dot) else ""
                while (names.contains(stem + n + ext)) n++
                name = stem + n + ext
            }
            if (isLabel) labelled = true
            if (firstLang.isEmpty()) firstLang = lang
            names.add(name); codes.add(code)
            lineCount += code.count { it == '\n' } + 1
        }
        if (names.isEmpty() || (!labelled && lineCount < 12)) return null
        val reuse = existing != null && existing.exists() && names.any { readFiles(existing).containsKey(it) }
        val dir: File
        if (reuse) {
            dir = existing!!
            snapshot(ctx, dir)
        } else {
            val nm = title.replace(Regex("\\s+"), " ").trim().take(40).ifBlank { "Chat project" }
            dir = newDir(ctx, nm)
            saveMeta(dir, JSONObject().put("name", nm).put("language", firstLang.ifEmpty { "auto" }).put("created", System.currentTimeMillis()))
            addHistory(dir, "u", title.take(300))
            addHistory(dir, "a", "Saved from the Anjoo chat.")
        }
        for (i in names.indices) writeFile(dir, names[i], codes[i] + "\n")
        keepCopy(ctx, dir)
        return Pair(dir, readFiles(dir).size)
    }

    /** Saves one code block from the chat as its own small project, so it can be edited and exported. */
    fun snippetProject(ctx: Context, lang: String, code: String): File {
        val l = lang.lowercase()
        val file = when (l) {
            "html", "htm" -> "index.html"
            "svg" -> "image.svg"
            "css" -> "style.css"
            "js", "javascript" -> "script.js"
            "ts", "typescript" -> "index.ts"
            "py", "python" -> "main.py"
            "kotlin", "kt" -> "Main.kt"
            "java" -> "Main.java"
            "c" -> "main.c"
            "cpp", "c++" -> "main.cpp"
            "go" -> "main.go"
            "rust", "rs" -> "main.rs"
            "php" -> "index.php"
            "sh", "bash", "shell" -> "script.sh"
            "json" -> "data.json"
            "sql" -> "query.sql"
            "dart" -> "main.dart"
            else -> "snippet.txt"
        }
        val dir = newDir(ctx, "snippet " + l)
        writeFile(dir, file, code + "\n")
        saveMeta(dir, JSONObject().put("name", "Snippet (" + l.ifEmpty { "code" } + ")").put("language", l).put("created", System.currentTimeMillis()))
        return dir
    }

    fun open(ctx: Context, dir: File?) {
        val i = Intent(ctx, CodeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (dir != null) i.putExtra("project", dir.absolutePath)
        ctx.startActivity(i)
    }

    // ---------- parsing ----------

    private fun cleanFile(b: String): String {
        var t = b.trim('\n', '\r')
        var fenced = false
        if (t.trimStart().startsWith("```")) { t = t.trimStart().substringAfter("\n", ""); fenced = true }
        if (fenced) {
            val e = t.trimEnd()
            if (e.endsWith("```")) t = e.removeSuffix("```")
        }
        return t.trimEnd() + "\n"
    }

    fun parse(raw: String): Out {
        val re = Regex("(?m)^=== (FILE|DELETE): (.+?) ===[ \\t]*$")
        val ms = re.findAll(raw).toList()
        var notes = raw
        val files = ArrayList<Pair<String, String>>()
        val dels = ArrayList<String>()
        if (ms.isNotEmpty()) {
            notes = raw.substring(0, ms[0].range.first)
            for (i in ms.indices) {
                val m = ms[i]
                val end = if (i + 1 < ms.size) ms[i + 1].range.first else raw.length
                val body = raw.substring(m.range.last + 1, end)
                val path = m.groupValues[2].trim()
                if (m.groupValues[1] == "DELETE") dels.add(path) else files.add(Pair(path, cleanFile(body)))
            }
        }
        notes = notes.replace(Regex("(?m)^=== NOTES ===[ \\t]*$"), "").trim()
        return Out(notes, files, dels)
    }

    private fun apply(dir: File, o: Out): Int {
        var n = 0
        for ((p, c) in o.files) if (writeFile(dir, p, c)) n++
        for (p in o.deletes) {
            val s = safe(p) ?: continue
            try { File(dir, s).delete() } catch (e: Exception) {}
        }
        return n
    }

    private fun dump(files: Map<String, String>, cap: Int = 110000): String {
        val sb = StringBuilder()
        for ((p, c) in files) {
            if (sb.length + c.length > cap) { sb.append("=== FILE: ").append(p).append(" === (skipped, too large)\n"); continue }
            sb.append("=== FILE: ").append(p).append(" ===\n").append(c).append("\n")
        }
        return sb.toString()
    }

    // ---------- model calls ----------

    /** Live view of the current model call: (thought summary so far, answer so far). Set by the screen showing progress. */
    @Volatile var live: ((String, String) -> Unit)? = null

    fun deepDefault(ctx: Context): Boolean = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean("codeThink", true)

    private fun gen(
        ctx: Context, system: String, user: String, max: Int,
        deep: Boolean = false, thought: (String) -> Unit = {}
    ): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val key = p.getString("key", "") ?: ""
        if (key.isEmpty()) throw IllegalStateException("Pehle Gemini key dalein.")
        val model = (p.getString("codeModel", "") ?: "").ifBlank { p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash" }
        val limit = if (deep) minOf(60000, max + 16000) else max
        val r = Gemini.plainFull(key, model, system, JSONArray().put(JSONObject().put("text", user)), limit, 0.3, deep, live)
        if (r.thoughts.isNotBlank()) thought(r.thoughts)
        return r.text
    }

    private fun defaultName(language: String): String = when (language.lowercase()) {
        "python", "py" -> "main.py"
        "kotlin" -> "Main.kt"
        "java" -> "Main.java"
        "javascript", "js", "node" -> "index.js"
        "typescript", "ts" -> "index.ts"
        "c++", "cpp" -> "main.cpp"
        "c" -> "main.c"
        "go" -> "main.go"
        "rust" -> "main.rs"
        "php" -> "index.php"
        else -> "index.html"
    }

    /** Analyses, plans, writes and reviews (two rounds) a brand-new project. Returns the folder and a short note. */
    fun build(
        ctx: Context, task: String, language: String, review: Boolean,
        deep: Boolean = false, thought: (String) -> Unit = {}, note: (String) -> Unit
    ): Pair<File, String> {
        val lang = language.ifBlank { "auto" }
        note(if (deep) "Deep analysis of the request..." else "Planning the architecture...")
        val plan = gen(ctx, PLAN_SYS, "Language/stack: " + lang + "\nTask: " + task, 6000, deep, thought)
        val name = Regex("(?m)^NAME:\\s*(.+)$").find(plan)?.groupValues?.get(1)?.trim()?.take(40)?.ifBlank { null } ?: task.take(30)
        thought("📐 Design plan\n" + plan)
        note("Writing the code...")
        val raw = gen(ctx, SYSTEM + FORMAT, "Language/stack: " + lang + "\nTask: " + task + "\n\nDESIGN PLAN (follow it and satisfy its test scenarios):\n" + plan, 32000, deep, thought)
        val out = parse(raw)
        var files = out.files
        if (files.isEmpty()) {
            val body = cleanFile(raw)
            if (body.isBlank()) throw IllegalStateException("Code nahi bana, dobara koshish karein.")
            files = listOf(Pair(defaultName(lang), body))
        }
        val dir = newDir(ctx, name)
        for ((p, c) in files) writeFile(dir, p, c)
        saveMeta(dir, JSONObject().put("name", name).put("language", lang).put("created", System.currentTimeMillis()))
        addHistory(dir, "u", task)
        var notes = out.notes.ifBlank { "Project tayyar hai: " + files.size + " file(s)." }
        if (review) {
            var fixed = 0
            try {
                note("Reviewing and testing (round 1)...")
                val n1 = reviewPass(ctx, dir, plan, deep, thought)
                fixed += n1
                if (n1 > 0) {
                    note("Verifying the fixes (round 2)...")
                    fixed += reviewPass(ctx, dir, plan, deep, thought)
                }
            } catch (e: Exception) {}
            if (fixed > 0) notes += "\n(Review: " + fixed + " file fix(es) applied.)"
        }
        addHistory(dir, "a", notes)
        return Pair(dir, notes)
    }

    private fun reviewPass(ctx: Context, dir: File, plan: String, deep: Boolean, thought: (String) -> Unit): Int {
        val files = readFiles(dir)
        val found = lint(files).ifBlank { "nothing found" }
        val raw = gen(
            ctx, REVIEW_SYS + FORMAT,
            "DESIGN PLAN AND TEST SCENARIOS:\n" + plan + "\n\nAUTOMATIC CHECK RESULTS (a tool found these; confirm each and fix real ones, ignore false alarms):\n" +
                found + "\n\nREVIEW THIS PROJECT:\n" + dump(files), 32000, deep, thought
        )
        val o = parse(raw)
        if (o.files.isEmpty()) return 0
        return apply(dir, o)
    }

    /** Cheap automatic checks (missing files, broken JSON, unclosed tags or braces) handed to the reviewer as facts. */
    private fun lint(files: Map<String, String>): String {
        val out = StringBuilder()
        for ((p, c) in files) {
            val low = p.lowercase()
            if (low.endsWith(".html")) {
                val base = p.substringBeforeLast('/', "")
                for (m in Regex("(?:src|href)\\s*=\\s*[\"']([^\"'#?]+)[\"']").findAll(c)) {
                    val ref = m.groupValues[1]
                    if (ref.startsWith("http") || ref.startsWith("//") || ref.startsWith("data:") ||
                        ref.startsWith("mailto:") || ref.startsWith("tel:") || ref.startsWith("javascript:")) continue
                    val path = if (base.isEmpty() || ref.startsWith("/")) ref.trimStart('/') else base + "/" + ref
                    if (!files.containsKey(path)) out.append("- ").append(p).append(" refers to a file that does not exist: ").append(ref).append("\n")
                }
                val opens = Regex("<script", RegexOption.IGNORE_CASE).findAll(c).count()
                val closes = Regex("</script>", RegexOption.IGNORE_CASE).findAll(c).count()
                if (opens > closes) out.append("- ").append(p).append(": a <script> tag is not closed\n")
            }
            if (low.endsWith(".json")) {
                try { JSONObject(c) } catch (e: Exception) {
                    try { JSONArray(c) } catch (e2: Exception) { out.append("- ").append(p).append(" is not valid JSON\n") }
                }
            }
            if (low.endsWith(".js") || low.endsWith(".css")) {
                val o = c.count { it == '{' }
                val cl = c.count { it == '}' }
                if (o != cl) out.append("- ").append(p).append(": curly braces do not match (").append(o).append(" open, ").append(cl).append(" close)\n")
            }
        }
        return out.toString()
    }

    /** Changes an existing project according to the instruction. Returns a short note. */
    fun revise(
        ctx: Context, dir: File, instruction: String,
        deep: Boolean = false, thought: (String) -> Unit = {}, note: (String) -> Unit
    ): String {
        note("Reading the project...")
        val hist = history(dir).takeLast(6).joinToString("\n") { (if (it.first == "u") "USER: " else "ASSISTANT: ") + it.second.take(500) }
        note(if (deep) "Thinking through the change..." else "Updating the code...")
        val raw = gen(
            ctx, SYSTEM + REVISE_RULES + FORMAT,
            "CURRENT PROJECT:\n" + dump(readFiles(dir)) + "\nRECENT CHAT:\n" + hist + "\n\nUSER REQUEST: " + instruction, 32000, deep, thought
        )
        val o = parse(raw)
        addHistory(dir, "u", instruction)
        if (o.files.isEmpty() && o.deletes.isEmpty()) {
            val msg = o.notes.ifBlank { "Koi badlav nahi hua. Request thori aur saaf likhein." }
            addHistory(dir, "a", msg)
            return msg
        }
        apply(dir, o)
        var msg = o.notes.ifBlank { "Update ho gaya: " + o.files.size + " file(s)." }
        if (deep) {
            try {
                note("Re-checking the change...")
                val n = reviewPass(ctx, dir, "Check that the user's request is fully satisfied: " + instruction, deep, thought)
                if (n > 0) msg += "\n(Review: " + n + " file fix(es) applied.)"
            } catch (e: Exception) {}
        }
        addHistory(dir, "a", msg)
        return msg
    }

    /** Answers a coding question; the project (if any) is given as context. */
    fun ask(ctx: Context, dir: File?, question: String, deep: Boolean = false, thought: (String) -> Unit = {}): String {
        val sb = StringBuilder()
        if (dir != null) {
            sb.append("PROJECT FILES:\n").append(dump(readFiles(dir), 90000)).append("\n")
            val hist = history(dir).takeLast(6).joinToString("\n") { (if (it.first == "u") "USER: " else "ASSISTANT: ") + it.second.take(500) }
            if (hist.isNotBlank()) sb.append("RECENT CHAT:\n").append(hist).append("\n\n")
        }
        sb.append("QUESTION: ").append(question)
        val ans = gen(ctx, ASK_SYS, sb.toString(), 8000, deep, thought)
        if (dir != null) { addHistory(dir, "u", question); addHistory(dir, "a", ans) }
        return ans.ifBlank { "Jawab nahi mila, dobara poochein." }
    }

    // ---------- entry points for the voice assistant ----------

    fun buildAndOpen(ctx: Context, task: String, language: String, review: Boolean): String {
        return try {
            val (dir, notes) = build(ctx, task, language, review, deepDefault(ctx)) {}
            open(ctx, dir)
            "Project '" + name(dir) + "' ban gaya (" + readFiles(dir).size + " files) aur Code Studio mein khol diya. " + notes.take(300)
        } catch (e: Exception) {
            "Code nahi ban saka: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    fun editLatest(ctx: Context, instruction: String): String {
        val dir = latest(ctx) ?: return "Abhi koi project nahi hai. Pehle write_code se banayein."
        return try {
            val msg = revise(ctx, dir, instruction, deepDefault(ctx)) {}
            open(ctx, dir)
            "Project '" + name(dir) + "' update ho gaya. " + msg.take(300)
        } catch (e: Exception) {
            "Badlav nahi ho saka: " + (e.message ?: e.javaClass.simpleName)
        }
    }
}
