# Anjoo AI: engineering notes (v99.1.32)

## v99.1.32: Code Studio toolbox (10 new coding tools, `CodeTools.kt`)
| Tool | What it does |
|---|---|
| `project_tree` | Map of a project: every file, lines, size. |
| `project_read` | A file with line numbers, `offset`/`limit` for big files; suggests near names when the path is wrong. |
| `project_write` | New file or full rewrite; quick check of that file afterwards. |
| `project_edit` | Exact old->new edit (must be unique, or `replace_all`), forgives trailing-space differences, `edits=[...]` applies several atomically (all or nothing), shows the +/- lines. |
| `project_search` | `grep` (regex, glob, context, files_only), `glob`, `symbols` (functions/classes/ids outline), `todos`. |
| `project_replace` | Regex or literal find/replace across the project, `dry_run`, group references. |
| `project_manage` | list_projects, stats, deps, format, new_file, move_file, delete_file (asks), rename/delete project (asks). |
| `project_check` | `lint` (Coder.lint), `run` (web page in a hidden browser / Python in Pyodide), `test` (Python unittest PASS/FAIL). |
| `project_history` | diff, undo, named checkpoints (checkpoint/log/compare/restore, newest 30 kept). |
| `project_template` | web, python (+unittest), node, pwa, readme, gitignore, dockerfile, github_actions. |
Prompt: `Style.PROJECT_TOOLS` (tree -> search -> read -> exact edit -> check -> checkpoint) is added to the voice agent and the chat prompt. Tools are registered in `MoreTools.run`, declared in `Gemini.DECLARATIONS` (119 tools now), labelled in the chat, and their results are redacted by `Guard`. `Coder.lint` and `Coder.lineDiff` became `internal`. `CodeTools.kt` was compiled and run with stubs here; the rest needs your Gradle build. No Android SDK here: if Gradle fails, send the error.

## v99.1.31: live voice circle
| Area | Change |
|---|---|
| Circle | `LiveOrb.kt`: a soft, see-through circle in Claude's warm colours (terracotta, peach, cream) that flows like water or a cloud and swells and ripples with the real sound level of your mic and of Anjoo's voice (`OrbLevel`, fed by `GeminiLiveSession`). 230dp, 62% opaque, centre of the screen, never touchable, so the screen behind stays visible. |
| Where | Shown by `VoiceService` as an overlay while live voice runs, so it appears whether the app is open or you went back to another app. If "draw over other apps" is not allowed, the same circle shows inside the app instead. |
| Not run | No Android SDK here; if Gradle fails, send the error. |

## v99.1.29: Claude-style chat details
| Area | Change |
|---|---|
| Process row | Above an answer: clock icon, one summary line ("Thought for 12s, wrote 3 files"), arrow. Tap opens the step-by-step summary sheet. |
| File card | Line icon (ZIP = file with zipper), file name, details under it (type, size, lines/files), blue-free clean card. Tap = download; small eye/copy/download icons for single files. |
| Links | Blue (`Md.linkColor`: #1A73E8 on light, #6CA8FF on dark), no underline; plain https:// links are tapped too; source chips are blue. |
| Answer actions | Line icons: copy, speaker, like, dislike, retry, and "more" (select, share, star, copy code). Version switch ‹ 1/2 › kept. |
| Send | Round button like Claude: sound waves when idle (tap = dictate, hold = live as before), orange waves while live voice runs, orange circle with white up-arrow when there is text, orange circle with stop square while working. Only the look changed. |
| Files | `LineIcon.kt` has new icons (clock, zip, copy, speaker, thumbs, retry, arrows, download, more, eye). |
| Not run | No Android SDK here; if Gradle fails, send the error. |

## v99.1.18: full models and keys report
| Area | Change |
|---|---|
| Report | `Router.report()` is now a full report: overview, live performance (ok/fail/speed counters kept on the phone), companies and models, key health, who can do what, who answers each job (with backup), and Anjoo's own experience with tips. Every number is a real counter; scores are labelled as estimates. |
| Trigger | "models ki report", "keys ki report", "performance", "tajurba" (with models/keys/anjoo) open it in chat. Messages naming pdf/docx/file do not. |
| Version | versionCode 99118 / versionName 99.1.18 (v17 zip still said 99.1.7). Includes everything from v99.1.17. |
| Not run | No Android SDK here; if Gradle fails, send the error. |


## v99.1.5: permanent "Anjoo AI" folder (survives uninstall)
| Area | Change |
|---|---|
| Folder | `Vault.kt` keeps `/storage/emulated/0/Anjoo AI` with Chats (Auto-saved, Readable, Attachments, Exports), Documents (PDF, Word, Excel, Other), Projects, Images/Created, Notes, Artifacts, App Backups, Key Backups, Downloads, README.txt. Needs "All files access" (asked once, same Storage screen). It lives in shared storage, so Android keeps it when the app is removed; after a reinstall the same folder is reused, nothing new is made. |
| Sync | Chats (json + txt), notes, projects, images, attachments, artifacts are copied into the folder in the background (on pause and when the app opens, at most every 15 s). Sync only adds and updates, it never deletes. |
| Backups | Auto backup (every 3 days) and "Backup now" write the full ZIP into App Backups (newest 7 kept). Key Backups holds the API keys ENCRYPTED (AES-256-GCM, key from your passphrase with PBKDF2, 200k rounds). The passphrase is never stored; without it the file cannot be opened. |
| Restore | On a fresh install that finds the old folder, a dialog offers Restore: newest ZIP, then newer files from the folders, chats (newer copy wins), notes, and keys if the passphrase is given. Also under Settings, "Anjoo AI folder". |
| Files Anjoo makes | With the folder on, new documents go to `Documents/<type>` and exported chats to `Chats/Exports` (a default save folder you chose yourself still wins). |
| Note | On reinstall, Android turns "All files access" off again: allow it once and the restore offer appears. Without that switch the app works as before and the folder is not used. |
| Not run | No Android SDK here; if Gradle fails, send the error. |

## v99.1.4: chat export, starred answers, home screen widget
| Area | Change |
|---|---|
| Chat export | ⋮ menu or + menu, "Export chat": PDF, Word (.docx) or text. `ChatExport.kt` builds the file (`Power.exportBytes`), saves it with `FileAccess.write` (default folder) and opens the share sheet through `ArtifactProvider` (now knows pdf and docx types). |
| Starred answers | ☆/⭐ under every answer (`Stars.kt`, pref `stars`, newest first, max 200). List: ⋮ menu, + menu or the widget; tap one to copy, share or un-star. |
| Widget | `AnjooWidget` (res/layout/widget_anjoo.xml, res/xml/anjoo_widget_info.xml): New chat, Voice, Stars. Buttons open `MainActivity` with extra `widget_action`, handled by `handleWidget`. |
| Not run | No Android SDK here; if Gradle fails, send the error. |

## v99.1.3: response style, limit meter, retry versions
| Area | Change |
|---|---|
| Response style | Picker (Normal, Short, Detailed, Formal, Roman Urdu) in the + menu and the Select model sheet. Saved as pref `respStyle`, added to the chat and agent prompts through `Style.styleLine`. The line under the title shows the active style. |
| Limit meter | New sheet (+ menu, Select model, Connectors) listing every company and key as 🟢 ready, 🟠 limit (429) with minutes left, 🔴 refused (401/402/403). Button "Aaram khatam karo" (`Router.clearRests`) lets every key try again. `Router.limitRows`, `KeyStat.code`. |
| Retry versions | Retry keeps the older answers of the same question; `‹ 1/2 ›` under the newest answer switches between them (screen only: a reopened chat shows the newest). |
| Not run | No Android SDK here; if Gradle fails, send the error. |

## v99.1.2: scrolling and keyboard
| Area | Change |
|---|---|
| Down button | A round ↓ button appears at the bottom of the chat when you scroll far up; one tap jumps to the latest message. |
| Answer follows | After you send, the list follows the answer to the end (even a long answer that arrives at once) until you drag the list yourself. Before, a big answer left the screen on your question. |
| Keyboard | The keyboard closes as soon as you send. |
| Not run | No Android SDK here; if Gradle fails, send the error. |

## v99.1.1: Projects (Projects.kt: named chat groups with their own instructions; chat ⋮ menu or + menu) and a Connectors sheet (keys, Telegram, notifications, accessibility, storage).

## v98: Effort (Low/Medium/High) in a "Select model" sheet; tap the small line under the title or use + menu.

## v97: Claude-style chat controls
| Area | Change |
|---|---|
| Reply | Select text in an answer, tap **Reply**: the selection is quoted in the input box. |
| Feedback | 👍 / 👎 under every answer. |
| ⋮ button | Now the chat menu: Share, Rename, Pin, Delete, Settings. |
| Not run | No Android SDK here; if Gradle fails, send the error. |

## v94: GET guard, check_keys, richer picture prompts; v93: better pictures, v92: universal tools, "no tool" is never an answer
| Area | Change |
|---|---|
| New file | `Power.kt` with 10 tools: `http_request`, `ask_model`, `list_tools`, `current_time`, `device_info`, `search_calendar`, `make_document`, `read_document`, `look_at_file`. Dispatched from `Actions.dispatch` after `MoreTools`. |
| http_request | Any web API (GET/POST/PUT/PATCH/DELETE) or file download (`save_as`). `use_key=<company id>` adds the saved key for that company, and only if the URL host is that company's own API host. Private/local hosts refused, redirects re-checked, non-GET asks the user first. |
| ask_model | Asks any company/model that has a saved key (`company="list"` shows them). Tries every saved key of the company. |
| Documents | `make_document` writes PDF (Android PdfDocument, Urdu/RTL works), DOCX and XLSX (hand-built OOXML, no library), CSV, text, HTML. `read_document` reads PDF (rendered, then read by a vision model), DOCX, XLSX, PPTX, ZIP. `look_at_file` reads a picture or PDF page. |
| Prompts | New `Style.RESOURCEFUL` block in the voice agent and the chat prompt; rule 3 and HONEST reworded: a missing tool is never a reason to refuse, only real blockers (permission off, bank/wallet) are stated. The "NOT AVAILABLE" tool reply now points to `list_tools` and the broad tools. |
| Privacy | No location tool and no location permission: the app cannot read the phone's position, so it can never be sent to any AI company. |
| Guard | Card/PIN/OTP redaction also covers the new tools' arguments and results. |
| Pictures | `ImageGen` now tries every company with a saved key, best first: OpenAI `gpt-image-1` (high quality), Gemini Pro image, xAI `grok-2-image`, Gemini Flash image, FLUX on Hugging Face, FLUX on Cloudflare; falls to the next on error/limit and uses a company's other keys first. New `engine` argument on `generate_image`. Editing a photo stays with Gemini. |
| Safety | `http_request` GET now also asks the user when the address carries a long query/path or a secret header (data-leak guard). |
| Keys | New `check_keys` tool tests every saved key and reports OK / refused / unknown (keys never shown). |
| Picture prompt | Short picture ideas are first rewritten into a detailed prompt (one extra quick call, falls back to the original). |
| More picture makers | Added OpenRouter (Gemini image), NVIDIA FLUX and Pollinations (free, no key, last resort; off with pref `freeImages`=false). `ImageGen.summary()` puts the live list of working makers into the prompt so the assistant stops claiming only OpenAI/Gemini work. |
| Not run | Written without being able to run Gradle here (no Android SDK). If the build fails, send the error. |


## v90: projects live in the chat (Code Studio only when needed)
| Area | Change |
|---|---|
| Project card | The chat card now has **Preview** (opens inside the chat, tap again to close), **Full screen**, **Download** (zip) and **Code Studio**. |
| Full screen | New `ProjectPreviewActivity` shows the whole project (all pages, css, js, images) with reload, page list, zip download and a Code Studio shortcut. `ProjectWeb` is the shared WebView that serves the files. |
| Voice / agent tools | `write_code` and `edit_code` no longer force Code Studio open: a website opens in the full-screen preview, other languages still open Code Studio. |
| Still true | Building and editing from the chat (`runProject`) already ran in the chat; Code Studio is still in the menu for big multi-file work. |

## v89: full-size projects (nothing cut short, nothing missing)
| Area | Change |
|---|---|
| Batched writing | A plan with 5+ files is written three files at a time (setup, styles, data, logic, inner pages, `index.html`, docs). Each call sees the files already written and reuses their ids, names and paths. |
| Cut-off repair | After each batch every file is checked (missing, empty, no `</html>`, unbalanced brackets); a broken file is written again, alone. |
| Completeness audit | After writing, an auditor compares the ORIGINAL request with the project, lists every expected feature, page and state, and builds what is missing before the bug review runs. |
| Bigger plans | The plan may list up to 40 files (was 25). |
| Tests | `CoderOrderTest` checks the build order. |

## v88: Anjoo's own coding (Code Studio and chat)
| Area | Change |
|---|---|
| Rules | `Coder.SYSTEM` now has rules 17-22: requirements traceability, per-language standards (Kotlin, Python, JS/TS, Java/C#, C/C++, Go, Rust, SQL, shell), error handling, accessibility and Urdu/RTL, performance, and delivery (README, .gitignore, .env.example, pinned versions). |
| Planning | The design plan also lists non-functional needs and test scenarios for normal, empty, huge and invalid input (55 lines instead of 45). |
| Review | The reviewer first checks that every plan requirement is implemented and removes stubs, dead buttons and fake data. |
| Local checks | `lint()` now also flags TODO/FIXME comments, "rest of the code" style placeholders, NotImplemented stubs, lorem ipsum, HTML cut off before `</html>`, and a missing README for projects with 3+ files. A finding triggers the model review. |
| Tests | `CoderPromptTest` fails if a coding rule or the output format is dropped from the prompt. |

## What changed in v87

## What changed in v87
| Area | Change |
|---|---|
| Security | `ReminderReceiver` is no longer exported. Before, any app on the phone could broadcast `kind=agent` with its own text and make Anjoo run a scheduled agent task. |
| Reliability | A malformed time in a daily agent task can no longer crash the receiver (`toInt()` replaced by validated `toIntOrNull()`). |
| Quality | Unit tests (`GuardTest`, `ProvidersTest`) cover the bank/card safety rules, the provider list and the Auto-fallback rules. |
| Release | Release builds use R8 shrinking (`app/proguard-rules.pro`). JavaScript bridges are kept by rule. |
| CI | One run does unit tests, lint (report only), debug APK and release APK, rejects empty APKs, cancels superseded runs and uploads reports. |

## How to run the checks
```
gradle testDebugUnitTest      # unit tests
gradle lintDebug              # report: app/build/reports/lint-results-debug.html
gradle assembleDebug          # debug APK
gradle assembleRelease        # R8 release APK (unsigned)
```

## Security model (short)
- Bank, wallet and card data: `Guard` refuses screen tools inside financial apps and redacts card numbers, CVV, PIN, OTP and passwords in tool results.
- Web pages, files, notifications and tool output are untrusted data, never instructions (see `PROMPT_AND_CODING_UPGRADE.md`).
- API keys live in private app storage; backups are off (`allowBackup=false`). Keys bundled through `keys.properties` can be extracted from the APK, so use that only for your own private build.
- Exported components are only the launcher/share activities, the home screen widget receiver (`AnjooWidget`, draws three buttons, takes no data) and the two system-bound services (Accessibility, Notification listener). Everything else is `exported=false`.

## Release checklist
1. `gradle testDebugUnitTest assembleDebug assembleRelease` is green.
2. Install the release APK on a real phone and check: microphone, Live voice for 15 minutes (reconnect), Accessibility control, reminders after a restart, a scheduled agent task, WebView features (Python runner, preview, artifacts).
3. Sign the release APK with your own keystore before sharing (`apksigner`). Keep the keystore out of Git.

## Known limits
- The release (R8) build and the new tests were written without being able to run Gradle in the authoring environment. If R8 removes something it should not, add a `-keep` rule to `proguard-rules.pro`; if a test fails, fix the test or the code and send the failure message.
- Many `catch (e: Exception) {}` blocks are deliberate best-effort cleanup. Failures that matter to the user go through `Errors`.

## Version numbering
Format `99.1.N`: each update raises N (99.1.1, 99.1.2, 99.1.3 ...). Per update change `versionName` and `versionCode` in `app/build.gradle.kts` (versionCode = 99100 + N, must always go up) and add a `## v99.1.N` section at the top of this file. Zip name: `AnjooAI-v99.1.N.zip`.
