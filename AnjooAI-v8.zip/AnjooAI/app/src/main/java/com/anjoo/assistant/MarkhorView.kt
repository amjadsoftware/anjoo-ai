package com.anjoo.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View
import java.util.Locale
import java.util.Random
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.cos

enum class Mood {
    IDLE, HAPPY, LOVE, SAD, SURPRISED, THINKING, LISTENING, SLEEP;

    companion object {
        private val sad = listOf("sorry", "afsos", "udaas", "maaf", "nahi ho saka", "nahi mila", "masla", "error",
            "fail", "ghalat", "dukh", "bimar", "takleef", "rona", "nahi hua", "نہیں ہو", "مسئلہ", "افسوس", "معاف")
        private val sleep = listOf("good night", "shab bakhair", "so jao", "neend", "allah hafiz", "khuda hafiz",
            "alvida", "الوداع", "خدا حافظ", "اللہ حافظ", "شب بخیر")
        private val love = listOf("love", "pyar", "pyaar", "shukriya", "shukria", "thank", "mehrbani", "jaan",
            "شکریہ", "پیار", "مہربانی", "❤")
        private val wow = listOf("wow", "kya baat", "really", "hairat", "amazing", "are wah", "حیرت", "واہ واہ")
        private val happy = listOf("haha", "hehe", "khush", "mubarak", "congrat", "zabardast", "wah", "great", "acha",
            "achha", "shabash", "ho gaya", "kar diya", "kar di", "khol di", "khol diya", "done", "salam", "hello",
            "assalam", "ہو گیا", "شاباش", "خوش", "مبارک", "سلام", "😊", "😂")

        /** Guesses a feeling from what was said. Returns null when nothing stands out. */
        fun fromText(text: String): Mood? {
            val t = text.lowercase(Locale.ROOT)
            fun has(l: List<String>) = l.any { t.contains(it) }
            return when {
                has(sad) -> SAD
                has(sleep) -> SLEEP
                has(love) -> LOVE
                has(wow) -> SURPRISED
                has(happy) -> HAPPY
                else -> null
            }
        }
    }
}

/** Messages from the background voice service to the screen (what was heard and answered). */
object Buddy {
    @Volatile var stamp = 0L
    @Volatile var kind = 0
    @Volatile var text = ""
    fun post(k: Int, t: String) { text = t; kind = k; stamp = System.nanoTime() }
}

/**
 * A small friendly markhor that wanders over the screen, reacts to what is said and walks to wherever
 * the user taps. Everything is drawn with code, no images.
 */
class MarkhorView(ctx: Context, private var accent: Int) : View(ctx), Runnable {

    private val rnd = Random()
    private val d = resources.displayMetrics.density
    private val u = 0.8f * d
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    private var px = -1f
    private var py = -1f
    private var tx = 0f
    private var ty = 0f
    private var dir = 1f
    private var moving = false
    private var t = 0f
    private var last = 0L
    private var waitUntil = 2f
    private var hop = 0f

    private var mood = Mood.IDLE
    private var moodUntil = 0L
    private var lastInteract = System.currentTimeMillis()
    private var talkUntil = 0L

    private var blink = 0f
    private var nextBlink = 2f
    private var spawnT = 0f

    private class P(var x: Float, var y: Float, var vx: Float, var vy: Float, var life: Float, val kind: Int)
    private val parts = ArrayList<P>()

    private var birdOn = false
    private var birdX = 0f
    private var birdY = 0f
    private var nextBird = 6f

    private var running = false

    // ---------- public ----------

    fun setMood(m: Mood, holdMs: Long = 0) {
        val now = System.currentTimeMillis()
        mood = m
        moodUntil = if (holdMs > 0) now + holdMs else 0
        lastInteract = now
        if (m == Mood.SURPRISED || (m == Mood.HAPPY && rnd.nextBoolean()) || m == Mood.LOVE) hop = 1f
        if (m == Mood.SURPRISED) spawn(3)
    }

    fun talk(ms: Long) { talkUntil = System.currentTimeMillis() + ms }

    /** Called for every screen touch. Poke the markhor to make it happy, or call it over to the touch. */
    fun onTap(x: Float, y: Float) {
        lastInteract = System.currentTimeMillis()
        if (mood == Mood.SLEEP) { mood = Mood.SURPRISED; moodUntil = lastInteract + 1500; hop = 1f }
        if (px < 0) return
        if (hypot(x - px, y - (py - 30 * u)) < 55 * u) {
            setMood(Mood.LOVE, 3500)
        } else {
            tx = clampX(x)
            ty = clampY(y)
            waitUntil = t + 5f
            if (mood == Mood.IDLE) setMood(Mood.HAPPY, 1500)
        }
    }

    fun setAccent(c: Int) { accent = c }

    // ---------- loop ----------

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        running = true
        last = 0L
        postOnAnimation(this)
    }

    override fun onDetachedFromWindow() {
        running = false
        removeCallbacks(this)
        super.onDetachedFromWindow()
    }

    override fun run() {
        if (!running) return
        val now = System.nanoTime()
        val dt = if (last == 0L) 0.016f else min(0.05f, (now - last) / 1e9f)
        last = now
        update(dt)
        invalidate()
        postOnAnimation(this)
    }

    private fun clampX(x: Float) = max(40 * u, min(width - 40 * u, x))
    private fun clampY(y: Float) = max(92 * u, min(height - 40 * u, y))

    private fun pickTarget() {
        tx = clampX(40 * u + rnd.nextFloat() * (width - 80 * u))
        ty = clampY(92 * u + rnd.nextFloat() * (height - 130 * u))
    }

    private fun update(dt: Float) {
        if (width == 0 || height == 0) return
        t += dt
        val nowMs = System.currentTimeMillis()
        if (px < 0) { px = width * 0.5f; py = height * 0.62f; tx = px; ty = py }

        if (moodUntil > 0 && nowMs > moodUntil) { mood = Mood.IDLE; moodUntil = 0 }
        if (mood == Mood.IDLE && nowMs - lastInteract > 40000) mood = Mood.SLEEP

        // walking
        val still = mood == Mood.SLEEP || mood == Mood.LISTENING || mood == Mood.THINKING
        val dx = tx - px
        val dy = ty - py
        val dist = hypot(dx, dy)
        if (!still && dist > 4f) {
            val sp = (if (mood == Mood.HAPPY || mood == Mood.LOVE) 190f else 140f) * d * dt
            val k = min(1f, sp / dist)
            px += dx * k
            py += dy * k
            if (abs(dx) > 3f) dir = if (dx > 0) 1f else -1f
            moving = true
        } else {
            moving = false
            if (!still && t >= waitUntil) { pickTarget(); waitUntil = t + 3f + rnd.nextFloat() * 5f }
        }

        if (hop > 0f) hop = max(0f, hop - dt * 1.5f)

        // blinking
        nextBlink -= dt
        if (nextBlink <= 0f) { blink = 0.14f; nextBlink = 2f + rnd.nextFloat() * 3.5f }
        if (blink > 0f) blink -= dt

        // feelings -> floating bits
        spawnT -= dt
        if (spawnT <= 0f) {
            when (mood) {
                Mood.LOVE -> { spawn(0); spawnT = 0.3f }
                Mood.HAPPY -> { spawn(1); spawnT = 0.5f }
                Mood.SLEEP -> { spawn(2); spawnT = 1.3f }
                Mood.THINKING -> { spawn(3); spawnT = 1.4f }
                Mood.SAD -> { spawn(4); spawnT = 0.6f }
                Mood.SURPRISED -> { spawn(5); spawnT = 0.7f }
                else -> spawnT = 0.4f
            }
        }
        val it = parts.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.life -= dt
            if (p.life <= 0f) it.remove()
        }

        // a little bird flies by now and then
        nextBird -= dt
        if (!birdOn && nextBird <= 0f) {
            birdOn = true; birdX = -30 * d; birdY = height * (0.08f + rnd.nextFloat() * 0.3f)
        }
        if (birdOn) {
            birdX += 120 * d * dt
            birdY += sin(t * 2f) * 20f * dt
            if (birdX > width + 30 * d) { birdOn = false; nextBird = 12f + rnd.nextFloat() * 15f }
        }
    }

    private fun headX() = px + dir * 32 * u
    private fun headY() = py - 32 * u - hopOff()
    private fun hopOff() = if (hop > 0f) sin((1f - hop) * Math.PI.toFloat()) * 26 * u else 0f

    private fun spawn(kind: Int) {
        val x = headX() + (rnd.nextFloat() - 0.5f) * 30 * u
        val y = headY() - 30 * u
        when (kind) {
            0 -> parts.add(P(x, y, (rnd.nextFloat() - 0.5f) * 30 * d, -45 * d, 1.8f, 0))
            1 -> parts.add(P(x, y, (rnd.nextFloat() - 0.5f) * 50 * d, -30 * d, 1.2f, 1))
            2 -> parts.add(P(headX() + dir * 14 * u, headY() - 8 * u, 14 * d, -22 * d, 2f, 2))
            3 -> parts.add(P(headX() + dir * 10 * u, headY() - 56 * u, 0f, -6 * d, 1.6f, 3))
            4 -> parts.add(P(headX() + dir * 4 * u, headY() + 2 * u, 0f, 50 * d, 1f, 4))
            5 -> parts.add(P(headX() + dir * 12 * u, headY() - 58 * u, 0f, -8 * d, 1.2f, 5))
        }
    }

    // ---------- drawing ----------

    private fun fill(c: Int, a: Int = 255) { paint.style = Paint.Style.FILL; paint.color = c; paint.alpha = a }
    private fun line(c: Int, w: Float, a: Int = 255) {
        paint.style = Paint.Style.STROKE; paint.color = c; paint.strokeWidth = w
        paint.strokeCap = Paint.Cap.ROUND; paint.alpha = a
    }

    private fun heart(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, a: Int = 255) {
        val p = Path()
        p.moveTo(cx, cy + s * 0.9f)
        p.cubicTo(cx - s * 1.6f, cy - s * 0.2f, cx - s * 0.7f, cy - s * 1.3f, cx, cy - s * 0.4f)
        p.cubicTo(cx + s * 0.7f, cy - s * 1.3f, cx + s * 1.6f, cy - s * 0.2f, cx, cy + s * 0.9f)
        p.close()
        fill(color, a)
        c.drawPath(p, paint)
    }

    private fun star(c: Canvas, cx: Float, cy: Float, s: Float, color: Int, a: Int) {
        val p = Path()
        p.moveTo(cx, cy - s); p.lineTo(cx + s * 0.3f, cy - s * 0.3f); p.lineTo(cx + s, cy)
        p.lineTo(cx + s * 0.3f, cy + s * 0.3f); p.lineTo(cx, cy + s); p.lineTo(cx - s * 0.3f, cy + s * 0.3f)
        p.lineTo(cx - s, cy); p.lineTo(cx - s * 0.3f, cy - s * 0.3f); p.close()
        fill(color, a)
        c.drawPath(p, paint)
    }

    override fun onDraw(c: Canvas) {
        if (px < 0) return
        drawButterfly(c)
        if (birdOn) drawBird(c)

        // shadow
        fill(Color.BLACK, 50)
        val sh = 1f - hopOff() / (60 * u)
        c.drawOval(RectF(px - 26 * u * sh, py + 31 * u, px + 26 * u * sh, py + 37 * u), paint)

        c.save()
        c.translate(px, py - hopOff())
        c.scale(u * dir, u)
        drawMarkhor(c)
        c.restore()

        drawParticles(c)
    }

    private fun bez(a: Float, b: Float, cc: Float, dd: Float, k: Float): Float {
        val m = 1 - k
        return m * m * m * a + 3 * m * m * k * b + 3 * m * k * k * cc + k * k * k * dd
    }

    private fun horn(c: Canvas, bx: Float, by: Float, p: FloatArray) {
        val path = Path()
        path.moveTo(bx + p[0], by + p[1])
        path.cubicTo(bx + p[2], by + p[3], bx + p[4], by + p[5], bx + p[6], by + p[7])
        line(0xFFE9DDB5.toInt(), 5.5f)
        c.drawPath(path, paint)
        // twisting ridges
        for (i in 1..8) {
            val k = i / 9f
            val x = bez(p[0], p[2], p[4], p[6], k) + bx
            val y = bez(p[1], p[3], p[5], p[7], k) + by
            val k2 = k + 0.02f
            val tx2 = bez(p[0], p[2], p[4], p[6], k2) + bx - x
            val ty2 = bez(p[1], p[3], p[5], p[7], k2) + by - y
            val len = hypot(tx2, ty2).coerceAtLeast(0.001f)
            val nx = -ty2 / len
            val ny = tx2 / len
            line(0xFF8C7748.toInt(), 1.5f)
            c.drawLine(x - nx * 2.8f + tx2 / len * 1.5f, y - ny * 2.8f + ty2 / len * 1.5f,
                x + nx * 2.8f - tx2 / len * 1.5f, y + ny * 2.8f - ty2 / len * 1.5f, paint)
        }
    }

    private fun drawMarkhor(c: Canvas) {
        val body = 0xFFBFAE92.toInt()
        val dark = 0xFF4A3F30.toInt()
        val cream = 0xFFF3EBDD.toInt()
        val bob = if (moving) abs(sin(t * 11f)) * -1.6f else sin(t * 2.6f) * 0.8f
        val hx = 32f
        val hy = -32f + bob + (if (mood == Mood.SLEEP) 8f else 0f)

        // legs
        val xs = floatArrayOf(-22f, -12f, 12f, 22f)
        for (i in xs.indices) {
            val ph = if (i % 2 == 0) 0f else Math.PI.toFloat()
            val off = if (moving) sin(t * 11f + ph) * 7f else 0f
            val lift = if (moving) max(0f, cos(t * 11f + ph)) * 3f else 0f
            line(if (i < 2) 0xFFA8977B.toInt() else body, 6f)
            c.drawLine(xs[i], 12f, xs[i] + off, 33f - lift, paint)
            line(0xFF5A4B38.toInt(), 6f)
            c.drawLine(xs[i] + off * 0.5f, 22f, xs[i] + off, 33f - lift, paint)
            fill(0xFF2E2A24.toInt())
            c.drawCircle(xs[i] + off, 33f - lift, 3.4f, paint)
        }

        // tail
        val wag = sin(t * (if (mood == Mood.HAPPY || mood == Mood.LOVE) 14f else 3f)) * 3f
        val tail = Path()
        tail.moveTo(-31f, -10f); tail.lineTo(-41f, -17f + wag); tail.lineTo(-30f, -1f); tail.close()
        fill(body); c.drawPath(tail, paint)

        // body, belly, neck
        fill(body); c.drawOval(RectF(-34f, -18f + bob, 34f, 21f + bob), paint)
        fill(cream, 220); c.drawOval(RectF(-24f, 3f + bob, 24f, 20f + bob), paint)
        fill(body); c.drawOval(RectF(12f, -36f + bob, 38f, 6f + bob), paint)

        // shaggy chest mane
        val mane = Path()
        mane.moveTo(14f, -16f + bob)
        val mp = floatArrayOf(6f, -2f, 11f, 0f, 5f, 13f, 12f, 10f, 8f, 25f, 17f, 16f, 21f, 27f, 25f, 12f, 31f, 19f, 33f, 0f)
        var mi = 0
        while (mi < mp.size) { mane.lineTo(mp[mi] + sin(t * 2f + mi) * 0.8f, mp[mi + 1] + bob); mi += 2 }
        mane.close()
        fill(0xFFE6DCC8.toInt()); c.drawPath(mane, paint)
        line(0xFFB9AC92.toInt(), 1f); c.drawPath(mane, paint)

        // beard (swaying)
        val sw = sin(t * 2f) * 2f
        val beard = Path()
        beard.moveTo(hx + 4f, hy + 8f)
        beard.lineTo(hx + 12f + sw, hy + 34f)
        beard.lineTo(hx + 7f, hy + 26f)
        beard.lineTo(hx + 3f + sw, hy + 39f)
        beard.lineTo(hx - 1f, hy + 25f)
        beard.lineTo(hx - 6f + sw, hy + 33f)
        beard.lineTo(hx - 7f, hy + 8f)
        beard.close()
        fill(cream); c.drawPath(beard, paint)
        line(0xFFCFC4AE.toInt(), 1f); c.drawPath(beard, paint)

        // horns (behind the head)
        val hs = sin(t * 1.5f) * 1.5f
        horn(c, hx - 5f, hy - 9f, floatArrayOf(0f, 0f, -13f, -18f, 5f, -30f, -9f + hs, -52f))
        horn(c, hx + 3f, hy - 10f, floatArrayOf(0f, 0f, 9f, -20f, 22f, -27f, 15f + hs, -50f))

        // ears
        val listen = mood == Mood.LISTENING
        val wig = sin(t * 5f) * (if (listen) 6f else 2f)
        for (e in 0..1) {
            c.save()
            if (e == 0) { c.translate(hx - 11f, hy - 5f); c.rotate(-75f + (if (listen) 40f else 0f) + wig) }
            else { c.translate(hx + 1f, hy - 11f); c.rotate(30f - (if (listen) 20f else 0f) - wig) }
            fill(body); c.drawOval(RectF(-3.8f, -14f, 3.8f, 0f), paint)
            fill(0xFFF2B8B0.toInt()); c.drawOval(RectF(-2f, -11.5f, 2f, -1.5f), paint)
            c.restore()
        }

        // head, snout, nose
        fill(body); c.drawOval(RectF(hx - 14f, hy - 12f, hx + 14f, hy + 12f), paint)
        fill(cream); c.drawOval(RectF(hx + 2f, hy + 1f, hx + 21f, hy + 14f), paint)
        fill(dark); c.drawCircle(hx + 17f, hy + 6f, 2.2f, paint)

        drawFace(c, hx, hy)
    }

    private fun drawFace(c: Canvas, hx: Float, hy: Float) {
        val ink = 0xFF1B1B1B.toInt()
        val closed = mood == Mood.SLEEP || blink > 0f
        val e1x = hx - 1f
        val e2x = hx + 10f
        val ey = hy - 2f
        var lx = if (moving) 0.9f else sin(t * 0.7f) * 0.7f
        var ly = 0f
        if (mood == Mood.THINKING) { lx = 0.8f; ly = -1.6f }

        for (ex in floatArrayOf(e1x, e2x)) {
            when {
                mood == Mood.LOVE -> heart(c, ex, ey, 3.3f, 0xFFFF4D6D.toInt())
                closed -> { line(ink, 1.8f); c.drawLine(ex - 3.2f, ey, ex + 3.2f, ey, paint) }
                mood == Mood.HAPPY -> {
                    line(ink, 1.9f)
                    c.drawArc(RectF(ex - 3.6f, ey - 3f, ex + 3.6f, ey + 4f), 200f, 140f, false, paint)
                }
                else -> {
                    val r = if (mood == Mood.SURPRISED) 5f else if (mood == Mood.LISTENING) 4.4f else 3.8f
                    fill(Color.WHITE); c.drawCircle(ex, ey, r, paint)
                    fill(ink); c.drawCircle(ex + lx, ey + ly + (if (mood == Mood.SAD) 1f else 0f), r * 0.55f, paint)
                    fill(Color.WHITE); c.drawCircle(ex + lx - 0.7f, ey + ly - 0.8f, 0.8f, paint)
                    if (mood == Mood.SAD) {
                        line(ink, 1.6f)
                        if (ex == e1x) c.drawLine(ex - 4f, ey - 4f, ex + 3f, ey - 7.5f, paint)
                        else c.drawLine(ex - 3f, ey - 7.5f, ex + 4f, ey - 4f, paint)
                    }
                }
            }
        }

        if (mood == Mood.HAPPY || mood == Mood.LOVE) {
            fill(0xFFFF8FA3.toInt(), 130)
            c.drawCircle(e1x - 4f, ey + 6f, 3.2f, paint)
            c.drawCircle(e2x + 3f, ey + 6f, 3.2f, paint)
        }

        // mouth
        val mx = hx + 11f
        val my = hy + 10.5f
        val talking = System.currentTimeMillis() < talkUntil
        if (talking) {
            fill(0xFF7A2E2E.toInt())
            val h = 1.5f + 2.6f * abs(sin(t * 14f))
            c.drawOval(RectF(mx - 3.2f, my - 1f, mx + 3.2f, my - 1f + h * 2f), paint)
        } else when (mood) {
            Mood.HAPPY, Mood.LOVE -> { line(ink, 1.6f); c.drawArc(RectF(mx - 5f, my - 4f, mx + 5f, my + 3f), 20f, 140f, false, paint) }
            Mood.SAD -> { line(ink, 1.6f); c.drawArc(RectF(mx - 4f, my + 0.5f, mx + 4f, my + 6.5f), 200f, 140f, false, paint) }
            Mood.SURPRISED -> { fill(0xFF7A2E2E.toInt()); c.drawOval(RectF(mx - 2.4f, my - 1f, mx + 2.4f, my + 5f), paint) }
            else -> { line(ink, 1.4f); c.drawArc(RectF(mx - 3f, my - 2f, mx + 3f, my + 2f), 20f, 140f, false, paint) }
        }

        // sound waves while listening
        if (mood == Mood.LISTENING) {
            for (i in 0..2) {
                val r = 18f + ((t * 22f + i * 8f) % 24f)
                val a = (200 * (1f - (r - 18f) / 24f)).toInt().coerceIn(0, 255)
                line(accent, 1.6f, a)
                c.drawArc(RectF(hx - 8f - r, hy - 12f - r, hx - 8f + r, hy - 12f + r), 200f, 100f, false, paint)
            }
        }
    }

    private fun drawParticles(c: Canvas) {
        for (p in parts) {
            val a = (255 * min(1f, p.life)).toInt().coerceIn(0, 255)
            when (p.kind) {
                0 -> heart(c, p.x, p.y, 6 * d, 0xFFFF4D6D.toInt(), a)
                1 -> star(c, p.x, p.y, 6 * d, 0xFFFFD54F.toInt(), a)
                2, 3, 5 -> {
                    paint.style = Paint.Style.FILL
                    paint.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                    paint.textSize = (if (p.kind == 2) 16 else 20) * d
                    paint.color = if (p.kind == 5) 0xFFFFD54F.toInt() else accent
                    paint.alpha = a
                    c.drawText(if (p.kind == 2) "z" else if (p.kind == 3) "?" else "!", p.x, p.y, paint)
                }
                4 -> { fill(0xFF6EC6FF.toInt(), a); c.drawCircle(p.x, p.y, 2.6f * d, paint) }
            }
        }
    }

    private fun drawButterfly(c: Canvas) {
        val bx = width * (0.5f + 0.42f * sin(t * 0.31f))
        val by = height * (0.45f + 0.3f * sin(t * 0.47f + 1f)) + sin(t * 3f) * 8f * d
        val flap = abs(sin(t * 14f))
        val w = 8 * d * (0.3f + 0.7f * flap)
        fill(accent, 190); c.drawOval(RectF(bx - w, by - 6 * d, bx, by + 1 * d), paint)
        fill(0xFFFF8AD8.toInt(), 190); c.drawOval(RectF(bx, by - 6 * d, bx + w, by + 1 * d), paint)
        fill(accent, 150); c.drawOval(RectF(bx - w * 0.8f, by, bx, by + 5 * d), paint)
        fill(0xFFFF8AD8.toInt(), 150); c.drawOval(RectF(bx, by, bx + w * 0.8f, by + 5 * d), paint)
        line(Color.WHITE, 1.4f * d, 200); c.drawLine(bx, by - 4 * d, bx, by + 5 * d, paint)
    }

    private fun drawBird(c: Canvas) {
        val f = sin(t * 12f)
        line(accent, 2.4f * d)
        c.drawLine(birdX, birdY, birdX - 9 * d, birdY - 7 * d * f, paint)
        c.drawLine(birdX, birdY, birdX + 9 * d, birdY - 7 * d * f, paint)
        fill(accent); c.drawCircle(birdX, birdY + 1 * d, 2.6f * d, paint)
    }
}
