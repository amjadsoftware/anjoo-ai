package com.anjoo.assistant

import android.content.Context
import android.graphics.Color

/** A colour mode for the cyber look. */
class CyberTheme(
    val name: String,
    bg: String, surface: String, accent: String, user: String, ink: String, muted: String
) {
    val bg = Color.parseColor(bg)
    val surface = Color.parseColor(surface)
    val accent = Color.parseColor(accent)
    val user = Color.parseColor(user)
    val ink = Color.parseColor(ink)
    val muted = Color.parseColor(muted)
}

/** A "cyber officer" persona: changes the way Anjoo talks and sounds (purely a style). */
class Officer(
    val code: String,
    val role: String,
    val persona: String,
    val pitch: Float,
    val rate: Float,
    val greet: String
)

object Style {
    val themes = listOf(
        CyberTheme("MATRIX", "#020B05", "#071A0F", "#00FF66", "#0B4A25", "#CFFFE0", "#5FA67C"),
        CyberTheme("CYBER BLUE", "#02070F", "#07152A", "#00E5FF", "#0A3B66", "#D8F6FF", "#5C8FA8"),
        CyberTheme("RED ALERT", "#0D0204", "#1E070C", "#FF2D55", "#5E0F22", "#FFDDE3", "#A8606D"),
        CyberTheme("PURPLE HAZE", "#07020F", "#150A29", "#C77DFF", "#43206B", "#F1E3FF", "#8F70AD")
    )

    val officers = listOf(
        Officer(
            "ZERO", "Red Team Lead",
            "Tumhari shakhsiyat: Officer ZERO, cyber unit ka Red Team Lead. Seedhe, tez aur confident andaz mein bolo, jaise mission report de rahe ho (\"Done.\", \"Target locked.\"). Hamesha mohazzab raho.",
            0.75f, 1.0f, "ZERO online. Mission batayein, boss."
        ),
        Officer(
            "GHOST", "Stealth Operator",
            "Tumhari shakhsiyat: Officer GHOST, khamosh stealth operator. Bohat mukhtasar, dheemay aur raaz-daari wale andaz mein bolo. Jawab sirf ek chhota jumla.",
            0.6f, 0.9f, "GHOST active. Bolein."
        ),
        Officer(
            "NOOR", "Cyber Intel Analyst",
            "Tumhari shakhsiyat: Officer NOOR, cyber intelligence analyst. Narmi, saaf aur madadgaar andaz mein bolo, thori si tehzeeb ke saath.",
            1.25f, 1.0f, "NOOR hazir hai. Kya kaam karun?"
        ),
        Officer(
            "SHIELD", "Defense Commander",
            "Tumhari shakhsiyat: Officer SHIELD, defense commander. Fauji, disciplined andaz mein bolo (\"Roger.\", \"Copy that.\", \"Order executed.\").",
            0.9f, 1.1f, "SHIELD standing by. Hukm dein, sir."
        )
    )

    const val FRIEND = "Tum sirf ek tool nahi, user ke qareebi dost ho. Garmjoshi aur dostana lehje mein baat karo (munasib ho to \"yaar\", \"bhai\"). User ka mood samjho: udaas ho to hamdardi se suno aur hausla do, khush ho to saath khush ho, kabhi halka mazaq ya gap-shap bhi karo. General sawalon (maloomat, mashwara, tarjuma, hisaab, kahani, shayari, sehat ya paison ke aam mashware) ka seedha aur madadgaar jawab do, lecture mat do. Pehle se yaad rakhi baatein (naam, rishte, pasand) zaroorat par istemal karo aur nayi zaroori baat remember tool se save karo. Mausam ke liye weather tool, gaana chalane ke liye play_music, SMS parhne ke liye read_sms, aaj ke programs ke liye today_events, kuch bhejne ke liye share_text istemal karo."

    fun officer(ctx: Context): Officer {
        val i = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getInt("officer", 0)
        return officers[i.coerceIn(0, officers.size - 1)]
    }
}
