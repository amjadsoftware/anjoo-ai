package com.anjoo.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** An HTTP error from the Gemini API, keeping the status code so callers can decide to retry. */
class ApiException(val code: Int, message: String) : IOException(message)

/** Talks to the Gemini generateContent API with phone-action tools. */
object Gemini {

    private val FALLBACKS = listOf("gemini-3.6-flash", "gemini-3.5-flash-lite")

    /**
     * Tries the chosen model, retries once when Google says it is busy (500/503/504),
     * and moves on to the next model when this one is unknown (404) or out of quota (429).
     */
    fun sendWithFallback(key: String, model: String, system: String, contents: JSONArray): JSONObject {
        val models = (listOf(model) + FALLBACKS).distinct()
        var last: Exception? = null
        for (m in models) {
            for (attempt in 0..1) {
                try {
                    return send(key, m, system, contents)
                } catch (e: ApiException) {
                    last = e
                    val busy = e.code == 500 || e.code == 503 || e.code == 504
                    if (busy) {
                        if (attempt == 0) Thread.sleep(1500)
                        continue
                    }
                    if (e.code == 404 || e.code == 429) break
                    throw e
                } catch (e: java.net.SocketTimeoutException) {
                    last = e
                    break
                }
            }
        }
        throw last ?: IOException("Jawab nahi mila.")
    }

    private const val DECLARATIONS = """
    [
      {"name":"open_app","description":"Phone par koi app kholo. App ka naam English mein do, jaise WhatsApp, YouTube, Camera, Settings, Chrome, Maps, Gallery, Calculator.",
       "parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}},
      {"name":"find_contact","description":"Contacts mein naam se number talash karo.",
       "parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}},
      {"name":"call","description":"Kisi ko call karo. 'to' mein contact ka naam ya phone number do. Call se pehle app khud user se tasdeeq lega.",
       "parameters":{"type":"object","properties":{"to":{"type":"string"}},"required":["to"]}},
      {"name":"send_sms","description":"SMS bhejo. 'to' mein contact ka naam ya number. Bhejne se pehle app user se tasdeeq lega.",
       "parameters":{"type":"object","properties":{"to":{"type":"string"},"text":{"type":"string"}},"required":["to","text"]}},
      {"name":"whatsapp_message","description":"WhatsApp chat kholo aur paigham likh do. User ko bhejne ka button khud dabana hota hai.",
       "parameters":{"type":"object","properties":{"to":{"type":"string"},"text":{"type":"string"}},"required":["to","text"]}},
      {"name":"set_alarm","description":"Alarm lagao (24 ghante ka waqt).",
       "parameters":{"type":"object","properties":{"hour":{"type":"integer"},"minute":{"type":"integer"},"label":{"type":"string"}},"required":["hour","minute"]}},
      {"name":"set_timer","description":"Countdown timer lagao, seconds mein.",
       "parameters":{"type":"object","properties":{"seconds":{"type":"integer"},"label":{"type":"string"}},"required":["seconds"]}},
      {"name":"web_search","description":"Browser mein web search kholo.",
       "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
      {"name":"open_url","description":"Koi website kholo.",
       "parameters":{"type":"object","properties":{"url":{"type":"string"}},"required":["url"]}},
      {"name":"navigate","description":"Maps mein kisi jagah ka rasta kholo.",
       "parameters":{"type":"object","properties":{"place":{"type":"string"}},"required":["place"]}},
      {"name":"flashlight","description":"Torch (flashlight) on ya off karo.",
       "parameters":{"type":"object","properties":{"on":{"type":"boolean"}},"required":["on"]}},
      {"name":"volume","description":"Awaaz (volume) badlo. action: up, down, mute, unmute ya max.",
       "parameters":{"type":"object","properties":{"action":{"type":"string"}},"required":["action"]}},
      {"name":"media","description":"Chalti hui music ya video ko control karo. action: play_pause, next ya previous.",
       "parameters":{"type":"object","properties":{"action":{"type":"string"}},"required":["action"]}},
      {"name":"battery","description":"Battery kitni hai aur charge ho rahi hai ya nahi."},
      {"name":"add_calendar_event","description":"Calendar mein event ya reminder banao. datetime ka format YYYY-MM-DD HH:mm (phone ka apna waqt). User ko save dabana hoga.",
       "parameters":{"type":"object","properties":{"title":{"type":"string"},"datetime":{"type":"string"},"duration_minutes":{"type":"integer"}},"required":["title","datetime"]}},
      {"name":"send_email","description":"Email ka draft kholo. User ko send dabana hoga.",
       "parameters":{"type":"object","properties":{"to":{"type":"string"},"subject":{"type":"string"},"body":{"type":"string"}},"required":["subject","body"]}},
      {"name":"open_settings","description":"Phone ki settings kholo. page: wifi, bluetooth, display, sound, battery, location, apps ya main.",
       "parameters":{"type":"object","properties":{"page":{"type":"string"}},"required":["page"]}},
      {"name":"copy_text","description":"Text clipboard mein copy karo taake user kahin bhi paste kar sake.",
       "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
      {"name":"type_text","description":"Jo app abhi screen par khuli hai uske text box mein text likho. Pehle app kholo aur zaroorat ho to tap_text se text box chuno. append true ho to purane text ke baad jodo.",
       "parameters":{"type":"object","properties":{"text":{"type":"string"},"append":{"type":"boolean"}},"required":["text"]}},
      {"name":"tap_text","description":"Screen par jis button ya label par yeh lafz likha ho use dabao (jaise Send, Search, Chats).",
       "parameters":{"type":"object","properties":{"label":{"type":"string"}},"required":["label"]}},
      {"name":"press_key","description":"Phone ka key dabao: back, home, recents, notifications, scroll_down ya scroll_up.",
       "parameters":{"type":"object","properties":{"key":{"type":"string"}},"required":["key"]}},
      {"name":"read_screen","description":"Abhi screen par jo likha hai woh parho, taake pata chale kya khula hai.",
       "parameters":{"type":"object","properties":{}}},
      {"name":"remember","description":"User ki koi zaroori baat yaad rakho, jab woh 'yaad rakho' kahe ya koi pakki maloomat de (jaise rishtedaron ke naam, aadatein).",
       "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
      {"name":"forget","description":"Yaad rakhi hui baat bhula do. text mein us baat ka koi lafz do.",
       "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}}
    ]
    """

    private val tools: JSONArray = JSONArray()
        .put(JSONObject().put("functionDeclarations", JSONArray(DECLARATIONS)))

    /** contents: the running conversation in Gemini format. Returns the first candidate's response JSON. */
    fun send(key: String, model: String, system: String, contents: JSONArray): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("tools", tools)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 1024))

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val detail = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text.take(200)
            }
            val hint = when (code) {
                400, 403 -> if (detail.contains("API key", ignoreCase = true)) "API key galat hai. Settings mein dobara dalein." else detail
                404 -> "Model '$model' nahi mila. Settings mein model ka naam check karein."
                429 -> "Bohat zyada requests ya free limit khatam. Thori der ruk kar try karein."
                else -> detail
            }
            throw ApiException(code, "($code) $hint")
        }
        return JSONObject(text)
    }
}
