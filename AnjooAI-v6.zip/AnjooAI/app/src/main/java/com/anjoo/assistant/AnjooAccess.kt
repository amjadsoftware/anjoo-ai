package com.anjoo.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Lets Anjoo type text, tap buttons and press back/home in any app. The user must switch it on once. */
class AnjooAccess : AccessibilityService() {

    companion object {
        @Volatile var inst: AnjooAccess? = null
        const val OFF = "Accessibility band hai. Anjoo app mein ACCESS dabayein aur Anjoo AI ko on karein."

        /** Retries for a few seconds, because a freshly opened app needs a moment to appear. */
        fun <T> retry(tries: Int = 8, gap: Long = 500, block: () -> T?): T? {
            repeat(tries) {
                val r = block()
                if (r != null) return r
                try { Thread.sleep(gap) } catch (e: InterruptedException) { return null }
            }
            return null
        }
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    fun typeText(text: String, append: Boolean): String {
        val done = retry {
            val root = rootInActiveWindow ?: return@retry null
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
                ?: findEditable(root) ?: return@retry null
            val old = if (append && !node.isShowingHintText) (node.text?.toString() ?: "") else ""
            val b = Bundle()
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + text)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        }
        return if (done == true) "Text likh diya." else "Koi text box nahi mila ya text nahi likha ja saka."
    }

    fun tapText(label: String): String {
        val done = retry {
            val root = rootInActiveWindow ?: return@retry null
            val hits = root.findAccessibilityNodeInfosByText(label)
            for (h in hits) {
                var n: AccessibilityNodeInfo? = h
                while (n != null && !n.isClickable) n = n.parent
                if (n != null && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return@retry true
            }
            null
        }
        return if (done == true) "'$label' dba diya." else "Screen par '$label' nahi mila."
    }

    fun key(k: String): String {
        val ok = when (k.lowercase()) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "scroll_down", "scroll_up" -> scroll(k.lowercase() == "scroll_down")
            else -> return "Yeh key samajh nahi aayi: $k"
        }
        return if (ok) "Ho gaya." else "Nahi ho saka."
    }

    private fun scrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) scrollable(n.getChild(i))?.let { return it }
        return null
    }

    private fun scroll(down: Boolean): Boolean {
        val s = scrollable(rootInActiveWindow) ?: return false
        return s.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    fun readScreen(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 1800) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) sb.append(t.trim()).append(" | ")
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return if (sb.isEmpty()) "Screen par kuch parha nahi gaya." else sb.toString()
    }
}
