# Anjoo AI: Android awaazi assistant

Mic dabayein aur bolein. Gemini hukm samajhta hai aur phone par kaam karta hai.

## Kya kar sakta hai
- Koi bhi installed app kholna ("WhatsApp kholo", "YouTube kholo")
- Contacts se naam dhoond kar call karna (call se pehle "Haan/Nahi" poochta hai)
- SMS bhejna (bhejne se pehle poochta hai)
- WhatsApp chat kholna aur paigham likh dena (send ka button aap dabate hain)
- Alarm aur timer lagana
- Web search, website kholna, Maps mein rasta
- Jawab awaaz mein bhi sunata hai (agar phone mein Urdu/English voice maujood ho)

## Jo nahi kar sakta
- Doosri apps ke andar khud tap karna (jaise bank app mein paise bhejna). Yeh jaan boojh kar nahi rakha.
- WhatsApp ka paigham khud send karna. Android is ki ijazat nahi deta, aap ko ek tap karna hota hai.

## Banane ke qadam (pehli baar)
1. Computer par Android Studio install karein (developer.android.com/studio).
2. Android Studio mein File > Open, aur is `AnjooAI` folder ko kholein. Gradle sync poora hone dein (internet chahiye, pehli baar kuch minute lagte hain).
3. Phone mein Settings > About phone > Build number par 7 baar tap karein, phir Developer options mein USB debugging on karein.
4. Phone ko USB se jorain, Android Studio mein upar ka hara Run button dabayein. App phone par install ho jayegi.
   (Ya Build > Build APK(s) se APK bana kar phone mein copy karke install karein.)

## Pehli dafa istemal
1. App kholte hi Settings aayegi. Apni Gemini API key dalein: aistudio.google.com/apikey par apne Google account se "Create API key" dabayein. Model "gemini-3.8-flash" rakhein (ya wahan ki list se jo naam dikhe).
2. Mic, contacts, call aur SMS ki ijazat "Allow" karein.
3. Mic dabayein aur bolein: "Ahmed ko call karo", "Subah 6 baje ka alarm lagao", "WhatsApp kholo".
   Zubaan ka button "اردو / English" bolne ki zubaan badalta hai.

## Zaroori baatein
- Gemini Pro subscription aur API key do alag cheezein hain. Key AI Studio se banti hai, us par free limit hoti hai aur us se zyada istemal par kharcha ho sakta hai. Key kisi ko na dein; yeh sirf aap ke phone mein rehti hai.
- WhatsApp ke liye "0300..." wale number Pakistan ke code (92) mein badal diye jate hain.
- Awaaz pehchaan Google ki service use karti hai, is liye internet aur Google app chahiye.
- Pehle kuch din call/SMS ki tasdeeq wali screen par nazar rakhein ke naam aur number sahi hain.
