package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Lets code (including a tool running on a background thread) show the visual folder picker and wait for the answer. */
object FolderPicker {
    @Volatile private var latch: CountDownLatch? = null
    @Volatile private var result: String? = null

    /** Opens the picker and waits for the user. Returns the chosen folder (like "Documents/Reports") or null if cancelled / timed out. */
    fun pick(ctx: Context, timeoutMs: Long = 120000, setDefault: Boolean = false): String? {
        result = null
        val l = CountDownLatch(1)
        latch = l
        try {
            ctx.startActivity(Intent(ctx, FolderPickerActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("setDefault", setDefault))
        } catch (e: Exception) { latch = null; return null }
        try { l.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (e: InterruptedException) {}
        latch = null
        return result
    }

    internal fun deliver(path: String?) { result = path; latch?.countDown() }
}

/** A built-in folder browser: open folders, make new ones, tap "Select this folder". */
class FolderPickerActivity : Activity() {
    private var dir: MutableList<String> = ArrayList()
    private var delivered = false
    private lateinit var pathView: TextView
    private lateinit var list: LinearLayout
    private lateinit var note: TextView
    private lateinit var remember: CheckBox
    private val GREEN = Color.parseColor("#3DDC84")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#0F1512")); setPadding(dp(14), dp(34), dp(14), dp(12)) }
        root.addView(TextView(this).apply { text = "Choose a folder"; textSize = 22f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD })
        note = TextView(this).apply { textSize = 12f; setTextColor(Color.parseColor("#9FB0A6")); setPadding(0, dp(4), 0, dp(8)) }
        root.addView(note)
        pathView = TextView(this).apply { textSize = 14f; setTextColor(GREEN); typeface = Typeface.MONOSPACE; setPadding(dp(10), dp(8), dp(10), dp(8)); background = GradientDrawable().apply { setColor(Color.parseColor("#16201B")); cornerRadius = dp(10).toFloat() } }
        root.addView(pathView)
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(4)) }
        tools.addView(Button(this).apply { text = "⬆ Up"; isAllCaps = false; setOnClickListener { if (dir.isNotEmpty()) { dir.removeAt(dir.size - 1); refresh() } } })
        tools.addView(Button(this).apply { text = "＋ New folder"; isAllCaps = false; setOnClickListener { newFolder() } })
        tools.addView(Button(this).apply { text = "More access"; isAllCaps = false; setOnClickListener { startActivity(Intent(this@FolderPickerActivity, StorageActivity::class.java)) } })
        root.addView(tools)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        remember = CheckBox(this).apply {
            text = "Use as my default save folder"; setTextColor(Color.WHITE)
            isChecked = intent.getBooleanExtra("setDefault", false)
        }
        root.addView(remember)
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
        bottom.addView(Button(this).apply { text = "Cancel"; isAllCaps = false; setOnClickListener { finish() } })
        bottom.addView(Button(this).apply { text = "✔ Select this folder"; isAllCaps = false; setOnClickListener { select() } })
        root.addView(bottom)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); refresh() }

    override fun onDestroy() {
        super.onDestroy()
        if (!delivered) { delivered = true; FolderPicker.deliver(null) }
    }

    private fun shownPath(): String = FileAccess.rootLabel(this) + (if (dir.isEmpty()) "" else "/" + dir.joinToString("/"))

    private fun refresh() {
        note.text = FileAccess.browseNote(this)
        pathView.text = shownPath()
        list.removeAllViews()
        val subs = try { FileAccess.subfolders(this, dir) } catch (e: Exception) { emptyList() }
        if (subs.isEmpty()) {
            list.addView(TextView(this).apply { text = "No sub-folders here. You can select this folder or make a new one."; textSize = 13f; setTextColor(Color.parseColor("#9FB0A6")); setPadding(dp(6), dp(14), dp(6), dp(14)) })
        }
        for (n in subs) {
            list.addView(TextView(this).apply {
                text = "📁  $n"; textSize = 16f; setTextColor(Color.WHITE); setPadding(dp(12), dp(14), dp(12), dp(14))
                background = GradientDrawable().apply { setColor(Color.parseColor("#16201B")); cornerRadius = dp(10).toFloat() }
                setOnClickListener { dir.add(n); refresh() }
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        }
    }

    private fun newFolder() {
        val et = EditText(this).apply { hint = "Folder name"; inputType = InputType.TYPE_CLASS_TEXT }
        AlertDialog.Builder(this).setTitle("New folder in " + shownPath()).setView(et)
            .setPositiveButton("Create") { _, _ ->
                val n = et.text.toString().trim().replace(Regex("[\\\\/:*?\"<>|]"), "_")
                if (n.isEmpty() || n == "." || n == "..") return@setPositiveButton
                if (FileAccess.makeFolder(this, dir, n)) { dir.add(n); refresh() } else Toast.makeText(this, "Folder nahi ban saka (access chahiye).", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun select() {
        if (dir.isEmpty() && !FileAccess.allFiles(this) && FileAccess.treeUri(this) == null) {
            Toast.makeText(this, "Pehle ek folder kholein (jaise Download ya Documents).", Toast.LENGTH_LONG).show(); return
        }
        val p = if (dir.isEmpty()) "." else dir.joinToString("/")
        if (remember.isChecked) FileAccess.setDefaultFolder(this, p)
        delivered = true
        FolderPicker.deliver(p)
        Toast.makeText(this, "Folder: " + shownPath(), Toast.LENGTH_SHORT).show()
        finish()
    }
}
