package com.anjoo.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import java.util.Locale

/**
 * Shared helpers that make spoken Urdu and English flow naturally:
 * text is cleaned (no "star star" or emoji read out loud), mixed Urdu/English replies are cut into parts
 * and each part is spoken with the matching voice, and other audio (music, videos) is lowered while
 * Anjoo talks.
 */
object VoiceKit {

    class Seg(val text: String, val urdu: Boolean)

    fun isUrdu(c: Char) = c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' || c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    /** Removes things that sound silly when read out: markdown marks, links, code, emoji, list dashes. */
    fun clean(text: String): String {
        var t = text
        t = Regex("```[\\s\\S]*?```").replace(t, " ")
        t = Regex("https?://\\S+").replace(t, " ")
        t = Regex("\\[\\[img:[^\\]]*]]").replace(t, " ")
        t = Regex("(?m)^\\s*[-\\u2022*]\\s+").replace(t, "")
        t = t.replace(Regex("[*_`#>|~]+"), " ")
        t = Regex("[\u2600-\u27BF\uFE0F\u200D\u20E3]|[\uD83C-\uD83E][\uDC00-\uDFFF]").replace(t, " ")
        t = t.replace(Regex("[ \\t]+"), " ").replace(Regex("\\s*\\n\\s*"), ". ").replace(Regex("\\.\\s*\\.+"), ".")
        return t.trim()
    }

    /** Cuts [text] into speakable parts. Urdu script goes to the Urdu voice, Latin script to the English voice. */
    fun segments(text: String): List<Seg> {
        val out = ArrayList<Seg>()
        val sentences = Regex("[^.!?\\u06D4\\u061F\\n]+[.!?\\u06D4\\u061F]*").findAll(text)
            .map { it.value.trim() }.filter { it.isNotEmpty() }.toList()
        for (s in sentences) {
            val words = s.split(' ').filter { it.isNotEmpty() }
            if (words.none { w -> w.any { isUrdu(it) } }) {
                addSplit(out, s, false)
                continue
            }
            // runs of consecutive words in the same script
            val runs = ArrayList<Pair<MutableList<String>, Boolean>>()
            for (w in words) {
                val hasU = w.any { isUrdu(it) }
                val hasL = w.any { it.isLetter() && !isUrdu(it) }
                val u = if (hasU) true else if (hasL) false else (runs.lastOrNull()?.second ?: true)
                val last = runs.lastOrNull()
                if (last != null && last.second == u) last.first.add(w) else runs.add(Pair(mutableListOf(w), u))
            }
            // a short English bit inside an Urdu sentence (an app name, a number) stays with the Urdu voice
            for (i in runs.indices) {
                val r = runs[i]
                if (!r.second && r.first.size <= 2 && runs.size > 1) runs[i] = Pair(r.first, true)
            }
            var cur = StringBuilder()
            var curU = runs[0].second
            for (r in runs) {
                if (r.second != curU) {
                    addSplit(out, cur.toString().trim(), curU)
                    cur = StringBuilder()
                    curU = r.second
                }
                cur.append(' ').append(r.first.joinToString(" "))
            }
            addSplit(out, cur.toString().trim(), curU)
        }
        // join neighbours that use the same voice so there are fewer pauses
        val merged = ArrayList<Seg>()
        for (g in out) {
            val l = merged.lastOrNull()
            if (l != null && l.urdu == g.urdu && l.text.length + g.text.length < 260) {
                merged[merged.size - 1] = Seg(l.text + " " + g.text, g.urdu)
            } else merged.add(g)
        }
        return merged
    }

    private fun addSplit(out: MutableList<Seg>, text: String, urdu: Boolean) {
        var t = text.trim()
        if (t.isEmpty()) return
        while (t.length > 300) {
            var cut = t.lastIndexOf(',', 300)
            if (cut < 120) cut = t.lastIndexOf('\u060C', 300)
            if (cut < 120) cut = t.lastIndexOf(' ', 300)
            if (cut < 60) cut = 300
            out.add(Seg(t.substring(0, cut + 1).trim(), urdu))
            t = t.substring(minOf(cut + 1, t.length)).trim()
        }
        if (t.isNotEmpty()) out.add(Seg(t, urdu))
    }

    fun urduAvailable(t: TextToSpeech): Boolean =
        try { t.isLanguageAvailable(Locale("ur", "PK")) >= TextToSpeech.LANG_AVAILABLE } catch (e: Exception) { false }

    private fun setLang(t: TextToSpeech, loc: Locale) {
        val r = t.setLanguage(loc)
        if (r < 0 && loc.language == "en") t.setLanguage(Locale.US)
    }

    /**
     * Speaks [text] with the right voice for each part, queued one after another.
     * Only the LAST part is announced with [id]; earlier parts use "id#n", which listeners must ignore.
     * Returns false when there was nothing to say.
     */
    fun speak(t: TextToSpeech, text: String, id: String, urduOk: Boolean, pitch: Float, rate: Float): Boolean {
        val segs = segments(clean(text).take(3500))
        if (segs.isEmpty()) return false
        var first = true
        for ((i, s) in segs.withIndex()) {
            val useUrdu = s.urdu && urduOk
            setLang(t, if (useUrdu) Locale("ur", "PK") else Locale("en", "IN"))
            t.setPitch(pitch)
            t.setSpeechRate(if (useUrdu) rate * 0.95f else rate)
            val uid = if (i == segs.size - 1) id else "$id#$i"
            t.speak(s.text, if (first) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, uid)
            first = false
        }
        return true
    }

    // ---------- other apps' sound ----------

    @Volatile private var focus: AudioFocusRequest? = null

    /** Lowers music or video while Anjoo talks. */
    fun focusOn(ctx: Context) {
        try {
            val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            focusOff(ctx)
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANT)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                .setOnAudioFocusChangeListener { }
                .build()
            am.requestAudioFocus(req)
            focus = req
        } catch (e: Exception) {}
    }

    fun focusOff(ctx: Context) {
        try {
            val req = focus ?: return
            (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(req)
        } catch (e: Exception) {}
        focus = null
    }
}
