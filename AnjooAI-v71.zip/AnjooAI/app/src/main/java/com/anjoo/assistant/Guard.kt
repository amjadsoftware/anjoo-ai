package com.anjoo.assistant

import org.json.JSONObject

/**
 * Keeps Anjoo away from bank, wallet and card details.
 * Allowed: the user's own account number (or IBAN), copied or typed only when the user asks.
 * Never handled: card numbers, CVV, PIN, OTP, card expiry, passwords, and anything inside a bank or wallet app
 * (no reading, tapping, screenshots).
 */
object Guard {

    private val LONG_TOKENS = listOf(
        "bank", "wallet", "jazzcash", "mobilink", "easypaisa", "paypal", "sadapay", "nayapay", "upaisa", "raast",
        "paytm", "phonepe", "paisa", "spay", "stcpay", "alrajhi", "alinma", "payoneer", "revolut", "meezan",
        "alfalah", "faysal", "askari", "konnect", "finja", "paymob", "mastercard", "visa", "moneygram", "westernunion"
    )
    private val SHORT_SEGMENTS = setOf("hbl", "ubl", "scb", "wise", "snb", "mcb", "nbp", "abl", "pay", "pays", "upi", "gpay")

    const val FIN_MSG = "Yeh bank/wallet app hai. Aap ki hifazat ke liye main iske andar padhta, dabata ya screenshot nahi leta. Sirf aap ka account number likhwana ho to bol dein, woh paste kar dunga."
    const val CARD_MSG = "Card number, CVV, PIN, OTP ya password jaisi malomat main na copy karta hoon, na likhta hoon, na save karta hoon."

    fun isFinancialApp(pkg: String?): Boolean {
        if (pkg.isNullOrBlank()) return false
        val p = pkg.lowercase()
        if (p == "com.anjoo.assistant") return false
        if (LONG_TOKENS.any { p.contains(it) }) return true
        return p.split('.').any { it in SHORT_SEGMENTS }
    }

    private fun luhn(digits: String): Boolean {
        if (digits.length !in 13..19) return false
        var sum = 0
        var alt = false
        for (i in digits.length - 1 downTo 0) {
            var n = digits[i] - '0'
            if (alt) { n *= 2; if (n > 9) n -= 9 }
            sum += n
            alt = !alt
        }
        return sum % 10 == 0
    }

    private val CARD_RE = Regex("(?<![\\d])(?:\\d[ -]?){12,18}\\d(?![\\d])")
    private val SECRET_RE = Regex("(?i)\\b(cvv2?|cvc2?|pin(?:\\s*code)?|otp|security\\s*code|expiry(?:\\s*date)?|exp\\.?\\s*date|password|passcode)\\b\\s*(?:is|hai|:|=|-)?\\s*\\d{3,8}\\b")
    private val ACCOUNT_CONTEXT = Regex("(?i)(account|acc\\.?|a/c|iban|title)\\s*(no\\.?|number|#)?\\s*[:=-]?\\s*$")

    private fun cardMatches(text: String): List<MatchResult> = CARD_RE.findAll(text).filter { m ->
        val digits = m.value.filter { it.isDigit() }
        val before = text.substring(maxOf(0, m.range.first - 30), m.range.first)
        luhn(digits) && digits.length >= 15 && !ACCOUNT_CONTEXT.containsMatchIn(before)
    }.toList()

    /** True when the text holds a card number, or a CVV/PIN/OTP/password with its digits. */
    fun hasCardData(text: String): Boolean = cardMatches(text).isNotEmpty() || SECRET_RE.containsMatchIn(text)

    /** Hides card numbers, CVV, PIN, OTP, expiry and passwords. Account numbers and IBANs stay. */
    fun redact(text: String): String {
        var t = text
        for (m in cardMatches(text).sortedByDescending { it.range.first }) {
            t = t.replaceRange(m.range.first, m.range.last + 1, "[card number hidden]")
        }
        return SECRET_RE.replace(t) { r -> r.groupValues[1] + ": [hidden]" }
    }

    private val ACCOUNT_LIKE = Regex("^[A-Za-z]{0,2}[0-9][0-9 \\-A-Za-z]{6,32}$")

    /** An account number or IBAN, not a card number. */
    fun isAccountNumber(text: String): Boolean = ACCOUNT_LIKE.matches(text.trim()) && !hasCardData(text)

    private val SCREEN_TOOLS = setOf("read_screen", "list_screen", "tap_text", "tap_xy", "swipe", "tap_image", "look_at_screen", "type_text")
    private val TEXT_ARGS = listOf("text", "body", "content")
    private val REDACT_RESULTS = setOf("read_screen", "list_screen", "look_at_screen", "read_sms", "read_notifications", "today_events", "search_chats", "read_file", "list_files")

    /** Returns a refusal message when the tool must not run, or null when it may. */
    fun block(name: String, a: JSONObject, pkg: String?): String? {
        if (name == "remember" && (hasCardData(a.optString("text")) || Regex("(?i)\\b(cvv|cvc|pin|otp|password|passcode|card)\\b").containsMatchIn(a.optString("text")))) return CARD_MSG
        if (name in listOf("copy_text", "type_text", "share_text", "send_sms", "whatsapp_message", "send_email", "reply_message", "save_file", "edit_file")) {
            for (k in TEXT_ARGS) if (hasCardData(a.optString(k))) return CARD_MSG
        }
        if (name in SCREEN_TOOLS && isFinancialApp(pkg)) {
            if (name == "type_text" && isAccountNumber(a.optString("text"))) return null
            return FIN_MSG
        }
        return null
    }

    fun cleanResult(name: String, out: String): String = if (name in REDACT_RESULTS) redact(out) else out
}
