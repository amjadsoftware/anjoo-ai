package com.anjoo.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.SystemClock
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * A natural, human-sounding voice from Gemini's speech model. Any failure returns false so the caller
 * can fall back to the phone's own voice.
 */
object GeminiVoice {

    private const val DEFAULT_MODEL = "gemini-2.5-flash-preview-tts"
    @Volatile private var track: AudioTrack? = null
    @Volatile private var stopFlag = false
    @Volatile private var failUntil = 0L

    fun enabled(ctx: Context): Boolean =
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean("human", true)

    /** Female voices offered in the picker: name to short description. */
    val FEMALE = listOf(
        "Leda" to "Leda · young and friendly",
        "Aoede" to "Aoede · light and breezy",
        "Kore" to "Kore · clear and confident",
        "Zephyr" to "Zephyr · bright and cheerful",
        "Sulafat" to "Sulafat · warm and soft",
        "Callirrhoe" to "Callirrhoe · easy-going",
        "Vindemiatrix" to "Vindemiatrix · gentle and calm"
    )

    fun voiceFor(ctx: Context): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        if (p.getString("voiceGender", "female") == "male") return "Orus"
        val v = p.getString("voiceName", "Leda") ?: "Leda"
        return if (FEMALE.any { it.first == v }) v else "Leda"
    }

    /** Removes markdown, links and emoji so the voice reads only natural words. */
    private fun clean(t: String): String = t
        .replace(Regex("```[\\s\\S]*?```"), " code block ")
        .replace(Regex("\\[([^\\]]+)]\\([^)]+\\)"), "$1")
        .replace(Regex("https?://\\S+"), " link ")
        .replace(Regex("[*_#`>~|]+"), " ")
        .replace(Regex("[\\u2190-\\u2BFF\\uD83C-\\uDBFF\\uDC00-\\uDFFF\\uFE0F\\u200D]"), " ")
        .replace(Regex("\\s+"), " ").trim()

    fun stop() {
        stopFlag = true
        try { track?.stop() } catch (e: Exception) {}
    }

    /** Splits a reply into a short first piece (so speech starts fast) and a few longer pieces. */
    private fun chunks(text: String): List<String> {
        val parts = Regex("[^.!?\\u06D4\\u061F\\n]+[.!?\\u06D4\\u061F]*").findAll(text).map { it.value.trim() }
            .filter { it.isNotEmpty() }.toList()
        if (parts.isEmpty()) return listOf(text)
        val out = ArrayList<String>()
        var i = 0
        var first = parts[0]
        i = 1
        while (first.length < 30 && i < parts.size) { first += " " + parts[i]; i++ }
        out.add(first)
        var cur = ""
        while (i < parts.size) {
            if (cur.isNotEmpty() && cur.length + parts[i].length > 260) { out.add(cur); cur = "" }
            cur = if (cur.isEmpty()) parts[i] else cur + " " + parts[i]
            i++
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }

    /** Speaks [text] and returns when playback has finished. Returns false if it could not start. */
    fun say(ctx: Context, text: String): Boolean {
        val prefs = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty() || !enabled(ctx)) return false
        if (SystemClock.elapsedRealtime() < failUntil) return false
        val model = prefs.getString("ttsModel", DEFAULT_MODEL)?.ifBlank { DEFAULT_MODEL } ?: DEFAULT_MODEL
        val voice = voiceFor(ctx)
        stopFlag = false
        val pieces = chunks(clean(text).take(1200).ifBlank { return false })
        val q = java.util.concurrent.LinkedBlockingQueue<Any>()
        val end = Any()
        val fail = Any()
        Thread {
            try {
                for (c in pieces) {
                    if (stopFlag) break
                    q.put(synth(key, model, voice, c))
                }
                q.put(end)
            } catch (e: Exception) { q.put(fail) }
        }.also { it.isDaemon = true }.start()
        var played = false
        while (true) {
            val item = q.poll(45, java.util.concurrent.TimeUnit.SECONDS) ?: fail
            if (item === end) break
            if (item === fail) {
                if (!played) { failUntil = SystemClock.elapsedRealtime() + 30000; return false }
                break
            }
            if (stopFlag) break
            @Suppress("UNCHECKED_CAST")
            val p = item as Pair<ByteArray, Int>
            play(p.first, p.second)
            played = true
        }
        return true
    }

    private fun synth(key: String, model: String, voice: String, text: String): Pair<ByteArray, Int> {
        val models = listOf(model, "gemini-2.5-flash-preview-tts", "gemini-2.5-pro-preview-tts").distinct()
        var last: Exception = java.io.IOException("tts")
        for (m in models) {
            for (attempt in 0..1) {
                try { return synthOnce(key, m, voice, text) } catch (e: Exception) {
                    last = e
                    try { Thread.sleep(400) } catch (x: InterruptedException) {}
                }
            }
        }
        throw last
    }

    private fun synthOnce(key: String, model: String, voice: String, text: String): Pair<ByteArray, Int> {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(
                JSONObject().put("text", "You are a real young woman in her twenties chatting with a close friend. Say the following exactly as written, with a soft, warm, smiling voice, natural breathing, small pauses at commas, gentle rises and falls, and real emotion that fits the words. Pronounce Urdu and Roman Urdu the way a native Pakistani speaker does, and English with a light natural accent. Never sound like a robot, a news reader, or an announcer: $text")
            ))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put(
                    "prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 40000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw java.io.IOException("tts $code")
        val inline = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData")
        val data = Base64.decode(inline.getString("data"), Base64.DEFAULT)
        val rate = Regex("rate=(\\d+)").find(inline.optString("mimeType", ""))?.groupValues?.get(1)?.toInt() ?: 24000
        return Pair(data, rate)
    }

    private fun play(pcm: ByteArray, rate: Int): Boolean {
        if (pcm.size < 2) return false
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = t
        t.write(pcm, 0, pcm.size)
        t.play()
        val frames = pcm.size / 2
        val deadline = SystemClock.elapsedRealtime() + frames * 1000L / rate + 2000
        while (!stopFlag && t.playbackHeadPosition < frames && SystemClock.elapsedRealtime() < deadline) {
            try { Thread.sleep(60) } catch (e: InterruptedException) { break }
        }
        try { t.stop() } catch (e: Exception) {}
        t.release()
        track = null
        return true
    }
}
