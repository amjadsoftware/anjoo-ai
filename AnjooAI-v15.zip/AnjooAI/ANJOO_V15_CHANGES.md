# Anjoo AI v15 – focused stability and UI update

## Changes in this update
- Removed the staged startup/loading messages from the chat timeline. The app opens directly into the conversation instead of displaying a fake boot/reboot-style sequence.
- Pauses the always-on microphone capture while Anjoo is speaking, including normal TTS and Gemini voice playback, then resumes listening after speech finishes.
- Adds a short post-speech quiet window to reduce echo and accidental self-transcription.
- Prevents the always-on microphone engine from restarting while the assistant is in speaking mode.

## Important scope note
This update improves the existing Android project; it does not merge the proprietary models or all internal features of ChatGPT, Claude, Gemini, Kimi, and DeepSeek. The app still uses its configured AI provider/API key and available Android permissions. A real-device test is needed for microphone echo, background service behavior, and visual fit.
