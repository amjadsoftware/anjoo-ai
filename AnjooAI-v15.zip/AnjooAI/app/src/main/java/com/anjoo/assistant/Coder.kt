package com.anjoo.assistant

import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * The coding brain. It plans the architecture first, writes a complete multi-file project, reviews it for
 * bugs, edits it later on request, and answers code questions with the whole project as context.
 * Projects are real folders of real files, so they can be opened, edited, previewed and exported as a zip.
 */
object Coder {

    const val SYSTEM = "You are Anjoo Code, a principal software engineer with deep expertise in every mainstream language and framework " +
        "(Kotlin/Android, Java, Python, JavaScript/TypeScript, HTML/CSS, Node, Flutter/Dart, C/C++, C#, Go, Rust, PHP, SQL, shell). " +
        "You write code the way a careful senior engineer ships it.\n" +
        "RULES:\n" +
        "1. COMPLETE and RUNNABLE: every file is fully written. Never use placeholders, TODO, '...', 'rest of code here' or pseudo-code.\n" +
        "2. ARCHITECTURE: sensible file structure, separation of concerns, small focused functions, clear names. Follow the given plan.\n" +
        "3. CORRECTNESS: before answering, mentally compile and run the code. Check imports, names that must match across files, " +
        "element ids between HTML and JS, async/await, null safety, types, off-by-one errors, resource cleanup.\n" +
        "4. ROBUST: validate input, handle errors and empty states, never crash on bad data. No hardcoded secrets.\n" +
        "5. SECURE: escape untrusted output, use parameterized queries, least privilege.\n" +
        "6. MODERN: use current stable APIs and idioms. Include the dependency/build file the project needs " +
        "(package.json, requirements.txt, build.gradle, pubspec.yaml ...) and a short README.md with how to run it.\n" +
        "7. WEB UI: semantic HTML, responsive mobile-first CSS, accessible, good spacing and typography, tasteful animation, " +
        "works offline without external libraries unless truly needed (cdnjs only).\n" +
        "8. ANDROID: Kotlin, minSdk 26, no deprecated calls, handle runtime permissions and lifecycle.\n" +
        "9. COMMENTS: short and meaningful, only where the reason is not obvious.\n" +
        "10. Choose the best language/stack yourself when it is not specified (websites and small tools: HTML/CSS/JS; scripts: Python).\n"

    const val FORMAT = "\nOUTPUT FORMAT (strict, never wrap the whole answer in code fences):\n" +
        "=== NOTES ===\n" +
        "2-5 short lines: what you built or changed, how to run it, anything the user must know. Same language style as the user (Roman Urdu or English).\n" +
        "=== FILE: relative/path/name.ext ===\n" +
        "the full raw content of that file (no code fences)\n" +
        "=== FILE: next/file.ext ===\n" +
        "...\n" +
        "Use forward slashes in paths. Put nothing between files except the markers.\n"

    private const val PLAN_SYS = "You are a software architect. Reply with at most 25 lines and NO code. " +
        "Line 1 must be: NAME: a short project name (2-4 words). Then: Stack, FILES (path - purpose, one per line), " +
        "KEY DESIGN DECISIONS, EDGE CASES TO HANDLE. Keep it practical and minimal but complete."

    private const val REVIEW_SYS = "You are a meticulous code reviewer and debugger. Mentally compile and run the whole project. " +
        "Look for: syntax errors, wrong or missing imports, names that do not match between files, undefined variables, " +
        "async/await mistakes, null errors, off-by-one errors, broken element ids between HTML and JS, missing dependencies, " +
        "logic bugs and security holes. Fix every REAL problem (do not rewrite for style). " +
        "Output ONLY the files you changed, each one complete, in the format below. If everything is already correct output exactly NO_CHANGES."

    private const val REVISE_RULES = "\nYou are modifying an existing project. Make the smallest correct change that fully satisfies the request " +
        "and keep everything else working. Output every file you change or add in FULL (never diffs or snippets). " +
        "To remove a file output a line like: === DELETE: path/name.ext ===\n"

    private const val ASK_SYS = "You are Anjoo Code, an expert pair-programmer. Explain, debug, review and compare approaches precisely. " +
        "Show code in fenced blocks with the language name, and give corrected complete snippets rather than vague advice. " +
        "Use the user's language style (Roman Urdu or English). Be concise but complete."

    class Out(val notes: String, val files: List<Pair<String, String>>, val deletes: List<String>)

    // ---------- storage ----------

    private fun root(ctx: Context) = File(ctx.filesDir, "projects").also { it.mkdirs() }
    private const val META = ".anjoo-meta.json"

    fun list(ctx: Context): List<File> =
        (root(ctx).listFiles()?.filter { it.isDirectory }?.toList() ?: emptyList()).sortedByDescending { it.lastModified() }

    fun latest(ctx: Context): File? = list(ctx).firstOrNull()

    private fun meta(dir: File): JSONObject =
        try { JSONObject(File(dir, META).readText(Charsets.UTF_8)) } catch (e: Exception) { JSONObject() }

    private fun saveMeta(dir: File, m: JSONObject) {
        try { File(dir, META).writeText(m.toString(), Charsets.UTF_8) } catch (e: Exception) {}
        dir.setLastModified(System.currentTimeMillis())
    }

    fun name(dir: File): String = meta(dir).optString("name", dir.name)

    fun history(dir: File): List<Pair<String, String>> {
        val h = meta(dir).optJSONArray("history") ?: return emptyList()
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until h.length()) {
            val o = h.optJSONObject(i) ?: continue
            out.add(Pair(o.optString("r"), o.optString("t")))
        }
        return out
    }

    private fun addHistory(dir: File, role: String, text: String) {
        val m = meta(dir)
        val h = m.optJSONArray("history") ?: JSONArray()
        h.put(JSONObject().put("r", role).put("t", text.take(6000)))
        // keep the file small
        val keep = JSONArray()
        val from = maxOf(0, h.length() - 60)
        for (i in from until h.length()) keep.put(h.get(i))
        m.put("history", keep)
        saveMeta(dir, m)
    }

    fun readFiles(dir: File): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        val all = dir.walkTopDown().filter { it.isFile && !it.name.startsWith(".anjoo") }.toList().sortedBy { it.path }
        for (f in all) {
            val rel = f.relativeTo(dir).path.replace('\\', '/')
            out[rel] = try { f.readText(Charsets.UTF_8) } catch (e: Exception) { "" }
        }
        return out
    }

    fun writeFile(dir: File, rel: String, content: String): Boolean {
        val p = safe(rel) ?: return false
        val f = File(dir, p)
        return try {
            f.parentFile?.mkdirs()
            f.writeText(content, Charsets.UTF_8)
            dir.setLastModified(System.currentTimeMillis())
            true
        } catch (e: Exception) { false }
    }

    private fun safe(p: String): String? {
        val parts = p.replace('\\', '/').split('/').map { it.trim() }.filter { it.isNotEmpty() && it != "." }
        if (parts.isEmpty() || parts.any { it == ".." } || parts.size > 7) return null
        if (parts.last().startsWith(".anjoo")) return null
        return parts.joinToString("/")
    }

    fun delete(dir: File) { try { dir.deleteRecursively() } catch (e: Exception) {} }

    private fun newDir(ctx: Context, name: String): File {
        val slug = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(24).ifEmpty { "project" }
        val d = File(root(ctx), slug + "-" + (System.currentTimeMillis() / 1000))
        d.mkdirs()
        return d
    }

    fun zip(dir: File): ByteArray {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            for ((rel, c) in readFiles(dir)) {
                z.putNextEntry(ZipEntry(rel))
                z.write(c.toByteArray(Charsets.UTF_8))
                z.closeEntry()
            }
        }
        return bo.toByteArray()
    }

    fun open(ctx: Context, dir: File?) {
        val i = Intent(ctx, CodeActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (dir != null) i.putExtra("project", dir.absolutePath)
        ctx.startActivity(i)
    }

    // ---------- parsing ----------

    private fun cleanFile(b: String): String {
        var t = b.trim('\n', '\r')
        var fenced = false
        if (t.trimStart().startsWith("```")) { t = t.trimStart().substringAfter("\n", ""); fenced = true }
        if (fenced) {
            val e = t.trimEnd()
            if (e.endsWith("```")) t = e.removeSuffix("```")
        }
        return t.trimEnd() + "\n"
    }

    fun parse(raw: String): Out {
        val re = Regex("(?m)^=== (FILE|DELETE): (.+?) ===[ \\t]*$")
        val ms = re.findAll(raw).toList()
        var notes = raw
        val files = ArrayList<Pair<String, String>>()
        val dels = ArrayList<String>()
        if (ms.isNotEmpty()) {
            notes = raw.substring(0, ms[0].range.first)
            for (i in ms.indices) {
                val m = ms[i]
                val end = if (i + 1 < ms.size) ms[i + 1].range.first else raw.length
                val body = raw.substring(m.range.last + 1, end)
                val path = m.groupValues[2].trim()
                if (m.groupValues[1] == "DELETE") dels.add(path) else files.add(Pair(path, cleanFile(body)))
            }
        }
        notes = notes.replace(Regex("(?m)^=== NOTES ===[ \\t]*$"), "").trim()
        return Out(notes, files, dels)
    }

    private fun apply(dir: File, o: Out): Int {
        var n = 0
        for ((p, c) in o.files) if (writeFile(dir, p, c)) n++
        for (p in o.deletes) {
            val s = safe(p) ?: continue
            try { File(dir, s).delete() } catch (e: Exception) {}
        }
        return n
    }

    private fun dump(files: Map<String, String>, cap: Int = 110000): String {
        val sb = StringBuilder()
        for ((p, c) in files) {
            if (sb.length + c.length > cap) { sb.append("=== FILE: ").append(p).append(" === (skipped, too large)\n"); continue }
            sb.append("=== FILE: ").append(p).append(" ===\n").append(c).append("\n")
        }
        return sb.toString()
    }

    // ---------- model calls ----------

    private fun gen(ctx: Context, system: String, user: String, max: Int): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val key = p.getString("key", "") ?: ""
        if (key.isEmpty()) throw IllegalStateException("Pehle Gemini key dalein.")
        val model = (p.getString("codeModel", "") ?: "").ifBlank { p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash" }
        return Gemini.plain(key, model, system, JSONArray().put(JSONObject().put("text", user)), max, 0.3)
    }

    private fun defaultName(language: String): String = when (language.lowercase()) {
        "python", "py" -> "main.py"
        "kotlin" -> "Main.kt"
        "java" -> "Main.java"
        "javascript", "js", "node" -> "index.js"
        "typescript", "ts" -> "index.ts"
        "c++", "cpp" -> "main.cpp"
        "c" -> "main.c"
        "go" -> "main.go"
        "rust" -> "main.rs"
        "php" -> "index.php"
        else -> "index.html"
    }

    /** Plans, writes and (optionally) reviews a brand-new project. Returns the folder and a short note. */
    fun build(ctx: Context, task: String, language: String, review: Boolean, note: (String) -> Unit): Pair<File, String> {
        val lang = language.ifBlank { "auto" }
        note("Planning the architecture...")
        val plan = gen(ctx, PLAN_SYS, "Language/stack: " + lang + "\nTask: " + task, 4000)
        val name = Regex("(?m)^NAME:\\s*(.+)$").find(plan)?.groupValues?.get(1)?.trim()?.take(40)?.ifBlank { null } ?: task.take(30)
        note("Writing the code...")
        val raw = gen(ctx, SYSTEM + FORMAT, "Language/stack: " + lang + "\nTask: " + task + "\n\nARCHITECTURE PLAN (follow it):\n" + plan, 32000)
        val out = parse(raw)
        var files = out.files
        if (files.isEmpty()) {
            val body = cleanFile(raw)
            if (body.isBlank()) throw IllegalStateException("Code nahi bana, dobara koshish karein.")
            files = listOf(Pair(defaultName(lang), body))
        }
        val dir = newDir(ctx, name)
        for ((p, c) in files) writeFile(dir, p, c)
        val m = JSONObject().put("name", name).put("language", lang).put("created", System.currentTimeMillis())
        saveMeta(dir, m)
        addHistory(dir, "u", task)
        var notes = out.notes.ifBlank { "Project tayyar hai: " + files.size + " file(s)." }
        if (review) {
            note("Reviewing for bugs...")
            try { notes += reviewPass(ctx, dir) } catch (e: Exception) {}
        }
        addHistory(dir, "a", notes)
        return Pair(dir, notes)
    }

    private fun reviewPass(ctx: Context, dir: File): String {
        val raw = gen(ctx, REVIEW_SYS + FORMAT, "Review this project:\n" + dump(readFiles(dir)), 32000)
        val o = parse(raw)
        if (o.files.isEmpty()) return ""
        val n = apply(dir, o)
        return if (n > 0) "\n(Review: " + n + " file mein bugs theek kiye.)" else ""
    }

    /** Changes an existing project according to the instruction. Returns a short note. */
    fun revise(ctx: Context, dir: File, instruction: String, note: (String) -> Unit): String {
        note("Reading the project...")
        val hist = history(dir).takeLast(6).joinToString("\n") { (if (it.first == "u") "USER: " else "ASSISTANT: ") + it.second.take(500) }
        note("Updating the code...")
        val raw = gen(
            ctx, SYSTEM + REVISE_RULES + FORMAT,
            "CURRENT PROJECT:\n" + dump(readFiles(dir)) + "\nRECENT CHAT:\n" + hist + "\n\nUSER REQUEST: " + instruction, 32000
        )
        val o = parse(raw)
        addHistory(dir, "u", instruction)
        if (o.files.isEmpty() && o.deletes.isEmpty()) {
            val msg = o.notes.ifBlank { "Koi badlav nahi hua. Request thori aur saaf likhein." }
            addHistory(dir, "a", msg)
            return msg
        }
        apply(dir, o)
        val msg = o.notes.ifBlank { "Update ho gaya: " + o.files.size + " file(s)." }
        addHistory(dir, "a", msg)
        return msg
    }

    /** Answers a coding question; the project (if any) is given as context. */
    fun ask(ctx: Context, dir: File?, question: String): String {
        val sb = StringBuilder()
        if (dir != null) {
            sb.append("PROJECT FILES:\n").append(dump(readFiles(dir), 90000)).append("\n")
            val hist = history(dir).takeLast(6).joinToString("\n") { (if (it.first == "u") "USER: " else "ASSISTANT: ") + it.second.take(500) }
            if (hist.isNotBlank()) sb.append("RECENT CHAT:\n").append(hist).append("\n\n")
        }
        sb.append("QUESTION: ").append(question)
        val ans = gen(ctx, ASK_SYS, sb.toString(), 8000)
        if (dir != null) { addHistory(dir, "u", question); addHistory(dir, "a", ans) }
        return ans.ifBlank { "Jawab nahi mila, dobara poochein." }
    }

    // ---------- entry points for the voice assistant ----------

    fun buildAndOpen(ctx: Context, task: String, language: String, review: Boolean): String {
        return try {
            val (dir, notes) = build(ctx, task, language, review) {}
            open(ctx, dir)
            "Project '" + name(dir) + "' ban gaya (" + readFiles(dir).size + " files) aur Code Studio mein khol diya. " + notes.take(300)
        } catch (e: Exception) {
            "Code nahi ban saka: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    fun editLatest(ctx: Context, instruction: String): String {
        val dir = latest(ctx) ?: return "Abhi koi project nahi hai. Pehle write_code se banayein."
        return try {
            val msg = revise(ctx, dir, instruction) {}
            open(ctx, dir)
            "Project '" + name(dir) + "' update ho gaya. " + msg.take(300)
        } catch (e: Exception) {
            "Badlav nahi ho saka: " + (e.message ?: e.javaClass.simpleName)
        }
    }
}
