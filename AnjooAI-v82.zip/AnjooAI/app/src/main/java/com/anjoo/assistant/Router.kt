package com.anjoo.assistant

import android.content.SharedPreferences
import org.json.JSONException
import org.json.JSONObject

/** One AI model Anjoo can talk to: which company, which key, which model. */
class Cand(val pv: Provider, val key: String, val model: String) {
    val id: String get() = pv.id + "|" + model
    val label: String get() = pv.id + " / " + model
}

/**
 * Picks which model answers, and learns which ones work.
 *
 * - The AI chosen in Settings goes first.
 * - If it fails (limit finished, wrong key, model gone, server down, no tool support) the next free model is tried,
 *   best first: models that worked recently and answered fast rank higher, models that failed rest for a while.
 * - A model that saved the day is kept for 10 minutes ("sticky"), so every message does not first fail on the
 *   broken one. After that the chosen AI gets another chance.
 * - Everything it learns (who worked, how fast, who failed) is saved on the phone, so after closing the app the
 *   best connection is still the one used. The same notes go into backups and into the keys file.
 * - Only FREE models are used as backups, and only for companies that have a saved key. Nothing paid is picked by itself.
 */
object Router {

    /** Free backup models, best first (company id, model). Order is the starting rank; results then adjust it. */
    private val POOL = listOf(
        "groq" to "openai/gpt-oss-120b",
        "gemini" to "gemini-3.8-flash",
        "gemini" to "gemini-3.6-flash",
        "groq" to "qwen/qwen3.8-27b",
        "groq" to "openai/gpt-oss-20b",
        "openrouter" to "nvidia/nemotron-3-super-120b-a12b:free",
        "openrouter" to "openai/gpt-oss-120b:free",
        "openrouter" to "qwen/qwen3-next-80b-a3b-instruct:free",
        "gemini" to "gemini-3.5-flash-lite",
        "gemini" to "gemini-3.1-flash-lite",
        "openrouter" to "openrouter/free",
        "openrouter" to "meta-llama/llama-3.3-70b-instruct:free"
    )

    private class Stat {
        var ok = 0
        var fail = 0
        var consecFail = 0
        var avgMs = 0L
        var coolUntil = 0L
    }

    private val stats = HashMap<String, Stat>()
    @Volatile private var stickyId: String? = null
    @Volatile private var stickyUntil = 0L
    private const val STICKY_MS = 10L * 60 * 1000
    private const val MAX_TRIES = 6

    /** Text for the screen, e.g. "groq / openai/gpt-oss-120b". Empty until the first answer. */
    @Volatile var lastUsed: String = ""


    // ------------------------------------------------------------ memory (kept on the phone)

    @Volatile private var loaded = false

    /** Reads the saved notes once per app start. Called from Providers.load. */
    @Synchronized fun load(p: SharedPreferences) {
        if (loaded) return
        loaded = true
        importJson(p.getString("routerStats", "") ?: "")
    }

    @Synchronized private fun save() {
        val p = Providers.prefsRef ?: return
        try { p.edit().putString("routerStats", exportJson()).apply() } catch (e: Exception) {}
    }

    @Synchronized fun exportJson(): String {
        val st = JSONObject()
        for ((id, s) in stats) {
            if (s.ok + s.fail == 0) continue
            st.put(id, JSONObject().put("ok", s.ok).put("fail", s.fail).put("cf", s.consecFail).put("ms", s.avgMs).put("cool", s.coolUntil))
        }
        return JSONObject().put("stats", st).put("sticky", stickyId ?: "").put("until", stickyUntil).put("last", lastUsed).toString()
    }

    @Synchronized fun importJson(text: String) {
        if (text.isBlank()) return
        try {
            val root = JSONObject(text)
            root.optJSONObject("stats")?.let { st ->
                val it = st.keys()
                while (it.hasNext()) {
                    val id = it.next()
                    val o = st.getJSONObject(id)
                    val s = stat(id)
                    s.ok = o.optInt("ok"); s.fail = o.optInt("fail"); s.consecFail = o.optInt("cf")
                    s.avgMs = o.optLong("ms"); s.coolUntil = o.optLong("cool")
                }
            }
            stickyId = root.optString("sticky", "").ifEmpty { null }
            stickyUntil = root.optLong("until")
            lastUsed = root.optString("last", "")
        } catch (e: Exception) { /* bad notes are ignored; they build up again */ }
    }

    // ------------------------------------------------------------ report ("kaun sa model best chal raha hai?")

    /** How strong each model is, as a rough guide (by size and class, not a test). */
    private val STRENGTH = mapOf(
        "groq|openai/gpt-oss-120b" to "bohat taqatwar, tez",
        "groq|openai/gpt-oss-20b" to "darmiyana, bohat tez",
        "groq|qwen/qwen3.8-27b" to "darmiyana se behtar",
        "gemini|gemini-3.8-flash" to "bohat taqatwar (Google ka sab se samajhdar Flash)",
        "gemini|gemini-3.6-flash" to "taqatwar",
        "gemini|gemini-3.5-flash-lite" to "halka aur tez",
        "gemini|gemini-3.1-flash-lite" to "halka aur tez",
        "gemini|gemini-2.5-pro" to "bohat taqatwar, thora sust",
        "gemini|gemini-2.5-flash" to "taqatwar",
        "openrouter|nvidia/nemotron-3-super-120b-a12b:free" to "taqatwar",
        "openrouter|nvidia/nemotron-3-ultra-550b-a55b:free" to "bohat taqatwar, bhari",
        "openrouter|openai/gpt-oss-120b:free" to "taqatwar",
        "openrouter|qwen/qwen3-next-80b-a3b-instruct:free" to "taqatwar",
        "openrouter|meta-llama/llama-3.3-70b-instruct:free" to "taqatwar",
        "openrouter|openrouter/free" to "badalta rehta hai (jo free model khali ho)"
    )

    private class Row(val c: Cand, val rank: Int, val chosen: Boolean)

    /** A plain-text status for the chat or voice: who works, how fast, how strong. */
    @Synchronized fun report(): String {
        val p = Providers.prefsRef ?: return "Abhi models ki maloomat nahi hai. Pehle Settings me key daalo."
        val now = System.currentTimeMillis()
        val active = Providers.active
        val chosen = Cand(active, Providers.savedKey(p, active.id), Providers.savedModel(p, active.id))
        val rows = ArrayList<Row>()
        if (chosen.key.isNotBlank()) rows.add(Row(chosen, 3, true))
        POOL.forEachIndexed { i, (pid, m) ->
            val k = Providers.savedKey(p, pid)
            if (k.isNotBlank() && !(pid == chosen.pv.id && m == chosen.model)) rows.add(Row(Cand(Providers.byId(pid), k, m), i, false))
        }
        if (rows.isEmpty()) return "Koi key saved nahi hai. Settings me Groq, Gemini ya OpenRouter ki free key daalo (ya Keys file import karo)."

        fun state(r: Row): Int { // 0 working, 1 untested, 2 resting
            val s = stat(r.c.id)
            return if (s.coolUntil > now) 2 else if (s.ok + s.fail == 0) 1 else 0
        }
        val sorted = rows.sortedWith(compareBy<Row>({ state(it) }, { score(it.rank, it.c) }))
        val sb = StringBuilder("📊 Models ka haal\n")
        val cur = stickyId?.takeIf { now < stickyUntil }
        val nowOn = rows.firstOrNull { it.c.id == cur }?.c?.label ?: lastUsed
        if (nowOn.isNotBlank()) sb.append("Abhi jawab de raha hai: ").append(nowOn).append('\n')
        sb.append('\n')
        var shownBest = false
        for (r in sorted) {
            val s = stat(r.c.id)
            val total = s.ok + s.fail
            val icon = when (state(r)) { 0 -> if (s.consecFail == 0) "✅" else "⚠️"; 2 -> "⏸️"; else -> "⚪" }
            sb.append(icon).append(' ').append(r.c.pv.id).append(" / ").append(r.c.model)
            if (r.chosen) sb.append("  (tumhara chuna hua)")
            if (state(r) == 0 && !shownBest && s.consecFail == 0) { sb.append("  🏆 sab se behtar"); shownBest = true }
            sb.append('\n')
            sb.append("   taqat: ").append(STRENGTH[r.c.id] ?: "pata nahi").append('\n')
            when (state(r)) {
                1 -> sb.append("   abhi tak test nahi hua\n")
                else -> {
                    sb.append("   kaam: ").append(s.ok).append(" me se ").append(total).append(" baar theek")
                    if (s.ok > 0) sb.append(", aam jawab ").append("%.1f".format(s.avgMs / 1000.0)).append(" sec")
                    sb.append('\n')
                    if (state(r) == 2) {
                        val mins = ((s.coolUntil - now) / 60000L).toInt() + 1
                        sb.append("   aaram par (lagbhag ").append(mins).append(" minute, limit ya masla)\n")
                    }
                }
            }
        }
        val missing = listOf("groq", "gemini", "openrouter").filter { Providers.savedKey(p, it).isBlank() }
        if (missing.isNotEmpty()) sb.append("\nKey nahi hai: ").append(missing.joinToString(", ")).append(" (inki free key daal do to backup aur mazboot ho)")
        sb.append("\n\n✅ chal raha  ⚠️ haal hi me fail  ⏸️ aaram par  ⚪ abhi test nahi hua")
        return sb.toString().trim()
    }

    private val ASK_ABOUT = Regex("(model|models|connection|connections|provider|groq|gemini|openrouter|\\bkeys?\\b)")
    private val ASK_STATUS = Regex("(kon|kaun|konsa|kaunsa|kon sa|kaun sa|which|best|behtar|behtreen|status|strong|taqat|tagat|chal raha|chal rahi|chal rahe|working|haal|report|performance|kitna|kitne)")
    private val ASK_NOT = Regex("(code|coding|project|website|python|kotlin|likh|bana|script|app |function)")

    /** True when the message is asking how the models/connections are doing (not asking for help using one). */
    fun asksStatus(text: String): Boolean {
        val t = text.lowercase().trim()
        if (t.length > 110 || t.contains("```")) return false
        if (t == "model status" || t == "models status" || t == "connection status") return true
        return ASK_ABOUT.containsMatchIn(t) && ASK_STATUS.containsMatchIn(t) && !ASK_NOT.containsMatchIn(t)
    }

    @Synchronized private fun stat(id: String) = stats.getOrPut(id) { Stat() }

    private fun cooling(c: Cand, now: Long) = stat(c.id).coolUntil > now

    private fun score(rank: Int, c: Cand): Double {
        val s = stat(c.id)
        val total = s.ok + s.fail
        var v = rank.toDouble()
        if (total > 0) v += 6.0 * s.fail / total
        if (s.ok >= 2) v += s.avgMs / 2000.0
        if (s.ok >= 3 && s.consecFail == 0) v -= 1.0
        return v
    }

    /** The models to try, in order, for a request whose chosen model is [primary]. */
    @Synchronized fun plan(primary: Cand): List<Cand> {
        val prefs = Providers.prefsRef
        val now = System.currentTimeMillis()
        val pool = ArrayList<Pair<Int, Cand>>()
        if (prefs != null) {
            POOL.forEachIndexed { i, (pid, m) ->
                val k = Providers.savedKey(prefs, pid)
                if (k.isNotBlank() && !(pid == primary.pv.id && m == primary.model)) pool.add(i to Cand(Providers.byId(pid), k, m))
            }
        }
        // A chosen model that fails more often than it works (seen several times) loses its automatic first place.
        val ps = stat(primary.id)
        val demoted = (ps.ok + ps.fail) >= 4 && ps.fail * 2 >= (ps.ok + ps.fail)
        if (demoted) pool.add(3 to primary)
        val rest = pool.sortedBy { (i, c) -> score(i, c) }.map { it.second }
        val all = ArrayList<Cand>()
        if (demoted) all.addAll(rest) else { all.add(primary); all.addAll(rest) }
        val sticky = stickyId?.takeIf { now < stickyUntil }?.let { sid -> all.firstOrNull { it.id == sid } }
        val healthy = all.filter { !cooling(it, now) }
        val resting = all.filter { cooling(it, now) }
        val ordered = ArrayList<Cand>()
        if (sticky != null && !cooling(sticky, now)) ordered.add(sticky)
        for (c in healthy) if (c !== sticky) ordered.add(c)
        // primary first among the healthy ones when there is no sticky choice
        if (!demoted && (sticky == null || cooling(sticky, now))) {
            if (ordered.remove(primary)) ordered.add(0, primary)
        }
        ordered.addAll(resting)
        return ordered.take(MAX_TRIES)
    }

    @Synchronized fun success(c: Cand, primary: Cand, ms: Long) {
        val s = stat(c.id)
        s.ok++; s.consecFail = 0; s.coolUntil = 0L
        s.avgMs = if (s.avgMs == 0L) ms else (s.avgMs * 7 + ms * 3) / 10
        if (c.id == primary.id) { stickyId = null } else { stickyId = c.id; stickyUntil = System.currentTimeMillis() + STICKY_MS }
        lastUsed = c.label
        save()
    }

    @Synchronized fun failure(c: Cand, e: Exception) {
        val s = stat(c.id)
        s.fail++; s.consecFail++
        val code = (e as? ApiException)?.code ?: 0
        val base = when (code) {
            401, 403, 404 -> 30L * 60_000          // wrong key / model gone: rest a long time
            400, 422 -> 5L * 60_000                // this model could not handle the request
            429 -> 60_000L                         // limit reached: rest, longer each time in a row
            else -> 45_000L                        // server down or no network
        }
        val mult = if (code == 429 || code == 0 || code >= 500) 1L shl minOf(s.consecFail - 1, 5) else 1L
        s.coolUntil = System.currentTimeMillis() + minOf(base * mult, 30L * 60_000)
        if (stickyId == c.id) stickyId = null
        save()
    }

    /** True when another model is worth trying after this error. [badRequests] counts earlier 400/422 in this request. */
    fun worthRetrying(e: Exception, badRequests: Int): Boolean {
        if (e is CancelledException) return false
        if (e is ApiException) return if (e.code == 400 || e.code == 422) badRequests < 2 else true
        return e is java.io.IOException || e is JSONException
    }
}
