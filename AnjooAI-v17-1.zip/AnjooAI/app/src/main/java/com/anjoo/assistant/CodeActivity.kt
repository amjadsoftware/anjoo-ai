package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream

/**
 * Code Studio: build a multi-file project from an idea, edit it by asking, ask questions about it,
 * read and copy every file, preview web projects, and export everything as a zip.
 */
class CodeActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var th: CyberTheme
    private var dir: File? = null
    private var cur: String? = null
    private var busy = false
    private var web: WebView? = null

    private lateinit var titleTv: TextView
    private lateinit var status: TextView
    private lateinit var tabs: LinearLayout
    private lateinit var area: FrameLayout
    private lateinit var logBox: LinearLayout
    private lateinit var logScroll: ScrollView
    private lateinit var codeWrap: LinearLayout
    private lateinit var codeText: TextView
    private lateinit var codeName: TextView
    private lateinit var input: EditText
    private lateinit var goBtn: Button
    private lateinit var thinkBtn: Button

    private fun toggleThink() {
        val p = getSharedPreferences("anjoo", MODE_PRIVATE)
        p.edit().putBoolean("codeThink", !p.getBoolean("codeThink", true)).apply()
        refreshThink()
    }

    private fun refreshThink() {
        thinkBtn.text = if (getSharedPreferences("anjoo", MODE_PRIVATE).getBoolean("codeThink", true)) "Deep think: ON" else "Deep think: OFF"
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int, r: Int) = GradientDrawable().apply {
        setColor(fill); setStroke(dp(1), stroke); cornerRadius = r.toFloat()
    }

    private fun btn(t: String, a: () -> Unit): Button = Button(this).apply {
        text = t; isAllCaps = false; textSize = 11f; setTextColor(th.accent)
        background = box(th.surface, th.accent, dp(8))
        minWidth = 0; minimumWidth = 0; setPadding(dp(10), 0, dp(10), 0)
        layoutParams = LinearLayout.LayoutParams(-2, dp(36)).apply { leftMargin = dp(5) }
        setOnClickListener { a() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        th = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        try { window.statusBarColor = th.bg } catch (e: Exception) {}

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(th.bg)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        titleTv = TextView(this).apply {
            text = "Code Studio"; setTextColor(th.accent); textSize = 17f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        bar.addView(titleTv, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(btn("Projects") { pickProject() })
        bar.addView(btn("New") { newProject() })
        thinkBtn = btn("") { toggleThink() }
        bar.addView(thinkBtn)
        bar.addView(btn("Run") { preview() })
        bar.addView(btn("Zip") { exportZip() })
        bar.addView(btn("Del") { deleteProject() })
        root.addView(bar)

        status = TextView(this).apply { setTextColor(th.muted); textSize = 11f; typeface = Typeface.MONOSPACE; setPadding(0, dp(4), 0, dp(4)) }
        root.addView(status)

        val tabScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tabScroll.addView(tabs)
        root.addView(tabScroll, LinearLayout.LayoutParams(-1, dp(44)))

        area = FrameLayout(this)
        logBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(2), dp(2), dp(2), dp(2)) }
        logScroll = ScrollView(this).apply { addView(logBox) }

        codeName = TextView(this).apply { setTextColor(th.accent); typeface = Typeface.MONOSPACE; textSize = 12f }
        val crow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(2), 0, dp(4)) }
        crow.addView(codeName, LinearLayout.LayoutParams(0, -2, 1f))
        crow.addView(btn("Edit") { editFile() })
        crow.addView(btn("Copy") { copy(codeText.text.toString()) })
        crow.addView(btn("Share") { share(codeText.text.toString()) })
        codeText = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(th.ink); setTextIsSelectable(true)
            setPadding(dp(8), dp(6), dp(8), dp(6))
        }
        val hs = HorizontalScrollView(this).apply { addView(codeText) }
        val vs = ScrollView(this).apply { addView(hs); setBackgroundColor(Color.argb(120, 0, 0, 0)) }
        codeWrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        codeWrap.addView(crow)
        codeWrap.addView(vs, LinearLayout.LayoutParams(-1, 0, 1f))

        area.addView(logScroll, FrameLayout.LayoutParams(-1, -1))
        area.addView(codeWrap, FrameLayout.LayoutParams(-1, -1))
        root.addView(area, LinearLayout.LayoutParams(-1, 0, 1f))

        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, 0) }
        input = EditText(this).apply {
            hint = "Kya banana hai? / What should I build or change?"
            setHintTextColor(th.muted); setTextColor(th.ink); textSize = 14f
            background = box(th.surface, th.accent, dp(10))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            maxLines = 5
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or
                android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        row.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(btn("Ask") { go(0) })
        goBtn = btn("Build") { go(1) }
        row.addView(goBtn)
        root.addView(row)

        setContentView(root)
        refreshThink()
        welcome()
        handle(intent)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        handle(i)
    }

    private fun handle(i: Intent?) {
        val p = i?.getStringExtra("project") ?: return
        val d = File(p)
        if (d.isDirectory) openProject(d)
    }

    // ---------- state ----------

    private fun welcome() {
        logBox.removeAllViews()
        addLog("a", "Assalam o alaikum! Main Code Studio hoon.\n\n" +
            "BUILD: likhein ya bolein kya banana hai (website, app, script, game...). Main pehle plan banata hoon, phir poora multi-file project likhta hoon aur bugs check karta hoon.\n" +
            "EDIT: project khulne ke baad likhein 'dark mode lagao', 'login page add karo' - main files badal dunga.\n" +
            "ASK: koi bhi code sawal ya bug poochein, main project dekh kar jawab dunga.\n" +
            "Files: oopar tabs mein har file dekhein, copy/share/edit karein, Run se web preview, Zip se poora project save.")
    }

    private fun say(s: String) { status.text = s }

    private fun setBusy(b: Boolean) {
        busy = b
        goBtn.isEnabled = !b
        goBtn.alpha = if (b) 0.4f else 1f
        if (!b) goBtn.text = if (dir == null) "Build" else "Edit"
    }

    private fun newProject() {
        if (busy) return
        dir = null; cur = null
        titleTv.text = "Code Studio"
        welcome(); refreshTabs(); show(null)
        goBtn.text = "Build"
        say("")
    }

    private fun openProject(d: File) {
        dir = d; cur = null
        titleTv.text = Coder.name(d)
        logBox.removeAllViews()
        val h = Coder.history(d)
        if (h.isEmpty()) addLog("a", "Project khul gaya. Badlav likhein ya sawal poochein.")
        for ((r, t) in h) addLog(r, t)
        addProjectCard(d, false)
        goBtn.text = "Edit"
        refreshTabs(); show(null)
        say(Coder.readFiles(d).size.toString() + " files")
    }

    private fun pickProject() {
        val ps = Coder.list(this)
        if (ps.isEmpty()) { Toast.makeText(this, "Abhi koi project nahi. Kuch banane ko bolein.", Toast.LENGTH_SHORT).show(); return }
        AlertDialog.Builder(this).setTitle("Projects")
            .setItems(ps.map { Coder.name(it) }.toTypedArray()) { _, i -> if (!busy) openProject(ps[i]) }.show()
    }

    private fun deleteProject() {
        val d = dir ?: return
        AlertDialog.Builder(this).setMessage("Delete project '" + Coder.name(d) + "'?")
            .setPositiveButton("Delete") { _, _ -> Coder.delete(d); newProject() }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- tabs and viewers ----------

    private fun refreshTabs() {
        tabs.removeAllViews()
        fun tab(label: String, sel: Boolean, a: () -> Unit) {
            val t = TextView(this).apply {
                text = label; textSize = 12f; typeface = Typeface.MONOSPACE
                setTextColor(if (sel) th.bg else th.accent)
                background = box(if (sel) th.accent else th.surface, th.accent, dp(8))
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setOnClickListener { a() }
            }
            tabs.addView(t, LinearLayout.LayoutParams(-2, dp(34)).apply { rightMargin = dp(5); topMargin = dp(4) })
        }
        tab("CHAT", cur == null) { show(null) }
        val d = dir ?: return
        for (p in Coder.readFiles(d).keys) tab(p, cur == p) { show(p) }
    }

    private fun show(path: String?) {
        cur = path
        web?.visibility = View.GONE
        if (path == null) {
            logScroll.visibility = View.VISIBLE
            codeWrap.visibility = View.GONE
        } else {
            val d = dir
            val text = if (d != null) try { File(d, path).readText(Charsets.UTF_8) } catch (e: Exception) { "File nahi khuli." } else ""
            codeName.text = path
            codeText.text = text
            logScroll.visibility = View.GONE
            codeWrap.visibility = View.VISIBLE
        }
        refreshTabs()
    }

    private fun editFile() {
        val d = dir ?: return
        val p = cur ?: return
        editFileDialog(d, p) {
            show(p)
            if (web?.visibility == View.VISIBLE) preview()
        }
    }

    private fun editFileDialog(d: File, p: String, saved: () -> Unit) {
        val et = EditText(this).apply {
            setText(try { File(d, p).readText(Charsets.UTF_8) } catch (e: Exception) { "" })
            typeface = Typeface.MONOSPACE; textSize = 12f
            setHorizontallyScrolling(true); gravity = Gravity.TOP or Gravity.START
            minLines = 12
        }
        AlertDialog.Builder(this).setTitle(p).setView(et)
            .setPositiveButton("Save") { _, _ ->
                Coder.writeFile(d, p, et.text.toString())
                saved()
            }
            .setNegativeButton("Cancel", null).show()
    }

    private fun copy(t: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Anjoo", t))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun share(t: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), "Share"))
    }

    // ---------- chat log ----------

    private fun addLog(role: String, text: String, thought: String = "") {
        val user = role == "u"
        val v = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = box(if (user) th.user else th.surface, if (user) th.user else faint(), dp(12))
        }
        if (user) {
            v.addView(TextView(this).apply { this.text = text; setTextColor(th.ink); textSize = 14.5f; setTextIsSelectable(true) })
        } else {
            if (thought.isNotBlank()) {
                val body = TextView(this).apply {
                    this.text = thought; textSize = 12.5f; setTextColor(th.muted); visibility = View.GONE
                    setPadding(dp(8), dp(2), dp(4), dp(8))
                }
                v.addView(TextView(this).apply {
                    this.text = "Thought process  ▸"; textSize = 12f; setTextColor(th.muted); setPadding(0, dp(2), 0, dp(6))
                    setOnClickListener {
                        val open = body.visibility == View.VISIBLE
                        body.visibility = if (open) View.GONE else View.VISIBLE
                        this.text = if (open) "Thought process  ▸" else "Thought process  ▾"
                    }
                })
                v.addView(body)
            }
            v.addView(Md.render(this, text, th))
        }
        logBox.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun faint() = Color.argb(70, 128, 128, 128)

    /** A project card inside the chat: file list, code viewer and live preview, all without leaving the chat. */
    private fun addProjectCard(d: File, open: Boolean) {
        val files = Coder.readFiles(d)
        if (files.isEmpty()) return
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = box(th.surface, th.accent, dp(12))
            setPadding(dp(10), dp(8), dp(10), dp(10))
        }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(TextView(this).apply {
            this.text = Coder.name(d) + "  ·  " + files.size + " files"; setTextColor(th.accent)
            textSize = 13.5f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val codeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val prevBox = FrameLayout(this).apply { visibility = View.GONE }
        var wv: WebView? = null
        val name = files.keys.firstOrNull { it.equals("index.html", true) }
            ?: files.keys.firstOrNull { it.equals("README.md", true) } ?: files.keys.first()
        val codeText2 = TextView(this).apply {
            typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(th.ink); setTextIsSelectable(true)
            setPadding(dp(10), dp(6), dp(10), dp(10))
        }
        var curName = name
        fun load(n: String) {
            curName = n
            codeText2.text = try { File(d, n).readText(Charsets.UTF_8) } catch (e: Exception) { "File nahi khuli." }
        }
        val fileRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (n in files.keys) {
            fileRow.addView(TextView(this).apply {
                this.text = n; textSize = 11.5f; typeface = Typeface.MONOSPACE; setTextColor(th.accent)
                background = box(Color.TRANSPARENT, faint(), dp(8)); setPadding(dp(9), dp(5), dp(9), dp(5))
                setOnClickListener { load(n) }
            }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        }
        codeBox.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(fileRow) })
        val hsv = HorizontalScrollView(this).apply { addView(codeText2) }
        val vsv = ScrollView(this).apply {
            addView(hsv); setBackgroundColor(Color.argb(140, 0, 0, 0))
            setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
        }
        codeBox.addView(vsv, LinearLayout.LayoutParams(-1, dp(300)).apply { topMargin = dp(6) })
        val bar = LinearLayout(this).apply { gravity = Gravity.END }
        bar.addView(TextView(this).apply {
            this.text = "Copy file"; textSize = 12f; setTextColor(th.accent); setPadding(dp(8), dp(8), dp(8), dp(4))
            setOnClickListener { copy(codeText2.text.toString()) }
        })
        bar.addView(TextView(this).apply {
            this.text = "Edit"; textSize = 12f; setTextColor(th.accent); setPadding(dp(8), dp(8), dp(8), dp(4))
            setOnClickListener { editFileDialog(d, curName) { load(curName) } }
        })
        codeBox.addView(bar)
        load(name)

        fun showCode() { codeBox.visibility = if (codeBox.visibility == View.VISIBLE) View.GONE else View.VISIBLE; prevBox.visibility = View.GONE }
        fun showPrev() {
            val entry = if (files.keys.any { it == "index.html" }) "index.html" else files.keys.firstOrNull { it.endsWith(".html") }
            if (entry == null) { Toast.makeText(this, "Preview sirf web (HTML) projects ke liye hai.", Toast.LENGTH_SHORT).show(); return }
            if (prevBox.visibility == View.VISIBLE) { prevBox.visibility = View.GONE; return }
            if (wv == null) {
                val w = projectWebView(d)
                w.setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
                w.loadUrl("https://app.local/" + entry)
                prevBox.addView(w, FrameLayout.LayoutParams(-1, -1))
                wv = w
            } else wv?.reload()
            codeBox.visibility = View.GONE
            prevBox.visibility = View.VISIBLE
        }
        top.addView(btn("Preview") { showPrev() })
        top.addView(btn("Code") { showCode() })
        card.addView(top)
        card.addView(codeBox, LinearLayout.LayoutParams(-1, -2))
        card.addView(prevBox, LinearLayout.LayoutParams(-1, dp(420)).apply { topMargin = dp(6) })
        logBox.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        if (open) {
            if (files.keys.any { it.endsWith(".html") }) showPrev() else showCode()
        }
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun mime(n: String): String = when (n.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "css" -> "text/css"
        "js", "mjs" -> "application/javascript"
        "json" -> "application/json"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "gif" -> "image/gif"
        "webp" -> "image/webp"
        else -> "text/plain"
    }

    /** A WebView that serves the project's files from https://app.local/ (so css/js/images link up). */
    private fun projectWebView(base: File): WebView {
        val wv = WebView(this)
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.setBackgroundColor(Color.WHITE)
        wv.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val u = request?.url ?: return null
                if (u.host != "app.local") return null
                val f = File(base, (u.path ?: "").trimStart('/'))
                return try {
                    if (f.isFile && f.canonicalPath.startsWith(base.canonicalPath)) WebResourceResponse(mime(f.name), "UTF-8", FileInputStream(f))
                    else WebResourceResponse("text/plain", "UTF-8", 404, "Not Found", emptyMap(), ByteArrayInputStream(ByteArray(0)))
                } catch (e: Exception) { null }
            }
        }
        return wv
    }

    // ---------- work ----------

    private fun go(kind: Int) {
        val t = input.text.toString().trim()
        if (t.isEmpty() || busy) return
        input.setText("")
        addLog("u", t)
        if (cur != null) show(null)
        setBusy(true)
        say("Working...")
        val d = dir
        val deep = getSharedPreferences("anjoo", MODE_PRIVATE).getBoolean("codeThink", true)
        val thoughts = StringBuilder()
        Thread {
            try {
                if (kind == 0) {
                    val ans = Coder.ask(this, d, t, deep, { tt -> thoughts.append(tt).append("\n") })
                    ui.post { addLog("a", ans, thoughts.toString().trim()); say(""); setBusy(false) }
                } else if (d == null) {
                    val r = Coder.build(this, t, "auto", true, deep, { tt -> thoughts.append(tt).append("\n\n") }) { s -> ui.post { say(s) } }
                    ui.post {
                        dir = r.first
                        titleTv.text = Coder.name(r.first)
                        addLog("a", r.second, thoughts.toString().trim())
                        addProjectCard(r.first, true)
                        say(Coder.readFiles(r.first).size.toString() + " files ready")
                        setBusy(false); refreshTabs()
                    }
                } else {
                    val notes = Coder.revise(this, d, t, deep, { tt -> thoughts.append(tt).append("\n\n") }) { s -> ui.post { say(s) } }
                    ui.post {
                        addLog("a", notes, thoughts.toString().trim())
                        addProjectCard(d, true)
                        say("Updated")
                        setBusy(false)
                        if (cur != null && !File(d, cur!!).exists()) cur = null
                        refreshTabs()
                        if (web?.visibility == View.VISIBLE) preview()
                    }
                }
            } catch (e: Exception) {
                ui.post { addLog("a", "Error: " + (e.message ?: e.javaClass.simpleName)); say(""); setBusy(false) }
            }
        }.start()
    }

    // ---------- preview and export ----------

    private fun preview() {
        val d = dir
        if (d == null) { Toast.makeText(this, "Pehle project banayein.", Toast.LENGTH_SHORT).show(); return }
        val files = Coder.readFiles(d).keys
        val entry = if ("index.html" in files) "index.html" else files.firstOrNull { it.endsWith(".html") }
        if (entry == null) { Toast.makeText(this, "Preview sirf web (HTML) projects ke liye hai.", Toast.LENGTH_LONG).show(); return }
        val w = web ?: projectWebView(d).also { area.addView(it, FrameLayout.LayoutParams(-1, -1)); web = it }
        logScroll.visibility = View.GONE
        codeWrap.visibility = View.GONE
        w.visibility = View.VISIBLE
        w.loadUrl("https://app.local/" + entry)
        say("Preview: " + entry)
    }

    private fun exportZip() {
        val d = dir
        if (d == null) { Toast.makeText(this, "Pehle project banayein.", Toast.LENGTH_SHORT).show(); return }
        val slug = Coder.name(d).lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "project" }
        try {
            startActivityForResult(
                Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/zip").putExtra(Intent.EXTRA_TITLE, "$slug.zip"), 41
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Zip save nahi ho saka.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 41 || res != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        val d = dir ?: return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(Coder.zip(d)) }
            Toast.makeText(this, "Zip save ho gaya.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Zip save nahi ho saka.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onBackPressed() {
        val w = web
        if (w != null && w.visibility == View.VISIBLE) { show(cur); return }
        if (cur != null) { show(null); return }
        super.onBackPressed()
    }
}
