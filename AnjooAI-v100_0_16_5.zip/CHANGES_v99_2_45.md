# v99.2.45

Edit mode limits fixed: (1) Browse button in the panel lets links and buttons work (the choice is remembered on the next pages); (2) edit mode now follows you to other pages by itself until you press Done; (3) text that is made by a script (not in the page HTML) is detected when you tap it: the text box is switched off with a clear message, colours and fonts still work.
