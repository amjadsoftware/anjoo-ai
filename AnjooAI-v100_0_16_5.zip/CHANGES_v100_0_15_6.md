# Anjoo AI v100.0.15.6 - Mercury added
- Providers.kt: new provider "mercury" (Inception Labs): OpenAI-compatible, https://api.inceptionlabs.ai/v1, model mercury-2, key link platform.inceptionlabs.ai/dashboard/api-keys.
- MainActivity.kt: names "mercury", "inception", "inceptionlabs" map to it when pasting keys.
- Key format not auto-detected (its start is not confirmed), so choose Mercury in the company list when pasting.
