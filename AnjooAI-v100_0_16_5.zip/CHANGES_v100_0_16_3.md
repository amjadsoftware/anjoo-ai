# Anjoo AI v100.0.16.3
- English UI, step 2: menus (MainMenus, strings.xml), Notes, Tasks, Memory & Knowledge, Permissions, Trash, Chat export, Md code runner, Offline helper, HS/Codixa screens.
- Remaining: errors, providers, file tools, phone actions, voice, agents (next versions).
