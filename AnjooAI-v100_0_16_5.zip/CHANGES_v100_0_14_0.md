# Anjoo AI v100.0.14.0 — Premium chat screen
- Your message bubble: rounder (22dp) with a small "tail" corner, more padding, softer line spacing.
- Composer: rounder (30dp), deeper shadow, roomier padding; "+" button and answer action icons (copy, listen, like, retry, more) now have ripple press feedback.
- Confirm/Cancel card: rounder, shadow, more padding.
