# Anjoo AI v100.0.15.8 - Build fix
- app/build.gradle.kts had been emptied by a faulty version-bump step in v100.0.14.3 to v100.0.15.7, so GitHub said "Task assembleDebug not found". File restored from v100.0.14.1; version name is now 100.0.15.8. All other changes of 14.3 to 15.7 are kept.
