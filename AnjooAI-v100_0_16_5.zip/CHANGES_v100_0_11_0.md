# Anjoo AI v100.0.11.0 — Settings the way it should be
- Settings order: Setup > Display > Assistant > Behavior > Connections > Phone > Data and privacy > About.
- New "Behavior" section: the 5 on/off switches (thinking, skip confirmations, auto-update, suggestions, self-check) in one place.
- Duplicates removed from Settings (Tasks, Notes, Website Builder, Artifacts, Chat history, Tools Hub): they live in the drawer / Workspace menu.
- Agent System, "continue last website" and older pages/code moved into the Workspace menu.
