# Anjoo AI v100.0.15.5 - chat commands (step 5, part 1)
- MainActivity.kt chatCommand(): short chat messages now do what the removed buttons did. "is chat ka PDF bana do" / "export this chat to word" exports the chat (pdf, docx, txt); "short jawab do", "detailed jawab", "formal jawab", "normal jawab", "roman urdu mein jawab" set the response style. Longer or unclear messages go to the AI as before.
- Modes (Think, Web, Code, Image, Big project) were already picked automatically from the message by autoRoutePrompt.
