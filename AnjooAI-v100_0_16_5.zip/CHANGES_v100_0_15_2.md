# Anjoo AI v100.0.15.2
- + (Add To Session) sheet in simple mode: Models row and Auto Memory row hidden. Photo, upload, Save Memory, Manage Memory and Language remain.
