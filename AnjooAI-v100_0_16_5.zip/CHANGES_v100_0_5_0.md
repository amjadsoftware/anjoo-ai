# Anjoo AI v100.0.5.0 — Built-in knowledge pack
- assets/kb_pack: 7 reference notes (Kotlin/Android errors, GitHub Actions/Gradle, web design checklist,
  AI APIs & prompting, Roman Urdu writing, security basics, coding best practices).
- KnowledgeSeed loads them once into the offline Knowledge Base (searchable, editable, deletable in Memory).
