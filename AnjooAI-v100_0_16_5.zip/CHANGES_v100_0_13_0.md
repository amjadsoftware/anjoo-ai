# Anjoo AI v100.0.13.0 — Cleanup 1: remove unused code
- Deleted RainView.kt (71 lines): no screen, layout or class referenced it.
