# Anjoo AI v100.0.10.0 — One chat screen
- Side drawer now shows only: New task, search, your chats, and a footer (Workspace, More tools, Update, Settings).
  The 4 big tiles (Codixa, HS, Website Builder, Artifacts) are gone from the drawer.
- New "Workspace" menu (workspaceMenu in MainMenus.kt) holds every tool in one place:
  Codixa, HS App Builder, Website Builder, Artifacts and docs, Tasks, Notes, Tools Hub.
- Texts live in strings.xml (ws_*).
