# v100.0.16.4
English-only UI, step 4: Code Studio tools (CodeTools, Coder), Shell, Sandbox (Privacy lock messages), PyRun.
Plus everything from step 3 (Providers, Router, FileAccess, Guard, Ear/Stt, etc.).
Roman Urdu is removed from user-visible results; voice-command recognisers are intentionally kept.
