# Anjoo AI v100.0.15.4
- Side menu: "More tools" entry removed. Settings has a new Advanced section (Advanced tools sheet, Starred answers, Export chat, Add chat to project) so nothing is lost, only moved out of the way.
- plusMenu, showStars, exportChat, projectMenu made internal so Settings (MainMenus.kt) can open them.
