# Anjoo AI v100.0.16.1
- Summary sheet matched closer to Claude: each command row has its own badge (terminal, book for reading, magnifier for search, checklist for tasks, file, globe for web).
- Command titles are bold sans-serif, thoughts stay serif; terminal rows show the command in monospace under the title.
- File steps show a code card (green added lines, red removed lines, fading at the bottom).
- The orange live row uses a changing word (Thinking, Sleuthing, Pondering...) with shimmer.
