# Anjoo AI v100.0.14.3
- Style.kt: new CLAUDE-STYLE JUDGMENT block in the system prompt: understand intent first, simplest tool only when needed, ask when unclear, answer first, never claim work without tool proof, admit what is unknown, own mistakes, work in small steps.
