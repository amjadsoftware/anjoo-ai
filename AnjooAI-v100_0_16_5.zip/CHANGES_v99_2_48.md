# v99.2.48 — Expanded AI Model Capability Registry

- Expanded the existing model registry to cover image generation, audio understanding, speech/TTS, video, translation, embeddings, reranking, mathematics, long-context and moderation alongside chat, coding, reasoning, vision, PDF and tools.
- Configured image-generation and voice-only providers now appear in the registry without being incorrectly offered as chat models.
- Added searchable filter chips for the extended categories in the existing Model Registry screen; existing navigation and UI structure are preserved.
- Capability names inferred from model IDs are marked as likely/unknown, not verified. Only a successful in-app task observation can produce a verified mark. Unknown context sizes and prices remain unclaimed.
- Added unit tests for capability coverage, conservative model-name hints, and extended task-to-capability mapping.
- Version bumped to 99.2.48.

Limitations: this change expands capability discovery and filtering; it does not automatically grant provider access or create unsupported image/audio/video/embedding APIs. Such operations still require a compatible provider, a valid key, and an implemented endpoint.
