# v99.2.44

Automatic background continue: an unfinished Website Builder build (internet lost, app closed) is remembered (wbPending); when the internet returns Android starts BgDrainService, which runs action=continue for it (up to 3 tries, no screenshots, nothing that needs the user), and the finished site appears in the chat with its project card plus a notification. The existing background outbox for chat messages is unchanged.
