# v99.2.51 — Memory & Knowledge (local-first)

## Personal memory
- Keeps long-term preferences, facts, people and ongoing tasks in app-private storage; existing `long_memory.json` data remains readable.
- Added review, search, add, edit, pin, complete and delete controls in Memory & Knowledge.
- Turning Save Memory off stops new/automatic captures but does not block editing or deleting existing memories.
- Added per-item deletion tombstones plus a global clear watermark. Forget, single delete and clear operations survive backup merges, including unseen records in older/offline backups, without resurrecting deleted information. Newer records created after a clear remain valid. Older backups without tombstones remain importable.
- Full backup and the separate Memory & Knowledge JSON export include active memories and deletion tombstones. Device-specific consents to send knowledge to external AI providers are not copied to or silently enabled by backup restore; the user must opt in on each device.

## Knowledge base
- SQLite document library with ordered overlapping chunks, duplicate detection, source metadata, pinning, edit/delete and full-text FTS4 search with a LIKE fallback.
- Imports text/code, CSV/JSON/XML/HTML, DOCX, PPTX, XLSX/XLSM, ODT/ODS/ODP and RTF locally; PDF and image imports use remote AI OCR and require a separate confirmation before pages/images are sent to the configured vision provider.
- Search results preserve multiple relevant chunks from the same document, with title/source labels for citations in assistant answers.
- Prompt-injection boundary: imported document text is untrusted reference data, never executable instructions.
- Full backup and restore merge knowledge documents by ID and newest timestamp; document deletion tombstones prevent deleted files returning from older backups.

## Optional semantic retrieval
- Added opt-in Gemini Embedding 2 (`gemini-embedding-2`) vector indexing, 768-dimensional vectors, batch indexing, cosine similarity and hybrid semantic + lexical retrieval.
- Google semantic indexing is OFF by default. Turning it on requires an explicit privacy confirmation; document chunks and search queries are sent to Google's Gemini Embedding API and may use API quota/billing.
- Knowledge excerpts are excluded from chat requests by default. A separate confirmation is required to enable `Use Knowledge in AI answers`; when enabled, only matching excerpts are added to the configured chat model request.
- Added status, build/rebuild controls and delete-semantic-index control. Turning semantic search off clears the in-memory query cache; stored vectors remain local until explicitly cleared or the source document is deleted.
- If semantic indexing is not enabled or has no vectors yet, retrieval uses the local lexical index and does not make an embedding API request.

## Storage and compatibility
- SQLite database schema upgraded to version 3 with an additive migration for semantic vector storage; v1/v2 knowledge and notes are preserved.
- Existing long-memory and chat JSON formats remain compatible; new backup fields are optional when importing older exports.

## Verification and limitations
- Pure Kotlin smoke tests passed for chunk splitting/reconstruction, credential redaction, Roman Urdu query expansion, cosine similarity edge cases, item deletion tombstones and global clear watermarks. Static checks passed for 152 unique tool declarations, all Memory/Knowledge action handlers, manifest registration, SQLite migration and backup wiring.
- Static checks cover model/tool declaration JSON, unique tool names, handler mappings, manifest registration, schema migration and backup wiring.
- No Android SDK/Gradle executable or wrapper script is available in this runtime; APK compilation, emulator/device tests and live Gemini API calls were not run. Configure a Google Gemini API key in Settings and opt in to try real semantic indexing.
