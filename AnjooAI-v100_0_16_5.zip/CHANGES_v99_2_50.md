# v99.2.50 — Coding & Software Engineering System

- Added a reusable offline static engineering analyzer for source projects.
- Added `project_engineering` AI tool with quality_gate, security, dependencies, architecture, metrics and release_check reports.
- Security heuristics identify likely embedded credentials (values are always redacted), private-key markers, live `.env` files, dynamic code execution, unsafe DOM sinks, wildcard CORS, cleartext HTTP/Android traffic, WebView JavaScript usage and risky shell execution patterns.
- Added dependency inventory for npm, Python requirements/pyproject, Gradle, Maven, Go modules, Cargo and Flutter manifests; identifies recognized lockfiles without claiming an online CVE scan.
- Added architecture map with languages, directory shape, entry-point candidates and static import hints; added code-size, TODO and test-file metrics.
- Added release-readiness checklist for README, tests, CI, `.gitignore`, sanitized environment template, lockfiles and high-severity static findings.
- Added Engineering audit entry points in Codixa project cards and project actions, with copyable reports.
- Fed structured engineering/security findings into the coding reviewer so detected risks are considered during build reviews; static heuristics remain conservative and are not treated as conclusive proof.
- Strengthened the coding agent's software-engineering standards: platform/runtime identification, interfaces, dependency/lockfile discipline, meaningful tests, CI/release documentation, diff inspection and truthful test reporting.
- Added regression tests for secret redaction, dependency inventory, architecture/metrics, release checklist and security rules.
- Version bumped to 99.2.50.

Limitations: reports are offline static heuristics. They cannot prove security, compile native Android/iOS apps, run arbitrary language test suites, or identify current CVEs without a configured external scanner. Use actual platform builds and CI for release verification.
