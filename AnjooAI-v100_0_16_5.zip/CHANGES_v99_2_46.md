# v99.2.46

AI Models System, step 1: token usage ledger (TokenLedger.kt). Every Gemini, OpenAI-style and Anthropic call now records the token counts the company returned (per company and model, per day, kept about 2 months). Model menu > Token usage shows today and this month, an optional daily token limit (one notification when passed; requests are never blocked) and optional prices typed in by the user (cost stays "unknown" without a price). Tests: TokenLedgerTest.
