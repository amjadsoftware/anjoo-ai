# Anjoo AI v100.0.1

- Version bumped to 100.0.1.
- Fixed build errors in `MemoryActivity.kt` (Switch text shadowing, missing `JSONObject` import, `setTextIsSelectable`).
