# Anjoo AI v100.0.7.0 — Step 2: strings.xml (menus)
- 72 menu/section/toggle/dialog/toast texts of the Settings menus (MainMenus.kt) moved into res/values/strings.xml
  (73 call sites use getString(R.string.mm_*)). Texts are unchanged; the menu is now translation-ready.
- Dynamic texts (those with variables) stay in code. The rest of the app's text is not moved yet.
