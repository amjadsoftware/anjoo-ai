# Anjoo AI v100.0.3.0 — Premium menus
- New Premium.kt: grouped rounded cards per section, icon chips, muted detail lines, chevrons,
  real On/Off switches for toggles, ripple press feedback, drag handle, close button, larger title.
- Applies to Settings and every sub-menu built with menu() (Voice, AI models, Backup, Phone control, More tools...).
- Side drawer footer rows (More tools / Update / Settings) use the same premium rows.
