# Anjoo AI v100.0.14.1 — Build fix
- KnowledgeSeed.kt: a comment contained "kb_pack/*.txt"; Kotlin reads "/*" as a nested comment start,
  so the file failed with "Unclosed comment" and MainActivity could not find KnowledgeSeed. Comment reworded.
- Scanned every .kt file for unbalanced block comments: none left.
