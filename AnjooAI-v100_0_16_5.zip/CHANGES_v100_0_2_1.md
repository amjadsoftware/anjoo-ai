# Anjoo AI v100.0.2.1 — Text size

- New Settings > "Text size (poori app)": Chhota / Normal / Bara / Bohat bara. Applies to every screen.
- Tiny text (9-11sp) raised to 11.5-12sp across screens.
- Added TextScale.kt; every Activity wraps its context so sp text scales together.
