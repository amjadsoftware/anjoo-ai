# Anjoo AI v99.2.52 — Voice & Multimodal readiness

## Added
- Added a unified Voice & Multimodal readiness report in Voice and language settings.
- Reports Android microphone permission, on-device speech recognition availability, cloud STT provider-key readiness, Gemini Live prerequisites, cloud TTS configuration, Android TTS fallback, current listening engine, image understanding/generation configuration, and document/knowledge availability.
- Added a one-tap spoken voice test from the readiness report.
- Improved voice error status wording: quota/rate errors and authentication/model-access errors are distinguished without claiming a live provider check.
- Bumped app version to 99.2.52.

## Existing capabilities retained
- Google SpeechRecognizer dictation with partial results and alternate transcripts.
- Groq Whisper and Gemini cloud speech transcription.
- Gemini Live bidirectional audio conversation, interruption handling, and tool calls.
- Gemini, ElevenLabs, Azure, and Android TTS paths where configured/supported.
- Mixed Urdu/English speech segmentation, voice selection, wake word, voice orb/hologram, audio focus and chat reply read-aloud.
- Image attachments/vision-model routing, image generation/editing, and document/Knowledge workflows.

## Accuracy and limitations
- The report checks local prerequisites and configured keys; it does not make paid test calls or guarantee provider quota/model access.
- Image generation depends on provider/model support and credentials.
- Arbitrary video-file understanding is explicitly marked unavailable/not verified; live microphone audio is a separate supported path.
- Cloud audio is transmitted to the selected provider when cloud voice/transcription is used. Users should review provider privacy and billing terms.
- Android APK build and physical-device testing require Android SDK/Gradle and were not available in this environment.
