# Anjoo AI v100.0.6.0 — Step 1: split MainActivity (menus)
- Moved 13 settings/menu functions (showMenu, voiceMenu, phoneMenu, pickTheme, pickTextSize, pickAnjooLanguage,
  showAbout, showCustom, pickHologramStyle, pickVoice, toggleLang, setJarvisMode, offerFix) from MainActivity.kt
  into MainMenus.kt as extension functions. MainActivity.kt: 6100+ -> 5800 lines.
- 34 members they use changed from private to internal (same module only). No behavior change.
