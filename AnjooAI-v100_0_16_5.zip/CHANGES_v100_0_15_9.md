# Anjoo AI v100.0.15.9 - Edit and check like Claude
- CodeTools.kt sanity(): after project_write and project_edit the tool result now carries a WARNING when the file became empty, shrank below 40%, or the edit left { } ( ) [ ] uneven. The AI must fix it or undo with project_history before saying done.
- Style.kt: new EDIT AUR JAANCH rule: read first, small edits, read the CHECK/WARNING, run project_check at the end, report only what was verified.
