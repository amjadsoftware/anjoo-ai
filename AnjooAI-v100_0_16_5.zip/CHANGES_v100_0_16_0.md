# Anjoo AI v100.0.16.0
- Live work now looks like Claude: while Anjoo works the chat shows one line, orange "···  Running command ›" (or "Thinking"), with a shimmer and, after a few seconds, "Still working on it…". The old dark "Anjoo Workstation" card is gone.
- Tap that line to open the Summary sheet (X at left, "Summary" centred). It updates live: every thought is a grey dot row, every command is a terminal-badge row in bold, the running command shimmers, and the last row is a pulsing orange dot with "Thinking". A vertical line joins all rows.
- When the answer starts, the live line folds into "Ran N commands ›" (or "Thought for Ns ›"); tapping it still opens the Summary.
- Finished replies use the same Summary sheet (Process pill). Thought rows come from the model's own bold headings when it writes them.
- Code: new SummarySheet.kt (sheet, dots loader, terminal badge); MainActivity live card and activity sheet rewired to it.
