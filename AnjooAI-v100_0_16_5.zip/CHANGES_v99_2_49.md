# v99.2.49 — Premium Tools System and Tools Hub

- Added a central tool registry that reads the same function schemas exposed to the model and classifies tools into web, browser, coding, data/API, documents, files, image, phone, communication, calendar, personal productivity, agents, artifacts and AI integration categories.
- Added a searchable Tools Hub with category filters, each tool's description, declared parameters, risk level, requirements and live local readiness checks. Readiness distinguishes chat-provider keys from image providers, checks network for remote/Pyodide tools, checks Android 13+ notification permission, Accessibility, storage and device permissions.
- Added a privacy-safe execution history (last 80 runs) that stores only tool name/category/status/time/duration; it never stores arguments, message contents, file contents, keys or raw results. Repeated-call loop blocks are logged as safeguards, not executed successes.
- Added `list_tools` query modes: `overview` / `status` for current readiness and `history` for recent activity, without adding extra model function declarations.
- Integrated execution recording into the central Actions dispatcher and exposed Tools Hub from More tools and Settings > Connections.
- Expanded assistant instructions to choose purpose-built tools, verify results, observe permissions and confirmations, and avoid repeating successful actions.
- Added tests for tool catalog integrity, category coverage, risk metadata and safe history classification.
- Version bumped to 99.2.49.

Limitations: readiness is a local prerequisite check, not proof that a provider API or third-party app will succeed. External APIs still require valid credentials and available network access; Android phone actions require their respective permissions or Accessibility access. Full Android build/device testing could not be run in this container because the Android SDK and Gradle executable are not installed.
