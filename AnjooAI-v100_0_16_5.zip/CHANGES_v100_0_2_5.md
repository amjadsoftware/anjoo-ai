# Anjoo AI v100.0.2.5 — Fix-it prompt
- When an answer fails with a wrong/blocked key (401/403), wrong model/URL (404) or quota limit (429),
  a dialog now offers "Settings kholo" in one tap (before: only a text message).
- Offline queue, crash report and plain-language error text already existed and are unchanged.
