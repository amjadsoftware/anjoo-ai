# Anjoo AI v100.0.14.2
- Style.kt: new MAP / NAQSHA rule. "World map bnao" now means a picture (generate_image), not an HTML/coding artifact. Interactive map only if the user asks for it.
