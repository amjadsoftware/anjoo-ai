# Anjoo AI v100.0.16.2
- English UI, step 1: the main chat screen (MainActivity) is now fully English: menus, dialogs, toasts, key manager, backup/privacy screens, offline messages, progress lines.
- Remaining files are translated in the next versions.
