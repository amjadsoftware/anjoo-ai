# Anjoo AI v100.0.12.0 — Trust: undo, timeline, confirmations
- Undo: deleted notes and tasks are kept 14 days (Trash.kt). Workspace > "Recently deleted" restores them with one tap.
- Timeline: Workspace > "Activity timeline" lists what Anjoo did (done / cancelled / issue) with time, from the existing tool log.
- delete_routine now asks for confirmation (it deleted silently before).
- Already in the app and unchanged: confirmation cards for call, SMS, replies, deletes, overwrite, shell;
  bank/card protection (Guard); rule "never claim an action was completed without tool confirmation".
