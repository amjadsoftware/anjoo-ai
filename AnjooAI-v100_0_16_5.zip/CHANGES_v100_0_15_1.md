# Anjoo AI v100.0.15.1 - Premium simple screen, step 1
- MainActivity.kt: SIMPLE_UI flag. Select Models chip hidden and model choice reset to Auto (app picks the best working model). The "Effort / Think / Style" line under the title is hidden. Nothing deleted: set SIMPLE_UI=false to bring them back.
