# Anjoo AI v100.0.2.2 — Errors no longer silent
- New Oops.kt: one short message (max 1 per 3 s) instead of failing silently.
- Now reported: chat not saved, offline-queue save failed, link/settings screen can't open,
  share sheet failed, auto-backup failed, restore of notes/memory failed, update installer screen failed.
