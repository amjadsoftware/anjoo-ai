# Anjoo AI v100.0.8.0 — Step 3: permissions only when needed
- First launch no longer asks 17 permissions at once. Welcome dialog explains; "Got it" or "Allow all now".
- New PermNeed.kt: when a feature finds a permission missing (contacts, calendar, location, SMS, calls, camera,
  mic, notifications, media), after the reply one dialog explains and asks for that group only.
  "Not now" is remembered for 3 days. "Grant all permissions" in Settings still works.
