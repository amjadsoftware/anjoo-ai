# Anjoo AI v100.0.15.7 - "X add karo" in chat (part 1)
- MainActivity.kt: writing "Mercury add karo", "add groq", "claude ki key lagao" in the chat opens a key box for that company (with its note and key link). The key is checked and saved by the existing key store and never enters the chat. Works for every company already in the app.
- A company that is not in the app yet (part 2) is still to do.
