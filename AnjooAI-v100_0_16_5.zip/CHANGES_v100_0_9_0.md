# Anjoo AI v100.0.9.0 — Step 4: automatic tests on GitHub
- New .github/workflows/tests.yml: runs all JVM unit tests on every push/PR (separate from your build workflow),
  prints a short pass/fail summary on the run page and uploads the report when something fails.
- New ManifestSanityTest: fails if an Activity exists in the code but is missing from AndroidManifest.xml,
  or if AnjooApp is not declared.
- Note: the project has no gradlew; the workflow uses setup-gradle 8.7 like your build.
