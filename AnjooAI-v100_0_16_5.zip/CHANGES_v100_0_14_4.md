# Anjoo AI v100.0.14.4
- Artifacts.kt: MAP_RULES. When an interactive map/world map artifact is requested, the generated page must be a real Leaflet + OpenStreetMap map (sized container, invalidateSize, search, my location, offline message) instead of an empty box. Applied on create and update.
