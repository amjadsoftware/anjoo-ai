# Anjoo AI v100.0.2.4 — Accessibility
- New AnjooApp + A11y: every tappable view without a label now gets one automatically (from its text),
  so TalkBack can read buttons on all screens, including dynamic chat views and menus.
