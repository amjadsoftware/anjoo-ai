# Anjoo AI v100.0.4.0 — Claude-style judgment
- master_instructions.txt: new section 30 (answer shape, honest calibration, careful-engineer habits,
  effort/tool discipline, wellbeing, fairness on contested topics, safety lines, pre-send check).
- Text-only change (loaded at runtime); no Kotlin code touched.
