package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolLoopBudgetTest {
    @Test fun normalCompletionAtLimitIsNotReportedAsFailure() {
        assertNull(ToolLoopBudget.incompleteMessage(finishedNormally = true, steps = ToolLoopBudget.MAX_STEPS))
    }

    @Test fun exhaustingBudgetProducesExplicitIncompleteMessage() {
        val message = ToolLoopBudget.incompleteMessage(finishedNormally = false, steps = ToolLoopBudget.MAX_STEPS)
        assertTrue(message!!.contains("the task is not fully verified yet"))
        assertTrue(message.contains("${ToolLoopBudget.MAX_STEPS} tool rounds"))
    }

    @Test fun budgetIsOnlyExhaustedAtFortyRounds() {
        assertNull(ToolLoopBudget.incompleteMessage(false, ToolLoopBudget.MAX_STEPS - 1))
        assertEquals(40, ToolLoopBudget.MAX_STEPS)
    }
}
