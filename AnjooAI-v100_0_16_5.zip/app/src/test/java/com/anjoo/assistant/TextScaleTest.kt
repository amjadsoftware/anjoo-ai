package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TextScaleTest {
    @Test fun labelsMatchScales() {
        assertEquals(TextScale.labels.size, TextScale.scales.size)
    }
    @Test fun defaultIsNormal() {
        assertEquals(1.0f, TextScale.scales[TextScale.DEFAULT_IDX], 0.0001f)
    }
    @Test fun scalesAreIncreasing() {
        for (i in 1 until TextScale.scales.size) assertTrue(TextScale.scales[i] > TextScale.scales[i - 1])
    }
}
