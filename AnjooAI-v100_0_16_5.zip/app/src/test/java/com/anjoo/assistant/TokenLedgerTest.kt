package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TokenLedgerTest {
    @Test fun addsUpCallsPerModelAndPerDay() {
        val b = UsageBook()
        b.record("2026-11-01", "Google|gemini-x", 100, 50)
        b.record("2026-11-01", "Google|gemini-x", 10, 5)
        b.record("2026-11-02", "OpenAI|gpt-y", 7, 3)
        val day = b.totals("2026-11-01")["Google|gemini-x"]!!
        assertEquals(110L, day.input); assertEquals(55L, day.output); assertEquals(2L, day.calls)
        assertEquals(165L, b.tokensOn("2026-11-01"))
        assertEquals(2, b.totals("2026-11").size)
    }

    @Test fun negativeCountsAreIgnoredAndOldDaysAreDropped() {
        val b = UsageBook()
        b.record("2026-01-01", "A|m", -5, 4)
        assertEquals(0L, b.totals("2026-01-01")["A|m"]!!.input)
        for (d in 1..70) b.record("2026-03-" + d.toString().padStart(2, '0'), "A|m", 1, 1)
        assertNull(b.totals("2026-01-01")["A|m"])
    }

    @Test fun savesAndLoadsAgain() {
        val b = UsageBook(); b.record("2026-11-01", "A|m", 3, 4)
        val c = UsageBook(); c.load(b.toJson())
        assertEquals(7L, c.tokensOn("2026-11-01"))
    }

    @Test fun costIsUnknownWithoutAPriceAndExactWithOne() {
        val prices = UsageBook.parsePrices("gpt-5-mini, 0.25, 2.0\nbad line\nflash,1,x")
        assertEquals(1, prices.size)
        assertNull(UsageBook.cost(prices, "gemini-flash", 1000, 1000))
        val c = UsageBook.cost(prices, "gpt-5-mini-2026", 2_000_000, 500_000)
        assertNotNull(c)
        assertEquals(0.5 + 1.0, c!!, 1e-9)
    }

    @Test fun longestMatchingPriceNameWins() {
        val prices = UsageBook.parsePrices("gpt,1,1\ngpt-5-mini,2,2")
        assertTrue(UsageBook.cost(prices, "gpt-5-mini", 1_000_000, 0)!! == 2.0)
    }
}
