package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KnowledgeLogicTest {
    @Test fun splitAndReconstructPreserveOriginalText() {
        val source = (1..600).joinToString(" ") { "word$it" }
        val chunks = KnowledgeLogic.split(source)
        assertTrue(chunks.size > 1)
        assertEquals(source, KnowledgeLogic.reconstruct(chunks))
    }

    @Test fun shortTextRemainsOneChunk() {
        val source = "Anjoo AI local knowledge"
        assertEquals(listOf(source), KnowledgeLogic.split(source))
        assertEquals(source, KnowledgeLogic.reconstruct(KnowledgeLogic.split(source)))
    }

    @Test fun credentialAndCardValuesAreRedacted() {
        val (safe, count) = KnowledgeLogic.redact("api_key=sk-live-123456789 password: mysecret123 card 4111 1111 1111 1111")
        assertEquals(3, count)
        assertFalse(safe.contains("sk-live-123456789"))
        assertFalse(safe.contains("mysecret123"))
        assertFalse(safe.contains("4111 1111 1111 1111"))
        assertTrue(safe.contains("[REDACTED]"))
    }

    @Test fun romanUrduAndEnglishQueriesExpand() {
        val terms = KnowledgeLogic.expand(setOf("nokri"))
        assertTrue(terms.contains("job"))
        assertTrue(terms.contains("work"))
    }

    @Test fun titleAndContentMatchesRankHigher() {
        val now = 1_800_000_000_000L
        val strong = KnowledgeLogic.score("Madinah duty", "Madinah Duty Schedule", "Tomorrow duty starts at twelve.", false, now, now)
        val weak = KnowledgeLogic.score("Madinah duty", "Unrelated notes", "Gardening and cooking ideas.", false, now, now)
        assertTrue(strong > weak)
    }

    @Test fun pinnedKnowledgeGetsPriorityOnTie() {
        val now = 1_800_000_000_000L
        val pinned = KnowledgeLogic.score("station", "Notes", "station attendance details", true, now, now)
        val normal = KnowledgeLogic.score("station", "Notes", "station attendance details", false, now, now)
        assertTrue(pinned > normal)
    }
    @Test fun cosineSimilarityHandlesDirectionAndMagnitude() {
        assertEquals(1.0, KnowledgeLogic.cosine(floatArrayOf(1f, 2f), floatArrayOf(2f, 4f))!!, 1e-6)
        assertEquals(0.0, KnowledgeLogic.cosine(floatArrayOf(1f, 0f), floatArrayOf(0f, 1f))!!, 1e-6)
    }


    @Test fun globalClearTombstoneBlocksOldBackupsButAllowsNewerMemory() {
        assertTrue(MemLogic.suppressedByGlobalClear(100L, 101L))
        assertTrue(MemLogic.suppressedByGlobalClear(101L, 101L))
        assertFalse(MemLogic.suppressedByGlobalClear(102L, 101L))
        assertFalse(MemLogic.suppressedByGlobalClear(100L, 0L))
    }

    @Test fun deletionTombstoneBlocksOlderBackupAndAllowsNewerEdit() {
        assertTrue(MemLogic.suppressedByDeletion(100L, 101L))
        assertTrue(MemLogic.suppressedByDeletion(101L, 101L))
        assertFalse(MemLogic.suppressedByDeletion(102L, 101L))
        assertFalse(MemLogic.suppressedByDeletion(100L, null))
    }

    @Test fun cosineRejectsInvalidVectors() {
        assertEquals(null, KnowledgeLogic.cosine(floatArrayOf(1f), floatArrayOf(1f, 2f)))
        assertEquals(null, KnowledgeLogic.cosine(floatArrayOf(0f, 0f), floatArrayOf(1f, 2f)))
        assertEquals(null, KnowledgeLogic.cosine(floatArrayOf(Float.NaN), floatArrayOf(1f)))
    }

}
