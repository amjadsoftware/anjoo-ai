package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ToolRegistryTest {
    @Test fun everyDeclaredToolHasUniqueCatalogMetadata() {
        val declared = org.json.JSONArray(Gemini.DECLARATIONS)
        val catalog = ToolRegistry.all()
        assertEquals(declared.length(), catalog.size)
        assertEquals(catalog.size, catalog.map { it.name }.toSet().size)
        for (t in catalog) {
            assertTrue("blank description: ${t.name}", t.description.isNotBlank())
            assertNotNull("missing category: ${t.name}", t.category)
            assertNotNull("missing parameters: ${t.name}", t.parameters)
        }
    }

    @Test fun allMajorToolDomainsAreRepresented() {
        val categories = ToolRegistry.all().map { it.category }.toSet()
        assertTrue(categories.containsAll(setOf(
            ToolRegistry.Category.WEB, ToolRegistry.Category.BROWSER, ToolRegistry.Category.CODE,
            ToolRegistry.Category.DATA, ToolRegistry.Category.DOCUMENTS, ToolRegistry.Category.FILES,
            ToolRegistry.Category.IMAGE, ToolRegistry.Category.PHONE, ToolRegistry.Category.COMMUNICATION,
            ToolRegistry.Category.CALENDAR, ToolRegistry.Category.PERSONAL, ToolRegistry.Category.AGENTS,
            ToolRegistry.Category.ARTIFACTS, ToolRegistry.Category.AI
        )))
    }

    @Test fun riskMetadataHighlightsConsequentialActions() {
        assertEquals(ToolRegistry.Risk.SENSITIVE, ToolRegistry.riskFor("call"))
        assertEquals(ToolRegistry.Risk.SENSITIVE, ToolRegistry.riskFor("send_sms"))
        assertEquals(ToolRegistry.Risk.EXTERNAL, ToolRegistry.riskFor("run_shell"))
        assertEquals(ToolRegistry.Risk.READ, ToolRegistry.riskFor("search_web"))
        assertFalse(ToolRegistry.requirementFor("search_web").isBlank())
    }

    @Test fun searchFindsRelevantPurposeBuiltTools() {
        assertTrue(ToolRegistry.search("pdf").any { it.name == "read_document" })
        assertTrue(ToolRegistry.search("image").any { it.name == "generate_image" })
        assertTrue(ToolRegistry.search("whatsapp").any { it.name == "whatsapp_message" })
        assertTrue(ToolRegistry.search("project", ToolRegistry.Category.CODE).isNotEmpty())
        assertTrue(ToolRegistry.search("engineering", ToolRegistry.Category.CODE).any { it.name == "project_engineering" })
    }

    @Test fun assistantInstructionsExplainOverviewAndHistoryModes() {
        val p = ToolRegistry.promptBlock()
        assertTrue(p.contains("query='overview'"))
        assertTrue(p.contains("query='history'"))
        assertTrue(p.contains("confirmation"))
    }
}
