package com.anjoo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class EngineeringTest {
    @Test fun secretScanFlagsCredentialButNeverPrintsValue() {
        val secret = "sk-abcdefghijklmnopqrstuvwxyz0123456789"
        val files = mapOf("src/config.js" to "const api_key = \"$secret\";\n")
        val hits = Engineering.findings(files)
        assertTrue(hits.any { it.code == "POSSIBLE_HARDCODED_SECRET" })
        val report = Engineering.report("Demo", files, "security")
        assertFalse(report.contains(secret))
        assertTrue(report.contains("value redacted"))
    }

    @Test fun environmentTemplateDoesNotTriggerAsLiveSecretFile() {
        val files = mapOf(
            ".env.example" to "API_KEY=your_api_key_here\n",
            ".gitignore" to ".env\nnode_modules/\n"
        )
        assertFalse(Engineering.findings(files).any { it.code == "ENV_FILE_INCLUDED" || it.code == "POSSIBLE_HARDCODED_SECRET" })
    }

    @Test fun dependencyInventoryReadsNpmManifestAndLockfile() {
        val files = mapOf(
            "package.json" to """{"dependencies":{"react":"^18.3.1"},"devDependencies":{"vite":"^5.4.0"}}""",
            "package-lock.json" to "{}"
        )
        val report = Engineering.report("Web app", files, "dependencies")
        assertTrue(report.contains("react @ ^18.3.1"))
        assertTrue(report.contains("vite @ ^5.4.0"))
        assertTrue(report.contains("package-lock.json"))
    }

    @Test fun architectureAndMetricsAreUsefulForSmallProjects() {
        val files = mapOf(
            "index.html" to "<html><body></body></html>",
            "src/main.js" to "export function start() { return true; }",
            "src/styles.css" to "body { margin: 0; }",
            "tests/main.test.js" to "// TODO verify startup"
        )
        assertTrue(Engineering.report("Demo", files, "architecture").contains("index.html"))
        assertTrue(Engineering.report("Demo", files, "metrics").contains("TODO/FIXME/HACK/XXX markers: 1"))
    }

    @Test fun releaseChecklistDistinguishesMissingFiles() {
        val report = Engineering.report("Minimal", mapOf("main.py" to "print('hi')"), "release_check")
        assertTrue(report.contains("[MISSING] README with install"))
        assertTrue(report.contains("Automated CI workflow"))
        assertTrue(report.contains("cannot validate signing keys"))
    }

    @Test fun securityScanDetectsDangerousPatternsAndCleartextSetting() {
        val files = mapOf(
            "src/app.js" to "const html = data; target.innerHTML = html; eval(input);",
            "app/src/main/AndroidManifest.xml" to "<application android:usesCleartextTraffic=\"true\" />"
        )
        val codes = Engineering.findings(files).map { it.code }.toSet()
        assertTrue(codes.contains("DYNAMIC_CODE_EXECUTION"))
        assertTrue(codes.contains("UNSAFE_DOM_SINK"))
        assertTrue(codes.contains("ANDROID_CLEARTEXT_ENABLED"))
    }
}
