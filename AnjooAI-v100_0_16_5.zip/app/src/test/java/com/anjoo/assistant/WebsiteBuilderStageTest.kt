package com.anjoo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WebsiteBuilderStageTest {
    @Test fun previewStageRequiresAnActualCleanPreviewResult() {
        assertTrue(WebsiteBuilder.stagePassed("run_check", "Preview ran: no console error or missing file found."))
        assertFalse(WebsiteBuilder.stagePassed("run_check", "These issues remain even after fixing:\n- JS error"))
        assertFalse(WebsiteBuilder.stagePassed("run_check", "Preview inspection timed out."))
        assertFalse(WebsiteBuilder.stagePassed("run_check", ""))
    }

    @Test fun auditBlocksRemainingHighAndMediumFindingsButAllowsLowFindings() {
        assertTrue(WebsiteBuilder.stagePassed("audit", "Audit after: 0 high, 0 medium, 3 low."))
        assertFalse(WebsiteBuilder.stagePassed("audit", "Audit after: 1 high, 0 medium, 0 low."))
        assertFalse(WebsiteBuilder.stagePassed("audit", "Audit after: 0 high, 2 medium, 1 low."))
    }

    @Test fun verificationRequiresEntryPageAndCleanPreview() {
        assertTrue(WebsiteBuilder.stagePassed("verify", "Entry page: index.html, 12 files.\nFinal preview check clean."))
        assertFalse(WebsiteBuilder.stagePassed("verify", "No HTML entry page found."))
        assertFalse(WebsiteBuilder.stagePassed("verify", "Entry page: index.html, 12 files.\nFinal preview check issues: HTTP 404"))
    }

    @Test fun premiumReviewDoesNotPassWhenReviewerFailsOrInteractionFindingsRemain() {
        assertTrue(WebsiteBuilder.stagePassed("premium_review", "Premium review completed. Interaction scan: no simple placeholder/dead-link patterns detected."))
        assertFalse(WebsiteBuilder.stagePassed("premium_review", "Premium review blocked: the AI review gave no valid result."))
        assertFalse(WebsiteBuilder.stagePassed("premium_review", "Premium review completed. Interaction scan still needs review: broken link."))
    }

    @Test fun visualCheckNeverBlocksEvenWhenItReportsDefects() {
        assertTrue(WebsiteBuilder.stagePassed("visual_check", "Visual check: 2 defect(s) found and a fix was attempted:\n- index.html: image failed to load -> use local file"))
        assertTrue(WebsiteBuilder.stagePassed("visual_check", "Visual check skipped: a Google Gemini key is needed."))
        assertFalse(WebsiteBuilder.stagePassed("visual_check", ""))
    }

    @Test fun imagesStagePassesWhenFilesAreReady() {
        assertTrue(WebsiteBuilder.stagePassed("images", "Images ready: 3 file(s) created (AI picture: 0, designed SVG: 3)."))
        assertFalse(WebsiteBuilder.stagePassed("images", "Images: error: disk full"))
    }
}
