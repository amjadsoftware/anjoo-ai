package com.anjoo.assistant

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/** Cheap guard: every Activity class in the source is declared in AndroidManifest.xml (a missing one crashes at launch). */
class ManifestSanityTest {
    private fun root(): File {
        var d: File? = File("").absoluteFile
        while (d != null && !File(d, "src/main/AndroidManifest.xml").exists()) d = d.parentFile
        return d ?: File("app").absoluteFile
    }

    @Test fun everyActivityIsDeclared() {
        val r = root()
        val manifest = File(r, "src/main/AndroidManifest.xml")
        if (!manifest.exists()) return
        val mf = manifest.readText()
        val pkgDir = File(r, "src/main/java/com/anjoo/assistant")
        val missing = ArrayList<String>()
        for (f in pkgDir.listFiles { x -> x.name.endsWith(".kt") }.orEmpty()) {
            Regex("""(?m)^class (\w+)\s*:\s*Activity\(\)""").findAll(f.readText()).forEach {
                val n = it.groupValues[1]
                if (!mf.contains(".$n\"") && !mf.contains("com.anjoo.assistant.$n\"")) missing += n
            }
        }
        assertTrue("Activities missing from the manifest: $missing", missing.isEmpty())
    }

    @Test fun applicationClassIsDeclared() {
        val manifest = File(root(), "src/main/AndroidManifest.xml")
        if (!manifest.exists()) return
        assertTrue(manifest.readText().contains("android:name=\".AnjooApp\""))
    }
}
