package com.anjoo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentJobsCompletionTest {
    @Test fun onlyKnownFailureMarkersKeepTaskOpen() {
        assertTrue(AgentJobs.resultLooksComplete("Report created and the results are attached."))
        assertFalse(AgentJobs.resultLooksComplete("Task failed: provider timeout."))
        assertFalse(AgentJobs.resultLooksComplete("Anjoo ne 40 tool rounds ki limit poori kar li."))
        assertFalse(AgentJobs.resultLooksComplete("Add an API key in Settings first."))
        assertFalse(AgentJobs.resultLooksComplete(""))
    }
}
