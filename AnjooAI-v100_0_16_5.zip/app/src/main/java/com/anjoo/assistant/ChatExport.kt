package com.anjoo.assistant

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import java.io.File

/** Export one chat as PDF, Word (.docx) or text: saved to the default folder and offered in the share sheet. */
object ChatExport {
    private fun markdown(ctx: Context, id: Long): String {
        val ls = ChatStore.lines(ctx, id)
        val sb = StringBuilder()
        for (i in 0 until ls.length()) {
            val o = ls.getJSONObject(i)
            val k = o.getInt("k")
            if (k > 1) continue
            sb.append(if (k == 0) "### You\n" else "### Anjoo\n").append(o.getString("t").trim()).append("\n\n")
        }
        return sb.toString().trim()
    }

    /** Runs on a worker thread. Returns the message to show the user. */
    fun run(ctx: Context, id: Long, fmt: String): String {
        val md = markdown(ctx, id)
        if (md.isBlank()) return "There is nothing in this chat yet."
        val sess = ChatStore.list(ctx).firstOrNull { it.getLong("id") == id }
        val title = if (sess != null) ChatStore.title(sess) else "Anjoo chat"
        val safe = title.replace(Regex("[\\\\/:*?\"<>|\\s]+"), "_").trim('_').take(40).ifEmpty { "chat" }
        val name = "Anjoo_" + safe + "_" + java.text.SimpleDateFormat("yyyyMMdd_HHmm", java.util.Locale.ENGLISH).format(java.util.Date()) + "." + fmt
        val bytes: ByteArray = try {
            when (fmt) {
                "pdf", "docx" -> Power.exportBytes(fmt, title, md)
                else -> (title + "\n\n" + md.replace("### ", "")).toByteArray(Charsets.UTF_8)
            }
        } catch (e: Exception) { return "Could not export: " + (e.message ?: e.javaClass.simpleName) }
        val saved = try { FileAccess.write(ctx, if (Vault.ready(ctx)) Vault.NAME + "/Chats/Exports" else "", name, bytes, false) { true } } catch (e: Exception) { "" }
        try {
            val d = File(ctx.filesDir, "artifacts/_share").also { it.mkdirs() }
            d.listFiles()?.forEach { if (System.currentTimeMillis() - it.lastModified() > 24 * 3600 * 1000L) it.delete() }
            File(d, name).writeBytes(bytes)
            val uri = Uri.parse("content://" + Artifacts.AUTH + "/" + Uri.encode(name))
            val mime = when (fmt) { "pdf" -> "application/pdf"; "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"; else -> "text/plain" }
            val i = Intent(Intent.ACTION_SEND).setType(mime).putExtra(Intent.EXTRA_STREAM, uri).putExtra(Intent.EXTRA_SUBJECT, title)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            i.clipData = ClipData.newRawUri(name, uri)
            Handler(Looper.getMainLooper()).post {
                try { ctx.startActivity(Intent.createChooser(i, "Share chat").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { Oops.note(ctx, "Could not open the share screen.", e) }
            }
        } catch (e: Exception) { return if (saved.startsWith("Saved")) saved else "Could not share: " + (e.message ?: "") }
        return if (saved.startsWith("Saved")) saved else "Share screen opened: $name"
    }
}
