package com.anjoo.assistant

import android.content.Context
import org.json.JSONObject
import java.util.Properties

/**
 * Saves all API keys (and the chosen AI + models) to one small file, and loads them back.
 * Use it once after typing your keys: export, keep the file safe, and import it after a reinstall.
 * Import also understands a plain keys.properties file (groq=..., gemini=...).
 *
 * The file holds the keys as plain text. Keep it private, never share it or upload it anywhere.
 */
object KeyFile {
    private val IDS: List<String> get() = Providers.ALL.map { it.id }

    fun export(ctx: Context): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val keys = JSONObject()
        val models = JSONObject()
        val more = JSONObject()
        for (id in IDS) {
            val extra = Providers.allKeys(p, id).drop(1)
            if (extra.isNotEmpty()) more.put(id, org.json.JSONArray(extra))
            val k = Providers.savedKey(p, id)
            if (k.isNotBlank()) keys.put(id, k)
            val m = Providers.savedModel(p, id)
            if (k.isNotBlank() && m.isNotBlank()) models.put(id, m)
        }
        return JSONObject().put("app", "AnjooAI").put("type", "keys").put("version", 1)
            .put("provider", p.getString("provider", "gemini") ?: "gemini")
            .put("base_custom", p.getString("base_custom", "") ?: "")
            .put("autoFree", p.getBoolean("autoFree", true))
            .put("keys", keys).put("models", models).put("more", more).put("router", Router.exportJson()).toString(2)
    }

    fun count(ctx: Context): Int {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        return IDS.sumOf { Providers.allKeys(p, it).size }
    }

    /** Returns a message for the user. Keys found in the file replace the saved ones; blank ones are skipped. */
    fun import(ctx: Context, text: String): String {
        val keys = HashMap<String, String>()
        val models = HashMap<String, String>()
        val extras = HashMap<String, ArrayList<String>>()
        var provider = ""
        var base = ""
        var auto: Boolean? = null
        var routerNotes = ""
        val t = text.trim()
        if (t.startsWith("{")) {
            val root = try { JSONObject(t) } catch (e: Exception) { return "This does not look like a keys file." }
            if (root.optString("app") != "AnjooAI" || root.optString("type") != "keys") return "This does not look like an Anjoo keys file."
            root.optJSONObject("keys")?.let { o -> for (id in IDS) o.optString(id, "").trim().takeIf { it.isNotEmpty() }?.let { keys[id] = it } }
            root.optJSONObject("models")?.let { o -> for (id in IDS) o.optString(id, "").trim().takeIf { it.isNotEmpty() }?.let { models[id] = it } }
            root.optJSONObject("more")?.let { o ->
                for (id in IDS) o.optJSONArray(id)?.let { a ->
                    for (i in 0 until a.length()) a.optString(i, "").trim().takeIf { it.isNotEmpty() }?.let { extras.getOrPut(id) { ArrayList() }.add(it) }
                }
            }
            provider = root.optString("provider", "")
            routerNotes = root.optString("router", "")
            base = root.optString("base_custom", "")
            if (root.has("autoFree")) auto = root.optBoolean("autoFree", true)
        } else {
            val props = Properties()
            try { props.load(t.byteInputStream(Charsets.UTF_8)) } catch (e: Exception) { return "This does not look like a keys file." }
            for (id in IDS) {
                props.getProperty(id, "").trim().takeIf { it.isNotEmpty() }?.let { keys[id] = it }
                props.getProperty("model_$id", "").trim().takeIf { it.isNotEmpty() }?.let { models[id] = it }
            }
            provider = props.getProperty("default_provider", "").trim()
        }
        if (keys.isEmpty()) return "No key found in the file."

        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val ed = p.edit()
        for ((id, k) in keys) ed.putString("key_$id", k)
        for ((id, l) in extras) ed.putString("keys_$id", l.filter { it != keys[id] }.distinct().joinToString("\n"))
        for ((id, m) in models) ed.putString("model_$id", m)
        if (base.isNotEmpty()) ed.putString("base_custom", base)
        auto?.let { ed.putBoolean("autoFree", it) }
        // Which AI is active: the one in the file, else keep the current one if it still has a key, else the first key found.
        val cur = p.getString("provider", "gemini") ?: "gemini"
        val pick = when {
            provider.isNotEmpty() && (keys.containsKey(provider) || Providers.savedKey(p, provider).isNotBlank()) -> provider
            Providers.savedKey(p, cur).isNotBlank() || keys.containsKey(cur) -> cur
            else -> keys.keys.first()
        }
        val pv = Providers.byId(pick)
        val key = keys[pv.id] ?: Providers.savedKey(p, pv.id)
        val model = models[pv.id] ?: Providers.savedModel(p, pv.id)
        ed.putString("provider", pv.id).putString("key", key).putString("model", model).putString("model_${pv.id}", model)
        ed.apply()
        Providers.load(p)
        Router.importJson(routerNotes)
        return "Keys restored: ${keys.size + extras.values.sumOf { it.size }} (" + keys.keys.joinToString(", ") + "). Active AI: ${pv.id}."
    }
}
