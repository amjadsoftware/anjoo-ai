package com.anjoo.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.CountDownLatch

/**
 * Settings menu and its sub-menus (voice, phone control, appearance, text size, language, about).
 * Moved out of MainActivity.kt so that file gets smaller; these are extension functions on MainActivity.
 */
internal fun MainActivity.showMenu() {
    val items = ArrayList<Pair<String, () -> Unit>>()
    items.add(section(getString(R.string.mm_setup)))
    items.add(mi("\uD83E\uDDE0  AI: " + (prefs.getString("provider", "gemini") ?: "gemini") + " / " +
        ((prefs.getString("model", "") ?: "").ifEmpty { "choose a model" }) + "\n" +
        (if (apiKey().isEmpty()) "API KEY MISSING: tap here" else "API key is set")) { showSettings() })
    items.add(section(getString(R.string.mm_display)))
    items.add(mi("Aa  Text size: " + TextScale.label(this)) { pickTextSize() })
    items.add(mi("\uD83C\uDF10  Anjoo language: " + LangPref.label(this)) { pickAnjooLanguage() })
    items.add(mi(getString(R.string.mm_appearance)) { pickTheme() })
    items.add(mi(getString(R.string.mm_live_ai_hologram_style)) { pickHologramStyle() })

    items.add(section(getString(R.string.mm_assistant)))
    items.add(mi(getString(R.string.mm_custom_instructions)) { showCustom() })
    items.add(mi(getString(R.string.mm_voice_and_language)) { voiceMenu() })
    items.add(mi(getString(R.string.mm_what_anjoo_has_learned)) { showHabits() })

    items.add(section(getString(R.string.mm_behavior)))
    items.add(toggleItem(getString(R.string.mm_show_thinking_and_commands), "showThink", true))
    items.add(toggleItem(getString(R.string.mm_skip_confirmations_call_sms_replies), "noConfirm", false))
    items.add(toggleItem(getString(R.string.mm_update_app_automatically_when_opened), "autoUpdate", true))
    items.add(toggleItem(getString(R.string.mm_proactive_suggestions), "habits", true))
    items.add(toggleItem(getString(R.string.mm_ai_self_check_failure_alerts), "modelHealthAlerts", true))
    items.add(section(getString(R.string.mm_connections)))
    items.add(mi(getString(R.string.mm_ai_models_and_keys_api)) {
        menu("AI models and keys", listOf(
            mi(getString(R.string.mm_api_key_and_model)) { showSettings() },
            mi(getString(R.string.mm_models_aur_keys_health)) { showModelMap() },
            mi(getString(R.string.mm_export_real_model_report)) { exportModelReportMenu() }))
    })
    items.add(mi(getString(R.string.mm_telegram)) { Telegram.showSettings(this) })

    items.add(section(getString(R.string.mm_phone)))
    items.add(mi("🛡  Permissions and status\n" + PermissionsActivity.quick(this)) { startActivity(Intent(this, PermissionsActivity::class.java)) })
    items.add(mi(getString(R.string.mm_phone_control)) { phoneMenu() })

    items.add(section(getString(R.string.mm_data_and_privacy)))
    items.add(mi("📁  Anjoo AI folder\n" + (if (Vault.ready(this)) "ON" else "off: allow All files access")) { vaultMenu() })
    items.add(mi(getString(R.string.mm_backup_and_restore)) {
        menu("Backup and restore", listOf(
            mi(getString(R.string.mm_export_backup)) { exportBackup() },
            mi(getString(R.string.mm_import_backup)) { importBackup() },
            toggleItem(getString(R.string.mm_auto_backup_every_3_days), "autoBackup", true)))
    })

    items.add(section("Advanced"))
    items.add(mi("🛠  Advanced\nmodes, models, keys, export, projects, starred, connectors, tools hub, style, effort") { plusMenu() })
    items.add(mi("⭐  Starred answers") { showStars() })
    items.add(mi("📄  Export this chat (PDF, Word, text)") { exportChat() })
    items.add(mi("🗂  Add this chat to a project") { projectMenu(ChatStore.currentId(this)) })
    items.add(section(getString(R.string.mm_about)))
    items.add(mi("ℹ️  About Anjoo AI\nVersion " + BuildConfig.VERSION_NAME.substringBefore(" (")) { showAbout() })
    menu("Settings", items)
}

/** Text size picker: saves the choice and reloads the screen so every label changes. */
internal fun MainActivity.pickTextSize() {
    AlertDialog.Builder(this)
        .setTitle(getString(R.string.mm_text_size))
        .setSingleChoiceItems(TextScale.labels, TextScale.index(this)) { d, i ->
            d.dismiss()
            if (i != TextScale.index(this)) {
                TextScale.set(this, i)
                Toast.makeText(this, "Text size: " + TextScale.labels[i], Toast.LENGTH_SHORT).show()
                recreate()
            }
        }
        .setNegativeButton("Cancel", null)
        .show()
}

internal fun MainActivity.pickAnjooLanguage() {
    val langs = LangPref.ALL
    val labels = langs.map { "${it.label}  ${it.nativeLabel}".trim() }.toTypedArray()
    val cur = langs.indexOfFirst { it.key == LangPref.get(this) }.coerceAtLeast(0)
    AlertDialog.Builder(this)
        .setTitle(getString(R.string.mm_anjoo_language))
        .setSingleChoiceItems(labels, cur) { d, i ->
            LangPref.set(this, langs[i].key)
            d.dismiss()
            Toast.makeText(this, "Language: " + LangPref.label(this), Toast.LENGTH_SHORT).show()
        }
        .setNegativeButton("Cancel", null)
        .show()
}

/** After a failed answer, offers a one-tap way to the Settings that fix key / model / limit problems. */
internal fun MainActivity.offerFix(e: Throwable) {
    var t: Throwable? = e
    var code = 0
    var depth = 0
    while (t != null && depth++ < 6) {
        if (t is ApiException) { code = t.code; break }
        t = t.cause
    }
    if (code != 401 && code != 403 && code != 404 && code != 429) return
    if (isFinishing) return
    val msg = when (code) {
        401, 403 -> "The API key looks invalid or disabled. Enter a correct key now?"
        404 -> "The model or Base URL looks wrong. Open Settings?"
        else -> "The provider's limit has been reached. Choose another key or another model?"
    }
    AlertDialog.Builder(this)
        .setTitle(getString(R.string.mm_masla_hal_karein))
        .setMessage(msg)
        .setPositiveButton("Open Settings") { _, _ -> showSettings() }
        .setNegativeButton("Later", null)
        .show()
}

internal fun MainActivity.showAbout() {
    val v = BuildConfig.VERSION_NAME.substringBefore(" (")
    val msg = "Version $v  (build ${BuildConfig.VERSION_CODE})\n\n" +
        "Talk. Chat. Create. Code.\n\n" +
        "ChatGPT, Gemini, Claude and other AIs in one app: chat, voice, code, documents and phone actions.\n\n" +
        "Made with ❤️ by Anjoo AI"
    AlertDialog.Builder(this).setTitle(getString(R.string.mm_anjoo_ai)).setMessage(msg).setPositiveButton("OK", null).show()
}

internal fun MainActivity.voiceMenu() {
    val engine = prefs.getString("engine", "live") ?: "live"
    val engineLabel = when (engine) { "live" -> "Gemini Live (recommended)"; "ear" -> "Always-on (Gemini STT)"; else -> "Google speech" }
    val items = ArrayList<Pair<String, () -> Unit>>()
    items.add(section(getString(R.string.mm_jarvis_mode)))
    items.add(mi(if (prefs.getBoolean("jarvisMode", false)) "🟢 JARVIS Mode is ON — turn off" else "⚡ Activate JARVIS Mode") {
        setJarvisMode(!prefs.getBoolean("jarvisMode", false))
    })
    items.add(section(getString(R.string.mm_speaking)))
    items.add(mi("🗣️  Assistant voice: " + (GeminiVoice.voiceFor(this))) { pickVoice() })
    items.add(toggleItem(getString(R.string.mm_natural_ai_voice), "human", true))
    items.add(toggleItem(getString(R.string.mm_read_chat_replies_aloud), "autoSpeak", false))
    items.add(toggleItem(getString(R.string.mm_read_new_messages_aloud), "notifread", true))

    items.add(section(getString(R.string.mm_listening)))
    items.add(mi("🌐  Speech language: " + langName(lang)) { toggleLang() })
    items.add(mi("🎧  Listening engine: $engineLabel (tap to change)") {
        val next = when (engine) { "live" -> "google"; "google" -> "ear"; else -> "live" }
        prefs.edit().putString("engine", next).apply()
        val label = when (next) { "live" -> "Gemini Live"; "ear" -> "Always-on Gemini STT"; else -> "Google speech" }
        Toast.makeText(this, "Listening engine set to $label. Restart live voice to apply.", Toast.LENGTH_SHORT).show()
    })
    items.add(toggleItem(getString(R.string.mm_wake_word_anjoo), "wake", false))

    items.add(section(getString(R.string.mm_live_voice_display)))
    items.add(toggleItem(getString(R.string.mm_live_orb_gol_transparent_orb), "liveOrbEnabled", true))
    items.add(toggleItem(getString(R.string.mm_hologram_tasveer_default_off), LiveVisual.PREF_HOLO, false))
    items.add(toggleItem(getString(R.string.mm_floating_buddy_character), "bubble", true))

    items.add(section(getString(R.string.mm_voice_multimodal_health)))
    items.add(mi(getString(R.string.mm_voice_multimodal_readiness_report)) {
        val checks = VoiceMultimodal.report(this)
        AlertDialog.Builder(this).setTitle(getString(R.string.mm_voice_multimodal))
            .setMessage(checks)
            .setPositiveButton("Test voice") { _, _ -> speakIdle("Hello! I am Anjoo. Voice test successful.") }
            .setNeutralButton("OK", null).show()
    })
    items.add(mi(getString(R.string.mm_last_voice_error)) {
        val e = GeminiVoice.lastError
        AlertDialog.Builder(this).setTitle(getString(R.string.mm_voice_status))
            .setMessage(if (e.isEmpty()) "Natural voice has not reported any error yet. This is not a guarantee of live provider availability." else "Aakhri error: " + e +
                "\n\n429 is usually a rate/quota limit. For 400/403, check the key, model access or request configuration.")
            .setPositiveButton("OK", null).show()
    })
    menu("Voice and language", items)
}

/** Applies a single, reversible assistant preset. Android permissions remain user-controlled. */
internal fun MainActivity.setJarvisMode(enabled: Boolean) {
    prefs.edit()
        .putBoolean("jarvisMode", enabled)
        .putBoolean("wake", enabled)
        .putBoolean("human", true)
        .putBoolean("autoSpeak", enabled)
        .putBoolean("notifread", enabled)
        .putBoolean("liveOrbEnabled", enabled)
        .putBoolean("bubble", enabled)
        .putBoolean("showThink", true)
        .putBoolean("habits", enabled)
        .putString("engine", if (enabled) "live" else "google")
        .apply()
    if (enabled) {
        Toast.makeText(this, getString(R.string.mm_jarvis_mode_enabled_wake_word), Toast.LENGTH_LONG).show()
        if (VoiceService.running) {
            startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
            ui.postDelayed({ toggleBackground() }, 700)
        } else {
            toggleBackground()
        }
    } else {
        if (VoiceService.running) startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP))
        Toast.makeText(this, getString(R.string.mm_jarvis_mode_disabled_and_background), Toast.LENGTH_LONG).show()
        ui.postDelayed({ refreshSend() }, 400)
    }
}

internal fun MainActivity.phoneMenu() {
    val items = ArrayList<Pair<String, () -> Unit>>()
    items.add(section(getString(R.string.mm_permissions)))
    items.add(mi(getString(R.string.mm_grant_permissions)) { requestPermissions(permissionList(), 1) })
    items.add(mi(getString(R.string.mm_accessibility_typing_taps)) { openAccess() })
    items.add(mi(getString(R.string.mm_notification_access)) {
        try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (e: Exception) { Oops.note(this@phoneMenu, "Could not open this screen. Please open it from the phone's Settings.", e) }
    })
    items.add(mi(getString(R.string.mm_exact_alarms_reminders)) {
        if (Build.VERSION.SDK_INT >= 31) {
            try { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) } catch (e: Exception) { Oops.note(this@phoneMenu, "Could not open this screen. Please open it from the phone's Settings.", e) }
        }
    })

    items.add(section(getString(R.string.mm_files)))
    items.add(mi(getString(R.string.mm_storage_access)) { startActivity(Intent(this, StorageActivity::class.java)) })
    items.add(mi("📂  Default save folder: " + FileAccess.defaultLabel(this)) { startActivity(Intent(this, FolderPickerActivity::class.java).putExtra("setDefault", true)) })

    items.add(section(getString(R.string.mm_display)))
    items.add(toggleItem(getString(R.string.mm_floating_buddy_character_when_app), "bubble", true))
    menu("Phone control", items)
}

internal fun MainActivity.showCustom() {
    val et = EditText(this).apply {
        setText(prefs.getString("custom", "") ?: "")
        hint = "e.g. Call me Ali. Reply in Roman Urdu. Keep answers short."
        minLines = 4; gravity = Gravity.TOP or Gravity.START
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
    }
    val box = LinearLayout(this).apply { setPadding(dp(20), dp(8), dp(20), 0); addView(et, LinearLayout.LayoutParams(-1, -2)) }
    AlertDialog.Builder(this).setTitle(getString(R.string.mm_custom_instructions_2))
        .setMessage(getString(R.string.mm_tell_anjoo_about_you_and))
        .setView(box)
        .setPositiveButton("Save") { _, _ -> prefs.edit().putString("custom", et.text.toString().trim()).apply() }
        .setNegativeButton("Cancel", null).show()
}

internal fun MainActivity.pickTheme() {
    AlertDialog.Builder(this)
        .setTitle(getString(R.string.mm_appearance_2))
        .setItems(Style.themes.map { it.name }.toTypedArray()) { _, i ->
            themeIdx = i
            prefs.edit().putInt("theme", i).apply()
            rebuild()
        }.show()
}

internal fun MainActivity.pickHologramStyle() {
    val names = HoloAgentView.styles.map { it.label }.toTypedArray()
    val selected = prefs.getInt("holoAgentStyle", 0).coerceIn(0, names.lastIndex)
    AlertDialog.Builder(this)
        .setTitle(getString(R.string.mm_live_ai_agent_appearance))
        .setSingleChoiceItems(names, selected) { dialog, which ->
            prefs.edit().putInt("holoAgentStyle", which).apply()
            liveHolo?.invalidate()
            try {
                if (VoiceService.running) VoiceService.inst?.refreshOrbVisibility()
            } catch (_: Exception) {}
            Toast.makeText(this, "Hologram style: ${names[which]}", Toast.LENGTH_SHORT).show()
            dialog.dismiss()
        }
        .setNegativeButton("Cancel", null)
        .show()
}

internal fun MainActivity.pickVoice() {
    val all = GeminiVoice.FEMALE + GeminiVoice.MALE
    val cur = GeminiVoice.voiceFor(this)
    val current = all.indexOfFirst { it.first == cur }.coerceAtLeast(0)
    AlertDialog.Builder(this)
        .setTitle(getString(R.string.mm_assistant_voice_tap_to_hear))
        .setSingleChoiceItems(all.map { it.second }.toTypedArray(), current) { _, which ->
            val name = all[which].first
            prefs.edit().putString("voiceName", name)
                .putString("voiceGender", if (GeminiVoice.isMale(name)) "male" else "female").apply()
            tts?.stop(); GeminiVoice.stop()
            Handler(Looper.getMainLooper()).postDelayed({
                speakIdle("Hello! I am Anjoo. How do you like my voice?")
            }, 250)
        }
        .setPositiveButton("Done", null)
        .show()
}

internal fun MainActivity.toggleLang() {
    lang = when (lang) { "ur-PK" -> "en-US"; "en-US" -> "auto"; else -> "ur-PK" }
    prefs.edit().putString("lang", lang).apply()
    Toast.makeText(this, "Speech language: " + langName(lang), Toast.LENGTH_SHORT).show()
}

/** One place for every tool. The side drawer lists only chats, so the app stays one chat screen. */
internal fun MainActivity.workspaceMenu() {
    val items = ArrayList<Pair<String, () -> Unit>>()
    items.add(mi(getString(R.string.ws_codixa)) { startActivity(Intent(this, CodixaActivity::class.java)) })
    items.add(mi(getString(R.string.ws_hs)) { startActivity(Intent(this, HSActivity::class.java)) })
    items.add(mi(getString(R.string.ws_website)) { askWebsite() })
    items.add(mi(getString(R.string.ws_artifacts, Artifacts.list(this).size)) { startActivity(Intent(this, ArtifactActivity::class.java)) })
    items.add(mi(getString(R.string.ws_tasks)) { startActivity(Intent(this, TasksActivity::class.java)) })
    items.add(mi(getString(R.string.ws_notes)) { startActivity(Intent(this, NotesActivity::class.java)) })
    items.add(mi(getString(R.string.ws_tools_hub)) { startActivity(Intent(this, ToolsActivity::class.java)) })
    items.add(mi(getString(R.string.mm_agent_system_autonomous_runs_checkpoints)) {
        AlertDialog.Builder(this).setTitle(getString(R.string.mm_agent_system))
            .setMessage(AgentOrchestrator.dashboard(this))
            .setPositiveButton("Open Task Board") { _, _ -> startActivity(Intent(this, TasksActivity::class.java)) }
            .setNegativeButton("Close", null).show()
    })
    items.add(mi(getString(R.string.mm_website_builder_pichla_kaam_jari)) { submit("Continue the previous website work from where it stopped using website_builder action=continue, and tell me the status.") })
    if (Studio.files(this).isNotEmpty()) items.add(mi(getString(R.string.mm_older_pages_and_code)) { showStudio() })

    items.add(mi(getString(R.string.ws_trash)) { trashMenu() })
    items.add(mi(getString(R.string.ws_timeline)) { timelineMenu() })
    menu(getString(R.string.ws_title), items)
}

private fun agoText(t: Long): String {
    val s = (System.currentTimeMillis() - t) / 1000
    return when {
        s < 60 -> "just now"
        s < 3600 -> (s / 60).toString() + " min ago"
        s < 86400 -> (s / 3600).toString() + " h ago"
        else -> (s / 86400).toString() + " d ago"
    }
}

/** Undo for deleted notes and tasks (kept 14 days). Tap an item to put it back. */
internal fun MainActivity.trashMenu() {
    val list = Trash.list(this)
    val items = ArrayList<Pair<String, () -> Unit>>()
    if (list.isEmpty()) items.add(mi(getString(R.string.tr_empty)) {})
    for ((i, item) in list.withIndex()) {
        val icon = if (item.kind == "note") "\uD83D\uDCDD" else "\uD83D\uDCCB"
        val title = item.title.ifBlank { "(untitled)" }
        items.add(mi(icon + "  Restore: " + title + "\nDeleted " + agoText(item.at)) {
            Toast.makeText(this, Trash.restore(this, i), Toast.LENGTH_LONG).show()
        })
    }
    menu(getString(R.string.tr_title), items)
}

/** What Anjoo did on the phone, newest first, with the real result of each tool run. */
internal fun MainActivity.timelineMenu() {
    val list = ToolRunLog.entries(this)
    val items = ArrayList<Pair<String, () -> Unit>>()
    if (list.isEmpty()) items.add(mi(getString(R.string.tl_empty)) {})
    for (e in list.take(40)) {
        val icon = when (e.status) {
            "DONE" -> "\u2705"
            "CANCELLED" -> "\u23F9"
            "ISSUE" -> "\u26A0\uFE0F"
            else -> "\u2139\uFE0F"
        }
        val name = e.name.replace('_', ' ')
        items.add(mi(icon + "  " + name + "\n" + e.status.lowercase().replace('_', ' ') + "  \u00B7  " + agoText(e.at)) {})
    }
    if (list.isNotEmpty()) items.add(mi(getString(R.string.tl_clear)) {
        ToolRunLog.clear(this)
        Toast.makeText(this, "Timeline cleared", Toast.LENGTH_SHORT).show()
    })
    menu(getString(R.string.tl_title), items)
}
