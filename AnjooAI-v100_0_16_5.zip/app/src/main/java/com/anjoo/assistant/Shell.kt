package com.anjoo.assistant

import android.content.Context
import android.os.Environment
import org.json.JSONObject
import java.io.File

/**
 * The Bash-like tool: runs one shell command on the phone (Android's own sh and toolbox: ls, cat, grep, ps, df, ping, getprop...).
 * Always asks the user first, runs inside Anjoo's sandbox (or a chosen Code Studio project / phone folder), has a time limit,
 * and refuses destructive or privileged commands.
 */
object Shell {
    private val BLOCK = listOf(
        Regex("(^|[;&|(]\\s*)(su|sudo)\\b"),
        Regex("\\brm\\s+(-[A-Za-z]+\\s+)*(/|/\\*|/sdcard/?\\*?|/storage(/emulated(/0)?)?/?\\*?|~/?\\*?|\\.\\./?)(\\s|$)"),
        Regex("\\b(mkfs\\S*|reboot|shutdown|poweroff|wipe|fastboot|recovery)\\b"),
        Regex("\\bdd\\s+[^|;]*\\bof=/dev/"),
        Regex(":\\(\\)\\s*\\{"),
        Regex("\\b(pm|cmd\\s+package)\\s+(uninstall|clear|disable|hide|suspend)\\b"),
        Regex("\\b(settings\\s+put|svc\\s+(wifi|data|power)|am\\s+(kill|force-stop|broadcast)|input\\s+keyevent)\\b"),
        Regex("\\bchmod\\s+-R\\s+\\d+\\s+/(\\s|$)")
    )

    private fun workDir(ctx: Context, cwd: String): Pair<File?, String> {
        val home = File(ctx.filesDir, "shell").also { it.mkdirs() }
        if (cwd.isBlank()) return Pair(home, "")
        if (cwd.startsWith("project:")) {
            val d = Coder.projectDir(ctx, cwd.removePrefix("project:").trim())
            return if (d.isDirectory) Pair(d, "") else Pair(null, "No such Code Studio project found: " + cwd.removePrefix("project:"))
        }
        if (!FileAccess.allFiles(ctx)) return Pair(null, "Running commands in a phone folder needs 'All files access' (storage_setup). Or leave cwd empty / pass project:<name>.")
        val parts = cwd.replace('\\', '/').split('/').filter { it.isNotBlank() && it != "." }
        if (parts.any { it == ".." } || parts.firstOrNull().equals("Android", true)) return Pair(null, "This cwd is invalid.")
        if (Sandbox.on(ctx) && !Sandbox.inside(parts)) return Pair(null, Sandbox.DENY_CODE)
        val d = File(Environment.getExternalStorageDirectory(), parts.joinToString("/"))
        return if (d.isDirectory) Pair(d, "") else Pair(null, "Folder not found: " + d.absolutePath)
    }

    /** Runs the command and returns "EXIT n" plus its output (stdout and stderr together). */
    fun run(ctx: Context, a: JSONObject, confirm: (String) -> Boolean): String {
        val cmd = a.optString("command").trim()
        if (cmd.isEmpty()) return "command do."
        if (cmd.length > 2000) return "The command is too long."
        if (Guard.hasCardData(cmd)) return Guard.CARD_MSG
        for (b in BLOCK) if (b.containsMatchIn(cmd)) return "This command is dangerous or privileged (delete-all, root, reboot, disabling settings/apps, etc.); I will not run it. If needed, give a short, clear command."
        val lockOn = Sandbox.on(ctx)
        if (lockOn && Sandbox.touchesPhone(cmd)) return Sandbox.DENY_CODE
        val (dir, err) = workDir(ctx, a.optString("cwd", "").trim())
        if (dir == null) return err
        if (lockOn && dir.absolutePath.startsWith(Environment.getExternalStorageDirectory().absolutePath) && (cmd.contains("..") || cmd.contains("~"))) return Sandbox.DENY_CODE
        val secs = a.optInt("timeout_sec", 20).coerceIn(1, 60)
        if (!confirm(Confirm.msg("shell", "Run this command on the phone?", "$ " + cmd + "\nfolder: " + dir.absolutePath + "\nlimit: " + secs + "s"))) return "The user declined to run the command."
        return try {
            val pb = ProcessBuilder("/system/bin/sh", "-c", cmd).directory(dir).redirectErrorStream(true)
            pb.environment()["HOME"] = ctx.filesDir.absolutePath
            pb.environment()["PATH"] = "/system/bin:/system/xbin:" + (pb.environment()["PATH"] ?: "")
            val p = pb.start()
            try { p.outputStream.close() } catch (e: Exception) {}
            val out = StringBuilder()
            val reader = Thread {
                try {
                    p.inputStream.bufferedReader().use { r ->
                        val buf = CharArray(4096)
                        while (true) { val n = r.read(buf); if (n < 0) break; if (out.length < 60000) out.append(buf, 0, n) }
                    }
                } catch (e: Exception) {}
            }
            reader.start()
            val waiter = Thread { try { p.waitFor() } catch (e: Exception) {} }
            waiter.start()
            waiter.join(secs * 1000L)
            val timedOut = waiter.isAlive
            if (timedOut) { try { p.destroy() } catch (e: Exception) {} }
            reader.join(1500)
            val txt = out.toString().trim()
            val shownOut = if (txt.length > 6000) txt.take(2500) + "\n...[middle part trimmed]...\n" + txt.takeLast(3000) else txt
            val head = if (timedOut) "TIMEOUT: command " + secs + "s limit reached; stopped." else "EXIT " + (try { p.exitValue() } catch (e: Exception) { -1 })
            head + "\n" + (if (shownOut.isEmpty()) "(no output)" else shownOut)
        } catch (e: Exception) { "The command could not run: " + (e.message ?: e.javaClass.simpleName) }
    }
}
