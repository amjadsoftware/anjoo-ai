package com.anjoo.assistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.speech.SpeechRecognizer

/** Capability and readiness report for voice and multimodal features. Reports device facts, not guesses. */
object VoiceMultimodal {
    data class Check(val name: String, val ready: Boolean, val detail: String)

    fun checks(ctx: Context): List<Check> {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val mic = ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val googleStt = try { SpeechRecognizer.isRecognitionAvailable(ctx) } catch (_: Exception) { false }
        val cloudStt = Stt.available(p)
        val geminiKey = Providers.geminiKey(p).isNotBlank()
        val cloudTts = CloudVoice.engine(p) != null
        val human = GeminiVoice.enabled(ctx)
        val engine = p.getString("engine", "live") ?: "live"
        val liveReady = geminiKey && mic
        return listOf(
            Check("Microphone permission", mic, if (mic) "Granted" else "Allow microphone in Android app permissions"),
            Check("Google speech recognition", googleStt, if (googleStt) "Installed and available on this device" else "No Android speech recognition service detected"),
            Check("Cloud speech-to-text", cloudStt, if (cloudStt) "Groq Whisper or Gemini key configured" else "Add Groq or Gemini API key for cloud transcription"),
            Check("Gemini Live conversation", liveReady, when { !mic -> "Microphone permission required"; !geminiKey -> "Gemini API key required"; else -> "Ready to connect; provider quota/network still apply" }),
            Check("Natural cloud text-to-speech", human && (geminiKey || cloudTts), when { !human -> "Natural AI voice is switched off"; geminiKey || cloudTts -> "Gemini, ElevenLabs or Azure voice key configured"; else -> "Add Gemini, ElevenLabs or Azure Speech key" }),
            Check("On-device text-to-speech", true, "Android TTS fallback is available; installed Urdu voice depends on device"),
            Check("Current listening engine", true, when (engine) { "live" -> "Gemini Live selected"; "ear" -> "Always-on cloud STT selected"; else -> "Google speech selected" }),
            Check("Image understanding", true, "Image attachments can be sent to a vision-capable chat model; provider/model support required"),
            Check("Image generation and editing", geminiKey, if (geminiKey) "Gemini image provider key detected; model access is still provider-controlled" else "Configure a supported image-generation provider"),
            Check("Documents and knowledge", true, "Supported document attachments and local Knowledge Base are available"),
            Check("Audio/video file understanding", false, "Live microphone/audio transcription is supported; direct arbitrary video-file understanding is not advertised as ready")
        )
    }

    fun report(ctx: Context): String = buildString {
        append("VOICE & MULTIMODAL READINESS\n\n")
        checks(ctx).forEach { c ->
            append(if (c.ready) "✓ " else "! ").append(c.name).append("\n  ").append(c.detail).append("\n\n")
        }
        append("Privacy: Live voice and cloud transcription send audio to the selected provider. Check provider terms and your API usage before enabling continuous listening.")
    }
}
