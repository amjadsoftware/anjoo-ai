package com.anjoo.assistant

import android.content.Context
import android.content.res.Configuration

/**
 * User-chosen text size. Applied to every screen by wrapping the base context
 * (see attachBaseContext in each Activity), so all sp text scales together.
 */
object TextScale {
    const val KEY = "text_scale_idx"
    val labels = arrayOf("Chhota", "Normal", "Bara", "Bohat bara")
    val scales = floatArrayOf(0.88f, 1.0f, 1.15f, 1.3f)
    const val DEFAULT_IDX = 1

    fun index(ctx: Context): Int = try {
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
            .getInt(KEY, DEFAULT_IDX).coerceIn(0, scales.size - 1)
    } catch (e: Exception) { DEFAULT_IDX }

    fun label(ctx: Context): String = labels[index(ctx)]

    fun set(ctx: Context, idx: Int) {
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
            .edit().putInt(KEY, idx.coerceIn(0, scales.size - 1)).apply()
    }

    /** Returns a context whose fontScale = phone's font scale x the user's choice. */
    fun wrap(base: Context): Context {
        return try {
            val s = scales[index(base)]
            if (s == 1.0f) return base
            val cfg = Configuration(base.resources.configuration)
            cfg.fontScale = (cfg.fontScale * s).coerceIn(0.7f, 2.0f)
            base.createConfigurationContext(cfg)
        } catch (e: Exception) { base }
    }
}
