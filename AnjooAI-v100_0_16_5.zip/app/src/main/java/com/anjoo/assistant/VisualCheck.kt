package com.anjoo.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Looks at the finished website the way a person would: renders the pages at phone width, takes screenshots and has a
 * vision model report only clear visual defects (overlapping or cut-off text, unreadable contrast, empty boxes, broken
 * layout). Real defects are fixed once with small edits. It never blocks a build: if screenshots or the vision model are
 * not available it says so and moves on.
 */
object VisualCheck {

    private const val MODEL = "gemini-3.8-flash"
    private const val CSS_W = 390
    private const val CSS_H = 844

    /** Up to 3 phone-sized screens of one page, stacked top to bottom, or null when nothing real was drawn. */
    private fun shoot(ctx: Context, dir: File, page: String?): Bitmap? {
        val density = ctx.resources.displayMetrics.density.coerceAtLeast(1f)
        val wpx = (CSS_W * density).toInt()
        val hpx = (CSS_H * density).toInt()
        val main = Handler(Looper.getMainLooper())
        val latch = CountDownLatch(1)
        var wv: WebView? = null
        var out: Bitmap? = null
        main.post {
            try {
                val w = ProjectWeb.create(ctx.applicationContext, dir)
                wv = w
                w.layout(0, 0, wpx, hpx)
                ProjectWeb.load(w, page)
            } catch (_: Exception) { latch.countDown() }
        }
        Cancel.sleep(4200)
        main.post {
            try {
                val w = wv
                if (w != null) {
                    val contentPx = (w.contentHeight * density).toInt()
                    val n = ((contentPx + hpx - 1) / hpx).coerceIn(1, 3)
                    val stack = Bitmap.createBitmap(CSS_W, CSS_H * n, Bitmap.Config.ARGB_8888)
                    val sc = Canvas(stack)
                    for (i in 0 until n) {
                        w.scrollTo(0, i * hpx)
                        val tile = Bitmap.createBitmap(wpx, hpx, Bitmap.Config.ARGB_8888)
                        w.draw(Canvas(tile))
                        val small = Bitmap.createScaledBitmap(tile, CSS_W, CSS_H, true)
                        sc.drawBitmap(small, 0f, (i * CSS_H).toFloat(), null)
                        tile.recycle(); small.recycle()
                    }
                    out = if (looksDrawn(stack)) stack else null
                    w.destroy()
                }
            } catch (_: Exception) {
            } finally { latch.countDown() }
        }
        latch.await(25, TimeUnit.SECONDS)
        return out
    }

    /** A blank capture (offscreen drawing not supported on this phone) has almost one single colour. */
    private fun looksDrawn(b: Bitmap): Boolean {
        val first = b.getPixel(2, 2)
        var different = 0
        var tries = 0
        val stepX = (b.width / 14).coerceAtLeast(1)
        val stepY = (b.height / 40).coerceAtLeast(1)
        var y = 0
        while (y < b.height) {
            var x = 0
            while (x < b.width) { tries++; if (b.getPixel(x, y) != first) different++; x += stepX }
            y += stepY
        }
        return tries > 0 && different * 100 / tries >= 3
    }

    private fun b64(b: Bitmap): String {
        val bo = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 72, bo)
        return android.util.Base64.encodeToString(bo.toByteArray(), android.util.Base64.NO_WRAP)
    }

    fun run(ctx: Context, dir: File, plan: JSONObject?, say: (String) -> Unit): String {
        if (BgDrain.inBackground) return "Visual check skipped: screenshots are not taken in the background; open the app and run again."
        val prefs = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val key = Providers.geminiKey(prefs)
        if (key.isEmpty()) return "Visual check skipped: a Google Gemini key is needed to understand screenshots (Settings)."
        val pages = PreviewServer.pages(dir).filter { it.lowercase().endsWith(".html") && !it.lowercase().startsWith("docs/") }.take(3)
        if (pages.isEmpty()) return "Visual check skipped: no HTML page found."
        val found = ArrayList<String>()
        var checked = 0
        var blank = 0
        for ((i, page) in pages.withIndex()) {
            say("Visual check " + (i + 1) + "/" + pages.size + " · " + page + " phone screenshot...")
            val shot = try { shoot(ctx, dir, if (i == 0) null else page) } catch (e: CancelledException) { throw e } catch (_: Exception) { null }
            if (shot == null) { blank++; continue }
            val ask = "These are consecutive phone-width screenshots (top to bottom) of the page '$page' of a website just built. " +
                "Report ONLY clear visual defects a visitor would notice: text overlapping other text or images, text cut off or unreadable (very low contrast), " +
                "large empty or grey boxes where an image should be, elements sticking out sideways, a broken or collapsed layout, buttons too small to tap. " +
                "Do not comment on taste, spacing preferences or missing content. Reply with JSON only: {\"ok\":true} or " +
                "{\"issues\":[{\"problem\":\"what is wrong and where\",\"fix\":\"the small change that fixes it\"}]} with at most 4 issues."
            val parts = JSONArray().put(JSONObject().put("text", ask))
                .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64(shot))))
            val reply = try { Gemini.plain(key, MODEL, "You are a careful web QA reviewer who looks at screenshots.", parts, 1200, 0.1, true) } catch (e: CancelledException) { throw e } catch (_: Exception) { "" }
            shot.recycle()
            if (reply.isBlank()) continue
            checked++
            try {
                val j = JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
                val arr = j.optJSONArray("issues")
                if (arr != null) for (k in 0 until arr.length()) {
                    val o = arr.optJSONObject(k) ?: continue
                    found.add(page + ": " + o.optString("problem") + " -> " + o.optString("fix"))
                }
            } catch (_: Exception) { }
        }
        if (checked == 0)
            return if (blank > 0) "Visual check skipped: a screenshot could not be taken on this phone; the other checks passed."
            else "Visual check skipped: the vision model did not answer."
        if (found.isEmpty()) return "Visual check: viewed $checked page(s) at phone width, no clear visual defect found."
        say("Visual check: " + found.size + " defect(s) found, fixing...")
        val instr = "A visual review of the finished website (phone screenshots) found these clear defects. Fix exactly these with small edits and change nothing else:\n" +
            found.joinToString("\n") { "- $it" }
        val res = try { Coder.revise(ctx, dir, instr, Coder.deepDefault(ctx), {}, { n -> say("Visual fix · $n") }) } catch (e: CancelledException) { throw e } catch (e: Exception) { "ERR: " + (e.message ?: "") }
        return "Visual check: " + found.size + " defect(s) found and a fix was attempted:\n" + found.joinToString("\n") { "- " + it.take(160) } +
            (if (res.startsWith("ERR:")) "\n(the fix could not be applied: " + res.take(100) + ")" else "")
    }
}
