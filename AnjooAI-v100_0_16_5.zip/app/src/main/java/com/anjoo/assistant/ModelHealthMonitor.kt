package com.anjoo.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.security.MessageDigest

/**
 * On-device model-health observer. It alerts only on repeated, measured API failures
 * and never mistakes quota/key/server errors for proof that a model is unintelligent.
 * No prompts, API keys, or raw provider responses are included in notifications.
 */
object ModelHealthMonitor {
    private const val CHANNEL = "anjoo_model_health"
    @Volatile private var app: Context? = null

    fun bind(ctx: Context) {
        val c = ctx.applicationContext
        app = c
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = c.getSystemService(NotificationManager::class.java)
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "Anjoo AI model health", NotificationManager.IMPORTANCE_DEFAULT).apply {
                    description = "Alerts when an AI connection repeatedly fails or recovers"
                })
            }
        } catch (_: Exception) {}
    }

    private fun token(provider: String, model: String): String = try {
        MessageDigest.getInstance("SHA-256").digest((provider + "|" + model).toByteArray(Charsets.UTF_8))
            .take(8).joinToString("") { "%02x".format(it) }
    } catch (_: Exception) { (provider + model).hashCode().toUInt().toString(16) }

    private fun issue(code: Int): Pair<String, String> = when (code) {
        401, 403 -> "API key / permission issue" to "The provider refused the key or access. Check the key and model access in Settings; do not treat this as a score of the model's intelligence."
        404 -> "Model / endpoint not found" to "The provider could not find this model or endpoint. Check the model name or custom base URL."
        429 -> "Provider limit reached" to "This provider's rate/quota limit is being hit. Use another provider or wait for the limit to reset."
        400, 422 -> "Request compatibility issue" to "This model may not accept this request's format/tool. Try another compatible model."
        408 -> "Request timed out" to "The server did not answer in time. Check the network and try again."
        in 500..599 -> "Provider server unstable" to "The provider server returned repeated errors. Try again in a little while or use another provider."
        else -> "Connection / transport issue" to "The AI connection failed repeatedly. Check the internet, the provider status and Settings."
    }

    /** Called by Router after the third consecutive failed attempt for one model. */
    fun onRepeatedFailure(provider: String, model: String, code: Int, consecutive: Int) {
        val c = app ?: return
        if (consecutive < 3) return
        val prefs = c.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("modelHealthAlerts", true)) return
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val id = token(provider, model)
        val now = System.currentTimeMillis()
        val throttle = "mh_alert_at_$id"
        if (now - prefs.getLong(throttle, 0L) < 8L * 60 * 60 * 1000) return
        val (title, advice) = issue(code)
        val modelShort = model.substringAfterLast('/').take(75)
        val body = "$modelShort · $consecutive consecutive failures. $advice"
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            val open = PendingIntent.getActivity(c, (id.hashCode() and 0x7fffffff),
                Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_notify_error)
                .setContentTitle("The AI connection needs attention")
                .setContentText("$provider · $modelShort: $title")
                .setStyle(Notification.BigTextStyle().bigText(body))
                .setContentIntent(open).setAutoCancel(true).setCategory(Notification.CATEGORY_STATUS)
                .build()
            nm.notify((id.hashCode() and 0x7fffffff), n)
            prefs.edit().putLong(throttle, now).putBoolean("mh_alerted_$id", true).putString("mh_last_issue", "$provider · $modelShort: $title\n$advice").apply()
        } catch (_: Exception) {}
    }

    /** One recovery ping only after Anjoo previously raised an alert for the same model. */
    fun onRecovered(provider: String, model: String) {
        val c = app ?: return
        val prefs = c.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val id = token(provider, model)
        if (!prefs.getBoolean("mh_alerted_$id", false) || !prefs.getBoolean("modelHealthAlerts", true)) return
        prefs.edit().putBoolean("mh_alerted_$id", false).apply()
        if (Build.VERSION.SDK_INT >= 33 && c.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            val open = PendingIntent.getActivity(c, (id.hashCode() and 0x7fffffff),
                Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            nm.notify((id.hashCode() and 0x7fffffff), Notification.Builder(c, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_upload_done)
                .setContentTitle("The AI model is working again")
                .setContentText(provider + " · " + model.substringAfterLast('/').take(70) + " returned a successful response.")
                .setContentIntent(open).setAutoCancel(true).build())
        } catch (_: Exception) {}
    }
}
