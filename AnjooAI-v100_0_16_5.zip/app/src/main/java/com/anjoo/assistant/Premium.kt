package com.anjoo.assistant

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

/** Shared "premium" building blocks for menus: grouped cards, icon chips, switches, chevrons, ripples. */
object Premium {
    private fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    private fun tint(color: Int, alpha: Int) = Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color))
    private val neutral = Color.argb(30, 128, 128, 128)

    fun ripple(c: Context, fill: Int, radius: Int): Drawable {
        val content = GradientDrawable().apply { setColor(fill); cornerRadius = radius.toFloat() }
        val mask = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = radius.toFloat() }
        return RippleDrawable(ColorStateList.valueOf(Color.argb(46, 128, 128, 128)), content, mask)
    }

    /** Splits "icon  text" into its icon and text parts (icon = first token when it is not a letter or digit). */
    fun splitGlyph(label: String): Pair<String, String> {
        val t = label.trimStart()
        if (t.isEmpty()) return Pair("\u2022", "")
        val cp = t.codePointAt(0)
        if (Character.isLetterOrDigit(cp)) return Pair("\u2022", t)
        var i = 0
        while (i < t.length && !t[i].isWhitespace()) i++
        return Pair(t.substring(0, i), t.substring(i).trim())
    }

    fun handle(c: Context): View = View(c).apply {
        background = GradientDrawable().apply { setColor(Color.argb(70, 128, 128, 128)); cornerRadius = dp(c, 3).toFloat() }
    }

    fun closeChip(c: Context, ink: Int, onClick: () -> Unit): TextView = TextView(c).apply {
        text = "\u2715"; textSize = 14f; setTextColor(ink); gravity = Gravity.CENTER
        background = ripple(c, neutral, dp(c, 24))
        contentDescription = "Close"
        setOnClickListener { onClick() }
    }

    fun header(c: Context, title: String, accent: Int): TextView = TextView(c).apply {
        text = title.uppercase(Locale.ENGLISH); textSize = 12f; setTextColor(accent)
        letterSpacing = 0.1f; typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setPadding(dp(c, 8), dp(c, 18), dp(c, 8), dp(c, 8))
    }

    fun group(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(Color.argb(20, 128, 128, 128)); cornerRadius = dp(c, 18).toFloat()
            setStroke(dp(c, 1), Color.argb(34, 128, 128, 128))
        }
        setPadding(0, dp(c, 3), 0, dp(c, 3))
    }

    fun divider(c: Context): View = View(c).apply { setBackgroundColor(Color.argb(28, 128, 128, 128)) }

    private fun switchView(c: Context, on: Boolean, accent: Int): View = FrameLayout(c).apply {
        background = GradientDrawable().apply {
            setColor(if (on) accent else Color.argb(80, 128, 128, 128)); cornerRadius = dp(c, 14).toFloat()
        }
        val knob = View(c).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.WHITE) }
        }
        addView(knob, FrameLayout.LayoutParams(dp(c, 22), dp(c, 22),
            (if (on) Gravity.END else Gravity.START) or Gravity.CENTER_VERTICAL).apply {
            setMargins(dp(c, 3), 0, dp(c, 3), 0)
        })
        contentDescription = if (on) "On" else "Off"
    }

    /** One menu row: icon chip, title, optional muted detail line, and a switch (for On/Off items) or a chevron. */
    fun row(c: Context, label: String, ink: Int, muted: Int, accent: Int, onClick: () -> Unit): View {
        val (glyph, rest) = splitGlyph(label)
        val nl = rest.indexOf('\n')
        var title = if (nl < 0) rest else rest.substring(0, nl)
        val sub = if (nl < 0) "" else rest.substring(nl + 1).trim()
        val isOn = title.endsWith(": On")
        val isOff = title.endsWith(": Off")
        if (isOn) title = title.dropLast(4) else if (isOff) title = title.dropLast(5)

        val row = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            minimumHeight = dp(c, 56)
            setPadding(dp(c, 12), dp(c, 9), dp(c, 12), dp(c, 9))
            background = ripple(c, Color.TRANSPARENT, dp(c, 16))
            setOnClickListener { onClick() }
        }
        row.addView(TextView(c).apply {
            text = glyph; textSize = 16f; gravity = Gravity.CENTER; setTextColor(accent)
            background = GradientDrawable().apply { setColor(tint(accent, 36)); cornerRadius = dp(c, 12).toFloat() }
        }, LinearLayout.LayoutParams(dp(c, 38), dp(c, 38)).apply { rightMargin = dp(c, 12) })

        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        col.addView(TextView(c).apply {
            text = title; textSize = 15.5f; setTextColor(ink)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        if (sub.isNotEmpty()) col.addView(TextView(c).apply {
            text = sub; textSize = 12.5f; setTextColor(muted); maxLines = 2
            setPadding(0, dp(c, 2), 0, 0)
        })
        row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))

        if (isOn || isOff) {
            row.addView(switchView(c, isOn, accent), LinearLayout.LayoutParams(dp(c, 48), dp(c, 28)).apply { leftMargin = dp(c, 8) })
        } else {
            row.addView(TextView(c).apply {
                text = "\u203a"; textSize = 22f; setTextColor(muted); gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(c, 20), -2).apply { leftMargin = dp(c, 6) })
        }
        return row
    }
}
