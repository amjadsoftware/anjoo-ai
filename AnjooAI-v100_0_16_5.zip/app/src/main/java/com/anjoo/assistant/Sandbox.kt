package com.anjoo.assistant

import android.content.Context

/**
 * Privacy lock ("Anjoo folder only").
 *
 *  - Inside the "Anjoo AI" folder (and its sub-folders): Anjoo reads, writes and edits freely; everything there is encrypted.
 *  - Any other folder: Anjoo may only LOOK at the folder names, and only after you allow that folder
 *    (once per folder, until the app is closed). It never reads, opens, copies, edits or deletes the files there
 *    (documents, photos, videos...), and it can only add a new file when you ask for it and allow it.
 *  - Gallery / file-manager / video apps are off limits for screen reading and screenshots.
 *
 * On by default. The switch is in the menu: Anjoo AI folder > Privacy lock.
 */
object Sandbox {
    @Volatile var lock = true
        private set

    private const val P = "privacyLock"

    fun on(ctx: Context): Boolean {
        lock = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean(P, true)
        return lock
    }

    fun set(ctx: Context, v: Boolean) {
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit().putBoolean(P, v).apply()
        lock = v
    }

    // Folders inside "Anjoo AI" meant for taking things OUT (you open them in Word, a PDF reader, the gallery...), so they stay normal files.
    private val SHARE = setOf("documents", "downloads", "chats/exports", "images/saved")

    /** True when a file saved in [dir] (path parts without the file name) must be stored encrypted. */
    fun encrypts(dir: List<String>): Boolean {
        if (!inside(dir)) return false
        val rest = dir.drop(1).map { it.lowercase() }
        if (rest.isEmpty()) return true
        return !(rest[0] in SHARE || rest.take(2).joinToString("/") in SHARE)
    }

    /** True when the (already cleaned) path parts start with the Anjoo AI folder. */
    fun inside(parts: List<String>): Boolean = parts.firstOrNull()?.equals(Vault.NAME, ignoreCase = true) == true

    const val DENY_READ = "Privacy lock ON: I only read, change or delete files in the 'Anjoo AI' folder (and its sub-folders). " +
        "I do not open or copy files, photos or videos from other folders. There I can only see folder names (with your permission)."

    const val DENY_APP = "Privacy lock ON: this is a gallery / file-manager / video app. To protect your photos, videos and files, I do not look inside it, " +
        "and I do not take screenshots."

    // folders the user allowed Anjoo to look into during this run of the app
    private val allowed = HashSet<String>()
    private val asker = ThreadLocal<((String) -> Boolean)?>()

    /** Set by the file tool for the duration of one user-driven call, so outside folders can ask first. */
    fun <T> withAsker(confirm: (String) -> Boolean, block: () -> T): T {
        asker.set(confirm)
        try { return block() } finally { asker.set(null) }
    }

    fun canAsk(): Boolean = asker.get() != null

    /** Asks (once per folder per app run) before Anjoo looks into / adds a file to a folder outside the Anjoo AI folder. */
    fun mayVisit(dir: List<String>, what: String): Boolean {
        val key = dir.joinToString("/").lowercase()
        if (allowed.contains(key)) return true
        val ask = asker.get() ?: return false
        val shown = "/" + dir.joinToString("/")
        val ok = ask(Confirm.msg("action", "Anjoo AI folder se bahar jaun?",
            "$shown\n\n$what\nI will not open or copy files, photos or videos."))
        if (ok) allowed.add(key)
        return ok
    }

    /** Where an internal save that has no one to ask (artifacts, exports...) goes when its folder is outside the Anjoo AI folder. */
    fun remap(parts: List<String>): List<String> = listOf(Vault.NAME) + parts

    // ---- code and commands that try to walk around the rules ----

    private val PHONE_PATH = Regex("(?i)(/sdcard|/storage/|/mnt/|/data/media|externalstorage|getExternalStorage|\\\$EXTERNAL_STORAGE|\\\$SECONDARY_STORAGE|/proc/self/cwd|emulated/0)")
    private val HOME_ONLY = Regex("(?i)(/sdcard|/storage/emulated/0|/storage/self/primary)/+Anjoo AI(/|\\s|\"|'|$)")

    /** True when a shell command or Python code mentions phone storage outside the Anjoo AI folder. */
    fun touchesPhone(text: String): Boolean {
        if (!PHONE_PATH.containsMatchIn(text)) return false
        val stripped = HOME_ONLY.replace(text, " ")
        return PHONE_PATH.containsMatchIn(stripped)
    }

    const val DENY_CODE = "Privacy lock ON: the command or code touches phone storage outside the Anjoo AI folder; I will not run it. " +
        "I can only work inside the 'Anjoo AI' folder or a Code Studio project."

    private val MEDIA_APP_TOKENS = listOf(
        "gallery", "photos", "documentsui", "filemanager", "file.manager", "fileexplorer", "files", "myfiles", "mediaprovider",
        "camera", "mxtech", "mxplayer", "vlc", "videoplayer", "musicplayer", "quickpic", "simplemobiletools.gallery", "cx.file"
    )

    fun isMediaApp(pkg: String?): Boolean {
        if (!lock || pkg.isNullOrBlank()) return false
        val p = pkg.lowercase()
        if (p == "com.anjoo.assistant") return false
        return MEDIA_APP_TOKENS.any { p.contains(it) }
    }
}
