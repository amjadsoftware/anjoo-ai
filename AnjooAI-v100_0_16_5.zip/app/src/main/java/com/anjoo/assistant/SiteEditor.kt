package com.anjoo.assistant

import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * Simple visual editing inside the project preview: tap any element, change its text, text colour, background colour,
 * font and size, then Save. Text changes are written into the page's own HTML source; style changes go into edits.css
 * (linked from the page and scoped to that page), so the generated code stays clean.
 */
object SiteEditor {

    /** The panel and tap handling, injected into the previewed page. No dollar signs in here on purpose. */
    const val JS = """
(function(){
if(window.__anjooEditInit){window.__anjooEdit(true);return;}
window.__anjooEditInit=true;
var on=false,sel=null,edits={},orig={},idxs={},browse=false,src=null;
try{browse=sessionStorage.getItem('__ajBrowse')==='1';}catch(e){}
function norm(x){return x.replace(/\s+/g,' ');}
try{fetch(location.pathname).then(function(r){return r.text();}).then(function(t){src=norm(t);}).catch(function(){});}catch(e){}
var st=document.createElement('style');
st.textContent='.__aj-sel{outline:2px dashed #e11d48!important;outline-offset:2px}#__aj-panel{position:fixed;left:0;right:0;bottom:0;z-index:2147483647;background:#18181b;color:#fff;font:14px sans-serif;padding:10px;box-shadow:0 -4px 16px rgba(0,0,0,.4)}#__aj-panel *{box-sizing:border-box;font:inherit}#__aj-panel textarea{width:100%;height:56px;border-radius:8px;border:0;padding:8px;color:#111}#__aj-panel .r{display:flex;gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap}#__aj-panel button,#__aj-panel select{background:#3f3f46;color:#fff;border:0;border-radius:8px;padding:8px 12px;min-height:40px}#__aj-panel input[type=color]{width:40px;height:34px;border:0;padding:0;background:none}';
document.head.appendChild(st);
var panel=document.createElement('div');panel.id='__aj-panel';
panel.innerHTML='<div><b id="__aj-l">Kisi cheez par tap karein</b> <span id="__aj-m" style="color:#86efac"></span></div><div id="__aj-ed"><textarea id="__aj-t" placeholder="Text"></textarea><div class="r"><span>Text</span><input type="color" id="__aj-c"><span>Bg</span><input type="color" id="__aj-b"><select id="__aj-f"><option value="">Font</option><option value="system-ui,-apple-system,Segoe UI,Roboto,sans-serif">Sans</option><option value="Georgia,Times New Roman,serif">Serif</option><option value="Courier New,monospace">Mono</option><option value="Trebuchet MS,Verdana,sans-serif">Rounded</option><option value="Impact,Arial Black,sans-serif">Bold display</option></select><button id="__aj-dn">A-</button><button id="__aj-up">A+</button></div></div><div class="r"><button id="__aj-br">Browse</button><button id="__aj-s" style="background:#16a34a">Save</button><button id="__aj-x">Done</button></div>';
document.body.appendChild(panel);
function gi(i){return document.getElementById(i);}
function path(el){if(el===document.body)return 'body';var p=[];while(el&&el.nodeType===1&&el!==document.body){var i=1,s=el;while((s=s.previousElementSibling)){if(s.tagName===el.tagName)i++;}p.unshift(el.tagName.toLowerCase()+':nth-of-type('+i+')');el=el.parentElement;}return 'body > '+p.join(' > ');}
function leaf(el){return el.children.length===0;}
function rec(el){var k=path(el);if(!edits[k])edits[k]={sel:k,style:{}};return edits[k];}
function hex(c){var m=/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?/.exec(c);if(!m||(m[4]!==undefined&&parseFloat(m[4])===0))return '#ffffff';function h(n){n=parseInt(n,10).toString(16);return n.length<2?'0'+n:n;}return '#'+h(m[1])+h(m[2])+h(m[3]);}
function before(el,t){var all=document.body.querySelectorAll('*'),n=0;for(var i=0;i<all.length;i++){var x=all[i];if(x===el)break;if(!panel.contains(x)&&x.children.length===0&&x.textContent.trim()===t)n++;}return n;}
function inSrc(t){if(src===null||!t)return true;var e=t.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');t=norm(t);e=norm(e);return src.indexOf(t)>=0||src.indexOf(e)>=0;}
function say(s){gi('__aj-m').textContent=s;}
function pick(el){if(sel)sel.classList.remove('__aj-sel');sel=el;el.classList.add('__aj-sel');var cs=getComputedStyle(el);var t=gi('__aj-t');var txt=leaf(el)?el.textContent.trim():'';t.value=txt;t.disabled=!leaf(el);gi('__aj-c').value=hex(cs.color);gi('__aj-b').value=hex(cs.backgroundColor);gi('__aj-l').textContent='<'+el.tagName.toLowerCase()+'>';say('');if(leaf(el)&&!inSrc(txt)){t.disabled=true;say('Ye text script se banta hai: text Save nahi hoga, rang aur font ho sakte hain.');}}
function setBrowse(v){browse=v;try{sessionStorage.setItem('__ajBrowse',v?'1':'0');}catch(e){}gi('__aj-br').textContent=v?'Edit':'Browse';gi('__aj-ed').style.display=v?'none':'block';if(v&&sel){sel.classList.remove('__aj-sel');sel=null;}gi('__aj-l').textContent=v?'Browse mode: links aur buttons chalenge':'Kisi cheez par tap karein';say('');}
gi('__aj-t').addEventListener('input',function(){if(!sel||!leaf(sel))return;var k=path(sel);if(orig[k]===undefined){orig[k]=sel.textContent.trim();idxs[k]=before(sel,orig[k]);}var v=gi('__aj-t').value;sel.textContent=v;var e=rec(sel);e.text=v.trim();e.old=orig[k];e.idx=idxs[k];});
gi('__aj-c').addEventListener('input',function(){if(!sel)return;var v=gi('__aj-c').value;sel.style.color=v;rec(sel).style.color=v;});
gi('__aj-b').addEventListener('input',function(){if(!sel)return;var v=gi('__aj-b').value;sel.style.backgroundColor=v;rec(sel).style.backgroundColor=v;});
gi('__aj-f').addEventListener('change',function(){if(!sel)return;var v=gi('__aj-f').value;if(!v)return;sel.style.fontFamily=v;rec(sel).style.fontFamily=v;});
function size(d){if(!sel)return;var n=parseFloat(getComputedStyle(sel).fontSize)+d;if(n<8)n=8;sel.style.fontSize=n+'px';rec(sel).style.fontSize=n+'px';}
gi('__aj-dn').addEventListener('click',function(){size(-2);});
gi('__aj-up').addEventListener('click',function(){size(2);});
gi('__aj-br').addEventListener('click',function(){setBrowse(!browse);});
gi('__aj-x').addEventListener('click',function(){window.__anjooEdit(false);try{AnjooEdit.done();}catch(e){}});
gi('__aj-s').addEventListener('click',function(){var list=[];for(var k in edits){if(edits.hasOwnProperty(k))list.push(edits[k]);}if(!list.length){say('Koi badlav nahi');return;}var r='';try{r=AnjooEdit.save(JSON.stringify({page:location.pathname,items:list}));}catch(e){r='ERR: '+e;}say(r);if(r.indexOf('ERR')!==0){for(var j=0;j<list.length;j++){if(list[j].text!==undefined)orig[list[j].sel]=list[j].text;}edits={};}});
document.addEventListener('click',function(e){if(!on||browse)return;if(panel.contains(e.target))return;e.preventDefault();e.stopPropagation();if(e.target===document.documentElement)return;pick(e.target);},true);
window.__anjooEdit=function(v){on=v;panel.style.display=v?'block':'none';if(!v&&sel){sel.classList.remove('__aj-sel');sel=null;}};
setBrowse(browse);
window.__anjooEdit(true);
})();
"""

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    /** Replaces only the first match of [re] with the text built by [make]; returns the input unchanged when there is no match. */
    private fun insertAfterMatch(text: String, re: Regex, make: (MatchResult) -> String): String {
        val m = re.find(text) ?: return text
        return text.substring(0, m.range.first) + make(m) + text.substring(m.range.last + 1)
    }

    private fun nthIndexOf(text: String, needle: String, n: Int): Int {
        var from = 0
        var i = -1
        for (k in 0..n) {
            i = text.indexOf(needle, from)
            if (i < 0) return -1
            from = i + needle.length
        }
        return i
    }

    /** Applies one Save from the preview. Returns a short message for the panel; starts with ERR on failure. */
    fun apply(dir: File, json: String): String {
        return try {
            val o = JSONObject(json)
            var page = java.net.URLDecoder.decode(o.optString("page", ""), "UTF-8").trimStart('/')
            if (page.isEmpty() || page.endsWith("/")) page += (PreviewServer.entry(dir)?.substringAfterLast('/') ?: "index.html")
            val file = File(dir, page)
            if (!file.isFile || !file.canonicalPath.startsWith(dir.canonicalPath)) return "ERR: page file not found ($page)"
            var html = file.readText(Charsets.UTF_8)
            val items = o.optJSONArray("items") ?: JSONArray()
            var textDone = 0
            val skipped = ArrayList<String>()
            val styleRules = LinkedHashMap<String, LinkedHashMap<String, String>>()
            for (i in 0 until items.length()) {
                val item = items.getJSONObject(i)
                if (item.has("text") && item.has("old")) {
                    val old = item.getString("old"); val nw = item.getString("text"); val idx = item.optInt("idx", 0)
                    if (old.isNotEmpty() && old != nw) {
                        var done = false
                        for ((a, b) in listOf(old to nw, esc(old) to esc(nw))) {
                            val pos = nthIndexOf(html, a, idx)
                            if (pos >= 0) { html = html.substring(0, pos) + b + html.substring(pos + a.length); done = true; break }
                        }
                        if (done) textDone++ else skipped.add(old.take(24))
                    }
                }
                val st = item.optJSONObject("style")
                if (st != null && st.length() > 0) {
                    val m = styleRules.getOrPut(item.getString("sel")) { LinkedHashMap() }
                    val names = mapOf("color" to "color", "backgroundColor" to "background-color", "fontFamily" to "font-family", "fontSize" to "font-size")
                    for ((js, css) in names) if (st.has(js)) m[css] = st.getString(js)
                }
            }
            var styleDone = 0
            if (styleRules.isNotEmpty()) {
                // Scope every rule to this page, so the same element path on another page is not affected.
                val scope = "body[data-edit-page=\"" + page.replace("\"", "") + "\"]"
                if (!html.contains("data-edit-page=\"$page\"")) {
                    html = insertAfterMatch(html, Regex("(?i)<body\\b([^>]*)>")) { m -> "<body" + m.groupValues[1] + " data-edit-page=\"" + page + "\">" }
                }
                val depth = page.count { it == '/' }
                val href = "../".repeat(depth) + "edits.css"
                if (!html.contains("edits.css")) {
                    html = insertAfterMatch(html, Regex("(?i)</head>")) { "<link rel=\"stylesheet\" href=\"$href\">\n</head>" }
                }
                val cssFile = File(dir, "edits.css")
                val existing = LinkedHashMap<String, LinkedHashMap<String, String>>()
                if (cssFile.isFile) Regex("([^{}]+)\\{([^}]*)\\}").findAll(cssFile.readText(Charsets.UTF_8).replace(Regex("/\\*[\\s\\S]*?\\*/"), "")).forEach { r ->
                    val props = LinkedHashMap<String, String>()
                    r.groupValues[2].split(';').forEach { d -> val kv = d.split(':', limit = 2); if (kv.size == 2) props[kv[0].trim()] = kv[1].replace("!important", "").trim() }
                    existing[r.groupValues[1].trim()] = props
                }
                for ((sel, props) in styleRules) {
                    val full = if (sel == "body") scope else scope + sel.removePrefix("body")
                    existing.getOrPut(full) { LinkedHashMap() }.putAll(props)
                    styleDone++
                }
                val sb = StringBuilder("/* Visual edits made in the preview (Anjoo AI). Safe to delete a rule. */\n")
                for ((s, props) in existing) sb.append(s).append(" { ").append(props.entries.joinToString(" ") { it.key + ": " + it.value + " !important;" }).append(" }\n")
                cssFile.writeText(sb.toString(), Charsets.UTF_8)
            }
            file.writeText(html, Charsets.UTF_8)
            val parts = ArrayList<String>()
            if (textDone > 0) parts.add("$textDone text")
            if (styleDone > 0) parts.add("$styleDone style")
            "Saved ✔ " + (if (parts.isEmpty()) "nothing changed" else parts.joinToString(" + ")) + (if (skipped.isNotEmpty()) " (skipped: " + skipped.joinToString(", ") + ")" else "")
        } catch (e: Exception) {
            "ERR: " + (e.message ?: e.javaClass.simpleName)
        }
    }

    class Bridge(private val dir: File, private val onDone: () -> Unit = {}) {
        @JavascriptInterface
        fun save(json: String): String = apply(dir, json)

        /** The Done button in the panel: edit mode stays off on the next pages too. */
        @JavascriptInterface
        fun done() { onDone() }
    }
}
