package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** "Undo" for deletes: the last 30 deleted notes and tasks are kept for 14 days and can be restored. */
object Trash {
    class Item(val kind: String, val title: String, val at: Long, val data: JSONObject)

    private const val PREF = "trashItems"
    private const val MAX = 30
    private const val KEEP_MS = 14L * 24 * 60 * 60 * 1000

    private fun p(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    private fun read(ctx: Context): JSONArray =
        try { JSONArray(p(ctx).getString(PREF, "[]")) } catch (e: Exception) { JSONArray() }

    @Synchronized fun stash(ctx: Context, kind: String, title: String, data: JSONObject) {
        try {
            val old = read(ctx)
            val next = JSONArray()
            next.put(JSONObject().put("kind", kind).put("title", title.take(60)).put("at", System.currentTimeMillis()).put("data", data))
            for (i in 0 until minOf(old.length(), MAX - 1)) next.put(old.getJSONObject(i))
            p(ctx).edit().putString(PREF, next.toString()).apply()
        } catch (e: Exception) {
            android.util.Log.w("Anjoo", "trash stash failed", e)
        }
    }

    @Synchronized fun list(ctx: Context): List<Item> {
        val a = read(ctx)
        val now = System.currentTimeMillis()
        val out = ArrayList<Item>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val at = o.optLong("at")
            if (now - at > KEEP_MS) continue
            out.add(Item(o.optString("kind"), o.optString("title"), at, o.optJSONObject("data") ?: JSONObject()))
        }
        return out
    }

    private fun save(ctx: Context, items: List<Item>) {
        val a = JSONArray()
        for (it0 in items) a.put(JSONObject().put("kind", it0.kind).put("title", it0.title).put("at", it0.at).put("data", it0.data))
        p(ctx).edit().putString(PREF, a.toString()).apply()
    }

    /** Puts item number [index] (as shown by [list]) back. Returns a message for the user. */
    @Synchronized fun restore(ctx: Context, index: Int): String {
        val items = list(ctx).toMutableList()
        val item = items.getOrNull(index) ?: return "This item was not found any more."
        try {
            when (item.kind) {
                "note" -> {
                    val n = Notes.add(ctx, item.data.optString("title"), item.data.optString("body"))
                    if (item.data.optBoolean("pinned")) Notes.setPinned(ctx, n.id, true)
                }
                "task" -> Tasks.add(ctx, item.data.optString("title"), item.data.optString("note"),
                    item.data.optString("status", "todo"), item.data.optString("due"))
                else -> return "This item cannot be restored."
            }
        } catch (e: Exception) {
            return "Could not restore: " + (e.message ?: "error")
        }
        items.removeAt(index)
        save(ctx, items)
        return (if (item.kind == "note") "Note" else "Task") + " restored: " + item.title
    }
}
