package com.anjoo.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager

/**
 * Ask for a permission only at the moment a feature needs it.
 * Actions notes a missing permission here; after the reply finishes, MainActivity calls [offer],
 * which explains why and asks once. If the user says "Abhi nahi" we do not ask again for 3 days.
 */
object PermNeed {
    private val pending = LinkedHashSet<String>()
    private const val QUIET_MS = 3L * 24 * 60 * 60 * 1000

    @Synchronized fun note(p: String) { pending.add(p) }

    @Synchronized private fun take(): List<String> {
        val l = pending.toList()
        pending.clear()
        return l
    }

    private class Group(val label: String, val perms: List<String>)

    private val groups = listOf(
        Group("Contacts", listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.WRITE_CONTACTS)),
        Group("Calendar", listOf(Manifest.permission.READ_CALENDAR, Manifest.permission.WRITE_CALENDAR)),
        Group("Location", listOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)),
        Group("SMS", listOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_SMS)),
        Group("Phone calls", listOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALL_LOG, Manifest.permission.READ_PHONE_STATE)),
        Group("Camera", listOf(Manifest.permission.CAMERA)),
        Group("Microphone", listOf(Manifest.permission.RECORD_AUDIO)),
        Group("Notifications", listOf("android.permission.POST_NOTIFICATIONS")),
        Group("Photos, videos and audio", listOf(
            "android.permission.READ_MEDIA_IMAGES", "android.permission.READ_MEDIA_VIDEO", "android.permission.READ_MEDIA_AUDIO")),
        Group("Bluetooth", listOf("android.permission.BLUETOOTH_CONNECT"))
    )

    private fun groupOf(p: String): Group? = groups.firstOrNull { p in it.perms }

    /** Shows one explain-then-ask dialog for the first missing permission group noted during the last request. */
    fun offer(act: Activity) {
        try {
            if (act.isFinishing) return
            val valid = Perms.all().toSet()
            val needed = take().filter { it in valid && act.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            val g = needed.firstNotNullOfOrNull { groupOf(it) } ?: return
            val prefs = act.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
            val key = "permAskedAt_" + g.label
            val now = System.currentTimeMillis()
            if (now - prefs.getLong(key, 0L) < QUIET_MS) return
            val ask = g.perms.filter { it in valid && act.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (ask.isEmpty()) return
            AlertDialog.Builder(act)
                .setTitle(act.getString(R.string.perm_need_title))
                .setMessage(act.getString(R.string.perm_need_message, g.label))
                .setPositiveButton(act.getString(R.string.perm_allow)) { _, _ -> act.requestPermissions(ask.toTypedArray(), 61) }
                .setNegativeButton(act.getString(R.string.perm_not_now)) { _, _ -> prefs.edit().putLong(key, System.currentTimeMillis()).apply() }
                .show()
        } catch (e: Exception) {
            android.util.Log.w("Anjoo", "permission offer failed", e)
        }
    }
}
