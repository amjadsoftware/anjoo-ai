package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One remembered thing. kind: "pref" (pasand/aadat), "task" (chal raha kaam), "person" (log/rishte), "fact" (baaqi). */
data class MemItem(
    val id: Long,
    val kind: String,
    val text: String,
    val created: Long,
    val updated: Long,
    val hits: Int = 0,
    val done: Boolean = false,
    val pinned: Boolean = false,
)

/**
 * Pure logic (no Android): word matching, duplicate detection, ranking and auto-capture rules.
 * Kept separate from storage so it can be unit tested on the JVM.
 */
object MemLogic {
    const val MAX_ITEMS = 600
    const val MAX_TEXT = 240

    private val STOP = setOf(
        "the", "a", "an", "is", "are", "to", "of", "and", "or", "in", "on", "for", "my", "me", "i", "it", "that", "this",
        "hai", "hain", "ho", "hoon", "tha", "thi", "ka", "ki", "ke", "ko", "se", "me", "mein", "par", "aur", "ya", "ye",
        "yeh", "wo", "woh", "main", "mujhe", "meri", "mera", "mere", "hum", "tum", "aap", "bhi", "to", "toh", "nahi", "na"
    )

    private val SENSITIVE = Regex(
        "(?i)(\\b(cvv|cvc|pin|otp|password|passcode|passwd|iban|api[ _-]?key|secret|token)\\b|\\b(?:\\d[ -]?){13,19}\\b)"
    )

    fun isSensitive(t: String) = SENSITIVE.containsMatchIn(t)

    fun suppressedByDeletion(updatedAt: Long, deletedAt: Long?): Boolean = deletedAt != null && deletedAt >= updatedAt

    fun suppressedByGlobalClear(updatedAt: Long, clearAllAt: Long): Boolean = clearAllAt > 0L && updatedAt <= clearAllAt

    fun words(t: String): Set<String> =
        t.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+"))
            .filter { it.length > 1 && it !in STOP }.toSet()

    fun similarity(a: String, b: String): Double {
        val x = words(a); val y = words(b)
        if (x.isEmpty() || y.isEmpty()) return 0.0
        val inter = x.intersect(y).size.toDouble()
        return inter / (x.size + y.size - inter)
    }

    fun clean(t: String): String = t.trim().replace(Regex("\\s+"), " ").trim('.', ' ', '\n').take(MAX_TEXT)

    fun normalizeKind(k: String?): String = when ((k ?: "").lowercase(Locale.ROOT).trim()) {
        "pref", "preference", "pasand", "aadat", "habit" -> "pref"
        "task", "kaam", "project", "todo", "ongoing" -> "task"
        "person", "log", "rishta", "contact", "family" -> "person"
        else -> "fact"
    }

    /** Finds an existing item that says (almost) the same thing, so we update instead of piling up copies. */
    fun findDuplicate(items: List<MemItem>, kind: String, text: String): MemItem? =
        items.filter { it.kind == kind }.firstOrNull { it.text.equals(text, true) || similarity(it.text, text) >= 0.7 }

    /** How useful this item is for the current message: word overlap first, then pinned, usage and recency. */
    fun score(it: MemItem, query: String, now: Long): Double {
        val q = words(query)
        val overlap = if (q.isEmpty()) 0.0 else words(it.text).intersect(q).size.toDouble()
        val ageDays = ((now - it.updated).coerceAtLeast(0L)) / 86_400_000.0
        val recency = 1.0 / (1.0 + ageDays / 30.0)
        return overlap * 3.0 + (if (it.pinned) 2.0 else 0.0) + minOf(it.hits, 10) * 0.1 + recency
    }

    /** What to put in front of the model for this message, limited so the prompt stays small. */
    fun pick(items: List<MemItem>, query: String, now: Long, maxChars: Int = 2200): List<MemItem> {
        val live = items.filter { !(it.kind == "task" && it.done) }
        val q = words(query)
        val prefs = live.filter { it.kind == "pref" }
            .sortedByDescending { score(it, query, now) }.take(if (q.isEmpty()) 6 else 10)
        val tasks = live.filter { it.kind == "task" }
            .sortedByDescending { score(it, query, now) }.take(8)
        val rest = live.filter { it.kind == "person" || it.kind == "fact" }
            .filter { q.isEmpty() && it.pinned || it.pinned || words(it.text).intersect(q).isNotEmpty() }
            .sortedByDescending { score(it, query, now) }.take(if (q.isEmpty()) 4 else 12)
        val out = ArrayList<MemItem>()
        var used = 0
        for (m in (prefs + tasks + rest).distinctBy { it.id }) {
            val cost = m.text.length + 24
            if (used + cost > maxChars) continue
            out.add(m); used += cost
        }
        return out
    }

    private val PREF_RX = listOf(
        Regex("(?i)\\bmujhe\\b.{2,80}\\b(pasand|achha|acha|bura|nahi pasand|pasand nahi)\\b.*"),
        Regex("(?i)\\bmain\\b.{2,80}\\b(hamesha|aksar|roz|kabhi nahi)\\b.*"),
        Regex("(?i)\\b(i (really )?(prefer|like|love|hate|always|never|usually))\\b.*"),
        Regex("(?i)\\bmeri (pasand|aadat)\\b.*"),
    )
    private val PERSON_RX = listOf(
        Regex("(?i)\\b(meri|mera|mere)\\s+(ammi|abbu|bhai|behan|bahan|biwi|shohar|beta|beti|dost|boss|chacha|mama|khala|phupho|dada|dadi|nana|nani)\\b.*"),
        Regex("(?i)\\bmy\\s+(mother|father|mom|dad|brother|sister|wife|husband|son|daughter|friend|boss)\\b.*"),
        Regex("(?i)\\b(mera naam|my name is)\\b.*"),
    )
    private val TASK_RX = listOf(
        Regex("(?i)\\b(main|hum)\\b.{2,80}\\b(bana raha|bana rahi|likh raha|likh rahi|kar raha hoon|kar rahi hoon|seekh raha|seekh rahi)\\b.*"),
        Regex("(?i)\\b(i am|i'm) (working on|building|writing|learning|preparing)\\b.*"),
        Regex("(?i)\\bmera (project|kaam|exam|paper|interview)\\b.*"),
    )

    /** A clear, single statement about the user -> (kind, text). Conservative on purpose; questions and commands are ignored. */
    fun extract(userText: String): Pair<String, String>? {
        val t = clean(userText)
        if (t.length < 12 || t.length > MAX_TEXT) return null
        if (t.endsWith("?") || isSensitive(t)) return null
        val low = t.lowercase(Locale.ROOT)
        if (Regex("^(kya|kaise|kyun|kab|kahan|kaun|what|how|why|when|where|who|can you|could you|please|karo|kholo|bhejo)\\b").containsMatchIn(low)) return null
        if (PERSON_RX.any { it.containsMatchIn(t) }) return "person" to t
        if (TASK_RX.any { it.containsMatchIn(t) }) return "task" to t
        if (PREF_RX.any { it.containsMatchIn(t) }) return "pref" to t
        return null
    }

    /** Words that mean "this ongoing thing is finished". */
    fun looksFinished(t: String) =
        Regex("(?i)\\b(ho gaya|ho gayi|khatam|complete|completed|done|finished|mukammal)\\b").containsMatchIn(t)
}

/** Anjoo's long-term memory on the phone (a JSON file). Survives app updates; included in Backup. */
object LongMemory {
    private const val FILE = "long_memory.json"
    private const val DELETED_FILE = "long_memory_deleted.json"
    private const val CLEAR_ALL_KEY = "memoryClearAllAt"

    @Volatile private var lastQuery: String = ""

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)
    private fun deletedFile(ctx: Context) = File(ctx.filesDir, DELETED_FILE)
    private fun readTombstones(ctx: Context): MutableMap<Long, Long> = try {
        val a = JSONArray(deletedFile(ctx).takeIf { it.exists() }?.readText(Charsets.UTF_8) ?: "[]")
        buildMap { for (i in 0 until a.length()) { val o = a.optJSONObject(i) ?: continue; val id = o.optLong("id"); if (id != 0L) put(id, o.optLong("deletedAt")) } }.toMutableMap()
    } catch (_: Exception) { mutableMapOf() }
    private fun writeTombstones(ctx: Context, values: Map<Long, Long>) {
        val a = JSONArray()
        values.entries.sortedBy { it.key }.takeLast(10000).forEach { a.put(JSONObject().put("id", it.key).put("deletedAt", it.value)) }
        val target = deletedFile(ctx); val tmp = File(ctx.filesDir, "$DELETED_FILE.tmp")
        tmp.writeText(a.toString(), Charsets.UTF_8)
        if (!tmp.renameTo(target)) { target.writeText(a.toString(), Charsets.UTF_8); tmp.delete() }
    }
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
    private fun clearAllAt(ctx: Context): Long = prefs(ctx).getLong(CLEAR_ALL_KEY, 0L)
    private fun nextTimestamp(ctx: Context): Long = maxOf(System.currentTimeMillis(), clearAllAt(ctx) + 1L, (all(ctx).maxOfOrNull { it.updated } ?: 0L) + 1L)
    fun enabled(ctx: Context) = prefs(ctx).getBoolean("saveMemory", true)
    fun auto(ctx: Context) = enabled(ctx) && prefs(ctx).getBoolean("autoMemory", true)

    private fun toJson(m: MemItem) = JSONObject().put("id", m.id).put("k", m.kind).put("t", m.text)
        .put("c", m.created).put("u", m.updated).put("h", m.hits).put("d", m.done).put("p", m.pinned)

    private fun fromJson(o: JSONObject) = MemItem(
        o.getLong("id"), o.optString("k", "fact"), o.getString("t"), o.optLong("c"), o.optLong("u"),
        o.optInt("h"), o.optBoolean("d"), o.optBoolean("p")
    )

    @Synchronized
    fun all(ctx: Context): List<MemItem> {
        migrateOldNotes(ctx)
        return try {
            val a = JSONArray(file(ctx).takeIf { it.exists() }?.readText(Charsets.UTF_8) ?: "[]")
            (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
        } catch (e: Exception) { emptyList() }
    }

    @Synchronized
    private fun save(ctx: Context, items: List<MemItem>) {
        var list = items
        if (list.size > MemLogic.MAX_ITEMS) {
            // drop the least useful first: finished tasks, then old unpinned items nobody asked about
            val keep = list.sortedByDescending {
                (if (it.pinned) 1000.0 else 0.0) + (if (it.kind == "task" && !it.done) 500.0 else 0.0) +
                    (if (it.done) -500.0 else 0.0) + it.hits * 2.0 + it.updated / 1.0e12
            }.take(MemLogic.MAX_ITEMS).map { it.id }.toSet()
            list = list.filter { it.id in keep }
        }
        val a = JSONArray()
        list.forEach { a.put(toJson(it)) }
        val target = file(ctx)
        val tmp = File(ctx.filesDir, "$FILE.tmp")
        tmp.writeText(a.toString(), Charsets.UTF_8)
        if (!tmp.renameTo(target)) {
            target.writeText(a.toString(), Charsets.UTF_8)
            tmp.delete()
        }
    }

    /** The old app kept up to 50 plain notes in settings. Move them over once, then leave them alone. */
    private fun migrateOldNotes(ctx: Context) {
        val p = prefs(ctx)
        if (p.getBoolean("memMigrated", false)) return
        p.edit().putBoolean("memMigrated", true).apply()
        try {
            val old = JSONArray(p.getString("notes", "[]"))
            if (old.length() == 0) return
            val now = System.currentTimeMillis()
            val a = JSONArray()
            for (i in 0 until old.length()) {
                val t = MemLogic.clean(old.getString(i))
                if (t.isNotEmpty()) a.put(toJson(MemItem(now + i, "fact", t, now, now)))
            }
            file(ctx).writeText(a.toString(), Charsets.UTF_8)
        } catch (e: Exception) {}
    }

    /** Saves (or refreshes) one memory. Returns a short message for the user. */
    @Synchronized
    fun add(ctx: Context, kindIn: String?, textIn: String, pinned: Boolean = false): String {
        if (!enabled(ctx)) return "Save Memory band hai, is liye yaad nahi rakha. (+ dabayen aur Save Memory on karein.)"
        val text = MemLogic.clean(textIn)
        if (text.length < 3) return "Kya yaad rakhna hai? Thori tafseel batayen."
        if (MemLogic.isSensitive(text)) return "Password, PIN, OTP, card ya API key main yaad nahi rakhta."
        val kind = MemLogic.normalizeKind(kindIn)
        val items = all(ctx).toMutableList()
        val now = nextTimestamp(ctx)
        val dup = MemLogic.findDuplicate(items, kind, text)
        if (dup != null) {
            items[items.indexOf(dup)] = dup.copy(text = text, updated = now, done = false, pinned = dup.pinned || pinned)
            save(ctx, items)
            return "Pehle se yaad tha, taza kar diya."
        }
        items.add(MemItem(now, kind, text, now, now, pinned = pinned))
        save(ctx, items)
        return "Yaad rakh liya."
    }

    @Synchronized
    fun update(ctx: Context, id: Long, kindIn: String?, textIn: String): String {
        // The master switch prevents new/automatic captures, but users must always be able to edit or remove existing data.
        val text = MemLogic.clean(textIn)
        if (text.length < 3) return "Memory text kam az kam 3 characters ka hona chahiye."
        if (MemLogic.isSensitive(text)) return "Password, PIN, OTP, card ya API key memory mein save nahi hoti."
        val items = all(ctx).toMutableList()
        val index = items.indexOfFirst { it.id == id }
        if (index < 0) return "Yeh memory ab maujood nahi."
        val old = items[index]
        val kind = kindIn?.takeIf { it.isNotBlank() }?.let { MemLogic.normalizeKind(it) } ?: old.kind
        val dup = items.firstOrNull { it.id != id && it.kind == kind && MemLogic.similarity(it.text, text) >= 0.85 }
        if (dup != null) return "Isi se milti-julti memory pehle se maujood hai (${dup.id})."
        items[index] = old.copy(kind = kind, text = text, updated = nextTimestamp(ctx))
        save(ctx, items)
        return "Memory update ho gayi."
    }

    @Synchronized
    fun pin(ctx: Context, id: Long, value: Boolean): Boolean {
        val items = all(ctx).toMutableList()
        val i = items.indexOfFirst { it.id == id }
        if (i < 0) return false
        items[i] = items[i].copy(pinned = value, updated = nextTimestamp(ctx))
        save(ctx, items)
        return true
    }

    @Synchronized
    fun deleteId(ctx: Context, id: Long): Boolean {
        val items = all(ctx)
        val keep = items.filterNot { it.id == id }
        if (keep.size == items.size) return false
        markDeleted(ctx, listOf(id))
        save(ctx, keep)
        return true
    }

    @Synchronized
    fun clear(ctx: Context): Int {
        val items = all(ctx)
        val count = items.size
        // A global clear watermark also suppresses stale records that were only present in an older/offline backup.
        val clearedAt = maxOf(System.currentTimeMillis(), (items.maxOfOrNull { it.updated } ?: 0L) + 1L)
        prefs(ctx).edit().putLong(CLEAR_ALL_KEY, clearedAt).apply()
        markDeleted(ctx, items.map { it.id }, clearedAt)
        save(ctx, emptyList())
        return count
    }

    @Synchronized
    private fun markDeleted(ctx: Context, ids: List<Long>, at: Long = System.currentTimeMillis()) {
        if (ids.isEmpty()) return
        val newestDeleted = all(ctx).filter { it.id in ids }.maxOfOrNull { it.updated } ?: 0L
        val deleteAt = maxOf(at, newestDeleted + 1L)
        val map = readTombstones(ctx)
        ids.forEach { map[it] = maxOf(map[it] ?: 0L, deleteAt) }
        writeTombstones(ctx, map)
    }

    fun search(ctx: Context, query: String = "", kind: String? = null, limit: Int = 100): List<MemItem> {
        val q = query.trim()
        val k = kind?.takeIf { it.isNotBlank() }?.let { MemLogic.normalizeKind(it) }
        val all = all(ctx).filter { k == null || it.kind == k }
        if (q.isBlank()) return all.sortedWith(compareByDescending<MemItem> { it.pinned }.thenByDescending { it.updated }).take(limit.coerceIn(1, 600))
        val now = System.currentTimeMillis()
        val queryWords = MemLogic.words(q)
        return all.map { it to MemLogic.score(it, q, now) }
            .filter { (m, _) -> m.text.contains(q, true) || MemLogic.words(m.text).intersect(queryWords).isNotEmpty() }
            .sortedWith(compareByDescending<Pair<MemItem, Double>> { it.second }.thenByDescending { it.first.updated })
            .take(limit.coerceIn(1, 600)).map { it.first }
    }

    fun currentQuery(): String = lastQuery

    @Synchronized
    fun forget(ctx: Context, q: String): String {
        val items = all(ctx)
        val key = q.trim()
        if (key.length < 2) return "Kya bhulana hai?"
        val removed = items.filter { it.text.contains(key, true) }
        if (removed.isEmpty()) return "Aisi koi yaad rakhi baat nahi mili."
        val removedIds = removed.map { it.id }.toSet()
        markDeleted(ctx, removedIds.toList())
        save(ctx, items.filterNot { it.id in removedIds })
        return "${removed.size} baat bhula di."
    }

    /** Marks an ongoing job as finished (kept for history, not shown in the prompt any more). */
    @Synchronized
    fun complete(ctx: Context, q: String): String {
        val items = all(ctx).toMutableList()
        val m = items.filter { it.kind == "task" && !it.done }
            .maxByOrNull { if (it.text.contains(q, true)) 100.0 else MemLogic.similarity(it.text, q) * 10 }
            ?: return "Koi chal raha kaam nahi mila."
        if (!m.text.contains(q, true) && MemLogic.similarity(m.text, q) < 0.2) return "Is naam ka koi chal raha kaam nahi mila."
        items[items.indexOf(m)] = m.copy(done = true, updated = nextTimestamp(ctx))
        save(ctx, items)
        return "Kaam mukammal likh liya: ${m.text}"
    }

    @Synchronized
    fun list(ctx: Context, kind: String? = null, query: String = ""): String {
        val items = search(ctx, query, kind, 100)
        if (items.isEmpty()) return "Abhi kuch yaad nahi rakha."
        val label = mapOf("pref" to "pasand", "task" to "kaam", "person" to "log", "fact" to "baat")
        val sb = StringBuilder()
        for (m in items.take(60)) {
            sb.append("- [id=").append(m.id).append(", ").append(label[m.kind]).append(if (m.done) ", mukammal" else "")
                .append(if (m.pinned) ", pinned" else "").append("] ").append(m.text).append("\n")
        }
        return sb.toString().trim()
    }

    /** Lines for the system prompt, chosen for the message the user just sent. */
    fun promptLines(ctx: Context): List<String> {
        if (!enabled(ctx)) return emptyList()
        val now = System.currentTimeMillis()
        val items = all(ctx)
        if (items.isEmpty()) return emptyList()
        val chosen = MemLogic.pick(items, lastQuery, now)
        touch(ctx, chosen.map { it.id }.toSet())
        val label = mapOf("pref" to "pasand", "task" to "chal raha kaam", "person" to "log", "fact" to "baat")
        return chosen.map { "[" + label[it.kind] + "] " + it.text }
    }

    @Synchronized
    private fun touch(ctx: Context, ids: Set<Long>) {
        if (ids.isEmpty()) return
        val items = all(ctx).map { if (it.id in ids) it.copy(hits = it.hits + 1) else it }
        save(ctx, items)
    }

    /** Old chats that mention the same words as the current message (so Anjoo can pick up where you left off). */
    fun relatedChats(ctx: Context, limit: Int = 3): String {
        val q = MemLogic.words(lastQuery)
        if (q.size < 2) return ""
        val cur = ChatStore.currentId(ctx)
        val a = ChatStore.all(ctx)
        data class Hit(val score: Int, val at: Long, val line: String)
        val hits = ArrayList<Hit>()
        for (i in 0 until a.length()) {
            val s = a.getJSONObject(i)
            if (s.optLong("id") == cur) continue
            val ls = s.optJSONArray("lines") ?: continue
            var best = 0; var bestLine = ""; var bestAt = 0L
            for (j in 0 until ls.length()) {
                val o = ls.getJSONObject(j)
                if (o.optInt("k") > 1) continue
                val n = MemLogic.words(o.optString("t")).intersect(q).size
                if (n > best) { best = n; bestLine = o.optString("t"); bestAt = o.optLong("at") }
            }
            if (best >= 2) hits.add(Hit(best, bestAt, bestLine.take(140)))
        }
        if (hits.isEmpty()) return ""
        val fmt = SimpleDateFormat("d MMM", Locale.ENGLISH)
        val sb = StringBuilder("Purani baat-cheet jo is baat se milti hai:\n")
        hits.sortedWith(compareByDescending<Hit> { it.score }.thenByDescending { it.at }).take(limit)
            .forEach { sb.append("- ").append(fmt.format(Date(it.at))).append(": ").append(it.line).append("\n") }
        return sb.toString()
    }

    /** Called for every message the user sends (typed or spoken). Remembers it as the "current topic" and saves clear facts on its own. */
    fun onUserMessage(ctx: Context, text: String) {
        lastQuery = text.take(400)
        if (!auto(ctx)) return
        try {
            if (MemLogic.looksFinished(text)) {
                val open = all(ctx).filter { it.kind == "task" && !it.done }
                val hit = open.firstOrNull { MemLogic.similarity(it.text, text) >= 0.25 }
                if (hit != null) { complete(ctx, hit.text); return }
            }
            val e = MemLogic.extract(text) ?: return
            add(ctx, e.first, e.second)
        } catch (e: Exception) { /* memory must never break chatting */ }
    }

    // ---- backup support
    fun exportArray(ctx: Context): JSONArray { val a = JSONArray(); all(ctx).forEach { a.put(toJson(it)) }; return a }

    fun exportDeletedArray(ctx: Context): JSONArray {
        val a = JSONArray()
        val clearAt = clearAllAt(ctx)
        if (clearAt > 0L) a.put(JSONObject().put("id", 0).put("deletedAt", clearAt).put("clearAll", true))
        readTombstones(ctx).forEach { (id, at) -> a.put(JSONObject().put("id", id).put("deletedAt", at)) }
        return a
    }

    /** Merges items by newest timestamp. Deletion tombstones prevent stale backups restoring forgotten data. */
    @Synchronized
    fun merge(ctx: Context, a: JSONArray, deleted: JSONArray = JSONArray()) {
        val tombstones = readTombstones(ctx)
        var globalClearAt = clearAllAt(ctx)
        for (i in 0 until deleted.length()) {
            val o = deleted.optJSONObject(i) ?: continue
            val id = o.optLong("id")
            val at = o.optLong("deletedAt", o.optLong("updated", 0L))
            if (id == 0L && o.optBoolean("clearAll", false)) { globalClearAt = maxOf(globalClearAt, at); continue }
            if (id == 0L) continue
            tombstones[id] = maxOf(tombstones[id] ?: 0L, at)
        }
        if (globalClearAt > clearAllAt(ctx)) prefs(ctx).edit().putLong(CLEAR_ALL_KEY, globalClearAt).apply()
        val map = LinkedHashMap<Long, MemItem>()
        all(ctx).forEach { if (!MemLogic.suppressedByGlobalClear(it.updated, globalClearAt) && !MemLogic.suppressedByDeletion(it.updated, tombstones[it.id])) map[it.id] = it }
        for (i in 0 until a.length()) {
            val m = try { fromJson(a.getJSONObject(i)) } catch (e: Exception) { continue }
            val deletedAt = tombstones[m.id] ?: 0L
            if (MemLogic.suppressedByGlobalClear(m.updated, globalClearAt) || MemLogic.suppressedByDeletion(m.updated, deletedAt)) { map.remove(m.id); continue }
            val cur = map[m.id]
            if (cur == null || m.updated > cur.updated) map[m.id] = m
            tombstones.remove(m.id)
        }
        writeTombstones(ctx, tombstones)
        save(ctx, map.values.toList())
    }
}
