package com.anjoo.assistant

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * One-tap publishing of a website project to Netlify (free). The project is sent as one ZIP: the first publish creates a
 * new site, later publishes of the same project update that same site, so the web address stays the same.
 */
object SitePublisher {

    private const val API = "https://api.netlify.com/api/v1"
    private const val TOKEN_KEY = "netlifyToken"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    fun hasToken(ctx: Context): Boolean = prefs(ctx).getString(TOKEN_KEY, "").orEmpty().isNotBlank()
    fun saveToken(ctx: Context, token: String) { prefs(ctx).edit().putString(TOKEN_KEY, token.trim()).apply() }
    fun clearToken(ctx: Context) { prefs(ctx).edit().remove(TOKEN_KEY).apply() }

    private fun siteKey(dir: File) = "netlifySite_" + dir.name

    /** Returns the live address, or throws with a short readable reason. Run on a background thread. */
    fun publish(ctx: Context, dir: File): String {
        val token = prefs(ctx).getString(TOKEN_KEY, "").orEmpty()
        if (token.isBlank()) throw IllegalStateException("No Netlify token set.")
        if (PreviewServer.entry(dir) == null) throw IllegalStateException("The project has no index page.")
        val zip = Coder.zip(dir)
        if (zip.size > 50 * 1024 * 1024) throw IllegalStateException("The project is larger than 50 MB.")
        val siteId = prefs(ctx).getString(siteKey(dir), "").orEmpty()
        var url = if (siteId.isBlank()) "$API/sites" else "$API/sites/$siteId/deploys"
        var res = post(url, token, zip)
        if (res.first == 404 && siteId.isNotBlank()) {
            // The saved site was deleted on Netlify: make a fresh one.
            prefs(ctx).edit().remove(siteKey(dir)).apply()
            url = "$API/sites"
            res = post(url, token, zip)
        }
        val (code, body) = res
        if (code == 401 || code == 403) throw IllegalStateException("The Netlify token is wrong or expired. Set a new token.")
        if (code !in 200..299) throw IllegalStateException("Netlify error $code: " + body.take(160))
        val o = JSONObject(body)
        // Creating a site returns the site itself; updating returns the deploy, which carries site_id.
        val id = o.optString("site_id").ifBlank { o.optString("id") }
        if (siteId.isBlank() && id.isNotBlank() && url.endsWith("/sites")) prefs(ctx).edit().putString(siteKey(dir), o.optString("id")).apply()
        val live = o.optString("ssl_url").ifBlank { o.optString("url") }.ifBlank { o.optString("deploy_ssl_url") }
        if (live.isBlank()) throw IllegalStateException("Published, but the address was not found. Check the Netlify dashboard.")
        return live
    }

    private fun post(url: String, token: String, zip: ByteArray): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 20000
            c.readTimeout = 120000
            c.doOutput = true
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Content-Type", "application/zip")
            c.setFixedLengthStreamingMode(zip.size)
            c.outputStream.use { it.write(zip) }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            return code to text
        } finally {
            c.disconnect()
        }
    }
}
