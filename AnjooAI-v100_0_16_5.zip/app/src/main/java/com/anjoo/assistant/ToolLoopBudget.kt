package com.anjoo.assistant

/** Shared budget and completion message for the foreground chat and background voice agent. */
internal object ToolLoopBudget {
    const val MAX_STEPS: Int = 40

    /** Returns an honest incomplete-state message only when the loop really exhausted its budget. */
    fun incompleteMessage(finishedNormally: Boolean, steps: Int): String? {
        if (finishedNormally || steps < MAX_STEPS) return null
        return "Anjoo reached the limit of ${MAX_STEPS} tool rounds, so the task is not fully verified yet. Check the last verified result or split the work into smaller parts."
    }
}
