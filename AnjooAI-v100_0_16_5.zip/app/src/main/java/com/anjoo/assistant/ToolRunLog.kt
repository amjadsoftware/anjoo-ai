package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Privacy-safe execution metadata. It deliberately never stores arguments or raw tool output. */
object ToolRunLog {
    private const val PREF = "toolRunHistory"
    private const val MAX = 80

    data class Entry(val name: String, val category: String, val status: String, val at: Long, val durationMs: Long)

    @Synchronized fun record(ctx: Context, name: String, result: String, durationMs: Long, thrown: Boolean) {
        if (name in setOf("tool_history", "tools_overview", "list_tools")) return
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val old = try { JSONArray(p.getString(PREF, "[]")) } catch (_: Exception) { JSONArray() }
        val status = classify(result, thrown)
        val row = JSONObject()
            .put("name", name)
            .put("category", ToolRegistry.categoryFor(name).id)
            .put("status", status)
            .put("at", System.currentTimeMillis())
            .put("ms", durationMs.coerceAtLeast(0))
        val next = JSONArray().put(row)
        for (i in 0 until minOf(old.length(), MAX - 1)) next.put(old.optJSONObject(i))
        p.edit().putString(PREF, next.toString()).apply()
    }

    private fun classify(result: String, thrown: Boolean): String {
        if (thrown) return "ISSUE"
        val s = result.lowercase(Locale.ROOT)
        return when {
            s.contains("user ne mana kar diya") || s.contains("user declined") || s.contains("cancelled") -> "CANCELLED"
            s.contains("permission nahi") || s.contains("ijazat nahi") || s.contains("accessibility") && s.contains("on karein") || s.contains("permission required") || s.contains("not configured") || s.contains("needs setup") -> "SETUP"
            s.startsWith("stop:") || s.startsWith("blocked:") || s.contains("nakam:") || s.contains("failed:") || s.contains("error:") || s.startsWith("no such tool") ||
                s.contains("nahi ho saka") || s.contains("nahi bana") || s.contains("not found") || s.contains("could not") || s.contains("unable to") || s.contains("traceback") || s.contains("syntaxerror") || s.contains("compilation error") -> "ISSUE"
            else -> "DONE"
        }
    }

    fun entries(ctx: Context): List<Entry> {
        val a = try { JSONArray(ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getString(PREF, "[]")) } catch (_: Exception) { JSONArray() }
        val out = ArrayList<Entry>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(Entry(o.optString("name"), o.optString("category"), o.optString("status", "DONE"), o.optLong("at"), o.optLong("ms")))
        }
        return out
    }

    fun clear(ctx: Context) { ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit().remove(PREF).apply() }

    fun report(ctx: Context, query: String = "", limit: Int = 12): String {
        val q = query.trim()
        val rows = entries(ctx).filter { q.isBlank() || it.name.contains(q, true) || it.category.contains(q, true) || it.status.contains(q, true) }.take(limit.coerceIn(1, 30))
        if (rows.isEmpty()) return if (q.isBlank()) "No tool execution history yet." else "No recent history found for '$q'."
        val fmt = SimpleDateFormat("d MMM, HH:mm:ss", Locale.getDefault())
        return buildString {
            append("RECENT TOOL ACTIVITY · ").append(rows.size).append("\n")
            for (e in rows) append("• ").append(e.name).append(" [").append(e.status).append("] · ")
                .append(fmt.format(Date(e.at))).append(" · ").append(e.durationMs).append(" ms\n")
            append("\nPrivacy: arguments and raw outputs are not saved in the history.")
        }
    }
}
