package com.anjoo.assistant

import java.util.Locale

/**
 * Capability registry. For every usable model it says, per capability, HOW SURE the app is:
 *  - VERIFIED: this model really answered a request of that kind in this app (a working observation, not a quality test).
 *  - LIKELY / UNLIKELY: only a guess from the model's name and company. It can be wrong.
 *  - UNKNOWN: nothing known.
 * Context size and price are never shown as facts because the app does not hold verified numbers for them.
 * Pure Kotlin so it can be unit tested; [Router.registryRaw] fills it from the live model list and the learned results.
 */
object ModelRegistry {

    enum class Level(val symbol: String) { VERIFIED("✓"), LIKELY("≈"), UNLIKELY("✗"), UNKNOWN("?") }

    class Cap(val key: String, val label: String)

    val CAPS = listOf(
        Cap("chat", "Chat"), Cap("tools", "Phone tools"), Cap("vision", "Photo input"), Cap("pdf", "PDF"),
        Cap("code", "Code"), Cap("think", "Reasoning"), Cap("write", "Writing"),
        Cap("imagegen", "Image generation"), Cap("audio", "Audio understanding"),
        Cap("speech", "Speech / TTS"), Cap("video", "Video"), Cap("translate", "Translation"),
        Cap("embedding", "Embeddings / search"), Cap("rerank", "Reranking"),
        Cap("math", "Math / science"), Cap("longcontext", "Long context"), Cap("moderation", "Safety / moderation")
    )

    /** What the app knows about one model right now. [listed] = is it in the company's own live model list (null = no list fetched). */
    class Raw(
        val providerId: String, val company: String, val model: String,
        val vision: Boolean, val pdf: Boolean, val tools: Boolean,
        val score: Map<String, Int>,            // "code", "think", "write" -> 0..10 name-based score
        val verified: Set<String>,              // capability keys observed to work
        val ok: Int, val fail: Int, val avgMs: Long, val listed: Boolean?
    ) {
        val id: String get() = "$providerId|$model"
    }

    class Info(val raw: Raw, val levels: Map<String, Level>) {
        fun level(cap: String): Level = levels[cap] ?: Level.UNKNOWN
        val verifiedCount: Int get() = levels.values.count { it == Level.VERIFIED }
    }

    /** Which capability a successful request of this task proves. */
    fun capForTask(taskName: String): String = when (taskName) {
        "PHONE" -> "tools"; "CODE" -> "code"; "THINK" -> "think"; "WRITE" -> "write"; "VISION" -> "vision"; "WEB" -> "chat"
        "IMAGE" , "IMAGEGEN" -> "imagegen"; "AUDIO" -> "audio"; "SPEECH", "TTS", "TRANSCRIBE" -> "speech"
        "VIDEO" -> "video"; "TRANSLATE" -> "translate"; "EMBEDDING", "SEARCH" -> "embedding"
        "RERANK" -> "rerank"; "MATH" -> "math"; "LONG_CONTEXT" -> "longcontext"; "MODERATION" -> "moderation"; else -> "chat"
    }

    private fun byScore(s: Int?): Level = when {
        s == null -> Level.UNKNOWN
        s >= 7 -> Level.LIKELY
        s <= 4 -> Level.UNLIKELY
        else -> Level.UNKNOWN
    }

    fun info(r: Raw): Info {
        val m = LinkedHashMap<String, Level>()
        fun put(key: String, guess: Level) { m[key] = if (key in r.verified) Level.VERIFIED else guess }
        put("chat", Level.LIKELY)
        put("tools", if (r.tools) Level.LIKELY else Level.UNLIKELY)
        put("vision", if (r.vision) Level.LIKELY else Level.UNLIKELY)
        put("pdf", if (r.pdf) Level.LIKELY else Level.UNLIKELY)
        put("code", byScore(r.score["code"]))
        put("think", byScore(r.score["think"]))
        put("write", byScore(r.score["write"]))

        // Name-based hints are intentionally only LIKELY/UNKNOWN, never proof that an API call works.
        // The app's successful task observations remain the only source of VERIFIED capability marks.
        val id = (r.providerId + " " + r.model).lowercase(Locale.ROOT)
        fun hint(key: String, regex: Regex, default: Level = Level.UNKNOWN) {
            m[key] = if (key in r.verified) Level.VERIFIED else if (regex.containsMatchIn(id)) Level.LIKELY else default
        }
        hint("imagegen", Regex("(dall[- ]?e|image[- ]?gen|imagen|stable[- ]?diffusion|\\bflux\\b|\\bsora\\b|pollinations|fal-ai)"), Level.UNLIKELY)
        hint("audio", Regex("(audio|whisper|transcri|speech|realtime|omni|audio-preview|gemini.*live)"))
        hint("speech", Regex("(tts|text-to-speech|speech|whisper|transcri|eleven|orpheus|playai|audio)"), Level.UNKNOWN)
        hint("video", Regex("(video|veo|sora|kling|runway|luma|hunyuan-video)"), Level.UNLIKELY)
        hint("translate", Regex("(translate|translation|multilingual|qwen|gemini|gpt|claude|mistral|deepseek|llama)"))
        hint("embedding", Regex("(embed|embedding|text-embedding|bge-|e5-|gte-|jina-embeddings)"), Level.UNLIKELY)
        hint("rerank", Regex("(rerank|reranker|jina-reranker|bge-reranker|cohere.*rerank)"), Level.UNLIKELY)
        hint("math", Regex("(math|mathstral|reasoner|deepseek-r|o[134]|qwen.*math|gpt-5|claude-opus)"))
        hint("longcontext", Regex("(long-context|longcontext|1m|200k|128k|256k|context)"))
        hint("moderation", Regex("(moderation|moderator|guard|safeguard|prompt-guard|shield)"), Level.UNLIKELY)
        return Info(r, m)
    }

    /**
     * Filters and orders the list. [need] = capability keys that must not be UNLIKELY (verified ones come first);
     * [verifiedOnly] keeps only models that proved every needed capability (or, with no needs, any capability).
     */
    fun filter(all: List<Info>, query: String, need: Set<String>, verifiedOnly: Boolean): List<Info> {
        val q = query.trim().lowercase(Locale.ROOT)
        return all.filter { i ->
            (q.isEmpty() || i.raw.model.lowercase(Locale.ROOT).contains(q) || i.raw.company.lowercase(Locale.ROOT).contains(q)) &&
                need.all { i.level(it) != Level.UNLIKELY } &&
                (!verifiedOnly || (if (need.isEmpty()) i.verifiedCount > 0 else need.all { i.level(it) == Level.VERIFIED }))
        }.sortedWith(compareByDescending<Info> { i -> need.count { i.level(it) == Level.VERIFIED } }
            .thenByDescending { it.verifiedCount }.thenBy { it.raw.company }.thenBy { it.raw.model })
    }

    fun legend(): String = "✓ confirmed by real use   ≈ guessed from the name only   ✗ probably not   ? unknown"

    /** Two short lines for one row of the list. */
    fun line(i: Info): String {
        val r = i.raw
        val caps = CAPS.joinToString("  ") { it.label + i.level(it.key).symbol }
        val record = if (r.ok + r.fail == 0) "not used in this app yet" else r.ok.toString() + " replies OK, " + r.fail + " fail" + (if (r.avgMs > 0) ", ~" + r.avgMs + " ms" else "")
        val listed = when (r.listed) { true -> "in the company's list: yes"; false -> "in the company's list: not found"; null -> "company list: not fetched" }
        return r.company + " · " + r.model + "\n" + caps + "\n" + record + " · " + listed + " · context and price: unknown"
    }
}
