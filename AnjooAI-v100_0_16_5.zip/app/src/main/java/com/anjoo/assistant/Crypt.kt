package com.anjoo.assistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Encryption of everything Anjoo keeps in the "Anjoo AI" folder (AES-256-GCM).
 *
 * One random data key is made on the phone and locked inside the Android Keystore, so other apps (and anyone who
 * copies the folder) only see unreadable bytes. A second copy of that data key, locked with YOUR passphrase, can be
 * written into the folder ("Key Backups/data-key.anjoowrap") so a reinstall can open the files again.
 * Files that are not encrypted yet (older versions) are still read normally and are encrypted when they are next saved.
 */
object Crypt {
    private val MAGIC = "ANJENC1".toByteArray(Charsets.US_ASCII)
    private const val ALIAS = "anjoo_data_key_wrap"
    private const val P_DEK = "dek_wrapped"
    const val WRAP_FILE = "data-key.anjoowrap"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo_crypt", Context.MODE_PRIVATE)

    private fun wrapKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return g.generateKey()
    }

    /** The data key (made on first use). Null only if the Keystore is broken: callers then refuse to write. */
    @Synchronized private fun dek(ctx: Context): SecretKeySpec? = try {
        val saved = prefs(ctx).getString(P_DEK, null)
        if (saved != null) {
            val raw = Base64.decode(saved, Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, wrapKey(), GCMParameterSpec(128, raw.copyOfRange(0, 12)))
            SecretKeySpec(c.doFinal(raw, 12, raw.size - 12), "AES")
        } else {
            val k = ByteArray(32).also { SecureRandom().nextBytes(it) }
            storeDek(ctx, k)
            SecretKeySpec(k, "AES")
        }
    } catch (e: Exception) { null }

    private fun storeDek(ctx: Context, k: ByteArray) {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, wrapKey())
        val ct = c.doFinal(k)
        prefs(ctx).edit().putString(P_DEK, Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)).apply()
    }

    fun available(ctx: Context): Boolean = dek(ctx) != null

    fun isEnc(head: ByteArray): Boolean = head.size >= MAGIC.size && MAGIC.indices.all { head[it] == MAGIC[it] }

    // ---------------------------------------------------------------- bytes

    fun encrypt(ctx: Context, plain: ByteArray): ByteArray? {
        val key = dek(ctx) ?: return null
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        return MAGIC + iv + c.doFinal(plain)
    }

    /** Plain bytes. Files that were never encrypted come back unchanged; null = encrypted but cannot be opened. */
    fun decrypt(ctx: Context, data: ByteArray): ByteArray? {
        if (!isEnc(data)) return data
        val key = dek(ctx) ?: return null
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, data.copyOfRange(MAGIC.size, MAGIC.size + 12)))
            c.doFinal(data, MAGIC.size + 12, data.size - MAGIC.size - 12)
        } catch (e: Exception) { null }
    }

    // ---------------------------------------------------------------- files (streams, for big files)

    private fun copy(i: InputStream, o: OutputStream) { val b = ByteArray(16384); while (true) { val n = i.read(b); if (n < 0) break; o.write(b, 0, n) } }

    /** Writes [src] encrypted to [dst]. */
    fun encryptFile(ctx: Context, src: File, dst: File): Boolean {
        val key = dek(ctx) ?: return false
        return try {
            dst.parentFile?.mkdirs()
            val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
            FileOutputStream(dst).use { fo ->
                fo.write(MAGIC); fo.write(iv)
                CipherOutputStream(fo, c).use { co -> FileInputStream(src).use { copy(it, co) } }
            }
            true
        } catch (e: Exception) { try { dst.delete() } catch (e2: Exception) {}; false }
    }

    /** Writes the plain content of [src] to [dst] (copies as is when [src] was never encrypted). False = could not open. */
    fun decryptFile(ctx: Context, src: File, dst: File): Boolean {
        return try {
            dst.parentFile?.mkdirs()
            FileInputStream(src).use { fi ->
                val head = ByteArray(MAGIC.size)
                val n = fi.read(head)
                if (n != MAGIC.size || !isEnc(head)) {
                    FileInputStream(src).use { i2 -> FileOutputStream(dst).use { copy(i2, it) } }
                    return true
                }
                val key = dek(ctx) ?: return false
                val iv = ByteArray(12); if (fi.read(iv) != 12) return false
                val c = Cipher.getInstance("AES/GCM/NoPadding")
                c.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                FileOutputStream(dst).use { fo -> CipherInputStream(fi, c).use { copy(it, fo) } }
            }
            true
        } catch (e: Exception) { try { dst.delete() } catch (e2: Exception) {}; false }
    }

    fun readText(ctx: Context, f: File): String? = decrypt(ctx, f.readBytes())?.toString(Charsets.UTF_8)

    fun writeText(ctx: Context, f: File, text: String): Boolean {
        val e = encrypt(ctx, text.toByteArray(Charsets.UTF_8)) ?: return false
        f.parentFile?.mkdirs(); f.writeBytes(e); return true
    }

    // ---------------------------------------------------------------- recovery after reinstall

    private fun derive(pass: CharArray, salt: ByteArray) =
        SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(pass, salt, 200_000, 256)).encoded, "AES")

    /** The data key, locked with the passphrase, as text to store in the folder. */
    fun wrapForPassphrase(ctx: Context, pass: CharArray): String? {
        val key = dek(ctx) ?: return null
        val rnd = SecureRandom()
        val salt = ByteArray(16).also { rnd.nextBytes(it) }
        val iv = ByteArray(12).also { rnd.nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, derive(pass, salt), GCMParameterSpec(128, iv))
        val ct = c.doFinal(key.encoded)
        return JSONObject().put("app", "AnjooAI").put("type", "datakey-enc").put("v", 1)
            .put("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .put("iv", Base64.encodeToString(iv, Base64.NO_WRAP))
            .put("ct", Base64.encodeToString(ct, Base64.NO_WRAP)).toString()
    }

    /** Installs the data key from a passphrase-locked copy (after a reinstall). Returns null when it worked, else the reason. */
    @Synchronized fun unwrapWithPassphrase(ctx: Context, json: String, pass: CharArray): String? = try {
        val o = JSONObject(json)
        if (o.optString("type") != "datakey-enc") "This does not look like a valid recovery file."
        else {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, derive(pass, Base64.decode(o.getString("salt"), Base64.NO_WRAP)),
                GCMParameterSpec(128, Base64.decode(o.getString("iv"), Base64.NO_WRAP)))
            val k = c.doFinal(Base64.decode(o.getString("ct"), Base64.NO_WRAP))
            if (k.size != 32) "The recovery file is damaged." else { storeDek(ctx, k); null }
        }
    } catch (e: javax.crypto.AEADBadTagException) { "The passphrase is wrong (or the file is damaged)." }
    catch (e: Exception) { "Recovery failed: " + (e.message ?: e.javaClass.simpleName) }
}
