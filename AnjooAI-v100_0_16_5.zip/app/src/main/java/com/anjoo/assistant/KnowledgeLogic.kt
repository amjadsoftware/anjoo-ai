package com.anjoo.assistant

import java.util.Locale

/** Pure retrieval/chunking/privacy helpers shared by KnowledgeBase and JVM tests. */
object KnowledgeLogic {
    const val CHUNK_CHARS = 1500
    const val OVERLAP_CHARS = 180

    fun redact(text: String): Pair<String, Int> {
        var out = text.replace("\u0000", "")
        var count = 0
        val patterns = listOf(
            Regex("(?i)(\\b(?:api[_ -]?key|access[_ -]?token|refresh[_ -]?token|client[_ -]?secret|password|passwd|authorization)\\b\\s*[:=]\\s*)([^\\s,;]{8,})"),
            Regex("(?i)(\\b(?:cvv|cvc|otp|pin)\\b\\s*[:=]\\s*)([0-9]{3,8})"),
            Regex("\\b(?:\\d[ -]?){13,19}\\b")
        )
        for (rx in patterns) {
            val matches = rx.findAll(out).toList()
            if (matches.isNotEmpty()) {
                count += matches.size
                out = rx.replace(out) { m ->
                    if (m.groupValues.size > 2) m.groupValues[1] + "[REDACTED]" else "[REDACTED PAYMENT NUMBER]"
                }
            }
        }
        return out to count
    }

    fun split(text: String, maxChunks: Int = 1800): List<String> {
        val clean = text.trim()
        if (clean.isEmpty()) return emptyList()
        val out = ArrayList<String>()
        var start = 0
        while (start < clean.length && out.size < maxChunks) {
            var end = minOf(clean.length, start + CHUNK_CHARS)
            if (end < clean.length) {
                val floor = start + (CHUNK_CHARS * 2 / 3)
                val para = clean.lastIndexOf("\n\n", end)
                val space = clean.lastIndexOf(' ', end)
                val cut = maxOf(para, space)
                if (cut >= floor) end = cut
            }
            val part = clean.substring(start, end).trim()
            if (part.isNotEmpty()) out.add(part)
            if (end >= clean.length) break
            start = (end - OVERLAP_CHARS).coerceAtLeast(start + 1)
        }
        return out
    }

    /** Remove intentional retrieval overlap and reconstruct the original source text. */
    fun reconstruct(chunks: List<String>): String {
        val sb = StringBuilder()
        for (piece in chunks) {
            if (sb.isEmpty()) sb.append(piece) else {
                val max = minOf(OVERLAP_CHARS + 40, sb.length, piece.length)
                var overlap = 0
                for (n in max downTo 1) {
                    if (sb.regionMatches(sb.length - n, piece, 0, n, false)) { overlap = n; break }
                }
                sb.append(piece.substring(overlap))
            }
        }
        return sb.toString()
    }

    fun expand(tokens: Set<String>): Set<String> {
        val groups = listOf(
            setOf("job", "work", "nokri", "kaam", "duty"),
            setOf("wife", "biwi", "shohar", "husband"),
            setOf("phone", "mobile", "cell", "telephone"),
            setOf("price", "cost", "rate", "qeemat", "keemat"),
            setOf("project", "app", "application", "software"),
            setOf("memory", "yaad", "knowledge", "maloomat")
        )
        val out = tokens.toMutableSet()
        for (group in groups) if (tokens.any { it in group }) out.addAll(group)
        return out
    }

    fun score(query: String, title: String, content: String, pinned: Boolean, updated: Long, now: Long): Double {
        val terms = expand(MemLogic.words(query))
        if (terms.isEmpty()) return if (pinned) 1.0 else 0.0
        val words = MemLogic.words(content)
        val matched = words.intersect(terms)
        val coverage = matched.size.toDouble() / terms.size.coerceAtLeast(1)
        val density = matched.size.toDouble() / words.size.coerceAtLeast(1)
        val titleHits = MemLogic.words(title).intersect(terms).size
        val phrase = if (query.trim().length >= 4 && content.contains(query.trim(), true)) 2.0 else 0.0
        val ageDays = ((now - updated).coerceAtLeast(0L)) / 86_400_000.0
        val freshness = 1.0 / (1.0 + ageDays / 90.0)
        return coverage * 8.0 + density * 5.0 + titleHits * 2.2 + phrase + (if (pinned) 1.5 else 0.0) + freshness * 0.5
    }

    /** Cosine similarity for normalized or raw finite vectors; returns null for invalid/mismatched vectors. */
    fun cosine(a: FloatArray, b: FloatArray): Double? {
        if (a.isEmpty() || a.size != b.size) return null
        var dot = 0.0
        var an = 0.0
        var bn = 0.0
        for (i in a.indices) {
            val x = a[i].toDouble()
            val y = b[i].toDouble()
            if (!x.isFinite() || !y.isFinite()) return null
            dot += x * y
            an += x * x
            bn += y * y
        }
        if (an <= 0.0 || bn <= 0.0) return null
        return (dot / (kotlin.math.sqrt(an) * kotlin.math.sqrt(bn))).coerceIn(-1.0, 1.0)
    }

    fun snippet(content: String, terms: Set<String>, max: Int = 420): String {
        if (content.length <= max) return content
        val low = content.lowercase(Locale.ROOT)
        val idx = terms.map { low.indexOf(it) }.filter { it >= 0 }.minOrNull() ?: 0
        val start = (idx - max / 4).coerceAtLeast(0)
        val end = (start + max).coerceAtMost(content.length)
        return (if (start > 0) "…" else "") + content.substring(start, end).trim() + (if (end < content.length) "…" else "")
    }
}
