package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.LinkedHashMap

/** Optional opt-in Gemini semantic index. Original documents and vectors remain in the app's private SQLite DB. */
object KnowledgeEmbeddings {
    const val MODEL = "gemini-embedding-2"
    const val DIMENSIONS = 768
    private const val BATCH = 16
    private const val PREFS = "anjoo"
    private const val CACHE_MAX = 32

    @Volatile private var running = false
    private val queryCache = object : LinkedHashMap<String, FloatArray>(CACHE_MAX, .75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, FloatArray>?): Boolean = size > CACHE_MAX
    }

    fun enabled(ctx: Context): Boolean = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("semanticKnowledge", false)

    fun clearQueryCache() { synchronized(queryCache) { queryCache.clear() } }

    fun status(ctx: Context): String = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("semanticIndexStatus", "Not indexed") ?: "Not indexed"

    private fun apiKey(ctx: Context): String {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val key = Providers.geminiKey(p).trim()
        if (key.isBlank()) throw IOException("Semantic search ke liye Settings mein Google Gemini API key configure karein.")
        return key
    }

    private fun request(ctx: Context, action: String, body: JSONObject): JSONObject {
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:$action").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("content-type", "application/json")
            conn.setRequestProperty("x-goog-api-key", apiKey(ctx))
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val detail = try { JSONObject(raw).getJSONObject("error").optString("message") } catch (_: Exception) { raw.take(240) }
                throw IOException("Gemini Embedding HTTP $code: ${detail.take(300)}")
            }
            return JSONObject(raw)
        } finally { conn.disconnect() }
    }

    private fun queryVector(ctx: Context, query: String): FloatArray {
        val key = query.trim().lowercase()
        synchronized(queryCache) { queryCache[key]?.let { return it } }
        val content = JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "task: search result | query: ${query.take(6000)}")))
        val body = JSONObject().put("model", "models/$MODEL").put("content", content)
            .put("embedContentConfig", JSONObject().put("outputDimensionality", DIMENSIONS))
        val arr = request(ctx, "embedContent", body).optJSONObject("embedding")?.optJSONArray("values")
            ?: throw IOException("Gemini ne query embedding return nahi ki.")
        val vector = FloatArray(arr.length()) { arr.optDouble(it).toFloat() }
        require(vector.size == DIMENSIONS) { "Embedding dimension mismatch: ${vector.size}" }
        synchronized(queryCache) { queryCache[key] = vector }
        return vector
    }

    fun search(ctx: Context, query: String, limit: Int = 5): List<KnowledgeHit> {
        require(query.isNotBlank()) { "Search query khaali hai." }
        if (!enabled(ctx)) throw IOException("AI Semantic Search off hai. Memory & Knowledge settings mein opt-in karein.")
        val q = queryVector(ctx, query)
        return KnowledgeBase.vectorSearch(ctx, q, limit, MODEL)
    }

    /** Indexes one document using bounded batches. Safe to call again: only missing/outdated vectors are sent. */
    @Synchronized
    fun indexDocument(ctx: Context, docId: String, onProgress: ((Int, Int) -> Unit)? = null): Int {
        check(enabled(ctx)) { "AI Semantic Search off hai." }
        val chunks = KnowledgeBase.chunksMissingEmbeddings(ctx, docId, MODEL)
        if (chunks.isEmpty()) return 0
        var done = 0
        for (start in chunks.indices step BATCH) {
            if (!enabled(ctx)) break
            val batch = chunks.subList(start, minOf(start + BATCH, chunks.size))
            val requests = JSONArray()
            batch.forEach { item ->
                val text = "title: ${item.title.take(180)} | text: ${item.text}"
                val req = JSONObject().put("model", "models/$MODEL")
                    .put("content", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text))))
                    .put("embedContentConfig", JSONObject().put("outputDimensionality", DIMENSIONS))
                requests.put(req)
            }
            val response = request(ctx, "batchEmbedContents", JSONObject().put("requests", requests))
            val embeddings = response.optJSONArray("embeddings") ?: throw IOException("Embedding batch mein vectors nahi mile.")
            require(embeddings.length() == batch.size) { "Embedding batch result count mismatch." }
            for (i in 0 until batch.size) {
                val values = embeddings.getJSONObject(i).optJSONArray("values") ?: throw IOException("Chunk ${batch[i].ordinal + 1} ka vector missing hai.")
                val vector = FloatArray(values.length()) { values.optDouble(it).toFloat() }
                require(vector.size == DIMENSIONS) { "Embedding dimensions mismatch: ${vector.size}" }
                KnowledgeBase.saveEmbedding(ctx, batch[i].chunkId, docId, MODEL, vector)
                done++
            }
            onProgress?.invoke(done, chunks.size)
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("semanticIndexStatus", "Indexing ${done}/${chunks.size} chunks for document")
                .apply()
        }
        return done
    }

    /** Resumes all missing vectors. Run on a worker thread, never the main thread. */
    @Synchronized
    fun indexAll(ctx: Context): Int {
        if (!enabled(ctx)) throw IOException("AI Semantic Search off hai.")
        if (running) return 0
        running = true
        try {
            val docs = KnowledgeBase.list(ctx, limit = 1000)
            var total = 0
            for (doc in docs) {
                if (!enabled(ctx)) break
                total += indexDocument(ctx, doc.id)
            }
            val stats = KnowledgeBase.semanticStats(ctx)
            val status = "Indexed ${stats.first}/${stats.second} chunks"
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("semanticIndexStatus", status).apply()
            return total
        } finally { running = false }
    }

    fun scheduleDocument(ctx: Context, docId: String) {
        if (!enabled(ctx)) return
        Thread {
            try {
                indexDocument(ctx.applicationContext, docId)
                val stats = KnowledgeBase.semanticStats(ctx)
                ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString("semanticIndexStatus", "Indexed ${stats.first}/${stats.second} chunks").apply()
            } catch (e: Exception) {
                ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString("semanticIndexStatus", "Index pending: ${e.message?.take(140) ?: "provider error"}").apply()
            }
        }.start()
    }

    fun scheduleAll(ctx: Context) {
        if (!enabled(ctx)) return
        Thread {
            try { indexAll(ctx.applicationContext) }
            catch (e: Exception) {
                ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString("semanticIndexStatus", "Index pending: ${e.message?.take(140) ?: "provider error"}").apply()
            }
        }.start()
    }
}
