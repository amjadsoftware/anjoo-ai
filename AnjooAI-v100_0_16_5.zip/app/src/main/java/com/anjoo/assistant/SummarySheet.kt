package com.anjoo.assistant

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * One line of the Claude-style "Summary" timeline.
 * kind 0 = a thought (small dot, grey text), kind 1 = a command (terminal badge, bold text).
 * state: 0 running, 1 done, 2 done with an issue, 3 failed.
 */
class TItem(
    val kind: Int, val text: String, val sub: String = "", val state: Int = 1,
    /** badge glyph: 0 terminal, 1 book (read), 2 magnifier (search), 3 checklist, 4 file, 5 globe */
    val icon: Int = 0,
    /** optional code preview: diff lines, each starting with "+ ", "- " or "  " */
    val code: String = ""
)

/** Three orange dots that light up one after another: the "···" in front of "Running command". */
class DotsLoader(context: Context, private val color: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = this@DotsLoader.color }
    private var phase = 0f
    private var anim: ValueAnimator? = null

    private fun begin() {
        if (anim != null) return
        anim = ValueAnimator.ofFloat(0f, 3f).apply {
            duration = 1200; repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun end() { anim?.cancel(); anim = null }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); if (visibility == VISIBLE) begin() }
    override fun onDetachedFromWindow() { end(); super.onDetachedFromWindow() }
    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE && isAttachedToWindow) begin() else if (visibility != VISIBLE) end()
    }

    override fun onDraw(c: Canvas) {
        val r = height * 0.13f
        val gap = (width - 6 * r) / 2f
        val cy = height / 2f
        for (i in 0 until 3) {
            // each dot has its own pulse, shifted a third of a turn
            val d = ((phase - i) % 3f + 3f) % 3f
            val a = if (d < 1f) 1f - d * 0.65f else 0.35f
            paint.alpha = (255 * a).toInt()
            c.drawCircle(r + i * (2 * r + gap), cy, r, paint)
        }
    }
}

/** The small outlined badge in front of a command row: a rounded square with a line-icon inside. */
class TermBadge(context: Context, private val fill: Int, private val edge: Int, private var ink: Int, private val icon: Int = 0) : View(context) {
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val box = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    fun tint(c: Int) { ink = c; invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val d = resources.displayMetrics.density
        val rad = 9f * d
        box.style = Paint.Style.FILL; box.color = fill
        c.drawRoundRect(0f, 0f, w, h, rad, rad, box)
        box.style = Paint.Style.STROKE; box.strokeWidth = 1.2f * d; box.color = edge
        c.drawRoundRect(0.6f * d, 0.6f * d, w - 0.6f * d, h - 0.6f * d, rad, rad, box)
        stroke.color = ink; stroke.strokeWidth = 1.7f * d
        path.reset()
        when (icon) {
            1 -> { // open book
                path.moveTo(w * 0.50f, h * 0.36f); path.cubicTo(w * 0.42f, h * 0.30f, w * 0.30f, h * 0.30f, w * 0.24f, h * 0.33f)
                path.lineTo(w * 0.24f, h * 0.68f); path.cubicTo(w * 0.30f, h * 0.65f, w * 0.42f, h * 0.65f, w * 0.50f, h * 0.72f)
                path.cubicTo(w * 0.58f, h * 0.65f, w * 0.70f, h * 0.65f, w * 0.76f, h * 0.68f)
                path.lineTo(w * 0.76f, h * 0.33f); path.cubicTo(w * 0.70f, h * 0.30f, w * 0.58f, h * 0.30f, w * 0.50f, h * 0.36f)
                path.lineTo(w * 0.50f, h * 0.72f)
                c.drawPath(path, stroke)
            }
            2 -> { // magnifier
                c.drawCircle(w * 0.46f, h * 0.46f, w * 0.17f, stroke)
                c.drawLine(w * 0.59f, h * 0.59f, w * 0.72f, h * 0.72f, stroke)
            }
            3 -> { // checklist
                path.moveTo(w * 0.27f, h * 0.37f); path.lineTo(w * 0.31f, h * 0.41f); path.lineTo(w * 0.38f, h * 0.32f)
                c.drawPath(path, stroke)
                c.drawLine(w * 0.48f, h * 0.36f, w * 0.73f, h * 0.36f, stroke)
                c.drawRoundRect(w * 0.27f, h * 0.58f, w * 0.38f, h * 0.69f, 2f * d, 2f * d, stroke)
                c.drawLine(w * 0.48f, h * 0.635f, w * 0.73f, h * 0.635f, stroke)
            }
            4 -> { // file
                path.moveTo(w * 0.32f, h * 0.26f); path.lineTo(w * 0.56f, h * 0.26f); path.lineTo(w * 0.70f, h * 0.40f)
                path.lineTo(w * 0.70f, h * 0.74f); path.lineTo(w * 0.32f, h * 0.74f); path.close()
                path.moveTo(w * 0.56f, h * 0.26f); path.lineTo(w * 0.56f, h * 0.40f); path.lineTo(w * 0.70f, h * 0.40f)
                c.drawPath(path, stroke)
            }
            5 -> { // globe
                c.drawCircle(w * 0.5f, h * 0.5f, w * 0.22f, stroke)
                c.drawOval(w * 0.41f, h * 0.28f, w * 0.59f, h * 0.72f, stroke)
                c.drawLine(w * 0.28f, h * 0.5f, w * 0.72f, h * 0.5f, stroke)
            }
            else -> { // terminal >_
                path.moveTo(w * 0.30f, h * 0.35f); path.lineTo(w * 0.45f, h * 0.50f); path.lineTo(w * 0.30f, h * 0.65f)
                c.drawPath(path, stroke)
                c.drawLine(w * 0.52f, h * 0.66f, w * 0.70f, h * 0.66f, stroke)
            }
        }
    }
}

object SummarySheet {
    class Colors(val bg: Int, val ink: Int, val muted: Int, val line: Int, val badge: Int)

    /** Lets the caller keep an open sheet up to date while work is still running. */
    class Handle internal constructor(private val dlg: Dialog, private val rebuild: () -> Unit) {
        private val h = Handler(Looper.getMainLooper())
        private var pending = false
        @Volatile var open = true
            internal set

        /** Redraw the list soon (calls close together are merged into one redraw). */
        fun refresh() {
            if (!open || pending) return
            pending = true
            h.postDelayed({ pending = false; if (open) rebuild() }, 160)
        }

        fun dismiss() { try { if (dlg.isShowing) dlg.dismiss() } catch (_: Exception) {} }
    }

    private val ORANGE = 0xFFD9633A.toInt()
    private val RED = 0xFFE5534B.toInt()
    private val AMBER = 0xFFD29922.toInt()

    /**
     * Opens the Summary sheet. [items] is asked again on every refresh. While [live] is true the sheet ends with
     * a pulsing orange dot and the [liveLabel] word ("Thinking"), the running command shimmers.
     */
    fun show(
        ctx: Context, c: Colors, items: () -> List<TItem>, live: () -> Boolean, liveLabel: () -> String
    ): Handle {
        val d = ctx.resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val dlg = object : Dialog(ctx) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                window?.decorView?.let { Touch.feedback(it, ev) }
                return super.dispatchTouchEvent(ev)
            }
        }
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val radius = dp(28).toFloat()
        val serif = Typeface.SERIF
        val serifBold = Typeface.create(Typeface.SERIF, Typeface.BOLD)

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(c.bg)
                cornerRadii = floatArrayOf(radius, radius, radius, radius, 0f, 0f, 0f, 0f)
            }
            setPadding(dp(18), dp(10), dp(18), dp(20))
        }
        root.addView(View(ctx).apply {
            background = GradientDrawable().apply { setColor(c.line); cornerRadius = dp(3).toFloat() }
        }, LinearLayout.LayoutParams(dp(40), dp(5)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(12) })

        val head = FrameLayout(ctx)
        head.addView(TextView(ctx).apply {
            text = "✕"; textSize = 20f; setTextColor(c.ink); gravity = Gravity.CENTER
            setOnClickListener { dlg.dismiss() }
        }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.START or Gravity.CENTER_VERTICAL))
        head.addView(TextView(ctx).apply {
            text = "Summary"; textSize = 19f; setTextColor(c.ink)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL); gravity = Gravity.CENTER
        }, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        root.addView(head, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(10) })

        val scroll = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), dp(6), dp(4), dp(16)) }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val anims = ArrayList<android.animation.Animator>()
        fun stopAnims() { for (a in anims) a.cancel(); anims.clear() }

        /** A soft light that sweeps over the text, like Claude's running line. */
        fun shimmer(tv: TextView, base: Int, hi: Int) {
            val w = dp(170).toFloat()
            val g = LinearGradient(0f, 0f, w, 0f, intArrayOf(base, hi, base), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
            val m = Matrix()
            tv.paint.shader = g
            val a = ValueAnimator.ofFloat(-w, w * 1.6f).apply {
                duration = 1600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                addUpdateListener { m.setTranslate(it.animatedValue as Float, 0f); g.setLocalMatrix(m); tv.invalidate() }
                start()
            }
            anims.add(a)
        }

        /** A small code preview card: green rows for added lines, red for removed, fading out at the bottom. */
        fun codeBox(code: String): View {
            val lines = code.split("\n").take(12)
            val frame = FrameLayout(ctx).apply {
                background = GradientDrawable().apply { setColor(c.badge); setStroke(dp(1), c.line); cornerRadius = dp(12).toFloat() }
                setPadding(0, dp(8), 0, dp(8))
            }
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            var addN = 0; var delN = 0
            for (ln in lines) {
                val kind = if (ln.startsWith("+ ")) 1 else if (ln.startsWith("- ")) 2 else 0
                val gut = when (kind) { 1 -> { addN++; "+$addN" }; 2 -> { delN++; "-$delN" }; else -> "" }
                val row = LinearLayout(ctx).apply {
                    orientation = LinearLayout.HORIZONTAL
                    if (kind == 1) setBackgroundColor(Color.argb(46, 63, 185, 80))
                    if (kind == 2) setBackgroundColor(Color.argb(46, 248, 81, 73))
                    setPadding(dp(12), dp(2), dp(8), dp(2))
                }
                row.addView(TextView(ctx).apply { text = gut; textSize = 13f; typeface = Typeface.MONOSPACE; setTextColor(c.muted) }, LinearLayout.LayoutParams(dp(42), -2))
                row.addView(TextView(ctx).apply {
                    text = if (ln.length >= 2) ln.substring(2) else ""
                    textSize = 13f; typeface = Typeface.MONOSPACE; setTextColor(c.ink); maxLines = 1
                }, LinearLayout.LayoutParams(0, -2, 1f))
                col.addView(row, LinearLayout.LayoutParams(-1, -2))
            }
            frame.addView(col, FrameLayout.LayoutParams(-1, -2))
            if (lines.size >= 8) frame.addView(View(ctx).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, c.bg))
            }, FrameLayout.LayoutParams(-1, dp(48), Gravity.BOTTOM))
            return frame
        }

        val nodeCenter = dp(19)   // every node (dot or badge) is centred this far below the top of its row
        val leftW = dp(44)

        fun addRow(item: TItem, first: Boolean, last: Boolean, active: Boolean) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val left = FrameLayout(ctx)
            // the connecting line runs behind the nodes: from the first node's centre to the last node's centre
            val lineH = if (last) nodeCenter else -1
            val lp = FrameLayout.LayoutParams(dp(2), lineH).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                if (first) topMargin = nodeCenter
            }
            if (!(first && last)) left.addView(View(ctx).apply { setBackgroundColor(c.line) }, lp)

            val running = item.state == 0 && live()
            if (active) {
                val dot = View(ctx).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ORANGE) } }
                left.addView(dot, FrameLayout.LayoutParams(dp(11), dp(11), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = nodeCenter - dp(5) })
                anims.add(ObjectAnimator.ofFloat(dot, "alpha", 1f, 0.3f, 1f).apply {
                    duration = 1100; repeatCount = ValueAnimator.INFINITE; interpolator = AccelerateDecelerateInterpolator(); start()
                })
            } else if (item.kind == 1) {
                val tint = when (item.state) { 2 -> AMBER; 3 -> RED; else -> c.ink }
                left.addView(TermBadge(ctx, c.badge, c.line, tint, item.icon),
                    FrameLayout.LayoutParams(dp(34), dp(34), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = nodeCenter - dp(17) })
            } else {
                left.addView(View(ctx).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c.muted) }
                    alpha = 0.55f
                }, FrameLayout.LayoutParams(dp(10), dp(10), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = nodeCenter - dp(5) })
            }
            row.addView(left, LinearLayout.LayoutParams(leftW, -1))

            val right = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(6), dp(7), 0, dp(if (last) 4 else 18)) }
            val tv = TextView(ctx).apply {
                text = item.text
                textSize = if (item.kind == 1 && !active) 19f else 19f
                setLineSpacing(0f, 1.1f)
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                if (active) { typeface = serif; setTextColor(c.muted) }
                else if (item.kind == 1) { typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); setTextColor(c.ink) }
                else { typeface = serif; setTextColor(c.muted) }
            }
            right.addView(tv, LinearLayout.LayoutParams(-1, -2))
            if (running || active) shimmer(tv, c.muted, c.ink)
            if (item.sub.isNotBlank() && !active) right.addView(TextView(ctx).apply {
                text = item.sub; textSize = if (item.icon == 0) 14f else 16f
                setTextColor(if (item.state >= 3) RED else if (item.state == 2) AMBER else c.muted)
                typeface = if (item.icon == 0) Typeface.MONOSPACE else Typeface.SANS_SERIF
                maxLines = 2; ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(4), 0, 0)
            }, LinearLayout.LayoutParams(-1, -2))
            if (item.code.isNotBlank() && !active) right.addView(codeBox(item.code), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            row.addView(right, LinearLayout.LayoutParams(0, -2, 1f))
            list.addView(row, LinearLayout.LayoutParams(-1, -2))
        }

        fun rebuild() {
            val atBottom = scroll.getChildAt(0)?.let { v -> v.bottom - (scroll.height + scroll.scrollY) < dp(48) } ?: true
            val oldY = scroll.scrollY
            stopAnims()
            list.removeAllViews()
            val isLive = live()
            val all = ArrayList<TItem>(items())
            if (all.isEmpty() && !isLive) all.add(TItem(0, "Kuch nahi hua"))
            for ((i, item) in all.withIndex()) addRow(item, i == 0, i == all.lastIndex && !isLive, false)
            if (isLive) addRow(TItem(0, liveLabel()), all.isEmpty(), true, true)
            if (atBottom) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } else scroll.post { scroll.scrollTo(0, oldY) }
        }

        val handle = Handle(dlg) { rebuild() }
        dlg.setOnDismissListener { handle.open = false; stopAnims() }
        dlg.setContentView(root)
        rebuild()
        dlg.show()
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(-1, (ctx.resources.displayMetrics.heightPixels * 0.92f).toInt())
            setGravity(Gravity.BOTTOM)
        }
        // slide up from the bottom
        root.post {
            root.translationY = root.height.toFloat().coerceAtLeast(dp(300).toFloat())
            root.animate().translationY(0f).setDuration(260).setInterpolator(AccelerateDecelerateInterpolator()).start()
        }
        return handle
    }
}
