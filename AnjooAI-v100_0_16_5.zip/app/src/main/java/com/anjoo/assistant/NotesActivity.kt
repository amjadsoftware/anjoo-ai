package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Notes that live in the phone's own database, so they open, search and save with no internet.
 * "⋮" lets you move notes and tasks to another phone with a small sync file (no server needed).
 */
class NotesActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }


    private lateinit var th: CyberTheme
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var search: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun box(fill: Int, stroke: Int, r: Int) = GradientDrawable().apply { setColor(fill); setStroke(dp(1), stroke); cornerRadius = r.toFloat() }
    private fun faint() = Color.argb(70, 128, 128, 128)

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        Touch.feedback(window.decorView, ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        th = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)]
        Style.bars(window, th)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(th.bg); setPadding(dp(12), dp(30), dp(12), dp(8)) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text = "‹"; textSize = 28f; setTextColor(th.ink); setPadding(dp(8), 0, dp(14), dp(4)); setOnClickListener { finish() } })
        head.addView(TextView(this).apply { text = "📝 Notes"; textSize = 20f; setTextColor(th.ink); typeface = Typeface.create("sans-serif-medium", Typeface.BOLD) },
            LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(this).apply {
            text = "+  New"; textSize = 14f; setTextColor(th.bg); gravity = Gravity.CENTER
            background = box(th.accent, th.accent, dp(18)); setPadding(dp(16), dp(8), dp(16), dp(8))
            setOnClickListener { edit(null) }
        })
        head.addView(TextView(this).apply {
            text = "⋮"; textSize = 22f; setTextColor(th.ink); gravity = Gravity.CENTER; setPadding(dp(14), 0, dp(6), 0)
            setOnClickListener { syncMenu() }
        })
        root.addView(head)

        status = TextView(this).apply { textSize = 12f; setTextColor(th.muted); setPadding(dp(8), dp(6), dp(8), dp(2)) }
        root.addView(status)

        search = EditText(this).apply {
            hint = "Search notes"; setHintTextColor(th.muted); setTextColor(th.ink); textSize = 15f
            background = box(th.surface, faint(), dp(20)); setPadding(dp(16), dp(10), dp(16), dp(10))
            inputType = InputType.TYPE_CLASS_TEXT; maxLines = 1; isSingleLine = true
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) { refresh() }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(8) })

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val q = search.text.toString()
        val notes = Notes.all(this, q)
        val net = if (Offline.online(this)) "online" else "offline"
        status.text = "● Saved on this phone  ·  " + notes.size + (if (q.isBlank()) " notes" else " found") + "  ·  " + net
        list.removeAllViews()
        if (notes.isEmpty()) {
            list.addView(TextView(this).apply {
                text = if (q.isBlank()) "No notes yet.\nTap \"+ New\", or tell Anjoo: \"note: buy milk tomorrow\" (works without internet too)." else "No note matches this word."
                textSize = 14f; setTextColor(th.muted); setPadding(dp(6), dp(24), dp(6), 0)
            })
            return
        }
        for (n in notes) list.addView(card(n), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
    }

    private fun card(n: Note): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = box(th.surface, faint(), dp(12)); setPadding(dp(14), dp(10), dp(14), dp(10))
            setOnClickListener { edit(n) }
        }
        c.addView(TextView(this).apply {
            text = (if (n.pinned) "📌 " else "") + n.title.ifEmpty { "(no title)" }; textSize = 15.5f; setTextColor(th.ink)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD); maxLines = 2
        })
        val prev = n.body.trim()
        if (prev.isNotEmpty() && prev != n.title) c.addView(TextView(this).apply {
            text = prev; textSize = 13.5f; setTextColor(th.muted); maxLines = 3; setPadding(0, dp(4), 0, 0)
            textDirection = android.view.View.TEXT_DIRECTION_FIRST_STRONG
        })
        c.addView(TextView(this).apply {
            text = SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH).format(Date(n.updated)); textSize = 12f; setTextColor(th.muted); setPadding(0, dp(6), 0, 0)
        })
        return c
    }

    private fun edit(n: Note?) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val t = EditText(this).apply { hint = "Title (optional)"; setText(n?.title ?: ""); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES }
        val body = EditText(this).apply {
            hint = "Write your note"; setText(n?.body ?: ""); minLines = 6; gravity = Gravity.TOP or Gravity.START
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            textDirection = android.view.View.TEXT_DIRECTION_FIRST_STRONG
        }
        box.addView(t); box.addView(body)
        val b = AlertDialog.Builder(this).setTitle(if (n == null) "New note" else "Edit note").setView(box)
            .setPositiveButton("Save") { _, _ ->
                val title = t.text.toString()
                val text = body.text.toString()
                if (title.isBlank() && text.isBlank()) return@setPositiveButton
                if (n == null) Notes.add(this, title, text) else Notes.update(this, n.id, title, text)
                refresh()
            }
            .setNegativeButton("Cancel", null)
        if (n != null) b.setNeutralButton("More") { _, _ -> more(n, t.text.toString(), body.text.toString()) }
        b.show()
    }

    private fun more(n: Note, title: String, body: String) {
        val items = arrayOf(if (n.pinned) "📌  Unpin" else "📌  Pin to top", "📤  Share text", "📋  Copy", "🗑  Delete")
        AlertDialog.Builder(this).setTitle(n.title.ifEmpty { "Note" }).setItems(items) { _, i ->
            when (i) {
                0 -> { Notes.setPinned(this, n.id, !n.pinned); refresh() }
                1 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, (if (title.isNotBlank()) title + "\n\n" else "") + body), "Share note"))
                2 -> {
                    (getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager)
                        .setPrimaryClip(android.content.ClipData.newPlainText("Anjoo", (if (title.isNotBlank()) title + "\n\n" else "") + body))
                    Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
                }
                else -> AlertDialog.Builder(this).setMessage("Delete this note?").setPositiveButton("Delete") { _, _ -> Notes.delete(this, n.id); refresh() }
                    .setNegativeButton("Cancel", null).show()
            }
        }.show()
    }

    // ---- sync file between phones

    private fun syncMenu() {
        AlertDialog.Builder(this).setTitle("Sync with another phone")
            .setMessage("Notes and tasks are saved in one small file. Send the file to another phone and choose \"Merge from file\". The most recently edited note is kept. No server or internet is needed.")
            .setPositiveButton("Save sync file") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                    .setType("application/json").putExtra(Intent.EXTRA_TITLE, "anjoo-sync-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.ENGLISH).format(Date()) + ".json"), 51)
            }
            .setNegativeButton("Merge from file") { _, _ ->
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), 52)
            }
            .setNeutralButton("Close", null).show()
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data
        if (res != RESULT_OK || uri == null) return
        Thread {
            val msg = try {
                if (req == 51) {
                    contentResolver.openOutputStream(uri)?.use { it.write(SyncFile.export(this).toByteArray(Charsets.UTF_8)) }
                    "Sync file saved."
                } else {
                    val txt = contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    SyncFile.merge(this, txt.take(5_000_000))
                }
            } catch (e: Exception) { "Could not do it: " + (e.message ?: "") }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show(); refresh() }
        }.start()
    }
}
