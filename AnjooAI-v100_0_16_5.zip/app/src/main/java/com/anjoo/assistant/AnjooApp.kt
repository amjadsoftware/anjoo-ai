package com.anjoo.assistant

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

/**
 * Accessibility safety net for every screen: any tappable view that has no spoken label
 * gets one (from its own text, or from the text of a child), so TalkBack can read it.
 * Also gives icon-only tappables a 48dp minimum touch area via a small TouchDelegate-free padding rule.
 */
class AnjooApp : Application() {
    override fun onCreate() {
        super.onCreate()
        registerActivityLifecycleCallbacks(object : ActivityLifecycleCallbacks {
            override fun onActivityResumed(a: Activity) { A11y.install(a) }
            override fun onActivityCreated(a: Activity, b: Bundle?) {}
            override fun onActivityStarted(a: Activity) {}
            override fun onActivityPaused(a: Activity) {}
            override fun onActivityStopped(a: Activity) {}
            override fun onActivitySaveInstanceState(a: Activity, b: Bundle) {}
            override fun onActivityDestroyed(a: Activity) {}
        })
    }
}

object A11y {
    private const val TAG_KEY = 0x7f0a_0001.toInt()

    fun install(a: Activity) {
        try {
            val decor = a.window?.decorView ?: return
            if (decor.getTag(TAG_KEY) != null) return
            decor.setTag(TAG_KEY, true)
            var last = 0L
            decor.viewTreeObserver.addOnGlobalLayoutListener {
                val now = SystemClock.uptimeMillis()
                if (now - last < 700) return@addOnGlobalLayoutListener
                last = now
                try { fix(decor, a.resources.displayMetrics.density) } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    private fun fix(v: View, density: Float) {
        if (v.isClickable && v.contentDescription.isNullOrBlank() && v !is EditText) {
            val label = labelOf(v)
            if (label.isNotBlank()) v.contentDescription = label.trim().take(80)
        }
        // Small tappable text buttons get a 48dp minimum height so they are easy to hit.
        if (v.isClickable && v is TextView && v !is EditText && v.visibility == View.VISIBLE) {
            val min = (48 * density).toInt()
            if (v.height in 1 until min && v.minHeight < min) v.minHeight = min
        }
        if (v.isClickable && v is ImageView && v.contentDescription.isNullOrBlank()) {
            v.contentDescription = "Button"
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) fix(v.getChildAt(i), density)
    }

    private fun labelOf(v: View): String {
        if (v is TextView) return v.text?.toString().orEmpty()
        if (v is ViewGroup) {
            val sb = StringBuilder()
            for (i in 0 until v.childCount) {
                val t = labelOf(v.getChildAt(i))
                if (t.isNotBlank()) { if (sb.isNotEmpty()) sb.append(", "); sb.append(t.trim()) }
                if (sb.length > 80) break
            }
            return sb.toString()
        }
        return ""
    }
}
