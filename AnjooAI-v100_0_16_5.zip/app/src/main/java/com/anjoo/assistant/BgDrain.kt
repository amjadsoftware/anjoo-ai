package com.anjoo.assistant

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Background outbox. Messages typed while offline wait in the [Outbox]. The moment the phone gets internet again
 * (even when the app is closed) Android starts [BgDrainService], which answers them one by one in the background,
 * keeps the answers in a small file and posts a notification. When the app is opened the answers appear in the chat.
 * Nothing that needs the user (calls, SMS, replies) is ever sent from here: the agent runs in the safe background mode.
 */
object BgDrain {
    private const val JOB_ID = 8310
    private const val FILE = "bg_results.json"
    private val running = AtomicBoolean(false)

    /** Set by the chat screen while it is visible, so new answers appear at once. */
    @Volatile var onResults: (() -> Unit)? = null

    /** True while the background job (not the open app) is working; heavy extras such as screenshots are skipped then. */
    @Volatile var inBackground = false

    class Result(val question: String, val answer: String, val at: Long, val proj: String = "")

    fun auto(ctx: Context): Boolean = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean("bgAuto", true)

    /** Asks Android to run the drain as soon as any network is available. Safe to call as often as needed. */
    fun schedule(ctx: Context) {
        try {
            if (!auto(ctx) || (Outbox.count(ctx) == 0 && WebsiteBuilder.pendingList(ctx).isEmpty())) return
            val js = ctx.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            val info = JobInfo.Builder(JOB_ID, ComponentName(ctx, BgDrainService::class.java))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setBackoffCriteria(30_000L, JobInfo.BACKOFF_POLICY_EXPONENTIAL)
                .apply { if (Outbox.count(ctx) == 0) setMinimumLatency(90_000L) }   // website-only: give the open app time to finish first
                .build()
            js.schedule(info)
        } catch (e: Exception) {}
    }

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)

    @Synchronized
    private fun saveResult(ctx: Context, q: String, a: String, proj: String = "") {
        val arr = try { JSONArray(file(ctx).readText()) } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject().put("q", q).put("a", a).put("at", System.currentTimeMillis()).put("p", proj))
        // Keep the newest 100 so the file never grows without limit.
        val out = JSONArray()
        for (i in maxOf(0, arr.length() - 100) until arr.length()) out.put(arr.get(i))
        file(ctx).writeText(out.toString())
    }

    /** Returns every finished background answer and empties the box. */
    @Synchronized
    fun takeAll(ctx: Context): List<Result> {
        val f = file(ctx)
        if (!f.exists()) return emptyList()
        val list = ArrayList<Result>()
        try {
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Result(o.optString("q"), o.optString("a"), o.optLong("at"), o.optString("p")))
            }
        } catch (e: Exception) {}
        f.delete()
        return list
    }

    fun waiting(ctx: Context): Int = try { JSONArray(file(ctx).readText()).length() } catch (e: Exception) { 0 }

    /** Blocking. Answers the waiting messages while the network works. Returns how many are still waiting. */
    fun drain(ctx: Context): Int {
        val app = ctx.applicationContext
        TokenLedger.bind(app)
        if (!running.compareAndSet(false, true)) return Outbox.count(app) + WebsiteBuilder.pendingList(app).size
        var done = 0
        try {
            val key = app.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getString("key", "") ?: ""
            if (key.isEmpty()) return Outbox.count(app) + WebsiteBuilder.pendingList(app).size
            val stamp = SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH)
            for (item in Outbox.all(app)) {
                if (!Offline.online(app)) break
                val reply = try {
                    AgentJobs.newAgent(app).ask("[Saved offline at " + stamp.format(Date(item.at)) + ", answered in the background] " + item.text)
                } catch (e: Exception) {
                    if (Offline.isNetworkError(e) || !Offline.online(app)) break   // net dropped again: keep it, try next time
                    Errors.explain(e, "Background kaam")
                }
                if (reply.isBlank()) continue
                saveResult(app, item.text, reply)
                Outbox.remove(app, item.id)
                done++
            }
            // Website builds that were interrupted (no internet, app closed) continue from where they stopped.
            for (name in WebsiteBuilder.pendingList(app)) {
                if (!Offline.online(app)) break
                if (WebsiteBuilder.isBusy()) continue   // the open app is building right now
                if (WebsiteBuilder.bumpTries(app, name) > 3) { WebsiteBuilder.removePending(app, name); continue }
                inBackground = true
                val r = try {
                    WebsiteBuilder.run(app, { false }, JSONObject().put("action", "continue").put("project", name))
                } catch (e: Exception) {
                    if (Offline.isNetworkError(e) || !Offline.online(app)) break
                    ""
                } finally { inBackground = false }
                if (r.startsWith("PROJECT_BUILT")) {
                    WebsiteBuilder.removePending(app, name)
                    saveResult(app, "🌐 Adhoori website: " + name,
                        "Website background mein poori ho gayi. Neeche project card se Preview dekhein, ya 🌐 se publish karein.", name)
                    done++
                }
            }
        } catch (e: Exception) {
        } finally {
            running.set(false)
        }
        if (done > 0) {
            AlertService.post(app, "Anjoo ne background mein $done jawab tayyar kar diye", "App kholein, jawab chat mein aa jayenge.")
            try { onResults?.invoke() } catch (e: Exception) {}
        }
        return Outbox.count(app) + WebsiteBuilder.pendingList(app).size
    }
}

class BgDrainService : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        val app = applicationContext
        Thread {
            val left = try { BgDrain.drain(app) } catch (e: Exception) { 1 }
            jobFinished(params, left > 0)   // true = run again later for what is still waiting
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean = true
}
