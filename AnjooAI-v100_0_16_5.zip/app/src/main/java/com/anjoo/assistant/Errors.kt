package com.anjoo.assistant

import android.content.Context
import java.io.File
import java.io.FileNotFoundException
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * One place that turns any failure into a clear message in three parts: WHAT failed, WHY, and WHAT TO DO.
 * The user should never be left staring at a raw exception text or at a spinner that never ends.
 */
object Errors {

    private class Reason(val why: String, val fix: String)

    private fun httpReason(code: Int, detail: String): Reason = when (code) {
        400 -> Reason("The request was invalid" + tail(detail) + ".", "Try again. If it keeps happening, try a shorter message or another model.")
        401, 403 -> if (detail.contains("API key", true) || code == 401)
            Reason("The API key is wrong or disabled.", "Enter the correct API key in Settings.")
        else Reason("Permission was denied for this action" + tail(detail) + ".", "Check the API key and model in Settings.")
        404 -> Reason("The model or address was not found.", "Check the model name or Base URL in Settings.")
        408 -> Reason("The server did not respond in time.", "Check your internet and try again.")
        413 -> Reason("The file or photo is too large.", "Send a smaller file or fewer photos.")
        429 -> Reason("The provider limit (quota) has been reached.", "Wait a minute and try again, or add another key under 🔑 Keys in the Menu.")
        in 500..599 -> Reason("The provider's server is having a problem right now (error $code).", "Try again in a little while, or choose another model.")
        else -> Reason("The server returned error $code" + tail(detail) + ".", "Try again; if the problem continues, check Settings.")
    }

    private fun tail(d: String) = if (d.isBlank()) "" else ": " + d.take(140)

    private fun reasonOf(e: Throwable): Reason {
        var t: Throwable? = e
        var depth = 0
        while (t != null && depth++ < 6) {
            if (t is ApiException) {
                val detail = (t.message ?: "").replace(Regex("^\\(\\d+\\)\\s*"), "")
                return httpReason(t.code, detail)
            }
            t = t.cause
        }
        val msg = e.message ?: ""
        Regex("^HTTP (\\d{3})(?: - (.*))?$", RegexOption.DOT_MATCHES_ALL).find(msg)?.let {
            return httpReason(it.groupValues[1].toInt(), it.groupValues[2])
        }
        var c: Throwable? = e
        depth = 0
        while (c != null && depth++ < 6) {
            when (c) {
                is SocketTimeoutException -> return Reason("The server did not respond in time (timeout).", "Check your internet and try again.")
                is UnknownHostException -> return Reason("Could not reach the server (no internet or DNS).", "Check Wi-Fi/mobile data, then try again.")
                is javax.net.ssl.SSLException -> return Reason("Could not establish a secure (SSL) connection.", "Check the phone's date/time and network, or try another network.")
                is java.net.ConnectException -> return Reason("Could not connect to the server.", "Check your internet; if you use a Base URL, check that too.")
                is org.json.JSONException -> return Reason("Could not understand the server's reply (wrong format).", "Try again. For a custom provider, check the Base URL and model.")
                is OutOfMemoryError -> return Reason("The phone ran out of memory.", "Send a smaller file or fewer photos, and close other apps.")
                is SecurityException -> return Reason("Android denied the permission.", "Go to Menu > Phone and turn on the required permission.")
                is FileNotFoundException -> return Reason("File or folder not found.", "Check the path or pick the folder again.")
                is android.content.ActivityNotFoundException -> return Reason("No app on the phone can do this.", "Install the required app or try another way.")
            }
            c = c.cause
        }
        if (e is IOException && (msg.contains("ENOSPC") || msg.contains("No space", true)))
            return Reason("The phone storage is full.", "Free up some space and try again.")
        if (msg.contains("No answer came back", true))
            return Reason("The model gave no answer" + (msg.substringAfter("No answer came back.", "").trim().let { if (it.isEmpty()) "" else " ($it)" }) + ".", "Rephrase your question a little or choose another model.")
        return Reason((if (msg.isBlank()) e.javaClass.simpleName else msg.take(220)), "Try again. If it still happens, copy the details from the Menu and send them.")
    }

    /** Message for a failed job. [what] says what was being done, e.g. "Jawab lana". */
    fun explain(e: Throwable, what: String): String {
        val r = reasonOf(e)
        return "⚠️ $what failed.\nReason: ${r.why}\nFix: ${r.fix}"
    }

    /** Text handed back to the model (and shown in the step list) when a tool fails, so it can tell the user plainly. */
    fun tool(name: String, e: Throwable): String {
        val r = reasonOf(e)
        return "FAIL: '$name' tool failed. Reason: ${r.why} Fix: ${r.fix} (Tell the user this reason plainly; do not claim false success.)"
    }

    // ---------- crash report ----------

    private fun crashFile(ctx: Context) = File(ctx.filesDir, "last_crash.txt")

    /** Remembers an app crash so the next start can explain it instead of the app just vanishing. */
    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val old = Thread.getDefaultUncaughtExceptionHandler()
        if (old is CrashHook) return
        Thread.setDefaultUncaughtExceptionHandler(CrashHook(app, old))
    }

    private class CrashHook(val ctx: Context, val old: Thread.UncaughtExceptionHandler?) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try {
                val r = reasonOf(e)
                val top = e.stackTrace.take(8).joinToString("\n") { "  at $it" }
                val stamp = SimpleDateFormat("d MMM HH:mm:ss", Locale.ENGLISH).format(Date())
                crashFile(ctx).writeText("Waqt: $stamp\nThread: ${t.name}\nWajah: ${r.why}\nHal: ${r.fix}\n\nTechnical:\n${e.javaClass.name}: ${e.message}\n$top", Charsets.UTF_8)
            } catch (x: Throwable) {}
            old?.uncaughtException(t, e)
        }
    }

    /** The saved crash report from the last run, if any. It is removed once read. */
    fun takeCrash(ctx: Context): String? = try {
        val f = crashFile(ctx)
        if (f.exists()) f.readText(Charsets.UTF_8).also { f.delete() } else null
    } catch (e: Exception) { null }
}
