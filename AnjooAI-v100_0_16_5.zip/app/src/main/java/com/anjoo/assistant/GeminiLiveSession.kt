package com.anjoo.assistant

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.max

/** Bidirectional low-latency Gemini Live voice session for Anjoo's foreground voice service. */
class GeminiLiveSession(
    private val key: String,
    private val model: String,
    private val voiceName: String,
    private val systemInstruction: String,
    private val listener: Listener
) {
    interface Listener {
        fun onReady()
        fun onStatus(text: String)
        fun onUserTranscript(text: String)
        fun onAssistantTranscript(text: String)
        fun onPlaybackStarted()
        fun onPlaybackFinished()
        fun onInterrupted()
        fun onToolCalls(calls: JSONArray)
        fun onFailure(message: String)
    }

    companion object {
        private const val INPUT_RATE = 16000
        private const val OUTPUT_RATE = 24000
        private const val CHUNK_SAMPLES = 640 // 40 ms at 16 kHz
        private const val END_TURN = "__ANJOO_LIVE_END_TURN__"
    }

    private val client = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build()
    private val live = AtomicBoolean(true)
    private val captureRunning = AtomicBoolean(false)
    private val playbackRunning = AtomicBoolean(false)
    private val captureLock = Any()
    private val playbackQueue = LinkedBlockingQueue<Any>()
    @Volatile private var socket: WebSocket? = null
    @Volatile private var setupReady = false
    /** True only while the CURRENT socket has finished setup; audio is never sent before that. */
    @Volatile private var ready = false
    @Volatile private var generation = 0
    @Volatile private var consecutiveFails = 0
    /** Lets a dropped or time-limited session continue where it left off. */
    @Volatile private var resumeHandle: String? = null
    @Volatile private var microphoneEnabled = true
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var audioTrack: AudioTrack? = null
    @Volatile private var echoCanceler: AcousticEchoCanceler? = null
    private val assistantText = StringBuilder()

    fun start() {
        listener.onStatus("Connecting to live voice...")
        connect()
    }

    @Synchronized
    private fun connect() {
        if (!live.get()) return
        val gen = ++generation
        ready = false
        val encodedKey = URLEncoder.encode(key, "UTF-8")
        val request = Request.Builder()
            .url("wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$encodedKey")
            .build()
        val ws = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                if (gen != generation) { try { webSocket.cancel() } catch (e: Exception) {}; return }
                socket = webSocket
                webSocket.send(JSONObject().put("setup", setupMessage()).toString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (gen != generation) return
                try { handleMessage(JSONObject(text)) }
                catch (e: Exception) { listener.onStatus("Live voice problem: could not understand a message.") }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                if (gen != generation) return
                try { handleMessage(JSONObject(bytes.utf8())) }
                catch (e: Exception) { listener.onStatus("Live voice problem: could not understand a message.") }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                handleDrop(gen, (t.message ?: "Live connection problem: could not connect.").take(120))
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                handleDrop(gen, reason.ifBlank { "Live connection problem: the connection closed." }.take(120))
            }
        })
        socket = ws
    }

    /**
     * Gemini Live connections last only about 10 minutes. Instead of giving up (which used to drop the user
     * to the phone's own voice), reconnect quietly with the saved resumption handle.
     */
    private fun handleDrop(gen: Int, message: String) {
        if (!live.get() || gen != generation) return
        ready = false
        if (consecutiveFails < 3) {
            consecutiveFails++
            val wait = 400L * consecutiveFails
            listener.onStatus("Reconnecting to live voice...")
            thread(name = "AnjooLiveReconnect", isDaemon = true) {
                try { Thread.sleep(wait) } catch (e: InterruptedException) { return@thread }
                if (live.get() && gen == generation) connect()
            }
        } else {
            listener.onFailure(message)
        }
    }

    /** The server announced it will end this connection soon: switch to a fresh one right away. */
    private fun reconnectNow() {
        if (!live.get()) return
        val old = socket
        connect()
        try { old?.cancel() } catch (e: Exception) {}
    }

    private fun setupMessage(): JSONObject {
        val generation = JSONObject()
            .put("responseModalities", JSONArray().put("AUDIO"))
            .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voiceName))))
        val tools = JSONArray().put(JSONObject().put("functionDeclarations", JSONArray(Gemini.DECLARATIONS)))
        return JSONObject()
            .put("model", "models/$model")
            .put("generationConfig", generation)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemInstruction))))
            .put("tools", tools)
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
            // Sliding window keeps long sessions alive; resumption survives the ~10 minute connection limit.
            .put("contextWindowCompression", JSONObject().put("slidingWindow", JSONObject()))
            .put("sessionResumption", JSONObject().also { r -> resumeHandle?.let { h -> r.put("handle", h) } })
    }

    private fun handleMessage(message: JSONObject) {
        if (message.has("setupComplete")) {
            setupReady = true
            ready = true
            consecutiveFails = 0
            startPlayback()
            startCapture()
            listener.onReady()
            return
        }
        message.optJSONObject("sessionResumptionUpdate")?.let { u ->
            val h = u.optString("newHandle")
            if (u.optBoolean("resumable", true) && h.isNotBlank()) resumeHandle = h
        }
        if (message.has("goAway")) { reconnectNow(); return }
        val error = message.optJSONObject("error")
        if (error != null) {
            listener.onFailure((error.optString("message").ifBlank { "Live API error ${error.optInt("code")}" }).take(160))
            return
        }
        val toolCall = message.optJSONObject("toolCall")
        if (toolCall != null) {
            val calls = toolCall.optJSONArray("functionCalls") ?: JSONArray()
            if (calls.length() > 0) listener.onToolCalls(calls)
        }
        val server = message.optJSONObject("serverContent") ?: return
        if (server.optBoolean("interrupted", false)) {
            clearPlayback()
            synchronized(assistantText) { assistantText.setLength(0) }
            listener.onInterrupted()
        }
        val interim = server.optJSONObject("interimInputTranscription")?.optString("text").orEmpty()
        if (interim.isNotBlank()) listener.onStatus("Listening: ${interim.takeLast(100)}")
        val input = server.optJSONObject("inputTranscription")?.optString("text").orEmpty()
        if (input.isNotBlank()) listener.onUserTranscript(input.trim())
        val output = server.optJSONObject("outputTranscription")?.optString("text").orEmpty()
        if (output.isNotBlank()) synchronized(assistantText) { assistantText.append(output) }
        val modelTurn = server.optJSONObject("modelTurn")
        val parts = modelTurn?.optJSONArray("parts")
        if (parts != null) for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            val inline = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data")
            val data = inline?.optString("data").orEmpty()
            if (data.isNotBlank()) {
                try { playbackQueue.offer(Base64.decode(data, Base64.DEFAULT)) } catch (e: Exception) {}
            }
            val text = part.optString("text").orEmpty()
            if (text.isNotBlank()) synchronized(assistantText) { assistantText.append(text) }
        }
        if (server.optBoolean("turnComplete", false)) playbackQueue.offer(END_TURN)
    }

    fun sendToolResponses(responses: JSONArray) {
        val s = socket ?: return
        if (!live.get()) return
        s.send(JSONObject().put("toolResponse", JSONObject().put("functionResponses", responses)).toString())
    }

    /** Pause capture for the app's existing spoken confirmation flow, then resume the live stream. */
    fun pauseMicrophone() {
        microphoneEnabled = false
        try { socket?.send(JSONObject().put("realtimeInput", JSONObject().put("audioStreamEnd", true)).toString()) } catch (e: Exception) {}
        synchronized(captureLock) {
            try { recorder?.stop() } catch (e: Exception) {}
        }
    }

    fun resumeMicrophone() {
        if (!live.get() || !setupReady) return
        microphoneEnabled = true
        startCapture()
    }

    private fun startCapture() {
        if (!live.get() || !setupReady || !microphoneEnabled || !captureRunning.compareAndSet(false, true)) return
        thread(name = "AnjooLiveMic", isDaemon = true) {
            var rec: AudioRecord? = null
            var aec: AcousticEchoCanceler? = null
            try {
                val min = AudioRecord.getMinBufferSize(INPUT_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (min <= 0) throw IllegalStateException("AudioRecord buffer unavailable")
                val bufferBytes = max(min * 2, CHUNK_SAMPLES * 4)
                rec = try { AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, INPUT_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferBytes) } catch (_: Exception) { null }
                if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) {
                    try { rec?.release() } catch (e: Exception) {}
                    rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, INPUT_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferBytes)
                }
                synchronized(captureLock) { recorder = rec }
                try {
                    if (AcousticEchoCanceler.isAvailable()) {
                        aec = AcousticEchoCanceler.create(rec.audioSessionId)
                        aec?.enabled = true
                    }
                } catch (e: Exception) { aec = null }
                synchronized(captureLock) { echoCanceler = aec }
                rec.startRecording()
                val samples = ShortArray(CHUNK_SAMPLES)
                val bytes = ByteArray(CHUNK_SAMPLES * 2)
                while (live.get() && microphoneEnabled) {
                    val count = rec.read(samples, 0, samples.size)
                    if (count <= 0) {
                        if (microphoneEnabled && live.get()) throw IllegalStateException("Microphone read failed: $count")
                        break
                    }
                    if (!microphoneEnabled) break
                    OrbLevel.feedMic(samples, count)
                    var out = 0
                    for (i in 0 until count) {
                        val value = samples[i].toInt()
                        bytes[out++] = (value and 255).toByte()
                        bytes[out++] = ((value shr 8) and 255).toByte()
                    }
                    val chunk = if (out == bytes.size) bytes.clone() else bytes.copyOf(out)
                    val b64 = Base64.encodeToString(chunk, Base64.NO_WRAP)
                    val audio = JSONObject().put("data", b64).put("mimeType", "audio/pcm;rate=16000")
                    if (ready) socket?.send(JSONObject().put("realtimeInput", JSONObject().put("audio", audio)).toString())
                }
            } catch (e: Exception) {
                if (live.get() && microphoneEnabled) listener.onFailure((e.message ?: "Microphone stream stopped.").take(120))
            } finally {
                synchronized(captureLock) {
                    recorder = null
                    echoCanceler = null
                }
                try { rec?.stop() } catch (e: Exception) {}
                try { aec?.release() } catch (e: Exception) {}
                try { rec?.release() } catch (e: Exception) {}
                captureRunning.set(false)
                if (live.get() && setupReady && microphoneEnabled) startCapture()
            }
        }
    }

    private fun startPlayback() {
        if (!playbackRunning.compareAndSet(false, true)) return
        thread(name = "AnjooLiveAudio", isDaemon = true) {
            var track: AudioTrack? = null
            try {
                val min = AudioTrack.getMinBufferSize(OUTPUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
                if (min <= 0) throw IllegalStateException("AudioTrack buffer unavailable")
                track = AudioTrack(android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ASSISTANT).setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH).build(), AudioFormat.Builder().setSampleRate(OUTPUT_RATE).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build(), max(min * 2, OUTPUT_RATE), AudioTrack.MODE_STREAM, 0)
                if (track.state != AudioTrack.STATE_INITIALIZED) throw IllegalStateException("Audio output unavailable")
                audioTrack = track
                track.play()
                var announced = false
                while (live.get()) {
                    val item = playbackQueue.take()
                    if (item === END_TURN) {
                        if (announced) {
                            val finalText = synchronized(assistantText) { assistantText.toString().trim().also { assistantText.setLength(0) } }
                            if (finalText.isNotBlank()) listener.onAssistantTranscript(finalText)
                            listener.onPlaybackFinished()
                        }
                        announced = false
                        continue
                    }
                    val pcm = item as? ByteArray ?: continue
                    if (pcm.isEmpty()) continue
                    if (!announced) { announced = true; listener.onPlaybackStarted() }
                    OrbLevel.feedOut(pcm)
                    var offset = 0
                    while (offset < pcm.size && live.get()) {
                        val n = track.write(pcm, offset, pcm.size - offset)
                        if (n <= 0) break
                        offset += n
                    }
                }
            } catch (e: InterruptedException) {
                Thread.currentThread().interrupt()
            } catch (e: Exception) {
                if (live.get()) listener.onStatus((e.message ?: "Audio playback failed.").take(100))
            } finally {
                audioTrack = null
                try { track?.pause(); track?.flush(); track?.release() } catch (e: Exception) {}
                playbackRunning.set(false)
            }
        }
    }

    private fun clearPlayback() {
        playbackQueue.clear()
        playbackQueue.offer(END_TURN)
        try {
            val t = audioTrack
            if (t != null) { t.pause(); t.flush(); t.play() }
        } catch (e: Exception) {}
    }

    fun close() {
        if (!live.compareAndSet(true, false)) return
        microphoneEnabled = false
        synchronized(captureLock) {
            try { recorder?.stop() } catch (e: Exception) {}
        }
        try { socket?.close(1000, "Voice service stopped") } catch (e: Exception) {}
        playbackQueue.clear()
        playbackQueue.offer(END_TURN)
        try { audioTrack?.pause(); audioTrack?.flush() } catch (e: Exception) {}
        try { echoCanceler?.release() } catch (e: Exception) {}
        client.dispatcher.executorService.shutdown()
        client.connectionPool.evictAll()
    }
}
