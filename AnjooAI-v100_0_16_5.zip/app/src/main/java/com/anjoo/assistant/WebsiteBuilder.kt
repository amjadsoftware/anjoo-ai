package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Website Builder agent. It does NOT replace Code Studio: it orchestrates the pieces that already exist
 * (Coder.build / Coder.revise, Runner.check, checkpoints, ZIP export, the preview card) into one staged workflow
 * with saved progress, so an interrupted job resumes at the first unfinished stage instead of starting again.
 *
 * Honest scope on a phone: sites are static (HTML + CSS + vanilla JS) and run in the built-in WebView. There is no Node,
 * npm, database server or hosting account on the device, so server features are reported as "needs server setup",
 * never faked, and nothing is deployed from here. Every line of the final report comes from a check that really ran.
 *
 * Stages: plan -> build -> run_check -> audit -> seo -> deploy_docs -> verify
 */
object WebsiteBuilder {

    /** Folder name of the project built or changed most recently; the chat uses it to always attach the project card. */
    @Volatile var lastDirName: String? = null

    /** Live progress line for the chat (set by the chat while the builder runs; null otherwise). */
    @Volatile var onProgress: ((String) -> Unit)? = null
    private fun say(msg: String) { try { onProgress?.invoke(msg) } catch (_: Exception) { } }

    private val STAGES = listOf("plan", "build", "images", "premium_review", "run_check", "audit", "visual_check", "seo", "deploy_docs", "verify")

    private val STAGE_LABEL = mapOf(
        "plan" to "Plan and checklist",
        "build" to "Design and build",
        "images" to "Images (local files, no empty boxes)",
        "premium_review" to "Premium design and interaction review",
        "visual_check" to "Visual check (phone screenshots)",
        "run_check" to "Run in preview",
        "audit" to "Security / accessibility / responsive audit",
        "seo" to "SEO files",
        "deploy_docs" to "Deployment files",
        "verify" to "Final verification"
    )

    // ------------------------------------------------------------------ saved state (outside the project, so it is never exported or overwritten)

    private fun stateFile(ctx: Context, key: String): File {
        val d = File(ctx.filesDir, "website_state").also { it.mkdirs() }
        return File(d, key.replace(Regex("[^A-Za-z0-9_.-]"), "_") + ".json")
    }

    private fun load(ctx: Context, key: String): JSONObject =
        try { JSONObject(stateFile(ctx, key).readText(Charsets.UTF_8)) } catch (e: Exception) { JSONObject() }

    private fun save(ctx: Context, key: String, st: JSONObject) {
        try { stateFile(ctx, key).writeText(st.toString(), Charsets.UTF_8) } catch (e: Exception) { }
    }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    private fun done(st: JSONObject, stage: String): Boolean = st.optJSONObject("done")?.optBoolean(stage, false) == true

    private fun mark(st: JSONObject, stage: String, ok: Boolean, note: String) {
        val d = st.optJSONObject("done") ?: JSONObject().also { st.put("done", it) }
        d.put(stage, ok)
        val n = st.optJSONObject("notes") ?: JSONObject().also { st.put("notes", it) }
        n.put(stage, note.take(1500))
    }

    private fun findDir(ctx: Context, a: JSONObject): File? {
        val hint = a.optString("project", "").trim().ifEmpty { prefs(ctx).getString("wbLast", "") ?: "" }
        val all = Coder.list(ctx)
        if (hint.isBlank()) return all.firstOrNull()
        return all.firstOrNull { it.name.equals(hint, true) }
            ?: all.firstOrNull { Coder.name(it).equals(hint, true) }
            ?: all.firstOrNull { Coder.name(it).contains(hint, true) }
    }

    // ------------------------------------------------------------------ entry point

    fun run(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val action = a.optString("action", "start").trim().lowercase().replace(' ', '_').replace('-', '_')
        // One build at a time: the open app and the background job must never work on the same site together.
        val heavy = action !in setOf("status", "progress", "plan", "export", "export_zip")
        if (heavy && !busy.compareAndSet(false, true)) return "Website Builder is busy with another task. Please write again in a little while."
        val result = try {
            when (action) {
                "start", "new", "build" -> start(ctx, confirm, a)
                "continue", "resume" -> resume(ctx, confirm, a)
                "status", "progress", "plan" -> status(ctx, a)
                "change", "edit", "revise" -> change(ctx, confirm, a)
                "audit" -> single(ctx, confirm, a, "audit")
                "seo" -> single(ctx, confirm, a, "seo")
                "deploy", "deploy_docs", "deployment" -> single(ctx, confirm, a, "deploy_docs")
                "verify", "report" -> single(ctx, confirm, a, "verify")
                "export", "export_zip" -> {
                    val dir = findDir(ctx, a) ?: return "No website project found. Create one first with action=start."
                    CodeTools.run(ctx, confirm, "project_studio", JSONObject().put("action", "export_zip").put("project", Coder.name(dir))) ?: "Export failed."
                }
                else -> "website_builder actions: start, continue, status, change, audit, seo, deploy, verify, export."
            }
        } catch (e: Exception) {
            "Website Builder stopped: " + (e.message ?: e.javaClass.simpleName) + ". Say 'continue' to resume from the same point."
        }
        finally { if (heavy) busy.set(false) }
        trackPending(ctx, a, action, result)
        return result
    }

    private val busy = java.util.concurrent.atomic.AtomicBoolean(false)
    fun isBusy(): Boolean = busy.get()

    // ------------------------------------------------------------------ background continue (internet returns)

    private const val PENDING_KEY = "wbPending"

    fun pendingList(ctx: Context): List<String> =
        prefs(ctx).getString(PENDING_KEY, "").orEmpty().split(',').map { it.trim() }.filter { it.isNotEmpty() }

    private fun setPending(ctx: Context, list: List<String>) { prefs(ctx).edit().putString(PENDING_KEY, list.distinct().joinToString(",")).apply() }
    fun addPending(ctx: Context, name: String) { if (name !in pendingList(ctx)) setPending(ctx, pendingList(ctx) + name) }
    fun removePending(ctx: Context, name: String) {
        setPending(ctx, pendingList(ctx) - name)
        prefs(ctx).edit().remove("wbTry_$name").apply()
    }
    /** Counts one background attempt for this project and returns the new count. */
    fun bumpTries(ctx: Context, name: String): Int {
        val n = prefs(ctx).getInt("wbTry_$name", 0) + 1
        prefs(ctx).edit().putInt("wbTry_$name", n).apply()
        return n
    }

    /** An unfinished build is remembered, so it is continued by itself when the internet returns; a finished one is forgotten. */
    private fun trackPending(ctx: Context, a: JSONObject, action: String, result: String) {
        if (action in setOf("status", "progress", "plan", "export", "export_zip")) return
        val name = findDir(ctx, a)?.name ?: lastDirName ?: return
        when {
            result.startsWith("PROJECT_BUILT") -> removePending(ctx, name)
            result.startsWith("PROJECT_IN_PROGRESS") || result.startsWith("Website Builder stopped") -> {
                addPending(ctx, name)
                BgDrain.schedule(ctx)
            }
        }
    }

    // ------------------------------------------------------------------ start / resume

    private fun start(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val request = a.optString("message", a.optString("request", a.optString("task", ""))).trim()
        if (request.isBlank()) return "What kind of website do you want? Write the requirements in the message (purpose, pages, colors/style, language)."
        val log = StringBuilder()

        // 1) PLAN
        say("Step 1/" + STAGES.size + " · Making the plan (pages, style, colors)...")
        val bp = SiteBlueprints.match(request)
        if (bp != null) say("Template found: " + bp.label + " (pages and sections start from a ready structure)")
        val plan = makePlan(ctx, request, a.optString("domain", ""), bp?.prompt() ?: "")
        say("Step 1/" + STAGES.size + " · Plan ready: " + plan.optString("summary", "").take(80))
        log.append("✔ Plan: ").append(plan.optString("summary", "ready")).append('\n')

        // 2) BUILD (Code Studio builder, with the plan + design rules as the brief)
        Coder.pageByPage = true
        var created: File? = null
        // Save progress the moment the project folder exists, so an interrupted build (no internet, app closed) can be resumed.
        Coder.onDirCreated = { d ->
            created = d
            lastDirName = d.name
            prefs(ctx).edit().putString("wbLast", Coder.name(d)).apply()
            val s0 = JSONObject().put("request", request).put("plan", plan).put("project", Coder.name(d))
                .put("domain", a.optString("domain", "")).put("created", System.currentTimeMillis())
            mark(s0, "plan", true, plan.optString("summary", ""))
            mark(s0, "build", false, "Build started")
            save(ctx, d.name, s0)
        }
        val built: Pair<File, String>? = try {
            Coder.build(ctx, brief(request, plan), "auto", true, Coder.deepDefault(ctx), {}, { n -> say("Step 2/" + STAGES.size + " · Build · " + n) })
        } catch (e: CancelledException) {
            throw e
        } catch (e: java.util.concurrent.CancellationException) {
            throw e
        } catch (e: Exception) {
            if (created == null) throw e
            say("Build stopped, files so far are saved")
            null
        } finally { Coder.pageByPage = false; Coder.onDirCreated = null }
        if (built == null) {
            val d = created!!
            return "PROJECT_IN_PROGRESS: '" + Coder.name(d) + "' build stopped midway (network or another problem), but " +
                Coder.readFiles(d).size + " file(s) so far are saved. Tell the user to write 'continue' and the work will finish from the same point. The project card is attached below."
        }
        val (dir, notes) = built
        val key = dir.name
        lastDirName = key
        prefs(ctx).edit().putString("wbLast", Coder.name(dir)).apply()
        val st = JSONObject().put("request", request).put("plan", plan).put("project", Coder.name(dir))
            .put("domain", a.optString("domain", "")).put("created", System.currentTimeMillis())
        mark(st, "plan", true, plan.optString("summary", ""))
        val brokenNow = Coder.brokenFiles(dir)
        mark(st, "build", brokenNow.isEmpty(), if (brokenNow.isEmpty()) notes else "Adhoori files: " + brokenNow.joinToString(", "))
        save(ctx, key, st)
        if (brokenNow.isNotEmpty())
            return "PROJECT_IN_PROGRESS: '" + Coder.name(dir) + "' these files are incomplete or empty: " + brokenNow.joinToString(", ") +
                ". Tell the user to write 'continue'; it will complete only these. The project card is attached below."
        log.append("✔ Build: ").append(Coder.readFiles(dir).size).append(" files\n")

        log.append(runStages(ctx, confirm, dir, st, key))
        return finish(ctx, dir, st, log.toString(), true)
    }

    private fun resume(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val dir = findDir(ctx, a) ?: return "No website project found. Create one first with action=start."
        val st = load(ctx, dir.name)
        if (st.length() == 0) return "This project has no Website Builder record ('" + Coder.name(dir) + "'). Use action=change to make changes or run action=audit."
        lastDirName = dir.name
        // An interrupted build: finish the missing pages and cut-off files first, keeping everything already written.
        if (!done(st, "build")) {
            say("Finishing the unfinished build (files already made will not change)...")
            val existing = Coder.readFiles(dir).keys.joinToString(", ").ifBlank { "none yet" }
            val broken = Coder.brokenFiles(dir)
            val plan = st.optJSONObject("plan")
            val pages = list(plan?.optJSONArray("pages")) ?: "see plan"
            val instr = "The website build was interrupted (no internet or the app closed). Finish it now without redoing finished work.\n" +
                "Planned pages: " + pages + "\nFiles that exist now: " + existing + "\n" +
                (if (broken.isEmpty()) "" else "Empty or cut-off files to rewrite completely: " + broken.joinToString(", ") + "\n") +
                "Write every missing page and shared file, keep the same navbar, footer, CSS classes and design as the existing files, and link only to files that exist.\n\n" +
                brief(st.optString("request", ""), plan ?: JSONObject())
            val r = try { Coder.revise(ctx, dir, instr, Coder.deepDefault(ctx), {}, { n -> say("Resume · " + n) }) } catch (e: CancelledException) { throw e } catch (e: Exception) { "ERR: " + (e.message ?: e.javaClass.simpleName) }
            val ok = !r.startsWith("ERR:") && Coder.readFiles(dir).isNotEmpty() && Coder.brokenFiles(dir).isEmpty()
            mark(st, "build", ok, r.take(300))
            save(ctx, dir.name, st)
            if (!ok) return "PROJECT_IN_PROGRESS: '" + Coder.name(dir) + "' is not finished yet (" + r.take(160) + "). Tell the user to write 'continue' again. The " + Coder.readFiles(dir).size + " file(s) so far are saved."
        }
        val left = STAGES.filter { !done(st, it) }
        if (left.isEmpty()) return finish(ctx, dir, st, "All stages are already complete.\n", false)
        val log = StringBuilder("Resume: baqi stages: " + left.joinToString(", ") + "\n")
        log.append(runStages(ctx, confirm, dir, st, dir.name))
        return finish(ctx, dir, st, log.toString(), false)
    }

    private fun single(ctx: Context, confirm: (String) -> Boolean, a: JSONObject, stage: String): String {
        val dir = findDir(ctx, a) ?: return "No website project found. Create one first with action=start."
        val st = load(ctx, dir.name)
        val note = runStage(ctx, confirm, dir, st, stage)
        val passed = stagePassed(stage, note)
        mark(st, stage, passed, note)
        save(ctx, dir.name, st)
        return (if (passed) "PASS · " else "BLOCKED · ") + STAGE_LABEL[stage] + ":\n" + note +
            (if (passed) "" else "\n\nThis stage was not marked complete. Fix the issues and run action=continue.") +
            "\n\nPROJECT_EDITED: '" + Coder.name(dir) + "'"
    }

    /** A change request through normal chat: revise the real files, then re-run the checks that depend on them. */
    private fun change(ctx: Context, confirm: (String) -> Boolean, a: JSONObject): String {
        val dir = findDir(ctx, a) ?: return "No website project found."
        val msg = a.optString("message", a.optString("instruction", "")).trim()
        if (msg.isBlank()) return "Write what to change in the message."
        // Safety checkpoint before editing, so the previous version can be restored.
        val cp = CodeTools.run(ctx, confirm, "project_studio", JSONObject().put("action", "checkpoint").put("project", Coder.name(dir)).put("message", "Before change: " + msg.take(60))) ?: ""
        val filesBefore = Coder.readFiles(dir).keys.toSet()
        say("Small change: changing only the necessary files...")
        Coder.focusChange = true
        val res = try { Coder.revise(ctx, dir, msg, Coder.deepDefault(ctx), {}, { n -> say(n) }) } finally { Coder.focusChange = false }
        val st = load(ctx, dir.name)
        // A small edit only needs the quick checks again. A new or removed file also refreshes SEO and deploy files.
        val filesChanged = Coder.readFiles(dir).keys.toSet() != filesBefore
        val redo = if (filesChanged) listOf("images", "run_check", "audit", "seo", "deploy_docs", "verify") else listOf("images", "run_check", "audit", "verify")
        for (s in redo)
            (st.optJSONObject("done") ?: JSONObject().also { st.put("done", it) }).put(s, false)
        save(ctx, dir.name, st)
        val log = StringBuilder("✔ Change applied. ").append(cp).append('\n').append(res.take(600)).append('\n')
        log.append(runStages(ctx, confirm, dir, st, dir.name))
        return finish(ctx, dir, st, log.toString(), false)
    }

    private fun status(ctx: Context, a: JSONObject): String {
        val dir = findDir(ctx, a) ?: return "No website project found."
        val st = load(ctx, dir.name)
        if (st.length() == 0) return "Project '" + Coder.name(dir) + "' was not made by Website Builder; no record exists."
        val sb = StringBuilder("Project: ").append(Coder.name(dir)).append('\n')
        val plan = st.optJSONObject("plan")
        if (plan != null) {
            sb.append("Summary: ").append(plan.optString("summary")).append('\n')
            list(plan.optJSONArray("pages"))?.let { sb.append("Pages: ").append(it).append('\n') }
            list(plan.optJSONArray("features"))?.let { sb.append("Features: ").append(it).append('\n') }
            list(plan.optJSONArray("assumptions"))?.let { sb.append("Assumptions: ").append(it).append('\n') }
            list(plan.optJSONArray("needs_server"))?.let { sb.append("Needs server setup (not built here): ").append(it).append('\n') }
        }
        sb.append("\nStages:\n")
        for (s in STAGES) sb.append(if (done(st, s)) "  [x] " else "  [ ] ").append(STAGE_LABEL[s]).append('\n')
        return sb.toString() + "\nPROJECT_EDITED: '" + Coder.name(dir) + "'"
    }

    // ------------------------------------------------------------------ stage runner

    private fun runStages(ctx: Context, confirm: (String) -> Boolean, dir: File, st: JSONObject, key: String): String {
        val log = StringBuilder()
        for (s in STAGES) {
            if (s == "plan" || s == "build") continue
            if (done(st, s)) continue
            say("Step " + (STAGES.indexOf(s) + 1) + "/" + STAGES.size + " · " + (STAGE_LABEL[s] ?: s) + "...")
            val note = try {
                runStage(ctx, confirm, dir, st, s)
            } catch (e: Exception) {
                save(ctx, key, st)
                log.append("✖ ").append(STAGE_LABEL[s]).append(" stopped: ").append(e.message ?: e.javaClass.simpleName)
                    .append(". Say 'continue' to resume from here.\n")
                return log.toString()
            }
            val passed = stagePassed(s, note)
            mark(st, s, passed, note)
            save(ctx, key, st)
            log.append(if (passed) "✔ " else "⚠ ").append(STAGE_LABEL[s]).append(": ")
                .append(note.lineSequence().firstOrNull() ?: "").append('\n')
            if (!passed) {
                log.append("  The stage is incomplete; the remaining stages were not run. Fix the issues and run action=continue.\n")
                return log.toString()
            }
        }
        return log.toString()
    }

    /** A stage is complete only when its output proves the required check passed. */
    internal fun stagePassed(stage: String, note: String): Boolean {
        val n = note.lowercase(java.util.Locale.ROOT)
        if (n.isBlank()) return false
        // The visual check only reports what a vision model saw (its text can contain words like "failed"); it never blocks a build.
        if (stage == "visual_check") return true
        if (n.contains("blocked") || n.contains("stopped:") || n.contains("build stopped") || n.contains("failed") || n.contains("nakam")) return false
        return when (stage) {
            "premium_review" -> !n.contains("review blocked") && !n.contains("interaction scan still needs review")
            "run_check" -> n.contains("preview ran:") && !n.contains("issues remain") && !n.contains("timeout") && !n.contains("did not load")
            "audit" -> !Regex("\\b[1-9][0-9]* high\\b|\\b[1-9][0-9]* medium\\b").containsMatchIn(n)
            "verify" -> n.contains("entry page:") && n.contains("final preview check clean") && !n.contains("issues")
            else -> !n.contains("error:") && !n.contains("exception:")
        }
    }

    private fun runStage(ctx: Context, confirm: (String) -> Boolean, dir: File, st: JSONObject, stage: String): String = when (stage) {
        "visual_check" -> VisualCheck.run(ctx, dir, st.optJSONObject("plan")) { m -> say(m) }
        "images" -> SiteImages.process(ctx, dir, st.optJSONObject("plan")) { m -> say(m) }
        "premium_review" -> premiumReview(ctx, dir, st)
        "run_check" -> runCheck(ctx, dir)
        "audit" -> auditAndFix(ctx, dir)
        "seo" -> seo(dir, st)
        "deploy_docs" -> deployDocs(dir, st)
        "verify" -> verify(ctx, confirm, dir)
        else -> ""
    }

    // ------------------------------------------------------------------ plan

    private fun makePlan(ctx: Context, request: String, domain: String, hint: String = ""): JSONObject {
        val sys = "You are a principal web architect and UX lead. Output ONLY one JSON object, no markdown, with keys: " +
            "name (short), summary (one sentence), assumptions (array of strings: reasonable assumptions you made), " +
            "pages (array of page names), features (array of concrete working features), roles (array, user roles if any), " +
            "data (array: data the site stores/handles), integrations (array), " +
            "needs_server (array: features that REALLY need a server/database/auth/payment and cannot work in a static site), " +
            "design (object: style, palette as hex list, heading_font, body_font, theme), " +
            "milestones (array of strings), checklist (array of short acceptance checks). " +
            "The site will be built as a static multi-page website (HTML, CSS, vanilla JS) that runs in a WebView; client-side persistence only through localStorage/IndexedDB. " +
            "Do not pretend server features exist. Write in the language of the request for visible content ideas."
        val out = try { Artifacts.askPublic(ctx, sys, "Website request:\n$request" + (if (domain.isNotBlank()) "\nDomain: $domain" else "") + (if (hint.isNotBlank()) "\n\n$hint" else "")) } catch (e: Exception) { "ERR:" + e.message }
        val parsed = try {
            val t = out.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
            JSONObject(t.substring(t.indexOf('{'), t.lastIndexOf('}') + 1))
        } catch (e: Exception) { null }
        if (parsed != null) return parsed
        return JSONObject().put("name", "website").put("summary", request.take(120))
            .put("assumptions", JSONArray().put("The plan could not be made by the AI, so the build used the request directly."))
            .put("pages", JSONArray().put("index")).put("features", JSONArray()).put("needs_server", JSONArray())
    }


    /** One shared quality standard, used by the first build brief and by the premium review pass. */
    internal const val PREMIUM_STANDARD =
        "PREMIUM WEBSITE STANDARD (all 9 must be met):\n" +
        "1. PLAN FIRST: before any code, decide the site goal, target audience, page list, sections per page and brand mood (colours, fonts, tone). Build only after this is clear.\n" +
        "2. DESIGN SYSTEM: one colour palette, at most 2 fonts, one spacing scale and reusable components (navbar, buttons, cards, forms, footer) so every page looks like one brand.\n" +
        "3. REAL CONTENT: write real headings, copy, menu or pricing items, testimonials and clear call-to-action buttons for this exact business. No lorem ipsum, no empty sections.\n" +
        "4. RESPONSIVE: mobile-first; check phone, tablet and desktop; no horizontal scrolling.\n" +
        "5. POLISH: hover effects and optional scroll-reveal (respect reduced motion), dark/light theme where it fits, strong typography, and a visible :focus-visible style on every link, button and input. NEVER hide content by default: base CSS must show everything (no opacity:0 or visibility:hidden in base styles). A reveal effect may hide an element only after a script adds a class to <html>, and a timeout must reveal everything after 1.5 seconds so the page can never stay blank.\n" +
        "6. PERFORMANCE AND SEO: light local images, no heavy libraries, lazy-load images, unique title and meta description per page, correct heading order, alt text.\n" +
        "7. ACCESSIBILITY: good contrast, full keyboard use, labels and aria-labels, semantic landmarks, skip link.\n" +
        "8. SELF-CHECK: after building, audit links, buttons, forms, layout at mobile width and focus styles, then fix small problems before delivering.\n" +
        "9. DELIVERY: hand over a project card, a working preview and a ZIP download in the chat, and say honestly what was checked and what was not.\n\n"

    private fun brief(request: String, plan: JSONObject, bp: SiteBlueprints.Blueprint? = SiteBlueprints.match(request)): String =
        "WEBSITE BUILDER BRIEF\n\nUser request:\n" + request + "\n\nApproved plan (follow it):\n" + plan.toString(2) + "\n\n" + (bp?.prompt()?.plus("\n") ?: "") +
        "Technical rules: a static website made of HTML, CSS and vanilla JavaScript that works offline inside an Android WebView. " +
        "No npm, no build step, no CDN-only dependencies. Multi-page if the plan lists several pages, with working navigation between them. " +
        "Persist user data only with localStorage/IndexedDB and make that really work. Do NOT fake server features (login against a fake user list, fake payments, fake API data shown as real): " +
        "implement the client-side part honestly and leave server-only items out of the UI. Never put API keys, tokens or passwords in the code.\n\n" +
        PREMIUM_STANDARD +
        "PREMIUM DESIGN SYSTEM: First create a distinct art direction that fits this exact business. Define reusable CSS tokens for brand colours, neutrals, typography, spacing, grid, radii, borders, elevation, focus rings and motion. " +
        "Use a deliberate type scale and excellent line lengths; align every section to a consistent grid; use strong visual hierarchy, generous but purposeful whitespace, high-quality relevant imagery, polished iconography, nuanced surfaces and subtle micro-interactions. " +
        "Avoid generic AI-template styling, repetitive card grids, excessive gradients, arbitrary rounded boxes, emoji icons, lorem ipsum, empty sections and oversized headings without purpose. Each page must feel intentionally designed, not copied from the homepage.\n\n" +
        "IMAGES: use only local image files under images/ (for example images/hero.jpg, images/team-1.jpg) and never http(s) image links, because the site runs offline. Give every image meaningful alt text, width and height, and loading=\"lazy\" except the first screen. Do not worry about creating the image files: the builder makes every missing image automatically (an AI picture or a designed SVG), so reference exactly the images the design needs.\n\n" +
        "PAGE COMPLETENESS: Create every page required by the plan, with unique content hierarchy and appropriate page-specific sections. Add consistent navigation, footer, breadcrumbs where useful, active navigation state, custom 404, and working internal links. Never create links to pages that do not exist. For multi-page sites, build the complete user journey across all pages.\n\n" +
        "FUNCTIONALITY CONTRACT: Before finishing, inventory every visible button, anchor, icon button, form, menu, tab, filter, toggle and interactive control. Each must have a real, appropriate result. No href=\"#\" placeholders, empty handlers, dead controls, fake success states, fake login/payment/API data, or controls that only look interactive. Validate forms, persist supported local data, and provide loading, empty, success and error states. If a feature requires a server that is unavailable, do not present it as working; explain the requirement and avoid misleading controls.\n\n" +
        "RESPONSIVE AND ACCESSIBLE: Mobile-first layout that is separately considered for small phones, large phones, tablets, laptops, desktops and wide screens; no horizontal overflow. Use semantic landmarks, one meaningful h1 per page, associated labels, descriptive alt text, visible focus, keyboard operation, sufficient contrast, skip link, reduced-motion support, and suitable touch targets. Add html lang, viewport, unique title, meta description and Open Graph metadata on each page.\n\n" +
        "TECHNICAL QUALITY: Use local assets where possible; do not depend on a CDN-only library or network access for core functionality. Use safe DOM APIs and never inject untrusted user input through innerHTML. Never hardcode secrets. Keep CSS, JS and HTML organized and consistent. Test real page navigation, forms, buttons, mobile menu, theme toggle and persistence. Every deliverable must be coherent and runnable in the built-in Android WebView."

    // ------------------------------------------------------------------ premium visual + interaction review

    /** A dedicated second pass targets the specific failure mode of generic-looking, partially wired websites. */
    private fun premiumReview(ctx: Context, dir: File, st: JSONObject): String {
        val before = Coder.readFiles(dir)
        val pages = PreviewServer.pages(dir)
        if (pages.isEmpty()) return "Premium review blocked: no HTML page found."
        val staticFindings = interactionFindings(before)
        // Speed: the full AI review is a slow extra pass. The first build already follows the premium standard,
        // so the pass only runs when the quick scan found real problems.
        if (staticFindings.isEmpty()) return "Premium review completed: quick scan found no dead links or missing basics across ${pages.size} HTML page(s), slow AI pass skipped for speed.\nInteraction scan: no simple placeholder/dead-link patterns detected."
        val plan = st.optJSONObject("plan")?.toString(2) ?: "No saved plan"
        val inventory = before.entries.joinToString("\n") { (path, content) ->
            val summary = when {
                path.endsWith(".html", true) -> "HTML page, ${Regex("(?i)<(button|a\\b|input|select|textarea)\\b").findAll(content).count()} interactive element(s)"
                path.endsWith(".css", true) -> "Stylesheet, ${content.length} chars"
                path.endsWith(".js", true) -> "JavaScript, ${content.length} chars"
                else -> "${content.length} chars"
            }
            "$path — $summary"
        }.take(12000)
        val instruction = """PREMIUM WEBSITE REVIEW — EDIT THE ACTUAL PROJECT FILES.

Saved project brief:
$plan

Current pages: ${pages.joinToString(", ")}
File inventory:
$inventory

Deterministic interaction findings:
${if (staticFindings.isEmpty()) "No simple placeholder/dead-link pattern detected." else staticFindings.joinToString("\n")}

Perform a senior design-team review of the current website, not a generic code review. Inspect all relevant source files and improve the existing implementation while preserving the intended features and content.

PRIORITIES:
1. Make the visual design feel genuinely premium, distinctive and business-specific: improve composition, hierarchy, typography, spacing, colour balance, imagery, navigation, section rhythm, page-specific layouts, responsive behavior, component consistency and micro-interactions.
2. Review every HTML page, not only index.html. Ensure each page has a complete, purposeful layout and the same coherent design system without cloning the same sections across every page.
3. Inspect every button, link, menu item, form, toggle, tab, filter and interactive control. Remove placeholder href="#" behavior, wire valid local navigation, implement meaningful client-side interactions and validation, and show honest outcomes. Never fake server-only functionality.
4. Fix any listed deterministic findings that are valid. Do not remove intended features to make a check pass.
5. Keep the site compatible with Android WebView and offline use. Do not add npm/build requirements, external runtime libraries, or CDN-only dependencies. Preserve safe handling of user input.
6. Respect prefers-reduced-motion, keyboard focus, labels, accessible contrast, image alt text, and small-screen layouts.
7. Keep code maintainable. Make targeted improvements; do not rewrite the entire project unnecessarily or destroy working features.

Return complete file edits using the required project file format. Do not merely describe recommendations. If a backend integration cannot exist in this static project, do not fake it.
""".trimIndent()
        val result = Coder.revise(ctx, dir, instruction, Coder.deepDefault(ctx), {}, { n -> say(n) })
        val after = Coder.readFiles(dir)
        val findingsAfter = interactionFindings(after)
        val changed = before.keys.union(after.keys).count { before[it] != after[it] }
        val reviewerFailed = result.isBlank() || result.contains("Add an API key in Settings", true) ||
            result.contains("No answer received", true) || result.contains("Could not create the code", true) ||
            result.contains("write the request a bit more clearly", true)
        return (if (reviewerFailed) "Premium review blocked: the AI review gave no valid result." else "Premium review completed: $changed file(s) changed across ${pages.size} HTML page(s).") + "\n" +
            (if (findingsAfter.isEmpty()) "Interaction scan: no simple placeholder/dead-link patterns detected." else "Interaction scan still needs review:\n" + findingsAfter.take(12).joinToString("\n")) +
            "\nReview notes: " + result.take(500).ifBlank { "No valid reviewer output." }
    }

    /** Fast, deterministic checks for common visible dead controls. These are heuristics, not proof of functionality. */
    internal fun interactionFindings(files: Map<String, String>): List<String> {
        val out = ArrayList<String>()
        val htmlFiles = files.filterKeys { it.endsWith(".html", true) || it.endsWith(".htm", true) }
        val knownPages = htmlFiles.keys.map { it.replace('\\', '/') }.toSet()
        for ((path, html) in htmlFiles) {
            val deadAnchors = Regex("(?is)<a\\b[^>]*href\\s*=\\s*['\"]#['\"][^>]*>").findAll(html).count()
            if (deadAnchors > 0) out.add("$path: $deadAnchors anchor(s) use href='#' with no destination")
            val blankButtons = Regex("(?is)<button\\b[^>]*>\\s*(?:Button|Click here|Submit|Learn more)\\s*</button>").findAll(html).count()
            if (blankButtons > 0) out.add("$path: $blankButtons generic button(s) may be unwired")
            val localLinks = Regex("(?is)<a\\b[^>]*href\\s*=\\s*['\"]([^'\"]+\\.html(?:#[^'\"]*)?)['\"][^>]*>").findAll(html)
            for (m in localLinks) {
                val dest = m.groupValues[1].substringBefore('#').trimStart('/')
                if (dest.isNotBlank() && !dest.startsWith("http", true) && dest !in knownPages && dest !in knownPages.map { it.substringAfterLast('/') })
                    out.add("$path: internal link target '$dest' not found")
            }
            if (!html.contains("<title", true)) out.add("$path: page title missing")
            if (!html.contains("name=\"viewport\"", true) && !html.contains("name='viewport'", true)) out.add("$path: viewport meta missing")
        }
        return out.distinct().take(40)
    }

    // ------------------------------------------------------------------ run in preview

    private fun runCheck(ctx: Context, dir: File): String {
        var report = Runner.check(ctx, dir).trim()
        var rounds = 0
        while (report.isNotEmpty() && rounds < 2) {
            rounds++
            Coder.revise(ctx, dir, "Fix these verified preview/runtime problems in the actual files, change nothing else:\n$report", Coder.deepDefault(ctx), {}, { n -> say(n) })
            report = Runner.check(ctx, dir).trim()
        }
        return if (report.isEmpty()) "Preview ran: no console error or missing file found" + (if (rounds > 0) " (after $rounds fix round(s))." else ".")
        else "These issues remain even after fixing:\n$report"
    }

    // ------------------------------------------------------------------ audit (deterministic static checks, then one AI fix round)

    data class Finding(val sev: String, val file: String, val msg: String)

    private val SECRET = listOf(
        Regex("AIza[0-9A-Za-z_\\-]{35}"),
        Regex("sk-[A-Za-z0-9]{20,}"),
        Regex("(?i)(api[_-]?key|secret|token|passw(or)?d)\\s*[:=]\\s*['\"][^'\"\\s]{8,}['\"]")
    )

    fun audit(dir: File): List<Finding> {
        val out = ArrayList<Finding>()
        val files = Coder.readFiles(dir)
        var anyMedia = false
        var anyFocus = false
        var anyDark = false
        var anyAnim = false
        var anyReduced = false
        for ((path, text) in files) {
            val ext = path.substringAfterLast('.', "").lowercase()
            val isHtml = ext == "html" || ext == "htm"
            if (ext == "css" || isHtml) {
                if (text.contains("@media")) anyMedia = true
                if (text.contains("focus-visible") || text.contains(":focus")) anyFocus = true
                if (text.contains("prefers-color-scheme")) anyDark = true
                if (text.contains("@keyframes") || text.contains("transition")) anyAnim = true
                if (text.contains("prefers-reduced-motion")) anyReduced = true
            }
            if (isHtml) {
                if (!Regex("(?i)<meta[^>]+name=[\"']viewport").containsMatchIn(text)) out.add(Finding("medium", path, "viewport meta missing (not mobile friendly)"))
                if (!Regex("(?i)<title>[^<]+</title>").containsMatchIn(text)) out.add(Finding("medium", path, "<title> missing"))
                if (!Regex("(?i)<meta[^>]+name=[\"']description").containsMatchIn(text)) out.add(Finding("low", path, "meta description missing"))
                if (!Regex("(?i)<html[^>]+lang=").containsMatchIn(text)) out.add(Finding("low", path, "<html lang> missing"))
                val h1 = Regex("(?i)<h1[\\s>]").findAll(text).count()
                if (h1 == 0) out.add(Finding("low", path, "no <h1>")) else if (h1 > 1) out.add(Finding("low", path, "more than one <h1>"))
                val noAlt = Regex("(?i)<img\\b(?![^>]*\\balt=)[^>]*>").findAll(text).count()
                if (noAlt > 0) out.add(Finding("medium", path, "$noAlt <img> without alt text"))
                val inputs = Regex("(?i)<(input|select|textarea)\\b(?![^>]*type=[\"'](hidden|submit|button|reset|image)[\"'])[^>]*>").findAll(text).count()
                val labelled = Regex("(?i)<label\\b|aria-label=|aria-labelledby=").findAll(text).count()
                if (inputs > labelled) out.add(Finding("medium", path, "some form fields have no label/aria-label"))
                if (Regex("(?i)<a\\b[^>]*target=[\"']_blank[\"'](?![^>]*rel=[\"'][^\"']*noopener)[^>]*>").containsMatchIn(text))
                    out.add(Finding("low", path, "target=_blank link without rel=noopener"))
                if (Regex("(?i)<script[^>]+src=[\"']http://").containsMatchIn(text)) out.add(Finding("high", path, "script loaded over insecure http://"))
                if (Regex("(?i)<script[^>]+src=[\"']https?://[^\"']*(cdn\\.|cdnjs|unpkg|jsdelivr)").containsMatchIn(text))
                    out.add(Finding("medium", path, "runtime script depends on a CDN (core functionality may fail offline)"))
                if (Regex("(?i)(src|href)=[\"']http://[^\"']+\\.(css|js|png|jpe?g|webp|svg)").containsMatchIn(text)) out.add(Finding("medium", path, "insecure http:// resource (mixed content)"))
            }
            if (isHtml || ext == "js" || ext == "mjs" || ext == "ts" || ext == "jsx" || ext == "tsx") {
                if (Regex("\\beval\\s*\\(|new\\s+Function\\s*\\(").containsMatchIn(text)) out.add(Finding("high", path, "eval()/new Function() used"))
                if (Regex("document\\.write\\s*\\(").containsMatchIn(text)) out.add(Finding("medium", path, "document.write() used"))
                if (Regex("innerHTML\\s*(\\+?=)\\s*[^'\"`;\\s]").containsMatchIn(text)) out.add(Finding("medium", path, "innerHTML assigned from a variable (XSS risk): use textContent or sanitise"))
                if (Regex("(?i)localStorage\\.setItem\\([^)]*(passw|token|secret)").containsMatchIn(text)) out.add(Finding("medium", path, "sensitive value stored in localStorage"))
            }
            if (ext in setOf("html", "htm", "js", "mjs", "ts", "jsx", "tsx", "json", "env", "css")) {
                for (r in SECRET) if (r.containsMatchIn(text)) { out.add(Finding("high", path, "possible secret/API key in source")); break }
            }
        }
        if (files.keys.any { it.endsWith(".html", true) || it.endsWith(".htm", true) }) {
            if (!anyMedia) out.add(Finding("medium", "(css)", "no @media queries: layout is probably not responsive"))
            if (!anyFocus) out.add(Finding("low", "(css)", "no visible focus style (keyboard navigation)"))
            if (!anyDark) out.add(Finding("low", "(css)", "no dark theme (prefers-color-scheme)"))
            if (anyAnim && !anyReduced) out.add(Finding("low", "(css)", "animations without prefers-reduced-motion"))
        }
        return out
    }

    private fun fmt(f: List<Finding>): String = f.joinToString("\n") { "- [" + it.sev + "] " + it.file + ": " + it.msg }

    private fun auditAndFix(ctx: Context, dir: File): String {
        var found = audit(dir)
        val serious = found.filter { it.sev == "high" || it.sev == "medium" }
        if (serious.isNotEmpty()) {
            Coder.revise(ctx, dir, "Fix these verified audit findings in the actual files (keep the design and features unchanged):\n" + fmt(found), Coder.deepDefault(ctx), {}, { n -> say(n) })
            found = audit(dir)
        }
        val high = found.count { it.sev == "high" }
        val med = found.count { it.sev == "medium" }
        val low = found.count { it.sev == "low" }
        val head = if (found.isEmpty()) "Audit clean: no findings (static checks)." else "Audit after: $high high, $med medium, $low low."
        return head + (if (found.isNotEmpty()) "\n" + fmt(found) else "") +
            "\n(These are static code checks: injection/XSS patterns, secrets, labels, alt, responsive, focus. Dependency scan, CSRF/auth and a real penetration test cannot be done on this device.)"
    }

    // ------------------------------------------------------------------ SEO + deployment files (never overwrite existing user files)

    private fun writeIfAbsent(dir: File, rel: String, content: String): Boolean =
        if (File(dir, rel).exists()) false else Coder.writeFile(dir, rel, content)

    private fun seo(dir: File, st: JSONObject): String {
        val domain = (st.optString("domain", "").ifBlank { "https://example.com" }).trimEnd('/')
        val pages = PreviewServer.pages(dir).filter { !it.startsWith("docs/") }
        val urls = pages.joinToString("\n") { p ->
            val loc = if (p == "index.html") "$domain/" else "$domain/$p"
            "  <url><loc>$loc</loc></url>"
        }
        val made = ArrayList<String>()
        if (writeIfAbsent(dir, "sitemap.xml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">\n$urls\n</urlset>\n")) made.add("sitemap.xml")
        if (writeIfAbsent(dir, "robots.txt", "User-agent: *\nAllow: /\n\nSitemap: $domain/sitemap.xml\n")) made.add("robots.txt")
        val placeholder = if (st.optString("domain", "").isBlank()) " The domain is still example.com: replace it in sitemap.xml and robots.txt once you have the real domain." else ""
        return (if (made.isEmpty()) "SEO files already exist." else "Banayi: " + made.joinToString(", ") + ".") + placeholder
    }

    private fun deployDocs(dir: File, st: JSONObject): String {
        val name = Coder.name(dir)
        val made = ArrayList<String>()
        if (writeIfAbsent(dir, "_headers", "/*\n  X-Content-Type-Options: nosniff\n  Referrer-Policy: strict-origin-when-cross-origin\n  X-Frame-Options: SAMEORIGIN\n  Permissions-Policy: camera=(), microphone=(), geolocation=()\n")) made.add("_headers")
        if (writeIfAbsent(dir, "netlify.toml", "[build]\n  publish = \".\"\n\n[[headers]]\n  for = \"/*\"\n  [headers.values]\n    X-Content-Type-Options = \"nosniff\"\n    Referrer-Policy = \"strict-origin-when-cross-origin\"\n    X-Frame-Options = \"SAMEORIGIN\"\n")) made.add("netlify.toml")
        if (writeIfAbsent(dir, "vercel.json", "{\n  \"cleanUrls\": true,\n  \"headers\": [\n    { \"source\": \"/(.*)\", \"headers\": [\n      { \"key\": \"X-Content-Type-Options\", \"value\": \"nosniff\" },\n      { \"key\": \"Referrer-Policy\", \"value\": \"strict-origin-when-cross-origin\" },\n      { \"key\": \"X-Frame-Options\", \"value\": \"SAMEORIGIN\" }\n    ] }\n  ]\n}\n")) made.add("vercel.json")
        val server = list(st.optJSONObject("plan")?.optJSONArray("needs_server"))
        val doc = "# $name: deployment\n\nThis is a static website (HTML, CSS, JavaScript). No build step is needed.\n\n" +
            "## Host it\n- **Netlify**: drag the project folder (or ZIP) onto app.netlify.com/drop, or connect a Git repository. `netlify.toml` and `_headers` add security headers.\n" +
            "- **Vercel**: import the folder/repository; `vercel.json` is included.\n- **GitHub Pages**: push the files, then Settings > Pages > deploy from branch.\n- **Any web server**: upload all files to the web root.\n\n" +
            "## Before going live\n- Replace `https://example.com` in `sitemap.xml` and `robots.txt` with your real domain.\n- Re-test every form and link on the live URL.\n- Add a privacy notice if you collect personal data.\n\n" +
            "## Not included (needs a server)\n" + (if (server != null) "- " + server.replace(", ", "\n- ") else "- Nothing was flagged in the plan.") +
            "\n\nAnjoo AI does not deploy sites by itself and has not deployed this one.\n"
        if (writeIfAbsent(dir, "DEPLOY.md", doc)) made.add("DEPLOY.md")
        if (writeIfAbsent(dir, "README.md", "# $name\n\nStatic website generated with Anjoo AI Website Builder.\n\nOpen `index.html` in a browser, or see `DEPLOY.md` to publish it.\n")) made.add("README.md")
        return if (made.isEmpty()) "Deployment files already exist." else "Banayi: " + made.joinToString(", ") + ". (Not deployed: the steps are in DEPLOY.md.)"
    }

    // ------------------------------------------------------------------ verify + report

    private fun verify(ctx: Context, confirm: (String) -> Boolean, dir: File): String {
        val files = Coder.readFiles(dir)
        val entry = PreviewServer.entry(dir)
        val report = Runner.check(ctx, dir).trim()
        val cp = CodeTools.run(ctx, confirm, "project_studio", JSONObject().put("action", "checkpoint").put("project", Coder.name(dir)).put("message", "Website Builder: verified build")) ?: ""
        return (if (entry == null) "No HTML entry page found." else "Entry page: $entry, ${files.size} files.") + "\n" +
            (if (report.isEmpty()) "Final preview check clean." else "Final preview check issues:\n$report") + "\n" + cp
    }

    @Suppress("UNUSED_PARAMETER")
    private fun finish(ctx: Context, dir: File, st: JSONObject, log: String, saveZip: Boolean): String {
        val sb = StringBuilder()
        lastDirName = dir.name
        val incomplete = STAGES.filter { !done(st, it) }
        if (incomplete.isEmpty()) {
            sb.append("PROJECT_BUILT: '").append(Coder.name(dir)).append("' passed all configured stages. The project card (Preview, files, ZIP download) is attached below this reply automatically. Do not write 'will be shown' in the reply; just say in one short line that the website is ready and ask what to change.\n\n")
        } else {
            sb.append("PROJECT_IN_PROGRESS: '").append(Coder.name(dir)).append("' was created, but not all quality stages passed. Pending/blocked: ")
                .append(incomplete.joinToString { STAGE_LABEL[it] ?: it }).append(".\n\n")
        }
        say("Ready · the project card is coming below the reply")
        sb.append("Workflow log:\n").append(log).append('\n')
        // Nothing is saved to the phone automatically: the person downloads it from the project card when they want it.
        sb.append("\nWHERE THE FILES ARE:\n- The project is inside Anjoo AI (it does not show in the phone's Files app). Open the chat's project card: the preview, files and ZIP are there.\n")
        sb.append("- To save to the phone, tap the card's ⬇ Download or the ZIP card; only then is it saved in Download/Anjoo, nothing is saved automatically.\n")
        val notes = st.optJSONObject("notes")
        notes?.optString("audit", "")?.takeIf { it.isNotBlank() }?.let { sb.append("\n").append(it).append('\n') }
        val plan = st.optJSONObject("plan")
        list(plan?.optJSONArray("assumptions"))?.let { sb.append("\nAssumptions: ").append(it).append('\n') }
        list(plan?.optJSONArray("needs_server"))?.let { sb.append("\nSERVER SETUP NEEDED (not built here, not faked): ").append(it).append('\n') }
        sb.append("\nNOT VERIFIED on device: npm/React/Next builds, database, real auth, unit/e2e tests, dependency CVE scan, live deployment.\n")
        sb.append("\nINSTRUCTION FOR REPLY: tell the user in short sentences only these verified things (what was built, preview result, audit result, where the files are, what is left) and ask what to change. Do not say anything that is not in this log.")
        return sb.toString()
    }

    private fun list(a: JSONArray?): String? {
        if (a == null || a.length() == 0) return null
        val parts = ArrayList<String>()
        for (i in 0 until a.length()) {
            val v = a.opt(i)
            parts.add(if (v is JSONObject) v.optString("name", v.toString()) else v.toString())
        }
        return parts.joinToString(", ").takeIf { it.isNotBlank() }
    }
}
