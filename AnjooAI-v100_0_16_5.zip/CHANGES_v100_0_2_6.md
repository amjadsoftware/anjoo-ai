# Anjoo AI v100.0.2.6 — Final
- Small tappable text buttons now get a 48dp minimum height.
- Added TextScaleTest unit tests.
- Cleartext HTTP left ON on purpose (custom/local AI servers such as Ollama need it).
