# Anjoo AI v100.0.2.3 — Settings menu
- New first section "Setup": shows current AI/model and warns "API KEY MISSING" with one tap to fix.
- "Look" renamed "Display": Text size and Anjoo language now directly in Settings.
- Settings (side menu) already sits last in the drawer; chat delete already asks for confirmation.
