# Anjoo AI v100.0.15.3
- Chat menu (3 dots) in simple mode: only Share, Rename, Delete and Settings. Add to project, Export, Pin and Starred answers move to Settings > Advanced (next step).
