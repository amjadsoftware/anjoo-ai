package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Saves everything Anjoo knows (settings, memory, diary, chats) to one file, and loads it back. */
object Backup {

    fun build(ctx: Context, withKey: Boolean): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val prefs = JSONObject()
        for ((k, v) in p.all) {
            if (k == "key" && !withKey) continue
            if (k == "batteryAsked" || k == "accAsked") continue
            val o = JSONObject()
            when (v) {
                is String -> o.put("t", "s").put("v", v)
                is Boolean -> o.put("t", "b").put("v", v)
                is Int -> o.put("t", "i").put("v", v)
                is Long -> o.put("t", "l").put("v", v)
                is Float -> o.put("t", "f").put("v", v.toDouble())
                else -> continue
            }
            prefs.put(k, o)
        }
        return JSONObject().put("app", "AnjooAI").put("version", 1).put("at", System.currentTimeMillis())
            .put("prefs", prefs).put("chats", ChatStore.all(ctx)).toString()
    }

    fun restore(ctx: Context, text: String): String {
        val root = try { JSONObject(text) } catch (e: Exception) { return "Ye Anjoo ki backup file nahi lagti." }
        if (root.optString("app") != "AnjooAI") return "Ye Anjoo ki backup file nahi lagti."
        val prefs = root.optJSONObject("prefs") ?: JSONObject()
        val ed = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit()
        val keys = prefs.keys()
        var n = 0
        while (keys.hasNext()) {
            val k = keys.next()
            val o = prefs.getJSONObject(k)
            when (o.getString("t")) {
                "s" -> ed.putString(k, o.getString("v"))
                "b" -> ed.putBoolean(k, o.getBoolean("v"))
                "i" -> ed.putInt(k, o.getInt("v"))
                "l" -> ed.putLong(k, o.getLong("v"))
                "f" -> ed.putFloat(k, o.getDouble("v").toFloat())
            }
            n++
        }
        ed.apply()
        val chats = root.optJSONArray("chats") ?: JSONArray()
        ChatStore.replaceAll(ctx, chats)
        Reminders.restoreAll(ctx)
        return "Backup wapas aa gayi: $n settings/yaadein aur ${chats.length()} chats."
    }
}
