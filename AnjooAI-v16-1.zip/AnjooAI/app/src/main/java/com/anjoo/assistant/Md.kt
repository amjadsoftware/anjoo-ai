package com.anjoo.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.view.Gravity
import android.view.View
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.regex.Pattern

/**
 * Claude-style message renderer: headings, bold, inline code, lists, quotes and fenced code cards.
 * Each code card has a language label, syntax colours, and Copy / Save / Share / Preview buttons.
 */
object Md {

    private class Code(val lang: String, val name: String, val text: String)

    private val KW = ("abstract|as|async|await|break|case|catch|class|const|continue|def|default|del|do|else|elif|enum|except|export|extends|" +
        "false|final|finally|for|fun|func|function|from|if|implements|import|in|interface|is|lambda|let|new|null|nil|None|object|override|" +
        "package|pass|private|protected|public|raise|return|self|static|struct|super|switch|this|throw|throws|true|True|False|try|typeof|" +
        "val|var|void|when|while|with|yield|using|namespace|template|typename|int|float|double|string|bool|boolean|char|long|SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|TABLE|JOIN|ORDER|GROUP|BY|AND|OR|NOT|INTO|VALUES")

    private fun pattern(lang: String): Pattern {
        val hash = lang.lowercase() in listOf("python", "py", "bash", "sh", "shell", "yaml", "yml", "ruby", "rb", "toml", "dockerfile")
        val comment = (if (hash) "#[^\\n]*|" else "") + "//[^\\n]*|/\\*[\\s\\S]*?\\*/|<!--[\\s\\S]*?-->|--[ ][^\\n]*"
        return Pattern.compile("($comment)|(\"\"\"[\\s\\S]*?\"\"\"|\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'|`(?:\\\\.|[^`\\\\])*`)|\\b(\\d+(?:\\.\\d+)?)\\b|\\b($KW)\\b")
    }

    fun highlight(code: String, lang: String, light: Boolean): CharSequence {
        val sb = SpannableStringBuilder(code)
        if (code.length > 12000) return sb
        val cK = if (light) 0xFFA626A4.toInt() else 0xFFC792EA.toInt()
        val cS = if (light) 0xFF2E7D32.toInt() else 0xFFA5D6A7.toInt()
        val cC = if (light) 0xFF8A8980.toInt() else 0xFF7F7E78.toInt()
        val cN = if (light) 0xFFB76B01.toInt() else 0xFFF2B66D.toInt()
        val m = pattern(lang).matcher(code)
        while (m.find()) {
            val c = when {
                m.group(1) != null -> cC
                m.group(2) != null -> cS
                m.group(3) != null -> cN
                else -> cK
            }
            sb.setSpan(ForegroundColorSpan(c), m.start(), m.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun inline(t: String, th: CyberTheme, codeBg: Int): CharSequence {
        val sb = SpannableStringBuilder()
        val p = Pattern.compile("\\*\\*(.+?)\\*\\*|`([^`\\n]+)`|\\*(?!\\s)([^*\\n]+?)\\*")
        val m = p.matcher(t)
        var last = 0
        while (m.find()) {
            sb.append(t, last, m.start())
            val s = sb.length
            when {
                m.group(1) != null -> { sb.append(m.group(1)); sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, 0) }
                m.group(2) != null -> {
                    sb.append(m.group(2))
                    sb.setSpan(TypefaceSpan("monospace"), s, sb.length, 0)
                    sb.setSpan(BackgroundColorSpan(codeBg), s, sb.length, 0)
                    sb.setSpan(RelativeSizeSpan(0.92f), s, sb.length, 0)
                }
                else -> { sb.append(m.group(3)); sb.setSpan(StyleSpan(Typeface.ITALIC), s, sb.length, 0) }
            }
            last = m.end()
        }
        sb.append(t, last, t.length)
        return sb
    }

    private fun isLight(th: CyberTheme): Boolean {
        val c = th.bg
        return (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000 > 140
    }

    /** Builds the views for one assistant message. */
    fun render(ctx: Context, text: String, th: CyberTheme, onLong: (String) -> Unit = {}): LinearLayout {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val light = isLight(th)
        val codeBg = if (light) 0xFFF0EEE6.toInt() else 0xFF1F1E1D.toInt()
        val blocks = ArrayList<Code>()
        val para = StringBuilder()

        fun flushPara() {
            if (para.isBlank()) { para.setLength(0); return }
            val tv = TextView(ctx).apply {
                this.text = inline(para.toString().trim(), th, codeBg)
                setTextColor(th.ink); textSize = 16f; setLineSpacing(0f, 1.25f)
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                setTextIsSelectable(true)
                setOnLongClickListener { onLong(text); true }
            }
            col.addView(tv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 6) })
            para.setLength(0)
        }

        val lines = text.split("\n")
        var i = 0
        while (i < lines.size) {
            val ln = lines[i]
            val t = ln.trim()
            if (t.startsWith("```")) {
                flushPara()
                val info = t.removePrefix("```").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                val lang = info.firstOrNull { !it.contains('.') && !it.contains('=') && !it.contains('/') } ?: ""
                var name = info.firstOrNull { it.contains('.') && !it.startsWith("title=") }
                    ?: info.firstOrNull { it.startsWith("title=") }?.removePrefix("title=")?.trim('"') ?: ""
                val body = StringBuilder()
                i++
                while (i < lines.size && !lines[i].trim().startsWith("```")) { body.append(lines[i]).append('\n'); i++ }
                var code = body.toString().trimEnd('\n')
                // "// file: name.ext" as the first line also names the file
                val first = code.lineSequence().firstOrNull()?.trim() ?: ""
                Regex("^(?://|#|<!--)\\s*(?:file|filename):\\s*(\\S+?)\\s*(?:-->)?$", RegexOption.IGNORE_CASE).find(first)?.let {
                    if (name.isEmpty()) name = it.groupValues[1]
                }
                val c = Code(lang, name, code)
                blocks.add(c)
                col.addView(codeCard(ctx, c, th, light, codeBg), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 8) })
                i++
                continue
            }
            val head = Regex("^(#{1,3})\\s+(.*)").find(t)
            val bullet = Regex("^([-*•]|\\d+[.)])\\s+(.*)").find(t)
            when {
                head != null -> {
                    flushPara()
                    val lvl = head.groupValues[1].length
                    col.addView(TextView(ctx).apply {
                        this.text = inline(head.groupValues[2], th, codeBg); setTextColor(th.ink)
                        textSize = if (lvl == 1) 22f else if (lvl == 2) 19f else 17f
                        typeface = Typeface.create("serif", Typeface.BOLD); setTextIsSelectable(true)
                    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 12) })
                }
                bullet != null -> {
                    flushPara()
                    val mark = bullet.groupValues[1].let { if (it[0].isDigit()) it else "•" }
                    col.addView(TextView(ctx).apply {
                        this.text = SpannableStringBuilder("$mark  ").append(inline(bullet.groupValues[2], th, codeBg))
                        setTextColor(th.ink); textSize = 16f; setLineSpacing(0f, 1.2f); setTextIsSelectable(true)
                        setPadding(dp(ctx, 6), 0, 0, 0)
                    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 3) })
                }
                t.startsWith(">") -> {
                    flushPara()
                    col.addView(TextView(ctx).apply {
                        this.text = inline(t.removePrefix(">").trim(), th, codeBg); setTextColor(th.muted); textSize = 15f
                        setPadding(dp(ctx, 12), dp(ctx, 2), 0, dp(ctx, 2)); setTextIsSelectable(true)
                        background = GradientDrawable().apply { setColor(Color.TRANSPARENT) }
                    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 4); leftMargin = dp(ctx, 2) })
                }
                t == "---" || t == "***" -> {
                    flushPara()
                    col.addView(View(ctx).apply { setBackgroundColor(th.muted and 0x55FFFFFF) },
                        LinearLayout.LayoutParams(-1, dp(ctx, 1)).apply { topMargin = dp(ctx, 10); bottomMargin = dp(ctx, 4) })
                }
                t.isEmpty() -> flushPara()
                else -> { if (para.isNotEmpty()) para.append('\n'); para.append(ln) }
            }
            i++
        }
        flushPara()

        // Several named files in one answer: one tap to download them all as a zip.
        val named = blocks.filter { it.name.isNotEmpty() }
        if (named.size >= 2) {
            col.addView(action(ctx, th, "⬇  Download all files (.zip)", true) {
                Files.saveZip(ctx, "anjoo-project.zip", named.map { it.name to it.text })
            }, LinearLayout.LayoutParams(-2, dp(ctx, 38)).apply { topMargin = dp(ctx, 10) })
        }
        return col
    }

    private fun action(ctx: Context, th: CyberTheme, label: String, filled: Boolean = false, onClick: () -> Unit) = TextView(ctx).apply {
        text = label; textSize = 12.5f; gravity = Gravity.CENTER
        setTextColor(if (filled) (if (isLight(th)) Color.WHITE else th.bg) else th.muted)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(dp(ctx, 12), dp(ctx, 6), dp(ctx, 12), dp(ctx, 6))
        if (filled) background = GradientDrawable().apply { setColor(th.accent); cornerRadius = dp(ctx, 10).toFloat() }
        setOnClickListener { onClick() }
    }

    private fun codeCard(ctx: Context, c: Code, th: CyberTheme, light: Boolean, codeBg: Int): LinearLayout {
        val card = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(codeBg); cornerRadius = dp(ctx, 12).toFloat()
                setStroke(dp(ctx, 1), if (light) 0xFFE0DDD2.toInt() else 0xFF3A3935.toInt())
            }
        }
        val fileName = c.name.ifEmpty { "snippet." + Files.ext(c.lang) }
        val bar = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(ctx, 12), dp(ctx, 2), dp(ctx, 4), dp(ctx, 2)) }
        bar.addView(TextView(ctx).apply {
            text = if (c.name.isNotEmpty()) c.name else c.lang.ifEmpty { "code" }
            setTextColor(th.muted); textSize = 12f; typeface = Typeface.MONOSPACE
        }, LinearLayout.LayoutParams(0, -2, 1f))
        if (Files.isPreviewable(c.lang, c.text)) bar.addView(action(ctx, th, "▶ Preview") { Files.preview(ctx, fileName, c.lang.ifEmpty { "html" }, c.text) })
        bar.addView(action(ctx, th, "Copy") { Files.copy(ctx, c.text) })
        bar.addView(action(ctx, th, "Save") { Files.save(ctx, fileName, c.text) })
        bar.addView(action(ctx, th, "Share") { Files.share(ctx, fileName, c.text) })
        card.addView(bar)
        val tv = TextView(ctx).apply {
            text = highlight(c.text, c.lang, light)
            typeface = Typeface.MONOSPACE; textSize = 12.5f; setTextColor(if (light) 0xFF2B2A28.toInt() else 0xFFE6E4DC.toInt())
            setTextIsSelectable(true); setHorizontallyScrolling(true)
            setPadding(dp(ctx, 12), dp(ctx, 4), dp(ctx, 12), dp(ctx, 12))
            textDirection = View.TEXT_DIRECTION_LTR
        }
        card.addView(HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(tv) })
        return card
    }
}
