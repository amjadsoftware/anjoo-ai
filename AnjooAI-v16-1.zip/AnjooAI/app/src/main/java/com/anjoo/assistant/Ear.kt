package com.anjoo.assistant

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import java.io.ByteArrayOutputStream
import java.util.ArrayDeque
import kotlin.math.max
import kotlin.math.sqrt

/**
 * An always-open microphone. It never restarts: it listens all the time, cuts the sound into sentences
 * by silence, and hands each sentence over as raw 16 kHz mono PCM.
 */
class Ear(private val onUtterance: (ByteArray) -> Unit, private val onFail: (String) -> Unit) {

    companion object {
        const val RATE = 16000

        fun wav(pcm: ByteArray): ByteArray {
            val out = ByteArrayOutputStream()
            fun i32(v: Int) { out.write(v and 255); out.write((v shr 8) and 255); out.write((v shr 16) and 255); out.write((v shr 24) and 255) }
            fun i16(v: Int) { out.write(v and 255); out.write((v shr 8) and 255) }
            out.write("RIFF".toByteArray()); i32(36 + pcm.size); out.write("WAVE".toByteArray())
            out.write("fmt ".toByteArray()); i32(16); i16(1); i16(1); i32(RATE); i32(RATE * 2); i16(2); i16(16)
            out.write("data".toByteArray()); i32(pcm.size); out.write(pcm)
            return out.toByteArray()
        }
    }

    @Volatile private var run = false
    /** While true (Anjoo is speaking through the loudspeaker) every frame is thrown away so it never hears itself. */
    @Volatile var muted = false
    @Volatile private var flushNow = false
    /** Forget any half-heard sound (called right after Anjoo stops talking). */
    fun flush() { flushNow = true }
    private var thread: Thread? = null

    fun isRunning() = run && thread?.isAlive == true

    fun start() {
        if (isRunning()) return
        run = true
        thread = Thread { loop() }.also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        run = false
        thread?.interrupt()
    }

    private fun open(source: Int): AudioRecord? {
        val min = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (min <= 0) return null
        return try {
            val r = AudioRecord(source, RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min * 2, 6400))
            if (r.state == AudioRecord.STATE_INITIALIZED) r else { r.release(); null }
        } catch (e: Exception) { null }
    }

    private fun loop() {
        val rec = open(MediaRecorder.AudioSource.VOICE_COMMUNICATION) ?: open(MediaRecorder.AudioSource.VOICE_RECOGNITION)
            ?: open(MediaRecorder.AudioSource.MIC)
        if (rec == null) { run = false; onFail("mic khula nahi"); return }
        try {
            try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(rec.audioSessionId)?.enabled = true } catch (e: Exception) {}
            try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.enabled = true } catch (e: Exception) {}
            rec.startRecording()
            val frame = ShortArray(RATE / 50)
            val pre = ArrayDeque<ShortArray>()
            val buf = ByteArrayOutputStream()
            var floor = 300.0
            var inSpeech = false
            var voiced = 0
            var silence = 0
            var frames = 0
            while (run) {
                val n = rec.read(frame, 0, frame.size)
                if (n < 0) { onFail("mic read error $n"); break }
                if (n == 0) continue
                if (flushNow || muted) {
                    flushNow = false
                    inSpeech = false; voiced = 0; silence = 0; frames = 0
                    buf.reset(); pre.clear()
                    continue
                }
                var sum = 0.0
                for (i in 0 until n) sum += frame[i].toDouble() * frame[i]
                val rms = sqrt(sum / n)
                val voice = rms > max(320.0, floor * 2.4)
                if (!inSpeech) {
                    if (!voice) floor = (floor * 0.98 + rms * 0.02).coerceAtMost(1400.0)
                    pre.addLast(frame.copyOf(n))
                    if (pre.size > 25) pre.removeFirst()
                    voiced = if (voice) voiced + 1 else 0
                    if (voiced >= 2) {
                        inSpeech = true; silence = 0; frames = 0
                        buf.reset()
                        for (f in pre) write(buf, f)
                        pre.clear()
                    }
                } else {
                    write(buf, frame.copyOf(n))
                    frames++
                    silence = if (voice) 0 else silence + 1
                    val voicedFrames = frames - silence
                    val needSilence = if (voicedFrames < 75) 70 else 55   // 1.4 s for short bits, 1.1 s otherwise
                    if (silence >= needSilence || frames > 2000) {
                        inSpeech = false; voiced = 0
                        if (voicedFrames >= 14) onUtterance(buf.toByteArray())
                        buf.reset()
                    }
                }
            }
        } catch (e: Exception) {
            if (run) onFail("mic: " + (e.message ?: e.javaClass.simpleName))
        } finally {
            run = false
            try { rec.stop() } catch (e: Exception) {}
            rec.release()
        }
    }

    private fun write(b: ByteArrayOutputStream, f: ShortArray) {
        for (s in f) { b.write(s.toInt() and 255); b.write((s.toInt() shr 8) and 255) }
    }
}
