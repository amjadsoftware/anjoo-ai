package com.anjoo.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Lets Anjoo type text, tap buttons and press back/home in any app. The user must switch it on once. */
class AnjooAccess : AccessibilityService() {

    companion object {
        @Volatile var inst: AnjooAccess? = null
        const val OFF = "Accessibility band hai. Anjoo app mein ACCESS dabayein aur Anjoo AI ko on karein."

        /** Retries for a few seconds, because a freshly opened app needs a moment to appear. */
        fun <T> retry(tries: Int = 8, gap: Long = 500, block: () -> T?): T? {
            repeat(tries) {
                val r = block()
                if (r != null) return r
                try { Thread.sleep(gap) } catch (e: InterruptedException) { return null }
            }
            return null
        }
    }

    private var cursor: CursorView? = null
    private val mainH = Handler(Looper.getMainLooper())

    private fun ensureCursor() {
        if (cursor != null) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
            val accent = Style.themes[prefs.getInt("theme", 1).coerceIn(0, Style.themes.size - 1)].accent
            val v = CursorView(this, accent)
            val lp = WindowManager.LayoutParams(
                -1, -1,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            cursor = v
        } catch (e: Exception) {}
    }

    /** Shows the mouse arrow at a screen position with a short caption (works over any app). */
    fun pointer(x: Int, y: Int, label: String, click: Boolean = false) {
        mainH.post { ensureCursor(); cursor?.moveTo(x.toFloat(), y.toFloat(), label, click) }
    }

    /** For tasks with no exact spot (opening an app, a call...): the arrow glides to mid-screen with a caption. */
    fun hint(label: String) {
        val m = resources.displayMetrics
        pointer(m.widthPixels / 2, (m.heightPixels * 0.55f).toInt(), label)
    }

    private fun pointAt(n: AccessibilityNodeInfo?, label: String, click: Boolean) {
        if (n == null) return
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return
        pointer(r.centerX(), r.centerY(), label, click)
        try { Thread.sleep(if (click) 650 else 500) } catch (e: InterruptedException) {}
    }

    private fun removeCursor() {
        val v = cursor ?: return
        cursor = null
        try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } catch (e: Exception) {}
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; mainH.post { removeCursor() }; return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; removeCursor(); super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun findEditable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isEditable) return n
        for (i in 0 until n.childCount) findEditable(n.getChild(i))?.let { return it }
        return null
    }

    fun typeText(text: String, append: Boolean): String {
        val done = retry {
            val root = rootInActiveWindow ?: return@retry null
            val node = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable }
                ?: findEditable(root) ?: return@retry null
            pointAt(node, "WRITE", false)
            val old = if (append && !node.isShowingHintText) (node.text?.toString() ?: "") else ""
            val b = Bundle()
            b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, old + text)
            node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
        }
        return if (done == true) "Text likh diya." else "Koi text box nahi mila ya text nahi likha ja saka."
    }

    fun tapText(label: String): String {
        val done = retry {
            val root = rootInActiveWindow ?: return@retry null
            val hits = root.findAccessibilityNodeInfosByText(label)
            for (h in hits) {
                var n: AccessibilityNodeInfo? = h
                while (n != null && !n.isClickable) n = n.parent
                if (n != null) {
                    pointAt(n, "TAP: " + label.take(18), true)
                    if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return@retry true
                }
            }
            null
        }
        return if (done == true) "'$label' dba diya." else "Screen par '$label' nahi mila."
    }

    fun key(k: String): String {
        val m = resources.displayMetrics
        val w = m.widthPixels
        val h = m.heightPixels
        when (k.lowercase()) {
            "back" -> pointer((w * 0.2f).toInt(), (h * 0.96f).toInt(), "BACK", true)
            "home" -> pointer(w / 2, (h * 0.96f).toInt(), "HOME", true)
            "recents" -> pointer((w * 0.8f).toInt(), (h * 0.96f).toInt(), "RECENTS", true)
            "notifications" -> pointer(w / 2, (h * 0.03f).toInt(), "NOTIFICATIONS", true)
            "scroll_down" -> pointer(w / 2, (h * 0.6f).toInt(), "SCROLL DOWN", false)
            "scroll_up" -> pointer(w / 2, (h * 0.4f).toInt(), "SCROLL UP", false)
        }
        try { Thread.sleep(550) } catch (e: InterruptedException) {}
        val ok = when (k.lowercase()) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "scroll_down", "scroll_up" -> scroll(k.lowercase() == "scroll_down")
            else -> return "Yeh key samajh nahi aayi: $k"
        }
        return if (ok) "Ho gaya." else "Nahi ho saka."
    }

    private fun scrollable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (n == null) return null
        if (n.isScrollable) return n
        for (i in 0 until n.childCount) scrollable(n.getChild(i))?.let { return it }
        return null
    }

    private fun scroll(down: Boolean): Boolean {
        val s = scrollable(rootInActiveWindow) ?: return false
        return s.performAction(
            if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        )
    }

    fun readScreen(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 1800) return
            val t = n.text?.toString() ?: n.contentDescription?.toString()
            if (!t.isNullOrBlank()) sb.append(t.trim()).append(" | ")
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return if (sb.isEmpty()) "Screen par kuch parha nahi gaya." else sb.toString()
    }
}
