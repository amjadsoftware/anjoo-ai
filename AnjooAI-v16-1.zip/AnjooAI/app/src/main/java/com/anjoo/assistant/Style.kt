package com.anjoo.assistant

import android.content.Context
import android.graphics.Color

/** A colour mode for the cyber look. */
class CyberTheme(
    val name: String,
    bg: String, surface: String, accent: String, user: String, ink: String, muted: String
) {
    val bg = Color.parseColor(bg)
    val surface = Color.parseColor(surface)
    val accent = Color.parseColor(accent)
    val user = Color.parseColor(user)
    val ink = Color.parseColor(ink)
    val muted = Color.parseColor(muted)
    val light: Boolean get() = (Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000 > 140
}

/** A "cyber officer" persona: changes the way Anjoo talks and sounds (purely a style). */
class Officer(
    val code: String,
    val role: String,
    val persona: String,
    val pitch: Float,
    val rate: Float,
    val greet: String
)

object Style {
    val themes = listOf(
        CyberTheme("MATRIX", "#020B05", "#071A0F", "#00FF66", "#0B4A25", "#CFFFE0", "#5FA67C"),
        CyberTheme("CYBER BLUE", "#02070F", "#07152A", "#00E5FF", "#0A3B66", "#D8F6FF", "#5C8FA8"),
        CyberTheme("RED ALERT", "#0D0204", "#1E070C", "#FF2D55", "#5E0F22", "#FFDDE3", "#A8606D"),
        CyberTheme("PURPLE HAZE", "#07020F", "#150A29", "#C77DFF", "#43206B", "#F1E3FF", "#8F70AD"),
        CyberTheme("CLAUDE", "#F5F4EE", "#FFFFFF", "#C96442", "#E9E6DB", "#1F1E1D", "#6B6A65"),
        CyberTheme("CLAUDE DARK", "#262624", "#30302E", "#D97757", "#3A3935", "#ECEBE6", "#9C9A92")
    )
    /** Index of the default (Claude-like) theme. */
    const val DEFAULT_THEME = 4

    val officers = listOf(
        Officer(
            "ZERO", "Red Team Lead",
            "Tumhari shakhsiyat: Officer ZERO, cyber unit ka Red Team Lead. Seedhe, tez aur confident andaz mein bolo, jaise mission report de rahe ho (\"Done.\", \"Target locked.\"). Hamesha mohazzab raho.",
            0.75f, 1.0f, "ZERO online. Mission batayein, boss."
        ),
        Officer(
            "GHOST", "Stealth Operator",
            "Tumhari shakhsiyat: Officer GHOST, khamosh stealth operator. Bohat mukhtasar, dheemay aur raaz-daari wale andaz mein bolo. Jawab sirf ek chhota jumla.",
            0.6f, 0.9f, "GHOST active. Bolein."
        ),
        Officer(
            "NOOR", "Cyber Intel Analyst",
            "Tumhari shakhsiyat: Officer NOOR, cyber intelligence analyst. Narmi, saaf aur madadgaar andaz mein bolo, thori si tehzeeb ke saath.",
            1.25f, 1.0f, "NOOR hazir hai. Kya kaam karun?"
        ),
        Officer(
            "SHIELD", "Defense Commander",
            "Tumhari shakhsiyat: Officer SHIELD, defense commander. Fauji, disciplined andaz mein bolo (\"Roger.\", \"Copy that.\", \"Order executed.\").",
            0.9f, 1.1f, "SHIELD standing by. Hukm dein, sir."
        )
    )

    const val FRIEND = "PERSONALITY: Be warm, friendly, patient, respectful, and genuinely useful—like a trusted human assistant. Use natural conversational Urdu, Roman Urdu, or English; never force a language the user did not use. Help with general knowledge, writing, translation, study, planning, brainstorming, coding, troubleshooting, and available phone tasks. Be emotionally considerate without theatrical mood changes or exaggerated roleplay. Give clear step-by-step help when useful. Be honest about uncertainty and limitations. Do not pretend to be human; simply use natural human-sounding language. Respect the user's exact intent and never take unrequested actions. Use available tools when appropriate, and verify results before reporting completion. Save personal details only when the user explicitly asks you to remember them."

    const val CODING = "ANSWER STYLE (like the best assistants): Answer first, then details. Use Markdown: short headings only for long answers, bullet or numbered lists for steps, **bold** for key terms. Match the user's language and script (Urdu, Roman Urdu, English). " +
        "REASONING: for maths, logic, debugging, planning and decisions, work through it carefully step by step internally, check the result, then give the verified answer plus a short explanation (no messy scratch work). If you are unsure or the topic may have changed recently, say so plainly. " +
        "DOCUMENTS: when given long text, give TL;DR, key points and action items. " +
        "AMBIGUITY: make the most sensible assumption, state it in one line and proceed; ask a question only when you are truly blocked. " +
        "CODE IN CHAT: always use fenced blocks with the language and a filename, for example ```html index.html or ```python app.py. One block per file; the app shows Copy, Save, Share, Preview and Download-all buttons on them. Code must be complete and runnable, never placeholders or '...'. For web demos give ONE self-contained HTML file (inline CSS and JS) so Preview works. " +
        "After code add 2-4 lines: how to run it and what to change. Think about edge cases, errors, security and accessibility before writing. " +
        "BIG BUILDS (multi-file apps, websites, games, edit an existing project): use the write_code or edit_code tool, which builds the whole project in Code Studio; then just say what was built. " +
        "VOICE REPLIES: keep them short and natural; never read code, URLs or markdown symbols aloud."

    /** Extra prompt lines that depend on the current modes and the latest message. */
    fun extra(ctx: Context): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val sb = StringBuilder()
        val tr = p.getString("translator", "") ?: ""
        if (tr.isNotEmpty()) sb.append("TARJUMAN MODE ON: user ki har baat ka sirf ").append(tr).append(" mein tarjuma bolo, aur kuch nahi, jab tak user band karne ko na kahe.\n")
        val n = NotifState.contextLine()
        if (n.isNotEmpty()) sb.append(n).append("\n")
        try {
            val r = org.json.JSONObject(p.getString("routines", "{}") ?: "{}")
            if (r.length() > 0) {
                sb.append("User ke sikhaye hue routines (user in naamon se bulaye to unke steps tools se poore karo):\n")
                for (k in r.keys()) sb.append("- ").append(k).append(": ").append(r.getString(k)).append("\n")
            }
        } catch (e: Exception) {}
        sb.append(ChatStore.recentContext(ctx))
        return sb.toString()
    }

    fun officer(ctx: Context): Officer {
        val i = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getInt("officer", 0)
        return officers[i.coerceIn(0, officers.size - 1)]
    }
}
