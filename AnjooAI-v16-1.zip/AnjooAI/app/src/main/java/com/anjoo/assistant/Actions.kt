package com.anjoo.assistant

import android.Manifest
import android.app.Activity
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Locale

/** Runs the phone actions Claude asks for. Call and SMS always ask the user first. */
class Actions(
    private val act: Context,
    private val confirm: (String) -> Boolean
) {

    /** Shows the mouse arrow for visible tasks, so the user can see Anjoo working (needs Accessibility on). */
    private fun hint(name: String, a: JSONObject) {
        val acc = AnjooAccess.inst ?: return
        val label = when (name) {
            "open_app" -> "OPEN: " + a.optString("name").take(16)
            "call" -> "CALL: " + a.optString("to").take(16)
            "send_sms" -> "SMS"
            "whatsapp_message" -> "WHATSAPP"
            "set_alarm" -> "ALARM"
            "set_timer" -> "TIMER"
            "web_search" -> "SEARCH"
            "open_url" -> "OPEN LINK"
            "navigate" -> "MAP"
            "flashlight" -> "TORCH"
            "volume" -> "VOLUME"
            "media" -> "MEDIA"
            "play_music" -> "MUSIC"
            "add_calendar_event" -> "CALENDAR"
            "send_email" -> "EMAIL"
            "open_settings" -> "SETTINGS"
            "share_text" -> "SHARE"
            "copy_text" -> "COPY"
            "weather" -> "WEATHER"
            "set_reminder" -> "REMINDER"
            "create_page", "write_code", "edit_code" -> "CODING..."
            else -> return
        }
        acc.hint(label)
    }

    fun run(name: String, a: JSONObject): String {
        try { hint(name, a) } catch (e: Exception) {}
        return dispatch(name, a)
    }

    private fun dispatch(name: String, a: JSONObject): String = when (name) {
        "open_app" -> openApp(a.getString("name"))
        "find_contact" -> findContact(a.getString("name"))
        "call" -> call(a.getString("to"))
        "send_sms" -> sendSms(a.getString("to"), a.getString("text"))
        "whatsapp_message" -> whatsapp(a.getString("to"), a.getString("text"))
        "set_alarm" -> setAlarm(a.getInt("hour"), a.getInt("minute"), a.optString("label", "Anjoo AI"))
        "set_timer" -> setTimer(a.getInt("seconds"), a.optString("label", "Anjoo AI"))
        "web_search" -> webSearch(a.getString("query"))
        "open_url" -> openUrl(a.getString("url"))
        "navigate" -> navigate(a.getString("place"))
        "flashlight" -> flashlight(a.getBoolean("on"))
        "volume" -> volume(a.getString("action"))
        "media" -> media(a.getString("action"))
        "battery" -> battery()
        "add_calendar_event" -> calendarEvent(
            a.getString("title"), a.getString("datetime"), a.optInt("duration_minutes", 60)
        )
        "send_email" -> email(a.optString("to", ""), a.getString("subject"), a.getString("body"))
        "open_settings" -> openSettings(a.getString("page"))
        "weather" -> weather(a.getString("city"))
        "play_music" -> playMusic(a.getString("query"))
        "share_text" -> shareText(a.getString("text"))
        "read_sms" -> readSms(a.optInt("count", 3), a.optString("from", ""))
        "today_events" -> todayEvents()
        "copy_text" -> copyText(a.getString("text"))
        "type_text" -> (AnjooAccess.inst?.typeText(a.getString("text"), a.optBoolean("append", false)) ?: AnjooAccess.OFF)
        "tap_text" -> (AnjooAccess.inst?.tapText(a.getString("label")) ?: AnjooAccess.OFF)
        "press_key" -> (AnjooAccess.inst?.key(a.getString("key")) ?: AnjooAccess.OFF)
        "read_screen" -> (AnjooAccess.inst?.readScreen() ?: AnjooAccess.OFF)
        "remember" -> remember(a.getString("text"))
        "forget" -> forget(a.getString("text"))
        else -> MoreTools.run(act, confirm, name, a) ?: "Yeh kaam mujhe nahi aata: $name"
    }

    private fun httpGet(url: String): String {
        val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
    }

    private fun weather(city: String): String {
        val g = JSONObject(httpGet("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + URLEncoder.encode(city, "UTF-8")))
        val r = g.optJSONArray("results")?.optJSONObject(0) ?: return "Shehar '$city' nahi mila."
        val w = JSONObject(httpGet(
            "https://api.open-meteo.com/v1/forecast?latitude=" + r.getDouble("latitude") + "&longitude=" + r.getDouble("longitude") +
                "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m" +
                "&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto&forecast_days=1"
        ))
        val cur = w.getJSONObject("current")
        val day = w.getJSONObject("daily")
        return r.optString("name", city) + ": abhi " + cur.getDouble("temperature_2m") + " C, nami " +
            cur.getInt("relative_humidity_2m") + "%, hawa " + cur.getDouble("wind_speed_10m") + " km/h, WMO weather_code " +
            cur.getInt("weather_code") + ". Aaj ziyada se ziyada " + day.getJSONArray("temperature_2m_max").getDouble(0) +
            " C, kam se kam " + day.getJSONArray("temperature_2m_min").getDouble(0) + " C, baarish ka imkaan " +
            day.getJSONArray("precipitation_probability_max").optInt(0) + "%."
    }

    private fun playMusic(q: String): String {
        val i = Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
            .putExtra(SearchManager.QUERY, q)
            .putExtra(android.provider.MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
        return try {
            launch(i)
            "'$q' chalane ki koshish ki."
        } catch (e: Exception) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8"))))
            "YouTube par '$q' khol diya."
        }
    }

    private fun shareText(t: String): String {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t)
        launch(Intent.createChooser(i, "Share"))
        return "Share ka menu khol diya."
    }

    private fun contactName(number: String): String {
        return try {
            act.contentResolver.query(
                Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null
            )?.use { if (it.moveToFirst()) it.getString(0) else number } ?: number
        } catch (e: Exception) { number }
    }

    private fun readSms(count: Int, from: String): String {
        if (!has(Manifest.permission.READ_SMS)) return "SMS parhne ki ijazat nahi di gayi. Settings > Apps > Anjoo AI > Permissions mein SMS allow karein."
        val n = count.coerceIn(1, 8)
        val sel = if (from.isNotBlank()) "address LIKE ?" else null
        val args = if (from.isNotBlank()) arrayOf("%" + from.filter { it.isDigit() || it == '+' } + "%") else null
        val out = StringBuilder()
        act.contentResolver.query(
            Uri.parse("content://sms/inbox"), arrayOf("address", "body", "date"), sel, args, "date DESC"
        )?.use { c ->
            var k = 0
            while (k < n && c.moveToNext()) {
                out.append(contactName(c.getString(0) ?: "?")).append(": ")
                    .append((c.getString(1) ?: "").take(300)).append("\n")
                k++
            }
        }
        return if (out.isEmpty()) "Koi SMS nahi mila." else out.toString()
    }

    private fun todayEvents(): String {
        if (!has(Manifest.permission.READ_CALENDAR)) return "Calendar ki ijazat nahi di gayi. Settings > Apps > Anjoo AI > Permissions mein Calendar allow karein."
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0); cal.set(java.util.Calendar.SECOND, 0)
        val start = cal.timeInMillis
        val end = start + 24L * 3600 * 1000
        val out = StringBuilder()
        val fmt = SimpleDateFormat("HH:mm", Locale.ENGLISH)
        CalendarContract.Instances.query(
            act.contentResolver, arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN), start, end
        )?.use { c ->
            while (c.moveToNext()) {
                out.append(fmt.format(java.util.Date(c.getLong(1)))).append(" - ").append(c.getString(0) ?: "").append("\n")
            }
        }
        return if (out.isEmpty()) "Aaj koi program nahi." else out.toString()
    }

    private fun copyText(t: String): String {
        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("Anjoo", t))
        return "Text copy kar diya."
    }

    // ---------- device controls ----------

    private fun flashlight(on: Boolean): String {
        val cm = act.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "Is phone mein torch nahi mili."
        cm.setTorchMode(id, on)
        return if (on) "Torch on kar di." else "Torch band kar di."
    }

    private fun volume(action: String): String {
        val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val stream = AudioManager.STREAM_MUSIC
        val flag = AudioManager.FLAG_SHOW_UI
        when (action.lowercase()) {
            "up" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, flag)
            "down" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, flag)
            "mute" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, flag)
            "unmute" -> am.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, flag)
            "max" -> am.setStreamVolume(stream, am.getStreamMaxVolume(stream), flag)
            else -> return "Volume ka action samajh nahi aaya: $action"
        }
        return "Volume theek kar diya."
    }

    private fun media(action: String): String {
        val code = when (action.lowercase()) {
            "play_pause", "play", "pause" -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
            "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
            "previous", "prev" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            else -> return "Media ka action samajh nahi aaya: $action"
        }
        val am = act.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        return "Music par kaam kar diya."
    }

    private fun battery(): String {
        val bm = act.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        return "Battery $pct% hai" + if (bm.isCharging) ", charge ho rahi hai." else "."
    }

    private fun calendarEvent(title: String, datetime: String, minutes: Int): String {
        val start = try {
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).parse(datetime.trim())?.time
        } catch (e: Exception) { null } ?: return "Waqt ka format galat hai: $datetime"
        val i = Intent(Intent.ACTION_INSERT)
            .setData(CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title)
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, start)
            .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, start + minutes * 60_000L)
        launch(i)
        return "Calendar mein '$title' ka event khol diya. User ko save dabana hoga."
    }

    private fun email(to: String, subject: String, body: String): String {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_SUBJECT, subject)
            .putExtra(Intent.EXTRA_TEXT, body)
        if (to.isNotBlank()) i.putExtra(Intent.EXTRA_EMAIL, arrayOf(to))
        launch(i)
        return "Email ka draft khol diya. User ko send dabana hoga."
    }

    private fun openSettings(page: String): String {
        val action = when (page.lowercase()) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            "apps" -> Settings.ACTION_APPLICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        launch(Intent(action))
        return "Settings ($page) khol di."
    }

    // ---------- notes the assistant keeps ----------

    private val prefs = act.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    fun notes(): List<String> {
        val a = try { JSONArray(prefs.getString("notes", "[]")) } catch (e: Exception) { JSONArray() }
        return (0 until a.length()).map { a.getString(it) }
    }

    private fun saveNotes(list: List<String>) {
        val a = JSONArray()
        list.takeLast(50).forEach { a.put(it) }
        prefs.edit().putString("notes", a.toString()).apply()
    }

    private fun remember(text: String): String {
        saveNotes(notes() + text.trim())
        return "Yaad rakh liya."
    }

    private fun forget(text: String): String {
        val before = notes()
        val after = before.filterNot { it.contains(text.trim(), ignoreCase = true) }
        saveNotes(after)
        return if (after.size < before.size) "Bhula diya." else "Aisi koi yaad rakhi baat nahi mili."
    }

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        act.startActivity(i)
    }

    private fun has(permission: String) =
        act.checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    // ---------- apps ----------

    private fun openApp(wanted: String): String {
        val pm = act.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0).map {
            Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName)
        }
        val w = wanted.trim().lowercase()
        val match = apps.firstOrNull { it.first.lowercase() == w }
            ?: apps.firstOrNull { it.first.lowercase().contains(w) }
            ?: apps.firstOrNull { w.contains(it.first.lowercase()) && it.first.length > 3 }
        if (match == null) {
            val names = apps.map { it.first }.sorted().take(60).joinToString(", ")
            return "'$wanted' naam ki app nahi mili. Installed apps: $names"
        }
        val intent = pm.getLaunchIntentForPackage(match.second)
            ?: return "${match.first} khul nahi saki."
        launch(intent)
        return "${match.first} khol di."
    }

    // ---------- contacts ----------

    private fun isNumber(s: String) = s.trim().matches(Regex("^[+0-9 ()-]{5,}$"))

    private fun lookup(q: String): List<Pair<String, String>> {
        if (!has(Manifest.permission.READ_CONTACTS)) return emptyList()
        val out = ArrayList<Pair<String, String>>()
        val c = act.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%" + q.trim() + "%"),
            null
        )
        c?.use {
            while (it.moveToNext()) out.add(Pair(it.getString(0) ?: "", it.getString(1) ?: ""))
        }
        return out.distinct()
    }

    private fun findContact(name: String): String {
        if (!has(Manifest.permission.READ_CONTACTS)) return "Contacts ki ijazat nahi mili."
        val r = lookup(name)
        if (r.isEmpty()) return "'$name' naam ka koi contact nahi mila."
        return r.take(8).joinToString("\n") { it.first + ": " + it.second }
    }

    /** Returns (display name, number) or an error text. */
    private fun resolve(to: String): Pair<Pair<String, String>?, String?> {
        if (isNumber(to)) return Pair(Pair(to.trim(), to.trim()), null)
        if (!has(Manifest.permission.READ_CONTACTS)) return Pair(null, "Contacts ki ijazat nahi mili.")
        val r = lookup(to)
        if (r.isEmpty()) return Pair(null, "'$to' naam ka koi contact nahi mila.")
        val names = r.map { it.first }.distinct()
        if (names.size > 1) {
            return Pair(null, "Kai contacts mile: " + names.take(6).joinToString(", ") + ". User se poochein kaun sa.")
        }
        return Pair(r[0], null)
    }

    private fun waNumber(n: String): String {
        var d = n.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.substring(2)
        else if (d.startsWith("0")) d = "92" + d.substring(1)
        return d
    }

    // ---------- call / sms / whatsapp ----------

    private fun call(to: String): String {
        val (hit, err) = resolve(to)
        if (hit == null) return err ?: "Number nahi mila."
        if (!confirm("${hit.first} ko call karun?\n${hit.second}")) return "User ne mana kar diya."
        val uri = Uri.parse("tel:" + Uri.encode(hit.second))
        return if (has(Manifest.permission.CALL_PHONE)) {
            launch(Intent(Intent.ACTION_CALL, uri))
            "${hit.first} ko call laga di."
        } else {
            launch(Intent(Intent.ACTION_DIAL, uri))
            "Call ki ijazat nahi, isliye dialer khol diya. User ko hara button dabana hoga."
        }
    }

    @Suppress("DEPRECATION")
    private fun sendSms(to: String, text: String): String {
        val (hit, err) = resolve(to)
        if (hit == null) return err ?: "Number nahi mila."
        if (!confirm("${hit.first} ko SMS bhejun?\n\n$text")) return "User ne mana kar diya."
        if (!has(Manifest.permission.SEND_SMS)) {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(hit.second)))
            i.putExtra("sms_body", text)
            launch(i)
            return "SMS ki ijazat nahi, isliye messages app khol di. User ko send dabana hoga."
        }
        val sms = SmsManager.getDefault()
        sms.sendMultipartTextMessage(hit.second, null, sms.divideMessage(text), null, null)
        return "${hit.first} ko SMS bhej diya."
    }

    private fun whatsapp(to: String, text: String): String {
        val (hit, err) = resolve(to)
        if (hit == null) return err ?: "Number nahi mila."
        val url = "https://wa.me/" + waNumber(hit.second) + "?text=" + URLEncoder.encode(text, "UTF-8")
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        i.setPackage("com.whatsapp")
        return try {
            launch(i)
            "${hit.first} ki WhatsApp chat khol di, paigham likha hua hai. User ko send dabana hoga."
        } catch (e: Exception) {
            try {
                launch(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                "WhatsApp link khol diya. User ko send dabana hoga."
            } catch (e2: Exception) {
                "WhatsApp nahi khul saka."
            }
        }
    }

    // ---------- alarm / timer ----------

    private fun setAlarm(hour: Int, minute: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, hour)
            .putExtra(AlarmClock.EXTRA_MINUTES, minute)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        launch(i)
        return "Alarm %02d:%02d par laga diya.".format(hour, minute)
    }

    private fun setTimer(seconds: Int, label: String): String {
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
            .putExtra(AlarmClock.EXTRA_MESSAGE, label)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        launch(i)
        return "$seconds seconds ka timer laga diya."
    }

    // ---------- web / maps ----------

    private fun webSearch(q: String): String {
        return try {
            launch(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
            "'$q' search kar diya."
        } catch (e: Exception) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
            "'$q' browser mein search kar diya."
        }
    }

    private fun openUrl(url: String): String {
        val u = if (url.startsWith("http")) url else "https://$url"
        launch(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
        return "$u khol diya."
    }

    private fun navigate(place: String): String {
        return try {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(place))))
            "$place ka rasta khol diya."
        } catch (e: Exception) {
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(place))))
            "$place Maps mein khol diya."
        }
    }
}
