package com.anjoo.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Keeps Anjoo AI listening in the background. Say "Anjoo" followed by a command.
 * Call and SMS ask for a spoken "haan" first.
 */
class VoiceService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val ACTION_STOP = "com.anjoo.assistant.STOP"
        const val ACTION_LISTEN = "com.anjoo.assistant.LISTEN"
        private const val CHANNEL = "anjoo_voice"
        private const val NOTIF_ID = 7

        @Volatile
        var running = false

        @Volatile
        var inst: VoiceService? = null

        /** Read a line out loud (for example a new chat message), without the mic hearing it. */
        fun announce(text: String) { inst?.announce(text) }

        private val WAKE = listOf("anjoo", "anju", "anjo", "انجو", "آنجو", "انجُو")
        private val YES = setOf(
            "haan", "han", "haa", "ha", "yes", "yeah", "ji", "jee", "ok", "okay", "theek", "thik",
            "bilkul", "kardo", "karo", "ہاں", "جی", "ٹھیک", "بالکل", "کردو", "کرو"
        )
        private val STOPW = listOf("ruko", "rukiye", "ruk jao", "bas karo", "bas kar", "chup", "khamosh", "stop", "band karo",
            "رکو", "رکیے", "رک جاؤ", "بس کرو", "بس کر", "چپ", "خاموش", "بند کرو")
        private val NO = setOf("nahi", "nahin", "na", "no", "mat", "nope", "نہیں", "نہ", "مت", "نا")
    }

    private enum class Mode { LISTEN, CONFIRM, BUSY, SPEAKING }

    private val main = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var urduOk = false
    private lateinit var agent: Agent
    private lateinit var actions: Actions
    private var overlay: View? = null

    @Volatile private var mode = Mode.LISTEN
    private var awaitingCommand = false
    private var stopped = false
    private var speakSeq = 0
    private var lastStart = 0L
    private var lastDiag = 0L
    private val pendingAnn = ArrayList<String>()
    private var ear: Ear? = null
    private var ignoreUntil = 0L
    private var lastBarge = 0L
    private var lastSpoken = ""
    private var lastSpokenEnd = 0L
    private var pendingHeard = ""
    private val flushHeard = Runnable {
        val t = pendingHeard.trim(); pendingHeard = ""
        if (t.isNotEmpty() && !stopped && mode == Mode.LISTEN) handleHeard(t)
    }

    private fun headsetOn(): Boolean = try {
        val am = getSystemService(AUDIO_SERVICE) as android.media.AudioManager
        am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS).any {
            it.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            it.type == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            it.type == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
            it.type == android.media.AudioDeviceInfo.TYPE_USB_HEADSET
        }
    } catch (e: Exception) { false }

    /** True when the heard text is just Anjoo's own last sentence coming back through the microphone. */
    private fun isOwnEcho(text: String): Boolean {
        if (lastSpoken.isEmpty() || SystemClock.elapsedRealtime() - lastSpokenEnd > 8000) return false
        fun words(x: String) = x.lowercase(Locale.ROOT).split(Regex("[^\\p{L}\\p{N}]+")).filter { it.length > 1 }
        val h = words(text); if (h.isEmpty()) return false
        val said = words(lastSpoken).toSet()
        return h.count { it in said }.toDouble() / h.size >= 0.6
    }

    /** Short or unfinished sentences (slow speakers) wait a moment for the rest; complete ones go instantly. */
    private fun looksUnfinished(t: String): Boolean {
        val w = t.trim().lowercase(Locale.ROOT).split(Regex("\\s+"))
        if (w.size < 3) return true
        val tail = setOf("aur","ya","to","ke","ka","ki","ko","se","mein","me","mujhe","hmm","umm","matlab","and","or","the","to","for","with","ek","wo","woh","ye","yeh")
        return w.last().trim(',', '.', '،') in tail
    }
    @Volatile private var queuedCmd: String? = null
    @Volatile private var dropReply = false
    private var lastSttDiag = 0L
    private var speakingId = ""
    private var bubble: BuddyView? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private var confirmLatch: CountDownLatch? = null
    @Volatile private var confirmAnswer = false

    // ---------- lifecycle ----------

    override fun onCreate() {
        super.onCreate()
        running = true
        inst = this
        createChannel()
        try {
            val n = notification("Sun raha hoon. Bolein: Anjoo, phir hukm.")
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Background mode shuru nahi ho saka (mic ya notification ki ijazat check karein).", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        addOverlay()
        addBubble()
        actions = Actions(this) { askYesNo(it) }
        agent = Agent(this, actions)
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_LISTEN -> main.post {
                awaitingCommand = true
                if (mode == Mode.LISTEN) startListening(0)
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopped = true
        running = false
        inst = null
        removeBubble()
        main.removeCallbacksAndMessages(null)
        try { recognizer?.destroy() } catch (e: Exception) {}
        recognizer = null
        GeminiVoice.stop()
        ear?.stop()
        tts?.shutdown()
        confirmLatch?.countDown()
        removeOverlay()
        super.onDestroy()
    }

    override fun onInit(status: Int) {
        val t = tts
        if (status == TextToSpeech.SUCCESS && t != null) {
            ttsReady = true
            urduOk = t.isLanguageAvailable(Locale("ur", "PK")) >= TextToSpeech.LANG_AVAILABLE
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    main.post { onSpeakDone(utteranceId ?: "") }
                }
                override fun onError(utteranceId: String?) {
                    main.post { onSpeakDone(utteranceId ?: "") }
                }
            })
        }
        agent.urduScriptVoice = urduOk
        if (!useEar() && !SpeechRecognizer.isRecognitionAvailable(this)) {
            Toast.makeText(this, "Is phone par awaaz pehchaan maujood nahi. Google app install karein.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        startListening(500)
        main.postDelayed(watchdog, 15000)
    }

    // ---------- keep the recogniser alive ----------

    private val watchdog = object : Runnable {
        override fun run() {
            if (stopped) return
            if (useEar()) ensureEar()
            else if (mode == Mode.LISTEN && SystemClock.elapsedRealtime() - lastStart > 40000) startListening(0)
            main.postDelayed(this, 15000)
        }
    }

    private fun useEar() = (getSharedPreferences("anjoo", MODE_PRIVATE).getString("engine", "ear") ?: "ear") == "ear"

    private fun startListening(delayMs: Long) {
        if (stopped) return
        if (useEar()) {
            main.postDelayed({ ensureEar() }, delayMs)
            return
        }
        main.postDelayed({ doStart() }, delayMs)
    }

    // ---------- always-open microphone ----------

    private fun ensureEar() {
        if (stopped || ear?.isRunning() == true) return
        ear?.stop()
        ear = Ear({ pcm -> main.post { onUtterance(pcm) } }, { msg ->
            main.post {
                Buddy.post(3, "[MIC] $msg")
                if (!stopped) main.postDelayed({ ensureEar() }, 4000)
            }
        }).also { it.start() }
    }

    private fun onUtterance(pcm: ByteArray) {
        if (stopped) return
        val now = SystemClock.elapsedRealtime()
        when (mode) {
            Mode.BUSY -> transcribeAsync(pcm) { text -> main.post { onBusyText(text) } }
            Mode.SPEAKING -> {
                if (now - lastBarge < 1500) return
                lastBarge = now
                transcribeAsync(pcm) { text -> main.post { onBargeText(text) } }
            }
            else -> {
                if (now < ignoreUntil) return
                val m = mode
                transcribeAsync(pcm) { text -> main.post { onEarText(text, m) } }
            }
        }
    }

    private fun transcribeAsync(pcm: ByteArray, done: (String) -> Unit) {
        Thread {
            val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
            val key = prefs.getString("key", "") ?: ""
            val model = prefs.getString("sttModel", null) ?: "gemini-3.5-flash-lite"
            val lang = prefs.getString("lang", "ur-PK") ?: "ur-PK"
            val text = try {
                if (key.isEmpty()) "" else Gemini.transcribe(key, model, pcm, lang)
            } catch (e: Exception) {
                val t = SystemClock.elapsedRealtime()
                if (t - lastSttDiag > 15000) {
                    lastSttDiag = t
                    Buddy.post(3, "[MIC] awaaz samajhne mein masla: " + (e.message ?: "").take(80))
                }
                ""
            }
            if (text.isNotBlank()) done(text)
        }.start()
    }

    private fun onEarText(text: String, wasMode: Mode) {
        if (stopped || mode != wasMode) return
        when (wasMode) {
            Mode.CONFIRM -> {
                confirmAnswer = isYes(text)
                confirmLatch?.countDown()
            }
            Mode.LISTEN -> {
                if (isOwnEcho(text)) return
                main.removeCallbacks(flushHeard)
                pendingHeard = (pendingHeard + " " + text).trim()
                if (looksUnfinished(pendingHeard) && !awaitingCommand) main.postDelayed(flushHeard, 900)
                else flushHeard.run()
            }
            else -> {}
        }
    }

    /** While Anjoo is talking: saying its name or "ruko/bas" stops it, and anything after the name is a new order. */
    private fun onBargeText(text: String) {
        if (stopped || mode != Mode.SPEAKING || speakingId == "confirm" || isOwnEcho(text)) return
        val lower = text.lowercase(Locale.ROOT)
        val named = WAKE.any { lower.contains(it) }
        val stopWord = STOPW.any { lower.contains(it) }
        if (!named && !stopWord) return
        GeminiVoice.stop()
        try { tts?.stop() } catch (e: Exception) {}
        speakSeq++
        endSpeakingEar()
        mode = Mode.LISTEN
        ignoreUntil = SystemClock.elapsedRealtime() + 300
        Buddy.post(3, "[MIC] beech mein rok diya")
        if (named) handleHeard(text)
    }

    private fun doStart() {
        if (stopped || (mode != Mode.LISTEN && mode != Mode.CONFIRM)) return
        try {
            recognizer?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(listener)
            recognizer = r
            val lang = getSharedPreferences("anjoo", MODE_PRIVATE).getString("lang", "ur-PK") ?: "ur-PK"
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
                .putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
            lastStart = SystemClock.elapsedRealtime()
            r.startListening(i)
        } catch (e: Exception) {
            startListening(3000)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            if (stopped) return
            when (mode) {
                Mode.CONFIRM -> {
                    confirmAnswer = false
                    confirmLatch?.countDown()
                }
                Mode.LISTEN -> {
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        stopSelf()
                        return
                    }
                    if (error != SpeechRecognizer.ERROR_NO_MATCH && error != SpeechRecognizer.ERROR_SPEECH_TIMEOUT &&
                        SystemClock.elapsedRealtime() - lastDiag > 15000
                    ) {
                        lastDiag = SystemClock.elapsedRealtime()
                        Buddy.post(3, "[MIC] awaaz pehchaan ka masla (code $error)" +
                            if (error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                                error == SpeechRecognizer.ERROR_SERVER) " - internet check karein" else "")
                    }
                    val wait = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 150L
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                        SpeechRecognizer.ERROR_SERVER -> 4000L
                        else -> 1500L
                    }
                    startListening(wait)
                }
                else -> {}
            }
        }

        override fun onResults(results: Bundle?) {
            if (stopped) return
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
            when (mode) {
                Mode.CONFIRM -> {
                    confirmAnswer = isYes(text)
                    confirmLatch?.countDown()
                }
                Mode.LISTEN -> handleHeard(text)
                else -> {}
            }
        }
    }

    // ---------- what was heard ----------

    private fun handleHeard(text: String) {
        val heard = text.trim()
        if (heard.isEmpty()) {
            startListening(150)
            return
        }
        val lower = heard.lowercase(Locale.ROOT)
        var found: String? = null
        for (w in WAKE) {
            val i = lower.indexOf(w)
            if (i >= 0) {
                found = heard.substring(i + w.length).trim().trimStart(',', '.', '،', ':', '-', ' ')
                break
            }
        }
        val needWake = getSharedPreferences("anjoo", MODE_PRIVATE).getBoolean("wake", false)
        val command: String = found ?: if (awaitingCommand || !needWake) heard else {
            startListening(150)
            return
        }
        if (command.isBlank()) {
            awaitingCommand = true
            mode = Mode.SPEAKING
            speak("Ji?", "ack")
            return
        }
        awaitingCommand = false
        beep()
        Buddy.post(0, command)
        ChatStore.append(this, 0, command)
        process(command)
    }

    /** A tiny sound the moment a command is understood, so the user knows Anjoo heard it. */
    private fun beep() {
        try {
            val tg = android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 45)
            tg.startTone(android.media.ToneGenerator.TONE_PROP_ACK, 110)
            main.postDelayed({ try { tg.release() } catch (e: Exception) {} }, 400)
        } catch (e: Exception) {}
    }

    private fun process(command: String) {
        mode = Mode.BUSY
        bubble?.setMood(Mood.THINKING, 0)
        try { recognizer?.cancel() } catch (e: Exception) {}
        setStatus("Soch raha hoon...")
        Thread {
            val answer = try {
                agent.ask(command)
            } catch (e: Exception) {
                "Masla aaya. " + (e.message ?: "").take(80)
            }
            main.post { deliver(answer) }
        }.start()
    }

    private fun onBusyText(text: String) {
        if (stopped || mode != Mode.BUSY || text.isBlank()) return
        val lower = text.lowercase(Locale.ROOT)
        if (STOPW.any { lower.contains(it) }) { dropReply = true; queuedCmd = null; return }
        queuedCmd = if (queuedCmd == null) text.trim() else queuedCmd + " " + text.trim()
    }

    private fun deliver(text: String) {
        if (stopped) return
        if (dropReply) {
            dropReply = false
            mode = Mode.LISTEN
            setStatus("Ruk gaya. Bolein.")
            startListening(150)
            return
        }
        val q = queuedCmd
        if (q != null) {
            queuedCmd = null
            Buddy.post(0, q)
            ChatStore.append(this, 0, q)
            process(q)
            return
        }
        setStatus("Sun raha hoon. Bolein: Anjoo, phir hukm.")
        if (text.isBlank()) {
            mode = Mode.LISTEN
            startListening(300)
            return
        }
        mode = Mode.SPEAKING
        Buddy.post(1, text)
        ChatStore.append(this, 1, text)
        bubble?.setMood(Mood.fromText(text) ?: Mood.HAPPY, 6000)
        bubble?.talk(minOf(8000L, text.length * 70L))
        speak(text, "reply")
    }

    // ---------- spoken yes/no for call and SMS ----------

    private fun isYes(text: String): Boolean {
        val words = text.lowercase(Locale.ROOT).split(Regex("[\\s,.!?؟،]+")).filter { it.isNotEmpty() }
        if (words.any { it in NO }) return false
        return words.any { it in YES }
    }

    /** Called from the agent thread: speaks the question, listens once, returns true only on a clear yes. */
    private fun askYesNo(message: String): Boolean {
        val latch = CountDownLatch(1)
        confirmLatch = latch
        confirmAnswer = false
        main.post {
            mode = Mode.SPEAKING
            try { recognizer?.cancel() } catch (e: Exception) {}
            speak(message.replace('\n', ' ') + ". Haan ya nahi bolein.", "confirm")
        }
        val finished = latch.await(45, TimeUnit.SECONDS)
        main.post {
            try { recognizer?.cancel() } catch (e: Exception) {}
            mode = Mode.BUSY
        }
        return finished && confirmAnswer
    }

    // ---------- speaking ----------

    private fun speak(text: String, id: String) {
        speakingId = id
        lastSpoken = text
        ear?.muted = !headsetOn()   // loudspeaker: stop listening while talking; headset: allow "ruko" interrupts
        if (GeminiVoice.enabled(this) && (getSharedPreferences("anjoo", MODE_PRIVATE).getString("key", "") ?: "").isNotEmpty()) {
            val seq = ++speakSeq
            main.postDelayed({
                if (seq == speakSeq && mode == Mode.SPEAKING) onSpeakDone(id)
            }, 15000L + text.length * 200L)
            Thread {
                val ok = GeminiVoice.say(this, text)
                main.post {
                    if (stopped) return@post
                    if (ok) { if (seq == speakSeq) onSpeakDone(id) } else systemSpeak(text, id)
                }
            }.start()
            return
        }
        systemSpeak(text, id)
    }

    private fun systemSpeak(text: String, id: String) {
        val t = tts
        if (t == null || !ttsReady) {
            main.post { onSpeakDone(id) }
            return
        }
        val urdu = text.any { it in '؀'..'ۿ' }
        t.setLanguage(if (urdu && urduOk) Locale("ur", "PK") else Locale("en", "IN"))
        val o = Style.officer(this)
        t.setPitch(o.pitch)
        t.setSpeechRate(o.rate)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        // If the speech engine never reports back, do not stay deaf forever.
        val seq = ++speakSeq
        main.postDelayed({
            if (seq == speakSeq && mode == Mode.SPEAKING) onSpeakDone(id)
        }, 8000L + text.length * 150L)
    }

    private fun endSpeakingEar() {
        lastSpokenEnd = SystemClock.elapsedRealtime()
        ear?.flush()
        main.postDelayed({ ear?.flush(); ear?.muted = false }, 700)   // let the room echo die out first
    }

    private fun onSpeakDone(id: String) {
        if (stopped || mode != Mode.SPEAKING) return
        speakSeq++
        endSpeakingEar()
        ignoreUntil = SystemClock.elapsedRealtime() + 1000
        when (id) {
            "confirm" -> {
                mode = Mode.CONFIRM
                startListening(150)
            }
            "ack" -> {
                mode = Mode.LISTEN
                awaitingCommand = true
                startListening(150)
            }
            else -> {
                mode = Mode.LISTEN
                if (pendingAnn.isNotEmpty()) announce(pendingAnn.removeAt(0)) else startListening(400)
            }
        }
    }

    // ---------- announcements and the floating markhor ----------

    private fun announce(text: String) {
        main.post {
            if (stopped) return@post
            if (mode == Mode.LISTEN) {
                mode = Mode.SPEAKING
                try { recognizer?.cancel() } catch (e: Exception) {}
                Buddy.post(3, "[MSG] $text")
                bubble?.setMood(Mood.SURPRISED, 2500)
                systemSpeak(text, "ann")
            } else if (pendingAnn.size < 5) {
                pendingAnn.add(text)
            }
        }
    }

    fun setBubbleVisible(show: Boolean) {
        main.post { bubble?.visibility = if (show) View.VISIBLE else View.GONE }
    }

    private fun addBubble() {
        val prefs = getSharedPreferences("anjoo", MODE_PRIVATE)
        if (!Settings.canDrawOverlays(this) || !prefs.getBoolean("bubble", true)) return
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val d = resources.displayMetrics.density
            val lp = WindowManager.LayoutParams(
                (130 * d).toInt(), (150 * d).toInt(),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = (10 * d).toInt()
            lp.y = (260 * d).toInt()
            val accent = Style.themes[prefs.getInt("theme", 0).coerceIn(0, Style.themes.size - 1)].accent
            val v = BuddyView(this, accent)
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            v.setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - sx
                        val dy = e.rawY - sy
                        if (Math.abs(dx) > 12 || Math.abs(dy) > 12) moved = true
                        if (moved) {
                            lp.x = ox + dx.toInt(); lp.y = oy + dy.toInt()
                            try { wm.updateViewLayout(v, lp) } catch (x: Exception) {}
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) v.onTap(e.x, e.y)
                }
                true
            }
            wm.addView(v, lp)
            bubble = v
            bubbleLp = lp
        } catch (e: Exception) {}
    }

    private fun removeBubble() {
        try {
            bubble?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        } catch (e: Exception) {}
        bubble = null
    }

    // ---------- notification and overlay ----------

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Anjoo AI", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP), flags
        )
        val talk = PendingIntent.getService(
            this, 2, Intent(this, VoiceService::class.java).setAction(ACTION_LISTEN), flags
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Anjoo AI chal raha hai")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_btn_speak_now), "Bolein", talk
                ).build()
            )
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Band karein", stop
                ).build()
            )
            .build()
    }

    private fun setStatus(text: String) {
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notification(text))
        } catch (e: Exception) {}
    }

    /**
     * A 1-pixel invisible window. Android lets a background app open other apps
     * (needed for "WhatsApp kholo") only while it has a visible overlay window.
     */
    private fun addOverlay() {
        try {
            if (!Settings.canDrawOverlays(this)) return
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val v = View(this)
            v.setBackgroundColor(Color.argb(1, 0, 0, 0))
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            overlay = v
        } catch (e: Exception) {}
    }

    private fun removeOverlay() {
        try {
            overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        } catch (e: Exception) {}
        overlay = null
    }
}
