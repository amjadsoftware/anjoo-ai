package com.anjoo.assistant

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast

/**
 * Replaces silent "catch {}" blocks on things the user cares about (saving, sharing, opening screens).
 * It logs the problem and shows ONE short message (at most one every 3 seconds, so nothing spams).
 */
object Oops {
    private var last = 0L

    fun note(ctx: Context, what: String, e: Throwable? = null) {
        try { android.util.Log.w("Anjoo", what, e) } catch (_: Throwable) {}
        val now = System.currentTimeMillis()
        if (now - last < 3000) return
        last = now
        val app = ctx.applicationContext ?: ctx
        Handler(Looper.getMainLooper()).post {
            try { Toast.makeText(app, what, Toast.LENGTH_LONG).show() } catch (_: Throwable) {}
        }
    }

    /** startActivity that tells the user when the phone has no screen for it. */
    fun open(ctx: Context, intent: Intent, what: String = "Ye screen is phone par nahi khul saki.") {
        try { ctx.startActivity(intent) } catch (e: Exception) { note(ctx, what, e) }
    }
}
