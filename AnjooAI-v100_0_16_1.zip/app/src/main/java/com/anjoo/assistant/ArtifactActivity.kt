package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject

/**
 * The Artifacts screen. Without an id it is the library (all pages, dashboards, apps, slides, documents, reports);
 * with an id it shows one artifact: live Preview, Code, hand Edit, Versions, Share (file / Wi-Fi link), Save to phone, Print / PDF.
 */
class ArtifactActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private val BG = Color.parseColor("#0B0F14")
    private val SURFACE = Color.parseColor("#151C24")
    private val INK = Color.parseColor("#E8EEF4")
    private val MUTED = Color.parseColor("#8A97A6")
    private val ACCENT = Color.parseColor("#4DD6A0")

    private lateinit var root: LinearLayout
    private var body: FrameLayout? = null
    private var currentId: String? = null
    private var fromLibrary = false
    private var mode = "preview"            // preview | code | edit
    private var wv: WebView? = null
    private var printAfterLoad = false
    private var busyDialog: AlertDialog? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        Touch.feedback(window.decorView, ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(0, dp(24), 0, 0) }
        setContentView(root)
        route(intent)
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        setIntent(i)
        route(i)
    }

    override fun onDestroy() {
        try { wv?.destroy() } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun route(i: Intent) {
        val id = i.getStringExtra("id")
        if (id != null && Artifacts.meta(this, id) != null) {
            fromLibrary = false
            showArtifact(id, i.getBooleanExtra("print", false))
        } else showLibrary()
    }

    override fun onBackPressed() {
        if (currentId != null && fromLibrary) showLibrary() else super.onBackPressed()
    }

    // ---------- small view helpers ----------

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }

    private fun chip(t: String, filled: Boolean = false, action: () -> Unit) = TextView(this).apply {
        text = t; textSize = 13f; gravity = Gravity.CENTER
        setTextColor(if (filled) BG else INK)
        background = GradientDrawable().apply { setColor(if (filled) ACCENT else SURFACE); cornerRadius = dp(10).toFloat() }
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { action() }
    }

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    private fun busy(msg: String) {
        busyDialog?.dismiss()
        busyDialog = AlertDialog.Builder(this).setMessage(msg).setCancelable(false).show()
    }

    private fun unbusy() { busyDialog?.dismiss(); busyDialog = null }

    private fun input(title: String, initial: String, ok: (String) -> Unit) {
        val et = EditText(this).apply { setText(initial); setSelection(text.length); inputType = InputType.TYPE_CLASS_TEXT }
        AlertDialog.Builder(this).setTitle(title).setView(et)
            .setPositiveButton("OK") { _, _ -> ok(et.text.toString()) }.setNegativeButton("Cancel", null).show()
    }

    // ---------- library ----------

    private fun showLibrary() {
        currentId = null; fromLibrary = false
        try { wv?.destroy() } catch (e: Exception) {}
        wv = null; body = null
        root.removeAllViews()
        val all = Artifacts.list(this)
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(16), dp(10), dp(12), dp(10)) }
        head.addView(label("🧩  Artifacts and docs", 20f, INK, true), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(chip("+ New", true) { newDialog() })
        root.addView(head)
        root.addView(label(all.size.toString() + " saved  ·  Anjoo se kaho: \"sales dashboard banao\", \"resume likho\", \"invitation page banao\"", 12f, MUTED).apply { setPadding(dp(16), 0, dp(16), dp(8)) })
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), 0, dp(12), dp(24)) }
        if (all.isEmpty()) {
            list.addView(label("Abhi koi artifact nahi.\n\nWeb page, dashboard, chhota app, slides, document ya report banwayein; yahan save hote hain, badal sakte hain, file ya Wi-Fi link se share kar sakte hain.", 14f, MUTED).apply { setPadding(dp(6), dp(20), dp(6), dp(6)) })
        }
        for (m in all) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
                background = GradientDrawable().apply { setColor(SURFACE); cornerRadius = dp(12).toFloat() }
                setOnClickListener { fromLibrary = true; showArtifact(m.id, false) }
                setOnLongClickListener { rowMenu(m); true }
            }
            row.addView(label(Artifacts.icon(m.kind) + "  " + m.title, 15.5f, INK, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END })
            row.addView(label(m.kind + "  ·  v" + m.version + "  ·  " + Artifacts.ago(m.updated), 12f, MUTED).apply { setPadding(0, dp(3), 0, 0) })
            list.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun rowMenu(m: Artifacts.Meta) {
        val opts = arrayOf("Open", "Share file (HTML)", "Wi-Fi link", "Rename", "Delete")
        AlertDialog.Builder(this).setTitle(m.title).setItems(opts) { _, w ->
            when (w) {
                0 -> { fromLibrary = true; showArtifact(m.id, false) }
                1 -> toast(Artifacts.shareFile(this, m, "html"))
                2 -> wifiLink(m)
                3 -> input("Rename", m.title) { Artifacts.rename(this, m, it); showLibrary() }
                else -> deleteAsk(m)
            }
        }.show()
    }

    private fun deleteAsk(m: Artifacts.Meta) {
        AlertDialog.Builder(this).setMessage("Delete \"" + m.title + "\" aur uski saari versions?")
            .setPositiveButton("Delete") { _, _ -> Artifacts.delete(this, m); showLibrary() }
            .setNegativeButton("Cancel", null).show()
    }

    private fun newDialog() {
        val kinds = Artifacts.KINDS
        val names = kinds.map { Artifacts.icon(it) + "  " + it }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val sp = Spinner(this).apply { adapter = ArrayAdapter(this@ArtifactActivity, android.R.layout.simple_spinner_dropdown_item, names) }
        val et = EditText(this).apply {
            hint = "Kya banana hai? (jaise: sales dashboard, resume, birthday invitation, quiz game)"
            minLines = 3; gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        box.addView(sp); box.addView(et)
        AlertDialog.Builder(this).setTitle("New artifact").setView(box)
            .setPositiveButton("Build") { _, _ ->
                val d = et.text.toString().trim()
                if (d.isEmpty()) return@setPositiveButton
                val kind = kinds[sp.selectedItemPosition]
                busy("Ban raha hai... (30 se 90 second lag sakte hain)")
                Thread {
                    val r = try { Artifacts.create(applicationContext, JSONObject().put("kind", kind).put("description", d)) }
                    catch (e: Exception) { "Nahi ban saka: " + (e.message ?: e.javaClass.simpleName) }
                    runOnUiThread {
                        unbusy()
                        if (!r.startsWith("Artifact ban gaya")) toast(r)
                    }
                }.start()
            }.setNegativeButton("Cancel", null).show()
    }

    // ---------- one artifact ----------

    private fun showArtifact(id: String, print: Boolean) {
        val m = Artifacts.meta(this, id) ?: run { showLibrary(); return }
        currentId = id; mode = "preview"; printAfterLoad = print
        try { wv?.destroy() } catch (e: Exception) {}
        wv = null
        root.removeAllViews()
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(6), dp(8), dp(6)) }
        bar.addView(label("←", 22f, INK).apply { setPadding(dp(10), 0, dp(10), 0); setOnClickListener { onBackPressed() } })
        bar.addView(label(Artifacts.icon(m.kind) + " " + m.title + "  v" + m.version, 14.5f, INK, true).apply { maxLines = 1; ellipsize = TextUtils.TruncateAt.END },
            LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(chip("Code") { toggleCode(m) }.apply { tag = "codeBtn" }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        bar.addView(chip("Edit") { startEdit(m) }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        bar.addView(chip("⋮") {}.also { c -> c.setOnClickListener { moreMenu(m, c) } })
        root.addView(bar)
        val b = FrameLayout(this)
        body = b
        root.addView(b, LinearLayout.LayoutParams(-1, 0, 1f))
        renderBody(m)
    }

    private fun toggleCode(m: Artifacts.Meta) {
        mode = if (mode == "code") "preview" else "code"
        renderBody(m)
    }

    private fun makeWebView(m: Artifacts.Meta): WebView {
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.allowFileAccess = false
        w.settings.allowContentAccess = false
        w.settings.setSupportZoom(true)
        w.settings.builtInZoomControls = true
        w.settings.displayZoomControls = false
        w.setBackgroundColor(Color.WHITE)
        w.webChromeClient = android.webkit.WebChromeClient()
        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return false
                if ((u.scheme == "http" || u.scheme == "https") && u.host != "artifact.local") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) {}
                    return true
                }
                return false
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                if (printAfterLoad) { printAfterLoad = false; view?.postDelayed({ doPrint(m) }, 400) }
            }
        }
        return w
    }

    private fun renderBody(m: Artifacts.Meta) {
        val b = body ?: return
        b.removeAllViews()
        try { wv?.destroy() } catch (e: Exception) {}
        wv = null
        val src = Artifacts.source(this, m)
        when (mode) {
            "code" -> {
                val tv = TextView(this).apply {
                    text = src; typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(Color.parseColor("#CFE8DD")); setTextIsSelectable(true)
                    setPadding(dp(12), dp(8), dp(12), dp(24))
                }
                b.addView(ScrollView(this).apply { addView(tv) }, FrameLayout.LayoutParams(-1, -1))
            }
            "edit" -> {
                val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                val et = EditText(this).apply {
                    setText(src); typeface = Typeface.MONOSPACE; textSize = 12f; setTextColor(Color.parseColor("#CFE8DD"))
                    gravity = Gravity.TOP; setBackgroundColor(Color.TRANSPARENT)
                    inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                }
                col.addView(ScrollView(this).apply { addView(et) }, LinearLayout.LayoutParams(-1, 0, 1f))
                val act = LinearLayout(this).apply { setPadding(dp(10), dp(8), dp(10), dp(10)); gravity = Gravity.END }
                act.addView(chip("Cancel") { mode = "preview"; renderBody(m) }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(8) })
                act.addView(chip("Save", true) {
                    Artifacts.write(this, m, et.text.toString())
                    toast("Save ho gaya (version " + m.version + ")")
                    showArtifact(m.id, false)
                })
                col.addView(act)
                b.addView(col, FrameLayout.LayoutParams(-1, -1))
            }
            else -> {
                val w = makeWebView(m)
                wv = w
                w.loadDataWithBaseURL("https://artifact.local/", Artifacts.pageHtml(m, src), "text/html", "UTF-8", null)
                b.addView(w, FrameLayout.LayoutParams(-1, -1))
            }
        }
        root.findViewWithTag<TextView>("codeBtn")?.text = if (mode == "code") "Preview" else "Code"
    }

    private fun startEdit(m: Artifacts.Meta) {
        if (Artifacts.source(this, m).length > 300_000) { toast("File bohat bari hai; Anjoo se kahein ke kya badalna hai."); return }
        mode = "edit"
        renderBody(m)
    }

    private fun doPrint(m: Artifacts.Meta) {
        val w = wv
        if (w == null || mode != "preview") { mode = "preview"; printAfterLoad = true; renderBody(m); return }
        try {
            val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
            val name = Artifacts.slug(m.title)
            pm.print(name, w.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
        } catch (e: Exception) { toast("Print nahi khul saka: " + (e.message ?: "")) }
    }

    private fun moreMenu(m: Artifacts.Meta, anchor: android.view.View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 1, 0, "📋  Copy source")
        pm.menu.add(0, 2, 1, "📤  Share file (HTML)")
        if (m.format == "md") pm.menu.add(0, 3, 2, "📤  Share as Word (.doc)")
        pm.menu.add(0, 4, 3, "📤  Share as text")
        pm.menu.add(0, 5, 4, if (ArtifactServer.isRunning()) "📶  Wi-Fi link (running)" else "📶  Wi-Fi link")
        pm.menu.add(0, 6, 5, "💾  Save to phone")
        pm.menu.add(0, 7, 6, "🖨  Print / Save as PDF")
        pm.menu.add(0, 8, 7, "🕘  Versions (" + m.version + ")")
        pm.menu.add(0, 9, 8, "✏️  Rename")
        pm.menu.add(0, 10, 9, "🗑  Delete")
        pm.setOnMenuItemClickListener { it2 ->
            when (it2.itemId) {
                1 -> {
                    (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Anjoo", Artifacts.source(this, m)))
                    toast("Copy ho gaya")
                }
                2 -> toast(Artifacts.shareFile(this, m, "html"))
                3 -> toast(Artifacts.shareFile(this, m, "doc"))
                4 -> toast(Artifacts.shareText(this, m))
                5 -> wifiLink(m)
                6 -> saveDialog(m)
                7 -> doPrint(m)
                8 -> versionsDialog(m)
                9 -> input("Rename", m.title) { Artifacts.rename(this, m, it); showArtifact(m.id, false) }
                10 -> deleteAsk(m)
            }
            true
        }
        pm.show()
    }

    private fun wifiLink(m: Artifacts.Meta) {
        AlertDialog.Builder(this).setTitle("Share on Wi-Fi?")
            .setMessage("Ek link banega jo isi Wi-Fi/hotspot par jude dusre phone ya laptop mein khulega. Sirf yeh artifact dikhega, 60 minute baad band ho jata hai. Link jis ke paas ho wo dekh sakta hai.")
            .setPositiveButton("Make link") { _, _ ->
                Thread {
                    val r = Artifacts.shareLink(applicationContext, m) { true }
                    runOnUiThread {
                        AlertDialog.Builder(this).setMessage(r).setPositiveButton("OK", null)
                            .setNeutralButton("Stop sharing") { _, _ -> ArtifactServer.stop(); toast("Link band kar diya") }.show()
                    }
                }.start()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun saveDialog(m: Artifacts.Meta) {
        val fmts = if (m.format == "md") listOf("html", "doc", "txt", "md") else listOf("html", "doc", "txt")
        val names = fmts.map { when (it) { "html" -> "HTML page (.html)"; "doc" -> "Word (.doc)"; "txt" -> "Plain text (.txt)"; else -> "Markdown (.md)" } }
        AlertDialog.Builder(this).setTitle("Save to phone").setItems(names.toTypedArray()) { _, w ->
            val f = fmts[w]
            Thread {
                val ex = try { Artifacts.export(applicationContext, m, f) } catch (e: Exception) { null }
                runOnUiThread {
                    if (ex == null) toast("Is format mein nahi ban saka.") else Dl.save(this, ex.first, ex.second)
                }
            }.start()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun versionsDialog(m: Artifacts.Meta) {
        val vs = Artifacts.versions(this, m)
        val items = vs.map { "v" + it.number + "  ·  " + Artifacts.ago(it.time) + (if (it.current) "  (abhi wala)" else "") }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Versions").setItems(items) { _, w ->
            val v = vs[w]
            val text = Artifacts.versionText(this, m, v.number) ?: run { toast("Yeh version nahi mila."); return@setItems }
            val pv = WebView(this).apply {
                settings.javaScriptEnabled = true
                setBackgroundColor(Color.WHITE)
                loadDataWithBaseURL("https://artifact.local/", Artifacts.pageHtml(m, text), "text/html", "UTF-8", null)
            }
            val holder = FrameLayout(this).apply { addView(pv, FrameLayout.LayoutParams(-1, dp(420))) }
            val bld = AlertDialog.Builder(this).setTitle("Version " + v.number).setView(holder).setNegativeButton("Close", null)
            if (!v.current) bld.setPositiveButton("Restore") { _, _ ->
                if (Artifacts.restore(this, m, v.number)) { toast("Version " + v.number + " wapas laga di (nayi version ban gayi)"); showArtifact(m.id, false) }
            }
            bld.show()
        }.setNegativeButton("Close", null).show()
    }
}
