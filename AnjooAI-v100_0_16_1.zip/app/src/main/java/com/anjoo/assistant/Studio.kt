package com.anjoo.assistant

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Builds web pages and code from a spoken idea, saves them, and shows them. */
object Studio {

    private fun dir(ctx: Context) = File(ctx.filesDir, "studio").also { it.mkdirs() }

    fun files(ctx: Context): List<File> = (dir(ctx).listFiles()?.toList() ?: emptyList()).sortedByDescending { it.lastModified() }

    private fun strip(s: String): String {
        var t = s.trim()
        if (t.startsWith("```")) t = t.substringAfter("\n")
        if (t.endsWith("```")) t = t.substringBeforeLast("```")
        return t.trim()
    }

    private fun ext(lang: String) = when (lang.lowercase()) {
        "python", "py" -> "py"
        "kotlin" -> "kt"
        "java" -> "java"
        "javascript", "js", "node" -> "js"
        "typescript", "ts" -> "ts"
        "c++", "cpp" -> "cpp"
        "c" -> "c"
        "c#", "csharp" -> "cs"
        "go" -> "go"
        "rust" -> "rs"
        "php" -> "php"
        "swift" -> "swift"
        "dart", "flutter" -> "dart"
        "sql" -> "sql"
        "bash", "shell" -> "sh"
        "html" -> "html"
        else -> "txt"
    }

    private fun make(ctx: Context, system: String, ask: String, name: String, ext: String): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        Providers.load(p)
        val key = p.getString("key", "") ?: ""
        if (key.isEmpty()) return "Pehle Settings mein API key dalein."
        val model = p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
        val out = strip(Gemini.plain(key, model, system, JSONArray().put(JSONObject().put("text", ask)), 12000))
        if (out.isBlank()) return "Kuch ban nahi saka, dobara koshish karein."
        val slug = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(24).ifEmpty { "project" }
        val f = File(dir(ctx), slug + "-" + (System.currentTimeMillis() / 1000) + "." + ext)
        f.writeText(out, Charsets.UTF_8)
        open(ctx, f)
        return "Bana diya aur screen par khol diya: " + f.name + " (" + out.length + " harf)."
    }

    fun page(ctx: Context, description: String): String = Coder.buildAndOpen(
        ctx,
        "Design and build a beautiful, modern, mobile-first, responsive web page or web app (index.html plus separate style.css and script.js if it is more than a simple page). Nice colour palette, spacing, typography, small animations, fully working interactions. Request: " + description,
        "HTML/CSS/JavaScript", false
    )

    fun code(ctx: Context, task: String, language: String): String = Coder.buildAndOpen(ctx, task, language, false)

    fun open(ctx: Context, f: File) {
        val i = Intent(ctx, PreviewActivity::class.java).putExtra("path", f.absolutePath).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}

/** Shows a generated page (live preview) or code, with copy and share. */
class PreviewActivity : Activity() {
    override fun attachBaseContext(base: android.content.Context) { super.attachBaseContext(TextScale.wrap(base)) }

    private var source = ""
    private var showingSource = false

    override fun dispatchTouchEvent(ev: android.view.MotionEvent): Boolean {
        Touch.feedback(window.decorView, ev)
        return super.dispatchTouchEvent(ev)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val f = File(intent.getStringExtra("path") ?: "")
        source = try { f.readText(Charsets.UTF_8) } catch (e: Exception) { "File nahi khuli." }
        val isHtml = f.name.endsWith(".html")
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#020B05")) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding((8 * d).toInt(), (6 * d).toInt(), (8 * d).toInt(), (6 * d).toInt()) }
        val title = TextView(this).apply { text = f.name; setTextColor(Color.parseColor("#00FF66")); typeface = Typeface.MONOSPACE; textSize = 12f }
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun showCode() {
            holder.removeAllViews()
            val tv = TextView(this).apply {
                text = source; typeface = Typeface.MONOSPACE; textSize = 12f
                setTextColor(Color.parseColor("#CFFFE0")); setTextIsSelectable(true)
                setPadding((10 * d).toInt(), (8 * d).toInt(), (10 * d).toInt(), (8 * d).toInt())
            }
            holder.addView(ScrollView(this).apply { addView(tv) }, LinearLayout.LayoutParams(-1, -1))
        }
        fun showPage() {
            holder.removeAllViews()
            val wv = WebView(this)
            wv.settings.javaScriptEnabled = true
            wv.setBackgroundColor(Color.WHITE)
            wv.loadDataWithBaseURL("https://preview.local/", source, "text/html", "UTF-8", null)
            holder.addView(wv, LinearLayout.LayoutParams(-1, -1))
        }
        fun btn(t: String, a: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; textSize = 12f; setTextColor(Color.parseColor("#00FF66"))
            setBackgroundColor(Color.parseColor("#071A0F")); minWidth = 0; minimumWidth = 0
            setPadding((10 * d).toInt(), 0, (10 * d).toInt(), 0)
            layoutParams = LinearLayout.LayoutParams(-2, (36 * d).toInt()).apply { leftMargin = (6 * d).toInt() }
            setOnClickListener { a() }
        }
        if (isHtml) bar.addView(btn("CODE") { showingSource = !showingSource; if (showingSource) showCode() else showPage() })
        bar.addView(btn("COPY") {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Anjoo", source))
            Toast.makeText(this, "Copy ho gaya", Toast.LENGTH_SHORT).show()
        })
        bar.addView(btn("SHARE") {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, source), "Share"))
        })
        root.addView(bar)
        root.addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (isHtml) showPage() else showCode()
    }
}
