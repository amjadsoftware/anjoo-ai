package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

/**
 * The task board (Kanban): To do / Doing / Done. Anjoo can add, move and list tasks by voice or chat,
 * scheduled agent runs write their result onto a card, and the board has its own screen (TasksActivity).
 * Stored in the "tasks" setting, so backups include it.
 */
object Tasks {
    val COLUMNS = listOf("todo", "doing", "done")
    val LABELS = mapOf("todo" to "To do", "doing" to "Doing", "done" to "Done")

    private fun p(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    @Synchronized
    fun all(ctx: Context): JSONArray = try { JSONArray(p(ctx).getString("tasks", "[]")) } catch (e: Exception) { JSONArray() }

    @Synchronized
    private fun save(ctx: Context, a: JSONArray) { p(ctx).edit().putString("tasks", a.toString()).apply() }

    private fun norm(status: String): String {
        val s = status.lowercase(Locale.ROOT).trim()
        return when {
            s.startsWith("do") && s.contains("ing") -> "doing"
            s in listOf("doing", "progress", "in progress", "in_progress", "chal raha", "started", "start") -> "doing"
            s in listOf("done", "complete", "completed", "finished", "ho gaya", "khatam") -> "done"
            else -> "todo"
        }
    }

    @Synchronized
    fun add(ctx: Context, title: String, note: String = "", status: String = "todo", due: String = ""): Int {
        val id = p(ctx).getInt("taskId", 0) + 1
        p(ctx).edit().putInt("taskId", id).apply()
        val a = all(ctx)
        a.put(JSONObject().put("id", id).put("title", title.trim().take(120)).put("note", note.trim().take(800))
            .put("status", norm(status)).put("due", due.trim().take(40)).put("at", System.currentTimeMillis()))
        save(ctx, a)
        return id
    }

    /** Adds a task that came from another phone (sync file). Skips it if the same task (title and time) is already here. */
    @Synchronized
    fun importOne(ctx: Context, o: JSONObject): Boolean {
        val title = o.optString("title").trim()
        if (title.isEmpty()) return false
        val at = o.optLong("at", 0L)
        val a = all(ctx)
        for (i in 0 until a.length()) {
            val x = a.getJSONObject(i)
            if (x.optString("title") == title && x.optLong("at", 0L) == at) return false
        }
        val id = p(ctx).getInt("taskId", 0) + 1
        p(ctx).edit().putInt("taskId", id).apply()
        a.put(JSONObject().put("id", id).put("title", title.take(120)).put("note", o.optString("note").take(800))
            .put("status", norm(o.optString("status", "todo"))).put("due", o.optString("due").take(40))
            .put("at", if (at > 0) at else System.currentTimeMillis()))
        save(ctx, a)
        return true
    }

    /** Finds a task by number ("3", "#3") or by words from its title. */
    @Synchronized
    fun find(ctx: Context, ref: String): JSONObject? {
        val a = all(ctx)
        val r = ref.trim().removePrefix("#")
        r.toIntOrNull()?.let { n -> for (i in 0 until a.length()) if (a.getJSONObject(i).optInt("id") == n) return a.getJSONObject(i) }
        val w = r.lowercase(Locale.ROOT)
        if (w.isEmpty()) return null
        var hit: JSONObject? = null
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optString("title").lowercase(Locale.ROOT).contains(w)) hit = o
        }
        return hit
    }

    @Synchronized
    fun update(ctx: Context, id: Int, f: (JSONObject) -> Unit): Boolean {
        val a = all(ctx)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optInt("id") == id) { f(o); save(ctx, a); return true }
        }
        return false
    }

    fun move(ctx: Context, id: Int, status: String) = update(ctx, id) { it.put("status", norm(status)) }

    fun setResult(ctx: Context, id: Int, text: String, done: Boolean = true) = update(ctx, id) { it.put("result", text.take(3000)).put("status", if (done) "done" else "todo") }

    @Synchronized
    fun delete(ctx: Context, id: Int): Boolean {
        val a = all(ctx)
        val keep = JSONArray()
        var found = false
        for (i in 0 until a.length()) { val o = a.getJSONObject(i); if (o.optInt("id") == id) found = true else keep.put(o) }
        if (found) {
            try {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    if (o.optInt("id") == id) { Trash.stash(ctx, "task", o.optString("title"), o); break }
                }
            } catch (e: Exception) { android.util.Log.w("Anjoo", "trash task failed", e) }
            save(ctx, keep)
        }
        return found
    }

    fun summary(ctx: Context, status: String = ""): String {
        val a = all(ctx)
        if (a.length() == 0) return "Task board khali hai."
        val want = if (status.isBlank() || status.lowercase(Locale.ROOT) == "all") "" else norm(status)
        val sb = StringBuilder()
        for (col in COLUMNS) {
            if (want.isNotEmpty() && col != want) continue
            val items = (0 until a.length()).map { a.getJSONObject(it) }.filter { it.optString("status") == col }
            sb.append(LABELS[col]).append(" (").append(items.size).append("):\n")
            for (o in items) {
                sb.append("  #").append(o.optInt("id")).append(" ").append(o.optString("title"))
                if (o.optString("due").isNotEmpty()) sb.append(" [due ").append(o.optString("due")).append("]")
                sb.append("\n")
            }
        }
        return sb.toString().trim()
    }

    // ---- tool entry points (called from MoreTools) ----

    fun toolAdd(ctx: Context, a: JSONObject): String {
        val id = add(ctx, a.getString("title"), a.optString("note", ""), a.optString("status", "todo"), a.optString("due", ""))
        return "Task #$id board par add ho gaya: " + a.getString("title")
    }

    fun toolMove(ctx: Context, a: JSONObject): String {
        val t = find(ctx, a.getString("task")) ?: return "Is naam ka task nahi mila. list_tasks se dekho."
        move(ctx, t.getInt("id"), a.getString("status"))
        return "Task #" + t.getInt("id") + " (" + t.optString("title") + ") ab " + Tasks.LABELS[norm(a.getString("status"))] + " mein hai."
    }

    fun toolDelete(ctx: Context, ref: String): String {
        val t = find(ctx, ref) ?: return "Is naam ka task nahi mila."
        delete(ctx, t.getInt("id"))
        return "Task #" + t.getInt("id") + " hata diya."
    }
}
