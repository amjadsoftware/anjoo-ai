plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.anjoo.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.anjoo.assistant"
        minSdk = 26
        targetSdk = 34
        versionCode = 59
        versionName = "77.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
