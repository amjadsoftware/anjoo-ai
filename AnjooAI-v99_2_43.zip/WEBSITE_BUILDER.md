# Website Builder (Anjoo AI v99.2.39)

Module: `WebsiteBuilder.kt`. Tool: `website_builder` (actions: start, continue, status, change, audit, seo, deploy, verify, export).
It reuses Code Studio (`Coder.build/revise`), `Runner.check` (WebView preview diagnostics), checkpoints, ZIP export and the chat project card. Nothing existing was replaced.

## Workflow (state saved in files/website_state/<project>.json, so `continue` resumes at the first unfinished stage)
Progress is saved as soon as the project folder exists, so a build interrupted by no internet or a closed app keeps its files; `continue` first finishes missing pages and cut-off files, then runs the remaining stages. Live progress ("Step N/10 ...") shows in the chat.
1. plan (AI JSON plan; a matching starter blueprint from SiteBlueprints.kt: cafe, portfolio, shop, business, clinic, event)
2. build (Code Studio, page by page: shared css/js first, then one HTML page per call; Premium Website Standard in the brief)
3. images (SiteImages.kt: every image becomes a local file; remote links replaced; designed SVG in the site colours, plus up to 2 AI hero pictures when a key-based picture maker is set up)
4. premium_review (slow AI pass; only runs when the quick interaction scan finds problems)
5. run_check (WebView preview diagnostics; blank-page and hidden-content detection; up to 2 fix rounds)
6. audit (static checks, one AI fix round)  7. visual_check (VisualCheck.kt: phone-width screenshots of up to 3 pages reviewed by Gemini; clear defects fixed once; skipped without a Gemini key or when screenshots are blank)
8. seo (sitemap.xml, robots.txt)  9. deploy_docs (DEPLOY.md, README.md, _headers, netlify.toml, vercel.json)  10. verify (final check + checkpoint)
Existing files are never overwritten by the seo/deploy stages. `change` makes a checkpoint first, shows the model only the pages you name (plus shared css/js), and re-runs only images, preview check, audit and verify (plus seo/deploy files when a file is added or removed).

## In the preview
Pencil: tap an element and change text, colours, font and size, then Save (text goes into the page HTML, styles into a page-scoped rule in edits.css).
Globe: one-tap publish to Netlify (token asked once; same site address on every republish). GitHub Pages is not included.

## Audit checks (static, run on-device)
viewport/title/description/lang, h1 count, img alt, form labels, target=_blank rel, http:// scripts/mixed content, eval/new Function, document.write,
innerHTML from variables, sensitive localStorage, API-key/secret patterns, @media, focus styles, dark theme, reduced motion.

## Premium review caveat
The interaction scan uses heuristics: passing it is not proof that every control works. The premium review asks the AI to inspect and edit every page and control, then the preview/runtime checks and static audit run afterward. Quality still depends on the configured model and the actual generated project; no automatic score is treated as proof of perfection.

## Limits (reported honestly in every result)
Static HTML/CSS/vanilla JS only. No npm/React/Next builds, no database/auth/payment servers, no unit/e2e tests, no dependency CVE scan, live deployment only to Netlify and only by tapping the globe in the preview, screenshots reviewed by Gemini (not a full cross-browser test).
Server-only features are listed under "needs_server" and are not faked. Configuration variables: none new (uses the existing API key setting).
