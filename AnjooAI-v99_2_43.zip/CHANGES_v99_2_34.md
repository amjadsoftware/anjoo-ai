# v99.2.34

Website Builder starter templates: SiteBlueprints.kt holds 6 blueprints (cafe/restaurant, portfolio, shop, business/agency, clinic, event/wedding) with pages, sections, design direction and working features. The best match for the request (English, Urdu or Hinglish keywords) is given to the planner and to the build brief; the request always wins, and with no match the planner decides alone.
