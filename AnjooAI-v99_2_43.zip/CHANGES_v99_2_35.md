# v99.2.35

Website Builder images: new "Images" stage (SiteImages.kt) after the build. Every image a page or stylesheet uses becomes a real local file: missing local images and remote links (which cannot load offline) are replaced by a designed SVG in the site palette, and up to 2 hero/banner images are made with the picture makers when a key-based engine is set up (ImageGen). Pages are rewritten to point at the new files. The build brief now requires local images/ paths with alt text.
