# v99.2.40

Search in menus: every menu with 8 or more rows (Settings, chat menu, voice menu and so on) now has a search box at the top that filters rows while typing, matching the title and the detail line; "Kuch nahi mila" when nothing matches. (menu() in MainActivity.kt)
