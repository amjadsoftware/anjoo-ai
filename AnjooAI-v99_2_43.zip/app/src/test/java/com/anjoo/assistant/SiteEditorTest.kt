package com.anjoo.assistant

import org.json.JSONArray
import org.json.JSONObject
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class SiteEditorTest {
    private fun project(html: String): File {
        val d = java.nio.file.Files.createTempDirectory("anjoo-editor").toFile()
        File(d, "index.html").writeText(html)
        return d
    }

    private fun save(page: String, vararg items: JSONObject) =
        JSONObject().put("page", page).put("items", JSONArray(items.toList())).toString()

    @Test fun textEditChangesOnlyTheChosenRepeatedText() {
        val d = project("<html><head></head><body><a>Order Now</a><a>Order Now</a></body></html>")
        val r = SiteEditor.apply(d, save("/index.html", JSONObject().put("sel", "body > a:nth-of-type(2)").put("old", "Order Now").put("text", "Book Table").put("idx", 1).put("style", JSONObject())))
        val html = File(d, "index.html").readText()
        assertTrue(r, r.startsWith("Saved"))
        assertTrue(html.contains("<a>Order Now</a><a>Book Table</a>"))
    }

    @Test fun textWithAmpersandIsFoundInEscapedForm() {
        val d = project("<html><head></head><body><h1>Tea &amp; Coffee</h1></body></html>")
        SiteEditor.apply(d, save("index.html", JSONObject().put("sel", "body > h1:nth-of-type(1)").put("old", "Tea & Coffee").put("text", "Chai").put("idx", 0).put("style", JSONObject())))
        assertTrue(File(d, "index.html").readText().contains("<h1>Chai</h1>"))
    }

    @Test fun styleEditGoesToPageScopedEditsCssAndIsLinked() {
        val d = project("<html><head></head><body><h1>Hi</h1></body></html>")
        val r = SiteEditor.apply(d, save("index.html", JSONObject().put("sel", "body > h1:nth-of-type(1)").put("style", JSONObject().put("color", "#ff0000").put("fontSize", "40px"))))
        val html = File(d, "index.html").readText()
        val css = File(d, "edits.css").readText()
        assertTrue(r, r.startsWith("Saved"))
        assertTrue(html.contains("href=\"edits.css\"") && html.contains("data-edit-page=\"index.html\""))
        assertTrue(css.contains("body[data-edit-page=\"index.html\"] > h1:nth-of-type(1)"))
        assertTrue(css.contains("color: #ff0000 !important") && css.contains("font-size: 40px !important"))
    }

    @Test fun savingTwiceMergesIntoTheSameRuleAndLinksOnce() {
        val d = project("<html><head></head><body><h1>Hi</h1></body></html>")
        val sel = "body > h1:nth-of-type(1)"
        SiteEditor.apply(d, save("index.html", JSONObject().put("sel", sel).put("style", JSONObject().put("color", "#111111"))))
        SiteEditor.apply(d, save("index.html", JSONObject().put("sel", sel).put("style", JSONObject().put("backgroundColor", "#222222"))))
        val css = File(d, "edits.css").readText()
        assertTrue(css.contains("color: #111111") && css.contains("background-color: #222222"))
        assertTrue(Regex("edits\\.css").findAll(File(d, "index.html").readText()).count() == 1)
    }

    @Test fun pathOutsideTheProjectIsRefused() {
        val d = project("<html><head></head><body></body></html>")
        val r = SiteEditor.apply(d, save("../../etc/passwd", JSONObject().put("sel", "body").put("style", JSONObject().put("color", "red"))))
        assertTrue(r, r.startsWith("ERR"))
        assertFalse(File(d, "edits.css").exists())
    }
}
