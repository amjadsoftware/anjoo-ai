package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SiteBlueprintsTest {
    @Test fun matchesHinglishCafeRequest() {
        assertEquals("cafe", SiteBlueprints.match("ek cafe ki 3-page website banao, dark theme ke saath")?.id)
    }

    @Test fun matchesOtherSiteTypes() {
        assertEquals("event", SiteBlueprints.match("Shaadi ka invitation website")?.id)
        assertEquals("shop", SiteBlueprints.match("online dukaan for clothing")?.id)
        assertEquals("clinic", SiteBlueprints.match("website for a dentist clinic")?.id)
        assertEquals("portfolio", SiteBlueprints.match("my designer portfolio")?.id)
    }

    @Test fun noMatchWhenNothingFits() {
        assertNull(SiteBlueprints.match("quantum chemistry lecture notes"))
    }

    @Test fun promptListsPagesFeaturesAndSaysRequestWins() {
        val p = SiteBlueprints.match("coffee shop")?.prompt()
        assertNotNull(p)
        assertTrue(p!!.contains("menu.html"))
        assertTrue(p.contains("the request always wins"))
    }

    @Test fun everyBlueprintHasPagesSectionsAndFeatures() {
        for (b in SiteBlueprints.ALL) {
            assertTrue(b.id, b.pages.size >= 3 && b.sections.isNotEmpty() && b.features.isNotEmpty() && b.keywords.isNotEmpty())
        }
    }
}
