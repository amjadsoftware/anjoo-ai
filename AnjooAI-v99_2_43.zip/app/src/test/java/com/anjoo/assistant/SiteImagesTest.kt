package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SiteImagesTest {
    private val pal = listOf("#112233", "#aa5500", "#ffeecc", "#006655")

    @Test fun svgIsWellFormedAndUsesTheRightSize() {
        val s = SiteImages.svgArt("hero", 1600, 900, pal)
        assertTrue(s.startsWith("<svg"))
        assertTrue(s.endsWith("</svg>"))
        assertTrue(s.contains("viewBox=\"0 0 1600 900\""))
        assertTrue(s.contains("role=\"img\""))
        assertTrue(s.contains("#112233") && s.contains("#aa5500"))
    }

    @Test fun sameNameGivesSameArtAndDifferentNamesDiffer() {
        assertEquals(SiteImages.svgArt("team-1", 600, 600, pal), SiteImages.svgArt("team-1", 600, 600, pal))
        assertNotEquals(SiteImages.svgArt("team-1", 600, 600, pal), SiteImages.svgArt("team-2", 600, 600, pal))
    }

    @Test fun labelComesFromTheFileName() {
        assertTrue(SiteImages.svgArt("Our Menu_photo", 1000, 700, pal).contains("aria-label=\"our menu photo\""))
    }
}
