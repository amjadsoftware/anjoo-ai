package com.anjoo.assistant

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WebsiteBuilderStageTest {
    @Test fun previewStageRequiresAnActualCleanPreviewResult() {
        assertTrue(WebsiteBuilder.stagePassed("run_check", "Preview chali: koi console error ya missing file nahi mili."))
        assertFalse(WebsiteBuilder.stagePassed("run_check", "Fix ke baad bhi ye masail baqi hain:\n- JS error"))
        assertFalse(WebsiteBuilder.stagePassed("run_check", "Preview inspection timed out."))
        assertFalse(WebsiteBuilder.stagePassed("run_check", ""))
    }

    @Test fun auditBlocksRemainingHighAndMediumFindingsButAllowsLowFindings() {
        assertTrue(WebsiteBuilder.stagePassed("audit", "Audit baad: 0 high, 0 medium, 3 low."))
        assertFalse(WebsiteBuilder.stagePassed("audit", "Audit baad: 1 high, 0 medium, 0 low."))
        assertFalse(WebsiteBuilder.stagePassed("audit", "Audit baad: 0 high, 2 medium, 1 low."))
    }

    @Test fun verificationRequiresEntryPageAndCleanPreview() {
        assertTrue(WebsiteBuilder.stagePassed("verify", "Entry page: index.html, 12 files.\nFinal preview check saaf."))
        assertFalse(WebsiteBuilder.stagePassed("verify", "Koi HTML entry page nahi mili."))
        assertFalse(WebsiteBuilder.stagePassed("verify", "Entry page: index.html, 12 files.\nFinal preview check mein masail: HTTP 404"))
    }

    @Test fun premiumReviewDoesNotPassWhenReviewerFailsOrInteractionFindingsRemain() {
        assertTrue(WebsiteBuilder.stagePassed("premium_review", "Premium review completed. Interaction scan: no simple placeholder/dead-link patterns detected."))
        assertFalse(WebsiteBuilder.stagePassed("premium_review", "Premium review blocked: AI review ka valid result nahi mila."))
        assertFalse(WebsiteBuilder.stagePassed("premium_review", "Premium review completed. Interaction scan still needs review: broken link."))
    }

    @Test fun visualCheckNeverBlocksEvenWhenItReportsDefects() {
        assertTrue(WebsiteBuilder.stagePassed("visual_check", "Visual check: 2 kharabi mili aur theek karne ki koshish ki:\n- index.html: image failed to load -> use local file"))
        assertTrue(WebsiteBuilder.stagePassed("visual_check", "Visual check skipped: Google Gemini key chahiye."))
        assertFalse(WebsiteBuilder.stagePassed("visual_check", ""))
    }

    @Test fun imagesStagePassesWhenFilesAreReady() {
        assertTrue(WebsiteBuilder.stagePassed("images", "Images tayyar: 3 file(s) bani (AI picture: 0, designed SVG: 3)."))
        assertFalse(WebsiteBuilder.stagePassed("images", "Images: error: disk full"))
    }
}
