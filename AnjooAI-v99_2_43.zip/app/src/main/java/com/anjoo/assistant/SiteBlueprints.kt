package com.anjoo.assistant

import java.util.Locale

/**
 * Starter blueprints for common website types. A blueprint is not fixed HTML: it is a proven starting structure
 * (pages, sections, design direction, working features) that is given to the planner and the builder, so the
 * plan is faster and the result is more complete. The request always wins over the blueprint.
 */
object SiteBlueprints {

    data class Blueprint(
        val id: String,
        val label: String,
        val keywords: List<String>,
        val pages: List<String>,
        val sections: List<String>,
        val design: String,
        val features: List<String>
    ) {
        fun prompt(): String =
            "STARTER BLUEPRINT (" + label + "): use it as a starting point and adapt it to the exact request; the request always wins.\n" +
                "Pages: " + pages.joinToString(", ") + "\n" +
                "Key sections: " + sections.joinToString("; ") + "\n" +
                "Design direction: " + design + "\n" +
                "Working client-side features: " + features.joinToString("; ") + "\n"
    }

    val ALL: List<Blueprint> = listOf(
        Blueprint(
            "cafe", "Cafe / restaurant",
            listOf("cafe", "coffee", "restaurant", "bakery", "dhaba", "khana", "hotel", "chai", "bistro", "dining"),
            listOf("index.html (Home)", "menu.html (Menu)", "about.html (Story)", "contact.html (Reservation and contact)"),
            listOf("hero with signature dish or drink and a Reserve button", "featured items", "full menu with category tabs and prices", "story and team", "opening hours and map area", "testimonials", "reservation form"),
            "warm, appetising palette with one accent colour; large food-focused hero; serif display heading with a clean sans body; generous whitespace",
            listOf("menu category filter", "reservation form with validation saved locally", "opening-hours open/closed badge", "mobile menu", "dark/light theme toggle")
        ),
        Blueprint(
            "portfolio", "Portfolio / personal",
            listOf("portfolio", "freelancer", "designer", "developer", "photographer", "resume", "cv", "personal website", "artist"),
            listOf("index.html (Intro and highlights)", "work.html (Projects)", "about.html (About and skills)", "contact.html (Contact)"),
            listOf("strong intro statement", "project grid with filters", "case-study detail blocks", "skills and tools", "experience timeline", "contact form"),
            "confident minimal layout, one bold accent, big typography, subtle motion; let the work images lead",
            listOf("project filter by category", "contact form with validation", "downloadable CV link only if a file exists", "theme toggle", "smooth anchor navigation")
        ),
        Blueprint(
            "shop", "Online shop / products",
            listOf("shop", "store", "dukaan", "ecommerce", "e-commerce", "products", "boutique", "mart", "clothing", "sell"),
            listOf("index.html (Home)", "products.html (Catalogue)", "cart.html (Cart)", "contact.html (Contact and delivery info)"),
            listOf("hero with offer", "category tiles", "product grid with price and Add to cart", "product details", "cart summary", "delivery and returns info", "reviews"),
            "clean retail look, product photography first, clear price and button hierarchy, trust badges",
            listOf("search and category filter", "working cart saved locally with quantity and total", "order request form (no fake payment)", "wishlist saved locally", "empty and sold-out states")
        ),
        Blueprint(
            "business", "Business / agency / company",
            listOf("business", "company", "agency", "startup", "services", "consulting", "firm", "corporate", "b2b"),
            listOf("index.html (Home)", "services.html (Services)", "about.html (About and team)", "contact.html (Contact and quote request)"),
            listOf("clear value proposition and primary call to action", "services overview", "process steps", "proof: numbers, logos, testimonials", "team", "FAQ", "quote request form"),
            "trustworthy and modern; restrained palette with one strong brand colour; clear hierarchy; grid-aligned sections",
            listOf("FAQ accordion", "quote request form with validation saved locally", "services tabs", "mobile menu", "theme toggle")
        ),
        Blueprint(
            "clinic", "Clinic / doctor / health",
            listOf("clinic", "doctor", "hospital", "dentist", "medical", "health", "pharmacy", "dispensary"),
            listOf("index.html (Home)", "services.html (Treatments)", "doctors.html (Doctors)", "appointment.html (Book appointment)"),
            listOf("reassuring hero with Book appointment button", "treatments list", "doctor profiles", "opening hours and emergency contact", "patient FAQ", "appointment form"),
            "calm, clean and trustworthy; soft blues or greens; large readable text; high contrast; no medical claims that cannot be verified",
            listOf("appointment form with date and time validation saved locally", "FAQ accordion", "click-to-call link", "mobile menu")
        ),
        Blueprint(
            "event", "Event / wedding / invitation",
            listOf("wedding", "event", "shaadi", "invitation", "birthday", "conference", "party", "walima"),
            listOf("index.html (Invitation and countdown)", "schedule.html (Programme)", "venue.html (Venue and travel)", "rsvp.html (RSVP)"),
            listOf("striking hero with names or event title and date", "countdown", "programme timeline", "venue and directions", "RSVP form", "gallery"),
            "elegant, emotional, typography-led; limited palette; subtle animation that never hides content",
            listOf("live countdown to the date", "RSVP form with validation saved locally", "gallery lightbox", "add-to-calendar link", "mobile menu")
        )
    )

    /** Best matching blueprint for a request, or null when nothing fits (the planner then decides alone). */
    fun match(request: String): Blueprint? {
        val r = request.lowercase(Locale.ROOT)
        var best: Blueprint? = null
        var bestScore = 0
        for (b in ALL) {
            val score = b.keywords.count { r.contains(it) }
            if (score > bestScore) { best = b; bestScore = score }
        }
        return best
    }
}
