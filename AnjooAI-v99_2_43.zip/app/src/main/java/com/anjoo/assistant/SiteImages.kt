package com.anjoo.assistant

import android.content.Context
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.Random

/**
 * Makes sure a built website never has empty image boxes or remote image links (which cannot load offline in the WebView).
 * Every image a page uses becomes a real local file: an AI picture for the first hero images when a picture maker with a key
 * is set up, otherwise a designed SVG in the site's own colours.
 */
object SiteImages {

    private val RASTER = setOf("png", "jpg", "jpeg", "webp", "gif")
    private val IMG_TAG = Regex("(?is)<img\\b[^>]*?\\bsrc\\s*=\\s*([\"'])(.*?)\\1")
    private val CSS_URL = Regex("(?is)url\\(\\s*[\"']?([^\"')]+)[\"']?\\s*\\)")

    private fun hasKeyedEngine(ctx: Context): Boolean = try {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        Providers.load(p)
        listOf("openai", "xai", "openrouter", "nvidia", "huggingface", "cloudflare", "fal", "pollinations").any { Providers.allKeys(p, it).isNotEmpty() } ||
            Providers.geminiKey(p).isNotEmpty()
    } catch (_: Exception) { false }

    private fun isImageRef(ref: String, fromImgTag: Boolean): Boolean {
        val r = ref.trim()
        if (r.isEmpty() || r.startsWith("data:") || r.startsWith("#") || r.startsWith("blob:")) return false
        val ext = r.substringBefore('?').substringBefore('#').substringAfterLast('.', "").lowercase(Locale.ROOT)
        if (ext in RASTER || ext == "svg") return true
        // A remote image link without a known extension (photo CDNs) inside an <img> tag.
        return fromImgTag && (r.startsWith("http", true) || r.startsWith("//"))
    }

    private fun isRemote(ref: String) = ref.startsWith("http", true) || ref.startsWith("//")

    private fun slug(s: String): String {
        val t = s.lowercase(Locale.ROOT).replace(Regex("[^a-z0-9]+"), "-").trim('-')
        return t.take(30).ifEmpty { "image" }
    }

    private fun sizeFor(name: String): Pair<Int, Int> {
        val n = name.lowercase(Locale.ROOT)
        return when {
            Regex("hero|banner|cover|bg|background|header").containsMatchIn(n) -> 1600 to 900
            Regex("avatar|team|profile|person|logo|icon|portrait").containsMatchIn(n) -> 600 to 600
            else -> 1000 to 700
        }
    }

    private fun palette(plan: JSONObject?): List<String> {
        val arr = plan?.optJSONObject("design")?.optJSONArray("palette")
        val out = ArrayList<String>()
        if (arr != null) for (i in 0 until arr.length()) {
            val c = arr.optString(i).trim()
            if (Regex("^#[0-9a-fA-F]{6}$").matches(c)) out.add(c)
        }
        val base = listOf("#1f2937", "#d97706", "#fde68a", "#0f766e")
        return (out + base).take(4)
    }

    /** A designed, offline SVG picture in the site's colours; the name seeds the composition so images differ. */
    fun svgArt(name: String, w: Int, h: Int, pal: List<String>): String {
        val rnd = Random(name.hashCode().toLong())
        val c1 = pal[0]; val c2 = pal.getOrElse(1) { pal[0] }; val c3 = pal.getOrElse(2) { c2 }; val c4 = pal.getOrElse(3) { c1 }
        val sb = StringBuilder()
        sb.append("<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 ").append(w).append(' ').append(h)
            .append("\" width=\"").append(w).append("\" height=\"").append(h).append("\" role=\"img\" aria-label=\"").append(slug(name).replace('-', ' ')).append("\">")
        val ang = rnd.nextInt(4)
        val x2 = if (ang % 2 == 0) "100%" else "0%"
        val y2 = if (ang < 2) "100%" else "0%"
        sb.append("<defs><linearGradient id=\"g\" x1=\"0%\" y1=\"0%\" x2=\"").append(x2).append("\" y2=\"").append(y2).append("\">")
            .append("<stop offset=\"0%\" stop-color=\"").append(c1).append("\"/><stop offset=\"100%\" stop-color=\"").append(c2).append("\"/></linearGradient></defs>")
        sb.append("<rect width=\"").append(w).append("\" height=\"").append(h).append("\" fill=\"url(#g)\"/>")
        val m = minOf(w, h)
        val cols = listOf(c3, c4, c3, "#ffffff")
        for (i in 0 until 5) {
            val r = (m * (0.12 + rnd.nextDouble() * 0.30)).toInt()
            val cx = (rnd.nextDouble() * w).toInt()
            val cy = (rnd.nextDouble() * h).toInt()
            val op = String.format(Locale.US, "%.2f", 0.10 + rnd.nextDouble() * 0.22)
            sb.append("<circle cx=\"").append(cx).append("\" cy=\"").append(cy).append("\" r=\"").append(r)
                .append("\" fill=\"").append(cols[i % cols.size]).append("\" fill-opacity=\"").append(op).append("\"/>")
        }
        val y0 = (h * (0.62 + rnd.nextDouble() * 0.15)).toInt()
        sb.append("<path d=\"M0 ").append(y0).append(" C ").append(w / 4).append(' ').append(y0 - h / 6).append(", ").append(w / 2).append(' ').append(y0 + h / 8)
            .append(", ").append(w).append(' ').append(y0 - h / 10).append(" L ").append(w).append(' ').append(h).append(" L 0 ").append(h)
            .append(" Z\" fill=\"").append(c4).append("\" fill-opacity=\"0.28\"/>")
        sb.append("</svg>")
        return sb.toString()
    }

    private fun relPrefix(fileRel: String): String {
        val depth = fileRel.replace('\\', '/').count { it == '/' }
        return "../".repeat(depth)
    }

    private fun resolve(fileRel: String, ref: String): String {
        val clean = ref.substringBefore('?').substringBefore('#')
        if (clean.startsWith("/")) return clean.trimStart('/')
        val base = fileRel.replace('\\', '/').substringBeforeLast('/', "")
        val parts = ArrayList<String>()
        if (base.isNotEmpty()) parts.addAll(base.split('/'))
        for (seg in clean.split('/')) {
            if (seg.isEmpty() || seg == ".") continue
            if (seg == "..") {
                if (parts.isNotEmpty()) parts.removeAt(parts.size - 1)
            } else {
                parts.add(seg)
            }
        }
        return parts.joinToString("/")
    }

    fun process(ctx: Context, dir: File, plan: JSONObject?, say: (String) -> Unit): String {
        val files = Coder.readFiles(dir).filterKeys { val l = it.lowercase(Locale.ROOT); (l.endsWith(".html") || l.endsWith(".htm") || l.endsWith(".css")) && !l.startsWith("docs/") }
        if (files.isEmpty()) return "Images: koi HTML/CSS file nahi mili."
        val pal = palette(plan)
        val summary = plan?.optString("summary", "") ?: ""
        val aiOk = hasKeyedEngine(ctx)
        var aiBudget = if (aiOk) 2 else 0
        var aiMade = 0; var svgMade = 0; var remoteFixed = 0; var already = 0
        val edited = HashMap<String, String>()
        for ((rel, text0) in files) {
            var text = text0
            val isCss = rel.lowercase(Locale.ROOT).endsWith(".css")
            val refs = ArrayList<Pair<String, Boolean>>()
            if (!isCss) IMG_TAG.findAll(text).forEach { refs.add(it.groupValues[2] to true) }
            CSS_URL.findAll(text).forEach { refs.add(it.groupValues[1] to false) }
            for ((ref, fromTag) in refs.distinct()) {
                if (!isImageRef(ref, fromTag)) continue
                val prefix = relPrefix(rel)
                if (isRemote(ref)) {
                    val nm = slug(ref.substringBefore('?').substringAfterLast('/').substringBeforeLast('.')) + "-" + (Math.abs(ref.hashCode()) % 1000)
                    val target = "images/$nm.svg"
                    val (w, h) = sizeFor(nm)
                    val out = File(dir, target); out.parentFile?.mkdirs()
                    if (!out.exists()) out.writeText(svgArt(nm, w, h, pal), Charsets.UTF_8)
                    text = text.replace(ref, prefix + target)
                    remoteFixed++; svgMade++
                    continue
                }
                val resolved = resolve(rel, ref)
                if (File(dir, resolved).isFile) { already++; continue }
                val ext = resolved.substringAfterLast('.', "").lowercase(Locale.ROOT)
                val nm = resolved.substringAfterLast('/').substringBeforeLast('.')
                val (w, h) = sizeFor(nm)
                val wantsAi = aiBudget > 0 && ext in RASTER && Regex("hero|banner|cover|header|main").containsMatchIn(nm.lowercase(Locale.ROOT))
                var done = false
                if (wantsAi) {
                    aiBudget--
                    say("Images · AI picture bana raha hoon: " + nm)
                    try {
                        val prompt = "Professional website photo: " + nm.replace('-', ' ').replace('_', ' ') + (if (summary.isNotBlank()) ", for " + summary.take(110) else "") +
                            ", natural light, high quality, wide composition, no text, no logos, no watermark"
                        val saved = ImageGen.make(ctx, prompt, false, "16:9")
                        val src = ImageGen.file(ctx, saved)
                        if (src.isFile && src.length() > 2000) {
                            val newExt = src.extension.lowercase(Locale.ROOT).ifEmpty { "png" }
                            val dest = resolved.substringBeforeLast('.') + "." + newExt
                            val out = File(dir, dest); out.parentFile?.mkdirs()
                            src.copyTo(out, overwrite = true)
                            if (newExt != ext) text = text.replace(ref, ref.substringBeforeLast('.') + "." + newExt)
                            aiMade++; done = true
                        }
                    } catch (e: CancelledException) { throw e } catch (_: Exception) { }
                }
                if (!done) {
                    if (ext == "svg") {
                        val out = File(dir, resolved); out.parentFile?.mkdirs()
                        out.writeText(svgArt(nm, w, h, pal), Charsets.UTF_8)
                    } else {
                        val dest = resolved.substringBeforeLast('.') + ".svg"
                        val out = File(dir, dest); out.parentFile?.mkdirs()
                        if (!out.exists()) out.writeText(svgArt(nm, w, h, pal), Charsets.UTF_8)
                        text = text.replace(ref, ref.substringBeforeLast('.') + ".svg")
                    }
                    svgMade++
                }
            }
            if (text != text0) edited[rel] = text
        }
        for ((rel, t) in edited) File(dir, rel).writeText(t, Charsets.UTF_8)
        val total = aiMade + svgMade
        return if (total == 0) "Images: har image ka asli local file maujood hai ($already ref), koi khali ya remote image nahi."
        else "Images tayyar: $total file(s) bani (AI picture: $aiMade, designed SVG: $svgMade" + (if (remoteFixed > 0) ", remote link badle: $remoteFixed" else "") + ")."
    }
}
