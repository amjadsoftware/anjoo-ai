package com.anjoo.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceError
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
import java.util.Collections
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Runs a website in an isolated, invisible WebView and reports runtime/resource/layout failures.
 * It deliberately does not click arbitrary controls: doing so could submit forms, delete data,
 * send messages or trigger other side effects. Interaction completeness is checked separately.
 */
object Runner {

    fun entry(dir: File): String? = PreviewServer.entry(dir)

    private fun jsString(raw: String?): String = try {
        val value = org.json.JSONTokener(raw ?: "null").nextValue()
        value?.toString() ?: ""
    } catch (_: Exception) { raw ?: "" }

    /** Returns an empty string only when the preview loaded and both viewport checks passed. */
    fun check(ctx: Context, dir: File, waitMs: Long = 3500): String {
        val page = entry(dir) ?: return PyRun.check(ctx, dir).ifBlank { "No HTML entry page was found; preview could not be run." }
        val found = StringBuilder()
        val missing = Collections.synchronizedSet(LinkedHashSet<String>())
        val done = CountDownLatch(1)
        val main = Handler(Looper.getMainLooper())
        val density = ctx.resources.displayMetrics.density.coerceAtLeast(1f)
        var wv: WebView? = null
        var loaded = false
        var finished = false

        fun addIssue(message: String) {
            if (message.isBlank() || found.length >= 3200) return
            if (found.isNotEmpty()) found.append('\n')
            found.append("- ").append(message.take(700))
        }

        main.post {
            try {
                val w = WebView(ctx.applicationContext)
                wv = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.setSupportMultipleWindows(false)
                w.layout(0, 0, (390 * density).toInt(), (844 * density).toInt())
                w.webChromeClient = object : WebChromeClient() {
                    override fun onConsoleMessage(m: ConsoleMessage?): Boolean {
                        if (m != null && m.messageLevel() == ConsoleMessage.MessageLevel.ERROR)
                            addIssue("JavaScript console error: ${m.message()} (${m.sourceId()?.substringAfterLast('/')}:${m.lineNumber()})")
                        return true
                    }
                }
                w.webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val u = request?.url ?: return null
                        return PreviewServer.serve(dir, u) { missing.add(it) }
                    }

                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        if (request?.isForMainFrame == true) {
                            addIssue("Main page load failed: ${error?.description ?: "unknown network error"} (code ${error?.errorCode ?: -1})")
                            finished = true
                            done.countDown()
                        }
                    }

                    override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                        if (request?.isForMainFrame == true) {
                            val code = errorResponse?.statusCode ?: -1
                            if (code >= 400) addIssue("Main page returned HTTP $code")
                        }
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        if (finished) return
                        loaded = true
                        // Give deferred scripts and styles a short opportunity to settle.
                        main.postDelayed({
                            val target = view ?: run { finished = true; done.countDown(); return@postDelayed }
                            val inspect = "(function(){var d=document.documentElement,b=document.body;" +
                                "var text=(b?(b.innerText||'').trim():'');" +
                                "var els=document.querySelectorAll('h1,h2,h3,p,img'),n=0,h=0;" +
                                "for(var i=0;i<els.length&&i<250;i++){var hid=false;for(var x=els[i];x&&x!==d;x=x.parentElement){var s=getComputedStyle(x);if(parseFloat(s.opacity)<0.05||s.visibility==='hidden'){hid=true;break;}}n++;if(hid)h++;}" +
                                "return JSON.stringify({title:document.title||'',blank:!b||(!text&&b.children.length===0)," +
                                "overflow:!!d&&d.scrollWidth>window.innerWidth+2,total:n,hidden:h,width:window.innerWidth,body:b?b.children.length:0});})()"
                            target.evaluateJavascript(inspect) { mobileRaw ->
                                val mobile = try { org.json.JSONObject(jsString(mobileRaw)) } catch (_: Exception) { null }
                                if (mobile == null) addIssue("Could not inspect the rendered page (JavaScript result unavailable).")
                                else {
                                    if (mobile.optBoolean("blank")) addIssue("The page is blank: no meaningful visible content was rendered.")
                                    if (mobile.optInt("total") >= 3 && mobile.optInt("hidden") * 10 >= mobile.optInt("total") * 7)
                                        addIssue("The page looks blank: ${mobile.optInt("hidden")} of ${mobile.optInt("total")} headings, paragraphs and images are invisible (opacity 0 or hidden). Content must be visible by default; scroll-reveal may only hide an element after a script adds a class to <html>, and must reveal everything after 1.5 seconds even if the script fails.")
                                    if (mobile.optBoolean("overflow")) addIssue("Horizontal overflow detected at phone viewport (${mobile.optInt("width")} CSS px).")
                                }
                                // Repeat the layout check at a desktop-like width without interacting with controls.
                                target.layout(0, 0, (1024 * density).toInt(), (768 * density).toInt())
                                target.evaluateJavascript(inspect) { desktopRaw ->
                                    val desktop = try { org.json.JSONObject(jsString(desktopRaw)) } catch (_: Exception) { null }
                                    if (desktop == null) addIssue("Could not inspect the desktop viewport.")
                                    else if (desktop.optBoolean("overflow")) addIssue("Horizontal overflow detected at wide viewport (${desktop.optInt("width")} CSS px).")
                                    finished = true
                                    done.countDown()
                                }
                            }
                        }, waitMs.coerceIn(250, 5000))
                    }
                }
                w.loadUrl(PreviewServer.origin(dir) + page)
            } catch (e: Exception) {
                addIssue("Preview could not start: ${e.message ?: e.javaClass.simpleName}")
                finished = true
                done.countDown()
            }
        }

        val completed = try { done.await(waitMs + 14000, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) { Thread.currentThread().interrupt(); false }
        if (!completed) addIssue(if (loaded) "Preview inspection timed out before all checks completed." else "Preview page did not finish loading before the timeout.")
        main.post { try { wv?.stopLoading(); wv?.destroy() } catch (_: Exception) {} }
        val missingSnapshot = synchronized(missing) { missing.toList() }
        for (m in missingSnapshot) if (!m.endsWith("favicon.ico") && m.isNotEmpty()) addIssue("Local file was not found: $m")
        return found.toString().trim()
    }
}
