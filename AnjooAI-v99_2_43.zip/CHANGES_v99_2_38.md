# v99.2.38

Website Builder visual check: new "visual_check" stage (VisualCheck.kt) after the audit. Up to 3 pages are rendered at phone width, screenshots (up to 3 screens each) are reviewed by Gemini, and only clear defects (overlapping or cut-off text, unreadable contrast, empty image boxes, sideways overflow, broken layout) are fixed once with small edits. If screenshots or a Gemini key are not available it is skipped with a message and never blocks the build.
