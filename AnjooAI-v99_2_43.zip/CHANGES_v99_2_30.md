# v99.2.30

Website Builder live progress: the running Website Builder step in the chat now shows what is happening right now (Step N/8, plan, build sub-steps from the code team, review, preview check, audit, SEO, verify) via WebsiteBuilder.onProgress, so there is no long silent wait.
