# v99.2.37

One-tap publish to Netlify from the project preview (globe button). SitePublisher.kt sends the project as one ZIP: the first publish creates a site, later publishes update the same site (same web address). The Netlify token is asked once and kept only on the phone. GitHub Pages is not included.
