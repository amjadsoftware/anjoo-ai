# v99.2.28

Website builder: (1) blank-page fix: standard now forbids content hidden by default (scroll-reveal fallback), and Runner.check detects pages whose headings/paragraphs/images are mostly invisible (opacity 0/hidden) so the auto-fix round repairs them; (2) speed: the slow AI premium review pass runs only when the quick scan finds problems; review prompt no longer repeats the standard.
