# Signing (v99.2.26 and newer)

Every build (debug from GitHub Actions and release) is signed with the same fixed key, `app/anjoo.keystore`
(alias `anjoo`). That is why a new APK installs over the old app: Android only accepts an update signed with the same key.
Do not delete or replace this file, or updates fail with INSTALL_FAILED_UPDATE_INCOMPATIBLE.

Security note: the key and its passwords are inside the project (fine for a private repository, not for a public one).
Anyone who has this ZIP can sign an APK that installs over your app. Keep the repository private and never share the ZIP publicly.

To use a separate private release key, set `ANJOO_STORE_FILE`, `ANJOO_STORE_PASSWORD`, `ANJOO_KEY_ALIAS`, `ANJOO_KEY_PASSWORD`
in the environment or in the untracked `local.properties`; release builds then use it. Moving to a new key later means
uninstalling once (export your keys and chats first).
