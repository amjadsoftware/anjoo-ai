# v99.2.41

Delete confirmation and button size: the AI tools delete_note and delete_task now ask for confirmation like delete_file and delete_project (chat, note, task, artifact, project and file deletes in the screens already asked). Project preview toolbar buttons are now at least 44 x 48 dp.
