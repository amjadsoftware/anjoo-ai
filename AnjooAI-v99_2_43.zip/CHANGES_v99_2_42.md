# v99.2.42

Tests: new unit tests for the Website Builder work (SiteBlueprintsTest, SiteImagesTest, SiteEditorTest with temp folders, and stage tests for images and visual_check). The visual_check stage can no longer block a build because of words in the vision model's text. Correction: the project already had 17 test files; v99.2.39 wrongly said none existed.
