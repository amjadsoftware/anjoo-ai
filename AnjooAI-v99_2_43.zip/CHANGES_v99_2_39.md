# v99.2.39

Full check of the project (no code behaviour changed): bracket balance of every Kotlin file compared with v99.2.25, all symbols used by the new Website Builder code checked to exist, docs brought up to date (WEBSITE_BUILDER.md now describes all 10 stages, editor and publish; SIGNING.md replaces the outdated SIGNING_v99_2_25.md).
