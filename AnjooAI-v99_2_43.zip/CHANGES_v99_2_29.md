# v99.2.29

Website Builder: the project card (Preview, files, ZIP download) is now always attached to the reply that ran the builder, using a saved last-built folder as a fallback (WebsiteBuilder.lastDirName + MainActivity safety net). The builder result no longer tells the model to say the card "will be shown"; it says the card is attached below.
