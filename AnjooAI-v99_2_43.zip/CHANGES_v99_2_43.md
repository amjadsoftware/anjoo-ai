# v99.2.43

GitHub Pages publish (GitHubPages.kt): the globe button in the preview now asks Netlify or GitHub Pages. GitHub: token asked once (classic token with repo), a public repository named anjoo-<project> is created or reused, every file is written in one commit through the Git Data API, Pages is turned on, and the address https://<user>.github.io/<repo>/ is shown. Republishing updates the same repository.
