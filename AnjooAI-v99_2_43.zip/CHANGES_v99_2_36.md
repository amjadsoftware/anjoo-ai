# v99.2.36

Visual edit mode in the project preview (pencil button): tap any element, change its text, text colour, background colour, font and size, then Save. Text edits are written into the page HTML; style edits go to a page-scoped rule in edits.css (linked from the page). SiteEditor.kt.
