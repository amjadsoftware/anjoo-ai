# v99.2.31

Website Builder builds page by page: instead of one huge 32k-token reply for all files (slow, often cut off or blank), shared files (css/js/data) are written first, then each HTML page in its own call that sees the files already written (Coder.pageByPage, used only by the Website Builder; other builds unchanged). Broken or cut-off files are still repaired by the existing rewriteIfBroken step.
