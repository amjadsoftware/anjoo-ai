# v99.2.33

Website Builder resume: progress is saved as soon as the project folder exists (Coder.onDirCreated), so a build interrupted by no internet or a closed app keeps its files and can be continued. If the build stops, the reply says so and the partial project card is still attached. "continue" finishes missing pages and cut-off files first (keeping finished ones), then runs the remaining stages.
