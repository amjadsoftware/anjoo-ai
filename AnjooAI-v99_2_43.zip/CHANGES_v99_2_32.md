# v99.2.32

Website Builder small changes: when a change request names pages (about.html, menu ...), only those pages plus shared css/js/data are shown to the model (Coder.focusChange / relevantFiles); after a change only the quick checks re-run (preview check, audit, verify), and SEO/deploy files only when a file was added or removed. The slow premium review no longer re-runs for a small edit.
