package com.anjoo.assistant

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** Makes and edits pictures with Gemini image models. Pictures are stored in the app and shown inside the chat. */
object ImageGen {

    /** Base64 JPEG of the photo the user attached to the current message (for "edit this"). */
    @Volatile var input: String? = null

    /** More photos attached to the same message, sent as extra references when editing/combining. */
    @Volatile var extra: List<String> = emptyList()

    /** When the chat screen is running a request it collects the new picture names here. */
    @Volatile var sink: MutableList<String>? = null

    @Volatile var lastFile: File? = null

    private val MODELS = listOf("gemini-2.5-flash-image", "gemini-3-pro-image-preview", "gemini-2.0-flash-preview-image-generation")

    fun dir(ctx: Context) = File(ctx.filesDir, "images").also { it.mkdirs() }

    fun file(ctx: Context, name: String) = File(dir(ctx), name.replace("/", "").replace("..", ""))

    /** The prompt a saved picture was made from (used by the "Another version" button). */
    fun promptOf(ctx: Context, name: String): String = try { File(dir(ctx), name.replace("/", "").replace("..", "") + ".txt").readText() } catch (e: Exception) { "" }

    private class Fail(val code: Int, msg: String) : Exception(msg)

    private fun call(key: String, model: String, prompt: String, src: String?, aspect: String?): Pair<String, String> {
        val parts = JSONArray().put(JSONObject().put("text", prompt))
        if (src != null) parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", src)))
        if (src != null) for (e in extra.take(3)) parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", e)))
        val gc = JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE"))
        if (aspect != null && src == null) gc.put("imageConfig", JSONObject().put("aspectRatio", aspect))
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", gc)
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = 150000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val txt = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val msg = try { JSONObject(txt).getJSONObject("error").getString("message") } catch (e: Exception) { txt.take(160) }
            throw Fail(code, msg)
        }
        val j = JSONObject(txt)
        val ps = j.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
        var said = ""
        if (ps != null) for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            val inl = p.optJSONObject("inlineData") ?: p.optJSONObject("inline_data")
            if (inl != null && inl.optString("data").isNotEmpty()) return Pair(inl.getString("data"), inl.optString("mimeType", inl.optString("mime_type", "image/png")))
            if (p.has("text")) said += p.getString("text")
        }
        val why = j.optJSONObject("promptFeedback")?.optString("blockReason") ?: ""
        throw Fail(0, (said.ifBlank { "No picture came back." } + " " + why).trim())
    }

    /** Creates (or, with [edit], changes) a picture. Returns the saved file name. Throws with a readable message. */
    fun make(ctx: Context, prompt: String, edit: Boolean, aspect: String?): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val key = Providers.geminiKey(p)
        if (key.isEmpty()) throw IllegalStateException("Picture creation needs a Google Gemini key. Open Settings, choose Google Gemini and add its key (your chat AI can stay different).")
        var src: String? = null
        if (edit) {
            src = input
            if (src == null) {
                val f = lastFile
                if (f != null && f.exists()) {
                    try {
                        val bmp = android.graphics.BitmapFactory.decodeFile(f.absolutePath)
                        if (bmp != null) {
                            val bo = java.io.ByteArrayOutputStream()
                            bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, bo)
                            src = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
                        }
                    } catch (e: Exception) {}
                }
            }
        }
        val first = (p.getString("imageModel", "") ?: "").trim()
        val models = (listOf(first).filter { it.isNotEmpty() } + MODELS).distinct()
        var last: Exception? = null
        var useAspect = aspect?.takeIf { it in listOf("1:1", "16:9", "9:16", "4:3", "3:4") }
        for (m in models) {
            for (attempt in 0..1) {
                try {
                    val (data, mime) = call(key, m, prompt, src, useAspect)
                    val ext = if (mime.contains("jpeg") || mime.contains("jpg")) "jpg" else "png"
                    val f = File(dir(ctx), "img_" + System.currentTimeMillis() + "." + ext)
                    f.writeBytes(Base64.decode(data, Base64.DEFAULT))
                    try { File(f.parentFile, f.name + ".txt").writeText(prompt.take(2000)) } catch (e2: Exception) {}
                    lastFile = f
                    // keep the storage small: remove the oldest pictures beyond 120 (with their prompt notes)
                    dir(ctx).listFiles { x -> !x.name.endsWith(".txt") }?.sortedBy { it.lastModified() }?.let { all ->
                        if (all.size > 120) all.take(all.size - 120).forEach { it.delete(); File(it.parentFile, it.name + ".txt").delete() }
                    }
                    return f.name
                } catch (e: Fail) {
                    last = e
                    if (e.code == 400 && useAspect != null) { useAspect = null; continue }
                    if (e.code == 500 || e.code == 503) { Thread.sleep(1500); continue }
                    break
                } catch (e: java.io.IOException) {
                    last = e
                    break
                }
            }
        }
        val e = last
        val msg = when {
            e is Fail && e.code == 429 -> "Google's image limit is used up for now. Try again in a few minutes."
            e is Fail && (e.code == 403 || e.code == 400) && (e.message ?: "").contains("API key", true) -> "The API key is not valid."
            e is Fail && e.code == 404 -> "No image model is available for this key."
            else -> e?.message ?: "Could not make the picture."
        }
        throw IllegalStateException(msg)
    }

    /** The tool entry point (chat and voice). n = how many versions (1 to 3, made at the same time). */
    fun tool(ctx: Context, a: JSONObject): String {
        val prompt = a.optString("prompt").trim()
        if (prompt.isEmpty()) return "Koi description nahi mili."
        val edit = a.optBoolean("edit", false)
        val aspect = a.optString("aspect", "").ifBlank { null }
        val n = a.optInt("n", 1).coerceIn(1, 3)
        val names = java.util.Collections.synchronizedList(ArrayList<String>())
        val errors = java.util.Collections.synchronizedList(ArrayList<String>())
        val jobs = (0 until n).map {
            Thread {
                try { names.add(make(ctx, prompt, edit, aspect)) } catch (e: Exception) { errors.add(e.message ?: e.javaClass.simpleName) }
            }.also { t -> t.start() }
        }
        jobs.forEach { try { it.join() } catch (e: InterruptedException) {} }
        if (names.isEmpty()) return "Picture nahi ban saki: " + (errors.firstOrNull() ?: "unknown error")
        val s = sink
        for (name in names) {
            if (s != null) synchronized(s) { s.add(name) } else ChatStore.append(ctx, 1, "[[img:$name]]")
        }
        val partial = if (names.size < n) " (sirf ${names.size} ban saki)" else ""
        return "Picture ban gayi$partial aur chat mein user ko dikha di gayi. Bas ek chhota jumla kaho; picture ka link ya file ka zikr mat karo."
    }
}
