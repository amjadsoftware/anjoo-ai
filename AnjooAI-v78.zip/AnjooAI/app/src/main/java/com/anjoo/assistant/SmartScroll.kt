package com.anjoo.assistant

import android.os.SystemClock
import android.view.MotionEvent
import android.widget.ScrollView

/**
 * Keeps a chat list glued to the bottom while new text arrives, WITHOUT fighting the user:
 * it does nothing while a finger is on the list (or just lifted), and only follows when the list is already
 * near the bottom. It scrolls with scrollTo, never fullScroll, which also moves keyboard focus and made the
 * screen jump when dragging or picking an option.
 */
class SmartScroll(private val sv: ScrollView) {
    @Volatile private var touching = false
    @Volatile private var lastTouch = 0L
    private var pending = false

    init {
        sv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> { touching = true; lastTouch = SystemClock.elapsedRealtime() }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { touching = false; lastTouch = SystemClock.elapsedRealtime() }
            }
            false
        }
    }

    /** [force] = go to the bottom whatever the user is doing (their own new message, opening a chat). */
    fun toBottom(force: Boolean = false) {
        if (pending && !force) return
        pending = true
        sv.postDelayed({
            pending = false
            val c = sv.getChildAt(0) ?: return@postDelayed
            val gap = c.bottom - (sv.height + sv.scrollY)
            val near = gap < (sv.resources.displayMetrics.density * 220).toInt()
            val idle = !touching && SystemClock.elapsedRealtime() - lastTouch > 1200
            if (force || (near && idle)) sv.scrollTo(0, maxOf(0, c.bottom - sv.height + sv.paddingBottom))
        }, 60)
    }
}
