package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Prompt engineering on demand.
 *  - make():    a rough idea -> one excellent, ready-to-paste prompt for ChatGPT / Claude / Gemini / an image or video tool / a coder.
 *  - improve(): a short coding request -> a precise engineering brief (used by the ✨ button in Code Studio).
 */
object PromptMaker {

    private const val MAKE_SYS = "You are a world-class prompt engineer. Turn the user's rough idea into ONE excellent prompt that can be pasted straight into the target tool.\n" +
        "METHOD:\n" +
        "1. Infer the real goal, the audience and what a perfect result looks like. Choose sensible defaults instead of asking questions.\n" +
        "2. Structure the prompt with clear labelled sections: ROLE (a specific expert), CONTEXT, TASK (numbered steps), INPUTS (use [PLACEHOLDERS] for anything unknown, never invent facts), " +
        "CONSTRAINTS (must / must not, length, tone, language, versions), OUTPUT FORMAT (exact structure, headings, tables, JSON schema), QUALITY BAR (what to double-check before answering), " +
        "and a short EXAMPLE of the wanted output when it removes doubt.\n" +
        "3. CODING targets: name the language and version, platform, libraries, file structure, input/output behaviour, edge cases, error handling, security, tests, how to run, and demand complete runnable code with no placeholders.\n" +
        "4. IMAGE or VIDEO targets: subject, action, setting, art style or medium, lighting, camera angle and lens, composition, colour palette, mood, detail level, aspect ratio, and a NEGATIVE prompt line. Write it as a dense descriptive paragraph (plus the negative line), in English.\n" +
        "5. WRITING, RESEARCH, STUDY, BUSINESS targets: audience, tone, length, structure, sources to rely on, what to avoid.\n" +
        "6. Be specific and measurable; remove filler such as 'please', 'very', 'best possible'. Keep the prompt as short as it can be while being complete.\n" +
        "OUTPUT (exactly this order):\n" +
        "First the finished prompt alone inside ONE fenced code block (the prompt itself in English unless the user clearly wants another language).\n" +
        "Then one line: 'Kyun behtar hai:' followed by at most 3 short reasons.\n" +
        "Then, only if something important is missing, one line: 'Aur behtar banane ke liye bataiye:' with at most 3 short questions.\n" +
        "Explanations use the user's own language style (Roman Urdu or English)."

    private const val IMPROVE_SYS = "You rewrite a developer's short request into a precise engineering brief for an AI coder. " +
        "Keep EVERY detail and wish the user gave; add only what a senior engineer would assume: the best-fit stack (or the project's existing stack), the main features as a short list, " +
        "the screens or modules, data and saved state, edge cases and empty/error states, UI quality (responsive, accessible, polished), and how it should be tested. " +
        "If a project already exists, say what must stay unchanged. Do not invent brand names or facts. " +
        "Write plain text in English, under 170 words, as a compact list of requirements. Output ONLY the brief: no preface, no code fences, no commentary."

    private fun call(ctx: Context, system: String, ask: String, max: Int): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        Providers.load(p)
        val key = p.getString("key", "") ?: ""
        if (key.isEmpty()) return ""
        val model = p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
        return try {
            Gemini.plain(key, model, system, JSONArray().put(JSONObject().put("text", ask)), max).trim()
        } catch (e: Exception) { "" }
    }

    /** [target] is where the prompt will be used (chatgpt, claude, gemini, image, video, code, general ...). */
    fun make(ctx: Context, idea: String, target: String): String {
        if (idea.isBlank()) return "Batayein kis cheez ka prompt chahiye."
        val out = call(ctx, MAKE_SYS, "TARGET: " + target.ifBlank { "any AI assistant" } + "\nUSER'S IDEA:\n" + idea, 3000)
        return if (out.isEmpty()) "Prompt nahi ban saka. Settings mein API key check karein aur dobara koshish karein." else
            "Prompt taiyar hai. User ko ye poora jawab waise ka waisa dikhao (code block mein prompt, phir neeche ki lines), badlo mat:\n\n" + out
    }

    /** Short request -> brief. Returns "" when it could not be done. */
    fun improve(ctx: Context, request: String, projectInfo: String): String =
        call(ctx, IMPROVE_SYS, (if (projectInfo.isNotBlank()) "EXISTING PROJECT:\n" + projectInfo + "\n\n" else "") + "REQUEST:\n" + request, 1200)
            .removePrefix("```").removeSuffix("```").trim()
}
