package com.anjoo.assistant

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** One AI company the app can talk to. kind: "gemini", "openai" (OpenAI-style API) or "anthropic". */
class Provider(
    val id: String,
    val label: String,
    val kind: String,
    val baseUrl: String,
    val models: List<String>,
    val keyHint: String,
    val keyUrl: String
)

/**
 * Lets the whole app keep using Gemini-shaped JSON (contents / parts / functionCall) while the
 * answer actually comes from another provider. Requests are translated on the way out and the
 * reply is translated back, so Agent, Coder, Studio and the chat screen do not need to change.
 */
object Providers {

    val ALL: List<Provider> = listOf(
        Provider(
            "gemini", "Google Gemini  (free tier, default)", "gemini",
            "https://generativelanguage.googleapis.com/v1beta",
            listOf(
                "gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite",
                "gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.5-flash-lite",
                "gemini-2.0-flash", "gemini-flash-latest", "gemini-flash-lite-latest", "gemini-pro-latest"
            ),
            "AIza...", "aistudio.google.com/apikey"
        ),
        Provider(
            "openai", "OpenAI  (ChatGPT)", "openai", "https://api.openai.com/v1",
            listOf("gpt-5", "gpt-5-mini", "gpt-5-nano", "gpt-4.1", "gpt-4.1-mini", "gpt-4o", "gpt-4o-mini"),
            "sk-...", "platform.openai.com/api-keys"
        ),
        Provider(
            "anthropic", "Anthropic  (Claude)", "anthropic", "https://api.anthropic.com/v1",
            listOf("claude-sonnet-5-5", "claude-opus-5-5", "claude-haiku-5-5", "claude-fable-5-1"),
            "sk-ant-...", "console.anthropic.com/settings/keys"
        ),
        Provider(
            "openrouter", "OpenRouter  (hundreds of models, some free)", "openai", "https://openrouter.ai/api/v1",
            listOf("openrouter/auto", "meta-llama/llama-3.3-70b-instruct:free", "deepseek/deepseek-chat-v3-0324:free"),
            "sk-or-...", "openrouter.ai/keys"
        ),
        Provider(
            "groq", "Groq  (very fast, free tier)", "openai", "https://api.groq.com/openai/v1",
            listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "openai/gpt-oss-120b"),
            "gsk_...", "console.groq.com/keys"
        ),
        Provider(
            "deepseek", "DeepSeek", "openai", "https://api.deepseek.com",
            listOf("deepseek-chat", "deepseek-reasoner"),
            "sk-...", "platform.deepseek.com/api_keys"
        ),
        Provider(
            "mistral", "Mistral", "openai", "https://api.mistral.ai/v1",
            listOf("mistral-large-latest", "mistral-medium-latest", "mistral-small-latest"),
            "", "console.mistral.ai/api-keys"
        ),
        Provider(
            "xai", "xAI  (Grok)", "openai", "https://api.x.ai/v1",
            listOf("grok-4", "grok-3", "grok-3-mini"),
            "xai-...", "console.x.ai"
        ),
        Provider(
            "custom", "Custom  (any OpenAI-compatible URL)", "openai", "",
            emptyList(), "", ""
        )
    )

    @Volatile var active: Provider = ALL[0]
    @Volatile var customBase: String = ""

    fun byId(id: String?): Provider = ALL.firstOrNull { it.id == id } ?: ALL[0]

    /** Reads which provider is chosen. Call before using Gemini.send* from any screen or service. */
    fun load(p: SharedPreferences) {
        active = byId(p.getString("provider", "gemini"))
        customBase = p.getString("base_custom", "") ?: ""
    }

    private fun baseOf(pv: Provider, override: String? = null): String =
        if (pv.id == "custom") (override ?: customBase).trim().trimEnd('/') else pv.baseUrl

    /** The Gemini key, for features that only Gemini can do (voice typing, Gemini voice, pictures). */
    fun geminiKey(p: SharedPreferences): String {
        val pid = p.getString("provider", "gemini") ?: "gemini"
        return if (pid == "gemini") (p.getString("key", "") ?: "") else (p.getString("key_gemini", "") ?: "")
    }

    /** The key saved for one provider (older installs only have "key", which was always Gemini's). */
    fun savedKey(p: SharedPreferences, id: String): String {
        val own = p.getString("key_$id", null)
        if (own != null && own.isNotBlank()) return own
        val cur = p.getString("provider", "gemini") ?: "gemini"
        return if (cur == id) (p.getString("key", "") ?: "") else ""
    }

    fun savedModel(p: SharedPreferences, id: String): String {
        val own = p.getString("model_$id", null)
        if (own != null && own.isNotBlank()) return own
        val cur = p.getString("provider", "gemini") ?: "gemini"
        if (cur == id) {
            val m = p.getString("model", null)
            if (m != null && m.isNotBlank()) return m
        }
        return byId(id).models.firstOrNull() ?: ""
    }

    // ---------------------------------------------------------------- model lists

    /** Asks the provider which models this key can use. Throws when the key or address is wrong. */
    fun listModels(pv: Provider, key: String, baseOverride: String? = null): List<String> {
        val base = baseOf(pv, baseOverride)
        if (base.isEmpty()) throw IOException("Enter the base URL first.")
        val out = ArrayList<String>()
        when (pv.kind) {
            "gemini" -> {
                val j = get("$base/models?pageSize=1000", mapOf("x-goog-api-key" to key))
                val arr = j.optJSONArray("models") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    val methods = m.optJSONArray("supportedGenerationMethods") ?: continue
                    var ok = false
                    for (k in 0 until methods.length()) if (methods.getString(k) == "generateContent") ok = true
                    val name = s(m, "name").removePrefix("models/")
                    val bad = listOf("-tts", "image", "embedding", "aqa", "live", "audio", "robotics")
                    if (ok && name.isNotEmpty() && bad.none { name.contains(it) }) out.add(name)
                }
            }
            "anthropic" -> {
                val j = get("$base/models?limit=1000", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"))
                val arr = j.optJSONArray("data") ?: JSONArray()
                for (i in 0 until arr.length()) out.add(s(arr.getJSONObject(i), "id"))
            }
            else -> {
                val j = get("$base/models", mapOf("Authorization" to "Bearer $key"))
                val arr = j.optJSONArray("data") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val id = s(arr.getJSONObject(i), "id")
                    if (id.isEmpty()) continue
                    if (pv.id == "openai") {
                        val chat = id.startsWith("gpt-") || id.startsWith("chatgpt-") || Regex("^o\\d").containsMatchIn(id)
                        val bad = listOf("audio", "realtime", "transcribe", "tts", "image", "search", "instruct", "embedding")
                        if (!chat || bad.any { id.contains(it) }) continue
                    }
                    out.add(id)
                }
            }
        }
        return out.filter { it.isNotBlank() }.distinct()
    }

    private fun get(url: String, headers: Map<String, String>): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "GET"
        conn.connectTimeout = 15000
        conn.readTimeout = 20000
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        val code = conn.responseCode
        if (code !in 200..299) {
            val err = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val detail = try {
                val e = JSONObject(err).opt("error")
                if (e is JSONObject) s(e, "message") else ""
            } catch (ex: Exception) { "" }
            throw IOException("HTTP $code" + if (detail.isNotBlank()) " - " + detail.take(120) else "")
        }
        val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        return JSONObject(text)
    }

    // ---------------------------------------------------------------- chat

    private val decl: JSONArray by lazy { JSONArray(Gemini.DECLARATIONS) }

    private const val NO_WEB = "\n\n(Live Google search is not available with this AI. For fresh facts use the news tool, " +
        "or say honestly that you cannot browse.)"

    /**
     * Sends the Gemini-format conversation to another provider and returns a Gemini-format reply
     * (candidates[0].content.parts with text and functionCall parts).
     */
    fun send(
        pv: Provider, key: String, model: String, system: String, contents: JSONArray,
        withTools: Boolean, maxTokens: Int, temperature: Double?, webWanted: Boolean,
        onText: ((String) -> Unit)?
    ): JSONObject {
        val sys = if (webWanted) system + NO_WEB else system
        var useTools = withTools
        var last: Exception? = null
        var attempt = 0
        while (attempt < 3) {
            try {
                Cancel.check()
                val r = if (pv.kind == "anthropic")
                    callAnthropic(pv, key, model, sys, contents, useTools, maxTokens, temperature)
                else
                    callOpenAi(pv, key, model, sys, contents, useTools, maxTokens, temperature)
                if (onText != null) {
                    val t = textOf(r)
                    if (t.isNotEmpty()) onText(t)
                }
                return r
            } catch (e: ApiException) {
                Cancel.check()
                last = e
                val toolsIssue = useTools && (e.code == 400 || e.code == 422) &&
                    Regex("tool|function", RegexOption.IGNORE_CASE).containsMatchIn(e.message ?: "")
                if (toolsIssue) { useTools = false; continue }
                val busy = e.code == 500 || e.code == 502 || e.code == 503 || e.code == 504 || e.code == 529
                if (busy && attempt < 2) { Thread.sleep(1500); attempt++; continue }
                if (e.code == 429 && attempt < 1 && e.retryMs in 1..20000L) { Thread.sleep(e.retryMs + 300); attempt++; continue }
                throw e
            } catch (e: java.net.SocketTimeoutException) {
                Cancel.check()
                throw e
            } catch (e: IOException) {
                Cancel.check()
                last = e
                if (attempt < 1) { Thread.sleep(1000); attempt++; continue }
                throw e
            }
        }
        throw last ?: IOException("No answer came back.")
    }

    private fun textOf(r: JSONObject): String {
        val ps = r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            if (p.has("text") && !p.optBoolean("thought", false)) sb.append(p.getString("text"))
        }
        return sb.toString().trim()
    }

    /** org.json turns a JSON null into the text "null"; this gives "" instead. */
    private fun s(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k, "")

    private fun wrapReply(parts: JSONArray, finish: String): JSONObject {
        val cand = JSONObject()
            .put("content", JSONObject().put("role", "model").put("parts", parts))
            .put("finishReason", finish)
        return JSONObject().put("candidates", JSONArray().put(cand))
    }

    private fun post(
        url: String, headers: Map<String, String>, body: JSONObject,
        maxTokens: Int, label: String, model: String
    ): JSONObject {
        val conn = URL(url).openConnection() as HttpURLConnection
        Cancel.track(conn)
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = if (maxTokens > 2000) 170000 else 60000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val raw = try {
                val e = JSONObject(text).opt("error")
                if (e is JSONObject) s(e, "message") else ""
            } catch (ex: Exception) { "" }
            val detail = raw.ifBlank { text.take(200) }
            val hint = when (code) {
                401 -> "$label ki API key galat hai. Settings mein dobara dalein."
                402 -> "$label mein credits/balance khatam hai. Detail: $detail"
                403 -> detail
                404 -> "Model '$model' nahi mila. Settings mein model ka naam check karein."
                429 -> "$label ki limit poori ho gayi. Thori der ruk kar try karein ya Settings mein doosra model chunein."
                else -> detail
            }
            val retryMs = (conn.getHeaderField("retry-after")?.toDoubleOrNull()?.times(1000))?.toLong() ?: 0L
            throw ApiException(code, "($code) $hint", retryMs)
        }
        return try { JSONObject(text) } catch (e: Exception) { throw IOException("$label ka jawab samajh nahi aaya.") }
    }

    // ---------------------------------------------------------------- OpenAI-style

    private fun openAiTools(): JSONArray {
        val out = JSONArray()
        for (i in 0 until decl.length()) {
            val d = decl.getJSONObject(i)
            val fn = JSONObject().put("name", d.getString("name")).put("description", d.optString("description"))
            fn.put("parameters", d.optJSONObject("parameters") ?: JSONObject().put("type", "object").put("properties", JSONObject()))
            out.put(JSONObject().put("type", "function").put("function", fn))
        }
        return out
    }

    private fun callOpenAi(
        pv: Provider, key: String, model: String, system: String, contents: JSONArray,
        useTools: Boolean, maxTokens: Int, temperature: Double?
    ): JSONObject {
        val base = baseOf(pv)
        if (base.isEmpty()) throw IOException("Settings mein Base URL dalein.")
        val msgs = JSONArray()
        if (system.isNotBlank()) msgs.put(JSONObject().put("role", "system").put("content", system))
        toOpenAiMessages(contents, msgs, pv.id == "openai")
        val body = JSONObject().put("model", model).put("messages", msgs)
        val isOpenAi = pv.id == "openai"
        val reasoning = isOpenAi && (model.startsWith("gpt-5") || Regex("^o\\d").containsMatchIn(model))
        if (isOpenAi) {
            // reasoning models count their hidden thinking inside this limit, so give them room
            body.put("max_completion_tokens", if (reasoning) minOf(32000, maxTokens * 4) else maxTokens)
        } else {
            body.put("max_tokens", if (pv.id == "deepseek") minOf(8192, maxTokens) else maxTokens)
        }
        if (temperature != null && !reasoning) body.put("temperature", temperature)
        if (useTools) body.put("tools", openAiTools())

        val headers = HashMap<String, String>()
        if (key.isNotBlank()) headers["Authorization"] = "Bearer $key"
        if (pv.id == "openrouter") headers["X-Title"] = "Anjoo AI"
        val j = post("$base/chat/completions", headers, body, maxTokens, pv.label, model)

        val ch = j.optJSONArray("choices")?.optJSONObject(0) ?: throw IOException("No answer came back.")
        val msg = ch.optJSONObject("message") ?: JSONObject()
        val parts = JSONArray()
        val reason = s(msg, "reasoning_content")
        if (reason.isNotBlank()) parts.put(JSONObject().put("text", reason).put("thought", true))
        var text = ""
        val c = msg.opt("content")
        if (c is String) text = c
        else if (c is JSONArray) {
            val sb = StringBuilder()
            for (i in 0 until c.length()) {
                val b = c.optJSONObject(i) ?: continue
                sb.append(s(b, "text"))
            }
            text = sb.toString()
        }
        if (text.isNotBlank()) parts.put(JSONObject().put("text", text))
        val calls = msg.optJSONArray("tool_calls")
        if (calls != null) {
            for (i in 0 until calls.length()) {
                val fn = calls.getJSONObject(i).optJSONObject("function") ?: continue
                val args = try { JSONObject(s(fn, "arguments").ifBlank { "{}" }) } catch (e: Exception) { JSONObject() }
                parts.put(JSONObject().put("functionCall", JSONObject().put("name", s(fn, "name")).put("args", args)))
            }
        }
        val fr = when (s(ch, "finish_reason")) {
            "length" -> "MAX_TOKENS"
            "content_filter" -> "SAFETY"
            else -> "STOP"
        }
        return wrapReply(parts, fr)
    }

    private fun dataUrl(p: JSONObject): Pair<String, String>? {
        val d = p.optJSONObject("inlineData") ?: return null
        return Pair(s(d, "mimeType"), s(d, "data"))
    }

    private fun toOpenAiMessages(contents: JSONArray, out: JSONArray, allowPdf: Boolean) {
        val pending = ArrayList<Pair<String, String>>() // function name, call id
        var n = 0
        for (i in 0 until contents.length()) {
            val c = contents.getJSONObject(i)
            val ps = c.optJSONArray("parts") ?: continue
            if (c.optString("role", "user") == "model") {
                val text = StringBuilder()
                val calls = JSONArray()
                for (j in 0 until ps.length()) {
                    val p = ps.getJSONObject(j)
                    if (p.optBoolean("thought", false)) continue
                    if (p.has("text")) text.append(p.getString("text"))
                    val fc = p.optJSONObject("functionCall")
                    if (fc != null) {
                        val id = "call_" + (++n)
                        val name = fc.getString("name")
                        pending.add(Pair(name, id))
                        calls.put(
                            JSONObject().put("id", id).put("type", "function").put(
                                "function", JSONObject().put("name", name)
                                    .put("arguments", (fc.optJSONObject("args") ?: JSONObject()).toString())
                            )
                        )
                    }
                }
                if (text.isEmpty() && calls.length() == 0) continue
                val m = JSONObject().put("role", "assistant")
                m.put("content", if (text.isEmpty()) JSONObject.NULL else text.toString())
                if (calls.length() > 0) m.put("tool_calls", calls)
                out.put(m)
            } else {
                val content = JSONArray()
                var onlyText = true
                val textAll = StringBuilder()
                for (j in 0 until ps.length()) {
                    val p = ps.getJSONObject(j)
                    val fr = p.optJSONObject("functionResponse")
                    if (fr != null) {
                        val name = fr.optString("name")
                        var idx = pending.indexOfFirst { it.first == name }
                        if (idx < 0 && pending.isNotEmpty()) idx = 0
                        val result = (fr.optJSONObject("response") ?: JSONObject()).let {
                            if (it.length() == 1 && it.has("result")) s(it, "result") else it.toString()
                        }
                        if (idx >= 0) {
                            val id = pending.removeAt(idx).second
                            out.put(JSONObject().put("role", "tool").put("tool_call_id", id).put("content", result.ifBlank { "done" }))
                        } else {
                            content.put(JSONObject().put("type", "text").put("text", "[tool result] $result"))
                            textAll.append("[tool result] ").append(result).append('\n')
                        }
                        continue
                    }
                    if (p.has("text")) {
                        content.put(JSONObject().put("type", "text").put("text", p.getString("text")))
                        textAll.append(p.getString("text")).append('\n')
                        continue
                    }
                    val d = dataUrl(p) ?: continue
                    val mime = d.first
                    if (mime.startsWith("image/")) {
                        onlyText = false
                        content.put(
                            JSONObject().put("type", "image_url")
                                .put("image_url", JSONObject().put("url", "data:$mime;base64," + d.second))
                        )
                    } else if (mime == "application/pdf" && allowPdf) {
                        onlyText = false
                        content.put(
                            JSONObject().put("type", "file").put(
                                "file", JSONObject().put("filename", "file.pdf")
                                    .put("file_data", "data:application/pdf;base64," + d.second)
                            )
                        )
                    } else {
                        content.put(JSONObject().put("type", "text").put("text", "[An attachment of type $mime was shared, but this AI cannot read it.]"))
                        textAll.append("[An attachment of type $mime was shared, but this AI cannot read it.]\n")
                    }
                }
                if (content.length() == 0) continue
                val m = JSONObject().put("role", "user")
                if (onlyText) m.put("content", textAll.toString().trim()) else m.put("content", content)
                out.put(m)
            }
        }
    }

    // ---------------------------------------------------------------- Claude

    private fun callAnthropic(
        pv: Provider, key: String, model: String, system: String, contents: JSONArray,
        useTools: Boolean, maxTokens: Int, temperature: Double?
    ): JSONObject {
        val body = JSONObject().put("model", model).put("max_tokens", minOf(16000, maxTokens))
            .put("messages", toAnthropicMessages(contents))
        if (system.isNotBlank()) body.put("system", system)
        if (temperature != null) body.put("temperature", temperature)
        if (useTools) {
            val tools = JSONArray()
            for (i in 0 until decl.length()) {
                val d = decl.getJSONObject(i)
                tools.put(
                    JSONObject().put("name", d.getString("name")).put("description", d.optString("description"))
                        .put("input_schema", d.optJSONObject("parameters") ?: JSONObject().put("type", "object").put("properties", JSONObject()))
                )
            }
            body.put("tools", tools)
        }
        val j = post(
            baseOf(pv) + "/messages",
            mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"),
            body, maxTokens, pv.label, model
        )
        val parts = JSONArray()
        val blocks = j.optJSONArray("content") ?: JSONArray()
        for (i in 0 until blocks.length()) {
            val b = blocks.getJSONObject(i)
            when (s(b, "type")) {
                "text" -> if (s(b, "text").isNotBlank()) parts.put(JSONObject().put("text", s(b, "text")))
                "thinking" -> if (s(b, "thinking").isNotBlank()) parts.put(JSONObject().put("text", s(b, "thinking")).put("thought", true))
                "tool_use" -> parts.put(
                    JSONObject().put(
                        "functionCall",
                        JSONObject().put("name", s(b, "name")).put("args", b.optJSONObject("input") ?: JSONObject())
                    )
                )
            }
        }
        val fr = when (s(j, "stop_reason")) {
            "max_tokens" -> "MAX_TOKENS"
            "refusal" -> "SAFETY"
            else -> "STOP"
        }
        return wrapReply(parts, fr)
    }

    private fun toAnthropicMessages(contents: JSONArray): JSONArray {
        val out = JSONArray()
        val pending = ArrayList<Pair<String, String>>()
        var n = 0
        fun add(role: String, blocks: List<JSONObject>) {
            if (blocks.isEmpty()) return
            val last = if (out.length() > 0) out.getJSONObject(out.length() - 1) else null
            if (last != null && last.getString("role") == role) {
                val arr = last.getJSONArray("content")
                for (b in blocks) arr.put(b)
            } else {
                val arr = JSONArray()
                for (b in blocks) arr.put(b)
                out.put(JSONObject().put("role", role).put("content", arr))
            }
        }
        for (i in 0 until contents.length()) {
            val c = contents.getJSONObject(i)
            val ps = c.optJSONArray("parts") ?: continue
            if (c.optString("role", "user") == "model") {
                val blocks = ArrayList<JSONObject>()
                for (j in 0 until ps.length()) {
                    val p = ps.getJSONObject(j)
                    if (p.optBoolean("thought", false)) continue
                    if (p.has("text") && p.getString("text").isNotBlank()) {
                        blocks.add(JSONObject().put("type", "text").put("text", p.getString("text")))
                    }
                    val fc = p.optJSONObject("functionCall")
                    if (fc != null) {
                        val id = "toolu_" + (++n)
                        val name = fc.getString("name")
                        pending.add(Pair(name, id))
                        blocks.add(
                            JSONObject().put("type", "tool_use").put("id", id).put("name", name)
                                .put("input", fc.optJSONObject("args") ?: JSONObject())
                        )
                    }
                }
                add("assistant", blocks)
            } else {
                val results = ArrayList<JSONObject>()
                val others = ArrayList<JSONObject>()
                for (j in 0 until ps.length()) {
                    val p = ps.getJSONObject(j)
                    val fr = p.optJSONObject("functionResponse")
                    if (fr != null) {
                        val name = fr.optString("name")
                        var idx = pending.indexOfFirst { it.first == name }
                        if (idx < 0 && pending.isNotEmpty()) idx = 0
                        val result = (fr.optJSONObject("response") ?: JSONObject()).let {
                            if (it.length() == 1 && it.has("result")) s(it, "result") else it.toString()
                        }
                        if (idx >= 0) {
                            val id = pending.removeAt(idx).second
                            results.add(
                                JSONObject().put("type", "tool_result").put("tool_use_id", id)
                                    .put("content", result.ifBlank { "done" })
                            )
                        } else {
                            others.add(JSONObject().put("type", "text").put("text", "[tool result] $result"))
                        }
                        continue
                    }
                    if (p.has("text")) {
                        if (p.getString("text").isNotBlank()) others.add(JSONObject().put("type", "text").put("text", p.getString("text")))
                        continue
                    }
                    val d = dataUrl(p) ?: continue
                    val mime = d.first
                    if (mime == "image/jpeg" || mime == "image/png" || mime == "image/gif" || mime == "image/webp") {
                        others.add(
                            JSONObject().put("type", "image").put(
                                "source", JSONObject().put("type", "base64").put("media_type", mime).put("data", d.second)
                            )
                        )
                    } else if (mime == "application/pdf") {
                        others.add(
                            JSONObject().put("type", "document").put(
                                "source", JSONObject().put("type", "base64").put("media_type", mime).put("data", d.second)
                            )
                        )
                    } else {
                        others.add(JSONObject().put("type", "text").put("text", "[An attachment of type $mime was shared, but this AI cannot read it.]"))
                    }
                }
                // tool results must come first inside the user turn
                add("user", results + others)
            }
        }
        return out
    }
}
