package com.anjoo.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.SystemClock
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * A natural, human-sounding voice from Gemini's speech model. Any failure returns false so the caller
 * can fall back to the phone's own voice.
 */
object GeminiVoice {

    private const val DEFAULT_MODEL = "gemini-2.5-flash-preview-tts"
    @Volatile private var track: AudioTrack? = null
    @Volatile private var stopFlag = false
    @Volatile private var failUntil = 0L
    @Volatile var lastError = ""

    /** Short phrases (like "Ji?") are kept so they never need a second request. */
    private val cache = object : LinkedHashMap<String, Pair<ByteArray, Int>>(16, 0.75f, true) {
        override fun removeEldestEntry(e: MutableMap.MutableEntry<String, Pair<ByteArray, Int>>?) = size > 16
    }

    fun enabled(ctx: Context): Boolean =
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean("human", true)

    /** Voices offered in the picker: Gemini voice name to label. */
    val FEMALE = listOf(
        "Aoede" to "Girl · Aoede · sweet and breezy",
        "Leda" to "Girl · Leda · young and cute",
        "Zephyr" to "Girl · Zephyr · bright and cheerful",
        "Sulafat" to "Girl · Sulafat · warm and soft",
        "Despina" to "Girl · Despina · smooth and charming",
        "Callirrhoe" to "Girl · Callirrhoe · easy-going",
        "Vindemiatrix" to "Girl · Vindemiatrix · gentle and calm",
        "Laomedeia" to "Girl · Laomedeia · upbeat and playful",
        "Achernar" to "Girl · Achernar · soft and dreamy",
        "Kore" to "Girl · Kore · clear and confident"
    )
    val MALE = listOf(
        "Puck" to "Boy · Puck · young and upbeat",
        "Achird" to "Boy · Achird · friendly and easy",
        "Fenrir" to "Man · Fenrir · energetic",
        "Orus" to "Man · Orus · firm and steady",
        "Charon" to "Man · Charon · deep and informative",
        "Algenib" to "Man · Algenib · rich and gravelly",
        "Sadaltager" to "Man · Sadaltager · knowledgeable",
        "Iapetus" to "Man · Iapetus · clear and calm"
    )

    fun isMale(name: String) = MALE.any { it.first == name }

    fun voiceFor(ctx: Context): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val v = p.getString("voiceName", "") ?: ""
        if (FEMALE.any { it.first == v } || isMale(v)) return v
        return if (p.getString("voiceGender", "female") == "male") "Orus" else "Aoede"
    }

    fun stop() {
        stopFlag = true
        try { track?.stop() } catch (e: Exception) {}
    }

    /** Splits a reply into a short first piece (so speech starts fast) and a few longer pieces. */
    private fun chunks(text: String): List<String> {
        val parts = Regex("[^.!?\\u06D4\\u061F\\n]+[.!?\\u06D4\\u061F]*").findAll(text).map { it.value.trim() }
            .filter { it.isNotEmpty() }.toList()
        if (parts.isEmpty()) return listOf(text)
        val out = ArrayList<String>()
        var i = 0
        var first = parts[0]
        i = 1
        while (first.length < 30 && i < parts.size) { first += " " + parts[i]; i++ }
        out.add(first)
        var cur = ""
        while (i < parts.size) {
            if (cur.isNotEmpty() && cur.length + parts[i].length > 520) { out.add(cur); cur = "" }
            cur = if (cur.isEmpty()) parts[i] else cur + " " + parts[i]
            i++
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }

    /** Speaks [text] and returns when playback has finished. Returns false if it could not start. */
    fun say(ctx: Context, text: String): Boolean {
        if (!enabled(ctx)) return false
        VoiceKit.focusOn(ctx)
        try { return sayInner(ctx, text) } finally { VoiceKit.focusOff(ctx) }
    }

    private fun sayInner(ctx: Context, text: String): Boolean {
        val prefs = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val key = Providers.geminiKey(prefs)
        if (key.isEmpty() || !enabled(ctx)) return false
        if (SystemClock.elapsedRealtime() < failUntil) return false
        val model = prefs.getString("ttsModel", DEFAULT_MODEL)?.ifBlank { DEFAULT_MODEL } ?: DEFAULT_MODEL
        val voice = voiceFor(ctx)
        stopFlag = false
        val spoken = VoiceKit.clean(text)
        if (spoken.isEmpty()) return true
        val pieces = chunks(spoken.take(900))
        val q = java.util.concurrent.LinkedBlockingQueue<Any>()
        val end = Any()
        val fail = Any()
        Thread {
            try {
                for (c in pieces) {
                    if (stopFlag) break
                    q.put(synthCached(key, model, voice, c))
                }
                q.put(end)
            } catch (e: Exception) { lastError = e.message ?: e.javaClass.simpleName; q.put(fail) }
        }.also { it.isDaemon = true }.start()
        var played = false
        while (true) {
            val item = q.poll(45, java.util.concurrent.TimeUnit.SECONDS) ?: fail
            if (item === end) break
            if (item === fail) {
                if (!played) { failUntil = SystemClock.elapsedRealtime() + 6000; return false }
                break
            }
            if (stopFlag) break
            @Suppress("UNCHECKED_CAST")
            val p = item as Pair<ByteArray, Int>
            play(p.first, p.second)
            played = true
        }
        return true
    }

    private fun synthCached(key: String, model: String, voice: String, text: String): Pair<ByteArray, Int> {
        val ck = voice + "|" + text
        if (text.length <= 80) synchronized(cache) { cache[ck] }?.let { return it }
        val r = synth(key, model, voice, text)
        if (text.length <= 80) synchronized(cache) { cache[ck] = r }
        return r
    }

    /** One try, and one gentle retry when Google says it is busy or the quota is momentarily full. */
    private fun synth(key: String, model: String, voice: String, text: String): Pair<ByteArray, Int> {
        try { return synthOnce(key, model, voice, text) } catch (e: java.io.IOException) {
            val m = e.message ?: ""
            if (!(m.contains("429") || m.contains("500") || m.contains("503") || m.contains("504"))) throw e
            try { Thread.sleep(if (m.contains("429")) 2500L else 900L) } catch (x: InterruptedException) {}
            return synthOnce(key, model, voice, text)
        }
    }

    private fun synthOnce(key: String, model: String, voice: String, text: String): Pair<ByteArray, Int> {
        val style = if (isMale(voice)) "deep, calm, warm and confident"
        else "the sweet, soft, youthful voice of a friendly young woman, gentle and feminine, with a warm smile in her tone, like a caring girl talking to a close friend"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(
                JSONObject().put("text", "Speak the following exactly as written, in a natural, clear conversational human voice, $style. Match Urdu, Roman Urdu, and English pronunciation naturally. Use a calm pace, not a robotic or theatrical tone: $text")
            ))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put(
                    "prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 40000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw java.io.IOException("tts $code")
        val inline = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData")
        val data = Base64.decode(inline.getString("data"), Base64.DEFAULT)
        val rate = Regex("rate=(\\d+)").find(inline.optString("mimeType", ""))?.groupValues?.get(1)?.toInt() ?: 24000
        return Pair(data, rate)
    }

    private fun play(pcm: ByteArray, rate: Int): Boolean {
        if (pcm.size < 2) return false
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = t
        t.write(pcm, 0, pcm.size)
        t.play()
        val frames = pcm.size / 2
        val deadline = SystemClock.elapsedRealtime() + frames * 1000L / rate + 2000
        while (!stopFlag && t.playbackHeadPosition < frames && SystemClock.elapsedRealtime() < deadline) {
            try { Thread.sleep(60) } catch (e: InterruptedException) { break }
        }
        try { t.stop() } catch (e: Exception) {}
        t.release()
        track = null
        return true
    }
}
