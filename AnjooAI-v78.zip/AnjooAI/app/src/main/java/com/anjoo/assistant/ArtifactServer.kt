package com.anjoo.assistant

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException
import java.net.Inet4Address
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.security.SecureRandom
import java.util.Collections

/**
 * "Link" for an artifact without any server on the internet: while the app is running, a tiny read-only web server on the phone
 * shows one artifact at http://<phone-wifi-ip>:<port>/p/<secret>. Anyone on the same Wi-Fi / hotspot who has the link can open it.
 * Each artifact gets its own random secret, the server only ever serves artifacts that were shared, and it stops by itself after 60 minutes.
 */
object ArtifactServer {
    private const val MAX_MINUTES = 60L
    private var server: ServerSocket? = null
    private val tokens = HashMap<String, String>()   // secret -> artifact id
    private var stopAt = 0L
    private var port = 0

    fun isRunning(): Boolean = server != null

    fun lanIps(): List<String> = try {
        Collections.list(java.net.NetworkInterface.getNetworkInterfaces()).filter { it.isUp && !it.isLoopback }
            .flatMap { Collections.list(it.inetAddresses) }
            .filter { it is Inet4Address && !it.isLoopbackAddress && it.isSiteLocalAddress }
            .mapNotNull { it.hostAddress }
    } catch (e: Exception) { emptyList() }

    private fun newToken(): String {
        val r = SecureRandom()
        val abc = "abcdefghijklmnopqrstuvwxyz0123456789"
        return (1..16).map { abc[r.nextInt(abc.length)] }.joinToString("")
    }

    /** Starts (or reuses) the server and returns the links for this artifact, or a text starting with "ERR:". */
    @Synchronized
    fun share(ctx: Context, id: String): String {
        val ips = lanIps()
        if (ips.isEmpty()) return "ERR:Phone kisi Wi-Fi ya hotspot se juda nahi, is liye link nahi ban sakta. Wi-Fi on karein (ya doosre phone ka hotspot) aur dobara kahein."
        if (server == null) {
            var s: ServerSocket? = null
            for (p in 8787..8797) {
                try { s = ServerSocket(p); port = p; break } catch (e: Exception) {}
            }
            val sock: ServerSocket = s ?: return "ERR:Server ke liye koi port khali nahi mila."
            server = sock
            val app = ctx.applicationContext
            Thread {
                try {
                    sock.soTimeout = 15000
                    while (!sock.isClosed) {
                        try {
                            val c = sock.accept()
                            Thread { handle(app, c) }.apply { isDaemon = true }.start()
                        } catch (e: SocketTimeoutException) {
                            synchronized(this) { if (System.currentTimeMillis() > stopAt) { stopLocked() } }
                        }
                    }
                } catch (e: Exception) {}
            }.apply { isDaemon = true }.start()
        }
        stopAt = System.currentTimeMillis() + MAX_MINUTES * 60_000L
        val tok = tokens.entries.firstOrNull { it.value == id }?.key ?: newToken().also { tokens[it] = id }
        return ips.joinToString("\n") { "http://$it:$port/p/$tok" }
    }

    @Synchronized
    fun stop() { stopLocked() }

    private fun stopLocked() {
        try { server?.close() } catch (e: Exception) {}
        server = null
        tokens.clear()
    }

    fun minutesLeft(): Long = if (server == null) 0 else maxOf(0, (stopAt - System.currentTimeMillis()) / 60_000L)

    private fun reply(c: Socket, code: String, type: String, body: ByteArray, head: Boolean) {
        val h = "HTTP/1.1 $code\r\nContent-Type: $type\r\nContent-Length: ${body.size}\r\nCache-Control: no-store\r\n" +
            "X-Content-Type-Options: nosniff\r\nReferrer-Policy: no-referrer\r\nConnection: close\r\n\r\n"
        val o = c.getOutputStream()
        o.write(h.toByteArray(Charsets.ISO_8859_1))
        if (!head) o.write(body)
        o.flush()
    }

    private fun handle(ctx: Context, c: Socket) {
        try {
            c.soTimeout = 5000
            val ins = c.getInputStream()
            val buf = StringBuilder()
            while (buf.length < 8192) {
                val b = ins.read()
                if (b < 0) break
                buf.append(b.toChar())
                if (buf.endsWith("\r\n\r\n") || buf.endsWith("\n\n")) break
            }
            val first = buf.lineSequence().firstOrNull() ?: ""
            val parts = first.split(" ")
            val method = parts.getOrElse(0) { "" }
            val path = parts.getOrElse(1) { "" }.substringBefore('?').substringBefore('#')
            if (method != "GET" && method != "HEAD") { reply(c, "405 Method Not Allowed", "text/plain", "Not allowed".toByteArray(), false); return }
            val m = Regex("^/p/([a-z0-9]{16})/?$").find(path)
            val id = m?.let { synchronized(this) { tokens[it.groupValues[1]] } }
            val meta = id?.let { Artifacts.meta(ctx, it) }
            if (meta == null) {
                reply(c, "404 Not Found", "text/plain; charset=utf-8", "Not found".toByteArray(), method == "HEAD")
                return
            }
            val html = Artifacts.pageHtml(meta, Artifacts.source(ctx, meta))
            reply(c, "200 OK", "text/html; charset=utf-8", html.toByteArray(Charsets.UTF_8), method == "HEAD")
        } catch (e: Exception) {
        } finally {
            try { c.close() } catch (e: Exception) {}
        }
    }
}

/** Lets the system share sheet read the exported artifact files (html, md, doc) from Anjoo's private share folder. */
class ArtifactProvider : ContentProvider() {
    override fun onCreate() = true

    private fun base(): File = File(context!!.filesDir, "artifacts/_share")

    private fun fileOf(uri: Uri): File? {
        val n = uri.lastPathSegment ?: return null
        if (n.contains('/') || n.contains("..")) return null
        val f = File(base(), n)
        return try { if (f.isFile && f.canonicalPath.startsWith(base().canonicalPath)) f else null } catch (e: Exception) { null }
    }

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor {
        val f = fileOf(uri) ?: throw FileNotFoundException(uri.toString())
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
    }

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor? {
        val f = fileOf(uri) ?: return null
        val c = MatrixCursor(arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE))
        c.addRow(arrayOf<Any>(f.name, f.length()))
        return c
    }

    override fun getType(uri: Uri): String? = when (uri.lastPathSegment?.substringAfterLast('.', "")?.lowercase()) {
        "html" -> "text/html"
        "md" -> "text/markdown"
        "txt" -> "text/plain"
        "doc" -> "application/msword"
        else -> "application/octet-stream"
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?) = 0
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?) = 0
}
