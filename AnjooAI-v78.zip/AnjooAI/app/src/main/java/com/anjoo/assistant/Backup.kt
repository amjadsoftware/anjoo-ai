package com.anjoo.assistant

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Saves everything Anjoo knows to one file, and loads it back.
 *
 * Version 2 is a ZIP: backup.json (settings, memory, diary, chats) plus the real folders
 *   projects/   Code Studio projects (their files AND their Code Studio chat, kept in .anjoo-meta.json)
 *   chatkeep/   the second copy of projects shown in chat cards
 *   studio/     older pages and code
 *   images/     pictures Anjoo made
 *   attach/     files you attached in chat (PDF, code, ZIP, photos)
 * Version 1 (plain .json) files from older builds can still be imported.
 */
object Backup {

    /** Folders (inside filesDir) that go into the backup as they are. */
    private val FOLDERS = listOf("projects", "chatkeep", "studio", "images", "attach")

    private fun prefsJson(ctx: Context, withKey: Boolean): JSONObject {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val prefs = JSONObject()
        for ((k, v) in p.all) {
            if ((k == "key" || k.startsWith("key_")) && !withKey) continue
            if (k == "batteryAsked" || k == "accAsked") continue
            val o = JSONObject()
            when (v) {
                is String -> o.put("t", "s").put("v", v)
                is Boolean -> o.put("t", "b").put("v", v)
                is Int -> o.put("t", "i").put("v", v)
                is Long -> o.put("t", "l").put("v", v)
                is Float -> o.put("t", "f").put("v", v.toDouble())
                else -> continue
            }
            prefs.put(k, o)
        }
        return prefs
    }

    /** Old plain-JSON format (still used for sharing small things and for reading old backups). */
    fun build(ctx: Context, withKey: Boolean): String =
        JSONObject().put("app", "AnjooAI").put("version", 1).put("at", System.currentTimeMillis())
            .put("prefs", prefsJson(ctx, withKey)).put("chats", ChatStore.all(ctx)).put("notes", Notes.exportArray(ctx)).toString()

    /** Writes the full ZIP backup. Returns how many files were saved. */
    fun write(ctx: Context, out: OutputStream, withKey: Boolean): Int {
        var files = 0
        ZipOutputStream(out.buffered()).use { z ->
            val head = JSONObject().put("app", "AnjooAI").put("version", 2).put("at", System.currentTimeMillis())
                .put("prefs", prefsJson(ctx, withKey)).put("chats", ChatStore.all(ctx)).put("notes", Notes.exportArray(ctx)).toString()
            z.putNextEntry(ZipEntry("backup.json"))
            z.write(head.toByteArray(Charsets.UTF_8))
            z.closeEntry()
            for (name in FOLDERS) {
                val base = File(ctx.filesDir, name)
                if (!base.isDirectory) continue
                for (f in base.walkTopDown()) {
                    if (!f.isFile) continue
                    val rel = f.relativeTo(ctx.filesDir).path.replace('\\', '/')
                    try {
                        z.putNextEntry(ZipEntry(rel))
                        f.inputStream().use { it.copyTo(z) }
                        z.closeEntry()
                        files++
                    } catch (e: Exception) { /* skip one unreadable file, keep the rest */ }
                }
            }
        }
        return files
    }

    private const val AUTO_EVERY_MS = 3L * 24 * 3600 * 1000
    private const val AUTO_KEEP = 3

    /**
     * Saves a backup by itself every 3 days (without the API key) into Downloads/AnjooAI, keeping the newest 3.
     * The first call only starts the clock. Turn off with the "autoBackup" setting.
     */
    fun autoIfDue(ctx: Context) {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        if (!p.getBoolean("autoBackup", true)) return
        val now = System.currentTimeMillis()
        val last = p.getLong("lastAutoBackup", 0L)
        if (last == 0L) { p.edit().putLong("lastAutoBackup", now).apply(); return }
        if (now - last < AUTO_EVERY_MS) return
        if (ChatStore.all(ctx).length() == 0 && Coder.list(ctx).isEmpty()) return
        p.edit().putLong("lastAutoBackup", now).apply()
        val app = ctx.applicationContext
        Thread {
            try {
                val name = "anjoo-auto-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.ENGLISH).format(Date()) + ".zip"
                if (Build.VERSION.SDK_INT >= 29) {
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/AnjooAI")
                    }
                    val uri = app.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return@Thread
                    app.contentResolver.openOutputStream(uri)?.use { write(app, it, false) }
                    pruneDownloads(app)
                } else {
                    val dir = File(app.getExternalFilesDir(null) ?: app.filesDir, "backups").also { it.mkdirs() }
                    File(dir, name).outputStream().use { write(app, it, false) }
                    dir.listFiles { f -> f.name.startsWith("anjoo-auto-") }?.sortedByDescending { it.name }?.drop(AUTO_KEEP)?.forEach { it.delete() }
                }
            } catch (e: Exception) { /* a failed auto backup is silent; the next try is in 3 days */ }
        }.start()
    }

    private fun pruneDownloads(ctx: Context) {
        try {
            val col = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val old = ArrayList<Long>()
            ctx.contentResolver.query(
                col, arrayOf(MediaStore.MediaColumns._ID),
                MediaStore.MediaColumns.DISPLAY_NAME + " LIKE ? AND " + MediaStore.MediaColumns.RELATIVE_PATH + " LIKE ?",
                arrayOf("anjoo-auto-%", "Download/AnjooAI%"), MediaStore.MediaColumns.DATE_ADDED + " DESC"
            )?.use { c ->
                var i = 0
                while (c.moveToNext()) { if (i++ >= AUTO_KEEP) old.add(c.getLong(0)) }
            }
            for (id in old) try { ctx.contentResolver.delete(ContentUris.withAppendedId(col, id), null, null) } catch (e: Exception) {}
        } catch (e: Exception) {}
    }

    /** Reads either format. Looks at the first bytes to know which one it is. */
    fun restore(ctx: Context, input: InputStream): String {
        val ins = input.buffered()
        ins.mark(4)
        val b0 = ins.read(); val b1 = ins.read()
        ins.reset()
        if (b0 == 'P'.code && b1 == 'K'.code) return restoreZip(ctx, ins)
        val text = ins.bufferedReader(Charsets.UTF_8).readText()
        return restore(ctx, text)
    }

    private fun restoreZip(ctx: Context, ins: InputStream): String {
        var head: ByteArray? = null
        var files = 0
        val filesRoot = ctx.filesDir.canonicalFile
        ZipInputStream(ins).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                if (e.name == "backup.json") {
                    val bo = ByteArrayOutputStream()
                    z.copyTo(bo)
                    head = bo.toByteArray()
                    continue
                }
                val top = e.name.substringBefore('/')
                if (top !in FOLDERS) continue
                val dest = File(ctx.filesDir, e.name).canonicalFile
                // refuse anything that would land outside the app's own folders
                if (!dest.path.startsWith(filesRoot.path + File.separator)) continue
                try {
                    dest.parentFile?.mkdirs()
                    dest.outputStream().use { z.copyTo(it) }
                    files++
                } catch (ex: Exception) { /* skip */ }
            }
        }
        val h = head ?: return "Ye Anjoo ki backup file nahi lagti."
        val msg = restore(ctx, String(h, Charsets.UTF_8))
        return if (msg.startsWith("Ye Anjoo")) msg else "$msg $files files (Code Studio projects, unki chat, attachments, images) bhi wapas aa gayin."
    }

    fun restore(ctx: Context, text: String): String {
        val root = try { JSONObject(text) } catch (e: Exception) { return "Ye Anjoo ki backup file nahi lagti." }
        if (root.optString("app") != "AnjooAI") return "Ye Anjoo ki backup file nahi lagti."
        val prefs = root.optJSONObject("prefs") ?: JSONObject()
        val ed = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).edit()
        val keys = prefs.keys()
        var n = 0
        while (keys.hasNext()) {
            val k = keys.next()
            val o = prefs.getJSONObject(k)
            when (o.getString("t")) {
                "s" -> ed.putString(k, o.getString("v"))
                "b" -> ed.putBoolean(k, o.getBoolean("v"))
                "i" -> ed.putInt(k, o.getInt("v"))
                "l" -> ed.putLong(k, o.getLong("v"))
                "f" -> ed.putFloat(k, o.getDouble("v").toFloat())
            }
            n++
        }
        ed.apply()
        val chats = root.optJSONArray("chats") ?: JSONArray()
        ChatStore.replaceAll(ctx, chats)
        // notes are merged (newest edit wins), so restoring never wipes notes written after the backup
        root.optJSONArray("notes")?.let { try { Notes.merge(ctx, it) } catch (e: Exception) {} }
        Reminders.restoreAll(ctx)
        return "Backup wapas aa gayi: $n settings/yaadein aur ${chats.length()} chats."
    }
}
