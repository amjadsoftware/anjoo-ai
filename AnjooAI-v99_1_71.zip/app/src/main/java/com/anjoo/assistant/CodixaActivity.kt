package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Codixa: mobile coding-agent workspace for saved projects, files, activity, preview and export. */
class CodixaActivity : Activity() {
    private val bg = Color.rgb(14, 17, 22)
    private val surface = Color.rgb(23, 27, 34)
    private val surface2 = Color.rgb(30, 36, 45)
    private val ink = Color.rgb(232, 234, 237)
    private val muted = Color.rgb(138, 147, 160)
    private val accent = Color.rgb(138, 180, 255)
    private val border = Color.argb(70, 138, 147, 160)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(fill: Int, stroke: Int = border, radius: Int = 14) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        render()
    }

    private fun text(label: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = label
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }

    private fun button(label: String, primary: Boolean = false, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 12.5f
        setTextColor(if (primary) Color.rgb(10, 18, 29) else ink)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        background = rounded(if (primary) accent else surface2, if (primary) accent else border, 10)
        setPadding(dp(11), dp(9), dp(11), dp(9))
        setOnClickListener { action() }
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(surface, border, 0)
        }
        toolbar.addView(button("‹  Back") { finish() }, LinearLayout.LayoutParams(-2, -2))
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("Codixa", 18f, ink, true))
        brand.addView(text("CODING WORKSPACE", 9.5f, accent, true).apply { letterSpacing = 0.1f })
        toolbar.addView(brand, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        toolbar.addView(button("+ New task", true) {
            finish()
            Toast.makeText(this, "Anjoo chat mein app, website, ya code change ka task likhein.", Toast.LENGTH_LONG).show()
        })
        root.addView(toolbar, LinearLayout.LayoutParams(-1, -2))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(18), dp(16), dp(20))
        }
        content.addView(text("Your projects", 25f, ink, true))
        content.addView(text("Open a workspace to inspect code, review project history, preview the app, or export files.", 13f, muted).apply {
            setLineSpacing(0f, 1.18f)
            setPadding(0, dp(5), 0, dp(15))
        })

        val search = EditText(this).apply {
            hint = "Search projects and files…"
            textSize = 14f
            setTextColor(ink)
            setHintTextColor(muted)
            isSingleLine = true
            background = rounded(surface, border, 12)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        content.addView(search, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val projectList = Coder.list(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list, LinearLayout.LayoutParams(-1, -2))
        fun fill(query: String = "") {
            list.removeAllViews()
            val q = query.trim()
            val projects = projectList.filter { dir ->
                q.isBlank() || Coder.name(dir).contains(q, true) ||
                    dir.name.contains(q, true) || Coder.readFiles(dir).keys.any { it.contains(q, true) }
            }
            if (projects.isEmpty()) {
                val empty = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    background = rounded(surface, border, 16)
                    setPadding(dp(16), dp(18), dp(16), dp(18))
                }
                empty.addView(text(if (q.isBlank()) "No projects yet" else "No matching projects", 17f, ink, true))
                empty.addView(text(
                    if (q.isBlank()) "Build an app or website in Anjoo chat. Saved Code Studio projects will appear here with their files, history and preview." else "Try another project name or file name.",
                    12.5f, muted
                ).apply { setPadding(0, dp(5), 0, dp(12)) })
                empty.addView(button("←  Start a task in Anjoo", true) { finish() }, LinearLayout.LayoutParams(-2, -2))
                list.addView(empty)
                return
            }
            for (dir in projects) list.addView(projectCard(dir), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        }
        fill()
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { fill(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })

        val scroll = ScrollView(this).apply {
            addView(content)
            isVerticalScrollBarEnabled = false
            clipToPadding = false
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("ANJOO AI  ·  CODEX-STYLE PROJECT WORKSPACE", 9.5f, muted, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(12), dp(8), dp(12))
        })
        setContentView(root)
    }

    private fun projectCard(dir: File): View {
        val files = Coder.readFiles(dir)
        val fileNames = files.keys.take(3).joinToString("  ·  ").ifBlank { "No text files yet" }
        val hasPreview = PreviewServer.entry(dir) != null
        val size = files.keys.sumOf { File(dir, it).length() }
        val modified = SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(Date(dir.lastModified()))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(surface, border, 16)
            setPadding(dp(13), dp(13), dp(13), dp(13))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val glyph = TextView(this).apply {
            text = "</>"; textSize = 12f; setTextColor(accent); gravity = Gravity.CENTER
            typeface = Typeface.MONOSPACE
            background = rounded(surface2, border, 10)
        }
        head.addView(glyph, LinearLayout.LayoutParams(dp(42), dp(42)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(text(Coder.name(dir), 16f, ink, true).apply { maxLines = 2 })
        titles.addView(text("${files.size} files  ·  ${size / 1024} KB  ·  Updated $modified", 10.5f, muted).apply {
            setPadding(0, dp(4), 0, 0)
        })
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
        if (hasPreview) head.addView(TextView(this).apply {
            text = "PREVIEW"; textSize = 9f; setTextColor(accent); gravity = Gravity.CENTER
            background = rounded(Color.argb(26, Color.red(accent), Color.green(accent), Color.blue(accent)), accent, 8)
            setPadding(dp(6), dp(5), dp(6), dp(5))
        })
        card.addView(head)
        card.addView(text(fileNames, 11.5f, muted).apply {
            maxLines = 2; setPadding(dp(2), dp(10), dp(2), dp(10))
        })

        val firstRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        firstRow.addView(button("Open workspace", true) { projectActions(dir) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        firstRow.addView(button("Files · ${files.size}") { showFiles(dir) }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(5) })
        card.addView(firstRow)
        val actionsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        actions.addView(button("Chat history") { showProjectChat(dir) }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        actions.addView(button("Build APK", true) {
            startActivity(Intent(this@CodixaActivity, HsApkBuilderActivity::class.java).putExtra("project", dir.absolutePath))
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        if (hasPreview) actions.addView(button("▶ Preview") {
            startActivity(Intent(this@CodixaActivity, ProjectPreviewActivity::class.java).putExtra("project", dir.absolutePath))
        }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        actions.addView(button("Export ZIP") { exportZip(dir) })
        actionsScroll.addView(actions)
        card.addView(actionsScroll, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        return card
    }

    private fun projectActions(dir: File) {
        val files = Coder.readFiles(dir)
        val options = mutableListOf("Open code files (${files.size})", "Project chat / history (${Coder.history(dir).size} entries)")
        val hasPreview = PreviewServer.entry(dir) != null
        if (hasPreview) options.add("Open live preview")
        options.add("Build APK for this project")
        options.add("Export project ZIP")
        AlertDialog.Builder(this).setTitle(Coder.name(dir)).setItems(options.toTypedArray()) { _, which ->
            when (options[which]) {
                options.firstOrNull { it.startsWith("Open code files") } -> showFiles(dir)
                options.firstOrNull { it.startsWith("Project chat") } -> showProjectChat(dir)
                options.firstOrNull { it.startsWith("Open live") } -> startActivity(Intent(this, ProjectPreviewActivity::class.java).putExtra("project", dir.absolutePath))
                options.firstOrNull { it.startsWith("Build APK") } -> startActivity(Intent(this, HsApkBuilderActivity::class.java).putExtra("project", dir.absolutePath))
                options.firstOrNull { it.startsWith("Export") } -> exportZip(dir)
            }
        }.show()
    }

    private fun showFiles(dir: File) {
        val files = Coder.readFiles(dir).toList()
        if (files.isEmpty()) {
            Toast.makeText(this, "Project mein files nahi hain.", Toast.LENGTH_SHORT).show()
            return
        }
        AlertDialog.Builder(this).setTitle("${Coder.name(dir)} — Code files")
            .setItems(files.map { "${it.first}  (${it.second.length} chars)" }.toTypedArray()) { _, i -> showSource(files[i].first, files[i].second) }
            .setNegativeButton("Close", null).show()
    }

    private fun showSource(name: String, source: String) {
        val tv = TextView(this).apply {
            text = source; textSize = 12f; typeface = Typeface.MONOSPACE; setTextColor(ink)
            setTextIsSelectable(true); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        AlertDialog.Builder(this).setTitle(name).setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Copy code") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText(name, source))
                Toast.makeText(this, "Code copied", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Close", null).show()
    }

    private fun showProjectChat(dir: File) {
        val history = Coder.history(dir)
        if (history.isEmpty()) {
            Toast.makeText(this, "Is project ki chat history abhi khaali hai.", Toast.LENGTH_SHORT).show()
            return
        }
        val transcript = history.joinToString("\n\n") { (role, message) -> (if (role == "u") "YOU" else "CODIXA / ANJOO AI") + ":\n" + message }
        val tv = TextView(this).apply {
            text = transcript; textSize = 13f; setTextColor(ink); setTextIsSelectable(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        AlertDialog.Builder(this).setTitle("${Coder.name(dir)} — Project chat")
            .setView(ScrollView(this).apply { addView(tv) })
            .setPositiveButton("Copy chat") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("${Coder.name(dir)} chat", transcript))
                Toast.makeText(this, "Project chat copied", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("Close", null).show()
    }

    private fun exportZip(dir: File) {
        try {
            Dl.save(this, dir.name + ".zip", Coder.zip(dir))
        } catch (e: Exception) {
            Toast.makeText(this, "ZIP export nahi ho saka: ${e.message ?: "error"}", Toast.LENGTH_LONG).show()
        }
    }
}
