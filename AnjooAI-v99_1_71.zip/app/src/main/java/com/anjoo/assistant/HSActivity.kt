package com.anjoo.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/** HS is a HappySeeds-inspired, prompt-first app-builder workspace powered by Anjoo's existing builder. */
class HSActivity : Activity() {
    private val bg = Color.rgb(12, 17, 16)
    private val surface = Color.rgb(21, 29, 26)
    private val surface2 = Color.rgb(29, 39, 34)
    private val ink = Color.rgb(239, 245, 240)
    private val muted = Color.rgb(157, 174, 162)
    private val green = Color.rgb(125, 222, 158)
    private val border = Color.argb(70, 125, 222, 158)
    private var selectedMode = Mode.WEB
    private var draft = ""
    private var planFirst = true
    private var promptBox: EditText? = null
    private val selectedFeatures = linkedSetOf<String>()

    private enum class Mode { WEB, ANDROID, MEDIA }
    private data class Template(val icon: String, val name: String, val description: String, val prompt: String)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(fill: Int, stroke: Int = border, radius: Int = 15) = GradientDrawable().apply {
        setColor(fill); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), stroke)
    }
    private fun text(label: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = label; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
    }
    private fun action(label: String, primary: Boolean = false, click: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER
        setTextColor(if (primary) Color.rgb(9, 23, 14) else ink)
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        background = rounded(if (primary) green else surface2, if (primary) green else border, 11)
        setPadding(dp(13), dp(11), dp(13), dp(11))
        setOnClickListener { click() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(11), dp(14), dp(11)); background = rounded(surface, border, 0)
        }
        toolbar.addView(action("‹  Back") { finish() })
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(text("🌱  HS", 19f, ink, true))
        brand.addView(text("AI APP BUILDER", 9f, green, true).apply { letterSpacing = 0.13f })
        toolbar.addView(brand, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) })
        toolbar.addView(action("My projects") { startActivity(Intent(this@HSActivity, CodixaActivity::class.java)) })
        root.addView(toolbar, LinearLayout.LayoutParams(-1, -2))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(17), dp(16), dp(22))
        }
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(surface, border, 22)
            setPadding(dp(18), dp(19), dp(18), dp(18))
        }
        hero.addView(text("FROM IDEA TO WORKING PROJECT", 10f, green, true).apply { letterSpacing = 0.12f })
        hero.addView(text("Build it.\nGrow it.", 34f, ink, true).apply { setLineSpacing(0f, 0.96f); setPadding(0, dp(8), 0, dp(8)) })
        hero.addView(text("Just describe what you want. Anjoo will turn your prompt into a build task, then let you inspect the generated project in Codixa.", 13f, muted).apply {
            setLineSpacing(dp(2).toFloat(), 1.08f)
        })
        val stats = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        stats.addView(tag("PROMPT → BUILD"), LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) })
        stats.addView(tag("PREVIEW → REFINE"), LinearLayout.LayoutParams(-2, -2))
        hero.addView(stats, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(13) })
        content.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        content.addView(text("What are we making?", 19f, ink, true).apply { setPadding(1, 0, 0, dp(10)) })
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; background = rounded(surface, border, 13); setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val webTab = TextView(this)
        val androidTab = TextView(this)
        val mediaTab = TextView(this)
        fun styleTab(view: TextView, label: String, active: Boolean) {
            view.text = label; view.textSize = 10.5f; view.gravity = Gravity.CENTER
            view.setTextColor(if (active) Color.rgb(9, 23, 14) else muted)
            view.typeface = Typeface.create("sans-serif-medium", if (active) Typeface.BOLD else Typeface.NORMAL)
            view.background = rounded(if (active) green else Color.TRANSPARENT, if (active) green else Color.TRANSPARENT, 10)
            view.setPadding(dp(4), dp(11), dp(4), dp(11))
        }
        styleTab(webTab, "◫  Web Apps", selectedMode == Mode.WEB)
        styleTab(androidTab, "▣  Android APK", selectedMode == Mode.ANDROID)
        styleTab(mediaTab, "✦  Media", selectedMode == Mode.MEDIA)
        webTab.setOnClickListener { draft = promptBox?.text?.toString() ?: draft; selectedMode = Mode.WEB; render() }
        androidTab.setOnClickListener { draft = promptBox?.text?.toString() ?: draft; selectedMode = Mode.ANDROID; render() }
        mediaTab.setOnClickListener { draft = promptBox?.text?.toString() ?: draft; selectedMode = Mode.MEDIA; render() }
        tabs.addView(webTab, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(3) })
        tabs.addView(androidTab, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(1); marginEnd = dp(1) })
        tabs.addView(mediaTab, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(3) })
        content.addView(tabs, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(surface, green, 17)
            setPadding(dp(13), dp(12), dp(13), dp(13))
        }
        composer.addView(text(when (selectedMode) { Mode.WEB -> "Describe your website or web app"; Mode.ANDROID -> "Describe your Android app"; Mode.MEDIA -> "Describe your image or video" }, 13f, ink, true))
        val et = EditText(this).apply {
            hint = when (selectedMode) {
                Mode.WEB -> "Build a booking website with calendar, login, dashboard, and mobile-friendly design…"
                Mode.ANDROID -> "Build an Android app with login, dashboard, saved data, and a polished native interface…"
                Mode.MEDIA -> "Create a premium product ad with cinematic shots, captions, and a matching social post…"
            }
            setText(draft); setTextColor(ink); setHintTextColor(Color.rgb(113, 133, 120)); textSize = 14f
            gravity = Gravity.TOP or Gravity.START; minLines = 4; maxLines = 7
            setPadding(dp(2), dp(10), dp(2), dp(10)); background = null
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { draft = s?.toString() ?: "" }
                override fun afterTextChanged(s: Editable?) {}
            })
        }
        promptBox = et
        composer.addView(et, LinearLayout.LayoutParams(-1, -2))
        val options = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val plan = CheckBox(this).apply {
            text = "Plan first"; textSize = 12f; setTextColor(muted); isChecked = planFirst
            buttonTintList = android.content.res.ColorStateList.valueOf(green)
            setOnCheckedChangeListener { _, checked -> planFirst = checked }
        }
        options.addView(plan, LinearLayout.LayoutParams(0, -2, 1f))
        options.addView(action("Build with AI  ↗", true) { beginBuild() })
        composer.addView(options, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        content.addView(composer, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        content.addView(action("Build APK from a saved project  ↓", true) {
            startActivity(Intent(this@HSActivity, HsApkBuilderActivity::class.java))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        if (selectedMode != Mode.MEDIA) {
            content.addView(text("Add capabilities", 15f, ink, true).apply { setPadding(1, 0, 0, dp(3)) })
            content.addView(text("Select what the project should include. The build task will receive these requirements.", 11.5f, muted).apply {
                setPadding(1, 0, 0, dp(9))
            })
            val choices = if (selectedMode == Mode.ANDROID) listOf("Login & roles", "Local database", "Notifications", "Camera / file upload", "Admin dashboard", "API / backend") else listOf("Login & roles", "Database & saved data", "Payments & subscriptions", "AI features / API", "Admin dashboard", "SEO metadata")
            val capabilityRows = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            choices.chunked(2).forEach { pair ->
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                pair.forEachIndexed { index, label ->
                    row.addView(capabilityChip(label), LinearLayout.LayoutParams(0, -2, 1f).apply {
                        if (index == 0) rightMargin = dp(4) else leftMargin = dp(4)
                    })
                }
                capabilityRows.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
            }
            content.addView(capabilityRows, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(17) })
        }

        content.addView(text(if (selectedMode == Mode.MEDIA) "Choose a creative task" else "Explore & remix a starter", 18f, ink, true).apply {
            setPadding(1, 0, 0, dp(4))
        })
        content.addView(text(when (selectedMode) { Mode.WEB -> "Start with a website idea and edit the brief before building."; Mode.ANDROID -> "Create a native Android project, then build and download its APK."; Mode.MEDIA -> "Choose a starting point for an image or video request." }, 12f, muted).apply {
            setPadding(1, 0, 0, dp(11))
        })
        val templates = when (selectedMode) { Mode.WEB -> appTemplates(); Mode.ANDROID -> androidTemplates(); Mode.MEDIA -> mediaTemplates() }
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        templates.chunked(2).forEach { pair ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
            pair.forEachIndexed { index, t ->
                row.addView(templateCard(t), LinearLayout.LayoutParams(0, -2, 1f).apply {
                    if (index == 0) rightMargin = dp(5) else leftMargin = dp(5)
                })
            }
            if (pair.size == 1) row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f).apply { marginStart = dp(5) })
            grid.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        content.addView(grid)

        val projectDirs = try { Coder.list(this).take(3) } catch (_: Exception) { emptyList() }
        content.addView(text("Your projects", 18f, ink, true).apply { setPadding(1, dp(14), 0, dp(4)) })
        content.addView(text("Open a previous build to inspect files, history and preview, or build its APK.", 12f, muted).apply {
            setPadding(1, 0, 0, dp(11))
        })
        if (projectDirs.isEmpty()) {
            val empty = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(surface, border, 15); setPadding(dp(14), dp(15), dp(14), dp(15)) }
            empty.addView(text("Your first project starts here", 14f, ink, true))
            empty.addView(text("Build something above. Saved Code Studio projects will appear in Codixa and here.", 12f, muted).apply { setPadding(0, dp(5), 0, dp(11)) })
            empty.addView(action("Open Codixa projects  →") { startActivity(Intent(this@HSActivity, CodixaActivity::class.java)) })
            content.addView(empty)
        } else {
            projectDirs.forEach { dir ->
                val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(surface, border, 15); setPadding(dp(13), dp(12), dp(13), dp(12)) }
                card.addView(text(Coder.name(dir), 14f, ink, true).apply { maxLines = 2 })
                val fileCount = try { Coder.readFiles(dir).size } catch (_: Exception) { 0 }
                card.addView(text("$fileCount project files", 11f, muted).apply { setPadding(0, dp(4), 0, dp(10)) })
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                row.addView(action("Open in Codixa") { startActivity(Intent(this@HSActivity, CodixaActivity::class.java)) }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(4) })
                row.addView(action("Build APK", true) {
                    startActivity(Intent(this@HSActivity, HsApkBuilderActivity::class.java).putExtra("project", dir.absolutePath))
                }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
                if (try { PreviewServer.entry(dir) != null } catch (_: Exception) { false }) {
                    row.addView(action("▶ Preview") {
                        startActivity(Intent(this@HSActivity, ProjectPreviewActivity::class.java).putExtra("project", dir.absolutePath))
                    }, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4) })
                }
                card.addView(row)
                content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
            }
            content.addView(action("View all projects in Codixa  →") { startActivity(Intent(this@HSActivity, CodixaActivity::class.java)) })
        }

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(surface2, border, 15); setPadding(dp(14), dp(14), dp(14), dp(14)) }
        info.addView(text("From prompt to publish", 15f, ink, true))
        info.addView(text("1  Plan pages and features\n2  Build and review the generated files\n3  Open Preview and request changes in chat\n4  Configure hosting and external service keys before production publishing", 12f, muted).apply {
            setPadding(0, dp(8), 0, 0); setLineSpacing(dp(3).toFloat(), 1.0f)
        })
        content.addView(info, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })
        content.addView(text("HS WORKSPACE  ·  POWERED BY ANJOO AI", 9f, muted, true).apply {
            gravity = Gravity.CENTER; setPadding(0, dp(18), 0, dp(3)); letterSpacing = 0.08f
        })

        val scroll = ScrollView(this).apply { addView(content); isVerticalScrollBarEnabled = false; clipToPadding = false }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun tag(label: String) = TextView(this).apply {
        text = label; textSize = 9f; setTextColor(green); typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        background = rounded(Color.argb(30, 125, 222, 158), Color.argb(80, 125, 222, 158), 9)
        setPadding(dp(8), dp(6), dp(8), dp(6))
    }

    private fun capabilityChip(label: String): View {
        val active = selectedFeatures.contains(label)
        return TextView(this).apply {
            text = (if (active) "✓  " else "+  ") + label
            textSize = 11.2f; setTextColor(if (active) green else muted)
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(if (active) Color.argb(27, 125, 222, 158) else surface, if (active) green else border, 10)
            setPadding(dp(9), dp(10), dp(7), dp(10))
            setOnClickListener {
                draft = promptBox?.text?.toString() ?: draft
                if (!selectedFeatures.add(label)) selectedFeatures.remove(label)
                render()
            }
        }
    }

    private fun appTemplates() = listOf(
        Template("⌂", "Business website", "Services, pricing, contact", "Build a polished, responsive business website with Home, Services, Pricing, About and Contact sections. Make navigation, contact form validation and all visible buttons work. Add SEO metadata and realistic demo content. My business details: [add details]."),
        Template("▣", "Online store", "Products, cart and checkout", "Build a responsive online store with product catalogue, search/filter, product details, shopping cart, quantity controls, checkout UI, order summary and an admin-ready product structure. Use sample products and clearly mark any payment integration that requires credentials."),
        Template("◷", "Booking app", "Calendar, slots and accounts", "Build a complete booking web app with calendar/date selection, available time slots, customer details, booking confirmation, cancellation flow and an admin schedule view. Validate forms and persist demo data. Explain backend and authentication setup requirements."),
        Template("▤", "Business tool", "Dashboard, data and reports", "Build a professional business management tool with dashboard KPIs, searchable table, create/edit/delete records, filters, export to CSV, form validation and persistent demo data. Make every visible control work and include empty, loading and error states."),
        Template("✧", "Mini game", "Playable, mobile-friendly", "Build a polished, fully playable mobile-friendly browser game with clear instructions, score, restart button, win/loss states, responsive controls and satisfying visual feedback. No dead buttons or placeholder gameplay."),
        Template("◈", "AI-powered app", "Chat, prompts and settings", "Build an AI-powered web app interface with chat/prompt input, conversation history, settings, responsive states and a clean provider/API configuration panel. Never hardcode secrets; clearly separate demo behavior from a connected AI backend."),
        Template("♙", "Client portal", "Login, roles and records", "Build a client portal with sign-in UI, role-aware dashboard layouts, profile/settings, searchable records and an admin management area. Include secure-backend implementation guidance; do not claim real authentication until connected and tested."),
        Template("⌘", "Custom from scratch", "Your idea, your design", "Plan and build this project from scratch based on my full idea. Create all source files and a realistic interactive preview. Ask only a necessary clarifying question; otherwise make reasonable assumptions and document them.")
    )

    private fun androidTemplates() = listOf(
        Template("▦", "Business app", "Native dashboard and records", "Build a complete native Android business management app in Kotlin with Gradle, Dashboard, searchable records, add/edit/delete forms, reports, settings and persistent local storage. Create a proper Android Studio project with settings.gradle.kts, root build.gradle.kts, app/build.gradle.kts, AndroidManifest.xml, Kotlin source and resources. Also create an interactive index.html preview of the same workflows. No dead buttons; include a README and build instructions."),
        Template("✓", "Task manager", "Tasks, reminders and filters", "Build a complete native Android task manager in Kotlin with task creation/editing, priorities, due dates, filters, search, completion, statistics, preferences and local persistence. Include a complete Gradle project, permissions only where needed, tests for pure logic, an interactive index.html preview, and README. Use a polished responsive UI and verify source consistency."),
        Template("▤", "Inventory app", "Stock, sales and reports", "Build a native Android inventory and sales app in Kotlin with product CRUD, stock movements, low-stock alerts, searchable inventory, sales records, totals, CSV export and locally saved data. Provide all Android Gradle files and resources, a real interactive index.html preview mirroring core screens, sample data, validation, and a README with exact build steps."),
        Template("◈", "Chat app", "Conversations and settings", "Build a native Android messaging app interface in Kotlin with conversation list, message thread, composer, attachment picker mock, unread status, search and settings. Persist local demo conversations. Do not claim real remote messaging/authentication without a backend. Include a complete Gradle Android project, matching interactive index.html preview, and README."),
        Template("⌂", "Booking app", "Calendar and appointments", "Build a native Android booking app in Kotlin with date/time selection, available slots, customer form, booking confirmation/cancellation, appointment list and admin schedule screen. Validate fields and save bookings locally for the demo. Include all Android Gradle files, required source/resources, matching interactive index.html preview, and README."),
        Template("⌘", "Custom Android app", "Your idea, built from scratch", "Plan and build my requested native Android app in Kotlin. Generate a complete importable Android Studio Gradle project with settings.gradle.kts, root build.gradle.kts, app/build.gradle.kts, AndroidManifest.xml, source Kotlin files, resources, and required dependencies. Also generate a working interactive index.html preview of the same main screens. Add tests where practical, run all checks available, and document any external service or credential required. Never claim a successful APK build until the cloud build result confirms it.")
    )

    private fun mediaTemplates() = listOf(
        Template("▧", "Product image", "Premium product visual", "Create a premium commercial product image concept for: [describe product]. Define composition, lighting, background, brand mood, camera feel and clean visual hierarchy. Preserve accurate product details and avoid extra text unless requested."),
        Template("▶", "Promo video", "Short ad for social media", "Create a short, high-quality promotional video concept for: [product/business]. Include scene-by-scene timing, camera movement, transitions, voiceover, subtitles and a strong call to action. Format for vertical 9:16 social media unless otherwise specified."),
        Template("▤", "Social campaign", "Post, caption and variants", "Create a complete social media campaign for: [product/service], including 3 visual directions, platform-appropriate captions, hooks, call-to-action variants and a suggested posting sequence. Keep all claims truthful and brand-consistent."),
        Template("◉", "Image to video", "Animate a reference image", "Turn the supplied/reference product image into a cinematic image-to-video brief. Preserve the subject and branding; add natural camera motion, subtle environmental movement, realistic lighting and a clean ending frame."),
        Template("✦", "Brand kit", "Logo direction and colours", "Create a cohesive brand kit for: [brand], including logo direction, colour palette, typography guidance, social post layout, profile image concept and usage rules. Explain each design choice and generate usable assets where supported."),
        Template("▣", "Video recreation", "Use a reference structure", "Analyse the provided reference video or link if accessible. Describe its scene structure, timing, transitions and visual style, then create a new original version for: [subject], without copying protected brand assets or exact footage." )
    )

    private fun templateCard(template: Template): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(surface, border, 15)
            setPadding(dp(12), dp(12), dp(12), dp(12)); isClickable = true
            setOnClickListener {
                draft = template.prompt
                promptBox?.setText(draft)
                promptBox?.setSelection(draft.length)
                Toast.makeText(this@HSActivity, "Template added — edit the prompt, then Build with AI.", Toast.LENGTH_SHORT).show()
            }
        }
        card.addView(text(template.icon, 21f, green, true))
        card.addView(text(template.name, 13.5f, ink, true).apply { setPadding(0, dp(7), 0, dp(3)) })
        card.addView(text(template.description, 11f, muted).apply { setLineSpacing(dp(1).toFloat(), 1.0f) })
        card.addView(text("Remix this idea  →", 10.5f, green, true).apply { setPadding(0, dp(11), 0, 0) })
        return card
    }

    private fun beginBuild() {
        val raw = promptBox?.text?.toString()?.trim().orEmpty()
        if (raw.isBlank()) {
            Toast.makeText(this, "Pehle batao kya banana hai.", Toast.LENGTH_SHORT).show()
            promptBox?.requestFocus()
            return
        }
        val instruction = if (selectedMode != Mode.MEDIA) {
            buildString {
                append(if (selectedMode == Mode.ANDROID) "HS NATIVE ANDROID APP BUILDER TASK\n" else "HS WEB APP BUILDER TASK\n")
                if (planFirst) append("WORKFLOW: First create a concise plan with screens/pages, user flows, data model, acceptance criteria and implementation risks. Then proceed to implementation in the same task unless an essential choice blocks progress.\n")
                if (selectedMode == Mode.ANDROID) {
                    append("TARGET: A real, importable native Android application built with Kotlin and Android Gradle Plugin. Create a complete buildable Android Studio project with settings.gradle.kts, root build.gradle.kts, app/build.gradle.kts, app/src/main/AndroidManifest.xml, app/src/main/java/... Kotlin source and all required resources/dependencies. Use minSdk 26, compileSdk 34, Java/Kotlin 17 unless the project requires otherwise. Implement the requested screens and logic in native Android UI; persist demo data locally where useful; ensure all visible controls work. ALSO create a standalone index.html interactive prototype matching the core native workflows so HS Preview can review the same screens. Add README.md with project structure, build instructions and unconfigured external integrations. Never use fake backend behavior as if it were live.\n\n")
                } else {
                    append("Build a real, responsive website/web app for the request below. Do not only describe a plan or return a mockup. Create/update the actual project files, implement functioning navigation, forms and buttons, realistic loading/empty/error states, responsive mobile layout, and persistent demo data where useful. Ensure the Preview actually matches the requested features. Add backend/auth/database/payment integration code only as supported by the request and clearly state which provider credentials or deployment configuration remain necessary. Never invent test results or claim deployment without verifying it.\n\n")
                }
                append("USER REQUEST:\n")
                append(raw)
                if (selectedFeatures.isNotEmpty()) {
                    append("\n\nADDITIONAL CAPABILITIES REQUESTED: ")
                    append(selectedFeatures.joinToString(", "))
                    append(". Implement these in the actual project where supported. For auth, database and payments, include secure integration/configuration points and clearly identify any service credentials or hosted backend still required; do not represent a mock as production-connected.")
                }
                append("\n\nAfter building, inspect the changed files, run available checks, fix verified errors, and summarize what works, what needs external credentials, and how to preview/refine the project.")
                if (selectedMode == Mode.ANDROID) append("\n\nANDROID APK WORKFLOW: Make this a complete Gradle Android project, not only Kotlin snippets. In Codixa, the user will select Build APK; its cloud builder compiles a complete Gradle project, or wraps a web project's index.html in a WebView APK if Auto mode is selected. Ensure the native Gradle project is at the project root and settings.gradle.kts plus app/build.gradle.kts exist. Never claim compilation has succeeded until the cloud build confirms it.")
            }
        } else {
            buildString {
                append("HS CREATIVE STUDIO TASK\n")
                if (planFirst) append("First outline the intended output, scene/design structure and acceptance criteria, then create the supported asset or deliverable.\n")
                append("Use any available image/video or creative-generation tools when applicable. If a requested media-generation capability is not available, provide a production-ready prompt/storyboard rather than claiming a file was generated.\n\nUSER REQUEST:\n")
                append(raw)
            }
        }
        val intent = Intent(this, MainActivity::class.java).apply {
            // Reuse MainActivity's existing task handler so Build submits the request directly,
            // rather than merely placing it in the composer and making the user press Send again.
            putExtra("habit_prompt", instruction)
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        startActivity(intent)
        finish()
    }
}
