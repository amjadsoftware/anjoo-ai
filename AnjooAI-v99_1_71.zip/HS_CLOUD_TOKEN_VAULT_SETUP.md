# Anjoo AI 99.1.71 — Personal GitHub Token + Supabase Backup

This is a personal-use build customized for the owner's GitHub token. On first launch, the bundled bootstrap token is immediately saved in Android Keystore-encrypted app storage. After the owner verifies their email through Supabase OTP, the app automatically backs the token up to the encrypted Supabase vault. The app does not need the GitHub token to be manually typed again.

**Private build warning:** This ZIP and any APK built from it contain the personal token bootstrap asset. Do not upload this ZIP/APK publicly or share it with anyone. The token was supplied in chat, so revoke it and replace it with a new token when convenient; then update `app/src/main/assets/personal_token_bootstrap.dat` with the base64-encoded replacement before building if you want the replacement embedded. Base64 is encoding, not encryption.

## Supabase project configured in this build

- URL: `https://vzlgekjtgqpezuvqcawb.supabase.co`
- Public publishable key is set in `app/build.gradle.kts` as `HS_SUPABASE_ANON_KEY`.
- Edge Function endpoint: `hs-github-token`

## Supabase server prerequisites (already performed by owner per setup conversation)

The deployed function must be named `hs-github-token`, the `hs_github_token_vault` table must exist, and the function secret `HS_TOKEN_ENCRYPTION_KEY` must be a 64-character hex string. Supabase must have email OTP sign-in enabled and email delivery working. The service role key stays server-side and is never embedded in the Android app.

## First-run cloud backup

1. Open **HS → APK Builder → Permanent cloud backup**.
2. Enter the email address you control and tap **Send email code**.
3. Enter the code received by email and tap **Verify & restore**.
4. On the first sign-in, app automatically backs up its preloaded personal GitHub token to the encrypted vault. Look for the success message. No GitHub token paste is needed.
5. If you plan to use APK Builder, enter your own private GitHub repository as `username/repository`, then tap **Save & test connection**. A placeholder repository ID is only used for token-only backup before a build repository has been selected.

After uninstall/reinstall, repeat email OTP sign-in and **Verify & restore**. The cloud-stored token is restored without pasting it again.

## Important verification note

This package configures the app workflow, but a live Supabase round-trip cannot be confirmed from the source-packaging environment. The app must display `GitHub token cloud backup successful` after OTP sign-in for the initial backup to be considered completed. If it shows an error, that error is the diagnostic to follow; do not assume the cloud save succeeded.
