package com.anjoo.assistant

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.regex.Pattern

/**
 * Chat message renderer. Markdown text, code cards with syntax colours, live "artifact" cards for web pages
 * (Preview / Code tabs, real WebView) and a project card with every file, Run and Zip download.
 */
object Md {

    class Code(val lang: String, val name: String, val text: String)

    private val KW = ("abstract|as|async|await|break|case|catch|class|const|continue|def|default|del|do|else|elif|enum|except|export|extends|" +
        "false|final|finally|for|fun|func|function|from|if|implements|import|in|interface|is|lambda|let|new|null|nil|None|object|override|" +
        "package|pass|private|protected|public|raise|return|self|static|struct|super|switch|this|throw|throws|true|True|False|try|typeof|" +
        "val|var|void|when|while|with|yield|using|namespace|template|typename|int|float|double|string|bool|boolean|char|long|SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|TABLE|JOIN|ORDER|GROUP|BY|AND|OR|NOT|INTO|VALUES")

    private fun pattern(lang: String): Pattern {
        val hash = lang.lowercase() in listOf("python", "py", "bash", "sh", "shell", "yaml", "yml", "ruby", "rb", "toml", "dockerfile")
        val comment = (if (hash) "#[^\\n]*|" else "") + "//[^\\n]*|/\\*[\\s\\S]*?\\*/|<!--[\\s\\S]*?-->|--[ ][^\\n]*"
        return Pattern.compile("($comment)|(\"\"\"[\\s\\S]*?\"\"\"|\"(?:\\\\.|[^\"\\\\\\n])*\"|'(?:\\\\.|[^'\\\\\\n])*'|`(?:\\\\.|[^`\\\\])*`)|\\b(\\d+(?:\\.\\d+)?)\\b|\\b($KW)\\b")
    }

    fun highlight(code: String, lang: String, light: Boolean): CharSequence {
        val sb = SpannableStringBuilder(code)
        if (code.length > 12000) return sb
        val cK = if (light) 0xFFA626A4.toInt() else 0xFFC792EA.toInt()
        val cS = if (light) 0xFF2E7D32.toInt() else 0xFFA5D6A7.toInt()
        val cC = if (light) 0xFF8A8980.toInt() else 0xFF7F7E78.toInt()
        val cN = if (light) 0xFFB76B01.toInt() else 0xFFF2B66D.toInt()
        val m = pattern(lang).matcher(code)
        while (m.find()) {
            val c = when {
                m.group(1) != null -> cC
                m.group(2) != null -> cS
                m.group(3) != null -> cN
                else -> cK
            }
            sb.setSpan(ForegroundColorSpan(c), m.start(), m.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return sb
    }

    private fun dp(ctx: Context, v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    private fun inline(t: String, codeBg: Int): CharSequence {
        val sb = SpannableStringBuilder()
        val m = Pattern.compile("\\*\\*(.+?)\\*\\*|`([^`\\n]+)`|\\*(?!\\s)([^*\\n]+?)\\*").matcher(t)
        var last = 0
        while (m.find()) {
            sb.append(t, last, m.start())
            val s = sb.length
            when {
                m.group(1) != null -> { sb.append(m.group(1)); sb.setSpan(StyleSpan(Typeface.BOLD), s, sb.length, 0) }
                m.group(2) != null -> {
                    sb.append(m.group(2))
                    sb.setSpan(TypefaceSpan("monospace"), s, sb.length, 0)
                    sb.setSpan(BackgroundColorSpan(codeBg), s, sb.length, 0)
                    sb.setSpan(RelativeSizeSpan(0.92f), s, sb.length, 0)
                }
                else -> { sb.append(m.group(3)); sb.setSpan(StyleSpan(Typeface.ITALIC), s, sb.length, 0) }
            }
            last = m.end()
        }
        sb.append(t, last, t.length)
        return sb
    }

    // ---------- parsing ----------

    private val LANG_OF = mapOf("html" to "html", "htm" to "html", "css" to "css", "js" to "javascript", "py" to "python", "kt" to "kotlin",
        "java" to "java", "ts" to "typescript", "json" to "json", "md" to "markdown", "svg" to "svg", "sh" to "bash", "xml" to "xml",
        "sql" to "sql", "go" to "go", "rs" to "rust", "php" to "php", "dart" to "dart", "cpp" to "cpp", "c" to "c", "cs" to "csharp", "yml" to "yaml", "yaml" to "yaml")

    private fun fenceOf(t: String): Int {
        if (!t.startsWith("```")) return 0
        var n = 0; while (n < t.length && t[n] == '`') n++
        return n
    }

    private fun makeCode(info: String, body: String): Code {
        val toks = info.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        var lang = toks.firstOrNull { !it.contains('.') && !it.contains('=') && !it.contains('/') }?.lowercase() ?: ""
        var name = toks.firstOrNull { Regex("^[\\w\\-./]+\\.\\w{1,6}$").matches(it) }
            ?: toks.firstOrNull { it.startsWith("title=") }?.removePrefix("title=")?.trim('"') ?: ""
        val first = body.lineSequence().firstOrNull()?.trim() ?: ""
        Regex("^(?://|#|<!--)\\s*(?:file|filename):\\s*(\\S+?)\\s*(?:-->)?$", RegexOption.IGNORE_CASE).find(first)?.let { if (name.isEmpty()) name = it.groupValues[1] }
        if (lang.isEmpty() && name.isNotEmpty()) lang = LANG_OF[name.substringAfterLast('.').lowercase()] ?: ""
        if (lang.isEmpty() && body.trimStart().let { it.startsWith("<!DOCTYPE", true) || it.startsWith("<html", true) }) lang = "html"
        return Code(lang, name, body)
    }

    /** Every fenced block of a message, in order. */
    fun scan(text: String): List<Code> {
        val out = ArrayList<Code>()
        val lines = text.split("\n")
        var i = 0
        while (i < lines.size) {
            val t = lines[i].trim()
            val f = fenceOf(t)
            if (f > 0) {
                val body = StringBuilder(); i++
                while (i < lines.size && !(fenceOf(lines[i].trim()) >= f && lines[i].trim().all { it == '`' })) { body.append(lines[i]).append('\n'); i++ }
                out.add(makeCode(t.substring(f), body.toString().trimEnd('\n')))
            }
            i++
        }
        return out
    }

    private fun isWeb(lang: String) = lang in listOf("html", "htm", "svg", "javascript", "js", "markdown", "md")
    private fun isPage(lang: String) = lang in listOf("html", "htm", "svg")

    // ---------- views ----------

    private fun btn(ctx: Context, th: CyberTheme, label: String, filled: Boolean = false, onClick: () -> Unit) = TextView(ctx).apply {
        text = label; textSize = 12.5f; gravity = Gravity.CENTER
        setTextColor(if (filled) (if (th.light) Color.WHITE else th.bg) else th.muted)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(dp(ctx, 11), dp(ctx, 6), dp(ctx, 11), dp(ctx, 6))
        if (filled) background = GradientDrawable().apply { setColor(th.accent); cornerRadius = dp(ctx, 10).toFloat() }
        setOnClickListener { onClick() }
    }

    private fun cardBg(ctx: Context, th: CyberTheme) = GradientDrawable().apply {
        setColor(if (th.light) 0xFFF0EEE6.toInt() else 0xFF1F1E1D.toInt()); cornerRadius = dp(ctx, 12).toFloat()
        setStroke(dp(ctx, 1), if (th.light) 0xFFE0DDD2.toInt() else 0xFF3A3935.toInt())
    }

    private fun codeBody(ctx: Context, th: CyberTheme, c: Code, collapsed: Boolean): View {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val lines = c.text.count { it == '\n' } + 1
        val tv = TextView(ctx).apply {
            text = highlight(c.text, c.lang, th.light)
            typeface = Typeface.MONOSPACE; textSize = 12.5f
            setTextColor(if (th.light) 0xFF2B2A28.toInt() else 0xFFE6E4DC.toInt())
            setTextIsSelectable(true); setHorizontallyScrolling(true)
            setPadding(dp(ctx, 12), dp(ctx, 4), dp(ctx, 12), dp(ctx, 10))
            textDirection = View.TEXT_DIRECTION_LTR
            if (collapsed && lines > 18) maxLines = 18
        }
        col.addView(HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; addView(tv) })
        if (collapsed && lines > 18) {
            var open = false
            val more = btn(ctx, th, "Show all $lines lines  ▾") {}
            more.setOnClickListener {
                open = !open
                tv.maxLines = if (open) Int.MAX_VALUE else 18
                more.text = if (open) "Show less  ▴" else "Show all $lines lines  ▾"
            }
            col.addView(more)
        }
        return col
    }

    private fun fileName(c: Code) = c.name.ifEmpty { "snippet." + Files.ext(c.lang) }

    private fun codeCard(ctx: Context, c: Code, th: CyberTheme): LinearLayout {
        val card = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; background = cardBg(ctx, th) }
        val bar = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(ctx, 12), dp(ctx, 2), dp(ctx, 4), dp(ctx, 2)) }
        bar.addView(TextView(ctx).apply {
            text = if (c.name.isNotEmpty()) c.name else c.lang.ifEmpty { "code" }
            setTextColor(th.muted); textSize = 12f; typeface = Typeface.MONOSPACE
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(btn(ctx, th, "Copy") { Files.copy(ctx, c.text) })
        bar.addView(btn(ctx, th, "Save") { Files.save(ctx, fileName(c), c.text) })
        bar.addView(btn(ctx, th, "Share") { Files.share(ctx, fileName(c), c.text) })
        card.addView(bar)
        card.addView(codeBody(ctx, th, c, true))
        return card
    }

    /** Like a Claude artifact: a live page with Preview and Code tabs, expand to full screen, Copy / Download / Share. */
    private fun artifactCard(ctx: Context, c: Code, files: Map<String, String>, th: CyberTheme, auto: Boolean): LinearLayout {
        val card = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; background = cardBg(ctx, th) }
        val name = fileName(c)
        val page = Files.pageFor(c.lang, c.text, files)
        val holder = FrameLayout(ctx)
        var web: android.webkit.WebView? = null
        val tabs = ArrayList<TextView>()
        fun mark(sel: Int) = tabs.forEachIndexed { i, t ->
            t.setTextColor(if (i == sel) (if (th.light) Color.WHITE else th.bg) else th.muted)
            t.background = GradientDrawable().apply { setColor(if (i == sel) th.accent else Color.TRANSPARENT); cornerRadius = dp(ctx, 14).toFloat() }
        }
        fun showPreview() {
            mark(0); holder.removeAllViews()
            val w = web ?: Files.webView(ctx, page).also { web = it }
            (w.parent as? android.view.ViewGroup)?.removeView(w)
            holder.addView(w, FrameLayout.LayoutParams(-1, dp(ctx, 420)))
        }
        fun showCode() { mark(1); holder.removeAllViews(); holder.addView(codeBody(ctx, th, c, true)) }

        val bar = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(ctx, 12), dp(ctx, 6), dp(ctx, 6), dp(ctx, 6)) }
        bar.addView(TextView(ctx).apply {
            text = name; setTextColor(th.ink); textSize = 12.5f; typeface = Typeface.MONOSPACE; maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }, LinearLayout.LayoutParams(0, -2, 1f))
        tabs.add(btn(ctx, th, "Preview") { showPreview() }); tabs.add(btn(ctx, th, "Code") { showCode() })
        tabs.forEach { bar.addView(it) }
        bar.addView(btn(ctx, th, "⤢") { Files.previewPage(ctx, name, page, c.text) })
        card.addView(bar)
        card.addView(holder)
        val foot = LinearLayout(ctx).apply { gravity = Gravity.END; setPadding(dp(ctx, 4), 0, dp(ctx, 4), dp(ctx, 2)) }
        foot.addView(btn(ctx, th, "Copy") { Files.copy(ctx, c.text) })
        foot.addView(btn(ctx, th, "Download") { Files.save(ctx, name, c.text) })
        foot.addView(btn(ctx, th, "Share") { Files.share(ctx, name, c.text) })
        card.addView(foot)
        if (auto && isPage(c.lang)) showPreview() else showCode()
        return card
    }

    /** A whole project in one answer: live page on top, then every file (tap to open), Run and Zip. */
    private fun projectCard(ctx: Context, named: List<Code>, files: Map<String, String>, th: CyberTheme, auto: Boolean, col: LinearLayout) {
        val entry = named.firstOrNull { it.name.substringAfterLast('/').equals("index.html", true) } ?: named.firstOrNull { it.name.endsWith(".html", true) }
        if (entry != null) col.addView(artifactCard(ctx, entry, files, th, auto), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 8) })
        val card = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; background = cardBg(ctx, th) }
        val head = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(ctx, 12), dp(ctx, 4), dp(ctx, 4), dp(ctx, 4)) }
        head.addView(TextView(ctx).apply { text = "Project · ${named.size} files"; setTextColor(th.ink); textSize = 13.5f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) },
            LinearLayout.LayoutParams(0, -2, 1f))
        if (entry != null) head.addView(btn(ctx, th, "▶ Run", true) { Files.preview(ctx, entry.name, "html", entry.text, files) })
        head.addView(btn(ctx, th, "⬇ Zip") { Files.saveZip(ctx, "anjoo-project.zip", named.map { it.name to it.text }) })
        card.addView(head)
        for (c in named) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            val bodyHolder = FrameLayout(ctx).apply { visibility = View.GONE }
            val rh = LinearLayout(ctx).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(ctx, 12), dp(ctx, 2), dp(ctx, 4), dp(ctx, 2)) }
            val lines = c.text.count { it == '\n' } + 1
            val title = TextView(ctx).apply { text = "▸  ${c.name}"; setTextColor(th.ink); textSize = 13f; typeface = Typeface.MONOSPACE; setPadding(0, dp(ctx, 9), 0, dp(ctx, 9)) }
            rh.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
            rh.addView(TextView(ctx).apply { text = "$lines lines"; setTextColor(th.muted); textSize = 11f; setPadding(0, 0, dp(ctx, 6), 0) })
            rh.addView(btn(ctx, th, "Copy") { Files.copy(ctx, c.text) })
            rh.addView(btn(ctx, th, "Save") { Files.save(ctx, c.name.substringAfterLast('/'), c.text) })
            rh.setOnClickListener {
                val open = bodyHolder.visibility != View.VISIBLE
                if (open && bodyHolder.childCount == 0) bodyHolder.addView(codeBody(ctx, th, c, true))
                bodyHolder.visibility = if (open) View.VISIBLE else View.GONE
                title.text = (if (open) "▾  " else "▸  ") + c.name
            }
            row.addView(View(ctx).apply { setBackgroundColor(if (th.light) 0xFFE0DDD2.toInt() else 0xFF3A3935.toInt()) }, LinearLayout.LayoutParams(-1, dp(ctx, 1)))
            row.addView(rh); row.addView(bodyHolder)
            card.addView(row)
        }
        col.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 8) })
    }

    /** Builds the views for one assistant message. autoPreview: show the live page straight away (newest message). */
    fun render(ctx: Context, text: String, th: CyberTheme, autoPreview: Boolean = false, onLong: (String) -> Unit = {}): LinearLayout {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val codeBg = if (th.light) 0xFFF0EEE6.toInt() else 0xFF1F1E1D.toInt()
        val blocks = scan(text)
        val named = blocks.filter { it.name.isNotEmpty() }
        val files = HashMap<String, String>().also { m -> named.forEach { m[it.name] = it.text } }
        val multi = named.size >= 2
        var projectAdded = false
        val para = StringBuilder()

        fun flushPara() {
            if (para.isBlank()) { para.setLength(0); return }
            col.addView(TextView(ctx).apply {
                this.text = inline(para.toString().trim(), codeBg)
                setTextColor(th.ink); textSize = 16f; setLineSpacing(0f, 1.25f)
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
                setTextIsSelectable(true)
                setOnLongClickListener { onLong(text); true }
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 6) })
            para.setLength(0)
        }

        val lines = text.split("\n")
        var i = 0
        while (i < lines.size) {
            val ln = lines[i]
            val t = ln.trim()
            val f = fenceOf(t)
            if (f > 0) {
                flushPara()
                val body = StringBuilder(); i++
                while (i < lines.size && !(fenceOf(lines[i].trim()) >= f && lines[i].trim().all { it == '`' })) { body.append(lines[i]).append('\n'); i++ }
                val c = makeCode(t.substring(f), body.toString().trimEnd('\n'))
                if (multi && c.name.isNotEmpty()) {
                    if (!projectAdded) { projectAdded = true; projectCard(ctx, named, files, th, autoPreview, col) }
                } else if (isWeb(c.lang) && c.text.length > 40) {
                    col.addView(artifactCard(ctx, c, files, th, autoPreview), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 8) })
                } else {
                    col.addView(codeCard(ctx, c, th), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 8) })
                }
                i++
                continue
            }
            val head = Regex("^(#{1,3})\\s+(.*)").find(t)
            val bullet = Regex("^([-*•]|\\d+[.)])\\s+(.*)").find(t)
            when {
                head != null -> {
                    flushPara()
                    val lvl = head.groupValues[1].length
                    col.addView(TextView(ctx).apply {
                        this.text = inline(head.groupValues[2], codeBg); setTextColor(th.ink)
                        textSize = if (lvl == 1) 22f else if (lvl == 2) 19f else 17f
                        typeface = Typeface.create("serif", Typeface.BOLD); setTextIsSelectable(true)
                    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 12) })
                }
                bullet != null -> {
                    flushPara()
                    val mark = bullet.groupValues[1].let { if (it[0].isDigit()) it else "•" }
                    col.addView(TextView(ctx).apply {
                        this.text = SpannableStringBuilder("$mark  ").append(inline(bullet.groupValues[2], codeBg))
                        setTextColor(th.ink); textSize = 16f; setLineSpacing(0f, 1.2f); setTextIsSelectable(true)
                        setPadding(dp(ctx, 6), 0, 0, 0)
                    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 3) })
                }
                t.startsWith(">") -> {
                    flushPara()
                    col.addView(TextView(ctx).apply {
                        this.text = inline(t.removePrefix(">").trim(), codeBg); setTextColor(th.muted); textSize = 15f
                        setPadding(dp(ctx, 12), dp(ctx, 2), 0, dp(ctx, 2)); setTextIsSelectable(true)
                    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(ctx, 4); leftMargin = dp(ctx, 2) })
                }
                t == "---" || t == "***" -> {
                    flushPara()
                    col.addView(View(ctx).apply { setBackgroundColor(th.muted and 0x55FFFFFF) },
                        LinearLayout.LayoutParams(-1, dp(ctx, 1)).apply { topMargin = dp(ctx, 10); bottomMargin = dp(ctx, 4) })
                }
                t.isEmpty() -> flushPara()
                else -> { if (para.isNotEmpty()) para.append('\n'); para.append(ln) }
            }
            i++
        }
        flushPara()
        return col
    }
}
