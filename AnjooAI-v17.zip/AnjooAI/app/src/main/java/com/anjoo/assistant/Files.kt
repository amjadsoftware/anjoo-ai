package com.anjoo.assistant

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Save, share and preview code or text: used by chat code cards, Code Studio and the preview screen. */
object Files {

    fun ext(lang: String) = when (lang.lowercase().trim()) {
        "python", "py" -> "py"; "kotlin", "kt" -> "kt"; "java" -> "java"
        "javascript", "js", "node", "jsx" -> "js"; "typescript", "ts", "tsx" -> "ts"
        "c++", "cpp" -> "cpp"; "c" -> "c"; "c#", "csharp", "cs" -> "cs"; "go" -> "go"
        "rust", "rs" -> "rs"; "php" -> "php"; "swift" -> "swift"; "dart", "flutter" -> "dart"
        "sql" -> "sql"; "bash", "shell", "sh", "zsh" -> "sh"; "html", "htm" -> "html"
        "css" -> "css"; "json" -> "json"; "xml" -> "xml"; "yaml", "yml" -> "yml"
        "markdown", "md" -> "md"; "svg" -> "svg"; "ruby", "rb" -> "rb"; "lua" -> "lua"
        else -> "txt"
    }

    fun mime(name: String) = when (name.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"; "css" -> "text/css"; "js" -> "text/javascript"
        "json" -> "application/json"; "svg" -> "image/svg+xml"; "zip" -> "application/zip"
        "md" -> "text/markdown"; else -> "text/plain"
    }

    fun isPreviewable(lang: String, code: String): Boolean {
        val l = lang.lowercase().trim()
        if (l in listOf("html", "htm", "svg", "javascript", "js", "markdown", "md")) return true
        return l.isEmpty() && code.trimStart().let { it.startsWith("<!DOCTYPE", true) || it.startsWith("<html", true) }
    }

    /** Writes into the public Downloads folder (Download/AnjooAI). Returns a short message for a Toast. */
    fun saveDownload(ctx: Context, name: String, bytes: ByteArray, mime: String = mime(name)): String {
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, mime)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/AnjooAI")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: return "Save nahi ho saka"
                ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                "Saved: Downloads/AnjooAI/$name"
            } else {
                val d = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "AnjooAI").also { it.mkdirs() }
                File(d, name).writeBytes(bytes)
                "Saved: " + File(d, name).absolutePath
            }
        } catch (e: Exception) { "Save nahi ho saka: " + (e.message ?: "") }
    }

    fun save(ctx: Context, name: String, text: String) =
        toast(ctx, saveDownload(ctx, name, text.toByteArray(Charsets.UTF_8)))

    fun saveZip(ctx: Context, zipName: String, files: List<Pair<String, String>>) {
        val bo = ByteArrayOutputStream()
        ZipOutputStream(bo).use { z ->
            for ((n, c) in files) { z.putNextEntry(ZipEntry(n)); z.write(c.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        }
        toast(ctx, saveDownload(ctx, zipName, bo.toByteArray(), "application/zip"))
    }

    fun share(ctx: Context, name: String, text: String) {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_SUBJECT, name).putExtra(Intent.EXTRA_TEXT, text)
        ctx.startActivity(Intent.createChooser(i, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun copy(ctx: Context, text: String) {
        (ctx.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager)
            .setPrimaryClip(android.content.ClipData.newPlainText("Anjoo", text))
        toast(ctx, "Copied")
    }

    fun toastSave(ctx: Context, m: String) = toast(ctx, m)

    private fun toast(ctx: Context, m: String) = Toast.makeText(ctx, m, Toast.LENGTH_SHORT).show()

    /** Joins <link href=x.css> and <script src=x.js> to the matching files, so a multi-file web project runs from one page. */
    fun bundle(html: String, files: Map<String, String>): String {
        if (files.isEmpty()) return html
        val byBase = files.entries.associate { it.key.substringAfterLast('/') to it.value }
        var out = Regex("<link[^>]*href=[\"']([^\"']+)[\"'][^>]*>", RegexOption.IGNORE_CASE).replace(html) { m ->
            val css = byBase[m.groupValues[1].substringAfterLast('/')]
            if (css != null && m.value.contains("stylesheet", true)) "<style>\n$css\n</style>" else m.value
        }
        out = Regex("<script([^>]*?)src=[\"']([^\"']+)[\"']([^>]*)>\\s*</script>", RegexOption.IGNORE_CASE).replace(out) { m ->
            val js = byBase[m.groupValues[2].substringAfterLast('/')]
            if (js != null) "<script${m.groupValues[1]}${m.groupValues[3]}>\n$js\n</script>" else m.value
        }
        return out
    }

    /** The full web page that shows this code. */
    fun pageFor(lang: String, code: String, files: Map<String, String> = emptyMap()): String {
        val l = lang.lowercase().trim()
        return when {
            l == "svg" -> "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><body style='margin:0;display:flex;justify-content:center;align-items:center;min-height:100vh;background:#fff'>$code"
            l in listOf("javascript", "js") -> jsPage(code)
            l in listOf("markdown", "md") -> mdPage(code)
            else -> bundle(code, files)
        }
    }

    /** A real, interactive WebView (JS, storage, alerts) used inside chat cards. */
    @android.annotation.SuppressLint("SetJavaScriptEnabled", "ClickableViewAccessibility")
    fun webView(ctx: Context, page: String): android.webkit.WebView {
        val w = android.webkit.WebView(ctx)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.settings.useWideViewPort = true
        w.webChromeClient = android.webkit.WebChromeClient()
        w.webViewClient = android.webkit.WebViewClient()
        w.setBackgroundColor(android.graphics.Color.WHITE)
        w.setOnTouchListener { v, _ -> v.parent?.requestDisallowInterceptTouchEvent(true); false }
        w.loadDataWithBaseURL("https://preview.local/", page, "text/html", "UTF-8", null)
        return w
    }

    fun preview(ctx: Context, name: String, lang: String, code: String, files: Map<String, String> = emptyMap()) =
        previewPage(ctx, name, pageFor(lang, code, files), code)

    /** Full-screen preview of a ready page. */
    fun previewPage(ctx: Context, name: String, page: String, source: String) {
        val dir = File(ctx.cacheDir, "preview").also { it.mkdirs() }
        val base = name.substringBeforeLast('.').ifEmpty { "preview" }
        val pf = File(dir, "$base.page.html").also { it.writeText(page, Charsets.UTF_8) }
        val sf = File(dir, name).also { it.writeText(source, Charsets.UTF_8) }
        ctx.startActivity(Intent(ctx, PreviewActivity::class.java)
            .putExtra("path", pf.absolutePath).putExtra("code", sf.absolutePath).putExtra("title", name)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun jsPage(code: String) = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<style>body{font:14px ui-monospace,monospace;margin:0;padding:12px;background:#1f1e1d;color:#ecebe6}.e{color:#ff8a80}.w{color:#ffd180}
#o div{padding:3px 0;border-bottom:1px solid #333;white-space:pre-wrap}</style><div id=o></div>
<script>
const o=document.getElementById('o');
function p(c,a){const d=document.createElement('div');d.className=c;d.textContent=a.map(x=>{try{return typeof x==='object'?JSON.stringify(x,null,2):String(x)}catch(e){return String(x)}}).join(' ');o.appendChild(d)}
['log','info','warn','error'].forEach(k=>{const f=console[k];console[k]=(...a)=>{p(k==='error'?'e':k==='warn'?'w':'l',a);f.apply(console,a)}});
window.onerror=(m,s,l)=>{p('e',[m+' (line '+l+')'])};
window.addEventListener('unhandledrejection',e=>p('e',['Unhandled: '+e.reason]));
</script><script>
try{
$code
}catch(e){console.error(e&&e.stack||e)}
</script>"""

    private fun mdPage(md: String): String {
        val sb = StringBuilder()
        var fence = false
        for (raw in md.lines()) {
            if (raw.trimStart().startsWith("```")) { sb.append(if (fence) "</pre>" else "<pre>"); fence = !fence; continue }
            if (fence) { sb.append(esc(raw)).append('\n'); continue }
            var t = esc(raw)
            t = t.replace(Regex("\\*\\*(.+?)\\*\\*"), "<b>$1</b>").replace(Regex("`([^`]+)`"), "<code>$1</code>")
            when {
                t.startsWith("### ") -> sb.append("<h3>").append(t.drop(4)).append("</h3>")
                t.startsWith("## ") -> sb.append("<h2>").append(t.drop(3)).append("</h2>")
                t.startsWith("# ") -> sb.append("<h1>").append(t.drop(2)).append("</h1>")
                t.startsWith("- ") || t.startsWith("* ") -> sb.append("<li>").append(t.drop(2)).append("</li>")
                t.isBlank() -> sb.append("<br>")
                else -> sb.append("<p>").append(t).append("</p>")
            }
        }
        return "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width,initial-scale=1'><style>body{font:16px/1.6 -apple-system,Roboto,sans-serif;max-width:720px;margin:0 auto;padding:16px;color:#1f1e1d;background:#faf9f5}pre{background:#f0eee6;padding:12px;border-radius:10px;overflow:auto}code{background:#f0eee6;padding:1px 5px;border-radius:5px}</style>$sb"
    }
}
