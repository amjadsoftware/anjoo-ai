package com.anjoo.assistant

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Code files only. Projects are built in the chat; here they are listed, opened, edited, downloaded and run.
 * Screens: projects -> files of one project -> one file (view / edit).
 */
class CodeActivity : Activity() {

    private lateinit var th: CyberTheme
    private lateinit var body: LinearLayout
    private lateinit var title: TextView
    private lateinit var actions: LinearLayout
    private var dir: File? = null
    private var file: String? = null
    private var editing = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dlg() = if (th.light) android.R.style.Theme_DeviceDefault_Light_Dialog_Alert else android.R.style.Theme_DeviceDefault_Dialog_Alert

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        th = Style.themes[getSharedPreferences("anjoo", MODE_PRIVATE).getInt("theme", Style.DEFAULT_THEME).coerceIn(0, Style.themes.size - 1)]
        try {
            window.statusBarColor = th.bg
            window.navigationBarColor = th.bg
            if (th.light) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        } catch (e: Exception) {}
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(th.bg); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(txt("‹") { goBack() }.apply { textSize = 24f })
        title = TextView(this).apply { setTextColor(th.ink); textSize = 20f; typeface = Typeface.create("serif", Typeface.NORMAL); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(bar)
        actions = LinearLayout(this).apply { setPadding(0, dp(6), 0, dp(6)) }
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(actions) })
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(body); isVerticalScrollBarEnabled = false }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        dir = intent.getStringExtra("project")?.let { File(it) }?.takeIf { it.isDirectory }
        show()
    }

    override fun onBackPressed() = goBack()

    private fun goBack() {
        when {
            file != null -> { if (editing) { editing = false } ; file = null; editing = false; show() }
            dir != null -> { dir = null; show() }
            else -> finish()
        }
    }

    private fun txt(label: String, accent: Boolean = true, on: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13.5f; setTextColor(if (accent) th.accent else th.muted)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(dp(10), dp(8), dp(10), dp(8)); setOnClickListener { on() }
    }

    private fun pill(label: String, filled: Boolean = false, on: () -> Unit) = TextView(this).apply {
        text = label; textSize = 13f; gravity = Gravity.CENTER
        setTextColor(if (filled) (if (th.light) Color.WHITE else th.bg) else th.ink)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        background = GradientDrawable().apply {
            setColor(if (filled) th.accent else Color.TRANSPARENT); cornerRadius = dp(18).toFloat()
            if (!filled) setStroke(dp(1), th.muted and 0x66FFFFFF)
        }
        setPadding(dp(14), dp(7), dp(14), dp(7))
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) }
        setOnClickListener { on() }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = GradientDrawable().apply {
            setColor(th.surface); cornerRadius = dp(14).toFloat(); setStroke(dp(1), th.muted and 0x44FFFFFF)
        }
        setPadding(dp(14), dp(12), dp(14), dp(12))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
    }

    private fun show() {
        body.removeAllViews(); actions.removeAllViews()
        val d = dir; val f = file
        when {
            d == null -> showProjects()
            f == null -> showFiles(d)
            else -> showFile(d, f)
        }
    }

    private fun showProjects() {
        title.text = "Code files"
        val ps = Coder.list(this)
        if (ps.isEmpty()) {
            body.addView(TextView(this).apply {
                text = "No projects yet.\n\nGo back to the chat and ask, for example:\n“Build a calculator app” or “Make a landing page for my shop”.\n\nThe code, live preview and every file appear in the chat, and the files are kept here."
                setTextColor(th.muted); textSize = 15f; setLineSpacing(0f, 1.25f); setPadding(dp(4), dp(24), dp(4), 0)
            })
            return
        }
        val fmt = SimpleDateFormat("d MMM, HH:mm", Locale.ENGLISH)
        for (p in ps) {
            val c = card()
            c.addView(TextView(this).apply { text = Coder.name(p); setTextColor(th.ink); textSize = 16.5f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL) })
            c.addView(TextView(this).apply { text = Coder.readFiles(p).size.toString() + " files  ·  " + fmt.format(Date(p.lastModified())); setTextColor(th.muted); textSize = 12.5f })
            c.setOnClickListener { dir = p; show() }
            c.setOnLongClickListener { confirmDeleteProject(p); true }
            body.addView(c)
        }
    }

    private fun entryOf(d: File): String? {
        val names = Coder.readFiles(d).keys
        return names.firstOrNull { it.equals("index.html", true) } ?: names.firstOrNull { it.endsWith(".html", true) }
    }

    private fun showFiles(d: File) {
        title.text = Coder.name(d)
        val files = Coder.readFiles(d)
        entryOf(d)?.let { e -> actions.addView(pill("▶ Run", true) { startActivity(Intent(this, PreviewActivity::class.java).putExtra("dir", d.absolutePath).putExtra("entry", e)) }) }
        actions.addView(pill("⬇ Zip") { Files.toastSave(this, Files.saveDownload(this, Coder.name(d).replace(Regex("[^A-Za-z0-9]+"), "-").trim('-').ifEmpty { "project" } + ".zip", Coder.zip(d), "application/zip")) })
        actions.addView(pill("＋ File") { newFile(d) })
        actions.addView(pill("Delete") { confirmDeleteProject(d) })
        for ((p, c) in files) {
            val row = card()
            row.addView(TextView(this).apply { text = p; setTextColor(th.ink); textSize = 14.5f; typeface = Typeface.MONOSPACE })
            row.addView(TextView(this).apply { text = (c.count { it == '\n' } + 1).toString() + " lines  ·  " + c.length + " chars"; setTextColor(th.muted); textSize = 12f })
            row.setOnClickListener { file = p; editing = false; show() }
            body.addView(row)
        }
    }

    private fun showFile(d: File, p: String) {
        title.text = p.substringAfterLast('/')
        val text = try { File(d, p).readText(Charsets.UTF_8) } catch (e: Exception) { "" }
        val ext = p.substringAfterLast('.', "")
        if (editing) {
            val et = EditText(this).apply {
                setText(text); typeface = Typeface.MONOSPACE; textSize = 12.5f; setTextColor(th.ink)
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
                gravity = Gravity.TOP; setHorizontallyScrolling(true)
                background = GradientDrawable().apply { setColor(th.surface); cornerRadius = dp(12).toFloat() }
                setPadding(dp(12), dp(10), dp(12), dp(10)); minLines = 18
            }
            actions.addView(pill("Save", true) {
                if (Coder.writeFile(d, p, et.text.toString())) { editing = false; Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show(); show() }
            })
            actions.addView(pill("Cancel") { editing = false; show() })
            body.addView(et, LinearLayout.LayoutParams(-1, -2))
        } else {
            actions.addView(pill("Edit", true) { editing = true; show() })
            actions.addView(pill("Copy") { Files.copy(this, text) })
            actions.addView(pill("Download") { Files.save(this, p.substringAfterLast('/'), text) })
            actions.addView(pill("Share") { Files.share(this, p, text) })
            if (ext.equals("html", true) || ext.equals("htm", true)) actions.addView(pill("▶ Run") {
                startActivity(Intent(this, PreviewActivity::class.java).putExtra("dir", d.absolutePath).putExtra("entry", p))
            })
            actions.addView(pill("Delete") {
                AlertDialog.Builder(this, dlg()).setMessage("Delete $p?").setPositiveButton("Delete") { _, _ ->
                    try { File(d, p).delete() } catch (e: Exception) {}
                    file = null; show()
                }.setNegativeButton("Cancel", null).show()
            })
            val tv = TextView(this).apply {
                this.text = Md.highlight(text, ext, th.light); typeface = Typeface.MONOSPACE; textSize = 12.5f
                setTextColor(th.ink); setTextIsSelectable(true); setHorizontallyScrolling(true)
                setPadding(dp(14), dp(12), dp(14), dp(14))
                background = GradientDrawable().apply { setColor(th.surface); cornerRadius = dp(12).toFloat() }
            }
            body.addView(HorizontalScrollView(this).apply { addView(tv) }, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun newFile(d: File) {
        val et = EditText(this).apply { hint = "folder/name.ext"; setSingleLine() }
        AlertDialog.Builder(this, dlg()).setTitle("New file").setView(et).setPositiveButton("Create") { _, _ ->
            val n = et.text.toString().trim()
            if (n.isNotEmpty() && Coder.writeFile(d, n, "")) { file = n; editing = true; show() }
            else Toast.makeText(this, "Naam theek nahi", Toast.LENGTH_SHORT).show()
        }.setNegativeButton("Cancel", null).show()
    }

    private fun confirmDeleteProject(p: File) {
        AlertDialog.Builder(this, dlg()).setMessage("Delete project “" + Coder.name(p) + "” and all its files?")
            .setPositiveButton("Delete") { _, _ -> Coder.delete(p); if (dir == p) dir = null; file = null; show() }
            .setNegativeButton("Cancel", null).show()
    }

    override fun onResume() { super.onResume(); if (!editing) show() }
}
