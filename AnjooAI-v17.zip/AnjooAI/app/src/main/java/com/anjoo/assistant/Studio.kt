package com.anjoo.assistant

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.webkit.WebView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Builds web pages and code from a spoken idea, saves them, and shows them. */
object Studio {

    private fun dir(ctx: Context) = File(ctx.filesDir, "studio").also { it.mkdirs() }

    fun files(ctx: Context): List<File> = (dir(ctx).listFiles()?.toList() ?: emptyList()).sortedByDescending { it.lastModified() }

    private fun strip(s: String): String {
        var t = s.trim()
        if (t.startsWith("```")) t = t.substringAfter("\n")
        if (t.endsWith("```")) t = t.substringBeforeLast("```")
        return t.trim()
    }

    private fun ext(lang: String) = when (lang.lowercase()) {
        "python", "py" -> "py"
        "kotlin" -> "kt"
        "java" -> "java"
        "javascript", "js", "node" -> "js"
        "typescript", "ts" -> "ts"
        "c++", "cpp" -> "cpp"
        "c" -> "c"
        "c#", "csharp" -> "cs"
        "go" -> "go"
        "rust" -> "rs"
        "php" -> "php"
        "swift" -> "swift"
        "dart", "flutter" -> "dart"
        "sql" -> "sql"
        "bash", "shell" -> "sh"
        "html" -> "html"
        else -> "txt"
    }

    private fun make(ctx: Context, system: String, ask: String, name: String, ext: String): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val key = p.getString("key", "") ?: ""
        if (key.isEmpty()) return "Pehle Gemini key dalein."
        val model = p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
        val out = strip(Gemini.plain(key, model, system, JSONArray().put(JSONObject().put("text", ask)), 12000))
        if (out.isBlank()) return "Kuch ban nahi saka, dobara koshish karein."
        val slug = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(24).ifEmpty { "project" }
        val f = File(dir(ctx), slug + "-" + (System.currentTimeMillis() / 1000) + "." + ext)
        f.writeText(out, Charsets.UTF_8)
        open(ctx, f)
        return "Bana diya aur screen par khol diya: " + f.name + " (" + out.length + " harf)."
    }

    fun page(ctx: Context, description: String): String = Coder.buildAndOpen(
        ctx,
        "Design and build a beautiful, modern, mobile-first, responsive web page or web app (index.html plus separate style.css and script.js if it is more than a simple page). Nice colour palette, spacing, typography, small animations, fully working interactions. Request: " + description,
        "HTML/CSS/JavaScript", false
    )

    fun code(ctx: Context, task: String, language: String): String = Coder.buildAndOpen(ctx, task, language, false)

    fun open(ctx: Context, f: File) {
        val i = Intent(ctx, PreviewActivity::class.java).putExtra("path", f.absolutePath).putExtra("title", f.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}

/** Full-screen live preview: real WebView, Preview/Code tabs, Reload, Copy, Download, Share. Can also serve a project folder. */
class PreviewActivity : Activity() {
    private var wv: WebView? = null

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val th = Style.themes[getSharedPreferences("anjoo", MODE_PRIVATE).getInt("theme", Style.DEFAULT_THEME).coerceIn(0, Style.themes.size - 1)]
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        val projectDir = intent.getStringExtra("dir")?.let { File(it) }
        val entry = intent.getStringExtra("entry") ?: "index.html"
        val pageFile = File(intent.getStringExtra("path") ?: "")
        val codeFile = File(intent.getStringExtra("code") ?: pageFile.absolutePath)
        val title = intent.getStringExtra("title") ?: (if (projectDir != null) entry else codeFile.name)
        val page = if (projectDir != null) "" else try { pageFile.readText(Charsets.UTF_8) } catch (e: Exception) { "File nahi khuli." }
        val source = try { if (projectDir != null) File(projectDir, entry).readText(Charsets.UTF_8) else codeFile.readText(Charsets.UTF_8) } catch (e: Exception) { page }
        val isHtml = projectDir != null || pageFile.name.endsWith(".html") || pageFile.name.endsWith(".htm")
        try {
            window.statusBarColor = th.bg
            if (th.light) window.decorView.systemUiVisibility = android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
        } catch (e: Exception) {}

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(th.bg) }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(8), dp(8), dp(8)) }
        val holder = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val tabs = ArrayList<TextView>()

        fun tab(label: String, on: () -> Unit): TextView = TextView(this).apply {
            text = label; textSize = 13f; gravity = Gravity.CENTER
            setPadding(dp(14), dp(7), dp(14), dp(7)); setOnClickListener { on() }
        }
        fun mark(sel: Int) = tabs.forEachIndexed { i, t ->
            t.setTextColor(if (i == sel) (if (th.light) Color.WHITE else th.bg) else th.muted)
            t.background = GradientDrawable().apply { setColor(if (i == sel) th.accent else Color.TRANSPARENT); cornerRadius = dp(16).toFloat() }
        }
        fun showCode() {
            mark(1); holder.removeAllViews()
            val tv = TextView(this).apply {
                text = Md.highlight(source, (if (projectDir != null) entry else codeFile.name).substringAfterLast('.', "html"), th.light)
                typeface = Typeface.MONOSPACE; textSize = 12.5f; setTextColor(th.ink); setTextIsSelectable(true)
                setPadding(dp(14), dp(10), dp(14), dp(14))
            }
            holder.addView(ScrollView(this).apply { addView(android.widget.HorizontalScrollView(context).apply { addView(tv) }) }, LinearLayout.LayoutParams(-1, -1))
        }
        fun showPage() {
            mark(0); holder.removeAllViews()
            val w = WebView(this)
            w.settings.javaScriptEnabled = true
            w.settings.domStorageEnabled = true
            w.settings.mediaPlaybackRequiresUserGesture = false
            w.webChromeClient = android.webkit.WebChromeClient()
            w.setBackgroundColor(Color.WHITE)
            if (projectDir != null) {
                val base = projectDir.canonicalPath
                w.webViewClient = object : android.webkit.WebViewClient() {
                    override fun shouldInterceptRequest(v: WebView, r: android.webkit.WebResourceRequest): android.webkit.WebResourceResponse? {
                        if (r.url.host != "preview.local") return null
                        val rel = (r.url.path ?: "/").trimStart('/').ifEmpty { entry }
                        val f = File(projectDir, rel)
                        return if (f.isFile && f.canonicalPath.startsWith(base))
                            android.webkit.WebResourceResponse(Files.mime(f.name), "UTF-8", java.io.FileInputStream(f)) else null
                    }
                }
                w.loadUrl("https://preview.local/$entry")
            } else {
                w.webViewClient = android.webkit.WebViewClient()
                w.loadDataWithBaseURL("https://preview.local/", page, "text/html", "UTF-8", null)
            }
            wv = w
            holder.addView(w, LinearLayout.LayoutParams(-1, -1))
        }
        fun txt(label: String, a: () -> Unit) = TextView(this).apply {
            text = label; textSize = 13f; setTextColor(th.accent); typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setPadding(dp(9), dp(8), dp(9), dp(8)); setOnClickListener { a() }
        }

        bar.addView(txt("‹ Back") { finish() })
        bar.addView(TextView(this).apply {
            text = title; setTextColor(th.ink); textSize = 14f; maxLines = 1; typeface = Typeface.MONOSPACE
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }, LinearLayout.LayoutParams(0, -2, 1f))
        if (isHtml) bar.addView(txt("↻") { if (showingPage) showPage() })
        bar.addView(txt("Copy") { Files.copy(this, source) })
        bar.addView(txt("Download") { Files.save(this, title.substringAfterLast('/'), source) })
        bar.addView(txt("Share") { Files.share(this, title, source) })
        root.addView(bar)

        if (isHtml) {
            val row = LinearLayout(this).apply { setPadding(dp(12), 0, dp(12), dp(8)) }
            tabs.add(tab("Preview") { showingPage = true; showPage() }); tabs.add(tab("Code") { showingPage = false; showCode() })
            tabs.forEach { row.addView(it, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(6) }) }
            root.addView(row)
        }
        root.addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (isHtml) showPage() else { tabs.add(TextView(this)); tabs.add(TextView(this)); showCode() }
    }

    private var showingPage = true

    override fun onBackPressed() {
        val w = wv
        if (showingPage && w != null && w.canGoBack()) w.goBack() else super.onBackPressed()
    }

    override fun onDestroy() { try { wv?.destroy() } catch (e: Exception) {}; super.onDestroy() }
}
