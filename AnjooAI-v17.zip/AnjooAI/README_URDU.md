# Anjoo AI: Android awaazi assistant

Mic dabayein aur bolein. Gemini hukm samajhta hai aur phone par kaam karta hai.

## Kya kar sakta hai
- Koi bhi installed app kholna ("WhatsApp kholo", "YouTube kholo")
- Contacts se naam dhoond kar call karna (call se pehle "Haan/Nahi" poochta hai)
- SMS bhejna (bhejne se pehle poochta hai)
- WhatsApp chat kholna aur paigham likh dena (send ka button aap dabate hain)
- Alarm aur timer lagana
- Web search, website kholna, Maps mein rasta
- Jawab awaaz mein bhi sunata hai (agar phone mein Urdu/English voice maujood ho)

## Jo nahi kar sakta
- Doosri apps ke andar khud tap karna (jaise bank app mein paise bhejna). Yeh jaan boojh kar nahi rakha.
- WhatsApp ka paigham khud send karna. Android is ki ijazat nahi deta, aap ko ek tap karna hota hai.

## Banane ke qadam (pehli baar)
1. Computer par Android Studio install karein (developer.android.com/studio).
2. Android Studio mein File > Open, aur is `AnjooAI` folder ko kholein. Gradle sync poora hone dein (internet chahiye, pehli baar kuch minute lagte hain).
3. Phone mein Settings > About phone > Build number par 7 baar tap karein, phir Developer options mein USB debugging on karein.
4. Phone ko USB se jorain, Android Studio mein upar ka hara Run button dabayein. App phone par install ho jayegi.
   (Ya Build > Build APK(s) se APK bana kar phone mein copy karke install karein.)

## Pehli dafa istemal
1. App kholte hi Settings aayegi. Apni Gemini API key dalein: aistudio.google.com/apikey par apne Google account se "Create API key" dabayein. Model "gemini-3.8-flash" rakhein (ya wahan ki list se jo naam dikhe).
2. Mic, contacts, call aur SMS ki ijazat "Allow" karein.
3. Mic dabayein aur bolein: "Ahmed ko call karo", "Subah 6 baje ka alarm lagao", "WhatsApp kholo".
   Zubaan ka button "اردو / English" bolne ki zubaan badalta hai.

## Zaroori baatein
- Gemini Pro subscription aur API key do alag cheezein hain. Key AI Studio se banti hai, us par free limit hoti hai aur us se zyada istemal par kharcha ho sakta hai. Key kisi ko na dein; yeh sirf aap ke phone mein rehti hai.
- WhatsApp ke liye "0300..." wale number Pakistan ke code (92) mein badal diye jate hain.
- Awaaz pehchaan Google ki service use karti hai, is liye internet aur Google app chahiye.
- Pehle kuch din call/SMS ki tasdeeq wali screen par nazar rakhein ke naam aur number sahi hain.

## v12 naye kaam
- Naya Anjoo AI app icon (robot + neon circuit).
- Markhor hata diya: ab ek cute robot (Buddy) screen par ghoomta hai, aapki baat par chehre ke expressions badalta hai (khush, pyar, udaas, hairan, soch, sunna, neend).
- Mouse jaisa arrow (cursor): jab Anjoo koi kaam kare (tap, likhna, back/home, scroll, app kholna) to arrow dusri apps ke upar bhi dikhta hai ke kahan ja raha hai. Iske liye Accessibility on honi chahiye.
- Awaaz pehchan behtar aur tez: jumla 0.7 sec khamoshi par poora, jawab ki awaz pehle jumle se shuru, Anjoo soch raha ho tab bhi aapki nayi baat sunta hai, aur samajhne par chhoti beep aati hai.

## v14 Code Studio (Claude jaisi coding)
- Menu > "Code Studio": likhein ya bolein kya banana hai. Pehle architecture plan, phir poora multi-file project (README aur dependency file samet), phir bug review.
- Project ke har file ka tab: dekhein, Copy, Share, haath se Edit/Save.
- Badlav: "dark mode lagao", "login add karo" likhein, sirf zaroori files badalti hain. Ask: koi bhi code ya bug ka sawal, project dekh kar jawab.
- Web projects ke liye Run (live preview), Zip se poora project save.
- Awaaz se: "Anjoo, ek calculator app banao" (write_code) ya "isme history add karo" (edit_code).

## v15 fixes
- Screen par "starting / loading" wali boot lines hata di (sirf ek chhota greeting). Rotate/theme change par screen dobara start nahi hoti.
- Apni awaaz khud sunna band: loudspeaker par bolte waqt mic mute, bolne ke baad 0.7 sec echo khatam hone ka intezar, aur apna hi jumla wapas aaye to ignore. Headset lagao to "ruko" bol kar beech mein rok sakte ho.
- Slow bolne wale ke liye: khamoshi ka intezar 1.1-1.4 sec, adhoora jumla (2 lafz ya "aur/ya/ko" par khatam) 0.9 sec mazeed ruk kar agle hisse se jud jata hai; mukammal jumla foran chalta hai.
- Galat/adhoore lafz: um/uh, dohrane, "nahi nahi" wali ghalti theek karke sahi lafz likhta hai.
- RainView.kt hata diya.

## v16 Claude-style interface, coding aur files
- Naya default look: "CLAUDE" (light) aur "CLAUDE DARK". Menu > Appearance se purane cyber themes bhi milte hain.
- Chat screen: saaf header, khali chat par "How can I help you today?" aur 4 starter, user ka bubble, jawab bina dabbe ke markdown mein (headings, bold, lists, `inline code`), neeche Copy/Share. Composer ek gol pill: + (image), text, mic, send. Buddy robot ab app ke andar chhupa hai (Menu mein ON kar sakte hain), baahar floating bubble pehle jaisa.
- Chat mein code ke cards: syntax colours, file ka naam, aur Copy, Save (Downloads/AnjooAI), Share, aur HTML/SVG/JS/Markdown par "Preview". Aik jawab mein 2+ named files hon to "Download all files (.zip)".
- Preview screen: Preview/Code tabs, JS ke liye console output, Copy, Download, Share.
- Code Studio: wahi cards, har file par Save button, syntax colours.
- Zyada advance prompts: pehle sochna aur check karna, tests, polished UI, har file mukammal, bug mein pehle wajah phir fix; chat mein jawab pehle phir tafseel, lambay matn par TL;DR/key points.

## v17 sidebar, chat mein sab kuch, Code Studio sirf files
- Sidebar (☰ ya left edge se swipe): New chat, Code files, Search chats, Recents (Today / Yesterday / Previous 7 days / Older, dabaye rakho = delete), Voice assistant on/off, Settings. Purani "Settings" list ab sirf settings rakhti hai.
- Chat mein code ka live "artifact" card: asli WebView (JS, alert, storage), Preview/Code tabs, ⤢ full screen, Copy/Download/Share. Alag style.css / script.js ho to ek page mein jur kar chalte hain.
- Project banane par (type karo ya bolo) sab chat mein aata hai: upar live preview, phir "Project · N files" card jis mein har file kholo/Copy/Save, ▶ Run aur ⬇ Zip.
- Full screen preview: Preview/Code, ↻ reload, Copy, Download, Share.
- Code Studio ab sirf code files ka manager hai: projects → files → file (dekhna, Edit/Save, Copy, Download, Share, Delete, ＋ File), ▶ Run, ⬇ Zip. Banana sirf chat se hota hai.
