package com.anjoo.assistant

import android.content.Context
import android.graphics.Color

/** A colour mode for the cyber look. */
class CyberTheme(
    val name: String,
    bg: String, surface: String, accent: String, user: String, ink: String, muted: String
) {
    val bg = Color.parseColor(bg)
    val surface = Color.parseColor(surface)
    val accent = Color.parseColor(accent)
    val user = Color.parseColor(user)
    val ink = Color.parseColor(ink)
    val muted = Color.parseColor(muted)
}

/** A "cyber officer" persona: changes the way Anjoo talks and sounds (purely a style). */
class Officer(
    val code: String,
    val role: String,
    val persona: String,
    val pitch: Float,
    val rate: Float,
    val greet: String
)

object Style {
    val themes = listOf(
        CyberTheme("MATRIX", "#020B05", "#071A0F", "#00FF66", "#0B4A25", "#CFFFE0", "#5FA67C"),
        CyberTheme("CYBER BLUE", "#02070F", "#07152A", "#00E5FF", "#0A3B66", "#D8F6FF", "#5C8FA8"),
        CyberTheme("RED ALERT", "#0D0204", "#1E070C", "#FF2D55", "#5E0F22", "#FFDDE3", "#A8606D"),
        CyberTheme("PURPLE HAZE", "#07020F", "#150A29", "#C77DFF", "#43206B", "#F1E3FF", "#8F70AD")
    )

    val officers = listOf(
        Officer(
            "ZERO", "Red Team Lead",
            "Tumhari shakhsiyat: Officer ZERO, cyber unit ka Red Team Lead. Seedhe, tez aur confident andaz mein bolo, jaise mission report de rahe ho (\"Done.\", \"Target locked.\"). Hamesha mohazzab raho.",
            0.75f, 1.0f, "ZERO online. Mission batayein, boss."
        ),
        Officer(
            "GHOST", "Stealth Operator",
            "Tumhari shakhsiyat: Officer GHOST, khamosh stealth operator. Bohat mukhtasar, dheemay aur raaz-daari wale andaz mein bolo. Jawab sirf ek chhota jumla.",
            0.6f, 0.9f, "GHOST active. Bolein."
        ),
        Officer(
            "NOOR", "Cyber Intel Analyst",
            "Tumhari shakhsiyat: Officer NOOR, cyber intelligence analyst. Narmi, saaf aur madadgaar andaz mein bolo, thori si tehzeeb ke saath.",
            1.25f, 1.0f, "NOOR hazir hai. Kya kaam karun?"
        ),
        Officer(
            "SHIELD", "Defense Commander",
            "Tumhari shakhsiyat: Officer SHIELD, defense commander. Fauji, disciplined andaz mein bolo (\"Roger.\", \"Copy that.\", \"Order executed.\").",
            0.9f, 1.1f, "SHIELD standing by. Hukm dein, sir."
        )
    )

    const val FRIEND = "PERSONALITY: Be warm, friendly, patient, respectful, and genuinely useful—like a trusted human assistant. Use natural conversational Urdu, Roman Urdu, or English; never force a language the user did not use. Help with general knowledge, writing, translation, study, planning, brainstorming, coding, troubleshooting, and available phone tasks. Be emotionally considerate without theatrical mood changes or exaggerated roleplay. Give clear step-by-step help when useful. Be honest about uncertainty and limitations. Do not pretend to be human; simply use natural human-sounding language. Respect the user's exact intent and never take unrequested actions. Use available tools when appropriate, and verify results before reporting completion. Save personal details only when the user explicitly asks you to remember them."

    /** Extra prompt lines that depend on the current modes and the latest message. */
    fun extra(ctx: Context): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val sb = StringBuilder()
        val tr = p.getString("translator", "") ?: ""
        if (tr.isNotEmpty()) sb.append("TARJUMAN MODE ON: user ki har baat ka sirf ").append(tr).append(" mein tarjuma bolo, aur kuch nahi, jab tak user band karne ko na kahe.\n")
        val n = NotifState.contextLine()
        if (n.isNotEmpty()) sb.append(n).append("\n")
        try {
            val r = org.json.JSONObject(p.getString("routines", "{}") ?: "{}")
            if (r.length() > 0) {
                sb.append("User ke sikhaye hue routines (user in naamon se bulaye to unke steps tools se poore karo):\n")
                for (k in r.keys()) sb.append("- ").append(k).append(": ").append(r.getString(k)).append("\n")
            }
        } catch (e: Exception) {}
        sb.append(ChatStore.recentContext(ctx))
        return sb.toString()
    }

    fun officer(ctx: Context): Officer {
        val i = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getInt("officer", 0)
        return officers[i.coerceIn(0, officers.size - 1)]
    }
}
