package com.anjoo.assistant

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.SystemClock
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * A natural, human-sounding voice from Gemini's speech model. Any failure returns false so the caller
 * can fall back to the phone's own voice.
 */
object GeminiVoice {

    private const val DEFAULT_MODEL = "gemini-2.5-flash-preview-tts"
    @Volatile private var track: AudioTrack? = null
    @Volatile private var stopFlag = false
    @Volatile private var failUntil = 0L

    fun enabled(ctx: Context): Boolean =
        ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE).getBoolean("human", true)

    fun voiceFor(ctx: Context): String = when (ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        .getString("voiceGender", "female")) {
        "male" -> "Orus"
        else -> "Aoede"
    }

    fun stop() {
        stopFlag = true
        try { track?.stop() } catch (e: Exception) {}
    }

    /** Speaks [text] and returns when playback has finished. Returns false if it could not. */
    fun say(ctx: Context, text: String): Boolean {
        val prefs = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        val key = prefs.getString("key", "") ?: ""
        if (key.isEmpty() || !enabled(ctx)) return false
        if (SystemClock.elapsedRealtime() < failUntil) return false
        val model = prefs.getString("ttsModel", DEFAULT_MODEL)?.ifBlank { DEFAULT_MODEL } ?: DEFAULT_MODEL
        stopFlag = false
        return try {
            val pcm = synth(key, model, voiceFor(ctx), text.take(700))
            if (stopFlag) true else play(pcm.first, pcm.second)
        } catch (e: Exception) {
            failUntil = SystemClock.elapsedRealtime() + 90000
            false
        }
    }

    private fun synth(key: String, model: String, voice: String, text: String): Pair<ByteArray, Int> {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(
                JSONObject().put("text", "Speak the following exactly as written, in a natural, warm, clear conversational human voice. Match Urdu, Roman Urdu, and English pronunciation naturally. Use a calm pace, not a robotic or theatrical tone: $text")
            ))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put(
                    "prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 40000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
            ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) throw java.io.IOException("tts $code")
        val inline = JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData")
        val data = Base64.decode(inline.getString("data"), Base64.DEFAULT)
        val rate = Regex("rate=(\\d+)").find(inline.optString("mimeType", ""))?.groupValues?.get(1)?.toInt() ?: 24000
        return Pair(data, rate)
    }

    private fun play(pcm: ByteArray, rate: Int): Boolean {
        if (pcm.size < 2) return false
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
            )
            .setBufferSizeInBytes(pcm.size)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = t
        t.write(pcm, 0, pcm.size)
        t.play()
        val frames = pcm.size / 2
        val deadline = SystemClock.elapsedRealtime() + frames * 1000L / rate + 2000
        while (!stopFlag && t.playbackHeadPosition < frames && SystemClock.elapsedRealtime() < deadline) {
            try { Thread.sleep(60) } catch (e: InterruptedException) { break }
        }
        try { t.stop() } catch (e: Exception) {}
        t.release()
        track = null
        return true
    }
}
