package com.anjoo.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** An HTTP error from the Gemini API, keeping the status code so callers can decide to retry. */
class ApiException(val code: Int, message: String) : IOException(message)

/** Talks to the Gemini generateContent API with phone-action tools. */
object Gemini {

    private val FALLBACKS = listOf("gemini-3.6-flash", "gemini-3.5-flash-lite")

    /**
     * Tries the chosen model, retries once when Google says it is busy (500/503/504),
     * and moves on to the next model when this one is unknown (404) or out of quota (429).
     */
    fun sendWithFallback(
        key: String, model: String, system: String, contents: JSONArray,
        withTools: Boolean = true, maxTokens: Int = 1024
    ): JSONObject {
        val models = (listOf(model) + FALLBACKS).distinct()
        var last: Exception? = null
        for (m in models) {
            for (attempt in 0..1) {
                try {
                    return send(key, m, system, contents, withTools, maxTokens)
                } catch (e: ApiException) {
                    last = e
                    val busy = e.code == 500 || e.code == 503 || e.code == 504
                    if (busy) {
                        if (attempt == 0) Thread.sleep(1500)
                        continue
                    }
                    if (e.code == 404 || e.code == 429) break
                    throw e
                } catch (e: java.net.SocketTimeoutException) {
                    last = e
                    break
                } catch (e: IOException) {
                    // dropped connection ("connection abort"): try again once
                    last = e
                    if (attempt == 0) Thread.sleep(1000)
                    continue
                }
            }
        }
        throw last ?: IOException("Jawab nahi mila.")
    }

    private const val DECLARATIONS = """
    [
      {"name":"open_app","description":"Phone par koi app kholo. App ka naam English mein do, jaise WhatsApp, YouTube, Camera, Settings, Chrome, Maps, Gallery, Calculator.",
       "parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}},
      {"name":"find_contact","description":"Contacts mein naam se number talash karo.",
       "parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}},
      {"name":"call","description":"Kisi ko call karo. 'to' mein contact ka naam ya phone number do. Call se pehle app khud user se tasdeeq lega.",
       "parameters":{"type":"object","properties":{"to":{"type":"string"}},"required":["to"]}},
      {"name":"send_sms","description":"SMS bhejo. 'to' mein contact ka naam ya number. Bhejne se pehle app user se tasdeeq lega.",
       "parameters":{"type":"object","properties":{"to":{"type":"string"},"text":{"type":"string"}},"required":["to","text"]}},
      {"name":"whatsapp_message","description":"WhatsApp chat kholo aur paigham likh do. User ko bhejne ka button khud dabana hota hai.",
       "parameters":{"type":"object","properties":{"to":{"type":"string"},"text":{"type":"string"}},"required":["to","text"]}},
      {"name":"set_alarm","description":"Alarm lagao (24 ghante ka waqt).",
       "parameters":{"type":"object","properties":{"hour":{"type":"integer"},"minute":{"type":"integer"},"label":{"type":"string"}},"required":["hour","minute"]}},
      {"name":"set_timer","description":"Countdown timer lagao, seconds mein.",
       "parameters":{"type":"object","properties":{"seconds":{"type":"integer"},"label":{"type":"string"}},"required":["seconds"]}},
      {"name":"web_search","description":"Browser mein web search kholo.",
       "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
      {"name":"open_url","description":"Koi website kholo.",
       "parameters":{"type":"object","properties":{"url":{"type":"string"}},"required":["url"]}},
      {"name":"navigate","description":"Maps mein kisi jagah ka rasta kholo.",
       "parameters":{"type":"object","properties":{"place":{"type":"string"}},"required":["place"]}},
      {"name":"flashlight","description":"Torch (flashlight) on ya off karo.",
       "parameters":{"type":"object","properties":{"on":{"type":"boolean"}},"required":["on"]}},
      {"name":"volume","description":"Awaaz (volume) badlo. action: up, down, mute, unmute ya max.",
       "parameters":{"type":"object","properties":{"action":{"type":"string"}},"required":["action"]}},
      {"name":"media","description":"Chalti hui music ya video ko control karo. action: play_pause, next ya previous.",
       "parameters":{"type":"object","properties":{"action":{"type":"string"}},"required":["action"]}},
      {"name":"battery","description":"Battery kitni hai aur charge ho rahi hai ya nahi."},
      {"name":"add_calendar_event","description":"Calendar mein event ya reminder banao. datetime ka format YYYY-MM-DD HH:mm (phone ka apna waqt). User ko save dabana hoga.",
       "parameters":{"type":"object","properties":{"title":{"type":"string"},"datetime":{"type":"string"},"duration_minutes":{"type":"integer"}},"required":["title","datetime"]}},
      {"name":"send_email","description":"Email ka draft kholo. User ko send dabana hoga.",
       "parameters":{"type":"object","properties":{"to":{"type":"string"},"subject":{"type":"string"},"body":{"type":"string"}},"required":["subject","body"]}},
      {"name":"open_settings","description":"Phone ki settings kholo. page: wifi, bluetooth, display, sound, battery, location, apps ya main.",
       "parameters":{"type":"object","properties":{"page":{"type":"string"}},"required":["page"]}},
      {"name":"copy_text","description":"Text clipboard mein copy karo taake user kahin bhi paste kar sake.",
       "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
      {"name":"type_text","description":"Jo app abhi screen par khuli hai uske text box mein text likho. Pehle app kholo aur zaroorat ho to tap_text se text box chuno. append true ho to purane text ke baad jodo.",
       "parameters":{"type":"object","properties":{"text":{"type":"string"},"append":{"type":"boolean"}},"required":["text"]}},
      {"name":"tap_text","description":"Screen par jis button ya label par yeh lafz likha ho use dabao (jaise Send, Search, Chats).",
       "parameters":{"type":"object","properties":{"label":{"type":"string"}},"required":["label"]}},
      {"name":"press_key","description":"Phone ka key dabao: back, home, recents, notifications, scroll_down ya scroll_up.",
       "parameters":{"type":"object","properties":{"key":{"type":"string"}},"required":["key"]}},
      {"name":"read_screen","description":"Abhi screen par jo likha hai woh parho, taake pata chale kya khula hai.",
       "parameters":{"type":"object","properties":{}}},
      {"name":"weather","description":"Kisi shehar ka mausam batao (abhi ka aur aaj ka). city English mein do, jaise Lahore, Riyadh.",
       "parameters":{"type":"object","properties":{"city":{"type":"string"}},"required":["city"]}},
      {"name":"play_music","description":"Gaana ya music chalao. query mein gaane/artist ka naam do.",
       "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
      {"name":"share_text","description":"Text ko kisi bhi app (WhatsApp, Telegram wagaira) par share karne ka menu kholo.",
       "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
      {"name":"read_sms","description":"Inbox ke taaza SMS parho. count kitne SMS (default 3), from mein number ka hissa (optional).",
       "parameters":{"type":"object","properties":{"count":{"type":"integer"},"from":{"type":"string"}}}},
      {"name":"today_events","description":"Aaj ke calendar ke programs/events batao.",
       "parameters":{"type":"object","properties":{}}},
      {"name":"set_reminder","description":"Yaad dihani lagao jo waqt par awaaz se bole. minutes (abhi se kitne minute baad) YA datetime ('yyyy-MM-dd HH:mm', local waqt) do. text mein kya yaad dilana hai.",
       "parameters":{"type":"object","properties":{"text":{"type":"string"},"minutes":{"type":"integer"},"datetime":{"type":"string"}},"required":["text"]}},
      {"name":"list_reminders","description":"Lagi hui yaad dihaniyan dikhao.",
       "parameters":{"type":"object","properties":{}}},
      {"name":"cancel_reminder","description":"Yaad dihani hatao. text mein uska koi lafz do.",
       "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
      {"name":"set_daily_briefing","description":"Roz subah ek waqt par mausam, programs aur yaad dihaniyon ka briefing sunao. hour (0-23), minute. on false se band.",
       "parameters":{"type":"object","properties":{"hour":{"type":"integer"},"minute":{"type":"integer"},"on":{"type":"boolean"}},"required":["hour"]}},
      {"name":"convert_currency","description":"Currency badlo, live rate se. from/to 3 harfi code jaise SAR, PKR, USD.",
       "parameters":{"type":"object","properties":{"amount":{"type":"number"},"from":{"type":"string"},"to":{"type":"string"}},"required":["amount","from","to"]}},
      {"name":"news","description":"Taaza khabrein ya kisi topic (jaise cricket score, petrol price) ki headlines. topic khali ho to aam khabrein.",
       "parameters":{"type":"object","properties":{"topic":{"type":"string"}}}},
      {"name":"prayer_times","description":"Kisi shehar ki namaz ke auqaat. city aur country English mein.",
       "parameters":{"type":"object","properties":{"city":{"type":"string"},"country":{"type":"string"}},"required":["city","country"]}},
      {"name":"set_prayer_reminders","description":"Har namaz ke waqt par roz khud yaad dilao. on false se band.",
       "parameters":{"type":"object","properties":{"city":{"type":"string"},"country":{"type":"string"},"on":{"type":"boolean"}},"required":["city"]}},
      {"name":"ledger_add","description":"Hisaab diary mein entry. kind: kharcha, aamdani, udhaar_diya (maine kisi ko diya), udhaar_liya, wapsi_mili (unhon ne lauta diya), wapsi_di (maine lauta diya). person optional.",
       "parameters":{"type":"object","properties":{"kind":{"type":"string"},"amount":{"type":"number"},"currency":{"type":"string"},"note":{"type":"string"},"person":{"type":"string"}},"required":["kind","amount"]}},
      {"name":"ledger_summary","description":"Hisaab diary ka khulasa. period: today, week, month ya all. person optional (kisi ka udhaar).",
       "parameters":{"type":"object","properties":{"period":{"type":"string"},"person":{"type":"string"}}}},
      {"name":"set_translator","description":"Tarjumaan mode on/off. on true ho to language mein (jaise Arabic, English, Urdu) har baat ka tarjuma hoga.",
       "parameters":{"type":"object","properties":{"on":{"type":"boolean"},"language":{"type":"string"}}}},
      {"name":"read_notifications","description":"WhatsApp/SMS/Telegram ke taaza aaye hue messages parho.",
       "parameters":{"type":"object","properties":{"count":{"type":"integer"}}}},
      {"name":"reply_message","description":"Aakhri aaye hue message ka usi chat mein jawab bhejo. Bhejne se pehle app user se tasdeeq lega.",
       "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
      {"name":"set_auto_reply","description":"Aate hue personal messages ko khud jawab do (jaise 'main gaari chala raha hoon'). on false se band.",
       "parameters":{"type":"object","properties":{"on":{"type":"boolean"},"text":{"type":"string"}}}},
      {"name":"create_page","description":"User ke bayan ke mutabiq khoobsurat modern web page / app screen ka design banao aur screen par live dikhao. description mein poori tafseel do.",
       "parameters":{"type":"object","properties":{"description":{"type":"string"}},"required":["description"]}},
      {"name":"write_code","description":"Kisi bhi programming language mein mukammal code likho (jaise Python, Kotlin, JavaScript, Java, C++). task mein kya banana hai, language mein zubaan.",
       "parameters":{"type":"object","properties":{"task":{"type":"string"},"language":{"type":"string"}},"required":["task"]}},
      {"name":"save_routine","description":"Nayi aadat/shortcut sikho: jab user name kahe to steps karne hain. steps mein saaf likho kya kya karna hai.",
       "parameters":{"type":"object","properties":{"name":{"type":"string"},"steps":{"type":"string"}},"required":["name","steps"]}},
      {"name":"delete_routine","description":"Sikhaya hua routine bhula do.",
       "parameters":{"type":"object","properties":{"name":{"type":"string"}},"required":["name"]}},
      {"name":"search_chats","description":"Purani baat-cheet mein koi lafz dhoondo (kab, kis topic par kya baat hui thi).",
       "parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"]}},
      {"name":"remember","description":"User ki koi zaroori baat yaad rakho, jab woh 'yaad rakho' kahe ya koi pakki maloomat de (jaise rishtedaron ke naam, aadatein).",
       "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}},
      {"name":"forget","description":"Yaad rakhi hui baat bhula do. text mein us baat ka koi lafz do.",
       "parameters":{"type":"object","properties":{"text":{"type":"string"}},"required":["text"]}}
    ]
    """

    private val tools: JSONArray = JSONArray()
        .put(JSONObject().put("functionDeclarations", JSONArray(DECLARATIONS)))

    /** One question, no tools. Returns the model's text. */
    fun plain(key: String, model: String, system: String, parts: JSONArray, maxTokens: Int = 1024): String {
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))
        val r = sendWithFallback(key, model, system, contents, false, maxTokens)
        val ps = r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
            ?: return ""
        val sb = StringBuilder()
        for (i in 0 until ps.length()) {
            val p = ps.getJSONObject(i)
            if (p.has("text") && !p.optBoolean("thought", false)) sb.append(p.getString("text"))
        }
        return sb.toString().trim()
    }

    /** Turns a spoken sentence (16 kHz PCM) into text. Blank when there was no clear human speech. */
    fun transcribe(key: String, model: String, pcm: ByteArray): String {
        val parts = JSONArray()
            .put(JSONObject().put("text", "Is awaaz mein insaan ne jo bola use bilkul waisa hi likho, usi zubaan aur script mein jis mein bola gaya (Urdu, Roman Urdu ya English). Sirf bola hua text do, koi tashreeh ya tarjuma nahi. Agar koi saaf insaani baat na ho (shor, khamoshi, sirf saans) to sirf ek hyphen - likho."))
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav")
                .put("data", android.util.Base64.encodeToString(Ear.wav(pcm), android.util.Base64.NO_WRAP))))
        val t = plain(key, model, "Tum sirf awaaz ko text mein likhne wale transcriber ho.", parts)
        val c = t.trim().trim('"')
        return if (c == "-" || c.length < 2) "" else c
    }

    /** contents: the running conversation in Gemini format. Returns the first candidate's response JSON. */
    fun send(
        key: String, model: String, system: String, contents: JSONArray,
        withTools: Boolean = true, maxTokens: Int = 1024
    ): JSONObject {
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens))
        if (withTools) body.put("tools", tools)

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent")
        val conn = url.openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 20000
        conn.readTimeout = if (maxTokens > 2000) 170000 else 60000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        conn.setRequestProperty("x-goog-api-key", key)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val detail = try {
                JSONObject(text).getJSONObject("error").getString("message")
            } catch (e: Exception) {
                text.take(200)
            }
            val hint = when (code) {
                400, 403 -> if (detail.contains("API key", ignoreCase = true)) "API key galat hai. Settings mein dobara dalein." else detail
                404 -> "Model '$model' nahi mila. Settings mein model ka naam check karein."
                429 -> "Bohat zyada requests ya free limit khatam. Thori der ruk kar try karein."
                else -> detail
            }
            throw ApiException(code, "($code) $hint")
        }
        return JSONObject(text)
    }
}
