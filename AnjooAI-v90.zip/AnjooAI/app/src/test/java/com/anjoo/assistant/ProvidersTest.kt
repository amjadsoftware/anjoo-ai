package com.anjoo.assistant

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.IOException

/** Provider list integrity and the rules that decide when Auto mode moves to the next free AI. */
class ProvidersTest {

    @Test fun providerIdsAreUnique() {
        val ids = Providers.ALL.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }

    @Test fun everyProviderHasALabelAndKnownKind() {
        for (p in Providers.ALL) {
            assertTrue("label of ${p.id}", p.label.isNotBlank())
            assertTrue("kind of ${p.id}", p.kind in setOf("gemini", "openai", "anthropic"))
        }
    }

    @Test fun freeProvidersAreAvailable() {
        for (id in listOf("gemini", "groq", "openrouter")) {
            assertEquals(id, Providers.byId(id).id)
        }
    }

    @Test fun unknownProviderFallsBackToTheFirst() {
        assertEquals(Providers.ALL[0].id, Providers.byId("no-such-provider").id)
        assertEquals(Providers.ALL[0].id, Providers.byId(null).id)
    }

    @Test fun quotaServerAndKeyErrorsFailOver() {
        assertTrue(Providers.shouldFailOver(ApiException(429, "quota")))
        assertTrue(Providers.shouldFailOver(ApiException(503, "busy")))
        assertTrue(Providers.shouldFailOver(ApiException(401, "bad key")))
        assertTrue(Providers.shouldFailOver(ApiException(404, "no model")))
    }

    @Test fun badRequestsDoNotFailOver() {
        assertFalse(Providers.shouldFailOver(ApiException(400, "bad request")))
        assertFalse(Providers.shouldFailOver(ApiException(422, "unprocessable")))
    }

    @Test fun networkErrorsFailOverButStopDoesNot() {
        assertTrue(Providers.shouldFailOver(IOException("connection reset")))
        assertFalse(Providers.shouldFailOver(CancelledException()))
        assertFalse(Providers.shouldFailOver(IllegalStateException("bug")))
    }
}
