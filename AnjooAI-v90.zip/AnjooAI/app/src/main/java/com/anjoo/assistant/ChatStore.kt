package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps every chat on the phone, grouped by topic, so Anjoo can remember what was talked about. */
object ChatStore {
    private const val FILE = "chats.json"
    private const val MAX_SESSIONS = 500
    private const val MAX_LINES = 2000

    private fun file(ctx: Context) = File(ctx.filesDir, FILE)
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)

    @Synchronized
    fun all(ctx: Context): JSONArray = try {
        JSONArray(file(ctx).takeIf { it.exists() }?.readText(Charsets.UTF_8) ?: "[]")
    } catch (e: Exception) { JSONArray() }

    @Synchronized
    fun replaceAll(ctx: Context, a: JSONArray) {
        file(ctx).writeText(a.toString(), Charsets.UTF_8)
    }

    private fun find(a: JSONArray, id: Long): JSONObject? {
        for (i in 0 until a.length()) if (a.getJSONObject(i).getLong("id") == id) return a.getJSONObject(i)
        return null
    }

    fun currentId(ctx: Context): Long = prefs(ctx).getLong("chatId", 0L)

    @Synchronized
    fun newSession(ctx: Context): Long {
        val a = all(ctx)
        val id = System.currentTimeMillis()
        a.put(JSONObject().put("id", id).put("title", "").put("start", id).put("last", id).put("lines", JSONArray()))
        while (a.length() > MAX_SESSIONS) a.remove(0)
        replaceAll(ctx, a)
        prefs(ctx).edit().putLong("chatId", id).apply()
        return id
    }

    @Synchronized
    fun setCurrent(ctx: Context, id: Long) { prefs(ctx).edit().putLong("chatId", id).apply() }

    /** The chat to write into now. It stays the same chat until the user taps New chat, so nothing seems to vanish. */
    @Synchronized
    private fun session(ctx: Context, a: JSONArray): JSONObject {
        val cur = find(a, currentId(ctx))
        if (cur != null) return cur
        val id = newSession(ctx)
        val a2 = all(ctx)
        a.put(find(a2, id))
        return find(a, id)!!
    }

    @Synchronized
    fun append(ctx: Context, kind: Int, text: String, proj: String = "", think: String = "", cmds: String = "", secs: Int = 0, attId: String = "", attName: String = "", by: String = "") {
        if (text.isBlank()) return
        val a = all(ctx)
        val s = session(ctx, a)
        val lines = s.getJSONArray("lines")
        val line = JSONObject().put("k", kind).put("t", text).put("at", System.currentTimeMillis())
        if (proj.isNotEmpty()) line.put("p", proj)
        if (think.isNotEmpty()) line.put("th", think.take(6000))
        if (cmds.isNotEmpty()) line.put("cm", cmds)
        if (secs > 0) line.put("sc", secs)
        if (attName.isNotEmpty()) line.put("an", attName)
        if (attId.isNotEmpty()) line.put("ax", attId)
        if (by.isNotEmpty()) line.put("by", by)
        lines.put(line)
        while (lines.length() > MAX_LINES) lines.remove(0)
        s.put("last", System.currentTimeMillis())
        if (s.optString("title").isEmpty() && kind == 0) s.put("title", text.take(40))
        replaceAll(ctx, a)
    }

    /** Removes the last [n] lines of the current chat (used by Regenerate). */
    @Synchronized
    fun dropLast(ctx: Context, n: Int) {
        val a = all(ctx)
        val s = find(a, currentId(ctx)) ?: return
        val lines = s.getJSONArray("lines")
        repeat(n) { if (lines.length() > 0) lines.remove(lines.length() - 1) }
        replaceAll(ctx, a)
    }

    @Synchronized
    fun setTitle(ctx: Context, id: Long, title: String) {
        val a = all(ctx)
        find(a, id)?.put("title", title.take(60))?.put("titled", true)
        replaceAll(ctx, a)
    }

    @Synchronized
    fun togglePin(ctx: Context, id: Long) {
        val a = all(ctx)
        val s = find(a, id) ?: return
        s.put("pin", !s.optBoolean("pin"))
        replaceAll(ctx, a)
    }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        val a = all(ctx)
        val keep = JSONArray()
        for (i in 0 until a.length()) {
            val s = a.getJSONObject(i)
            if (s.getLong("id") != id) { keep.put(s); continue }
            // the chat's saved attachments go with it
            val ls = s.getJSONArray("lines")
            for (j in 0 until ls.length()) {
                val ax = ls.getJSONObject(j).optString("ax")
                if (ax.isNotEmpty() && !ax.contains('/') && !ax.contains("..")) try { File(File(ctx.filesDir, "attach"), "$ax.json").delete() } catch (e: Exception) {}
            }
        }
        replaceAll(ctx, keep)
        if (currentId(ctx) == id) prefs(ctx).edit().putLong("chatId", 0L).apply()
    }

    @Synchronized
    fun lines(ctx: Context, id: Long): JSONArray = find(all(ctx), id)?.getJSONArray("lines") ?: JSONArray()

    /** Newest first: id, title, last time, number of lines. */
    @Synchronized
    fun list(ctx: Context): List<JSONObject> {
        val a = all(ctx)
        return (0 until a.length()).map { a.getJSONObject(it) }.filter { it.getJSONArray("lines").length() > 0 }.reversed()
            .sortedByDescending { it.optBoolean("pin") }
    }

    /** True when any message of the chat contains [q] (used by the history search box). */
    @Synchronized
    fun contains(ctx: Context, id: Long, q: String): Boolean {
        val w = q.lowercase(Locale.ROOT)
        val ls = lines(ctx, id)
        for (i in 0 until ls.length()) {
            val o = ls.getJSONObject(i)
            if (o.getInt("k") < 2 && o.optString("t").lowercase(Locale.ROOT).contains(w)) return true
        }
        return false
    }

    fun title(s: JSONObject) = s.optString("title").ifBlank { "New chat" }

    /** The whole chat as plain text, for Copy / Share. */
    fun transcript(ctx: Context, id: Long): String {
        val ls = lines(ctx, id)
        val sb = StringBuilder()
        for (i in 0 until ls.length()) {
            val o = ls.getJSONObject(i)
            if (o.getInt("k") > 1) continue
            sb.append(if (o.getInt("k") == 0) "You: " else "Anjoo: ").append(o.getString("t")).append("\n\n")
        }
        return sb.toString().trim()
    }

    fun dateOf(ms: Long): String = SimpleDateFormat("d MMM HH:mm", Locale.ENGLISH).format(Date(ms))

    /** A few lines about earlier chats, put in the prompt so Anjoo remembers them. */
    fun recentContext(ctx: Context): String {
        val cur = currentId(ctx)
        val old = list(ctx).filter { it.getLong("id") != cur }.take(4)
        if (old.isEmpty()) return ""
        val sb = StringBuilder("Pichli baat-cheet ka khulasa (yaad rakho):\n")
        for (s in old) {
            val ls = s.getJSONArray("lines")
            var lastBot = ""
            for (i in ls.length() - 1 downTo 0) {
                val o = ls.getJSONObject(i)
                if (o.getInt("k") == 1) { lastBot = o.getString("t"); break }
            }
            sb.append("- ").append(dateOf(s.getLong("last"))).append(" | ").append(title(s))
            if (lastBot.isNotEmpty()) sb.append(" | akhri jawab: ").append(lastBot.take(120))
            sb.append("\n")
        }
        return sb.toString()
    }

    @Synchronized
    fun search(ctx: Context, q: String): String {
        val w = q.lowercase(Locale.ROOT)
        val out = StringBuilder()
        val a = all(ctx)
        var n = 0
        for (i in a.length() - 1 downTo 0) {
            val s = a.getJSONObject(i)
            val ls = s.getJSONArray("lines")
            for (j in 0 until ls.length()) {
                val o = ls.getJSONObject(j)
                if (o.getInt("k") < 2 && o.getString("t").lowercase(Locale.ROOT).contains(w)) {
                    out.append(dateOf(o.getLong("at"))).append(" [").append(title(s)).append("] ")
                        .append(if (o.getInt("k") == 0) "user: " else "anjoo: ").append(o.getString("t").take(160)).append("\n")
                    if (++n >= 8) return out.toString()
                }
            }
        }
        return if (out.isEmpty()) "Purani chats mein kuch nahi mila." else out.toString()
    }
}
