package com.anjoo.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Prompt engineering on demand, in three passes so that nothing is missing:
 *  1. SPEC   - the idea is turned into a complete requirements list (stated, implied, edge cases, assumptions).
 *  2. WRITE  - a full, structured prompt is written that covers every item of that list.
 *  3. AUDIT  - a strict reviewer compares the prompt with the idea and the list, fills every gap and fixes weak spots.
 *
 *  make():    a rough idea (or an existing draft prompt) -> one complete, ready-to-paste prompt for ChatGPT / Claude / Gemini /
 *             an image or video tool / a coder / an agent.
 *  improve(): a short coding request -> a detailed engineering brief (used by the ✨ button in Code Studio).
 */
object PromptMaker {

    /** What a complete prompt must cover, whatever the target. The writer and the auditor both work from this list. */
    private const val CORE = "CORE CHECKLIST (every prompt must cover each item that applies; never leave one out silently):\n" +
        "1 ROLE: a specific expert persona with the experience level and viewpoint needed.\n" +
        "2 GOAL: the real objective, why it matters, and what a perfect result looks like (success criteria that can be checked).\n" +
        "3 AUDIENCE and USE: who reads or uses the result, and where it will be used.\n" +
        "4 CONTEXT: background, domain facts, current situation, existing work that must be kept.\n" +
        "5 INPUTS: everything the AI will receive, with [PLACEHOLDERS] for unknown details (never invent facts, names, numbers, prices or sources).\n" +
        "6 TASK: numbered steps in the right order; for hard work tell the AI to plan first, then do, then verify.\n" +
        "7 SCOPE: what is included and what is explicitly out of scope.\n" +
        "8 CONSTRAINTS: must / must not / never; length; tone; reading level; language and script; versions, budget, time, platform limits.\n" +
        "9 STYLE and VOICE: tone, vocabulary, formatting habits, what to avoid (filler, flattery, generic phrases).\n" +
        "10 OUTPUT FORMAT: the exact structure (headings, order, tables, bullet rules, JSON schema, file names, word counts).\n" +
        "11 EXAMPLES: one short good example of the wanted output, and when it helps one bad example to avoid.\n" +
        "12 EDGE CASES and FAILURE HANDLING: missing or contradictory input, ambiguity, errors, unsafe or impossible requests, what to do then.\n" +
        "13 QUALITY BAR: a self-check list the AI must run before answering (accuracy, completeness, format, constraints respected).\n" +
        "14 ASSUMPTIONS: every default chosen for the user, stated openly inside the prompt so they can be changed.\n" +
        "15 INTERACTION RULES: ask a question only when truly blocked, otherwise proceed with stated assumptions; how to handle follow-ups.\n" +
        "16 DEPTH: how thorough to be, and what to do when the answer is long (continue in parts, never cut off or summarise by placeholders).\n"

    /** Extra things to cover for each kind of target. */
    private const val TARGETS = "TARGET-SPECIFIC ADDITIONS:\n" +
        "CODE / APP / WEBSITE / SCRIPT: language and exact version, platform and min OS/browser, framework and libraries (and which NOT to use), project/folder structure with file names, " +
        "full feature list, screens or pages and navigation, data model and storage, state handling, API/network behaviour, authentication and permissions, error, empty and loading states, " +
        "input validation, security (secrets, injection, permissions), performance, accessibility, responsive and RTL/Urdu text support when relevant, logging, tests (unit and manual test cases), " +
        "build and run steps, and the rule: deliver COMPLETE runnable files with no TODOs, no '...' and no placeholders; list files in order; explain nothing before the code unless asked.\n" +
        "IMAGE: subject and count, action, setting and background, art style or medium, era, lighting, camera angle, lens, depth of field, composition, colour palette, mood, textures, level of detail, " +
        "aspect ratio, resolution, text inside the image (exact words), consistency notes, a NEGATIVE prompt line, and tool parameters when the tool is known (Midjourney --ar --stylize, Stable Diffusion steps/CFG/sampler). Write the main part as dense English description.\n" +
        "VIDEO: duration, aspect ratio and fps, a shot-by-shot list (shot number, framing, camera movement, subject action, setting, lighting, seconds), transitions, style reference, colour grade, " +
        "on-screen text, voice-over script, music and sound effects, pacing, consistency of characters between shots, and a negative line.\n" +
        "WRITING / MARKETING / SOCIAL / EMAIL: audience persona, goal and call-to-action, tone, brand voice, length per piece, structure (hook, body, close), keywords, platform rules, language and script, number of variations, what claims to avoid.\n" +
        "RESEARCH / STUDY / TEACHING: question scope, depth, time range and recency, source types to trust and how to cite them, how to separate facts from estimates, structure of the report, comparison tables, level of the learner, practice questions and answers.\n" +
        "DATA / ANALYSIS / SPREADSHEET: data description and columns, cleaning rules, calculations with formulas, assumptions, charts wanted, validation checks, output tables, how to show uncertainty.\n" +
        "BUSINESS / REAL ESTATE / SALES / FINANCE: market and location, customer type, offer details as [PLACEHOLDERS], pricing logic, legal or compliance cautions, tone, deliverables (listing text, ad copy, scripts, follow-ups), measurable goals.\n" +
        "AGENT / AUTOMATION / SYSTEM PROMPT: the agent's identity and limits, the tools it may use and when, step loop (plan, act, check), stop conditions, what needs human confirmation, safety and privacy rules, how to report results honestly, what to do on failure.\n"

    private const val SPEC_SYS = "You are a senior prompt engineer and requirements analyst. Do NOT write the final prompt yet. " +
        "Read the user's idea (it may be rough, in Roman Urdu, Urdu or English, or it may already be a draft prompt) and produce a complete REQUIREMENTS SPEC that a prompt writer can follow without missing anything.\n" +
        "Write plain text with these numbered sections, each as short bullet lines:\n" +
        "A. TARGET and USE: the tool the prompt is for and where the result will be used.\n" +
        "B. REAL GOAL and SUCCESS CRITERIA.\n" +
        "C. STATED REQUIREMENTS: every single thing the user asked for or mentioned, one per line, in the user's own meaning (nothing dropped, nothing reworded into something else).\n" +
        "D. IMPLIED REQUIREMENTS: what an expert would add so the result is complete and excellent for this goal.\n" +
        "E. DETAILS STILL UNKNOWN: facts only the user knows (names, numbers, places, dates, links, brand). These become [PLACEHOLDERS], never invented.\n" +
        "F. EDGE CASES and RISKS: what could go wrong or be misunderstood by the AI.\n" +
        "G. ASSUMPTIONS: sensible defaults you chose (language, tone, length, format, versions).\n" +
        "H. OUTPUT SHAPE: exactly what the final answer from the target AI should look like.\n" +
        "Be concrete and measurable. Do not ask questions here. Under 700 words.\n\n" + CORE + "\n" + TARGETS

    private const val WRITE_SYS = "You are a world-class prompt engineer. Write ONE complete, detailed, ready-to-paste prompt for the target tool, based on the user's idea and the REQUIREMENTS SPEC.\n" +
        "RULES:\n" +
        "- Cover EVERY item of the spec and every item of the CORE CHECKLIST that applies. If the user gave a draft prompt, keep every instruction in it and strengthen it.\n" +
        "- Use clear labelled sections in this order when they apply: ROLE, GOAL AND SUCCESS CRITERIA, AUDIENCE, CONTEXT, INPUTS, TASK (numbered), SCOPE, CONSTRAINTS, STYLE, OUTPUT FORMAT, EXAMPLE, EDGE CASES, QUALITY CHECKLIST, ASSUMPTIONS, INTERACTION RULES.\n" +
        "- Be specific and measurable. Use [PLACEHOLDERS] for unknown facts; never invent facts, prices, names, statistics or sources.\n" +
        "- Write full sentences for instructions; no filler like 'please' or 'best possible'. Detail is welcome, repetition is not.\n" +
        "- Write the prompt in English unless the user clearly wants the answer or the prompt in another language; if the final answer must be in Urdu or Roman Urdu, say so inside the prompt.\n" +
        "- Do not put triple backticks inside the prompt (it will be shown inside a code block); use indentation or tags for code samples.\n" +
        "- Length: as long as completeness needs (typically 350 to 1200 words, more for big projects), never padded.\n" +
        "Output ONLY the prompt text, no preface and no commentary.\n\n" + CORE + "\n" + TARGETS

    private const val AUDIT_SYS = "You are a strict prompt reviewer. You get the user's ORIGINAL IDEA, the REQUIREMENTS SPEC and a DRAFT PROMPT. Your job: make sure NOTHING is missing.\n" +
        "STEPS (do them silently): 1) tick every STATED requirement of the idea against the draft; 2) tick every item of the CORE CHECKLIST and the matching target-specific list; " +
        "3) find vague words, contradictions, invented facts, missing output format, missing edge cases, missing quality checks; 4) rewrite the prompt so every gap is filled and every weakness fixed, " +
        "keeping what was already good. Never shorten the prompt by removing needed detail.\n" +
        "OUTPUT, exactly in this order:\n" +
        "1. The FINAL complete prompt alone inside ONE fenced code block (no triple backticks inside it).\n" +
        "2. One line 'Kyun behtar hai:' with at most 3 short reasons.\n" +
        "3. One line 'Maine ye maan liya:' with at most 5 short assumptions or placeholders the user should fill in.\n" +
        "4. Only if something important is still unknown: one line 'Aur behtar banane ke liye bataiye:' with at most 3 short questions.\n" +
        "Lines 2 to 4 use the user's own language style (Roman Urdu or English).\n\n" + CORE + "\n" + TARGETS

    private const val IMPROVE_SYS = "You rewrite a developer's short request into a complete engineering brief for an AI coder. " +
        "Keep EVERY detail and wish the user gave, and add what a senior engineer would require so nothing is missing:\n" +
        "GOAL and who uses it; STACK (the project's existing one, or the best fit with versions); FEATURES (full list, grouped); SCREENS or MODULES with navigation; " +
        "DATA MODEL and saved state; INPUT VALIDATION; EDGE, EMPTY, LOADING and ERROR states; SECURITY and PERMISSIONS; PERFORMANCE; UI QUALITY (responsive, accessible, polished, RTL/Urdu text if relevant); " +
        "FILE STRUCTURE; TESTS (manual test cases); DELIVERY (complete runnable files, no placeholders). " +
        "If a project already exists, say exactly what must stay unchanged. Do not invent brand names or facts; use [PLACEHOLDERS] for unknown details. " +
        "Write plain text in English as a labelled list of requirements, between 250 and 600 words. Output ONLY the brief: no preface, no code fences, no commentary."

    private fun call(ctx: Context, system: String, ask: String, max: Int, task: Task = Task.THINK): String {
        val p = ctx.getSharedPreferences("anjoo", Context.MODE_PRIVATE)
        Providers.load(p)
        val key = p.getString("key", "") ?: ""
        if (key.isEmpty()) return ""
        val model = p.getString("model", "gemini-3.8-flash") ?: "gemini-3.8-flash"
        Router.taskOverride.set(task)
        return try {
            Gemini.plain(key, model, system, JSONArray().put(JSONObject().put("text", ask)), max).trim()
        } catch (e: Exception) { "" } finally { Router.taskOverride.remove() }
    }

    private fun ensureFence(s: String): String = if (s.contains("```")) s else "```\n" + s.trim() + "\n```"

    /** [target] is where the prompt will be used (chatgpt, claude, gemini, image, video, code, general ...). */
    fun make(ctx: Context, idea: String, target: String): String {
        if (idea.isBlank()) return "Batayein kis cheez ka prompt chahiye."
        val head = "TARGET: " + target.ifBlank { "any AI assistant" } + "\nUSER'S IDEA:\n" + idea
        val task = if (Regex("code|app|web|script|program", RegexOption.IGNORE_CASE).containsMatchIn(target)) Task.CODE else Task.THINK
        // 1) full requirements list
        val spec = call(ctx, SPEC_SYS, head, 3500, task)
        // 2) the full prompt
        val draft = call(ctx, WRITE_SYS, head + (if (spec.isNotEmpty()) "\n\nREQUIREMENTS SPEC:\n" + spec else ""), 8000, task)
        if (draft.isEmpty()) return "Prompt nahi ban saka. Settings mein API key check karein aur dobara koshish karein."
        // 3) audit: fill every gap
        val audited = call(ctx, AUDIT_SYS, head + "\n\nREQUIREMENTS SPEC:\n" + spec + "\n\nDRAFT PROMPT:\n" + draft, 8000, task)
        val out = if (audited.contains("```")) audited else ensureFence(draft.removePrefix("```").removeSuffix("```").trim()) +
            "\nKyun behtar hai: har zaroori hissa (role, maqsad, inputs, qadam, qaaide, output format, misaal, edge cases, quality check) shamil hai."
        return "Prompt taiyar hai. User ko ye poora jawab waise ka waisa dikhao (code block mein prompt, phir neeche ki lines), badlo mat:\n\n" + out
    }

    /** Short request -> brief. Returns "" when it could not be done. */
    fun improve(ctx: Context, request: String, projectInfo: String): String =
        call(ctx, IMPROVE_SYS, (if (projectInfo.isNotBlank()) "EXISTING PROJECT:\n" + projectInfo + "\n\n" else "") + "REQUEST:\n" + request, 3000, Task.CODE)
            .removePrefix("```").removeSuffix("```").trim()
}
