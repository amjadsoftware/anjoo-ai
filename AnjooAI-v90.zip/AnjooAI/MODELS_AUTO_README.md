# v85: Kaam ke hisaab se model, multi-key, aur "kaun kya kar raha hai"

- Menu (+) → "🔑 Keys add karo": saari keys ek saath paste karo. Company khud pehchan li jati hai (AIza = Gemini, gsk_ = Groq, sk-or- = OpenRouter, sk-ant- = Claude ... baaqi ko check karke). Ek company ki kayi keys ho sakti hain.
- Har message ek kaam mein baanta jata hai: seedhi baat, phone ke kaam, coding, gehri soch/hisaab, likhna/tarjuma, photo/PDF, web. Us kaam ke liye sab se munasib model jawab deta hai; baaqi sab tayyar rehte hain.
- Ek key ki limit khatam ho to usi company ki doosri key foran lag jati hai; phir doosra model.
- Jawab ke end par: "🤖 Banaya: company · model · kaam · N aur models tayyar". Kaam ke dauran neeche live dikhta hai kaun sa model chal raha hai.
- Menu (+) → "🧭 Models aur keys": kaun si company/kitni keys/har model kis kaam ka, aur abhi har kaam kaun karega.
- Paid companies (OpenAI, Claude, xAI ...) tab hi istemal hoti hain jab unki key add ho; barabar score par free model ko tarjeeh milti hai.
- Settings → AI "Auto" band karne par sirf chuna hua model chalta hai.
- Naya: Errors.kt (har masla "kya hua / wajah / hal"), pichli baar crash ho to agli dafa wajah dikhti hai.
